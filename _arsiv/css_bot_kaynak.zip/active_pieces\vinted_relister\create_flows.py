# Flow dosyalarini olusturan script
import os

BASE = r'c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces\vinted_relister'
FLOWS = os.path.join(BASE, 'flows')
os.makedirs(FLOWS, exist_ok=True)

# Flow 1: Scraper
flow1 = r'''# Flow 1: Vinted Product Scraper
import sys, os, time, requests, re
from typing import List, Dict, Optional
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')

from playwright.sync_api import sync_playwright
from config import BASE_DIR, RAW_DIR
from utils.database import db

class VintedScraper:
    def __init__(self, store_name: str, limit: int = 15):
        self.store_name = store_name
        self.limit = limit
        self.store = db.get_store_by_name(store_name)
        if not self.store:
            raise ValueError(f'Store not found: {store_name}')
        self.profile_url = self.store.get('profile_url', '')
        self.playwright_profile = self.store.get('chrome_profile', store_name)
        self.proxy_enabled = self.store.get('proxy_enabled', 0)
        self.proxy_host = self.store.get('proxy_host', '')
        self.proxy_port = self.store.get('proxy_port', 0)
        os.makedirs(RAW_DIR, exist_ok=True)

    def get_browser(self, pw):
        pdir = os.path.join(BASE_DIR, 'playwright_profiles', self.playwright_profile)
        os.makedirs(pdir, exist_ok=True)
        args = ['--disable-blink-features=AutomationControlled', '--no-sandbox']
        if self.proxy_enabled and self.proxy_host:
            args.append(f'--proxy-server=http://{self.proxy_host}:{self.proxy_port}')
        return pw.chromium.launch_persistent_context(user_data_dir=pdir, headless=False,
            args=args, viewport={'width':1920,'height':1080}, locale='de-DE', timezone_id='Europe/Berlin')

    def get_product_urls(self) -> List[str]:
        print(f'[SCRAPER] {self.store_name} - {self.profile_url}')
        urls = []
        with sync_playwright() as pw:
            br = self.get_browser(pw)
            pg = br.pages[0] if br.pages else br.new_page()
            try:
                pg.goto(self.profile_url + '/items', wait_until='domcontentloaded', timeout=60000)
                pg.wait_for_timeout(3000)
                try:
                    cb = pg.query_selector('[data-testid="cookie-consent-accept-all"]')
                    if cb: cb.click(); pg.wait_for_timeout(1000)
                except: pass
                for _ in range(3):
                    pg.evaluate('window.scrollTo(0, document.body.scrollHeight)')
                    pg.wait_for_timeout(2000)
                seen = set()
                for lnk in pg.query_selector_all('a[href*="/items/"]'):
                    href = lnk.get_attribute('href')
                    if href and re.search(r'/items/\d+', href):
                        full = f'https://www.vinted.de{href}' if href.startswith('/') else href
                        if full not in seen:
                            seen.add(full); urls.append(full)
                            if len(urls) >= self.limit: break
                print(f'[OK] {len(urls)} URL bulundu')
            except Exception as e: print(f'[ERROR] {e}')
            finally: br.close()
        return urls

    def get_product(self, url: str) -> Optional[Dict]:
        with sync_playwright() as pw:
            br = self.get_browser(pw)
            pg = br.pages[0] if br.pages else br.new_page()
            try:
                pg.goto(url, wait_until='domcontentloaded', timeout=60000)
                pg.wait_for_timeout(3000)
                vid = re.search(r'/items/(\d+)', url)
                if not vid: br.close(); return None
                data = {'vinted_id': vid.group(1), 'vinted_url': url, 'source_store': self.store_name}
                el = pg.query_selector('[data-testid="item-title"], h1')
                if el: data['raw_title'] = el.inner_text().strip()
                el = pg.query_selector('[data-testid="item-description"]')
                if el: data['raw_description'] = el.inner_text().strip()
                el = pg.query_selector('[data-testid="item-price"]')
                if el:
                    m = re.search(r'[\d,\.]+', el.inner_text().replace(',','.'))
                    if m: data['price'] = float(m.group())
                el = pg.query_selector('a[href*="/brand/"]')
                if el: data['brand'] = el.inner_text().strip()
                imgs = []
                for im in pg.query_selector_all('[data-testid="item-photo"] img'):
                    src = im.get_attribute('src')
                    if src and 'vinted' in src:
                        hi = re.sub(r'/f\d+x\d+/', '/f800x800/', src)
                        if hi not in imgs: imgs.append(hi)
                data['image_urls'] = imgs
                data['image_count'] = len(imgs)
                print(f'[OK] {data.get("raw_title","?")[:40]} - {len(imgs)} img')
                br.close()
                return data
            except Exception as e:
                print(f'[ERROR] {e}')
                br.close()
                return None

    def download_imgs(self, data: Dict) -> str:
        vid = data.get('vinted_id')
        urls = data.get('image_urls', [])
        if not vid or not urls: return ''
        pdir = os.path.join(RAW_DIR, vid)
        os.makedirs(pdir, exist_ok=True)
        for i, u in enumerate(urls):
            try:
                r = requests.get(u, timeout=30)
                if r.status_code == 200:
                    with open(os.path.join(pdir, f'img_{i+1}.jpg'), 'wb') as f: f.write(r.content)
            except: pass
        return pdir

    def run(self) -> List[int]:
        print('='*50 + f'\nSCRAPER: {self.store_name} - {self.limit} urun\n' + '='*50)
        urls = self.get_product_urls()
        if not urls: return []
        ids = []
        for i, url in enumerate(urls):
            print(f'\n[{i+1}/{len(urls)}] {url}')
            data = self.get_product(url)
            if not data: continue
            data['raw_images_path'] = self.download_imgs(data)
            try:
                pid = db.add_product(data)
                ids.append(pid)
                db.add_log(pid, 'scrape', 'success', f'From {self.store_name}')
                print(f'[DB] Saved ID={pid}')
            except Exception as e: print(f'[DB ERR] {e}')
            time.sleep(2)
        print(f'\n*** DONE: {len(ids)} products saved ***')
        return ids

def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--store', default='cyhn85')
    p.add_argument('--limit', type=int, default=15)
    a = p.parse_args()
    return VintedScraper(a.store, a.limit).run()

if __name__ == '__main__': main()
'''

with open(os.path.join(FLOWS, 'flow1_scraper.py'), 'w', encoding='utf-8') as f:
    f.write(flow1)
print('flow1_scraper.py created!')

# Flow 2: Image Processor
flow2 = r'''# Flow 2: Image Processor - Background removal + white background
import sys, os, shutil
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')

from config import RAW_DIR, PROCESSED_DIR, NCONVERT_PATH, STATUS_RAW, STATUS_IMAGE_DONE
from utils.database import db

class ImageProcessor:
    def __init__(self):
        os.makedirs(PROCESSED_DIR, exist_ok=True)

    def process_product(self, product_id: int) -> bool:
        product = db.get_product(product_id)
        if not product: return False

        raw_path = product.get('raw_images_path', '')
        if not raw_path or not os.path.exists(raw_path):
            print(f'[SKIP] No images: {product_id}')
            return False

        vinted_id = product.get('vinted_id', str(product_id))
        proc_path = os.path.join(PROCESSED_DIR, vinted_id)
        os.makedirs(proc_path, exist_ok=True)

        count = 0
        for fname in os.listdir(raw_path):
            if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                src = os.path.join(raw_path, fname)
                dst = os.path.join(proc_path, fname)
                try:
                    # Simple copy for now - can add rembg later
                    img = Image.open(src)
                    # Create white background
                    if img.mode == 'RGBA':
                        bg = Image.new('RGB', img.size, (255,255,255))
                        bg.paste(img, mask=img.split()[3])
                        bg.save(dst, 'JPEG', quality=95)
                    else:
                        img.convert('RGB').save(dst, 'JPEG', quality=95)
                    count += 1
                except Exception as e:
                    print(f'[ERR] {fname}: {e}')

        if count > 0:
            db.update_product(product_id, {'processed_images_path': proc_path, 'status': STATUS_IMAGE_DONE})
            db.add_log(product_id, 'image', 'success', f'{count} images processed')
            print(f'[OK] Product {product_id}: {count} images')
            return True
        return False

    def run(self) -> int:
        print('='*50 + '\nIMAGE PROCESSOR\n' + '='*50)
        products = db.get_products_by_status(STATUS_RAW)
        print(f'{len(products)} products to process')
        done = 0
        for p in products:
            if self.process_product(p['id']): done += 1
        print(f'\n*** DONE: {done} products processed ***')
        return done

def main():
    return ImageProcessor().run()

if __name__ == '__main__': main()
'''

with open(os.path.join(FLOWS, 'flow2_image.py'), 'w', encoding='utf-8') as f:
    f.write(flow2)
print('flow2_image.py created!')

# Flow 3: SEO Generator
flow3 = r'''# Flow 3: SEO Content Generator with Groq
import sys, os, json, time
import requests
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')

from config import GROQ_API_KEY, GROQ_MODEL, STATUS_IMAGE_DONE, STATUS_SEO_DONE
from utils.database import db

class SEOGenerator:
    def __init__(self):
        self.api_key = GROQ_API_KEY
        self.model = GROQ_MODEL

    def generate_seo(self, product: dict) -> dict:
        title = product.get('raw_title', '')
        desc = product.get('raw_description', '')
        brand = product.get('brand', '')

        prompt = f"""Du bist ein Vinted-Verkaufsexperte. Erstelle einen neuen Titel und eine neue Beschreibung auf Deutsch.

Original Titel: {title}
Original Beschreibung: {desc}
Marke: {brand}

Regeln:
- Titel max 70 Zeichen, SEO-optimiert
- Beschreibung 2-3 Saetze, verkaufsfoerdernd
- Erwaehne Zustand und Versand
- Keine Emojis
- Antworte NUR im JSON Format: {{"title": "...", "description": "..."}}
"""

        try:
            resp = requests.post(
                'https://api.groq.com/openai/v1/chat/completions',
                headers={'Authorization': f'Bearer {self.api_key}', 'Content-Type': 'application/json'},
                json={'model': self.model, 'messages': [{'role': 'user', 'content': prompt}], 'temperature': 0.7},
                timeout=30
            )
            if resp.status_code == 200:
                content = resp.json()['choices'][0]['message']['content']
                # Parse JSON from response
                start = content.find('{')
                end = content.rfind('}') + 1
                if start >= 0 and end > start:
                    return json.loads(content[start:end])
        except Exception as e:
            print(f'[ERR] Groq: {e}')
        return {}

    def process_product(self, product_id: int) -> bool:
        product = db.get_product(product_id)
        if not product: return False

        result = self.generate_seo(product)
        if result:
            db.update_product(product_id, {
                'processed_title': result.get('title', ''),
                'processed_description': result.get('description', ''),
                'status': STATUS_SEO_DONE
            })
            db.add_log(product_id, 'seo', 'success', 'SEO generated')
            print(f'[OK] {product_id}: {result.get("title", "")[:40]}')
            return True
        return False

    def run(self) -> int:
        print('='*50 + '\nSEO GENERATOR (Groq)\n' + '='*50)
        products = db.get_products_by_status(STATUS_IMAGE_DONE)
        print(f'{len(products)} products to process')
        done = 0
        for p in products:
            if self.process_product(p['id']): done += 1
            time.sleep(1)  # Rate limit
        print(f'\n*** DONE: {done} products ***')
        return done

def main():
    return SEOGenerator().run()

if __name__ == '__main__': main()
'''

with open(os.path.join(FLOWS, 'flow3_seo.py'), 'w', encoding='utf-8') as f:
    f.write(flow3)
print('flow3_seo.py created!')

# Flow 4: Validator
flow4 = r'''# Flow 4: Content Validator with Gemini
import sys, os, json
import google.generativeai as genai
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')

from config import GEMINI_API_KEY, STATUS_SEO_DONE, STATUS_VALIDATED
from utils.database import db

class ContentValidator:
    def __init__(self):
        genai.configure(api_key=GEMINI_API_KEY)
        self.model = genai.GenerativeModel('gemini-1.5-flash')

    def validate(self, product: dict) -> dict:
        title = product.get('processed_title', '')
        desc = product.get('processed_description', '')

        prompt = f"""Pruefe diesen Vinted-Eintrag auf Qualitaet:

Titel: {title}
Beschreibung: {desc}

Bewerte (1-10) und gib Feedback. Antworte NUR als JSON:
{{"score": 8, "valid": true, "notes": "Gut geschrieben"}}
"""
        try:
            resp = self.model.generate_content(prompt)
            text = resp.text
            start = text.find('{')
            end = text.rfind('}') + 1
            if start >= 0 and end > start:
                return json.loads(text[start:end])
        except Exception as e:
            print(f'[ERR] Gemini: {e}')
        return {'score': 5, 'valid': True, 'notes': 'Auto-approved'}

    def process_product(self, product_id: int) -> bool:
        product = db.get_product(product_id)
        if not product: return False

        result = self.validate(product)
        if result.get('valid', True):
            db.update_product(product_id, {
                'status': STATUS_VALIDATED,
                'validation_notes': result.get('notes', '')
            })
            db.add_log(product_id, 'validate', 'success', f"Score: {result.get('score', 0)}")
            print(f'[OK] {product_id}: Score {result.get("score", 0)}')
            return True
        return False

    def run(self) -> int:
        print('='*50 + '\nVALIDATOR (Gemini)\n' + '='*50)
        products = db.get_products_by_status(STATUS_SEO_DONE)
        print(f'{len(products)} products to validate')
        done = 0
        for p in products:
            if self.process_product(p['id']): done += 1
        print(f'\n*** DONE: {done} validated ***')
        return done

def main():
    return ContentValidator().run()

if __name__ == '__main__': main()
'''

with open(os.path.join(FLOWS, 'flow4_validator.py'), 'w', encoding='utf-8') as f:
    f.write(flow4)
print('flow4_validator.py created!')

# Flow 5: Uploader
flow5 = r'''# Flow 5: Vinted Uploader
import sys, os, time, random
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')

from playwright.sync_api import sync_playwright
from config import BASE_DIR, STATUS_VALIDATED, STATUS_UPLOADED, DELAY_BETWEEN_PRODUCTS
from utils.database import db

class VintedUploader:
    def __init__(self, target_store: str):
        self.target_store = target_store
        self.store = db.get_store_by_name(target_store)
        if not self.store:
            raise ValueError(f'Store not found: {target_store}')
        self.playwright_profile = self.store.get('chrome_profile', target_store)
        self.proxy_enabled = self.store.get('proxy_enabled', 0)
        self.proxy_host = self.store.get('proxy_host', '')
        self.proxy_port = self.store.get('proxy_port', 0)

    def get_browser(self, pw):
        pdir = os.path.join(BASE_DIR, 'playwright_profiles', self.playwright_profile)
        os.makedirs(pdir, exist_ok=True)
        args = ['--disable-blink-features=AutomationControlled', '--no-sandbox']
        if self.proxy_enabled and self.proxy_host:
            args.append(f'--proxy-server=http://{self.proxy_host}:{self.proxy_port}')
            print(f'[PROXY] {self.proxy_host}:{self.proxy_port}')
        return pw.chromium.launch_persistent_context(user_data_dir=pdir, headless=False,
            args=args, viewport={'width':1920,'height':1080}, locale='de-DE', timezone_id='Europe/Berlin')

    def upload_product(self, product: dict) -> bool:
        print(f'[UPLOAD] {product.get("processed_title", "?")[:40]}')

        with sync_playwright() as pw:
            br = self.get_browser(pw)
            pg = br.pages[0] if br.pages else br.new_page()
            try:
                pg.goto('https://www.vinted.de/items/new', wait_until='domcontentloaded', timeout=60000)
                pg.wait_for_timeout(3000)

                # Check login
                if pg.query_selector('[data-testid="header-login-button"]'):
                    print('[WARN] Not logged in!')
                    br.close()
                    return False

                # TODO: Implement full form filling
                # This is a placeholder - real implementation needs form interaction
                print('[INFO] Upload form opened - manual completion needed')
                pg.wait_for_timeout(5000)

                br.close()
                return True
            except Exception as e:
                print(f'[ERROR] {e}')
                br.close()
                return False

    def run(self, limit: int = 15) -> int:
        print('='*50 + f'\nUPLOADER: {self.target_store}\n' + '='*50)
        products = db.get_products_by_status(STATUS_VALIDATED)[:limit]
        print(f'{len(products)} products to upload')
        done = 0
        for p in products:
            if self.upload_product(p):
                db.update_product(p['id'], {'status': STATUS_UPLOADED, 'target_store': self.target_store})
                db.add_log(p['id'], 'upload', 'success', f'To {self.target_store}')
                done += 1
            delay = random.randint(*DELAY_BETWEEN_PRODUCTS)
            print(f'[WAIT] {delay}s before next...')
            time.sleep(delay)
        print(f'\n*** DONE: {done} uploaded ***')
        return done

def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--store', default='cssberlin')
    p.add_argument('--limit', type=int, default=15)
    a = p.parse_args()
    return VintedUploader(a.store).run(a.limit)

if __name__ == '__main__': main()
'''

with open(os.path.join(FLOWS, 'flow5_uploader.py'), 'w', encoding='utf-8') as f:
    f.write(flow5)
print('flow5_uploader.py created!')

print('\n*** ALL FLOWS CREATED! ***')
