# VPN Manager - Windscribe CLI Integration
# Manages VPN connection, quota tracking, and auto-switching
# MULTI-ACCOUNT SUPPORT: Auto-rotate between accounts when quota low

import os
import sys
import subprocess
import time
import sqlite3
from datetime import datetime, timedelta
from typing import Optional, Tuple, List

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'vpn_quota.db')

# ============================================================================
# WINDSCRIBE ACCOUNTS (Çoklu Hesap)
# ============================================================================
# Hesapları windscribe_accounts.py dosyasından yükle
try:
    from windscribe_accounts import ACCOUNTS as WINDSCRIBE_ACCOUNTS
    from windscribe_accounts import SWITCH_THRESHOLD_MB, DAILY_LIMIT_GB as DAILY_QUOTA_GB
    from windscribe_accounts import PREFERRED_LOCATION
    print(f'[OK] {len([a for a in WINDSCRIBE_ACCOUNTS if a.get("email")])} Windscribe account(s) loaded')
except ImportError:
    WINDSCRIBE_ACCOUNTS = []
    SWITCH_THRESHOLD_MB = 500
    DAILY_QUOTA_GB = 1
    PREFERRED_LOCATION = 'best'
    print('[WARN] windscribe_accounts.py not found - using defaults')

# Quota Settings
TOTAL_MONTHLY_QUOTA_GB = sum(a.get('monthly_quota_gb', 10) for a in WINDSCRIBE_ACCOUNTS) or 10
QUOTA_WARNING_PERCENT = 70  # Warn at 70% usage

class VPNManager:
    def __init__(self):
        self._init_db()
        self.connected = False
        self.current_account = None
        self.accounts = WINDSCRIBE_ACCOUNTS
        print('[OK] VPN Manager initialized (Multi-Account)')

    def get_active_accounts(self) -> List[dict]:
        """Get accounts with credentials configured (username required)"""
        return [a for a in self.accounts if a.get('username') and a.get('password')]

    def _init_db(self):
        """Initialize quota tracking database"""
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()

        # Account-based usage tracking
        c.execute('''CREATE TABLE IF NOT EXISTS vpn_usage (
            id INTEGER PRIMARY KEY,
            date TEXT,
            account_id TEXT,
            bytes_used INTEGER DEFAULT 0,
            sessions INTEGER DEFAULT 0,
            store TEXT,
            UNIQUE(date, account_id)
        )''')

        c.execute('''CREATE TABLE IF NOT EXISTS vpn_sessions (
            id INTEGER PRIMARY KEY,
            start_time TEXT,
            end_time TEXT,
            account_id TEXT,
            store TEXT,
            bytes_start INTEGER,
            bytes_end INTEGER,
            status TEXT
        )''')

        # Account status tracking
        c.execute('''CREATE TABLE IF NOT EXISTS vpn_accounts (
            id TEXT PRIMARY KEY,
            email TEXT,
            last_used TEXT,
            total_bytes_used INTEGER DEFAULT 0,
            month_reset TEXT,
            status TEXT DEFAULT 'active'
        )''')

        conn.commit()
        conn.close()

    # =========================================================================
    # WINDSCRIBE CLI COMMANDS
    # =========================================================================

    def is_windscribe_installed(self) -> bool:
        """Check if Windscribe CLI is available"""
        try:
            result = subprocess.run(
                ['windscribe', 'status'],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0 or 'windscribe' in result.stdout.lower()
        except FileNotFoundError:
            return False
        except Exception:
            return False

    def get_status(self) -> dict:
        """Get Windscribe connection status"""
        try:
            result = subprocess.run(
                ['windscribe', 'status'],
                capture_output=True,
                text=True,
                timeout=10
            )
            output = result.stdout.lower()

            return {
                'installed': True,
                'connected': 'connected' in output and 'disconnected' not in output,
                'ip': self._parse_ip(result.stdout),
                'location': self._parse_location(result.stdout),
                'raw': result.stdout
            }
        except FileNotFoundError:
            return {'installed': False, 'connected': False, 'error': 'Windscribe not installed'}
        except Exception as e:
            return {'installed': False, 'connected': False, 'error': str(e)}

    def connect(self, location: str = None) -> Tuple[bool, str]:
        """Connect to Windscribe VPN (default: Germany)"""
        if location is None:
            location = PREFERRED_LOCATION  # Default: Germany

        if not self.is_windscribe_installed():
            return False, 'Windscribe not installed'

        # Check quota before connecting
        quota_ok, quota_msg = self.check_quota()
        if not quota_ok:
            return False, f'Quota exceeded: {quota_msg}'

        try:
            print(f'[VPN] Connecting to {location}...')

            # Connect command
            result = subprocess.run(
                ['windscribe', 'connect', location],
                capture_output=True,
                text=True,
                timeout=30
            )

            # Verify connection
            time.sleep(3)
            status = self.get_status()

            if status.get('connected'):
                self.connected = True
                self._start_session()
                return True, f"Connected to {status.get('location', location)}"
            else:
                return False, f"Connection failed: {result.stdout}"

        except subprocess.TimeoutExpired:
            return False, 'Connection timeout'
        except Exception as e:
            return False, str(e)

    def disconnect(self) -> Tuple[bool, str]:
        """Disconnect from Windscribe VPN"""
        try:
            print('[VPN] Disconnecting...')

            result = subprocess.run(
                ['windscribe', 'disconnect'],
                capture_output=True,
                text=True,
                timeout=15
            )

            time.sleep(2)
            self.connected = False
            self._end_session()

            return True, 'Disconnected'

        except Exception as e:
            return False, str(e)

    def _parse_ip(self, output: str) -> Optional[str]:
        """Parse IP from windscribe status output"""
        import re
        match = re.search(r'IP:\s*(\d+\.\d+\.\d+\.\d+)', output)
        return match.group(1) if match else None

    def _parse_location(self, output: str) -> Optional[str]:
        """Parse location from windscribe status output"""
        import re
        match = re.search(r'(?:Location|Server):\s*(.+)', output, re.IGNORECASE)
        return match.group(1).strip() if match else None

    # =========================================================================
    # MULTI-ACCOUNT MANAGEMENT
    # =========================================================================

    def get_best_account(self) -> Optional[dict]:
        """Get account with most remaining quota (must have username)"""
        best = None
        best_remaining = -1

        for account in self.accounts:
            # Username required for login
            if not account.get('username'):
                continue

            remaining = self.get_account_remaining_mb(account['id'])
            if remaining > best_remaining:
                best = account
                best_remaining = remaining

        return best

    def get_account_remaining_mb(self, account_id: str) -> float:
        """Get remaining MB for a specific account"""
        account = next((a for a in self.accounts if a['id'] == account_id), None)
        if not account:
            return 0

        quota_gb = account.get('monthly_quota_gb', 10)
        used_gb = self.get_account_monthly_usage_gb(account_id)
        remaining_mb = (quota_gb - used_gb) * 1024

        return max(0, remaining_mb)

    def get_account_monthly_usage_gb(self, account_id: str) -> float:
        """Get monthly usage for specific account"""
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()

        today = datetime.now()
        first_day = today.replace(day=1).strftime('%Y-%m-%d')

        c.execute('''
            SELECT COALESCE(SUM(bytes_used), 0)
            FROM vpn_usage
            WHERE date >= ? AND account_id = ?
        ''', (first_day, account_id))

        bytes_used = c.fetchone()[0]
        conn.close()

        return bytes_used / (1024 ** 3)

    def should_switch_account(self) -> bool:
        """Check if current account should be switched (quota low)"""
        if not self.current_account:
            return True

        remaining = self.get_account_remaining_mb(self.current_account['id'])
        return remaining < SWITCH_THRESHOLD_MB

    def switch_to_best_account(self) -> Tuple[bool, str]:
        """Switch to account with best quota"""
        best = self.get_best_account()

        if not best:
            return False, 'No accounts with quota available'

        if best.get('id') == getattr(self.current_account, 'id', None):
            return True, f'Already on best account: {best["id"]}'

        # Logout current account
        if self.current_account:
            self._logout_windscribe()

        # Login to new account (use username, not email)
        success = self._login_windscribe(best['username'], best['password'])

        if success:
            self.current_account = best
            print(f'[VPN] Switched to account: {best["id"]} ({self.get_account_remaining_mb(best["id"]):.0f}MB remaining)')
            return True, f'Switched to {best["id"]}'
        else:
            return False, f'Failed to login to {best["id"]}'

    def _login_windscribe(self, username: str, password: str) -> bool:
        """Login to Windscribe with username and password"""
        try:
            print(f'[VPN] Logging in as {username}...')
            result = subprocess.run(
                ['windscribe', 'login'],
                input=f'{username}\n{password}\n',
                capture_output=True,
                text=True,
                timeout=30
            )
            success = 'logged in' in result.stdout.lower() or result.returncode == 0
            if success:
                print(f'[VPN] Login successful: {username}')
            else:
                print(f'[VPN] Login failed: {result.stdout}')
            return success
        except Exception as e:
            print(f'[VPN] Login error: {e}')
            return False

    def _logout_windscribe(self) -> bool:
        """Logout from Windscribe"""
        try:
            subprocess.run(['windscribe', 'logout'], capture_output=True, timeout=10)
            return True
        except:
            return False

    # =========================================================================
    # QUOTA MANAGEMENT
    # =========================================================================

    def check_quota(self) -> Tuple[bool, str]:
        """Check if quota allows more usage (multi-account aware)"""
        daily = self.get_daily_usage_gb()

        # Check daily self-imposed limit (all accounts combined)
        if daily >= DAILY_QUOTA_GB:
            return False, f'Daily limit reached: {daily:.2f}GB / {DAILY_QUOTA_GB}GB'

        # Check if current account needs switching
        if self.should_switch_account():
            success, msg = self.switch_to_best_account()
            if not success:
                return False, f'All accounts exhausted: {msg}'

        # Check current account quota
        if self.current_account:
            remaining = self.get_account_remaining_mb(self.current_account['id'])
            if remaining < 100:  # Less than 100MB
                return False, f'Account {self.current_account["id"]} quota too low: {remaining:.0f}MB'

        return True, f'OK: Using {self.current_account["id"] if self.current_account else "default"}'

    def get_monthly_usage_gb(self) -> float:
        """Get current month's VPN data usage in GB"""
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()

        # Get first day of current month
        today = datetime.now()
        first_day = today.replace(day=1).strftime('%Y-%m-%d')

        c.execute('''
            SELECT COALESCE(SUM(bytes_used), 0)
            FROM vpn_usage
            WHERE date >= ?
        ''', (first_day,))

        bytes_used = c.fetchone()[0]
        conn.close()

        return bytes_used / (1024 ** 3)  # Convert to GB

    def get_daily_usage_gb(self) -> float:
        """Get today's VPN data usage in GB"""
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()

        today = datetime.now().strftime('%Y-%m-%d')

        c.execute('''
            SELECT COALESCE(SUM(bytes_used), 0)
            FROM vpn_usage
            WHERE date = ?
        ''', (today,))

        bytes_used = c.fetchone()[0]
        conn.close()

        return bytes_used / (1024 ** 3)

    def record_usage(self, bytes_used: int, store: str = 'cssberlin'):
        """Record VPN data usage"""
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()

        today = datetime.now().strftime('%Y-%m-%d')

        # Update or insert
        c.execute('''
            INSERT INTO vpn_usage (date, bytes_used, sessions, store)
            VALUES (?, ?, 1, ?)
            ON CONFLICT(date, store) DO UPDATE SET
            bytes_used = bytes_used + ?,
            sessions = sessions + 1
        ''', (today, bytes_used, store, bytes_used))

        conn.commit()
        conn.close()

    def _start_session(self, store: str = 'cssberlin'):
        """Record session start"""
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()

        c.execute('''
            INSERT INTO vpn_sessions (start_time, store, status)
            VALUES (?, ?, 'active')
        ''', (datetime.now().isoformat(), store))

        conn.commit()
        conn.close()

    def _end_session(self, bytes_used: int = 0):
        """Record session end"""
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()

        c.execute('''
            UPDATE vpn_sessions
            SET end_time = ?, bytes_end = ?, status = 'completed'
            WHERE status = 'active'
            ORDER BY id DESC LIMIT 1
        ''', (datetime.now().isoformat(), bytes_used))

        conn.commit()
        conn.close()

    def get_quota_summary(self) -> dict:
        """Get quota summary for dashboard"""
        monthly = self.get_monthly_usage_gb()
        daily = self.get_daily_usage_gb()

        return {
            'monthly_used_gb': round(monthly, 2),
            'monthly_limit_gb': MONTHLY_QUOTA_GB,
            'monthly_remaining_gb': round(MONTHLY_QUOTA_GB - monthly, 2),
            'monthly_percent': round((monthly / MONTHLY_QUOTA_GB) * 100, 1),
            'daily_used_gb': round(daily, 2),
            'daily_limit_gb': DAILY_QUOTA_GB,
            'can_continue': monthly < MONTHLY_QUOTA_GB and daily < DAILY_QUOTA_GB,
            'status': self.get_status()
        }

    def estimate_remaining_uploads(self, mb_per_upload: float = 7) -> int:
        """Estimate how many more uploads possible this month"""
        remaining_gb = MONTHLY_QUOTA_GB - self.get_monthly_usage_gb()
        remaining_mb = remaining_gb * 1024
        return int(remaining_mb / mb_per_upload)


# Singleton
_manager = None

def get_vpn_manager() -> VPNManager:
    global _manager
    if _manager is None:
        _manager = VPNManager()
    return _manager


if __name__ == '__main__':
    print('=' * 50)
    print('VPN MANAGER TEST')
    print('=' * 50)

    mgr = get_vpn_manager()

    # Check installation
    print(f'\nWindscribe installed: {mgr.is_windscribe_installed()}')

    # Get status
    status = mgr.get_status()
    print(f'Status: {status}')

    # Check quota
    quota_ok, quota_msg = mgr.check_quota()
    print(f'Quota: {quota_ok} - {quota_msg}')

    # Summary
    summary = mgr.get_quota_summary()
    print(f'\nQuota Summary:')
    print(f'  Monthly: {summary["monthly_used_gb"]}GB / {summary["monthly_limit_gb"]}GB ({summary["monthly_percent"]}%)')
    print(f'  Daily: {summary["daily_used_gb"]}GB / {summary["daily_limit_gb"]}GB')
    print(f'  Remaining uploads: ~{mgr.estimate_remaining_uploads()}')
