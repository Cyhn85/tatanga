# Telegram handler for Vinted Relister
import os
import sys
import asyncio
from typing import Optional, Callable, Dict, Any
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

try:
    from telegram import Bot, Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
    TELEGRAM_AVAILABLE = True
except ImportError:
    TELEGRAM_AVAILABLE = False
    print("Warning: python-telegram-bot not installed. Run: pip install python-telegram-bot")


class VintedTelegramBot:
    """Telegram bot for Vinted Relister notifications and approvals"""

    def __init__(self, token: str = TELEGRAM_BOT_TOKEN, chat_id: str = TELEGRAM_CHAT_ID):
        self.token = token
        self.chat_id = chat_id
        self.bot: Optional[Bot] = None
        self.application: Optional[Application] = None
        self.approval_callbacks: Dict[int, Callable] = {}

        if TELEGRAM_AVAILABLE and token:
            self.bot = Bot(token=token)

    async def send_message(self, text: str, parse_mode: str = 'HTML') -> bool:
        """Send a simple text message"""
        if not self.bot:
            print(f"[Telegram Mock] {text}")
            return False

        try:
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=text,
                parse_mode=parse_mode
            )
            return True
        except Exception as e:
            print(f"Telegram error: {e}")
            return False

    async def send_photo(self, photo_path: str, caption: str = '') -> bool:
        """Send a photo with optional caption"""
        if not self.bot:
            print(f"[Telegram Mock] Photo: {photo_path}, Caption: {caption}")
            return False

        try:
            with open(photo_path, 'rb') as photo:
                await self.bot.send_photo(
                    chat_id=self.chat_id,
                    photo=photo,
                    caption=caption,
                    parse_mode='HTML'
                )
            return True
        except Exception as e:
            print(f"Telegram error: {e}")
            return False

    async def send_product_approval(self, product: Dict, image_path: Optional[str] = None) -> bool:
        """
        Send product for approval with inline buttons

        Args:
            product: Product data dictionary
            image_path: Optional path to product image

        Returns:
            True if sent successfully
        """
        if not self.bot:
            print(f"[Telegram Mock] Product approval: {product.get('raw_title')}")
            return False

        try:
            # Build message
            title = product.get('processed_title') or product.get('raw_title', 'N/A')
            desc = product.get('processed_description') or product.get('raw_description', '')
            desc_preview = desc[:150] + '...' if len(desc) > 150 else desc

            message = f"""
📦 <b>Yeni Ürün Hazır!</b>
━━━━━━━━━━━━━━━━━━

📌 <b>Başlık:</b> {title}

📝 <b>Açıklama:</b>
{desc_preview}

💰 <b>Fiyat:</b> {product.get('price', 0):.2f}€
🏷️ <b>Marka:</b> {product.get('brand', 'N/A')}
📏 <b>Beden:</b> {product.get('size', 'N/A')}
🎨 <b>Renk:</b> {product.get('color', 'N/A')}
📦 <b>Durum:</b> {product.get('condition', 'N/A')}

🆔 <b>ID:</b> {product.get('id')}
"""

            # Create inline keyboard
            keyboard = [
                [
                    InlineKeyboardButton("✅ Onayla", callback_data=f"approve_{product.get('id')}"),
                    InlineKeyboardButton("✏️ Düzelt", callback_data=f"edit_{product.get('id')}"),
                    InlineKeyboardButton("❌ Atla", callback_data=f"skip_{product.get('id')}")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)

            # Resim gönderme devre dışı - API 400 hatasını önlemek için sadece metin
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=message,
                parse_mode='HTML',
                reply_markup=reply_markup
            )

            return True

        except Exception as e:
            print(f"Telegram error: {e}")
            return False

    async def send_captcha_alert(self, screenshot_path: str, suggestion: str = '') -> bool:
        """
        Send captcha alert with screenshot

        Args:
            screenshot_path: Path to screenshot
            suggestion: AI-generated suggestion for solving

        Returns:
            True if sent successfully
        """
        if not self.bot:
            print(f"[Telegram Mock] CAPTCHA Alert!")
            return False

        try:
            message = f"""
🚨 <b>ACİL - Manuel Müdahale Gerekli!</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Vinted captcha veya engel tespit edildi.

📸 Ekran görüntüsü ekte.

💡 <b>Önerilen çözüm:</b>
{suggestion or 'Manuel olarak captcha çözün ve sistemi yeniden başlatın.'}
"""

            keyboard = [
                [
                    InlineKeyboardButton("🔄 Tekrar Dene", callback_data="retry_upload"),
                    InlineKeyboardButton("⏸️ Duraklat", callback_data="pause_system")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)

            # Resim gönderme devre dışı - API 400 hatasını önlemek için sadece metin
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=message,
                parse_mode='HTML',
                reply_markup=reply_markup
            )

            return True

        except Exception as e:
            print(f"Telegram error: {e}")
            return False

    async def send_limit_warning(self, api_name: str, used: int, limit: int, remaining_products: int) -> bool:
        """
        Send API limit warning

        Args:
            api_name: Name of the API (Groq, Gemini)
            used: Number of requests used today
            limit: Total daily limit
            remaining_products: Number of products that can still be processed

        Returns:
            True if sent successfully
        """
        if not self.bot:
            print(f"[Telegram Mock] Limit warning: {api_name} {used}/{limit}")
            return False

        try:
            percentage = (used / limit) * 100

            message = f"""
⚠️ <b>API Limit Uyarısı</b>
━━━━━━━━━━━━━━━━━━

📊 <b>{api_name}:</b> {percentage:.0f}% kullanıldı
   ({used:,} / {limit:,})

📦 <b>Bugün kalan ürün:</b> {remaining_products}
"""

            keyboard = [[InlineKeyboardButton("📊 Detaylı Rapor", callback_data="detailed_report")]]
            reply_markup = InlineKeyboardMarkup(keyboard)

            await self.bot.send_message(
                chat_id=self.chat_id,
                text=message,
                parse_mode='HTML',
                reply_markup=reply_markup
            )
            return True

        except Exception as e:
            print(f"Telegram error: {e}")
            return False

    async def send_daily_report(self, stats: Dict) -> bool:
        """
        Send daily summary report

        Args:
            stats: Statistics dictionary

        Returns:
            True if sent successfully
        """
        if not self.bot:
            print(f"[Telegram Mock] Daily report: {stats}")
            return False

        try:
            today = datetime.now().strftime('%d.%m.%Y')

            uploaded = stats.get('uploaded_today', 0)
            pending = stats.get('pending', 0)
            images_processed = stats.get('images_processed', 0)
            days_remaining = (pending // 15) + 1 if pending > 0 else 0

            message = f"""
📊 <b>Günlük Rapor - {today}</b>
━━━━━━━━━━━━━━━━━━━━━━━━━

✅ <b>Yüklenen:</b> {uploaded} ürün
⏳ <b>Bekleyen:</b> {pending} ürün
🖼️ <b>İşlenen resim:</b> {images_processed}
📈 <b>Tahmini bitiş:</b> {days_remaining} gün

━━━━━━━━━━━━━━━━━━━━━━━━━
<b>Durum Dağılımı:</b>
• Ham: {stats.get('raw', 0)}
• Resim OK: {stats.get('image_done', 0)}
• SEO OK: {stats.get('seo_done', 0)}
• Onay Bekliyor: {stats.get('validated', 0)}
• Yüklendi: {stats.get('uploaded', 0)}
"""

            keyboard = [[InlineKeyboardButton("📋 Detaylı Liste", callback_data="product_list")]]
            reply_markup = InlineKeyboardMarkup(keyboard)

            await self.bot.send_message(
                chat_id=self.chat_id,
                text=message,
                parse_mode='HTML',
                reply_markup=reply_markup
            )
            return True

        except Exception as e:
            print(f"Telegram error: {e}")
            return False

    async def send_upload_success(self, product: Dict, new_url: str) -> bool:
        """
        Send upload success notification

        Args:
            product: Product data
            new_url: URL of newly created listing

        Returns:
            True if sent successfully
        """
        if not self.bot:
            print(f"[Telegram Mock] Upload success: {product.get('raw_title')}")
            return False

        try:
            message = f"""
✅ <b>Ürün Başarıyla Yüklendi!</b>
━━━━━━━━━━━━━━━━━━━━━━━━━

📌 <b>{product.get('processed_title', product.get('raw_title'))}</b>

💰 Fiyat: {product.get('price', 0):.2f}€
🔗 <a href="{new_url}">İlanı Görüntüle</a>
"""

            await self.bot.send_message(
                chat_id=self.chat_id,
                text=message,
                parse_mode='HTML',
                disable_web_page_preview=False
            )
            return True

        except Exception as e:
            print(f"Telegram error: {e}")
            return False


# Sync wrapper functions for non-async contexts
def send_telegram_message(text: str) -> bool:
    """Synchronous wrapper for sending telegram message"""
    bot = VintedTelegramBot()
    return asyncio.run(bot.send_message(text))


def send_telegram_photo(photo_path: str, caption: str = '') -> bool:
    """Synchronous wrapper for sending telegram photo"""
    bot = VintedTelegramBot()
    return asyncio.run(bot.send_photo(photo_path, caption))


def send_product_for_approval(product: Dict, image_path: Optional[str] = None) -> bool:
    """Synchronous wrapper for sending product approval"""
    bot = VintedTelegramBot()
    return asyncio.run(bot.send_product_approval(product, image_path))


def send_captcha_alert(screenshot_path: str, suggestion: str = '') -> bool:
    """Synchronous wrapper for captcha alert"""
    bot = VintedTelegramBot()
    return asyncio.run(bot.send_captcha_alert(screenshot_path, suggestion))


def send_daily_report(stats: Dict) -> bool:
    """Synchronous wrapper for daily report"""
    bot = VintedTelegramBot()
    return asyncio.run(bot.send_daily_report(stats))


# Global bot instance
telegram_bot = VintedTelegramBot()
