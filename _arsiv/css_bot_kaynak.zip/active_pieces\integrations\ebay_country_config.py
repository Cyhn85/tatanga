#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EBAY COUNTRY CONFIG - 10 Marketplace Configuration
Each marketplace has its own selectors, condition mapping, and API settings
"""

EBAY_COUNTRY_CONFIG = {
    'de': {
        'marketplace_id': 'EBAY_DE',
        'site_id': 77,
        'domain': 'ebay.de',
        'base_url': 'https://www.ebay.de',
        'api_url': 'https://api.ebay.com',
        'language': 'de-DE',
        'currency': 'EUR',
        'search_path': '/sch/i.html?_nkw=',
        'condition_map': {
            'new': 'NEW',
            'like_new': 'LIKE_NEW',
            'very_good': 'USED_EXCELLENT',
            'good': 'USED_VERY_GOOD',
            'fair': 'USED_GOOD'
        },
        'condition_labels': {
            'NEW': 'Neu',
            'LIKE_NEW': 'Wie neu',
            'USED_EXCELLENT': 'Hervorragend',
            'USED_VERY_GOOD': 'Sehr gut',
            'USED_GOOD': 'Gut'
        },
        'item_selectors': [
            '.s-item__wrapper',
            '[data-testid="search-result"]',
            '.srp-results li.s-item'
        ],
        'title_selectors': ['.s-item__title', 'h3.s-item__title', '.s-item__title span'],
        'price_selectors': ['.s-item__price', '[data-testid="price"]', '.s-item__price span'],
        'condition_selectors': ['.SECONDARY_INFO', '[data-testid="condition"]', '.s-item__subtitle'],
        'image_selectors': ['.s-item__image img', 'img.s-item__image-img'],
        'link_selectors': ['.s-item__link', 'a.s-item__link']
    },
    'uk': {
        'marketplace_id': 'EBAY_GB',
        'site_id': 3,
        'domain': 'ebay.co.uk',
        'base_url': 'https://www.ebay.co.uk',
        'api_url': 'https://api.ebay.com',
        'language': 'en-GB',
        'currency': 'GBP',
        'search_path': '/sch/i.html?_nkw=',
        'condition_map': {
            'new': 'NEW',
            'like_new': 'LIKE_NEW',
            'very_good': 'USED_EXCELLENT',
            'good': 'USED_VERY_GOOD',
            'fair': 'USED_GOOD'
        },
        'condition_labels': {
            'NEW': 'New',
            'LIKE_NEW': 'New other',
            'USED_EXCELLENT': 'Excellent',
            'USED_VERY_GOOD': 'Very Good',
            'USED_GOOD': 'Good'
        },
        'item_selectors': ['.s-item__wrapper', '.srp-results li.s-item'],
        'title_selectors': ['.s-item__title'],
        'price_selectors': ['.s-item__price'],
        'condition_selectors': ['.SECONDARY_INFO'],
        'image_selectors': ['.s-item__image img'],
        'link_selectors': ['.s-item__link']
    },
    'fr': {
        'marketplace_id': 'EBAY_FR',
        'site_id': 71,
        'domain': 'ebay.fr',
        'base_url': 'https://www.ebay.fr',
        'api_url': 'https://api.ebay.com',
        'language': 'fr-FR',
        'currency': 'EUR',
        'search_path': '/sch/i.html?_nkw=',
        'condition_map': {
            'new': 'NEW',
            'like_new': 'LIKE_NEW',
            'very_good': 'USED_EXCELLENT',
            'good': 'USED_VERY_GOOD',
            'fair': 'USED_GOOD'
        },
        'condition_labels': {
            'NEW': 'Neuf',
            'LIKE_NEW': 'Neuf autre',
            'USED_EXCELLENT': 'Excellent',
            'USED_VERY_GOOD': 'Très bon état',
            'USED_GOOD': 'Bon état'
        },
        'item_selectors': ['.s-item__wrapper', '.srp-results li.s-item'],
        'title_selectors': ['.s-item__title'],
        'price_selectors': ['.s-item__price'],
        'condition_selectors': ['.SECONDARY_INFO'],
        'image_selectors': ['.s-item__image img'],
        'link_selectors': ['.s-item__link']
    },
    'us': {
        'marketplace_id': 'EBAY_US',
        'site_id': 0,
        'domain': 'ebay.com',
        'base_url': 'https://www.ebay.com',
        'api_url': 'https://api.ebay.com',
        'language': 'en-US',
        'currency': 'USD',
        'search_path': '/sch/i.html?_nkw=',
        'condition_map': {
            'new': 'NEW',
            'like_new': 'LIKE_NEW',
            'very_good': 'USED_EXCELLENT',
            'good': 'USED_VERY_GOOD',
            'fair': 'USED_GOOD'
        },
        'condition_labels': {
            'NEW': 'New',
            'LIKE_NEW': 'Open box',
            'USED_EXCELLENT': 'Excellent',
            'USED_VERY_GOOD': 'Very Good',
            'USED_GOOD': 'Good'
        },
        'item_selectors': ['.s-item__wrapper', '.srp-results li.s-item'],
        'title_selectors': ['.s-item__title'],
        'price_selectors': ['.s-item__price'],
        'condition_selectors': ['.SECONDARY_INFO'],
        'image_selectors': ['.s-item__image img'],
        'link_selectors': ['.s-item__link']
    },
    'it': {
        'marketplace_id': 'EBAY_IT',
        'site_id': 101,
        'domain': 'ebay.it',
        'base_url': 'https://www.ebay.it',
        'api_url': 'https://api.ebay.com',
        'language': 'it-IT',
        'currency': 'EUR',
        'search_path': '/sch/i.html?_nkw=',
        'condition_map': {
            'new': 'NEW',
            'like_new': 'LIKE_NEW',
            'very_good': 'USED_EXCELLENT',
            'good': 'USED_VERY_GOOD',
            'fair': 'USED_GOOD'
        },
        'condition_labels': {
            'NEW': 'Nuovo',
            'LIKE_NEW': 'Come nuovo',
            'USED_EXCELLENT': 'Eccellente',
            'USED_VERY_GOOD': 'Molto buono',
            'USED_GOOD': 'Buono'
        },
        'item_selectors': ['.s-item__wrapper', '.srp-results li.s-item'],
        'title_selectors': ['.s-item__title'],
        'price_selectors': ['.s-item__price'],
        'condition_selectors': ['.SECONDARY_INFO'],
        'image_selectors': ['.s-item__image img'],
        'link_selectors': ['.s-item__link']
    },
    'es': {
        'marketplace_id': 'EBAY_ES',
        'site_id': 186,
        'domain': 'ebay.es',
        'base_url': 'https://www.ebay.es',
        'api_url': 'https://api.ebay.com',
        'language': 'es-ES',
        'currency': 'EUR',
        'search_path': '/sch/i.html?_nkw=',
        'condition_map': {
            'new': 'NEW',
            'like_new': 'LIKE_NEW',
            'very_good': 'USED_EXCELLENT',
            'good': 'USED_VERY_GOOD',
            'fair': 'USED_GOOD'
        },
        'condition_labels': {
            'NEW': 'Nuevo',
            'LIKE_NEW': 'Como nuevo',
            'USED_EXCELLENT': 'Excelente',
            'USED_VERY_GOOD': 'Muy bueno',
            'USED_GOOD': 'Bueno'
        },
        'item_selectors': ['.s-item__wrapper', '.srp-results li.s-item'],
        'title_selectors': ['.s-item__title'],
        'price_selectors': ['.s-item__price'],
        'condition_selectors': ['.SECONDARY_INFO'],
        'image_selectors': ['.s-item__image img'],
        'link_selectors': ['.s-item__link']
    },
    'nl': {
        'marketplace_id': 'EBAY_NL',
        'site_id': 146,
        'domain': 'ebay.nl',
        'base_url': 'https://www.ebay.nl',
        'api_url': 'https://api.ebay.com',
        'language': 'nl-NL',
        'currency': 'EUR',
        'search_path': '/sch/i.html?_nkw=',
        'condition_map': {
            'new': 'NEW',
            'like_new': 'LIKE_NEW',
            'very_good': 'USED_EXCELLENT',
            'good': 'USED_VERY_GOOD',
            'fair': 'USED_GOOD'
        },
        'condition_labels': {
            'NEW': 'Nieuw',
            'LIKE_NEW': 'Als nieuw',
            'USED_EXCELLENT': 'Uitstekend',
            'USED_VERY_GOOD': 'Zeer goed',
            'USED_GOOD': 'Goed'
        },
        'item_selectors': ['.s-item__wrapper', '.srp-results li.s-item'],
        'title_selectors': ['.s-item__title'],
        'price_selectors': ['.s-item__price'],
        'condition_selectors': ['.SECONDARY_INFO'],
        'image_selectors': ['.s-item__image img'],
        'link_selectors': ['.s-item__link']
    },
    'be': {
        'marketplace_id': 'EBAY_BE',
        'site_id': 23,
        'domain': 'ebay.be',
        'base_url': 'https://www.ebay.be',
        'api_url': 'https://api.ebay.com',
        'language': 'fr-BE',
        'currency': 'EUR',
        'search_path': '/sch/i.html?_nkw=',
        'condition_map': {
            'new': 'NEW',
            'like_new': 'LIKE_NEW',
            'very_good': 'USED_EXCELLENT',
            'good': 'USED_VERY_GOOD',
            'fair': 'USED_GOOD'
        },
        'condition_labels': {
            'NEW': 'Neuf',
            'LIKE_NEW': 'Comme neuf',
            'USED_EXCELLENT': 'Excellent',
            'USED_VERY_GOOD': 'Tres bon',
            'USED_GOOD': 'Bon'
        },
        'item_selectors': ['.s-item__wrapper', '.srp-results li.s-item'],
        'title_selectors': ['.s-item__title'],
        'price_selectors': ['.s-item__price'],
        'condition_selectors': ['.SECONDARY_INFO'],
        'image_selectors': ['.s-item__image img'],
        'link_selectors': ['.s-item__link']
    },
    'at': {
        'marketplace_id': 'EBAY_AT',
        'site_id': 16,
        'domain': 'ebay.at',
        'base_url': 'https://www.ebay.at',
        'api_url': 'https://api.ebay.com',
        'language': 'de-AT',
        'currency': 'EUR',
        'search_path': '/sch/i.html?_nkw=',
        'condition_map': {
            'new': 'NEW',
            'like_new': 'LIKE_NEW',
            'very_good': 'USED_EXCELLENT',
            'good': 'USED_VERY_GOOD',
            'fair': 'USED_GOOD'
        },
        'condition_labels': {
            'NEW': 'Neu',
            'LIKE_NEW': 'Wie neu',
            'USED_EXCELLENT': 'Hervorragend',
            'USED_VERY_GOOD': 'Sehr gut',
            'USED_GOOD': 'Gut'
        },
        'item_selectors': ['.s-item__wrapper', '.srp-results li.s-item'],
        'title_selectors': ['.s-item__title'],
        'price_selectors': ['.s-item__price'],
        'condition_selectors': ['.SECONDARY_INFO'],
        'image_selectors': ['.s-item__image img'],
        'link_selectors': ['.s-item__link']
    },
    'ch': {
        'marketplace_id': 'EBAY_CH',
        'site_id': 193,
        'domain': 'ebay.ch',
        'base_url': 'https://www.ebay.ch',
        'api_url': 'https://api.ebay.com',
        'language': 'de-CH',
        'currency': 'CHF',
        'search_path': '/sch/i.html?_nkw=',
        'condition_map': {
            'new': 'NEW',
            'like_new': 'LIKE_NEW',
            'very_good': 'USED_EXCELLENT',
            'good': 'USED_VERY_GOOD',
            'fair': 'USED_GOOD'
        },
        'condition_labels': {
            'NEW': 'Neu',
            'LIKE_NEW': 'Wie neu',
            'USED_EXCELLENT': 'Hervorragend',
            'USED_VERY_GOOD': 'Sehr gut',
            'USED_GOOD': 'Gut'
        },
        'item_selectors': ['.s-item__wrapper', '.srp-results li.s-item'],
        'title_selectors': ['.s-item__title'],
        'price_selectors': ['.s-item__price'],
        'condition_selectors': ['.SECONDARY_INFO'],
        'image_selectors': ['.s-item__image img'],
        'link_selectors': ['.s-item__link']
    }
}


def get_ebay_config(country: str) -> dict:
    """Get eBay config for a specific country"""
    country = country.lower().replace('ebay_', '')
    return EBAY_COUNTRY_CONFIG.get(country, EBAY_COUNTRY_CONFIG['de'])


def get_supported_marketplaces() -> list:
    """Get list of supported eBay marketplaces"""
    return [f"ebay_{k}" for k in EBAY_COUNTRY_CONFIG.keys()]
