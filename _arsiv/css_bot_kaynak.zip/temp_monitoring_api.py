"""
TATANGA V3 - Monitoring API
URL tracking and status monitoring
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, func, text
from database import get_db
from models import URLTracking, Product, Publication
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

router = APIRouter()


class AddURLRequest(BaseModel):
    product_id: int
    source_url: str


@router.get("/status")
async def get_monitoring_status(db: AsyncSession = Depends(get_db)):
    total = await db.execute(select(func.count()).select_from(URLTracking))
    active = await db.execute(select(func.count()).select_from(URLTracking).where(URLTracking.status == "active"))
    sold = await db.execute(select(func.count()).select_from(URLTracking).where(URLTracking.status == "sold"))
    removed = await db.execute(select(func.count()).select_from(URLTracking).where(URLTracking.status == "removed"))
    error = await db.execute(select(func.count()).select_from(URLTracking).where(URLTracking.status == "error"))

    return {
        "total_tracked": total.scalar(),
        "active": active.scalar(),
        "sold": sold.scalar(),
        "removed": removed.scalar(),
        "error": error.scalar(),
        "last_check": datetime.utcnow().isoformat(),
        "check_interval_minutes": 5,
        "worker_status": "active"
    }


@router.get("/urls")
async def get_tracked_urls(
    status: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """Get all tracked URLs with optional status filter"""
    query = select(URLTracking).order_by(desc(URLTracking.last_checked))

    if status:
        query = query.where(URLTracking.status == status)

    query = query.offset(skip).limit(limit)
    result = await db.execute(query)
    tracking_items = result.scalars().all()

    response = []
    for item in tracking_items:
        # Get product info
        prod_result = await db.execute(select(Product).where(Product.id == item.product_id))
        product = prod_result.scalar_one_or_none()

        response.append({
            "id": item.id,
            "product_id": item.product_id,
            "product_title": product.title if product else None,
            "source_url": item.source_url,
            "status": item.status,
            "check_count": item.check_count,
            "last_checked": item.last_checked,
            "last_error": item.last_error
        })

    return response


@router.post("/urls")
async def add_url_tracking(request: AddURLRequest, db: AsyncSession = Depends(get_db)):
    """Add a URL to tracking"""
    # Check product exists
    prod_result = await db.execute(select(Product).where(Product.id == request.product_id))
    product = prod_result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    # Check not already tracked
    existing = await db.execute(
        select(URLTracking).where(
            URLTracking.product_id == request.product_id,
            URLTracking.source_url == request.source_url
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="URL already tracked")

    # Create tracking entry
    tracking = URLTracking(
        product_id=request.product_id,
        source_url=request.source_url,
        status="active"
    )
    db.add(tracking)
    await db.commit()
    await db.refresh(tracking)

    return {
        "message": "URL added to tracking",
        "tracking_id": tracking.id,
        "source_url": request.source_url
    }


@router.delete("/urls/{tracking_id}")
async def remove_url_tracking(tracking_id: int, db: AsyncSession = Depends(get_db)):
    """Remove a URL from tracking"""
    result = await db.execute(select(URLTracking).where(URLTracking.id == tracking_id))
    tracking = result.scalar_one_or_none()
    if not tracking:
        raise HTTPException(status_code=404, detail="Tracking not found")

    await db.delete(tracking)
    await db.commit()
    return {"message": "URL removed from tracking"}


@router.get("/alerts")
async def get_alerts(db: AsyncSession = Depends(get_db)):
    """Get URLs that need attention (sold, removed, error)"""
    result = await db.execute(
        select(URLTracking)
        .where(URLTracking.status.in_(["sold", "removed", "error"]))
        .order_by(desc(URLTracking.last_checked))
        .limit(50)
    )
    tracking_items = result.scalars().all()

    alerts = []
    for item in tracking_items:
        prod_result = await db.execute(select(Product).where(Product.id == item.product_id))
        product = prod_result.scalar_one_or_none()

        pub_result = await db.execute(
            select(Publication)
            .where(Publication.product_id == item.product_id)
            .where(Publication.status == "active")
        )
        publications = pub_result.scalars().all()

        if product:
            alerts.append({
                "tracking_id": item.id,
                "product_id": item.product_id,
                "product_title": product.title,
                "source_url": item.source_url,
                "status": item.status,
                "last_checked": item.last_checked,
                "error": item.last_error,
                "active_publications": [{"platform": p.platform, "url": p.listing_url} for p in publications]
            })

    return alerts


@router.post("/check/{tracking_id}")
async def force_check(tracking_id: int, db: AsyncSession = Depends(get_db)):
    """Force immediate check of a URL"""
    from services.url_checker import URLChecker

    result = await db.execute(select(URLTracking).where(URLTracking.id == tracking_id))
    tracking = result.scalar_one_or_none()
    if not tracking:
        raise HTTPException(status_code=404, detail="Tracking not found")

    # Perform check
    checker = URLChecker()
    check_result = checker.check_url(tracking.source_url)

    # Update database
    tracking.status = check_result["status"]
    tracking.last_checked = datetime.utcnow()
    tracking.check_count = (tracking.check_count or 0) + 1
    tracking.last_error = check_result.get("error")

    await db.commit()

    return {
        "tracking_id": tracking_id,
        "status": check_result["status"],
        "http_code": check_result.get("http_code"),
        "error": check_result.get("error")
    }


@router.post("/check-all")
async def trigger_check_all():
    """Trigger URL monitor task via Celery"""
    from celery_worker import url_monitor_task

    task = url_monitor_task.delay()
    return {
        "message": "URL check scheduled",
        "task_id": task.id
    }


@router.post("/dismiss/{tracking_id}")
async def dismiss_alert(tracking_id: int, db: AsyncSession = Depends(get_db)):
    """Dismiss an alert by marking it as acknowledged"""
    result = await db.execute(select(URLTracking).where(URLTracking.id == tracking_id))
    tracking = result.scalar_one_or_none()
    if not tracking:
        raise HTTPException(status_code=404, detail="Tracking not found")

    tracking.status = "dismissed"
    await db.commit()
    return {"message": "Alert dismissed"}


@router.post("/reactivate/{tracking_id}")
async def reactivate_tracking(tracking_id: int, db: AsyncSession = Depends(get_db)):
    """Reactivate a dismissed or error tracking"""
    result = await db.execute(select(URLTracking).where(URLTracking.id == tracking_id))
    tracking = result.scalar_one_or_none()
    if not tracking:
        raise HTTPException(status_code=404, detail="Tracking not found")

    tracking.status = "active"
    tracking.last_error = None
    await db.commit()
    return {"message": "Tracking reactivated"}
