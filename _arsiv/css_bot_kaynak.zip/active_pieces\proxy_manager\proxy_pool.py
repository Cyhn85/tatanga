# Proxy Pool - Manages proxy rotation and store-specific rules
# Automatic switching based on quota and store configuration

import requests
import time
from typing import Optional, Dict, Tuple
from config import STORE_RULES, PROXY_SERVICES, ROTATION_CONFIG
from quota_tracker import get_tracker

class ProxyPool:
    def __init__(self):
        self.tracker = get_tracker()
        self.current_proxies = {}  # store_id -> current proxy info
        self.health_cache = {}  # service -> (is_healthy, last_check)
        print('[OK] ProxyPool initialized')

    def get_proxy_for_store(self, store_id: str) -> Optional[Dict]:
        """Get appropriate proxy for a store based on rules"""
        rule = STORE_RULES.get(store_id, {})
        proxy_mode = rule.get('proxy_mode', 'direct')

        # Direct mode - no proxy needed
        if proxy_mode == 'direct':
            print(f'  [{store_id}] Direct connection (no proxy)')
            return None

        # Auto mode - select best proxy automatically
        if proxy_mode == 'auto':
            preferred_type = rule.get('preferred_type', None)
            return self._select_best_proxy(store_id, preferred_type)

        # Specific proxy mode
        return self._get_specific_proxy(proxy_mode)

    def _select_best_proxy(self, store_id: str, preferred_type: str = None) -> Optional[Dict]:
        """Auto-select best proxy based on quota and quality"""
        # Check if current proxy still has quota
        if store_id in self.current_proxies:
            current = self.current_proxies[store_id]
            service = current.get('service')
            if service and not self.tracker.should_switch(service):
                return current

        # Get best available service
        service = self.tracker.get_best_available(preferred_type)
        if not service:
            print(f'  [WARN] No proxy available for {store_id}!')
            return None

        proxy = self._build_proxy(service)
        if proxy:
            self.current_proxies[store_id] = proxy
            print(f'  [{store_id}] Using: {service} ({proxy.get("type", "unknown")})')

        return proxy

    def _build_proxy(self, service: str) -> Optional[Dict]:
        """Build proxy configuration for a service"""
        config = PROXY_SERVICES.get(service, {})
        if not config.get('enabled', False):
            return None

        proxy_type = config.get('type', 'datacenter')

        # Handle different proxy types
        if service == 'proxyscrape':
            return self._fetch_proxyscrape_proxy(config)
        elif service == 'mobile_hotspot':
            return {
                'service': service,
                'type': 'mobile',
                'host': config.get('host', '192.168.43.1'),
                'port': config.get('port', 8080),
                'url': f"http://{config.get('host')}:{config.get('port')}",
                'requires_manual': True
            }
        elif service == 'webshare':
            return self._build_authenticated_proxy(service, config)
        elif service == 'geonode':
            return self._build_authenticated_proxy(service, config)
        else:
            # Generic proxy with API key
            return {
                'service': service,
                'type': proxy_type,
                'api_key': config.get('api_key', ''),
                'enabled': bool(config.get('api_key'))
            }

    def _fetch_proxyscrape_proxy(self, config: dict) -> Optional[Dict]:
        """Fetch a proxy from ProxyScrape free list"""
        try:
            api_url = config.get('api_url', '')
            if not api_url:
                return None

            response = requests.get(api_url, timeout=10)
            if response.status_code == 200:
                proxies = response.text.strip().split('\n')
                if proxies:
                    # Get first working proxy
                    proxy_str = proxies[0].strip()
                    if ':' in proxy_str:
                        host, port = proxy_str.split(':')
                        return {
                            'service': 'proxyscrape',
                            'type': 'mixed',
                            'host': host,
                            'port': int(port),
                            'url': f'http://{host}:{port}'
                        }
        except Exception as e:
            print(f'  [ERR] ProxyScrape fetch: {e}')
        return None

    def _build_authenticated_proxy(self, service: str, config: dict) -> Optional[Dict]:
        """Build proxy with authentication (Webshare, GeoNode, etc.)"""
        api_key = config.get('api_key', '')
        if not api_key:
            print(f'  [WARN] {service}: API key not configured')
            return None

        # These services need API integration to fetch proxy details
        # For now, return placeholder - will be implemented per service
        return {
            'service': service,
            'type': config.get('type', 'datacenter'),
            'api_key': api_key,
            'needs_setup': True
        }

    def _get_specific_proxy(self, service: str) -> Optional[Dict]:
        """Get a specific proxy service"""
        return self._build_proxy(service)

    def record_request(self, store_id: str, success: bool = True):
        """Record a request for quota tracking"""
        if store_id in self.current_proxies:
            service = self.current_proxies[store_id].get('service')
            if service:
                self.tracker.record_usage(service, store_id, success)

    def check_health(self, service: str) -> bool:
        """Check if a proxy service is healthy"""
        # Check cache first (5 min TTL)
        if service in self.health_cache:
            is_healthy, last_check = self.health_cache[service]
            if time.time() - last_check < 300:  # 5 min cache
                return is_healthy

        is_healthy = self._perform_health_check(service)
        self.health_cache[service] = (is_healthy, time.time())
        return is_healthy

    def _perform_health_check(self, service: str) -> bool:
        """Perform actual health check on proxy"""
        proxy = self._build_proxy(service)
        if not proxy:
            return False

        if proxy.get('requires_manual') or proxy.get('needs_setup'):
            return True  # Assume manual proxies are OK

        proxy_url = proxy.get('url')
        if not proxy_url:
            return False

        try:
            proxies = {'http': proxy_url, 'https': proxy_url}
            response = requests.get(
                'https://api.ipify.org',
                proxies=proxies,
                timeout=10
            )
            return response.status_code == 200
        except:
            return False

    def get_status(self) -> Dict:
        """Get overall proxy pool status"""
        summary = self.tracker.get_dashboard_summary()
        summary['active_stores'] = dict(self.current_proxies)
        return summary

    def format_for_playwright(self, store_id: str) -> Optional[Dict]:
        """Format proxy for Playwright browser context"""
        proxy = self.get_proxy_for_store(store_id)
        if not proxy:
            return None

        url = proxy.get('url')
        if not url:
            host = proxy.get('host')
            port = proxy.get('port')
            if host and port:
                url = f'http://{host}:{port}'

        if url:
            return {
                'server': url,
                # Add username/password if authenticated
            }
        return None


# Singleton
_pool = None

def get_pool() -> ProxyPool:
    global _pool
    if _pool is None:
        _pool = ProxyPool()
    return _pool


if __name__ == '__main__':
    pool = get_pool()

    print('\n=== STORE PROXY TEST ===')
    for store_id in STORE_RULES:
        print(f'\n{store_id}:')
        proxy = pool.get_proxy_for_store(store_id)
        if proxy:
            print(f'  Service: {proxy.get("service")}')
            print(f'  Type: {proxy.get("type")}')
        else:
            print('  Direct connection')

    print('\n=== POOL STATUS ===')
    status = pool.get_status()
    print(f'Best available: {status.get("best_available")}')
    for s in status.get('services', []):
        print(f'  {s["service"]}: {s["remaining"]}/{s["limit"]} ({s["percentage"]}%)')
