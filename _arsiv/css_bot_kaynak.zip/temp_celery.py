"""
TATANGA V3 - Celery Worker with Product Saving
"""
import os
import sys
import logging
from celery import Celery
from datetime import datetime

# Add backend to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import REDIS_URL

celery_app = Celery(
    "tatanga_worker",
    broker=REDIS_URL,
    backend=REDIS_URL.replace("/0", "/1"),
)

celery_app.conf.update(
    enable_utc=True,
    task_track_started=True,
    task_time_limit=600,
    worker_prefetch_multiplier=1,
    worker_concurrency=2,
)

logger = logging.getLogger("TATANGA.celery")


def save_products_to_db(products: list, platform: str, query: str):
    """Save scraped products to database"""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from config import DATABASE_URL
    from models import Product

    sync_db_url = DATABASE_URL.replace("+asyncpg", "")
    engine = create_engine(sync_db_url)
    Session = sessionmaker(bind=engine)
    session = Session()

    saved_count = 0
    try:
        for p in products:
            # Check if product already exists by URL
            existing = session.query(Product).filter_by(url=p.get("url")).first()
            if existing:
                continue

            product = Product(
                title=p.get("title", ""),
                price=p.get("price"),
                url=p.get("url", ""),
                image_url=p.get("image", ""),
                platform=platform,
                search_term=query,
                condition=p.get("condition"),
                seller_name=p.get("seller"),
                location=p.get("location"),
                scraped_at=datetime.now(),
                status="inbox"
            )
            session.add(product)
            saved_count += 1

        session.commit()
        logger.info(f"Saved {saved_count} new products to database")
    except Exception as e:
        session.rollback()
        logger.error(f"Failed to save products: {e}")
    finally:
        session.close()

    return saved_count


def update_job_status(job_id: str, status: str, result_count: int = 0, error_message: str = None):
    """Update job status in database"""
    from sqlalchemy import create_engine, text
    from config import DATABASE_URL

    sync_db_url = DATABASE_URL.replace("+asyncpg", "")
    engine = create_engine(sync_db_url)

    try:
        with engine.connect() as conn:
            if status == "completed":
                conn.execute(text("""
                    UPDATE scrape_jobs
                    SET status = :status, result_count = :count, completed_at = NOW()
                    WHERE job_id = :job_id
                """), {"status": status, "count": result_count, "job_id": job_id})
            else:
                conn.execute(text("""
                    UPDATE scrape_jobs
                    SET status = :status, error_message = :error, completed_at = NOW()
                    WHERE job_id = :job_id
                """), {"status": status, "error": error_message, "job_id": job_id})
            conn.commit()
            logger.info(f"Updated job {job_id} status to {status}")
    except Exception as e:
        logger.error(f"Failed to update job status: {e}")


@celery_app.task(bind=True, name="tatanga.scrape")
def scrape_task(self, platform: str, query: str, max_pages: int = 3, max_items: int = 50,
                min_price: float = None, max_price: float = None, condition: str = None,
                sort: str = None, job_id: str = None):
    from services.scraper_service import run_scrape_task

    logger.info(f"Starting scrape: {platform} - {query} (price: {min_price}-{max_price}, condition: {condition})")
    self.update_state(state="PROGRESS", meta={"status": "scraping", "platform": platform})

    try:
        result = run_scrape_task(platform, query, max_pages, max_items, min_price, max_price, condition, sort)
        products = result.get("products", [])
        items_found = len(products)

        # Save products to database
        if products:
            saved_count = save_products_to_db(products, platform, query)
            result["stats"]["items_saved"] = saved_count

        # Update job status
        if job_id:
            update_job_status(job_id, "completed", items_found)

        logger.info(f"Completed: {items_found} items found")
        return result
    except Exception as e:
        logger.error(f"Failed: {e}")
        if job_id:
            update_job_status(job_id, "failed", error_message=str(e))
        return {"status": "error", "error": str(e), "platform": platform, "query": query}


@celery_app.task(name="tatanga.url_monitor")
def url_monitor_task():
    """Check all active tracked URLs"""
    from services.url_checker import URLChecker
    from sqlalchemy import create_engine, text
    from config import DATABASE_URL

    logger.info("URL monitor running")

    sync_db_url = DATABASE_URL.replace("+asyncpg", "")
    engine = create_engine(sync_db_url)

    checked = 0
    updated = 0

    try:
        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT id, url, platform, last_price, check_interval_minutes
                FROM url_tracking
                WHERE is_active = true
            """))
            urls = result.fetchall()

        checker = URLChecker()

        for url_row in urls:
            url_id, url, platform, last_price, interval = url_row

            try:
                new_price = checker.check_price(url, platform)
                checked += 1

                if new_price and new_price != last_price:
                    with engine.connect() as conn:
                        conn.execute(text("""
                            UPDATE url_tracking
                            SET last_price = :price, last_checked = NOW()
                            WHERE id = :id
                        """), {"price": new_price, "id": url_id})
                        conn.commit()
                    updated += 1
                    logger.info(f"Price changed for {url}: {last_price} -> {new_price}")
            except Exception as e:
                logger.warning(f"Failed to check {url}: {e}")

        checker.close()

    except Exception as e:
        logger.error(f"URL monitor error: {e}")

    return {"checked": checked, "updated": updated}
