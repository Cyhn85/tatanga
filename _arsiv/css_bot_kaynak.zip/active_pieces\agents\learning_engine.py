#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SELF-LEARNING ENGINE - Kendi Kendine Ogrenen Ajan Altyapisi
Ajanlar deneyimlerinden ogrenip kendilerini gelistirir

Features:
- Pattern learning from successful/failed operations
- Feedback loop for agent improvement
- Training data storage and analysis
- Cross-agent knowledge sharing
- Adaptive behavior based on history
- Error pattern detection
- Success rate optimization
- A/B testing for strategies

Author: TATANGA Team
Version: 1.0
"""

import sys
import os
import json
import sqlite3
import hashlib
import statistics
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import threading

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.logger import ModuleLogger


# ============================================================================
# ENUMS & DATA MODELS
# ============================================================================

class LearningType(Enum):
    """Types of learning"""
    PATTERN = "pattern"           # Pattern recognition
    FEEDBACK = "feedback"         # User feedback
    OUTCOME = "outcome"           # Success/failure outcome
    TIMING = "timing"             # Optimal timing
    STRATEGY = "strategy"         # Strategy selection
    ERROR = "error"               # Error patterns
    OPTIMIZATION = "optimization" # Parameter optimization


class ConfidenceLevel(Enum):
    """Confidence levels for learned patterns"""
    LOW = "low"           # < 60% success rate
    MEDIUM = "medium"     # 60-80% success rate
    HIGH = "high"         # > 80% success rate
    VERY_HIGH = "very_high"  # > 95% success rate


@dataclass
class LearningEvent:
    """Single learning event"""
    id: int = None
    agent_name: str = ""
    event_type: LearningType = LearningType.OUTCOME
    context: Dict = field(default_factory=dict)     # Input context
    action: str = ""                                 # Action taken
    outcome: bool = True                             # Success or failure
    outcome_details: Dict = field(default_factory=dict)  # Outcome details
    feedback_score: float = 0.0                      # -1 to 1 (negative to positive)
    timestamp: datetime = None
    metadata: Dict = field(default_factory=dict)


@dataclass
class LearnedPattern:
    """A pattern learned from events"""
    id: int = None
    pattern_hash: str = ""
    agent_name: str = ""
    learning_type: LearningType = LearningType.PATTERN
    pattern_data: Dict = field(default_factory=dict)
    success_count: int = 0
    failure_count: int = 0
    total_uses: int = 0
    avg_feedback_score: float = 0.0
    confidence: ConfidenceLevel = ConfidenceLevel.LOW
    is_active: bool = True
    last_used: datetime = None
    created_at: datetime = None
    metadata: Dict = field(default_factory=dict)


@dataclass
class LearningInsight:
    """Insight derived from learning"""
    insight_type: str
    description: str
    confidence: float
    data: Dict
    recommendations: List[str]
    created_at: datetime = None


@dataclass
class ABTest:
    """A/B test for strategy comparison"""
    id: int = None
    agent_name: str = ""
    test_name: str = ""
    variant_a: Dict = field(default_factory=dict)
    variant_b: Dict = field(default_factory=dict)
    success_a: int = 0
    failure_a: int = 0
    success_b: int = 0
    failure_b: int = 0
    is_active: bool = True
    winner: str = None  # 'a', 'b', or None
    started_at: datetime = None
    ended_at: datetime = None


# ============================================================================
# LEARNING ENGINE
# ============================================================================

class LearningEngine:
    """
    Self-Learning Engine for AI Agents

    Provides:
    - Pattern learning and recognition
    - Outcome tracking
    - Strategy optimization
    - Cross-agent knowledge sharing
    - A/B testing

    Usage:
        engine = LearningEngine()

        # Record a learning event
        engine.record_event(
            agent_name='screenshot',
            event_type=LearningType.OUTCOME,
            context={'url': 'vinted.de/...', 'platform': 'vinted'},
            action='scrape_product',
            outcome=True
        )

        # Get recommended action
        recommendation = engine.get_recommendation(
            agent_name='screenshot',
            context={'url': 'vinted.de/...'}
        )

        # Get insights
        insights = engine.get_insights('screenshot')
    """

    def __init__(self, db_path: str = None):
        """Initialize Learning Engine"""
        self.logger = ModuleLogger('learning_engine')

        # Database path
        if db_path:
            self.db_path = Path(db_path)
        else:
            self.db_path = Path(__file__).parent.parent / 'storage' / 'learning_engine.db'

        self._init_db()

        # In-memory pattern cache
        self._pattern_cache: Dict[str, List[LearnedPattern]] = {}
        self._cache_lock = threading.Lock()

        # Learning callbacks
        self._on_pattern_learned_callbacks = []
        self._on_insight_generated_callbacks = []

        self.logger.info("Learning Engine initialized")

    def _init_db(self):
        """Initialize database"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Learning events table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS learning_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_name TEXT NOT NULL,
                event_type TEXT NOT NULL,
                context_json TEXT,
                action TEXT,
                outcome INTEGER DEFAULT 1,
                outcome_details_json TEXT,
                feedback_score REAL DEFAULT 0,
                metadata_json TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Learned patterns table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS learned_patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern_hash TEXT UNIQUE NOT NULL,
                agent_name TEXT NOT NULL,
                learning_type TEXT NOT NULL,
                pattern_data_json TEXT NOT NULL,
                success_count INTEGER DEFAULT 0,
                failure_count INTEGER DEFAULT 0,
                total_uses INTEGER DEFAULT 0,
                avg_feedback_score REAL DEFAULT 0,
                confidence TEXT DEFAULT 'low',
                is_active INTEGER DEFAULT 1,
                last_used DATETIME,
                metadata_json TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # A/B tests table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ab_tests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_name TEXT NOT NULL,
                test_name TEXT NOT NULL,
                variant_a_json TEXT,
                variant_b_json TEXT,
                success_a INTEGER DEFAULT 0,
                failure_a INTEGER DEFAULT 0,
                success_b INTEGER DEFAULT 0,
                failure_b INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                winner TEXT,
                started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                ended_at DATETIME
            )
        """)

        # Insights table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS learning_insights (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_name TEXT NOT NULL,
                insight_type TEXT NOT NULL,
                description TEXT,
                confidence REAL DEFAULT 0,
                data_json TEXT,
                recommendations_json TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Cross-agent knowledge table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS shared_knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_agent TEXT NOT NULL,
                target_agent TEXT,
                knowledge_type TEXT NOT NULL,
                knowledge_data_json TEXT NOT NULL,
                relevance_score REAL DEFAULT 0,
                times_used INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Indexes
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_agent ON learning_events(agent_name)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_type ON learning_events(event_type)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_patterns_agent ON learned_patterns(agent_name)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_patterns_hash ON learned_patterns(pattern_hash)")

        conn.commit()
        conn.close()

    # ========================================================================
    # EVENT RECORDING
    # ========================================================================

    def record_event(
        self,
        agent_name: str,
        event_type: LearningType,
        context: Dict,
        action: str,
        outcome: bool = True,
        outcome_details: Dict = None,
        feedback_score: float = 0.0,
        metadata: Dict = None
    ) -> int:
        """
        Record a learning event

        Args:
            agent_name: Name of the agent
            event_type: Type of learning event
            context: Input context (what triggered the action)
            action: Action taken
            outcome: Success (True) or failure (False)
            outcome_details: Details about the outcome
            feedback_score: User feedback (-1 to 1)
            metadata: Additional metadata

        Returns:
            Event ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO learning_events (
                agent_name, event_type, context_json, action, outcome,
                outcome_details_json, feedback_score, metadata_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            agent_name,
            event_type.value,
            json.dumps(context),
            action,
            1 if outcome else 0,
            json.dumps(outcome_details or {}),
            feedback_score,
            json.dumps(metadata or {})
        ))

        event_id = cursor.lastrowid
        conn.commit()
        conn.close()

        # Update pattern after recording event
        self._update_pattern_from_event(
            agent_name, event_type, context, action, outcome, feedback_score
        )

        self.logger.debug(f"Recorded learning event {event_id} for {agent_name}")
        return event_id

    def record_feedback(
        self,
        agent_name: str,
        context: Dict,
        feedback_score: float,
        feedback_text: str = ""
    ) -> int:
        """Record user feedback"""
        return self.record_event(
            agent_name=agent_name,
            event_type=LearningType.FEEDBACK,
            context=context,
            action="feedback",
            outcome=feedback_score > 0,
            outcome_details={'feedback_text': feedback_text},
            feedback_score=feedback_score
        )

    def record_error(
        self,
        agent_name: str,
        context: Dict,
        error_type: str,
        error_message: str
    ) -> int:
        """Record an error for pattern learning"""
        return self.record_event(
            agent_name=agent_name,
            event_type=LearningType.ERROR,
            context=context,
            action="error",
            outcome=False,
            outcome_details={
                'error_type': error_type,
                'error_message': error_message
            }
        )

    # ========================================================================
    # PATTERN LEARNING
    # ========================================================================

    def _update_pattern_from_event(
        self,
        agent_name: str,
        event_type: LearningType,
        context: Dict,
        action: str,
        outcome: bool,
        feedback_score: float
    ):
        """Update or create pattern from event"""
        # Generate pattern hash from context
        pattern_key = self._generate_pattern_key(context, action)
        pattern_hash = hashlib.md5(pattern_key.encode()).hexdigest()

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Check if pattern exists
        cursor.execute(
            "SELECT id, success_count, failure_count, total_uses, avg_feedback_score FROM learned_patterns WHERE pattern_hash = ?",
            (pattern_hash,)
        )
        row = cursor.fetchone()

        if row:
            # Update existing pattern
            pattern_id, success, failure, total, avg_feedback = row
            new_success = success + (1 if outcome else 0)
            new_failure = failure + (0 if outcome else 1)
            new_total = total + 1
            new_avg_feedback = (avg_feedback * total + feedback_score) / new_total

            # Calculate confidence
            success_rate = new_success / new_total if new_total > 0 else 0
            confidence = self._calculate_confidence(success_rate, new_total)

            cursor.execute("""
                UPDATE learned_patterns
                SET success_count = ?, failure_count = ?, total_uses = ?,
                    avg_feedback_score = ?, confidence = ?, last_used = datetime('now')
                WHERE id = ?
            """, (new_success, new_failure, new_total, new_avg_feedback, confidence.value, pattern_id))

        else:
            # Create new pattern
            pattern_data = self._extract_pattern_data(context, action)
            confidence = ConfidenceLevel.LOW

            cursor.execute("""
                INSERT INTO learned_patterns (
                    pattern_hash, agent_name, learning_type, pattern_data_json,
                    success_count, failure_count, total_uses, avg_feedback_score, confidence
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                pattern_hash,
                agent_name,
                event_type.value,
                json.dumps(pattern_data),
                1 if outcome else 0,
                0 if outcome else 1,
                1,
                feedback_score,
                confidence.value
            ))

            # Notify callbacks
            for callback in self._on_pattern_learned_callbacks:
                try:
                    callback(agent_name, pattern_data)
                except:
                    pass

        conn.commit()
        conn.close()

        # Invalidate cache
        with self._cache_lock:
            if agent_name in self._pattern_cache:
                del self._pattern_cache[agent_name]

    def _generate_pattern_key(self, context: Dict, action: str) -> str:
        """Generate unique key for pattern"""
        # Extract key features from context
        key_parts = [action]

        # Add important context features
        if 'platform' in context:
            key_parts.append(f"platform:{context['platform']}")
        if 'url' in context:
            # Extract domain from URL
            url = context['url']
            domain = url.split('/')[2] if '//' in url else url.split('/')[0]
            key_parts.append(f"domain:{domain}")
        if 'category' in context:
            key_parts.append(f"category:{context['category']}")
        if 'type' in context:
            key_parts.append(f"type:{context['type']}")

        return '|'.join(sorted(key_parts))

    def _extract_pattern_data(self, context: Dict, action: str) -> Dict:
        """Extract pattern data from context"""
        pattern = {
            'action': action,
            'features': {}
        }

        # Extract relevant features
        for key in ['platform', 'category', 'type', 'status', 'language']:
            if key in context:
                pattern['features'][key] = context[key]

        # Extract URL pattern
        if 'url' in context:
            url = context['url']
            if '//' in url:
                domain = url.split('/')[2]
                path_parts = url.split('/')[3:5]  # First two path segments
                pattern['features']['domain'] = domain
                pattern['features']['path_pattern'] = '/'.join(path_parts)

        return pattern

    def _calculate_confidence(self, success_rate: float, sample_size: int) -> ConfidenceLevel:
        """Calculate confidence level based on success rate and sample size"""
        # Need minimum samples for confidence
        if sample_size < 5:
            return ConfidenceLevel.LOW

        if success_rate >= 0.95 and sample_size >= 20:
            return ConfidenceLevel.VERY_HIGH
        elif success_rate >= 0.80 and sample_size >= 10:
            return ConfidenceLevel.HIGH
        elif success_rate >= 0.60:
            return ConfidenceLevel.MEDIUM
        else:
            return ConfidenceLevel.LOW

    # ========================================================================
    # RECOMMENDATIONS
    # ========================================================================

    def get_recommendation(
        self,
        agent_name: str,
        context: Dict,
        action_type: str = None
    ) -> Dict:
        """
        Get recommendation based on learned patterns

        Args:
            agent_name: Agent requesting recommendation
            context: Current context
            action_type: Type of action (optional filter)

        Returns:
            Dict with recommended action and confidence
        """
        # Get relevant patterns
        patterns = self._get_matching_patterns(agent_name, context)

        if not patterns:
            return {
                'has_recommendation': False,
                'reason': 'No matching patterns found'
            }

        # Find best pattern
        best_pattern = max(patterns, key=lambda p: (
            p.confidence.value,
            p.success_count / max(p.total_uses, 1),
            p.total_uses
        ))

        success_rate = best_pattern.success_count / max(best_pattern.total_uses, 1)

        return {
            'has_recommendation': True,
            'recommended_action': best_pattern.pattern_data.get('action'),
            'confidence': best_pattern.confidence.value,
            'success_rate': success_rate,
            'sample_size': best_pattern.total_uses,
            'pattern_data': best_pattern.pattern_data,
            'avg_feedback': best_pattern.avg_feedback_score
        }

    def _get_matching_patterns(
        self,
        agent_name: str,
        context: Dict
    ) -> List[LearnedPattern]:
        """Get patterns matching context"""
        # Check cache first
        with self._cache_lock:
            if agent_name in self._pattern_cache:
                cached = self._pattern_cache[agent_name]
            else:
                cached = self._load_patterns_for_agent(agent_name)
                self._pattern_cache[agent_name] = cached

        # Filter by context match
        matching = []
        for pattern in cached:
            if self._pattern_matches_context(pattern, context):
                matching.append(pattern)

        return matching

    def _load_patterns_for_agent(self, agent_name: str) -> List[LearnedPattern]:
        """Load all patterns for agent from database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, pattern_hash, agent_name, learning_type, pattern_data_json,
                   success_count, failure_count, total_uses, avg_feedback_score,
                   confidence, is_active, last_used, metadata_json, created_at
            FROM learned_patterns
            WHERE agent_name = ? AND is_active = 1
        """, (agent_name,))

        patterns = []
        for row in cursor.fetchall():
            patterns.append(LearnedPattern(
                id=row[0],
                pattern_hash=row[1],
                agent_name=row[2],
                learning_type=LearningType(row[3]),
                pattern_data=json.loads(row[4]) if row[4] else {},
                success_count=row[5],
                failure_count=row[6],
                total_uses=row[7],
                avg_feedback_score=row[8],
                confidence=ConfidenceLevel(row[9]) if row[9] else ConfidenceLevel.LOW,
                is_active=bool(row[10]),
                last_used=datetime.fromisoformat(row[11]) if row[11] else None,
                metadata=json.loads(row[12]) if row[12] else {},
                created_at=datetime.fromisoformat(row[13]) if row[13] else None
            ))

        conn.close()
        return patterns

    def _pattern_matches_context(self, pattern: LearnedPattern, context: Dict) -> bool:
        """Check if pattern matches context"""
        features = pattern.pattern_data.get('features', {})

        for key, value in features.items():
            if key in context:
                if key == 'domain':
                    # Partial domain match
                    if value not in str(context.get('url', '')):
                        return False
                elif context[key] != value:
                    return False

        return True

    # ========================================================================
    # A/B TESTING
    # ========================================================================

    def create_ab_test(
        self,
        agent_name: str,
        test_name: str,
        variant_a: Dict,
        variant_b: Dict
    ) -> int:
        """Create A/B test"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO ab_tests (agent_name, test_name, variant_a_json, variant_b_json)
            VALUES (?, ?, ?, ?)
        """, (agent_name, test_name, json.dumps(variant_a), json.dumps(variant_b)))

        test_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Created A/B test {test_id}: {test_name}")
        return test_id

    def get_ab_variant(self, test_id: int) -> Tuple[str, Dict]:
        """Get variant for A/B test (random selection with balancing)"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT variant_a_json, variant_b_json, success_a, failure_a, success_b, failure_b
            FROM ab_tests WHERE id = ? AND is_active = 1
        """, (test_id,))

        row = cursor.fetchone()
        conn.close()

        if not row:
            return None, {}

        variant_a = json.loads(row[0])
        variant_b = json.loads(row[1])
        total_a = row[2] + row[3]
        total_b = row[4] + row[5]

        # Balance selection (prefer less-tested variant)
        import random
        if total_a < total_b:
            probability_a = 0.6
        elif total_b < total_a:
            probability_a = 0.4
        else:
            probability_a = 0.5

        if random.random() < probability_a:
            return 'a', variant_a
        else:
            return 'b', variant_b

    def record_ab_result(self, test_id: int, variant: str, success: bool):
        """Record A/B test result"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        if variant == 'a':
            if success:
                cursor.execute("UPDATE ab_tests SET success_a = success_a + 1 WHERE id = ?", (test_id,))
            else:
                cursor.execute("UPDATE ab_tests SET failure_a = failure_a + 1 WHERE id = ?", (test_id,))
        else:
            if success:
                cursor.execute("UPDATE ab_tests SET success_b = success_b + 1 WHERE id = ?", (test_id,))
            else:
                cursor.execute("UPDATE ab_tests SET failure_b = failure_b + 1 WHERE id = ?", (test_id,))

        conn.commit()
        conn.close()

        # Check if we can determine winner
        self._check_ab_winner(test_id)

    def _check_ab_winner(self, test_id: int):
        """Check if A/B test has a statistical winner"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT success_a, failure_a, success_b, failure_b
            FROM ab_tests WHERE id = ?
        """, (test_id,))

        row = cursor.fetchone()
        if not row:
            conn.close()
            return

        success_a, failure_a, success_b, failure_b = row
        total_a = success_a + failure_a
        total_b = success_b + failure_b

        # Need minimum samples
        if total_a < 30 or total_b < 30:
            conn.close()
            return

        rate_a = success_a / total_a
        rate_b = success_b / total_b

        # Simple significance check (>10% difference with enough samples)
        if abs(rate_a - rate_b) > 0.1:
            winner = 'a' if rate_a > rate_b else 'b'

            cursor.execute("""
                UPDATE ab_tests SET winner = ?, is_active = 0, ended_at = datetime('now')
                WHERE id = ?
            """, (winner, test_id))

            conn.commit()
            self.logger.info(f"A/B test {test_id} winner: {winner}")

        conn.close()

    # ========================================================================
    # INSIGHTS
    # ========================================================================

    def get_insights(self, agent_name: str) -> List[LearningInsight]:
        """Get insights for agent"""
        insights = []

        # Get pattern-based insights
        patterns = self._load_patterns_for_agent(agent_name)

        # Find high-performing patterns
        high_performers = [p for p in patterns if p.confidence in [ConfidenceLevel.HIGH, ConfidenceLevel.VERY_HIGH]]
        if high_performers:
            insights.append(LearningInsight(
                insight_type='high_performing_patterns',
                description=f'Found {len(high_performers)} high-performing patterns',
                confidence=0.9,
                data={'patterns': [p.pattern_data for p in high_performers[:5]]},
                recommendations=['Continue using these patterns', 'Share with similar agents'],
                created_at=datetime.now()
            ))

        # Find problematic patterns (high failure)
        problematic = [p for p in patterns if p.failure_count > p.success_count and p.total_uses >= 5]
        if problematic:
            insights.append(LearningInsight(
                insight_type='problematic_patterns',
                description=f'Found {len(problematic)} patterns with high failure rates',
                confidence=0.85,
                data={'patterns': [p.pattern_data for p in problematic[:5]]},
                recommendations=['Review and modify these patterns', 'Consider alternative approaches'],
                created_at=datetime.now()
            ))

        # Get error patterns
        error_insights = self._analyze_errors(agent_name)
        insights.extend(error_insights)

        # Save insights
        self._save_insights(agent_name, insights)

        return insights

    def _analyze_errors(self, agent_name: str) -> List[LearningInsight]:
        """Analyze error patterns"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT outcome_details_json, COUNT(*) as count
            FROM learning_events
            WHERE agent_name = ? AND event_type = 'error' AND created_at > datetime('now', '-7 days')
            GROUP BY outcome_details_json
            HAVING count >= 3
            ORDER BY count DESC
            LIMIT 10
        """, (agent_name,))

        insights = []
        for row in cursor.fetchall():
            details = json.loads(row[0]) if row[0] else {}
            count = row[1]

            if details.get('error_type'):
                insights.append(LearningInsight(
                    insight_type='recurring_error',
                    description=f"Error '{details.get('error_type')}' occurred {count} times",
                    confidence=0.8,
                    data={'error_type': details.get('error_type'), 'count': count},
                    recommendations=['Investigate root cause', 'Add error handling'],
                    created_at=datetime.now()
                ))

        conn.close()
        return insights

    def _save_insights(self, agent_name: str, insights: List[LearningInsight]):
        """Save insights to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        for insight in insights:
            cursor.execute("""
                INSERT INTO learning_insights (
                    agent_name, insight_type, description, confidence, data_json, recommendations_json
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                agent_name,
                insight.insight_type,
                insight.description,
                insight.confidence,
                json.dumps(insight.data),
                json.dumps(insight.recommendations)
            ))

        conn.commit()
        conn.close()

    # ========================================================================
    # CROSS-AGENT KNOWLEDGE
    # ========================================================================

    def share_knowledge(
        self,
        source_agent: str,
        knowledge_type: str,
        knowledge_data: Dict,
        target_agent: str = None,
        relevance_score: float = 0.5
    ) -> int:
        """Share knowledge between agents"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO shared_knowledge (
                source_agent, target_agent, knowledge_type, knowledge_data_json, relevance_score
            ) VALUES (?, ?, ?, ?, ?)
        """, (source_agent, target_agent, knowledge_type, json.dumps(knowledge_data), relevance_score))

        knowledge_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return knowledge_id

    def get_shared_knowledge(
        self,
        agent_name: str,
        knowledge_type: str = None
    ) -> List[Dict]:
        """Get shared knowledge for agent"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        query = """
            SELECT knowledge_type, knowledge_data_json, source_agent, relevance_score
            FROM shared_knowledge
            WHERE (target_agent = ? OR target_agent IS NULL)
        """
        params = [agent_name]

        if knowledge_type:
            query += " AND knowledge_type = ?"
            params.append(knowledge_type)

        query += " ORDER BY relevance_score DESC, times_used DESC"

        cursor.execute(query, params)

        knowledge = []
        for row in cursor.fetchall():
            knowledge.append({
                'type': row[0],
                'data': json.loads(row[1]) if row[1] else {},
                'source': row[2],
                'relevance': row[3]
            })

        conn.close()
        return knowledge

    # ========================================================================
    # STATISTICS
    # ========================================================================

    def get_statistics(self, agent_name: str = None) -> Dict:
        """Get learning statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Total events
        if agent_name:
            cursor.execute("SELECT COUNT(*) FROM learning_events WHERE agent_name = ?", (agent_name,))
        else:
            cursor.execute("SELECT COUNT(*) FROM learning_events")
        total_events = cursor.fetchone()[0]

        # Success rate
        if agent_name:
            cursor.execute("""
                SELECT AVG(outcome) FROM learning_events WHERE agent_name = ?
            """, (agent_name,))
        else:
            cursor.execute("SELECT AVG(outcome) FROM learning_events")
        success_rate = cursor.fetchone()[0] or 0

        # Patterns count
        if agent_name:
            cursor.execute("SELECT COUNT(*) FROM learned_patterns WHERE agent_name = ?", (agent_name,))
        else:
            cursor.execute("SELECT COUNT(*) FROM learned_patterns")
        total_patterns = cursor.fetchone()[0]

        # High confidence patterns
        if agent_name:
            cursor.execute("""
                SELECT COUNT(*) FROM learned_patterns
                WHERE agent_name = ? AND confidence IN ('high', 'very_high')
            """, (agent_name,))
        else:
            cursor.execute("""
                SELECT COUNT(*) FROM learned_patterns WHERE confidence IN ('high', 'very_high')
            """)
        high_confidence = cursor.fetchone()[0]

        conn.close()

        return {
            'total_events': total_events,
            'success_rate': round(success_rate * 100, 1),
            'total_patterns': total_patterns,
            'high_confidence_patterns': high_confidence,
            'learning_progress': round(high_confidence / max(total_patterns, 1) * 100, 1)
        }

    # ========================================================================
    # CALLBACKS
    # ========================================================================

    def on_pattern_learned(self, callback: Callable[[str, Dict], None]):
        """Register callback for new pattern learned"""
        self._on_pattern_learned_callbacks.append(callback)

    def on_insight_generated(self, callback: Callable[[str, LearningInsight], None]):
        """Register callback for new insight generated"""
        self._on_insight_generated_callbacks.append(callback)


# ============================================================================
# GLOBAL INSTANCE
# ============================================================================

_learning_engine_instance = None


def get_learning_engine() -> LearningEngine:
    """Get global learning engine instance"""
    global _learning_engine_instance
    if _learning_engine_instance is None:
        _learning_engine_instance = LearningEngine()
    return _learning_engine_instance


# ============================================================================
# CLI TEST
# ============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("SELF-LEARNING ENGINE - Test")
    print("=" * 60)

    engine = get_learning_engine()

    # Record some test events
    print("\nRecording test events...")

    for i in range(10):
        engine.record_event(
            agent_name='test_agent',
            event_type=LearningType.OUTCOME,
            context={'platform': 'vinted', 'url': 'https://vinted.de/items/123'},
            action='scrape_product',
            outcome=(i % 3 != 0)  # 70% success rate
        )

    # Get recommendation
    print("\nGetting recommendation...")
    rec = engine.get_recommendation(
        agent_name='test_agent',
        context={'platform': 'vinted'}
    )
    print(f"  Has recommendation: {rec['has_recommendation']}")
    if rec['has_recommendation']:
        print(f"  Confidence: {rec['confidence']}")
        print(f"  Success rate: {rec['success_rate']:.0%}")

    # Get insights
    print("\nGetting insights...")
    insights = engine.get_insights('test_agent')
    for insight in insights:
        print(f"  [{insight.insight_type}] {insight.description}")

    # Get statistics
    print("\nStatistics:")
    stats = engine.get_statistics('test_agent')
    print(f"  Total events: {stats['total_events']}")
    print(f"  Success rate: {stats['success_rate']}%")
    print(f"  Patterns learned: {stats['total_patterns']}")
    print(f"  Learning progress: {stats['learning_progress']}%")

    print("\n" + "=" * 60)
    print("Usage:")
    print("  engine = get_learning_engine()")
    print("  engine.record_event(agent, type, context, action, outcome)")
    print("  recommendation = engine.get_recommendation(agent, context)")
    print("  insights = engine.get_insights(agent)")
    print("=" * 60)
