#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LEBONCOIN CONFIG - France Configuration
Selectors, URL patterns, condition mapping, and category mapping for Leboncoin.fr
"""

LEBONCOIN_CONFIG = {
    'fr': {
        'domain': 'leboncoin.fr',
        'base_url': 'https://www.leboncoin.fr',
        'language': 'fr',
        'currency': 'EUR',
        'currency_symbol': '\u20ac',

        # Search URL patterns
        'search_url': 'https://www.leboncoin.fr/{category}',
        'search_params': {
            'text': 'text',
            'price_min': 'price_min',
            'price_max': 'price_max',
            'condition': 'item_condition'
        },

        # Condition IDs for URL filter (KRITIK - daha once KULLANILMIYORDU!)
        'condition_ids': {
            'new': '1',
            'like_new': '2',
            'good': '3',
            'fair': '4',
            'parts': '5'
        },

        # Search result selectors (multiple fallbacks)
        'item_selectors': [
            '[data-qa-id="aditem_container"]',
            '[data-test-id="ad"]',
            'a[class*="AdCard"]',
            'article a[href*="/ad/"]',
            '[class*="styles_adCard"]'
        ],

        # Title selectors
        'title_selectors': [
            '[data-qa-id="aditem_title"]',
            '[data-test-id="ad-title"]',
            'h2[class*="Title"]',
            'p[class*="title"]',
            'span[class*="Title"]'
        ],

        # Price selectors
        'price_selectors': [
            '[data-qa-id="aditem_price"]',
            '[data-test-id="ad-price"]',
            'span[class*="Price"]',
            'p[class*="price"]'
        ],

        # Image selectors
        'image_selectors': [
            '[data-qa-id="aditem_image"] img',
            'img[data-lazyload]',
            'img[src*="img.leboncoin.fr"]',
            'picture img'
        ],

        # Location selectors
        'location_selectors': [
            '[data-qa-id="aditem_location"]',
            '[data-test-id="ad-location"]',
            '[class*="Location"]'
        ],

        # Condition selectors (for product detail page)
        'condition_selectors': [
            '[data-qa-id="criteria_item_item_condition"]',
            '[data-test-id="criteria-item-condition"]',
            'div[class*="Criterion"]'
        ],

        # URL pattern for extracting ad ID
        'url_pattern': r'/(\d+)\.htm',

        # French condition mapping (text to normalized)
        'condition_map': {
            'neuf': 'new',
            'tres bon etat': 'like_new',
            'bon etat': 'good',
            'etat satisfaisant': 'fair',
            'pour pieces': 'parts'
        },

        # Normalized to French (for display)
        'condition_labels': {
            'new': 'Neuf',
            'like_new': 'Tres bon etat',
            'good': 'Bon etat',
            'fair': 'Etat satisfaisant',
            'parts': 'Pour pieces'
        },

        # Categories
        'categories': {
            'all': 'recherche',
            'clothing': 'vetements',
            'accessories': 'accessoires_bagagerie',
            'shoes': 'chaussures',
            'watches': 'montres_bijoux',
            'electronics': 'informatique',
            'phones': 'telephonie',
            'furniture': 'ameublement',
            'appliances': 'electromenager',
            'sports': 'sports_hobbies',
            'baby': 'equipement_bebe'
        },

        # Pagination
        'pagination': {
            'param': 'page',
            'max_pages': 50
        },

        # Cookie popup selectors
        'cookie_selectors': [
            'button[id*="accept"]',
            'button[data-testid="accept-button"]',
            '#didomi-notice-agree-button',
            'button.didomi-components-button',
            '[aria-label*="accepter"]'
        ]
    }
}


def get_leboncoin_config(country: str = 'fr') -> dict:
    """Get Leboncoin config - only France supported"""
    return LEBONCOIN_CONFIG.get(country, LEBONCOIN_CONFIG['fr'])


def build_search_url(
    query: str,
    category: str = None,
    condition: str = None,
    min_price: float = None,
    max_price: float = None,
    page: int = 1
) -> str:
    """
    Build Leboncoin search URL with all filters including condition

    Args:
        query: Search keywords
        category: Category code (e.g., 'clothing', 'shoes')
        condition: Condition filter (new, like_new, good, fair, parts)
        min_price: Minimum price
        max_price: Maximum price
        page: Page number

    Returns:
        Complete search URL with all filters
    """
    from urllib.parse import quote_plus, urlencode

    config = LEBONCOIN_CONFIG['fr']

    # Get category path
    cat_path = config['categories'].get(category, config['categories']['all'])

    # Build base URL
    base_url = f"{config['base_url']}/{cat_path}"

    # Build params
    params = {}

    if query:
        params['text'] = query

    # ADD CONDITION FILTER - This was missing before!
    if condition and condition in config['condition_ids']:
        params['item_condition'] = config['condition_ids'][condition]

    if min_price:
        params['price_min'] = int(min_price)

    if max_price:
        params['price_max'] = int(max_price)

    if page > 1:
        params['page'] = page

    # Build final URL
    if params:
        return f"{base_url}?{urlencode(params)}"
    return base_url


def get_condition_id(condition: str) -> str:
    """Get Leboncoin condition ID for URL parameter"""
    config = LEBONCOIN_CONFIG['fr']
    return config['condition_ids'].get(condition, '')


def normalize_condition(french_condition: str) -> str:
    """Convert French condition text to normalized value"""
    config = LEBONCOIN_CONFIG['fr']
    french_lower = french_condition.lower().strip()

    # Remove accents for matching
    french_lower = french_lower.replace('\xe9', 'e').replace('\xe8', 'e').replace('\xe0', 'a')

    return config['condition_map'].get(french_lower, 'unknown')
