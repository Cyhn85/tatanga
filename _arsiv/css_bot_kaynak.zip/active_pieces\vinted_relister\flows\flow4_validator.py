# Flow 4: Content Validator with Gemini
import sys, os, json
import google.generativeai as genai
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')

from config import GEMINI_API_KEY, STATUS_SEO_DONE, STATUS_VALIDATED
from utils.database import db

class ContentValidator:
    def __init__(self):
        genai.configure(api_key=GEMINI_API_KEY)
        self.model = genai.GenerativeModel('gemini-1.5-flash')

    def validate(self, product: dict) -> dict:
        title = product.get('processed_title', '')
        desc = product.get('processed_description', '')

        prompt = f"""Pruefe diesen Vinted-Eintrag auf Qualitaet:

Titel: {title}
Beschreibung: {desc}

Bewerte (1-10) und gib Feedback. Antworte NUR als JSON:
{{"score": 8, "valid": true, "notes": "Gut geschrieben"}}
"""
        try:
            resp = self.model.generate_content(prompt)
            text = resp.text
            start = text.find('{')
            end = text.rfind('}') + 1
            if start >= 0 and end > start:
                return json.loads(text[start:end])
        except Exception as e:
            print(f'[ERR] Gemini: {e}')
        return {'score': 5, 'valid': True, 'notes': 'Auto-approved'}

    def process_product(self, product_id: int) -> bool:
        product = db.get_product(product_id)
        if not product: return False

        result = self.validate(product)
        if result.get('valid', True):
            db.update_product(product_id, {
                'status': STATUS_VALIDATED,
                'validation_notes': result.get('notes', '')
            })
            db.add_log(product_id, 'validate', 'success', f"Score: {result.get('score', 0)}")
            print(f'[OK] {product_id}: Score {result.get("score", 0)}')
            return True
        return False

    def run(self) -> int:
        print('='*50 + '\nVALIDATOR (Gemini)\n' + '='*50)
        products = db.get_products_by_status(STATUS_SEO_DONE)
        print(f'{len(products)} products to validate')
        done = 0
        for p in products:
            if self.process_product(p['id']): done += 1
        print(f'\n*** DONE: {done} validated ***')
        return done

def main():
    return ContentValidator().run()

if __name__ == '__main__': main()
