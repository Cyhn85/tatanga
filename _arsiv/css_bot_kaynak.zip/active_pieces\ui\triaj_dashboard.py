#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Triaj Merkezi Dashboard v2.0
Terminal-First Design with Smart Agent Chat System

Author: TATANGA Team
Version: 2.0
"""

import streamlit as st
import sqlite3
import pandas as pd
import json
import re
from pathlib import Path
from datetime import datetime
import sys
import requests

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

# GitHub Publisher import (CSS Berlin - GitHub + Cloudflare Pages)
try:
    from integrations.github_publisher import (
        publish_favorite_to_cssberlin,
        publish_variant_to_cssberlin,
        GitHubPublisher
    )
    GITHUB_PUBLISHER_AVAILABLE = True
except ImportError:
    GITHUB_PUBLISHER_AVAILABLE = False

# Product Card Agent import (komisyon, kargo, künye)
try:
    from agents.product_card_agent import ProductCardAgent, PLATFORM_FEES, SHIPPING_COSTS, Platform
    PRODUCT_CARD_AVAILABLE = True
    product_card_agent = ProductCardAgent()
except ImportError:
    PRODUCT_CARD_AVAILABLE = False
    product_card_agent = None

# Legacy - WooCommerce kullanılmıyor
WOOCOMMERCE_AVAILABLE = False

# API Base URL
API_URL = "http://localhost:8080"

# Daemon API URL (Hetzner)
DAEMON_API_URL = "http://195.201.146.224:8000/api/daemon"

# Daemon interval options
DAEMON_INTERVAL_OPTIONS = {
    "30 saniye (Hizli)": 30,
    "1 dakika (Normal)": 60,
    "3 dakika (Yavas)": 180,
    "6 dakika (Cok Yavas)": 360
}

# V2 Scraper imports (doğrudan kazıma için)
try:
    from vinted_v2_scraper import VintedV2Scraper
    VINTED_V2_AVAILABLE = True
except ImportError:
    VINTED_V2_AVAILABLE = False

try:
    from kleinanzeigen_v2_scraper import KleinanzeigenV2Scraper
    KLEINANZEIGEN_V2_AVAILABLE = True
except ImportError:
    KLEINANZEIGEN_V2_AVAILABLE = False

try:
    from ebay_de_v2_scraper import EbayDeV2Scraper
    EBAY_V2_AVAILABLE = True
except ImportError:
    EBAY_V2_AVAILABLE = False

# eBay API Connector (daha hızlı, resmi API)
try:
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from integrations.ebay_connector import EbayConnector
    EBAY_API_AVAILABLE = True
except ImportError:
    EBAY_API_AVAILABLE = False

# Tradera Connector (İsveç)
try:
    from integrations.tradera_connector import TraderaConnector
    TRADERA_AVAILABLE = True
except ImportError:
    TRADERA_AVAILABLE = False

# Sellpy Connector (İkinci El)
try:
    from integrations.sellpy_connector import SellpyConnector
    SELLPY_AVAILABLE = True
except ImportError:
    SELLPY_AVAILABLE = False

# Publishing Page import
try:
    from publish_page import render_publish_page
    PUBLISH_PAGE_AVAILABLE = True
except ImportError:
    PUBLISH_PAGE_AVAILABLE = False

# Percentil Connector (Çocuk/Yetişkin Moda)
try:
    from integrations.percentil_connector import PercentilConnector
    PERCENTIL_AVAILABLE = True
except ImportError:
    PERCENTIL_AVAILABLE = False

# Task Scheduler (TATANGA v3)
try:
    from task_scheduler import SchedulerService, AVAILABLE_SCRAPERS
    SCHEDULER_AVAILABLE = True
except ImportError:
    SCHEDULER_AVAILABLE = False
    AVAILABLE_SCRAPERS = {}

# Variant Generator (Multi-platform image/SEO variants)
try:
    from integrations.variant_generator import (
        ProductVariantGenerator,
        download_images_on_favorite,
        generate_product_variants
    )
    VARIANT_GENERATOR_AVAILABLE = True
except ImportError:
    VARIANT_GENERATOR_AVAILABLE = False
    download_images_on_favorite = None
    generate_product_variants = None

# Category Mapper (TATANGA v3)
try:
    from category_mapper import CATEGORY_TREE, BRAND_DATABASE, PLATFORM_MAPPING
    MAPPER_AVAILABLE = True
except ImportError:
    MAPPER_AVAILABLE = False
    CATEGORY_TREE = {}
    BRAND_DATABASE = {}
    PLATFORM_MAPPING = {}

# Favorites Validator (Kaynak kontrol, maliyet hesaplama)
try:
    from integrations.favorites_validator import (
        FavoritesValidator,
        generate_original_title,
        generate_original_description,
        ensure_minimum_images,
        manipulate_images_for_publish,
        get_validator
    )
    FAVORITES_VALIDATOR_AVAILABLE = True
except ImportError:
    FAVORITES_VALIDATOR_AVAILABLE = False
    get_validator = None

# Vinted Manual Publisher (dosya sistemi tabanlı manuel yayınlama)
try:
    from integrations.vinted_manual_publisher import VintedManualPublisher, prepare_vinted_manual_listing
    VINTED_MANUAL_AVAILABLE = True
except ImportError:
    VINTED_MANUAL_AVAILABLE = False
    VintedManualPublisher = None
    prepare_vinted_manual_listing = None

# ==================== CONFIGURATION ====================

st.set_page_config(
    page_title="TATANGA Triaj Merkezi",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)

# DB_PATH - try multiple locations
_base_dir = Path(__file__).parent.parent
_possible_paths = [
    _base_dir / 'storage' / 'tatanga.db',
    _base_dir / 'tatanga.db',
    _base_dir / 'data' / 'tatanga.db',
    Path(r'C:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces\storage\tatanga.db'),
]
DB_PATH = None
for _p in _possible_paths:
    if _p.exists():
        DB_PATH = _p
        break
if DB_PATH is None:
    # Create in storage folder
    DB_PATH = _base_dir / 'storage' / 'tatanga.db'
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)

# ==================== PUBLISH TARGETS (STORES) ====================

PUBLISH_TARGETS = {
    "cssberlin": {
        "name": "CSS Berlin",
        "url": "https://cssberlin.de",
        "type": "woocommerce",
        "icon": "🏪",
        "requires_login": True
    },
    "vinted_de": {
        "name": "Vinted DE (Satici)",
        "url": "https://www.vinted.de",
        "type": "vinted",
        "icon": "👗",
        "requires_login": True
    },
    "ebay_de": {
        "name": "eBay DE (Satici)",
        "url": "https://www.ebay.de",
        "type": "ebay",
        "icon": "🛒",
        "requires_login": True
    },
    "kleinanzeigen": {
        "name": "Kleinanzeigen",
        "url": "https://www.kleinanzeigen.de",
        "type": "kleinanzeigen",
        "icon": "📋",
        "requires_login": True
    }
}

# ==================== PLATFORM DEFINITIONS ====================

PLATFORMS = {
    "vinted": {
        "name": "Vinted",
        "countries": ["de", "fr", "uk", "es", "it", "nl", "be", "pl", "cz", "at", "se", "dk", "no"],
        "icon": "👗"
    },
    "ebay": {
        "name": "eBay",
        "countries": ["de", "uk", "fr", "us", "it", "es", "nl", "be", "at", "ch"],
        "icon": "🛒"
    },
    "kleinanzeigen": {"name": "Kleinanzeigen", "countries": ["de"], "icon": "📋"},
    "willhaben": {"name": "Willhaben", "countries": ["at"], "icon": "🇦🇹"},
    "leboncoin": {"name": "Leboncoin", "countries": ["fr"], "icon": "🇫🇷"},
    "tradera": {"name": "Tradera", "countries": ["se"], "icon": "🇸🇪"},
    "sellpy": {"name": "Sellpy", "countries": ["se", "de"], "icon": "♻���"},
    "percentil": {"name": "Percentil", "countries": ["es"], "icon": "🇪🇸"},
    "shpock": {"name": "Shpock", "countries": ["de", "at", "uk"], "icon": "📱"},
}

# ==================== AGENT INFO ====================

AGENTS = {
    "CEOAgent": {
        "name": "CEO Agent",
        "description": "Tum sistemi yonetir, kararlar alir, diger ajanlari koordine eder",
        "status": "active",
        "capabilities": ["Strateji belirleme", "Ajan koordinasyonu", "Raporlama"]
    },
    "ScrapingManager": {
        "name": "Scraping Manager",
        "description": "36 platformda urun kazima islemlerini yonetir",
        "status": "active",
        "capabilities": ["Paralel kazima", "Rate limiting", "Hata yonetimi"]
    },
    "ConditionAgent": {
        "name": "Condition Normalization Agent",
        "description": "Ham durum etiketlerini evrensel 1-5 skoruna cevirir",
        "status": "active",
        "capabilities": ["12 dil destegi", "Catisma tespiti", "Ogrenme yetenegi"]
    },
    "FilteringAgent": {
        "name": "Filtering Agent",
        "description": "Urunleri kurallara gore filtreler, onaylar veya reddeder",
        "status": "active",
        "capabilities": ["Otomatik filtreleme", "Kar marji hesabi", "Risk analizi"]
    },
    "SelfHealing": {
        "name": "Self-Healing Agent",
        "description": "Hatalari tespit eder ve otomatik duzeltir",
        "status": "active",
        "capabilities": ["Hata tespiti", "Selector onarimi", "Sistem izleme"]
    },
    "TelegramBot": {
        "name": "Telegram Bot",
        "description": "Telegram uzerinden bildirim ve kontrol",
        "status": "active",
        "capabilities": ["Bildirimler", "Uzaktan kontrol", "Raporlar"]
    },
    "LogisticsEstimator": {
        "name": "Logistics Estimator",
        "description": "Kargo surelerini ve maliyetlerini tahmin eder",
        "status": "active",
        "capabilities": ["28 ulke destegi", "Sure tahmini", "Maliyet hesabi"]
    },
    "VisionAgent": {
        "name": "Vision Agent",
        "description": "Urun fotograflarini analiz eder",
        "status": "active",
        "capabilities": ["Durum analizi", "Marka tespiti", "Sahtecilik kontrolu"]
    }
}

# ==================== DATABASE ====================

def get_db():
    """Get database connection"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    # Products tablosunu oluştur (yoksa)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            url TEXT UNIQUE,
            price REAL,
            currency TEXT DEFAULT 'EUR',
            platform TEXT,
            images TEXT,
            image TEXT,
            condition TEXT,
            batch_id TEXT,
            is_in_inbox INTEGER DEFAULT 1,
            is_favorite INTEGER DEFAULT 0,
            scraped_at TEXT,
            category TEXT,
            brand TEXT,
            size TEXT,
            description TEXT,
            seller TEXT,
            seller_rating REAL,
            location TEXT,
            shipping_price REAL,
            original_price REAL,
            discount_percent REAL,
            views INTEGER DEFAULT 0,
            favorites_count INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Favorites tablosunu oluştur (yoksa)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS favorites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER,
            added_at TEXT DEFAULT CURRENT_TIMESTAMP,
            notes TEXT,
            FOREIGN KEY (product_id) REFERENCES products(id)
        )
    """)

    conn.commit()
    return conn


def dict_from_row(row):
    """Convert sqlite3.Row to dict"""
    return dict(row) if row else None


# ==================== SMART AGENT SYSTEM ====================

def extract_product_id(text: str) -> int:
    """Extract product/favorite ID from text"""
    patterns = [
        r'favori\s*#?(\d+)',
        r'#(\d+)',
        r'urun\s*#?(\d+)',
        r'id\s*:?\s*(\d+)',
    ]
    for pattern in patterns:
        match = re.search(pattern, text.lower())
        if match:
            return int(match.group(1))
    return None


def extract_platform(text: str) -> str:
    """Extract platform name from text"""
    text_lower = text.lower()
    for key in PLATFORMS.keys():
        if key in text_lower:
            return key
    # Check with country codes
    patterns = [
        r'vinted_(\w{2})',
        r'ebay_(\w{2})',
    ]
    for pattern in patterns:
        match = re.search(pattern, text_lower)
        if match:
            return pattern.split('_')[0]
    return None


def detect_intent(text: str) -> str:
    """Detect user intent from message"""
    text_lower = text.lower()

    # Command intents
    if text_lower.startswith('/'):
        if '/status' in text_lower:
            return 'status'
        if '/help' in text_lower:
            return 'help'
        if '/pause' in text_lower or '/duraklat' in text_lower:
            return 'pause'
        if '/resume' in text_lower or '/devam' in text_lower:
            return 'resume'
        if '/stop' in text_lower or '/durdur' in text_lower:
            return 'stop'

    # Natural language intents
    intents = {
        'product_info': ['favori', 'urun', 'hakkinda', 'bilgi', 'ne biliyorsun'],
        'recommendation': ['iyi mi', 'alayim mi', 'oneri', 'tavsiye', 'almali mi'],
        'statistics': ['kac', 'rapor', 'istatistik', 'bugun', 'toplam'],
        'agent_info': ['ne yapar', 'gorevi', 'nasil calisir', 'agent', 'ajan'],
        'list': ['en karli', 'liste', 'goster', 'sirala', 'top'],
        'platform_info': ['platform', 'desteklenen', 'kac ulke'],
        'scraping': ['kazima', 'basalt', 'scrape', 'tara'],
        'pause': ['duraklat', 'bekle', 'dur'],
        'greeting': ['merhaba', 'selam', 'hey', 'nasil'],
    }

    for intent, keywords in intents.items():
        for keyword in keywords:
            if keyword in text_lower:
                return intent

    return 'unknown'


def get_product_info(product_id: int) -> dict:
    """Get detailed product info from database"""
    conn = get_db()
    cursor = conn.cursor()

    # First try favorites
    cursor.execute("""
        SELECT
            f.id as fav_id,
            p.*,
            ps.normalized_score,
            ps.profit_amount,
            ps.profit_margin,
            ps.is_conflicting,
            ps.conflict_reason
        FROM favorites f
        JOIN products p ON f.product_id = p.id
        LEFT JOIN product_scores ps ON p.id = ps.product_id
        WHERE f.id = ?
    """, (product_id,))

    row = cursor.fetchone()
    if not row:
        # Try product directly
        cursor.execute("""
            SELECT
                p.*,
                ps.normalized_score,
                ps.profit_amount,
                ps.profit_margin,
                ps.is_conflicting,
                ps.conflict_reason
            FROM products p
            LEFT JOIN product_scores ps ON p.id = ps.product_id
            WHERE p.id = ?
        """, (product_id,))
        row = cursor.fetchone()

    conn.close()
    return dict_from_row(row) if row else None


def get_top_profitable(limit: int = 5) -> list:
    """Get top profitable favorites"""
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            f.id as fav_id,
            p.title, p.platform, p.price,
            ps.profit_margin, ps.profit_amount
        FROM favorites f
        JOIN products p ON f.product_id = p.id
        LEFT JOIN product_scores ps ON p.id = ps.product_id
        WHERE ps.profit_margin IS NOT NULL
        ORDER BY ps.profit_margin DESC
        LIMIT ?
    """, (limit,))

    rows = cursor.fetchall()
    conn.close()
    return [dict_from_row(r) for r in rows]


def get_platform_stats(platform: str = None) -> dict:
    """Get platform statistics"""
    conn = get_db()
    cursor = conn.cursor()

    if platform:
        cursor.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN is_in_inbox = 1 THEN 1 ELSE 0 END) as inbox,
                SUM(CASE WHEN id IN (SELECT product_id FROM favorites) THEN 1 ELSE 0 END) as favorites
            FROM products
            WHERE platform LIKE ?
        """, (f"%{platform}%",))
    else:
        cursor.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN is_in_inbox = 1 THEN 1 ELSE 0 END) as inbox,
                SUM(CASE WHEN id IN (SELECT product_id FROM favorites) THEN 1 ELSE 0 END) as favorites
            FROM products
        """)

    row = cursor.fetchone()
    conn.close()
    return dict_from_row(row)


def process_message(user_input: str) -> tuple:
    """
    Process user message and generate smart response
    Returns: (agent_name, response_text)
    """
    intent = detect_intent(user_input)
    product_id = extract_product_id(user_input)
    platform = extract_platform(user_input)
    text_lower = user_input.lower()

    # Terim eğitimi komutları (CEO Agent üzerinden)
    if 'terim ekle' in text_lower or 'eğit' in text_lower:
        # Pattern: "terim ekle 'nyskick' = 4" veya "eğit nyskick 4"
        match = re.search(r'["\']?(\w+)["\']?\s*[=:]\s*(\d)', user_input)
        if match:
            term = match.group(1)
            score = int(match.group(2))
            # DB'ye ekle
            try:
                conn = get_db()
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO condition_mapping
                    (language, platform, raw_term, normalized_score, confidence, learned_from, is_verified)
                    VALUES ('auto', 'all', ?, ?, 0.9, 'terminal_training', 1)
                """, (term, score))
                conn.commit()
                cursor.execute("SELECT COUNT(*) FROM condition_mapping")
                total = cursor.fetchone()[0]
                conn.close()
                return "CEOAgent", f"✅ Terim eklendi: \"{term}\" = {score}/5\n📊 Toplam terim: {total}"
            except:
                return "CEOAgent", "❌ Terim eklenemedi."
        return "CEOAgent", "💡 Kullanım: terim ekle \"nyskick\" = 4"

    # Bilinmeyen terimler sorgusu
    if 'bilinmeyen' in text_lower or 'eğitilmemiş' in text_lower or 'hangi terim' in text_lower:
        try:
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT DISTINCT p.condition, COUNT(*) as cnt
                FROM products p
                WHERE p.condition IS NOT NULL AND p.condition != ''
                AND NOT EXISTS (SELECT 1 FROM condition_mapping cm WHERE cm.raw_term = p.condition)
                GROUP BY p.condition ORDER BY cnt DESC LIMIT 5
            """)
            terms = cursor.fetchall()
            conn.close()
            if terms:
                response = "📋 **Bilinmeyen Terimler:**\n"
                for t in terms:
                    response += f"├─ \"{t['condition']}\" ({t['cnt']}x)\n"
                response += "\n💡 Eğitmek için: terim ekle \"terim\" = skor"
                return "CEOAgent", response
            return "CEOAgent", "✅ Tüm terimler eğitilmiş!"
        except:
            return "CEOAgent", "Veri bulunamadı."

    # Status command - KISA
    if intent == 'status':
        response = "📊 **Sistem:** 8 ajan aktif ✅"
        return "CEOAgent", response

    # Help command - KISA
    if intent == 'help':
        response = """📖 **Komutlar:**
/status | /help | /pause | /stop

**Sorular:**
• Favori 1 hakkında bilgi
• En karlı 5 favori
• Kaç platform var?
• Bilinmeyen terimler?
• terim ekle "xyz" = 4"""
        return "CEOAgent", response

    # Product info
    if intent == 'product_info' and product_id:
        product = get_product_info(product_id)
        if product:
            score = product.get('normalized_score', '-')
            profit = product.get('profit_margin', 0) or 0
            profit_amt = product.get('profit_amount', 0) or 0

            response = f"""📦 **Favori #{product_id}** - {product.get('title', 'Bilinmiyor')[:40]}

**Platform:** {product.get('platform', 'unknown')}
**Fiyat:** {product.get('price', 0):.0f}€
**Kar Marji:** +{profit*100:.0f}% ({profit_amt:.0f}€ potansiyel kar)

**Durum:** {score}/5
**Kargo:** {product.get('estimated_shipping_days', '-')} gun
**Tip:** {'🏛️ Vintage' if product.get('product_type') == 'vintage' else '📦 Standart'}
"""
            if product.get('is_conflicting'):
                response += f"\n⚠️ **Uyari:** Catisma tespit edildi - {product.get('conflict_reason', '')}"

            return "CEOAgent", response
        else:
            return "CEOAgent", f"❌ Favori #{product_id} bulunamadi."

    # Recommendation
    if intent == 'recommendation' and product_id:
        product = get_product_info(product_id)
        if product:
            score = product.get('normalized_score', 0) or 0
            profit = product.get('profit_margin', 0) or 0
            ship_days = product.get('estimated_shipping_days', 99) or 99

            reasons = []
            if profit >= 0.4:
                reasons.append(f"├─ Kar marji %{profit*100:.0f} (hedef: %40'in ustu ✓)")
            if score >= 3:
                reasons.append(f"├─ Durum skoru {score}/5 (minimum 3 ✓)")
            if ship_days <= 5:
                reasons.append(f"├─ Kargo {ship_days} gun (maksimum 5 ✓)")

            if len(reasons) >= 2:
                response = f"""✅ **ONERI: ALINMALI**

Sebep:
{chr(10).join(reasons)}

📊 **Tahmini kar:** {product.get('profit_amount', 0) or 0:.0f}€"""
            else:
                response = f"""⚠️ **ONERI: DIKKATLI OLUN**

Bu urun bazi kriterleri karsilamiyor.
Detayli inceleme onerilir."""

            return "FilteringAgent", response
        else:
            return "FilteringAgent", f"❌ Urun bulunamadi."

    # Top profitable
    if intent == 'list':
        products = get_top_profitable(5)
        if products:
            response = "📊 **EN KARLI 5 FAVORI:**\n\n"
            total = 0
            for i, p in enumerate(products, 1):
                profit = (p.get('profit_margin', 0) or 0) * 100
                amount = p.get('profit_amount', 0) or 0
                response += f"{i}. #{p.get('fav_id', '?')} {p.get('title', '')[:25]}... +{profit:.0f}% ({amount:.0f}€) {p.get('platform', '')}\n"
                total += amount
            response += f"\n💡 **Toplam potansiyel:** {total:.0f}€"
            return "CEOAgent", response
        else:
            return "CEOAgent", "Henuz favorilerde kar marji hesaplanmis urun yok."

    # Statistics
    if intent == 'statistics':
        stats = get_platform_stats(platform)
        if platform:
            response = f"""📊 **{platform.upper()} Raporu:**

Toplam kazinmis: {stats.get('total', 0)} urun
├─ Gelen Kutusunda: {stats.get('inbox', 0)}
├─ Favorilerde: {stats.get('favorites', 0)}"""
        else:
            response = f"""📊 **Genel Istatistikler:**

Toplam urun: {stats.get('total', 0)}
├─ Gelen Kutusunda: {stats.get('inbox', 0)}
├─ Favorilerde: {stats.get('favorites', 0)}"""
        return "ScrapingManager", response

    # Agent info
    if intent == 'agent_info':
        for key, agent in AGENTS.items():
            if key.lower() in user_input.lower() or agent['name'].lower() in user_input.lower():
                response = f"""🧠 **{agent['name']}**

**Gorevi:** {agent['description']}

**Ozellikler:**
"""
                for cap in agent['capabilities']:
                    response += f"├─ {cap}\n"
                return "CEOAgent", response

        # General agent list
        response = "🤖 **TATANGA Ajanlari:**\n\n"
        for key, agent in AGENTS.items():
            response += f"├─ **{agent['name']}**: {agent['description'][:50]}...\n"
        return "CEOAgent", response

    # Platform info
    if intent == 'platform_info':
        total = sum(len(p.get('countries', [p])) for p in PLATFORMS.values())
        response = f"""📍 **DESTEKLENEN PLATFORMLAR: {total}**

🟢 **Vinted** (13 ulke):
   DE, FR, UK, ES, IT, NL, BE, PL, CZ, AT, SE, DK, NO

🟢 **eBay** (10 marketplace):
   DE, UK, FR, US, IT, ES, NL, BE, AT, CH

🟢 **Diger** (13):
   Kleinanzeigen, Willhaben, Leboncoin, Tradera,
   Sellpy, Percentil, Shpock"""
        return "CEOAgent", response

    # Scraping intent - Now uses Bridge System
    if intent == 'scraping':
        return "ScrapingManager", "🚀 Kazima islemini baslatmak icin '📥 Gelen Kutusu' sayfasina gidin veya dogal dil komutu yazin:\n\n💡 Örnek: \"ebay+vinted'de nike ayakkabi ara zustand:gut\""

    # Pause
    if intent == 'pause':
        return "ScrapingManager", "⏸️ Duraklama komutu alindi. (Simdilik simule ediliyor)"

    # Greeting - KISA
    if intent == 'greeting':
        return "CEOAgent", "👋 Merhaba! /help ile komutları görün."

    # Try to parse as natural language scraping command
    try:
        from core.command_parser import parse_command, to_dict
        parsed = parse_command(user_input)

        # Arama komutu algılandı - Arama sekmesine yönlendir
        if parsed.action == 'search' and parsed.query and parsed.confidence >= 0.5:
            platforms = ", ".join(parsed.platforms)
            return "CEOAgent", f"""🔍 **Arama komutu algılandı!**

📍 **Platformlar:** {platforms}
🔍 **Arama:** {parsed.query}

👉 Lütfen **🔍 Arama** sekmesine geçin ve kategori bazlı arama yapın."""

    except Exception as e:
        pass  # Fall through to unknown handler

    # Unknown - KISA, sadece dashboard odaklı
    return "CEOAgent", "🤔 Anlamadım. /help yazın veya arama komutu deneyin:\n\n💡 Örnek: \"ebay+vinted'de nike ayakkabi ara\""


# ==================== SIDEBAR ====================

def render_sidebar():
    """Render sidebar with stats and navigation"""
    st.sidebar.title("🎯 TATANGA Triaj Merkezi")
    st.sidebar.markdown("---")

    # Quick stats
    conn = get_db()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT COUNT(*) FROM products WHERE is_in_inbox = 1")
        inbox_count = cursor.fetchone()[0]
    except:
        inbox_count = 0

    try:
        cursor.execute("SELECT COUNT(*) FROM favorites")
        favorites_count = cursor.fetchone()[0]
    except:
        favorites_count = 0

    try:
        cursor.execute("SELECT COUNT(*) FROM condition_mapping")
        trained_count = cursor.fetchone()[0]
    except:
        trained_count = 0

    conn.close()

    # Stats boxes
    st.sidebar.markdown("### 📊 Hizli Istatistikler")
    col1, col2, col3 = st.sidebar.columns(3)
    col1.metric("📥", inbox_count, help="Gelen Kutusu")
    col2.metric("❤️", favorites_count, help="Favoriler")
    col3.metric("🧠", trained_count, help="Egitilmis Terim")

    st.sidebar.markdown("---")
    st.sidebar.markdown("### 📍 SUREC AKISI")

    # Navigation - TATANGA v3.0 (5 Sekme)
    page = st.sidebar.radio(
        "",
        [
            "1️⃣ 🔍 Arama",
            "2️⃣ 📥 Gelen Kutusu",
            "3️⃣ ❤️ Favoriler",
            "4️⃣ 🏪 Magazalar",
            "5️⃣ 🗑️ Silinen Urunler"
        ],
        label_visibility="collapsed"
    )

    st.sidebar.markdown("---")

    # ==================== DAEMON CONTROL PANEL ====================
    with st.sidebar.expander("Stock Monitor Kontrol", expanded=False):
        render_daemon_control_panel()

    st.sidebar.markdown("---")
    st.sidebar.caption("TATANGA Enterprise v2.0")

    return page


def render_daemon_control_panel():
    """Render daemon control panel in sidebar"""
    try:
        # Fetch current status
        status_resp = requests.get(f"{DAEMON_API_URL}/status", timeout=5)
        config_resp = requests.get(f"{DAEMON_API_URL}/config", timeout=5)

        if status_resp.status_code == 200 and config_resp.status_code == 200:
            status = status_resp.json()
            config = config_resp.json()

            # Status indicators
            is_running = config.get('is_running', False)
            status_icon = "🟢" if is_running else "🔴"
            status_text = "Running" if is_running else "Stopped"

            st.markdown(f"**Durum:** {status_icon} {status_text}")

            # Stats in columns
            col1, col2 = st.columns(2)
            col1.metric("Taranan", status.get('products_checked', 0))
            col2.metric("Kaldirilan", status.get('products_removed', 0))

            # Current interval
            current_interval = config.get('check_interval_seconds', 60)
            current_label = [k for k, v in DAEMON_INTERVAL_OPTIONS.items() if v == current_interval]
            current_label = current_label[0] if current_label else "1 dakika (Normal)"

            # Interval selector
            selected = st.selectbox(
                "Kontrol Hizi",
                options=list(DAEMON_INTERVAL_OPTIONS.keys()),
                index=list(DAEMON_INTERVAL_OPTIONS.keys()).index(current_label) if current_label in DAEMON_INTERVAL_OPTIONS else 1,
                key="daemon_interval_select"
            )

            # Action buttons
            col1, col2 = st.columns(2)

            with col1:
                if st.button("Uygula", key="daemon_apply", type="primary", use_container_width=True):
                    new_interval = DAEMON_INTERVAL_OPTIONS[selected]
                    try:
                        resp = requests.post(
                            f"{DAEMON_API_URL}/config",
                            json={"check_interval_seconds": new_interval},
                            timeout=10
                        )
                        if resp.status_code == 200:
                            st.success("Guncellendi!")
                            st.rerun()
                        else:
                            st.error(f"Hata: {resp.text}")
                    except Exception as e:
                        st.error(f"API Hatasi: {e}")

            with col2:
                if st.button("Restart", key="daemon_restart", use_container_width=True):
                    try:
                        resp = requests.post(f"{DAEMON_API_URL}/restart", timeout=30)
                        if resp.status_code == 200:
                            result = resp.json()
                            if result.get('success'):
                                st.success("Yeniden baslatildi!")
                            else:
                                st.error(result.get('message', 'Hata'))
                        else:
                            st.error(f"Hata: {resp.text}")
                    except Exception as e:
                        st.error(f"API Hatasi: {e}")

            # Last check info
            last_check = status.get('last_check')
            if last_check:
                st.caption(f"Son kontrol: {last_check[:19]}")

        else:
            st.warning("API yanitlamiyor")

    except requests.RequestException:
        st.info("Hetzner'a baglanilamiyor")
        st.caption("Daemon henuz deploy edilmemis olabilir")
    except Exception as e:
        st.error(f"Hata: {e}")


# ==================== SEARCH PAGE (KATEGORI BAZLI ARAMA) ====================

def render_search_page():
    """Render category-based search page - TATANGA v3.0"""
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))

    try:
        from category_mapper import (
            CATEGORY_TREE, BRAND_DATABASE, PLATFORM_MAPPING,
            build_search_queries, get_all_categories_flat,
            get_brands_for_category, get_supported_platforms
        )
    except ImportError:
        st.error("category_mapper.py bulunamadi!")
        return

    # CSS for search page
    st.markdown("""
    <style>
    .search-header {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 20px;
        border: 1px solid #0f3460;
    }
    .search-title {
        text-align: center;
        font-size: 1.5rem;
        color: #4ade80;
        font-weight: bold;
    }
    .search-subtitle {
        text-align: center;
        color: #9ca3af;
        font-size: 0.85rem;
    }
    .category-box {
        background: #161b22;
        border: 1px solid #30363d;
        border-radius: 8px;
        padding: 15px;
        margin: 10px 0;
    }
    .platform-mapping {
        background: #0d1117;
        border: 1px solid #21262d;
        border-radius: 8px;
        padding: 12px;
        font-family: monospace;
        font-size: 12px;
        color: #8b949e;
    }
    </style>
    """, unsafe_allow_html=True)

    # Header
    st.markdown('''
    <div class="search-header">
        <div class="search-title">🔍 Kategori Bazli Arama</div>
        <div class="search-subtitle">Platform kategorilerini sec ve insansi arama baslat</div>
    </div>
    ''', unsafe_allow_html=True)

    # ========== LAYOUT: 2 KOLONLU ==========
    col_left, col_right = st.columns([1, 2])

    # ========== SOL KOLON: PLATFORM SECIMI ==========
    with col_left:
        st.subheader("📡 Platform Secimi")

        # Platform grupları
        all_platforms = st.checkbox("✅ TUM PLATFORMLAR", value=False)

        st.markdown("---")

        # Vinted
        vinted_enabled = st.checkbox("👗 Vinted (13 ulke)", value=True, disabled=all_platforms)
        if vinted_enabled or all_platforms:
            vinted_countries = st.multiselect(
                "Vinted Ulkeleri",
                ["de", "fr", "uk", "es", "it", "nl", "be", "pl", "cz", "at", "se", "dk", "pt"],
                default=["de", "fr", "uk"],
                disabled=all_platforms
            )

        # eBay
        ebay_enabled = st.checkbox("🛒 eBay (10 market)", value=True, disabled=all_platforms)
        if ebay_enabled or all_platforms:
            ebay_countries = st.multiselect(
                "eBay Ulkeleri",
                ["de", "uk", "fr", "us", "it", "es", "nl", "be", "at", "ch"],
                default=["de", "uk"],
                disabled=all_platforms
            )

        # Diger platformlar
        kleinanzeigen_enabled = st.checkbox("🏠 Kleinanzeigen", value=True, disabled=all_platforms)
        tradera_enabled = st.checkbox("🇸🇪 Tradera", value=False, disabled=all_platforms)
        sellpy_enabled = st.checkbox("♻️ Sellpy", value=False, disabled=all_platforms)
        percentil_enabled = st.checkbox("👶 Percentil", value=False, disabled=all_platforms)
        willhaben_enabled = st.checkbox("🇦🇹 Willhaben", value=False, disabled=all_platforms)

    # ========== SAG KOLON: KATEGORI SECIMI ==========
    with col_right:
        st.subheader("📁 Kategori Secimi")

        # Ana kategori secimi
        main_categories = {
            "herren": "👔 Herren (Erkek)",
            "damen": "👗 Damen (Kadin)"
        }

        selected_main = st.selectbox(
            "Ana Kategori",
            options=list(main_categories.keys()),
            format_func=lambda x: main_categories[x]
        )

        # Alt kategori secimi (dinamik)
        if selected_main and selected_main in CATEGORY_TREE:
            children = CATEGORY_TREE[selected_main].get("children", {})
            sub_categories = {k: v.get("label", k) for k, v in children.items()}

            selected_sub = st.selectbox(
                "Alt Kategori",
                options=list(sub_categories.keys()),
                format_func=lambda x: sub_categories.get(x, x)
            )

            # Eger alt kategorinin de children'i varsa (3. seviye)
            if selected_sub and selected_sub in children:
                sub_children = children[selected_sub].get("children", {})
                if sub_children:
                    leaf_categories = {k: v.get("label", k) for k, v in sub_children.items()}
                    selected_leaf = st.selectbox(
                        "Detay Kategori",
                        options=[""] + list(leaf_categories.keys()),
                        format_func=lambda x: leaf_categories.get(x, "-- Hepsi --") if x else "-- Hepsi --"
                    )
                    final_category = selected_leaf if selected_leaf else selected_sub
                else:
                    final_category = selected_sub
            else:
                final_category = selected_sub
        else:
            final_category = None
            selected_sub = None

        st.markdown("---")

        # Marka secimi
        st.subheader("🏷️ Marka (Opsiyonel)")

        # Kategoriye gore markalar
        brand_options = []
        for brand_key, brand_data in BRAND_DATABASE.items():
            if final_category:
                # Kategori affinite kontrolu
                affinity = brand_data.get("category_affinity", [])
                if any(final_category in cat or cat in final_category for cat in affinity):
                    brand_options.append((brand_key, brand_data["name"]))
            else:
                brand_options.append((brand_key, brand_data["name"]))

        selected_brands = st.multiselect(
            "Markalar",
            options=[b[0] for b in brand_options],
            format_func=lambda x: next((b[1] for b in brand_options if b[0] == x), x),
            help="Bos birakirsaniz tum markalar aranir"
        )

        st.markdown("---")

        # Fiyat araligi
        st.subheader("💰 Fiyat Araligi")
        price_col1, price_col2 = st.columns(2)
        with price_col1:
            min_price = st.number_input("Min (€)", min_value=0, value=5)
        with price_col2:
            max_price = st.number_input("Max (€)", min_value=0, value=100)

        # Durum filtresi
        condition = st.selectbox(
            "📊 Durum",
            ["Hepsi", "Neu mit Etikett", "Neu ohne Etikett", "Sehr gut", "Gut"],
            index=0
        )

    # ========== PLATFORM-KATEGORI ESLEME ONIZLEME ==========
    st.markdown("---")

    with st.expander("📋 Platform-Kategori Eslemesi", expanded=True):
        if final_category and final_category in PLATFORM_MAPPING:
            mapping = PLATFORM_MAPPING[final_category]
            mapping_text = ""
            for platform, config in mapping.items():
                if "category_id" in config:
                    mapping_text += f"**{platform}** → category_id: `{config['category_id']}`\n\n"
                elif "catalog_id" in config:
                    mapping_text += f"**{platform}** → catalog: `{config['catalog_id']}`, subcatalog: `{config.get('subcatalog_id', '-')}`\n\n"
                elif "category_path" in config:
                    mapping_text += f"**{platform}** → path: `{config['category_path']}`\n\n"
            st.markdown(mapping_text if mapping_text else "Bu kategori icin esleme bulunamadi.")
        else:
            st.info("Kategori secin ve platform eslemelerini gorun.")

    # ========== ARAMA BUTONU ==========
    st.markdown("---")

    # Secilen platformlari hesapla
    selected_platforms = []
    if vinted_enabled or all_platforms:
        for country in (vinted_countries if not all_platforms else ["de", "fr", "uk", "es", "it", "nl", "be", "pl", "cz", "at", "se", "dk", "pt"]):
            selected_platforms.append(f"vinted.{country}")
    if ebay_enabled or all_platforms:
        for country in (ebay_countries if not all_platforms else ["de", "uk", "fr", "us", "it", "es", "nl", "be", "at", "ch"]):
            selected_platforms.append(f"ebay.{country}")
    if kleinanzeigen_enabled or all_platforms:
        selected_platforms.append("kleinanzeigen")
    if tradera_enabled or all_platforms:
        selected_platforms.append("tradera")
    if sellpy_enabled or all_platforms:
        selected_platforms.append("sellpy")
    if percentil_enabled or all_platforms:
        selected_platforms.append("percentil")
    if willhaben_enabled or all_platforms:
        selected_platforms.append("willhaben")

    platform_count = len(selected_platforms)

    col_btn1, col_btn2, col_btn3 = st.columns([1, 2, 1])
    with col_btn2:
        if st.button(f"🚀 ARAMAYI BASLAT ({platform_count} platform)", use_container_width=True, type="primary"):
            if not final_category:
                st.error("Lutfen bir kategori secin!")
            else:
                st.success(f"✅ Arama baslatiliyor: {final_category}")
                st.info(f"📍 Platformlar: {', '.join(selected_platforms[:5])}{'...' if len(selected_platforms) > 5 else ''}")

                # Arama sorgularini olustur
                brand_names = [BRAND_DATABASE[b]["name"] for b in selected_brands] if selected_brands else [""]

                # Platform isimlerini PLATFORM_MAPPING'deki anahtarlarla esle
                mapping_keys = list(PLATFORM_MAPPING.get(final_category, {}).keys())

                # Secilen platformlari mapping anahtarlarina donustur
                matched_platforms = []
                for p in selected_platforms:
                    # Direkt esleme (kleinanzeigen, sellpy, vb.)
                    if p in mapping_keys:
                        matched_platforms.append(p)
                    # Domain ile esleme (vinted.de -> vinted.de)
                    elif '.' in p:
                        if p in mapping_keys:
                            matched_platforms.append(p)
                        base = p.split('.')[0]
                        for key in mapping_keys:
                            if key.startswith(base):
                                if key not in matched_platforms:
                                    matched_platforms.append(key)

                queries = build_search_queries(
                    category=final_category,
                    brands=brand_names,
                    platforms=matched_platforms
                )

                # Sonuclari goster
                st.markdown("### 🔗 Olusturulan Arama URL'leri")
                for platform, platform_queries in queries.items():
                    st.markdown(f"**{platform}:**")
                    for q in platform_queries[:3]:
                        st.markdown(f"- [{q.query}]({q.url})")

                st.info(f"📋 {len(queries)} platform icin arama URL'leri olusturuldu")

                # ========== SCRAPING ISLEMINI BASLAT ==========
                st.markdown("---")
                st.markdown("### 🔄 Kazima Islemi")

                batch_id = f"search_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                all_results = []
                total_saved = 0

                progress_bar = st.progress(0)
                status_text = st.empty()
                results_container = st.container()

                conn = get_db()
                cursor = conn.cursor()

                platform_count = len(queries)
                current_platform = 0

                for platform, platform_queries in queries.items():
                    current_platform += 1
                    progress = int((current_platform / platform_count) * 100)
                    progress_bar.progress(progress)

                    # Her platform icin ilk sorguyu kullan (marka)
                    if not platform_queries:
                        continue

                    query_obj = platform_queries[0]
                    query_text = query_obj.query
                    search_url = query_obj.url

                    status_text.text(f"🔄 {platform} taraniyor: {query_text}...")

                    try:
                        results = []

                        # Platform bazli scraper sec
                        if 'vinted' in platform:
                            if VINTED_V2_AVAILABLE:
                                scraper = VintedV2Scraper(headless=True, fast_mode=True)
                                # URL'den ulke kodunu cikar
                                country = platform.split('.')[-1] if '.' in platform else 'de'
                                results = scraper.scrape_vinted(
                                    query=query_text,
                                    country=country,
                                    max_pages=3,
                                    visit_random_products=False
                                )
                                scraper.close()

                        elif 'ebay' in platform:
                            if EBAY_V2_AVAILABLE:
                                scraper = EbayDeV2Scraper(headless=True)
                                results = scraper.scrape_ebay(query=query_text, max_pages=2)
                                scraper.close()
                            elif EBAY_API_AVAILABLE:
                                connector = EbayConnector()
                                results = connector.search_products(query=query_text, limit=50)

                        elif 'kleinanzeigen' in platform:
                            if KLEINANZEIGEN_V2_AVAILABLE:
                                scraper = KleinanzeigenV2Scraper(headless=True, fast_mode=True)
                                results = scraper.scrape_kleinanzeigen(
                                    query=query_text,
                                    max_pages=3,
                                    visit_random_products=False
                                )
                                scraper.close()

                        elif 'sellpy' in platform:
                            if SELLPY_AVAILABLE:
                                connector = SellpyConnector()
                                results = connector.search_products(query=query_text, max_results=50)
                                try:
                                    connector.close()
                                except:
                                    pass

                        elif 'percentil' in platform:
                            if PERCENTIL_AVAILABLE:
                                connector = PercentilConnector()
                                results = connector.search_products(query=query_text, max_results=50)
                                try:
                                    connector.close()
                                except:
                                    pass

                        elif 'tradera' in platform:
                            if TRADERA_AVAILABLE:
                                connector = TraderaConnector()
                                results = connector.search_products(query=query_text, max_results=50)
                                try:
                                    connector.close()
                                except:
                                    pass

                        # Sonuclari veritabanina kaydet
                        saved_count = 0
                        for item in results:
                            price = item.get('price_value', item.get('price', 0))
                            if isinstance(price, str):
                                try:
                                    price = float(price.replace(',', '.').replace('€', '').replace('EUR', '').replace('SEK', '').replace('kr', '').strip())
                                except:
                                    price = 0

                            # Fiyat filtresi
                            if min_price <= price <= max_price:
                                try:
                                    cursor.execute("""
                                        INSERT OR IGNORE INTO products
                                        (title, url, price, currency, platform, images, condition, batch_id, is_in_inbox, scraped_at, category, brand)
                                        VALUES (?, ?, ?, 'EUR', ?, ?, ?, ?, 1, ?, ?, ?)
                                    """, (
                                        item.get('title', ''),
                                        item.get('url', item.get('itemWebUrl', '')),
                                        price,
                                        platform,
                                        json.dumps([item.get('image', item.get('thumbnail', ''))]),
                                        item.get('condition', ''),
                                        batch_id,
                                        datetime.now().isoformat(),
                                        final_category,
                                        query_text
                                    ))
                                    if cursor.rowcount > 0:
                                        saved_count += 1
                                        all_results.append(item)
                                except Exception as e:
                                    pass

                        conn.commit()
                        total_saved += saved_count

                        with results_container:
                            if results:
                                st.success(f"✅ {platform}: {len(results)} urun bulundu, {saved_count} kaydedildi")
                            else:
                                st.warning(f"⚠️ {platform}: Urun bulunamadi")

                    except Exception as e:
                        with results_container:
                            st.error(f"❌ {platform} hatasi: {str(e)[:100]}")

                progress_bar.progress(100)
                status_text.text("✅ Kazima tamamlandi!")

                conn.close()

                # Ozet
                st.markdown("---")
                st.markdown("### 📊 Kazima Ozeti")
                col_s1, col_s2, col_s3 = st.columns(3)
                col_s1.metric("🔍 Taranan Platform", platform_count)
                col_s2.metric("📦 Toplam Urun", len(all_results))
                col_s3.metric("💾 Kaydedilen", total_saved)

                if total_saved > 0:
                    st.success(f"🎉 {total_saved} urun Gelen Kutusu'na eklendi! Batch: {batch_id}")
                    st.info("📥 Gelen Kutusu sekmesine giderek urunleri inceleyebilirsiniz.")


# ==================== SCRAPING PAGE ====================

def render_scraping_page():
    """Render scraping starter page"""
    st.title("🚀 Kazima Baslat")
    st.markdown("*Tek butonla tum platformlarda arama*")

    # Platform selection
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("📍 Platform Gruplari")

        all_platforms = st.checkbox("✅ TUM PLATFORMLAR (36)", value=True)
        st.markdown("---")

        vinted_enabled = st.checkbox("👗 Vinted (13 ulke)", value=True, disabled=all_platforms)
        if vinted_enabled or all_platforms:
            vinted_countries = st.multiselect(
                "Vinted Ulkeleri",
                ["de", "fr", "uk", "es", "it", "nl", "be", "pl", "cz", "at", "se", "dk", "no"],
                default=["de", "fr", "uk", "es", "it"] if not all_platforms else ["de", "fr", "uk", "es", "it", "nl", "be", "pl", "cz", "at", "se", "dk", "no"],
                disabled=all_platforms
            )

        ebay_enabled = st.checkbox("🛒 eBay (10 marketplace)", value=True, disabled=all_platforms)
        if ebay_enabled or all_platforms:
            ebay_countries = st.multiselect(
                "eBay Ulkeleri",
                ["de", "uk", "fr", "us", "it", "es", "nl", "be", "at", "ch"],
                default=["de", "uk", "fr"] if not all_platforms else ["de", "uk", "fr", "us", "it", "es", "nl", "be", "at", "ch"],
                disabled=all_platforms
            )

        kleinanzeigen_enabled = st.checkbox("🏠 Kleinanzeigen (Almanya)", value=True, disabled=all_platforms)

        tradera_enabled = st.checkbox("🇸🇪 Tradera (İsveç)", value=False, disabled=all_platforms)
        sellpy_enabled = st.checkbox("♻️ Sellpy (İkinci El)", value=False, disabled=all_platforms)
        percentil_enabled = st.checkbox("👶 Percentil (Çocuk/Yetişkin)", value=False, disabled=all_platforms)

        other_enabled = st.checkbox("📋 Diger Platformlar (9)", value=False, disabled=all_platforms)

    with col2:
        st.subheader("🔍 Arama Ayarlari")

        query = st.text_input("Urun Adi", "Levi's 501", help="Aranacak urun")

        # Fiyat filtreleri (min/max)
        st.markdown("**Fiyat Araligi (€)**")
        price_col1, price_col2 = st.columns(2)
        with price_col1:
            min_price = st.number_input("Min", min_value=0, value=5, help="Minimum fiyat")
        with price_col2:
            max_price = st.number_input("Max", min_value=0, value=100, help="Maksimum fiyat")

        min_score = st.slider("Minimum Durum Skoru", 1, 5, 3, help="1=Kotu, 5=Yeni")

        st.markdown("---")

        st.subheader("⚙️ Kazıma Modu")

        # Paralel/Sirali secimi - daha açıklayıcı
        scrape_mode = st.radio(
            "Mod Seçin",
            ["🚀 Paralel - Hızlı (2dk), riskli (ban olabilir)",
             "🔄 Sıralı - Yavaş (2saat), güvenli (ban yok)"],
            horizontal=False
        )

        # Mod açıklaması
        if "Paralel" in scrape_mode:
            st.caption("⚡ 36 platform AYNI ANDA taranır. Hızlı ama platformlar sizi engelleyebilir.")
            rate_limit = 0
        else:
            st.caption("🛡️ Platformlar SIRAYLA taranır. Yavaş ama güvenli.")
            rate_limit = st.slider("Platformlar Arası Bekleme (saniye)", 1, 10, 3)

    st.markdown("---")

    # Summary
    if all_platforms:
        total_platforms = 39  # 36 + 3 yeni platform
    else:
        total_platforms = (len(vinted_countries) if vinted_enabled else 0) + \
                         (len(ebay_countries) if ebay_enabled else 0) + \
                         (1 if kleinanzeigen_enabled else 0) + \
                         (1 if tradera_enabled else 0) + \
                         (1 if sellpy_enabled else 0) + \
                         (1 if percentil_enabled else 0) + \
                         (9 if other_enabled else 0)

    mode_text = "Paralel" if "Paralel" in scrape_mode else f"Sirali ({rate_limit}s bekleme)"
    st.info(f"📊 **Taranacak:** {total_platforms} platform | **Arama:** \"{query}\" | **Fiyat:** {min_price}-{max_price}€ | **Mod:** {mode_text}")

    # V2 Scraper durumunu göster
    v2_status = []
    if VINTED_V2_AVAILABLE:
        v2_status.append("✅ Vinted V2")
    else:
        v2_status.append("❌ Vinted V2")
    if KLEINANZEIGEN_V2_AVAILABLE:
        v2_status.append("✅ Kleinanzeigen V2")
    else:
        v2_status.append("❌ Kleinanzeigen V2")
    if EBAY_V2_AVAILABLE:
        v2_status.append("✅ eBay V2")
    else:
        v2_status.append("❌ eBay V2")
    if TRADERA_AVAILABLE:
        v2_status.append("✅ Tradera")
    else:
        v2_status.append("❌ Tradera")
    if SELLPY_AVAILABLE:
        v2_status.append("✅ Sellpy")
    else:
        v2_status.append("❌ Sellpy")
    if PERCENTIL_AVAILABLE:
        v2_status.append("✅ Percentil")
    else:
        v2_status.append("❌ Percentil")

    st.caption(f"V2 Scraperlar: {' | '.join(v2_status)}")

    # Start button - Doğrudan V2 Scraper kullan
    if st.button("🚀 KAZIMA BASLAT", type="primary", use_container_width=True):
        batch_id = f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        all_results = []

        # Progress bar
        progress_bar = st.progress(0)
        status_text = st.empty()

        conn = get_db()
        cursor = conn.cursor()

        # Vinted DE kazıma - fast_mode ile daha hızlı
        if VINTED_V2_AVAILABLE and (all_platforms or vinted_enabled):
            status_text.text("🔄 Vinted DE taranıyor (fast mode)...")
            try:
                scraper = VintedV2Scraper(headless=True, fast_mode=True)
                results = scraper.scrape_vinted(query=query, max_pages=5, visit_random_products=False)
                scraper.close()

                for item in results:
                    # Fiyat filtresi
                    price = item.get('price_value', item.get('price', 0))
                    if isinstance(price, str):
                        try:
                            price = float(price.replace(',', '.').replace('€', '').strip())
                        except:
                            price = 0

                    if min_price <= price <= max_price:
                        # Veritabanına kaydet
                        cursor.execute("""
                            INSERT OR IGNORE INTO products
                            (title, url, price, currency, platform, images, condition, batch_id, is_in_inbox, scraped_at)
                            VALUES (?, ?, ?, 'EUR', 'vinted_de', ?, ?, ?, 1, ?)
                        """, (
                            item.get('title', ''),
                            item.get('url', ''),
                            price,
                            json.dumps([item.get('image', '')]),
                            item.get('condition', ''),
                            batch_id,
                            datetime.now().isoformat()
                        ))
                        all_results.append(item)

                conn.commit()
                st.success(f"✅ Vinted DE: {len(results)} ürün bulundu, {len([r for r in results if min_price <= (r.get('price_value', 0) or 0) <= max_price])} kaydedildi")
            except Exception as e:
                st.error(f"❌ Vinted hatası: {e}")

        progress_bar.progress(33)

        # Kleinanzeigen kazıma - fast_mode ile daha hızlı
        if KLEINANZEIGEN_V2_AVAILABLE and (all_platforms or kleinanzeigen_enabled):
            status_text.text("🔄 Kleinanzeigen taranıyor (fast mode)...")
            try:
                scraper = KleinanzeigenV2Scraper(headless=True, fast_mode=True)
                results = scraper.scrape_kleinanzeigen(query=query, max_pages=5, visit_random_products=False)
                scraper.close()

                for item in results:
                    price = item.get('price_value', 0) or 0
                    if min_price <= price <= max_price:
                        cursor.execute("""
                            INSERT OR IGNORE INTO products
                            (title, url, price, currency, platform, images, location, batch_id, is_in_inbox, scraped_at)
                            VALUES (?, ?, ?, 'EUR', 'kleinanzeigen', ?, ?, ?, 1, ?)
                        """, (
                            item.get('title', ''),
                            item.get('url', ''),
                            price,
                            json.dumps([item.get('image', '')]),
                            item.get('location', ''),
                            batch_id,
                            datetime.now().isoformat()
                        ))
                        all_results.append(item)

                conn.commit()
                st.success(f"✅ Kleinanzeigen: {len(results)} ürün bulundu")
            except Exception as e:
                st.error(f"❌ Kleinanzeigen hatası: {e}")

        progress_bar.progress(66)

        # eBay DE kazıma - API tercih edilir (daha hızlı)
        if (EBAY_API_AVAILABLE or EBAY_V2_AVAILABLE) and (all_platforms or ebay_enabled):
            status_text.text("🔄 eBay DE taranıyor...")
            try:
                results = []

                # API varsa onu kullan (çok daha hızlı)
                if EBAY_API_AVAILABLE:
                    connector = EbayConnector()
                    results = connector.search_products(query=query, limit=100)
                    status_text.text("🚀 eBay API kullanıldı (hızlı)")
                # API yoksa V2 Selenium scraper kullan
                elif EBAY_V2_AVAILABLE:
                    scraper = EbayDeV2Scraper(headless=True)
                    results = scraper.scrape_ebay(query=query, max_pages=2)
                    scraper.close()

                for item in results:
                    price = item.get('price_value', 0) or item.get('price', 0) or 0
                    if isinstance(price, str):
                        price = float(price.replace(',', '.').replace('€', '').replace('EUR', '').strip() or 0)
                    if min_price <= price <= max_price:
                        cursor.execute("""
                            INSERT OR IGNORE INTO products
                            (title, url, price, currency, platform, images, condition, batch_id, is_in_inbox, scraped_at)
                            VALUES (?, ?, ?, 'EUR', 'ebay_de', ?, ?, ?, 1, ?)
                        """, (
                            item.get('title', ''),
                            item.get('url', item.get('itemWebUrl', '')),
                            price,
                            json.dumps([item.get('image', item.get('thumbnailImages', [{}])[0].get('imageUrl', '') if item.get('thumbnailImages') else '')]),
                            item.get('condition', item.get('conditionId', '')),
                            batch_id,
                            datetime.now().isoformat()
                        ))
                        all_results.append(item)

                conn.commit()
                api_type = "API" if EBAY_API_AVAILABLE else "Selenium"
                st.success(f"✅ eBay DE ({api_type}): {len(results)} ürün bulundu")
            except Exception as e:
                st.error(f"❌ eBay hatası: {e}")

        # Tradera kazıma (İsveç)
        if TRADERA_AVAILABLE and (all_platforms or tradera_enabled):
            status_text.text("🔄 Tradera taranıyor...")
            try:
                connector = TraderaConnector()
                results = connector.search_products(query=query, max_results=50)
                for item in results:
                    price = item.get('price', 0) or 0
                    if isinstance(price, str):
                        price = float(price.replace(',', '.').replace('kr', '').replace('SEK', '').strip() or 0)
                    if min_price <= price <= max_price:
                        cursor.execute("""
                            INSERT OR IGNORE INTO products
                            (title, url, price, currency, platform, images, location, batch_id, is_in_inbox, scraped_at)
                            VALUES (?, ?, ?, 'SEK', 'tradera', ?, ?, ?, 1, ?)
                        """, (item.get('title'), item.get('url'), price,
                              json.dumps([item.get('image', '')]), 'Sweden',
                              batch_id, datetime.now().isoformat()))
                        all_results.append(item)
                conn.commit()
                st.success(f"✅ Tradera: {len(results)} ürün bulundu")
                try:
                    connector.close()
                except:
                    pass
            except Exception as e:
                st.error(f"❌ Tradera hatası: {e}")

        # Sellpy kazıma (İkinci El)
        if SELLPY_AVAILABLE and (all_platforms or sellpy_enabled):
            status_text.text("🔄 Sellpy taranıyor...")
            try:
                connector = SellpyConnector()
                results = connector.search_products(query=query, max_results=50)
                for item in results:
                    price = item.get('price', 0) or 0
                    if isinstance(price, str):
                        price = float(price.replace(',', '.').replace('€', '').replace('EUR', '').strip() or 0)
                    if min_price <= price <= max_price:
                        cursor.execute("""
                            INSERT OR IGNORE INTO products
                            (title, url, price, currency, platform, images, location, batch_id, is_in_inbox, scraped_at)
                            VALUES (?, ?, ?, 'EUR', 'sellpy', ?, ?, ?, 1, ?)
                        """, (item.get('title'), item.get('url'), price,
                              json.dumps([item.get('image', '')]), item.get('location', ''),
                              batch_id, datetime.now().isoformat()))
                        all_results.append(item)
                conn.commit()
                st.success(f"✅ Sellpy: {len(results)} ürün bulundu")
                try:
                    connector.close()
                except:
                    pass
            except Exception as e:
                st.error(f"❌ Sellpy hatası: {e}")

        # Percentil kazıma (Çocuk/Yetişkin Moda)
        if PERCENTIL_AVAILABLE and (all_platforms or percentil_enabled):
            status_text.text("🔄 Percentil taranıyor...")
            try:
                connector = PercentilConnector()
                results = connector.search_products(query=query, max_results=50)
                for item in results:
                    price = item.get('price', 0) or 0
                    if isinstance(price, str):
                        price = float(price.replace(',', '.').replace('€', '').replace('EUR', '').strip() or 0)
                    if min_price <= price <= max_price:
                        cursor.execute("""
                            INSERT OR IGNORE INTO products
                            (title, url, price, currency, platform, images, location, batch_id, is_in_inbox, scraped_at)
                            VALUES (?, ?, ?, 'EUR', 'percentil', ?, ?, ?, 1, ?)
                        """, (item.get('title'), item.get('url'), price,
                              json.dumps([item.get('image', '')]), item.get('location', ''),
                              batch_id, datetime.now().isoformat()))
                        all_results.append(item)
                conn.commit()
                st.success(f"✅ Percentil: {len(results)} ürün bulundu")
                try:
                    connector.close()
                except:
                    pass
            except Exception as e:
                st.error(f"❌ Percentil hatası: {e}")

        progress_bar.progress(100)
        status_text.text("✅ Kazıma tamamlandı!")

        conn.close()

        # Özet
        st.success(f"""
        🎉 **Kazıma Tamamlandı!**

        - **Batch ID:** {batch_id}
        - **Toplam:** {len(all_results)} ürün
        - **Arama:** "{query}"

        📥 Gelen Kutusu'ndan ürünleri inceleyin.
        """)

    # Active jobs from API
    st.markdown("---")
    st.subheader("📦 Aktif İşler")

    try:
        response = requests.get(f"{API_URL}/api/scrape/jobs", timeout=5)
        if response.status_code == 200:
            data = response.json()
            jobs = data.get('jobs', [])

            if jobs:
                for job in jobs:
                    status_icon = "🟢" if job['status'] == 'running' else "🟡" if job['status'] == 'started' else "🔴"
                    with st.expander(f"{status_icon} {job['batch_id']} - {job['query']}"):
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Durum", job['status'])
                        with col2:
                            st.metric("İlerleme", f"{job['progress']}%")
                        with col3:
                            st.metric("Bulunan", job['products_found'])

                        st.caption(f"Job ID: {job['job_id']} | Başlangıç: {job['started_at']}")

                        if job['status'] not in ['completed', 'stopped']:
                            if st.button("🛑 Durdur", key=f"stop_{job['job_id']}"):
                                requests.post(f"{API_URL}/api/scrape/stop/{job['job_id']}")
                                st.rerun()
            else:
                st.info("Aktif iş yok. Yukarıdan kazıma başlatın.")
        else:
            st.warning("API'den iş listesi alınamadı.")
    except requests.exceptions.ConnectionError:
        st.warning("⚠️ API çalışmıyor. İşleri görmek için API'yi başlatın.")
    except Exception as e:
        st.info("Henüz aktif iş yok.")

    # Database batches (fallback)
    st.markdown("---")
    st.subheader("📊 Veritabanı Partileri")

    conn = get_db()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            SELECT
                batch_id,
                COUNT(*) as total,
                SUM(CASE WHEN is_in_inbox = 1 THEN 1 ELSE 0 END) as inbox,
                MIN(scraped_at) as started,
                MAX(scraped_at) as updated
            FROM products
            WHERE batch_id IS NOT NULL
            GROUP BY batch_id
            ORDER BY MAX(scraped_at) DESC
            LIMIT 5
        """)
        batches = cursor.fetchall()

        if batches:
            for batch in batches:
                with st.expander(f"📦 {batch['batch_id']} ({batch['total']} ürün)"):
                    st.markdown(f"""
- **Toplam:** {batch['total']} ürün
- **Gelen Kutusu:** {batch['inbox']} ürün
- **Başlangıç:** {batch['started']}
- **Son Güncelleme:** {batch['updated']}
""")
        else:
            st.info("Veritabanında parti yok.")
    except:
        st.info("Veritabanında parti yok.")

    conn.close()


# ==================== INBOX PAGE ====================

def render_inbox_page():
    """Render inbox (triage) page with grid product cards"""
    st.title("📥 Gelen Kutusu (Triaj)")
    st.markdown("*Kazinmis urunleri ayiklayin - Begen veya Sil*")

    # Session state for liked products (shows red heart before moving to favorites)
    if 'liked_products' not in st.session_state:
        st.session_state.liked_products = set()

    # Custom CSS for product cards
    st.markdown("""
    <style>
    .product-card {
        border: 1px solid #e0e0e0;
        border-radius: 12px;
        padding: 12px;
        margin: 8px 0;
        background: white;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        transition: all 0.2s ease;
    }
    .product-card:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        transform: translateY(-2px);
    }
    .product-image {
        width: 100%;
        height: 180px;
        object-fit: cover;
        border-radius: 8px;
        background: #f5f5f5;
    }
    .product-title {
        font-weight: 600;
        font-size: 14px;
        margin: 8px 0 4px 0;
        color: #333;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .product-price {
        font-size: 18px;
        font-weight: 700;
        color: #e53935;
        margin: 4px 0;
    }
    .product-platform {
        font-size: 11px;
        color: #666;
        background: #f0f0f0;
        padding: 2px 8px;
        border-radius: 10px;
        display: inline-block;
    }
    .product-kunye {
        font-size: 10px;
        color: #555;
        background: #f8f9fa;
        padding: 6px 8px;
        border-radius: 6px;
        margin-top: 6px;
        border-left: 3px solid #4CAF50;
    }
    .kunye-row {
        display: flex;
        justify-content: space-between;
        margin: 2px 0;
    }
    .kunye-label {
        color: #888;
    }
    .kunye-value {
        font-weight: 600;
        color: #333;
    }
    .condition-badge {
        display: inline-block;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 10px;
        font-weight: 600;
    }
    .condition-5 { background: #4CAF50; color: white; }
    .condition-4 { background: #8BC34A; color: white; }
    .condition-3 { background: #FFC107; color: #333; }
    .condition-2 { background: #FF9800; color: white; }
    .condition-1 { background: #f44336; color: white; }
    .card-actions {
        display: flex;
        gap: 8px;
        margin-top: 8px;
    }
    .btn-like {
        background: #4CAF50;
        color: white;
        border: none;
        padding: 6px 12px;
        border-radius: 6px;
        cursor: pointer;
        flex: 1;
    }
    .btn-delete {
        background: #f44336;
        color: white;
        border: none;
        padding: 6px 12px;
        border-radius: 6px;
        cursor: pointer;
        flex: 1;
    }
    .btn-link {
        background: #2196F3;
        color: white;
        border: none;
        padding: 6px 12px;
        border-radius: 6px;
        cursor: pointer;
        text-decoration: none;
        flex: 1;
        text-align: center;
    }
    </style>
    """, unsafe_allow_html=True)

    conn = get_db()
    cursor = conn.cursor()

    # Batch selection
    try:
        cursor.execute("""
            SELECT batch_id, COUNT(*) as count
            FROM products
            WHERE batch_id IS NOT NULL AND is_in_inbox = 1
            GROUP BY batch_id
            ORDER BY MAX(scraped_at) DESC
        """)
        batches = cursor.fetchall()
    except:
        batches = []

    col1, col2, col3 = st.columns([2, 1, 1])

    with col1:
        batch_options = ["Tum Partiler"] + [f"{b['batch_id']} ({b['count']} urun)" for b in batches]
        selected_batch_display = st.selectbox("📦 Parti Secin", batch_options)

        selected_batch = None
        if selected_batch_display != "Tum Partiler":
            selected_batch = selected_batch_display.split(" (")[0]

    with col2:
        view_mode = st.radio("Gorunum", ["Izgara", "Liste"], horizontal=True)

    with col3:
        if selected_batch:
            if st.button("🗑️ Partiyi Temizle", type="secondary"):
                cursor.execute("""
                    DELETE FROM products
                    WHERE batch_id = ? AND is_in_inbox = 1
                    AND id NOT IN (SELECT product_id FROM favorites)
                """, (selected_batch,))
                conn.commit()
                st.success(f"{cursor.rowcount} urun silindi!")
                st.rerun()

    # Platform filter and sorting - always visible
    filter_col1, filter_col2 = st.columns(2)
    with filter_col1:
        platform_filter = st.selectbox(
            "🌐 Platform",
            ["Tumu", "vinted_de", "ebay_de", "kleinanzeigen"],
            index=0,
            help="Platforma gore filtrele"
        )
    with filter_col2:
        sort_option = st.selectbox(
            "🔄 Siralama",
            ["Tarih (Yeni)", "Tarih (Eski)", "Fiyat (Dusuk)", "Fiyat (Yuksek)"],
            index=0,
            help="Sirala"
        )

    # Sayfalama session state
    if 'inbox_page' not in st.session_state:
        st.session_state.inbox_page = 1

    # Sayfa başına ürün ve sayfalama
    page_col1, page_col2 = st.columns([3, 1])
    with page_col1:
        pass  # Boş bırak
    with page_col2:
        per_page = st.selectbox("Sayfa başına", [24, 48, 96, 200], index=1, help="Sayfada gösterilecek ürün sayısı")

    # Compact filters
    with st.expander("🔍 Diger Filtreler", expanded=False):
        col1, col2, col3, col4, col5 = st.columns(5)
        with col1:
            min_score = st.selectbox("Min Skor", [None, 1, 2, 3, 4, 5], index=0)
        with col2:
            max_shipping = st.selectbox("Max Kargo", [None, 2, 3, 5, 7], index=0)
        with col3:
            product_type = st.selectbox("Tip", [None, "standard", "vintage"], index=0)
        with col4:
            min_price = st.number_input("Min €", min_value=0, value=0)
        with col5:
            max_price = st.number_input("Max €", min_value=0, value=0)

    # Build query
    query = """
        SELECT
            p.*,
            ps.normalized_score,
            ps.is_conflicting,
            ps.profit_amount,
            ps.profit_margin
        FROM products p
        LEFT JOIN product_scores ps ON p.id = ps.product_id
        WHERE p.is_in_inbox = 1
    """
    params = []

    if selected_batch:
        query += " AND p.batch_id = ?"
        params.append(selected_batch)
    if min_score:
        query += " AND ps.normalized_score >= ?"
        params.append(min_score)
    if max_shipping:
        query += " AND p.estimated_shipping_days <= ?"
        params.append(max_shipping)
    if product_type:
        query += " AND p.product_type = ?"
        params.append(product_type)
    if min_price > 0:
        query += " AND p.price >= ?"
        params.append(min_price)
    if max_price > 0:
        query += " AND p.price <= ?"
        params.append(max_price)

    # Platform filter
    if platform_filter and platform_filter != "Tumu":
        query += " AND p.platform = ?"
        params.append(platform_filter)

    # Sorting
    sort_mapping = {
        "Tarih (Yeni)": "p.scraped_at DESC",
        "Tarih (Eski)": "p.scraped_at ASC",
        "Fiyat (Dusuk)": "p.price ASC",
        "Fiyat (Yuksek)": "p.price DESC"
    }
    order_by = sort_mapping.get(sort_option, "p.scraped_at DESC")

    # Önce toplam sayıyı al (filtreli)
    count_query = query.replace("SELECT\n            p.*,\n            ps.normalized_score,\n            ps.is_conflicting,\n            ps.profit_amount,\n            ps.profit_margin", "SELECT COUNT(*)")
    try:
        cursor.execute(count_query, params)
        total_filtered = cursor.fetchone()[0]
    except:
        total_filtered = 0

    # Toplam sayfa sayısı
    total_pages = max(1, (total_filtered + per_page - 1) // per_page)

    # Sayfa sınırlarını kontrol et
    if st.session_state.inbox_page > total_pages:
        st.session_state.inbox_page = total_pages
    if st.session_state.inbox_page < 1:
        st.session_state.inbox_page = 1

    current_page = st.session_state.inbox_page
    offset = (current_page - 1) * per_page

    # Sayfalama ile sorgu
    query += f" ORDER BY {order_by} LIMIT {per_page} OFFSET {offset}"

    try:
        cursor.execute(query, params)
        products = [dict_from_row(row) for row in cursor.fetchall()]
    except:
        products = []

    # Count total (tüm inbox)
    try:
        cursor.execute("SELECT COUNT(*) FROM products WHERE is_in_inbox = 1")
        total_count = cursor.fetchone()[0]
    except:
        total_count = 0

    # Sayfalama kontrolleri
    st.markdown("---")
    pag_col1, pag_col2, pag_col3, pag_col4, pag_col5 = st.columns([1, 1, 2, 1, 1])

    with pag_col1:
        if st.button("⏮️ İlk", disabled=(current_page == 1), use_container_width=True):
            st.session_state.inbox_page = 1
            st.rerun()

    with pag_col2:
        if st.button("◀️ Önceki", disabled=(current_page == 1), use_container_width=True):
            st.session_state.inbox_page -= 1
            st.rerun()

    with pag_col3:
        start_item = offset + 1
        end_item = min(offset + per_page, total_filtered)
        st.markdown(f"<div style='text-align:center;padding:8px;'><b>{start_item}-{end_item}</b> / {total_filtered} ürün | Sayfa <b>{current_page}</b>/{total_pages}</div>", unsafe_allow_html=True)

    with pag_col4:
        if st.button("Sonraki ▶️", disabled=(current_page >= total_pages), use_container_width=True):
            st.session_state.inbox_page += 1
            st.rerun()

    with pag_col5:
        if st.button("Son ⏭️", disabled=(current_page >= total_pages), use_container_width=True):
            st.session_state.inbox_page = total_pages
            st.rerun()

    st.markdown("---")

    # Session state for selections
    if 'selected_products' not in st.session_state:
        st.session_state.selected_products = set()

    if products:
        if view_mode == "Izgara":
            # GRID VIEW - 4 columns
            cols_per_row = 4
            for row_idx in range(0, len(products), cols_per_row):
                cols = st.columns(cols_per_row)
                for col_idx, col in enumerate(cols):
                    product_idx = row_idx + col_idx
                    if product_idx < len(products):
                        product = products[product_idx]
                        with col:
                            # Get image
                            images = product.get('images', '[]')
                            try:
                                img_list = json.loads(images) if isinstance(images, str) else images
                                img_url = img_list[0] if img_list else None
                            except:
                                img_url = None

                            # Product card
                            with st.container():
                                # Checkbox for selection
                                selected = st.checkbox("Sec", key=f"sel_{product['id']}", label_visibility="collapsed")
                                if selected:
                                    st.session_state.selected_products.add(product['id'])
                                elif product['id'] in st.session_state.selected_products:
                                    st.session_state.selected_products.discard(product['id'])

                                # Image
                                if img_url:
                                    st.image(img_url, use_container_width=True)
                                else:
                                    st.markdown("""
                                    <div style="width:100%;height:150px;background:#f0f0f0;border-radius:8px;
                                    display:flex;align-items:center;justify-content:center;color:#999;">
                                    📷 Resim Yok
                                    </div>
                                    """, unsafe_allow_html=True)

                                # Title
                                title = product.get('title', 'Urun')[:35]
                                st.markdown(f"**{title}**")

                                # Price & Platform with Künye
                                price = product.get('price', 0)
                                currency = product.get('currency', 'EUR')
                                platform = product.get('platform', 'unknown')
                                condition = product.get('normalized_score', 0) or 0

                                st.markdown(f"<span style='font-size:20px;font-weight:bold;color:#e53935;'>{price:.0f} {currency}</span>", unsafe_allow_html=True)

                                # Platform ve kondisyon badge
                                condition_class = f"condition-{min(max(int(condition), 1), 5)}" if condition > 0 else ""
                                condition_text = f"<span class='{condition_class}'>{int(condition)}/5</span>" if condition > 0 else ""
                                st.markdown(f"📍 {platform} {condition_text}", unsafe_allow_html=True)

                                # Akilli Fiyatlandirma (Product Card Agent ile)
                                if PRODUCT_CARD_AVAILABLE and product_card_agent:
                                    try:
                                        card = product_card_agent.create_card(product)
                                        suggested_price = card.total_cost * 1.30  # %30 kar marji
                                        profit = suggested_price - card.total_cost
                                        st.markdown(f"""
                                        <div class='product-kunye' style='background: linear-gradient(135deg, #f8f9fa 0%, #e8f5e9 100%); border-left: 3px solid #2196F3;'>
                                            <div style='font-weight:700; color:#1976D2; font-size:11px; margin-bottom:4px;'>AKILLI FIYATLANDIRMA</div>
                                            <div class='kunye-row'><span class='kunye-label'>Urun Fiyati:</span><span class='kunye-value'>{price:.2f} EUR</span></div>
                                            <div class='kunye-row'><span class='kunye-label'>Komisyon ({platform}):</span><span class='kunye-value' style='color:#FF5722;'>+{card.platform_commission:.2f} EUR</span></div>
                                            <div class='kunye-row'><span class='kunye-label'>Kargo:</span><span class='kunye-value' style='color:#FF5722;'>+{card.shipping_cost:.2f} EUR</span></div>
                                            <div class='kunye-row' style='border-top:1px solid #ddd; padding-top:4px; margin-top:4px;'>
                                                <span class='kunye-label'><strong>Toplam Maliyet:</strong></span>
                                                <span class='kunye-value' style='color:#e53935; font-size:13px;'><strong>{card.total_cost:.2f} EUR</strong></span>
                                            </div>
                                            <div class='kunye-row' style='background:#4CAF50; color:white; padding:4px 6px; border-radius:4px; margin-top:4px;'>
                                                <span>Onerilen Satis:</span>
                                                <span style='font-weight:700;'>{suggested_price:.2f} EUR (+{profit:.2f})</span>
                                            </div>
                                        </div>
                                        """, unsafe_allow_html=True)
                                    except:
                                        pass

                                # Action buttons - Single click adds to favorites directly
                                bcol1, bcol2, bcol3 = st.columns(3)
                                with bcol1:
                                    # Check if already in favorites
                                    cursor.execute("SELECT 1 FROM favorites WHERE product_id = ?", (product['id'],))
                                    is_favorite = cursor.fetchone() is not None
                                    heart_icon = "❤️" if is_favorite else "🤍"
                                    if st.button(heart_icon, key=f"like_{product['id']}", help="Favorilere ekle" if not is_favorite else "Favorilerden cikar", use_container_width=True):
                                        if is_favorite:
                                            # Remove from favorites
                                            cursor.execute("DELETE FROM favorites WHERE product_id = ?", (product['id'],))
                                            cursor.execute("UPDATE products SET is_in_inbox = 1 WHERE id = ?", (product['id'],))
                                        else:
                                            # Single click - add to favorites directly
                                            cursor.execute("INSERT OR IGNORE INTO favorites (product_id, added_at) VALUES (?, ?)",
                                                          (product['id'], datetime.now()))
                                            cursor.execute("UPDATE products SET is_in_inbox = 0 WHERE id = ?", (product['id'],))

                                            # FAZ A: Download images when favorited
                                            if VARIANT_GENERATOR_AVAILABLE and download_images_on_favorite:
                                                try:
                                                    # Get image URLs from product
                                                    images_raw = product.get('images', '[]')
                                                    if isinstance(images_raw, str):
                                                        try:
                                                            image_urls = json.loads(images_raw)
                                                        except:
                                                            image_urls = [images_raw] if images_raw else []
                                                    else:
                                                        image_urls = images_raw if images_raw else []

                                                    # Add single image if list empty
                                                    if not image_urls and product.get('image'):
                                                        image_urls = [product['image']]

                                                    if image_urls:
                                                        # Download in background (non-blocking)
                                                        downloaded = download_images_on_favorite(product['id'], image_urls)
                                                        if downloaded:
                                                            st.toast(f"📸 {len(downloaded)} resim indirildi", icon="✅")
                                                except Exception as img_err:
                                                    pass  # Silent fail - don't block favorite action

                                        conn.commit()
                                        st.rerun()
                                with bcol2:
                                    if st.button("🗑️", key=f"del_{product['id']}", help="Sil", use_container_width=True):
                                        cursor.execute("DELETE FROM products WHERE id = ?", (product['id'],))
                                        conn.commit()
                                        st.rerun()
                                with bcol3:
                                    url = product.get('url', '#')
                                    st.link_button("🔗", url, help="Urune git", use_container_width=True)

                                st.markdown("---")

        else:
            # LIST VIEW - Original table format
            for i, product in enumerate(products):
                with st.container():
                    col1, col2, col3, col4, col5 = st.columns([0.3, 0.8, 2.5, 1, 1.5])

                    with col1:
                        selected = st.checkbox("", key=f"sel_list_{product['id']}")
                        if selected:
                            st.session_state.selected_products.add(product['id'])

                    with col2:
                        # Thumbnail
                        images = product.get('images', '[]')
                        try:
                            img_list = json.loads(images) if isinstance(images, str) else images
                            img_url = img_list[0] if img_list else None
                        except:
                            img_url = None
                        if img_url:
                            st.image(img_url, width=80)
                        else:
                            st.markdown("📷")

                    with col3:
                        title = product.get('title', 'No Title')[:50]
                        platform = product.get('platform', 'unknown')
                        url = product.get('url', '#')
                        st.markdown(f"**[{title}]({url})**")
                        st.caption(f"📍 {platform}")

                    with col4:
                        price = product.get('price', 0)
                        currency = product.get('currency', 'EUR')
                        st.markdown(f"**{price:.0f} {currency}**")
                        # Künye mini görünüm
                        if PRODUCT_CARD_AVAILABLE and product_card_agent:
                            try:
                                card = product_card_agent.create_card(product)
                                st.caption(f"📦 +€{card.shipping_cost:.0f} | 💰 -€{card.platform_commission:.0f}")
                            except:
                                pass

                    with col5:
                        bcol1, bcol2, bcol3 = st.columns(3)
                        with bcol1:
                            if st.button("🤍", key=f"like_l_{product['id']}", help="Favorilere ekle"):
                                cursor.execute("INSERT OR IGNORE INTO favorites (product_id, added_at) VALUES (?, ?)",
                                              (product['id'], datetime.now()))
                                cursor.execute("UPDATE products SET is_in_inbox = 0 WHERE id = ?", (product['id'],))
                                conn.commit()
                                st.rerun()
                        with bcol2:
                            if st.button("🗑️", key=f"del_l_{product['id']}"):
                                cursor.execute("DELETE FROM products WHERE id = ?", (product['id'],))
                                conn.commit()
                                st.rerun()
                        with bcol3:
                            st.link_button("🔗", product.get('url', '#'))

                st.markdown("---")

        # Bulk actions
        selected_ids = list(st.session_state.selected_products)
        if selected_ids:
            st.markdown(f"### 📋 {len(selected_ids)} urun secili")
            col1, col2, col3 = st.columns(3)

            with col1:
                if st.button("❤️ Tumunu Favorilere Ekle", type="primary", use_container_width=True):
                    downloaded_count = 0
                    for pid in selected_ids:
                        cursor.execute("INSERT OR IGNORE INTO favorites (product_id, added_at) VALUES (?, ?)",
                                      (pid, datetime.now()))
                        cursor.execute("UPDATE products SET is_in_inbox = 0 WHERE id = ?", (pid,))

                        # FAZ A: Download images for each product
                        if VARIANT_GENERATOR_AVAILABLE and download_images_on_favorite:
                            try:
                                cursor.execute("SELECT images, image FROM products WHERE id = ?", (pid,))
                                row = cursor.fetchone()
                                if row:
                                    images_raw = row[0] or '[]'
                                    single_image = row[1]
                                    if isinstance(images_raw, str):
                                        try:
                                            image_urls = json.loads(images_raw)
                                        except:
                                            image_urls = []
                                    else:
                                        image_urls = images_raw or []
                                    if not image_urls and single_image:
                                        image_urls = [single_image]
                                    if image_urls:
                                        downloaded = download_images_on_favorite(pid, image_urls)
                                        if downloaded:
                                            downloaded_count += 1
                            except:
                                pass

                    conn.commit()
                    st.session_state.selected_products.clear()
                    msg = f"{len(selected_ids)} urun favorilere eklendi!"
                    if downloaded_count > 0:
                        msg += f" (📸 {downloaded_count} üründen resim indirildi)"
                    st.success(msg)
                    st.rerun()

            with col2:
                if st.button("🗑️ Tumunu Sil", type="secondary", use_container_width=True):
                    for pid in selected_ids:
                        cursor.execute("DELETE FROM products WHERE id = ?", (pid,))
                    conn.commit()
                    st.session_state.selected_products.clear()
                    st.success(f"{len(selected_ids)} urun silindi!")
                    st.rerun()

            with col3:
                if st.button("❌ Secimi Temizle", use_container_width=True):
                    st.session_state.selected_products.clear()
                    st.rerun()

    else:
        st.info("Filtrelere uygun urun bulunamadi.")

    conn.close()


# ==================== FAZ 8: TOPLU FAVORİ SİLME ====================

def bulk_delete_favorites(product_ids: list, cursor, conn) -> dict:
    """
    Birden fazla favoriyi toplu sil (CSS Berlin cascade delete dahil)

    Args:
        product_ids: Silinecek ürün ID'leri listesi
        cursor: Veritabanı cursor
        conn: Veritabanı bağlantısı

    Returns:
        dict: {success: int, failed: int, css_berlin_removed: int, errors: list}
    """
    results = {
        'success': 0,
        'failed': 0,
        'css_berlin_removed': 0,
        'errors': []
    }

    # Progress bar
    progress_bar = st.progress(0)
    status_text = st.empty()

    for i, product_id in enumerate(product_ids):
        try:
            status_text.text(f"Siliniyor: {i+1}/{len(product_ids)}")

            # 1. Yayın kontrolü
            cursor.execute("""
                SELECT ph.json_product_id, s.store_key, ph.published_url, ph.store_id
                FROM publish_history ph
                LEFT JOIN stores s ON ph.store_id = s.id
                WHERE ph.product_id = ? AND ph.status = 'success'
            """, (product_id,))

            published = cursor.fetchall()

            # 2. CSS Berlin'den sil (eğer yayınlandıysa)
            for record in published:
                json_id = record[0]
                store_key = record[1]
                published_url = record[2]

                # json_product_id NULL ise published_url'den parse et
                if not json_id and store_key == 'css_berlin' and published_url:
                    import re
                    match = re.search(r'ID:\s*(\d+)', published_url)
                    if match:
                        json_id = int(match.group(1))

                if json_id and store_key == 'css_berlin':
                    try:
                        from integrations.github_publisher import GitHubPublisher
                        publisher = GitHubPublisher()
                        result = publisher.remove_product(json_id, reason="bulk_delete")
                        if result.get('success'):
                            results['css_berlin_removed'] += 1
                    except Exception as e:
                        results['errors'].append(f"CSS Berlin error (ID:{json_id}): {str(e)[:50]}")

            # 3. publish_history sil
            cursor.execute("DELETE FROM publish_history WHERE product_id = ?", (product_id,))

            # 4. favorites sil
            cursor.execute("DELETE FROM favorites WHERE product_id = ?", (product_id,))

            # 5. Gelen kutusuna geri gönder
            cursor.execute("UPDATE products SET is_in_inbox = 1 WHERE id = ?", (product_id,))

            results['success'] += 1

        except Exception as e:
            results['failed'] += 1
            results['errors'].append(f"Product {product_id}: {str(e)[:50]}")

        # Progress güncelle
        progress_bar.progress((i + 1) / len(product_ids))

    conn.commit()

    progress_bar.empty()
    status_text.empty()

    return results


def bulk_publish_to_cssberlin(product_ids: list, cursor, conn) -> dict:
    """
    Birden fazla favoriyi CSS Berlin'e toplu yayınla (sırayla kuyruk sistemi)

    Args:
        product_ids: Yayınlanacak ürün ID'leri listesi
        cursor: Veritabanı cursor
        conn: Veritabanı bağlantısı

    Returns:
        dict: {success: int, failed: int, skipped: int, errors: list}
    """
    results = {
        'success': 0,
        'failed': 0,
        'skipped': 0,  # Zaten yayınlanmış
        'errors': []
    }

    # Progress bar
    progress_bar = st.progress(0)
    status_text = st.empty()
    current_product_text = st.empty()

    # GitHub Publisher import
    try:
        from integrations.github_publisher import publish_favorite_to_cssberlin
    except ImportError:
        st.error("❌ GitHub Publisher modülü bulunamadı!")
        return results

    for i, product_id in enumerate(product_ids):
        try:
            # Ürün bilgisini al
            cursor.execute("""
                SELECT p.title, p.price, p.platform, p.url
                FROM products p
                WHERE p.id = ?
            """, (product_id,))
            product_row = cursor.fetchone()

            if not product_row:
                results['failed'] += 1
                results['errors'].append(f"ID:{product_id} - Ürün bulunamadı")
                continue

            title = product_row[0][:40] if product_row[0] else "Ürün"
            price = product_row[1] or 0
            source_url = product_row[3] or ""

            status_text.text(f"Yayınlanıyor: {i+1}/{len(product_ids)}")
            current_product_text.markdown(f"**{title}...** - {price}€")

            # 1. Zaten yayınlanmış mı kontrol et
            cursor.execute("""
                SELECT ph.id FROM publish_history ph
                LEFT JOIN stores s ON ph.store_id = s.id
                WHERE ph.product_id = ? AND ph.status = 'success' AND s.store_key = 'css_berlin'
            """, (product_id,))

            already_published = cursor.fetchone()
            if already_published:
                results['skipped'] += 1
                continue

            # 2. Duplicate kontrolü - aynı source_url zaten yayınlanmış mı?
            # (Bu kontrol github_publisher içinde de var ama UI'da da uyaralım)

            # 3. CSS Berlin'e yayınla
            import time
            time.sleep(0.5)  # Rate limiting - sunucuyu yormamak için

            result = publish_favorite_to_cssberlin(product_id, auto_push=True)

            if result.get('success'):
                results['success'] += 1

                # publish_history tablosuna kaydet
                # Store ID al (css_berlin)
                cursor.execute("SELECT id FROM stores WHERE store_key = 'css_berlin'")
                store_row = cursor.fetchone()
                if not store_row:
                    # Store yoksa oluştur
                    cursor.execute("""
                        INSERT INTO stores (store_key, name, store_type, is_active)
                        VALUES ('css_berlin', 'CSS Berlin', 'github_pages', 1)
                    """)
                    conn.commit()
                    cursor.execute("SELECT id FROM stores WHERE store_key = 'css_berlin'")
                    store_row = cursor.fetchone()

                store_id = store_row[0] if store_row else None

                cursor.execute("""
                    INSERT INTO publish_history
                    (product_id, store_id, status, published_url, json_product_id, created_at)
                    VALUES (?, ?, 'success', ?, ?, datetime('now'))
                """, (product_id, store_id, result.get('message', ''), result.get('product_id')))
                conn.commit()
            else:
                # Duplicate hatası mı kontrol et
                if 'Duplicate' in str(result.get('message', '')):
                    results['skipped'] += 1
                else:
                    results['failed'] += 1
                    results['errors'].append(f"{title[:20]}: {result.get('message', 'Hata')[:50]}")

        except Exception as e:
            results['failed'] += 1
            results['errors'].append(f"ID:{product_id}: {str(e)[:50]}")

        # Progress güncelle
        progress_bar.progress((i + 1) / len(product_ids))

    progress_bar.empty()
    status_text.empty()
    current_product_text.empty()

    return results


# ==================== FAVORITES PAGE ====================

def render_favorites_page():
    """Render favorites page with grid layout"""
    st.title("❤️ Favoriler")
    st.markdown("*Begendiginiz urunler - Yayinla veya Mesaj Gonder*")

    # ============== FAZ 8: TOPLU SEÇİM SESSION STATE ==============
    if 'selected_favorites' not in st.session_state:
        st.session_state.selected_favorites = set()
    if 'show_bulk_delete_confirm' not in st.session_state:
        st.session_state.show_bulk_delete_confirm = False
    if 'show_bulk_publish_confirm' not in st.session_state:
        st.session_state.show_bulk_publish_confirm = False

    conn = get_db()
    cursor = conn.cursor()

    # Ensure stores table exists for publish functionality
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS stores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            store_key TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            url TEXT,
            store_type TEXT,
            username TEXT,
            password TEXT,
            api_key TEXT,
            is_active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            last_used TEXT
        )
    """)

    # Ensure publish_history table exists
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS publish_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER,
            store_id INTEGER,
            status TEXT,
            published_url TEXT,
            error_message TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id),
            FOREIGN KEY (store_id) REFERENCES stores(id)
        )
    """)
    conn.commit()

    try:
        cursor.execute("""
            SELECT
                f.id as fav_id,
                f.product_id,
                p.title, p.url, p.price, p.currency, p.platform,
                p.condition, p.brand, p.images, p.location,
                p.size, p.color, p.shipping_cost,
                p.estimated_shipping_days,
                ps.normalized_score, ps.profit_amount, ps.profit_margin
            FROM favorites f
            JOIN products p ON f.product_id = p.id
            LEFT JOIN product_scores ps ON p.id = ps.product_id
            ORDER BY f.added_at DESC
        """)

        favorites = [dict_from_row(row) for row in cursor.fetchall()]
    except:
        favorites = []

    st.markdown(f"**{len(favorites)} favori urun**")

    # ============== FAZ 8: TOPLU SEÇİM KONTROL PANELİ ==============
    if favorites:
        # Geçersiz seçimleri temizle (silinmiş ürünler)
        valid_product_ids = {fav['product_id'] for fav in favorites}
        st.session_state.selected_favorites = st.session_state.selected_favorites.intersection(valid_product_ids)

        # Kontrol butonları - 5 sütun
        ctrl_col1, ctrl_col2, ctrl_col3, ctrl_col4, ctrl_col5 = st.columns([1, 1, 2, 1, 1])

        with ctrl_col1:
            if st.button("☑️ Tümünü Seç", key="select_all_favs", use_container_width=True):
                st.session_state.selected_favorites = set(fav['product_id'] for fav in favorites)
                st.rerun()

        with ctrl_col2:
            if st.button("☐ Temizle", key="clear_fav_selection", use_container_width=True):
                st.session_state.selected_favorites = set()
                st.rerun()

        with ctrl_col3:
            selected_count = len(st.session_state.selected_favorites)
            if selected_count > 0:
                st.info(f"🔹 {selected_count} ürün seçili")
            else:
                st.caption("Seçim yapın veya Tümünü Seç")

        with ctrl_col4:
            selected_count = len(st.session_state.selected_favorites)
            if selected_count > 0:
                if st.button("🚀 CSS Berlin", key="bulk_publish_btn", type="primary", use_container_width=True):
                    st.session_state.show_bulk_publish_confirm = True
                    st.rerun()

        with ctrl_col5:
            selected_count = len(st.session_state.selected_favorites)
            if selected_count > 0:
                if st.button("🗑️ Sil", key="bulk_delete_btn", use_container_width=True):
                    st.session_state.show_bulk_delete_confirm = True
                    st.rerun()

        # ============== TOPLU YAYINLA ONAY DİALOGU ==============
        if st.session_state.show_bulk_publish_confirm:
            selected_ids = list(st.session_state.selected_favorites)

            st.success(f"🚀 **{len(selected_ids)} ürün CSS Berlin'e yayınlanacak!**")
            st.caption("Ürünler sırayla işlenecek. Zaten yayınlanmış ürünler atlanacak.")

            pub_col1, pub_col2 = st.columns(2)
            with pub_col1:
                if st.button("✅ Yayınla", key="confirm_bulk_publish", type="primary", use_container_width=True):
                    # Toplu yayınlama işlemi
                    results = bulk_publish_to_cssberlin(selected_ids, cursor, conn)

                    # Sonuç mesajı
                    if results['success'] > 0:
                        st.success(f"✅ {results['success']} ürün yayınlandı!")
                    if results['skipped'] > 0:
                        st.info(f"⏭️ {results['skipped']} ürün atlandı (zaten yayınlanmış/duplicate)")
                    if results['failed'] > 0:
                        st.error(f"❌ {results['failed']} ürün yayınlanamadı")
                        for err in results['errors'][:3]:
                            st.caption(f"• {err}")

                    # State temizle
                    st.session_state.show_bulk_publish_confirm = False
                    st.session_state.selected_favorites = set()
                    st.rerun()

            with pub_col2:
                if st.button("❌ İptal", key="cancel_bulk_publish", use_container_width=True):
                    st.session_state.show_bulk_publish_confirm = False
                    st.rerun()

        # ============== TOPLU SİLME ONAY DİALOGU ==============
        if st.session_state.show_bulk_delete_confirm:
            selected_ids = list(st.session_state.selected_favorites)

            st.warning(f"⚠️ **{len(selected_ids)} ürün silinecek!**")
            st.caption("Yayınlanmış ürünler CSS Berlin'den de kaldırılacak.")

            confirm_col1, confirm_col2 = st.columns(2)
            with confirm_col1:
                if st.button("✅ Evet, Sil", key="confirm_bulk_delete", type="primary", use_container_width=True):
                    # Toplu silme işlemi
                    results = bulk_delete_favorites(selected_ids, cursor, conn)

                    # Sonuç mesajı
                    if results['success'] > 0:
                        msg = f"✅ {results['success']} ürün silindi"
                        if results['css_berlin_removed'] > 0:
                            msg += f" ({results['css_berlin_removed']} CSS Berlin'den kaldırıldı)"
                        st.success(msg)

                    if results['failed'] > 0:
                        st.error(f"❌ {results['failed']} ürün silinemedi")
                        for err in results['errors'][:3]:
                            st.caption(f"• {err}")

                    # State temizle
                    st.session_state.show_bulk_delete_confirm = False
                    st.session_state.selected_favorites = set()
                    st.rerun()

            with confirm_col2:
                if st.button("❌ İptal", key="cancel_bulk_delete", use_container_width=True):
                    st.session_state.show_bulk_delete_confirm = False
                    st.rerun()

    st.markdown("---")

    # ============== KAYNAK KONTROL VE MALİYET PANELİ ==============
    if favorites and FAVORITES_VALIDATOR_AVAILABLE:
        with st.expander("🔍 Kaynak Kontrol & Maliyet Analizi", expanded=False):
            tool_col1, tool_col2, tool_col3 = st.columns(3)

            with tool_col1:
                if st.button("🔄 Tüm Kaynakları Kontrol Et", key="check_all_sources", use_container_width=True):
                    validator = get_validator()
                    with st.spinner("Kaynaklar kontrol ediliyor..."):
                        results = validator.validate_all_favorites()

                    st.success(f"✅ Kontrol tamamlandı!")
                    st.markdown(f"""
                    - **Toplam:** {results['total']}
                    - **Mevcut:** {results['available']} ✅
                    - **Satılmış:** {results['sold']} 🔴
                    - **Hata:** {results['error']} ⚠️
                    """)

                    if results['sold'] > 0:
                        st.warning(f"⚠️ {results['sold']} ürün satılmış! Favorilerden kaldırmanız önerilir.")

            with tool_col2:
                st.markdown("**Satılmış Ürünleri Temizle**")
                if st.button("🗑️ Satılmışları Sil", key="remove_sold_favorites", use_container_width=True):
                    cursor.execute("""
                        DELETE FROM favorites
                        WHERE id IN (
                            SELECT f.id FROM favorites f
                            WHERE f.is_sold = 1
                        )
                    """)
                    deleted = cursor.rowcount
                    conn.commit()
                    if deleted > 0:
                        st.success(f"✅ {deleted} satılmış ürün silindi!")
                        st.rerun()
                    else:
                        st.info("Satılmış ürün bulunamadı.")

            with tool_col3:
                st.markdown("**Otomatik Kontrol**")
                auto_check = st.checkbox("Her 30 dk kontrol et", key="auto_source_check", value=False)
                if auto_check:
                    st.caption("Cron job aktif: Hetzner + Windows")

    if favorites:
        # GRID VIEW - 4 columns (same as inbox)
        cols_per_row = 4
        for row_idx in range(0, len(favorites), cols_per_row):
            cols = st.columns(cols_per_row)
            for col_idx, col in enumerate(cols):
                fav_idx = row_idx + col_idx
                if fav_idx < len(favorites):
                    fav = favorites[fav_idx]
                    with col:
                        # Get image
                        images = fav.get('images', '[]')
                        try:
                            img_list = json.loads(images) if isinstance(images, str) else images
                            img_url = img_list[0] if img_list else None
                        except:
                            img_url = None

                        # Product card
                        with st.container():
                            # ============== FAZ 8: CHECKBOX İLE SEÇİM ==============
                            is_selected = fav['product_id'] in st.session_state.selected_favorites

                            # Seçili kartları vurgula
                            if is_selected:
                                st.markdown("""<div style="border: 2px solid #4CAF50; border-radius: 8px; padding: 5px; background: rgba(76, 175, 80, 0.1);">""", unsafe_allow_html=True)

                            checkbox_col, title_col = st.columns([1, 6])
                            with checkbox_col:
                                new_selection = st.checkbox(
                                    "",
                                    value=is_selected,
                                    key=f"sel_fav_{fav['product_id']}",
                                    label_visibility="collapsed"
                                )
                                # Seçim değişikliği
                                if new_selection != is_selected:
                                    if new_selection:
                                        st.session_state.selected_favorites.add(fav['product_id'])
                                    else:
                                        st.session_state.selected_favorites.discard(fav['product_id'])
                                    st.rerun()

                            # Image
                            if img_url:
                                st.image(img_url, use_container_width=True)
                            else:
                                st.markdown("""
                                <div style="width:100%;height:150px;background:#f0f0f0;border-radius:8px;
                                display:flex;align-items:center;justify-content:center;color:#999;">
                                📷 Resim Yok
                                </div>
                                """, unsafe_allow_html=True)

                            # Title
                            title = fav.get('title', 'Urun')[:35]
                            st.markdown(f"**{title}**")

                            # Price & Platform with Künye
                            price = fav.get('price', 0)
                            currency = fav.get('currency', 'EUR')
                            platform = fav.get('platform', 'unknown')
                            condition = fav.get('normalized_score', 0) or 0

                            st.markdown(f"<span style='font-size:20px;font-weight:bold;color:#e53935;'>{price:.0f} {currency}</span>", unsafe_allow_html=True)

                            # Platform ve kondisyon badge
                            condition_class = f"condition-{min(max(int(condition), 1), 5)}" if condition > 0 else ""
                            condition_text = f"<span class='{condition_class}'>{int(condition)}/5</span>" if condition > 0 else ""
                            st.markdown(f"📍 {platform} {condition_text}", unsafe_allow_html=True)

                            # Künye bilgileri (Product Card Agent ile)
                            if PRODUCT_CARD_AVAILABLE and product_card_agent:
                                try:
                                    card = product_card_agent.create_card(fav)
                                    shipping = fav.get('shipping_cost', 0) or card.shipping_cost
                                    total_cost = price + shipping + card.platform_commission
                                    suggested_price = round(total_cost * 1.30, 2)  # 30% kar marji

                                    st.markdown(f"""
                                    <div class='product-kunye' style='background:#f8f9fa;padding:8px;border-radius:6px;margin:5px 0;'>
                                        <div style='font-size:11px;color:#666;'>
                                            <div>📦 Kaynak: <b>€{price:.2f}</b></div>
                                            <div>🚚 Kargo: <b>€{shipping:.2f}</b></div>
                                            <div>💰 Komisyon: €{card.platform_commission:.2f}</div>
                                            <div style='border-top:1px solid #ddd;margin-top:4px;padding-top:4px;'>
                                                <span style='color:#e53935;'>Maliyet: <b>€{total_cost:.2f}</b></span>
                                            </div>
                                            <div style='color:#4CAF50;'>Önerilen: <b>€{suggested_price:.2f}</b></div>
                                        </div>
                                    </div>
                                    """, unsafe_allow_html=True)
                                except:
                                    pass

                            # Resim sayısı göster
                            img_count = len(img_list) if img_list else 0
                            img_status = "✅" if img_count >= 5 else "⚠️"
                            st.caption(f"📷 {img_count} resim {img_status}")

                            # Manuel fiyat girişi
                            custom_price = st.number_input(
                                "Satış Fiyatı (€)",
                                min_value=0.0,
                                value=float(fav.get('target_price') or (price * 1.3 if price else 0)),
                                step=1.0,
                                key=f"price_{fav['product_id']}",
                                label_visibility="collapsed"
                            )

                            # Fiyat değişikliğini kaydet
                            if custom_price and custom_price != fav.get('target_price'):
                                cursor.execute("UPDATE favorites SET target_price = ? WHERE product_id = ?",
                                              (custom_price, fav['product_id']))
                                conn.commit()

                            # Action buttons - Red heart, click to remove from favorites
                            bcol1, bcol2, bcol3 = st.columns(3)
                            with bcol1:
                                if st.button("❤️", key=f"fav_heart_{fav['product_id']}", help="Favoriden cikar (gelen kutusuna gonder)", use_container_width=True):
                                    # FAZ 7: Cascade silme - Yayınlanan sitelerden de sil
                                    removed_from_sites = []

                                    # 1. Yayınlanmış mı kontrol et
                                    cursor.execute("""
                                        SELECT ph.json_product_id, ph.store_id, s.store_key, s.name
                                        FROM publish_history ph
                                        LEFT JOIN stores s ON ph.store_id = s.id
                                        WHERE ph.product_id = ? AND ph.status = 'success'
                                    """, (fav['product_id'],))

                                    published_records = cursor.fetchall()

                                    # 2. Her yayından sil
                                    for record in published_records:
                                        json_id, store_id, store_key, store_name = record

                                        # json_product_id NULL ise published_url'den parse et
                                        if not json_id and store_key == 'css_berlin':
                                            cursor.execute("SELECT published_url FROM publish_history WHERE product_id = ? AND store_id = ?",
                                                          (fav['product_id'], store_id))
                                            url_row = cursor.fetchone()
                                            if url_row and url_row[0]:
                                                # "cssberlin.de (ID: 277)" formatından ID'yi çıkar
                                                import re
                                                match = re.search(r'ID:\s*(\d+)', url_row[0])
                                                if match:
                                                    json_id = int(match.group(1))

                                        if json_id and store_key == 'css_berlin':
                                            try:
                                                from integrations.github_publisher import GitHubPublisher
                                                publisher = GitHubPublisher()
                                                result = publisher.remove_product(json_id, reason="favorite_removed")
                                                if result.get('success'):
                                                    removed_from_sites.append(f"CSS Berlin (ID: {json_id})")
                                            except Exception as pub_err:
                                                st.warning(f"CSS Berlin silme hatasi: {pub_err}")

                                    # 3. publish_history'den sil
                                    cursor.execute("DELETE FROM publish_history WHERE product_id = ?", (fav['product_id'],))

                                    # 4. Favorilerden sil
                                    cursor.execute("DELETE FROM favorites WHERE product_id = ?", (fav['product_id'],))

                                    # 5. Gelen kutusuna geri gönder
                                    cursor.execute("UPDATE products SET is_in_inbox = 1 WHERE id = ?", (fav['product_id'],))

                                    conn.commit()

                                    # 6. Kullanıcıya bilgi ver
                                    if removed_from_sites:
                                        st.success(f"Ürün favorilerden ve {', '.join(removed_from_sites)} sitesinden kaldirildi!")
                                    else:
                                        st.info("Ürün favorilerden kaldirildi (gelen kutusuna gönderildi)")

                                    st.rerun()
                            with bcol2:
                                # Initialize session state for publish modal
                                if f"show_publish_{fav['product_id']}" not in st.session_state:
                                    st.session_state[f"show_publish_{fav['product_id']}"] = False

                                if st.button("🚀", key=f"pub_{fav['product_id']}", help="Yayina Al", use_container_width=True):
                                    st.session_state[f"show_publish_{fav['product_id']}"] = not st.session_state[f"show_publish_{fav['product_id']}"]
                                    st.rerun()
                            with bcol3:
                                url = fav.get('url', '#')
                                st.link_button("🔗", url, help="Urune git", use_container_width=True)

                            # Show publish panel if button was clicked
                            if st.session_state.get(f"show_publish_{fav['product_id']}", False):
                                st.markdown("---")

                                # Multi-platform selection with variants
                                st.markdown("**🎯 Hedef Platformlar (her biri farklı resim/başlık alır):**")

                                # Check which platforms have credentials configured
                                cursor.execute("SELECT store_key, name, username FROM stores WHERE is_active = 1")
                                configured_stores = {row['store_key']: row for row in cursor.fetchall()}

                                # Platform availability based on credentials
                                css_available = 'css_berlin' in configured_stores  # CSS Berlin = GitHub, no login needed
                                vinted_available = 'vinted' in configured_stores and configured_stores['vinted'].get('username')
                                ebay_available = 'ebay' in configured_stores and configured_stores['ebay'].get('username')
                                klein_available = 'kleinanzeigen' in configured_stores and configured_stores['kleinanzeigen'].get('username')
                                will_available = 'willhaben' in configured_stores and configured_stores['willhaben'].get('username')

                                # Platform checkboxes
                                platform_cols = st.columns(3)
                                with platform_cols[0]:
                                    if css_available:
                                        pub_cssberlin = st.checkbox("🌐 CSS Berlin", value=True, key=f"pub_css_{fav['product_id']}")
                                    else:
                                        pub_cssberlin = st.checkbox("🌐 CSS Berlin", key=f"pub_css_{fav['product_id']}", disabled=True, help="⚠️ Mağazalar'dan ekleyin")
                                with platform_cols[1]:
                                    # Vinted Manuel Dosya Sistemi - her zaman kullanılabilir
                                    if VINTED_MANUAL_AVAILABLE:
                                        pub_vinted = st.checkbox("👗 Vinted (Manuel)", key=f"pub_vinted_{fav['product_id']}", help="Dosya sistemi ile manuel yayın")
                                    else:
                                        pub_vinted = st.checkbox("👗 Vinted", key=f"pub_vinted_{fav['product_id']}", disabled=True, help="⚠️ Modül yüklenemedi")
                                with platform_cols[2]:
                                    if ebay_available:
                                        pub_ebay = st.checkbox("🛒 eBay", key=f"pub_ebay_{fav['product_id']}")
                                    else:
                                        pub_ebay = st.checkbox("🛒 eBay", key=f"pub_ebay_{fav['product_id']}", disabled=True, help="⚠️ Giriş bilgisi gerekli")

                                platform_cols2 = st.columns(3)
                                with platform_cols2[0]:
                                    if klein_available:
                                        pub_kleinanzeigen = st.checkbox("📋 Kleinanzeigen", key=f"pub_klein_{fav['product_id']}")
                                    else:
                                        pub_kleinanzeigen = st.checkbox("📋 Kleinanzeigen", key=f"pub_klein_{fav['product_id']}", disabled=True, help="⚠️ Giriş bilgisi gerekli")
                                with platform_cols2[1]:
                                    if will_available:
                                        pub_willhaben = st.checkbox("🏠 Willhaben", key=f"pub_will_{fav['product_id']}")
                                    else:
                                        pub_willhaben = st.checkbox("🏠 Willhaben", key=f"pub_will_{fav['product_id']}", disabled=True, help="⚠️ Giriş bilgisi gerekli")

                                # Show message if no platforms available
                                all_disabled = not (css_available or vinted_available or ebay_available or klein_available or will_available)
                                if all_disabled:
                                    st.warning("⚠️ Hiç platform tanımlı değil! Önce **🏪 Mağazalar** sayfasından platform ekleyin.")

                                # Collect selected platforms
                                selected_platforms = []
                                if css_available and pub_cssberlin:
                                    selected_platforms.append('cssberlin')
                                if VINTED_MANUAL_AVAILABLE and pub_vinted:
                                    selected_platforms.append('vinted_manual')
                                if ebay_available and pub_ebay:
                                    selected_platforms.append('ebay')
                                if klein_available and pub_kleinanzeigen:
                                    selected_platforms.append('kleinanzeigen')
                                if will_available and pub_willhaben:
                                    selected_platforms.append('willhaben')

                                # Show variant preview if available
                                if VARIANT_GENERATOR_AVAILABLE and selected_platforms:
                                    st.caption(f"✨ {len(selected_platforms)} platform seçili - her biri farklı resim & başlık alacak")

                                # Get CSS Berlin store for compatibility
                                cursor.execute("SELECT * FROM stores WHERE store_key = 'css_berlin' AND is_active = 1")
                                css_berlin_store = cursor.fetchone()
                                is_cssberlin = 'cssberlin' in selected_platforms

                                # Publish button
                                pub_col1, pub_col2 = st.columns(2)
                                with pub_col1:
                                    if st.button("✅ Yayinla", key=f"do_pub_{fav['product_id']}", type="primary", use_container_width=True, disabled=len(selected_platforms)==0):
                                        if not selected_platforms:
                                            st.warning("En az bir platform seçin!")
                                        else:
                                            try:
                                                # 1. VARYANT ÜRET (Yeni sistem)
                                                if VARIANT_GENERATOR_AVAILABLE:
                                                    with st.spinner(f"🎨 {len(selected_platforms)} platform için varyant oluşturuluyor..."):
                                                        # Check for already downloaded local images
                                                        local_images = []
                                                        images_dir = Path(__file__).parent.parent / 'storage' / 'images' / str(fav['product_id'])
                                                        if images_dir.exists():
                                                            local_images = [str(p) for p in sorted(images_dir.glob("original_*.jpg"))]

                                                        # Prepare product data with COMPLETE metadata
                                                        product_data = {
                                                            'id': fav['product_id'],
                                                            'title': fav.get('title', ''),
                                                            'description': fav.get('description', ''),
                                                            'price': fav.get('price', 0),
                                                            'images': fav.get('images', '[]'),
                                                            'image': fav.get('image', ''),
                                                            'platform': fav.get('platform', 'unknown'),
                                                            'url': fav.get('url', ''),
                                                            'local_images': local_images,  # Pre-downloaded images
                                                            # METADATA - Kaynak verisinden doğrudan aktarılacak
                                                            'size': fav.get('size', ''),
                                                            'color': fav.get('color', ''),
                                                            'condition': fav.get('condition', ''),
                                                            'brand': fav.get('brand', ''),
                                                            'shipping_cost': fav.get('shipping_cost', 5.99)  # Fiyat formülü için
                                                        }

                                                        # Generate variants for each platform
                                                        variants = generate_product_variants(product_data, selected_platforms)
                                                        st.success(f"✅ {len(variants)} varyant oluşturuldu!")

                                                        # Show variant preview
                                                        for platform, variant in variants.items():
                                                            with st.expander(f"📋 {platform.upper()} Varyantı"):
                                                                st.write(f"**Başlık:** {variant['title'][:60]}...")
                                                                st.write(f"**Fiyat:** {variant['price']}€ (+{variant['margin_percent']}% kar)")
                                                                if variant.get('images'):
                                                                    st.write(f"**Resimler:** {len(variant['images'])} adet (işlenmiş)")

                                                # 2. CSS BERLIN'E YAYINLA
                                                if is_cssberlin and css_berlin_store:
                                                    # Record publish attempt
                                                    cursor.execute("""
                                                        INSERT INTO publish_history (product_id, store_id, status)
                                                        VALUES (?, ?, 'pending')
                                                    """, (fav['product_id'], css_berlin_store['id']))
                                                    conn.commit()

                                                    # Kaynak doğrulama
                                                    source_url = fav.get('url', '')
                                                    validation_passed = True

                                                    if source_url and GITHUB_PUBLISHER_AVAILABLE:
                                                        with st.spinner("🔍 Kaynak kontrol ediliyor..."):
                                                            try:
                                                                from integrations.github_publisher import GitHubPublisher
                                                                publisher = GitHubPublisher()
                                                                validation = publisher.validate_source_availability(source_url)
                                                                if validation['status'] != 'available':
                                                                    validation_passed = False
                                                                    st.error(f"❌ Kaynak mevcut değil: {validation['status']}")
                                                                else:
                                                                    st.success(f"✅ Kaynak doğrulandı ({validation.get('confidence', 0):.0%})")
                                                            except:
                                                                pass  # Continue on error

                                                    # Yayınla (varyant ile veya ham veri ile)
                                                    if validation_passed and GITHUB_PUBLISHER_AVAILABLE:
                                                        with st.spinner("📤 CSS Berlin'e yayınlanıyor..."):
                                                            # Use variant if available (işlenmiş resim + SEO başlık/açıklama)
                                                            if VARIANT_GENERATOR_AVAILABLE and 'cssberlin' in variants:
                                                                variant = variants['cssberlin']
                                                                # Varyant verisini kullan (resim+SEO zaten işlenmiş)
                                                                result = publish_variant_to_cssberlin(variant, auto_push=True)
                                                                st.info(f"🎨 Varyant kullanıldı: {variant.get('title', '')[:40]}...")
                                                            else:
                                                                # Fallback: ham veri ile yayınla
                                                                result = publish_favorite_to_cssberlin(fav['product_id'], auto_push=True)

                                                        if result['success']:
                                                            json_product_id = result.get('product_id')
                                                            st.success(f"✅ CSS Berlin'e eklendi! ID: {json_product_id}")

                                                            # Update history
                                                            try:
                                                                cursor.execute("""
                                                                    UPDATE publish_history
                                                                    SET json_product_id = ?, status = 'success', published_url = ?
                                                                    WHERE product_id = ? AND store_id = ?
                                                                """, (json_product_id, f"cssberlin.de (ID: {json_product_id})", fav['product_id'], css_berlin_store['id']))
                                                                conn.commit()
                                                            except:
                                                                pass

                                                            if result.get('pushed'):
                                                                st.info("🚀 GitHub'a push edildi!")
                                                            else:
                                                                st.warning("⚠️ JSON'a eklendi ama push yapılamadı")
                                                        else:
                                                            st.error(f"❌ Hata: {result.get('message')}")
                                                    elif not GITHUB_PUBLISHER_AVAILABLE:
                                                        st.error("GitHub Publisher yüklenemedi!")

                                                # 3. VINTED MANUEL DOSYA SİSTEMİ
                                                if 'vinted_manual' in selected_platforms and VINTED_MANUAL_AVAILABLE:
                                                    with st.spinner("📁 Vinted dosyaları hazırlanıyor..."):
                                                        try:
                                                            # Get custom price from session
                                                            custom_price_key = f"price_{fav['product_id']}"
                                                            custom_price = st.session_state.get(custom_price_key, None)

                                                            # Prepare product data
                                                            product_for_vinted = {
                                                                'id': fav['product_id'],
                                                                'title': fav.get('title', ''),
                                                                'description': fav.get('description', ''),
                                                                'price': fav.get('price', 0),
                                                                'currency': fav.get('currency', 'EUR'),
                                                                'platform': fav.get('platform', 'unknown'),
                                                                'url': fav.get('url', ''),
                                                                'brand': fav.get('brand', ''),
                                                                'size': fav.get('size', ''),
                                                                'color': fav.get('color', ''),
                                                                'condition': fav.get('condition', 'Sehr gut'),
                                                                'images': fav.get('images', '[]')
                                                            }

                                                            # Call Vinted Manual Publisher
                                                            vinted_result = prepare_vinted_manual_listing(
                                                                product_for_vinted,
                                                                custom_price=custom_price,
                                                                generate_organic_content=True,
                                                                manipulation_level='medium'
                                                            )

                                                            if vinted_result.get('success'):
                                                                st.success(f"✅ Vinted dosyaları hazır!")
                                                                st.info(f"📷 {vinted_result.get('images_count', 0)} görsel işlendi")
                                                                st.markdown(f"**Başlık:** {vinted_result.get('title', '')[:50]}...")
                                                                st.markdown(f"**Fiyat:** {vinted_result.get('price', 0):.2f}€")

                                                                # Clickable file link
                                                                file_link = vinted_result.get('file_link', '')
                                                                folder_path = vinted_result.get('folder_path', '')

                                                                st.markdown("---")
                                                                st.markdown("**📂 Dosya Konumu:**")
                                                                st.code(folder_path, language=None)

                                                                # Create clickable link
                                                                st.markdown(f"""
                                                                <a href="{file_link}" target="_blank" style="
                                                                    display: inline-block;
                                                                    padding: 10px 20px;
                                                                    background: #4CAF50;
                                                                    color: white;
                                                                    text-decoration: none;
                                                                    border-radius: 5px;
                                                                    margin: 10px 0;
                                                                ">📁 Klasörü Aç</a>
                                                                """, unsafe_allow_html=True)

                                                                # Save to publish history
                                                                try:
                                                                    cursor.execute("""
                                                                        INSERT INTO publish_history (product_id, store_id, status, published_url)
                                                                        VALUES (?, NULL, 'pending_manual', ?)
                                                                    """, (fav['product_id'], f"vinted_manual:{folder_path}"))
                                                                    conn.commit()
                                                                except:
                                                                    pass

                                                            else:
                                                                st.error(f"❌ Vinted hazırlama hatası: {vinted_result.get('error', 'Bilinmeyen hata')}")

                                                        except Exception as vinted_err:
                                                            st.error(f"❌ Vinted modül hatası: {str(vinted_err)}")

                                                st.session_state[f"show_publish_{fav['product_id']}"] = False
                                            except Exception as pub_error:
                                                st.error(f"❌ Yayınlama hatası: {str(pub_error)}")

                                with pub_col2:
                                    if st.button("❌ İptal", key=f"cancel_pub_{fav['product_id']}", use_container_width=True):
                                        st.session_state[f"show_publish_{fav['product_id']}"] = False
                                        st.rerun()

                            # ============== FAZ 8: SEÇİM DIV KAPANIŞ ==============
                            if is_selected:
                                st.markdown("</div>", unsafe_allow_html=True)

                            st.markdown("---")
    else:
        st.info("Henuz favori urun yok. Gelen Kutusu'ndan urun begenin.")

    conn.close()


# ==================== LEARNING CENTER PAGE ====================

def render_learning_page():
    """Render learning center page"""
    st.title("🧠 Ogrenme Merkezi")
    st.markdown("*Ajanlari egitin - Terim tanitin, Kural ekleyin*")

    conn = get_db()
    cursor = conn.cursor()

    tab1, tab2 = st.tabs(["📝 Bilinmeyen Terimler", "⚙️ Filtreleme Kurallari"])

    with tab1:
        st.subheader("Bilinmeyen Durum Terimleri")
        st.markdown("*Bu terimleri puanlayarak ConditionNormalizationAgent'i egitin*")

        try:
            cursor.execute("""
                SELECT DISTINCT
                    p.condition,
                    p.platform,
                    p.language,
                    COUNT(*) as count
                FROM products p
                WHERE p.condition IS NOT NULL
                AND p.condition != ''
                AND NOT EXISTS (
                    SELECT 1 FROM condition_mapping cm
                    WHERE cm.raw_term = p.condition
                )
                GROUP BY p.condition, p.platform
                ORDER BY count DESC
                LIMIT 20
            """)

            unknown_terms = cursor.fetchall()
        except:
            unknown_terms = []

        if unknown_terms:
            for term in unknown_terms:
                with st.container():
                    col1, col2, col3, col4 = st.columns([3, 1, 1, 2])

                    with col1:
                        st.markdown(f"**{term['condition']}**")
                        st.caption(f"Platform: {term['platform']} | Dil: {term['language'] or 'unknown'}")

                    with col2:
                        st.markdown(f"📊 {term['count']}x")

                    with col3:
                        score = st.selectbox(
                            "Skor",
                            [1, 2, 3, 4, 5],
                            index=2,
                            key=f"score_{term['condition']}_{term['platform']}"
                        )

                    with col4:
                        if st.button("💾 Kaydet", key=f"save_{term['condition']}_{term['platform']}"):
                            cursor.execute("""
                                INSERT INTO condition_mapping
                                (language, platform, raw_term, normalized_score, confidence, learned_from, is_verified)
                                VALUES (?, ?, ?, ?, 0.8, 'user_training', 1)
                            """, (term['language'] or 'unknown', term['platform'], term['condition'], score))
                            conn.commit()
                            st.success("Terim egitildi!")
                            st.rerun()

                    st.markdown("---")
        else:
            st.success("Tum terimler egitilmis durumda!")

    with tab2:
        st.subheader("Filtreleme Kurallari")
        st.markdown("*Otomatik onay/red kurallari tanimlayin*")

        try:
            cursor.execute("SELECT * FROM filtering_rules ORDER BY priority DESC")
            rules = cursor.fetchall()
        except:
            rules = []

        if rules:
            for rule in rules:
                with st.container():
                    col1, col2, col3 = st.columns([4, 1, 1])

                    with col1:
                        status = "🟢" if rule['is_active'] else "🔴"
                        st.markdown(f"{status} **{rule['name']}**")
                        st.caption(f"EGER {rule['condition_field']} {rule['condition_operator']} {rule['condition_value']} → {rule['action'].upper()}")

                    with col2:
                        st.markdown(f"Oncelik: {rule['priority']}")

                    with col3:
                        if st.button("🗑️", key=f"delete_rule_{rule['id']}"):
                            cursor.execute("DELETE FROM filtering_rules WHERE id = ?", (rule['id'],))
                            conn.commit()
                            st.rerun()

                    st.markdown("---")

        st.subheader("➕ Yeni Kural Ekle")

        with st.form("new_rule_form"):
            col1, col2 = st.columns(2)

            with col1:
                rule_name = st.text_input("Kural Adi")
                rule_type = st.selectbox("Kural Tipi", ["auto_reject", "auto_approve", "risky"])
                condition_field = st.selectbox("Alan", ["normalized_score", "price", "description", "brand", "profit_margin"])

            with col2:
                condition_operator = st.selectbox("Operator", ["<", "<=", "=", ">=", ">", "contains", "in"])
                condition_value = st.text_input("Deger")
                priority = st.number_input("Oncelik", min_value=0, max_value=100, value=50)

            if st.form_submit_button("Kural Ekle"):
                if rule_name and condition_value:
                    action = "reject" if rule_type == "auto_reject" else "approve" if rule_type == "auto_approve" else "review"
                    cursor.execute("""
                        INSERT INTO filtering_rules
                        (name, rule_type, condition_field, condition_operator, condition_value, action, priority)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (rule_name, rule_type, condition_field, condition_operator, condition_value, action, priority))
                    conn.commit()
                    st.success("Kural eklendi!")
                    st.rerun()
                else:
                    st.error("Lutfen tum alanlari doldurun")

    conn.close()


# ==================== STATS PAGE ====================

def render_stats_page():
    """Render statistics page"""
    st.title("📊 Istatistikler")

    conn = get_db()
    cursor = conn.cursor()

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        try:
            cursor.execute("SELECT COUNT(*) FROM products WHERE is_in_inbox = 1")
            st.metric("📥 Gelen Kutusu", cursor.fetchone()[0])
        except:
            st.metric("📥 Gelen Kutusu", 0)

    with col2:
        try:
            cursor.execute("SELECT COUNT(*) FROM favorites")
            st.metric("❤️ Favoriler", cursor.fetchone()[0])
        except:
            st.metric("❤️ Favoriler", 0)

    with col3:
        try:
            cursor.execute("SELECT COUNT(*) FROM products WHERE DATE(scraped_at) = DATE('now')")
            st.metric("📆 Bugun", cursor.fetchone()[0])
        except:
            st.metric("📆 Bugun", 0)

    with col4:
        try:
            cursor.execute("SELECT COUNT(*) FROM condition_mapping")
            st.metric("🧠 Egitilmis", cursor.fetchone()[0])
        except:
            st.metric("🧠 Egitilmis", 0)

    st.markdown("---")

    # Platform distribution
    st.subheader("📍 Platform Dagilimi")
    try:
        cursor.execute("""
            SELECT platform, COUNT(*) as count
            FROM products WHERE is_in_inbox = 1
            GROUP BY platform
            ORDER BY count DESC
            LIMIT 10
        """)
        platform_data = cursor.fetchall()
        if platform_data:
            df = pd.DataFrame([dict(row) for row in platform_data])
            st.bar_chart(df.set_index('platform'))
        else:
            st.info("Henuz veri yok")
    except:
        st.info("Henuz veri yok")

    # Type distribution
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("📦 Urun Tipine Gore")
        try:
            cursor.execute("""
                SELECT COALESCE(product_type, 'standard') as type, COUNT(*) as count
                FROM products WHERE is_in_inbox = 1
                GROUP BY product_type
            """)
            type_data = cursor.fetchall()
            if type_data:
                df = pd.DataFrame([dict(row) for row in type_data])
                st.bar_chart(df.set_index('type'))
        except:
            st.info("Henuz veri yok")

    with col2:
        st.subheader("📦 Kargo Suresine Gore")
        try:
            cursor.execute("""
                SELECT
                    CASE
                        WHEN estimated_shipping_days <= 2 THEN '1-2 gun'
                        WHEN estimated_shipping_days <= 4 THEN '3-4 gun'
                        WHEN estimated_shipping_days <= 6 THEN '5-6 gun'
                        ELSE '7+ gun'
                    END as category,
                    COUNT(*) as count
                FROM products
                WHERE is_in_inbox = 1 AND estimated_shipping_days IS NOT NULL
                GROUP BY category
            """)
            ship_data = cursor.fetchall()
            if ship_data:
                df = pd.DataFrame([dict(row) for row in ship_data])
                st.bar_chart(df.set_index('category'))
        except:
            st.info("Henuz veri yok")

    conn.close()


# ==================== STORES PAGE ====================

def render_stores_page():
    """Render stores/publish targets management page"""
    st.title("🏪 Magazalar")
    st.markdown("*Urunlerinizi yayinlayacaginiz hedef magazalari yonetin*")

    conn = get_db()
    cursor = conn.cursor()

    # Create stores table if not exists
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS stores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            store_key TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            url TEXT,
            store_type TEXT,
            username TEXT,
            password TEXT,
            api_key TEXT,
            is_active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            last_used TEXT
        )
    """)
    conn.commit()

    # Auto-add CSS Berlin as default store if not exists
    cursor.execute("SELECT COUNT(*) FROM stores WHERE store_key = 'css_berlin'")
    if cursor.fetchone()[0] == 0:
        cursor.execute("""
            INSERT INTO stores (store_key, name, url, store_type, username, password, api_key, is_active)
            VALUES ('css_berlin', 'CSS Berlin', 'https://cssberlin.de', 'woocommerce', '', '', '', 1)
        """)
        conn.commit()

    # Get existing stores
    cursor.execute("SELECT * FROM stores ORDER BY is_active DESC, name")
    stores = cursor.fetchall()

    col1, col2 = st.columns([2, 1])

    with col1:
        st.subheader("📋 Kayitli Magazalar")

        if stores:
            for store in stores:
                status_icon = "🟢" if store['is_active'] else "🔴"
                is_cssberlin = store['store_key'] == 'css_berlin'
                store_label = f"{status_icon} {store['name']} ({store['store_type']})"
                if is_cssberlin:
                    store_label += " 🎯 PILOT"

                with st.expander(store_label, expanded=is_cssberlin):
                    col_a, col_b = st.columns(2)

                    with col_a:
                        st.markdown(f"**URL:** {store['url']}")
                        st.markdown(f"**Tip:** {store['store_type']}")

                        # CSS Berlin için GitHub Publisher bilgileri
                        if is_cssberlin:
                            st.markdown("---")
                            st.markdown("**🐙 GitHub Publisher:**")
                            st.markdown("✅ Repo: `CSS-Berlin-Website`")
                            st.markdown("✅ Dosya: `scraped-products.json`")
                            st.markdown("✅ Deploy: Cloudflare Pages")

                            # Test butonu
                            if GITHUB_PUBLISHER_AVAILABLE:
                                if st.button("🔌 Repo Test", key=f"test_github_{store['id']}"):
                                    try:
                                        publisher = GitHubPublisher()
                                        data = publisher.load_products()
                                        product_count = len(data.get('products', []))
                                        st.success(f"✅ Repo erisilebilir! {product_count} urun mevcut")
                                    except Exception as e:
                                        st.error(f"❌ Repo hatasi: {e}")
                            else:
                                st.warning("GitHub Publisher modülü yüklenemedi")

                        elif store['store_type'] == 'woocommerce':
                            # Diğer WooCommerce mağazalar (gelecekte)
                            st.markdown("---")
                            st.caption("WooCommerce entegrasyonu yakinda...")
                        else:
                            # Diğer mağazalar için normal login
                            st.markdown(f"**Kullanici:** {store['username'] or '-'}")

                        st.markdown(f"**Son Kullanim:** {store['last_used'] or 'Hic'}")

                    with col_b:
                        # Toggle active
                        new_status = not store['is_active']
                        status_label = "Deaktif Et" if store['is_active'] else "Aktif Et"
                        if st.button(status_label, key=f"toggle_{store['id']}"):
                            cursor.execute("UPDATE stores SET is_active = ? WHERE id = ?",
                                          (1 if new_status else 0, store['id']))
                            conn.commit()
                            st.rerun()

                        # Delete (CSS Berlin silinemez)
                        if not is_cssberlin:
                            if st.button("🗑️ Sil", key=f"del_store_{store['id']}"):
                                cursor.execute("DELETE FROM stores WHERE id = ?", (store['id'],))
                                conn.commit()
                                st.success(f"{store['name']} silindi!")
                                st.rerun()
                        else:
                            st.caption("🔒 Pilot magaza silinemez")

                        # CSS Berlin için bilgi
                        if is_cssberlin:
                            st.markdown("---")
                            st.info("""
**Nasil Calisir:**
1. Favorilerden 🚀 Yayinla tikla
2. Urun `scraped-products.json`'a eklenir
3. Git commit & push yapilir
4. Cloudflare Pages otomatik build eder
5. Site guncellenir (~1-2 dk)
                            """)
        else:
            st.info("Henuz kayitli magaza yok. Sagdan yeni magaza ekleyin.")

    with col2:
        st.subheader("➕ Yeni Magaza Ekle")

        with st.form("add_store_form"):
            # Quick add from predefined
            st.markdown("**Hizli Ekle (Hazir Sablonlar):**")
            template = st.selectbox(
                "Sablon Sec",
                ["Manuel Giris"] + [f"{v['icon']} {v['name']}" for k, v in PUBLISH_TARGETS.items()]
            )

            st.markdown("---")
            st.markdown("**Magaza Bilgileri:**")

            # Pre-fill if template selected
            if template != "Manuel Giris":
                # Find template
                for key, target in PUBLISH_TARGETS.items():
                    if target['name'] in template:
                        default_name = target['name']
                        default_url = target['url']
                        default_type = target['type']
                        break
            else:
                default_name = ""
                default_url = ""
                default_type = "woocommerce"

            store_name = st.text_input("Magaza Adi", value=default_name)
            store_url = st.text_input("URL", value=default_url)
            store_type = st.selectbox("Tip", ["woocommerce", "vinted", "ebay", "kleinanzeigen", "custom"],
                                      index=["woocommerce", "vinted", "ebay", "kleinanzeigen", "custom"].index(default_type) if default_type in ["woocommerce", "vinted", "ebay", "kleinanzeigen", "custom"] else 0)

            st.markdown("---")
            st.markdown("**Giris Bilgileri:**")
            username = st.text_input("Kullanici Adi / Email")
            password = st.text_input("Sifre", type="password")
            api_key = st.text_input("API Key (opsiyonel)")

            if st.form_submit_button("💾 Magaza Ekle", use_container_width=True):
                if store_name and store_url:
                    store_key = store_name.lower().replace(" ", "_")
                    try:
                        cursor.execute("""
                            INSERT INTO stores (store_key, name, url, store_type, username, password, api_key)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                        """, (store_key, store_name, store_url, store_type, username, password, api_key))
                        conn.commit()
                        st.success(f"✅ {store_name} eklendi!")
                        st.rerun()
                    except sqlite3.IntegrityError:
                        st.error("Bu magaza zaten mevcut!")
                else:
                    st.error("Magaza adi ve URL zorunlu!")

    st.markdown("---")

    # Publish history
    st.subheader("📊 Yayinlama Gecmisi")

    # Create publish_history table if not exists
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS publish_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER,
            store_id INTEGER,
            status TEXT,
            published_url TEXT,
            error_message TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id),
            FOREIGN KEY (store_id) REFERENCES stores(id)
        )
    """)
    conn.commit()

    cursor.execute("""
        SELECT
            ph.*,
            p.title as product_title,
            s.name as store_name
        FROM publish_history ph
        JOIN products p ON ph.product_id = p.id
        JOIN stores s ON ph.store_id = s.id
        ORDER BY ph.created_at DESC
        LIMIT 20
    """)
    history = cursor.fetchall()

    if history:
        for h in history:
            status_icon = "✅" if h['status'] == 'success' else "❌"
            st.markdown(f"{status_icon} **{h['product_title'][:30]}...** → {h['store_name']} ({h['created_at'][:16]})")
            if h['published_url']:
                st.caption(f"URL: {h['published_url']}")
            if h['error_message']:
                st.caption(f"Hata: {h['error_message']}")
    else:
        st.info("Henuz yayinlama gecmisi yok.")

    conn.close()


# ==================== SYSTEM MONITOR PAGE ====================

def render_system_page():
    """Render system monitor page with logs and errors"""
    st.title("🔧 Sistem Izleme")
    st.markdown("*Canli log takibi, hatalar ve self-healing durumu*")

    tab1, tab2, tab3 = st.tabs(["📊 Orchestrator", "📝 Loglar", "⚠️ Hatalar"])

    with tab1:
        st.subheader("Scrape Orchestrator Durumu")

        # Orchestrator status from API
        try:
            response = requests.get(f"{API_URL}/api/scrape/orchestrator/status", timeout=5)
            if response.status_code == 200:
                data = response.json()

                if data.get('status') == 'active':
                    st.success("🟢 Orchestrator AKTIF")

                    stats = data.get('stats', {})
                    col1, col2, col3, col4 = st.columns(4)

                    with col1:
                        st.metric("Toplam Is", stats.get('total_jobs', 0))
                    with col2:
                        st.metric("Basarili Kazima", stats.get('successful_scrapes', 0))
                    with col3:
                        st.metric("Basarisiz", stats.get('failed_scrapes', 0))
                    with col4:
                        st.metric("Onarilan Hata", stats.get('healed_errors', 0))

                    st.markdown("---")
                    st.subheader("Aktif Isler")

                    active_jobs = data.get('active_jobs', [])
                    if active_jobs:
                        for job in active_jobs:
                            status_icon = "🟢" if job['status'] == 'completed' else "🟡" if job['status'] == 'running' else "🔴"
                            with st.expander(f"{status_icon} {job.get('batch_id', 'unknown')} - {job.get('query', '')}"):
                                col1, col2, col3 = st.columns(3)
                                with col1:
                                    st.metric("Durum", job.get('status', 'unknown'))
                                with col2:
                                    st.metric("Ilerleme", f"{job.get('progress', 0)}%")
                                with col3:
                                    st.metric("Bulunan Urun", job.get('products_found', 0))

                                st.caption(f"Job ID: {job.get('job_id')} | Baslatma: {job.get('started_at', '-')}")

                                if job.get('errors'):
                                    st.error(f"Hatalar: {len(job['errors'])} adet")
                                    for err in job['errors'][:3]:
                                        st.code(str(err)[:200])
                    else:
                        st.info("Aktif is yok")
                else:
                    st.warning("🟡 Orchestrator INAKTIF")
                    st.info("API baslatildiginda orchestrator otomatik baslar.")
            else:
                st.error(f"API hatasi: {response.status_code}")
        except requests.exceptions.ConnectionError:
            st.error("❌ API'ye baglanilamadi!")
            st.info("💡 API'yi baslatmak icin: `python api/triaj_api.py`")
        except Exception as e:
            st.error(f"Hata: {str(e)}")

    with tab2:
        st.subheader("Sistem Loglari")

        col1, col2 = st.columns([3, 1])
        with col1:
            log_level = st.selectbox("Log Seviyesi", [None, "INFO", "WARNING", "ERROR"], index=0)
        with col2:
            log_limit = st.number_input("Satir Limiti", min_value=10, max_value=500, value=50)

        if st.button("🔄 Loglari Yenile", use_container_width=True):
            st.rerun()

        try:
            params = {'limit': log_limit}
            if log_level:
                params['level'] = log_level

            response = requests.get(f"{API_URL}/api/system/logs", params=params, timeout=5)
            if response.status_code == 200:
                data = response.json()
                logs = data.get('logs', [])

                if logs:
                    st.markdown(f"**{len(logs)} log satiri** - `{data.get('file', 'unknown')}`")

                    # Log container with fixed height
                    log_text = "\n".join(logs)
                    st.code(log_text, language="log")
                else:
                    st.info("Log bulunamadi")
            else:
                st.warning("Log alinamadi")
        except requests.exceptions.ConnectionError:
            st.warning("API baglantisi yok - loglar API uzerinden okunur")

            # Fallback: Dogrudan dosyadan oku
            log_file = Path(__file__).parent.parent / 'storage' / 'scrape_orchestrator.log'
            if log_file.exists():
                try:
                    with open(log_file, 'r', encoding='utf-8') as f:
                        lines = f.readlines()[-log_limit:]
                    st.code("".join(lines), language="log")
                except:
                    st.info("Log dosyasi okunamadi")
            else:
                st.info("Log dosyasi henuz olusturulmamis")
        except Exception as e:
            st.error(f"Hata: {str(e)}")

    with tab3:
        st.subheader("Son Hatalar")

        try:
            response = requests.get(f"{API_URL}/api/system/errors", timeout=5)
            if response.status_code == 200:
                data = response.json()
                errors = data.get('errors', [])

                if errors:
                    st.warning(f"⚠️ {len(errors)} hata kayitli")

                    for i, err in enumerate(errors):
                        with st.expander(f"Hata #{i+1} - {err.get('job_id', 'unknown')}"):
                            st.markdown(f"**Batch:** {err.get('batch_id', '-')}")
                            st.code(json.dumps(err.get('error', {}), indent=2, ensure_ascii=False))
                else:
                    st.success("✅ Hata yok!")
            else:
                st.info("Hata verisi alinamadi")
        except requests.exceptions.ConnectionError:
            st.warning("API baglantisi yok")
        except Exception as e:
            st.error(f"Hata: {str(e)}")

        st.markdown("---")
        st.subheader("Self-Healing Durumu")

        # Event Bus stats
        try:
            conn = get_db()
            cursor = conn.cursor()

            # selector_failed events
            cursor.execute("""
                SELECT COUNT(*) FROM event_log
                WHERE event_type = 'selector_failed'
                AND timestamp > datetime('now', '-24 hours')
            """)
            failed_24h = cursor.fetchone()[0]

            # operation_retry events
            cursor.execute("""
                SELECT COUNT(*) FROM event_log
                WHERE event_type = 'operation_retry'
                AND timestamp > datetime('now', '-24 hours')
            """)
            retry_24h = cursor.fetchone()[0]

            conn.close()

            col1, col2 = st.columns(2)
            with col1:
                st.metric("Son 24 Saat Selector Hatasi", failed_24h)
            with col2:
                st.metric("Son 24 Saat Retry", retry_24h)

        except Exception as e:
            st.info("Event verisi alinamadi")


# ==================== SCHEDULER PAGE ====================

def get_scheduler_category_options():
    """Kategori seçeneklerini oluştur"""
    options = {}

    if MAPPER_AVAILABLE:
        for main_key, main_data in CATEGORY_TREE.items():
            main_label = main_data.get('label', main_key)

            if 'children' in main_data:
                for sub_key, sub_data in main_data['children'].items():
                    sub_label = sub_data.get('label', sub_key)
                    display = f"{main_label} > {sub_label}"
                    options[display] = sub_key

                    if 'children' in sub_data:
                        for nested_key, nested_data in sub_data['children'].items():
                            nested_label = nested_data.get('label', nested_key)
                            display = f"{main_label} > {sub_label} > {nested_label}"
                            options[display] = nested_key
    else:
        options = {
            'Herren > Mäntel & Jacken': 'herren_mantel',
            'Herren > Schuhe': 'herren_schuhe',
            'Herren > Pullover': 'herren_pullover',
            'Herren > Hosen': 'herren_hosen',
            'Damen > Mäntel & Jacken': 'damen_mantel',
            'Damen > Schuhe': 'damen_schuhe',
            'Damen > Kleider': 'damen_kleider',
        }

    return options


def get_scheduler_brand_options():
    """Marka seçeneklerini oluştur"""
    if MAPPER_AVAILABLE:
        return {info['name']: key for key, info in BRAND_DATABASE.items()}
    else:
        return {
            'Hugo Boss': 'hugo_boss',
            'Tommy Hilfiger': 'tommy_hilfiger',
            'Ralph Lauren': 'ralph_lauren',
            'Nike': 'nike',
            'Adidas': 'adidas',
            'Puma': 'puma',
            'The North Face': 'the_north_face',
            "Levi's": 'levis',
            'Zara': 'zara',
            'H&M': 'hm',
        }


def get_scheduler_platform_options():
    """Platform seçeneklerini oluştur"""
    platforms = {
        'Willhaben (AT)': 'willhaben',
        'eBay.de': 'ebay',
        'Kleinanzeigen.de': 'kleinanzeigen',
        'Vinted.de': 'vinted',
        'Sellpy': 'sellpy',
        'Tradera (SE)': 'tradera',
        'Percentil': 'percentil',
    }

    if SCHEDULER_AVAILABLE:
        available = AVAILABLE_SCRAPERS.keys()
        return {
            f"{name} {'✓' if key in available else '○'}": key
            for name, key in platforms.items()
        }

    return platforms


def format_scheduler_duration(seconds):
    """Süreyi formatla"""
    if not seconds:
        return 'N/A'
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        return f"{seconds // 60}m {seconds % 60}s"
    else:
        return f"{seconds // 3600}h {(seconds % 3600) // 60}m"


def render_scheduler_page():
    """TATANGA v3 Scheduler Sayfası"""
    st.header("🗓️ TATANGA v3 Scheduler")

    if not SCHEDULER_AVAILABLE:
        st.error("Task Scheduler modülü yüklenemedi. Lütfen import'ları kontrol edin.")
        st.info("task_scheduler.py dosyasının active_pieces klasöründe olduğundan emin olun.")
        return

    # Initialize scheduler service
    if 'scheduler_service' not in st.session_state:
        st.session_state.scheduler_service = SchedulerService()

    scheduler = st.session_state.scheduler_service

    # Scheduler status sidebar info
    status = scheduler.get_status()

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        if status['is_running']:
            st.success("🟢 Scheduler Çalışıyor")
        else:
            st.warning("🔴 Scheduler Durdu")
    with col2:
        st.metric("Aktif Task", status['active_tasks'])
    with col3:
        st.metric("Toplam Task", status['total_tasks'])
    with col4:
        col_start, col_stop = st.columns(2)
        with col_start:
            if st.button("▶️ Başlat", use_container_width=True):
                scheduler.start()
                st.rerun()
        with col_stop:
            if st.button("⏹️ Durdur", use_container_width=True):
                scheduler.stop()
                st.rerun()

    st.divider()

    # Tab navigation
    scheduler_tab = st.tabs(["📋 Tasks", "➕ Yeni Task", "📊 Ürünler", "📈 İstatistikler"])

    # ===== TASKS TAB =====
    with scheduler_tab[0]:
        st.subheader("Zamanlanmış Tasklar")

        tasks = scheduler.get_tasks()

        if not tasks:
            st.info("Henüz task oluşturulmadı. 'Yeni Task' sekmesinden oluşturabilirsiniz.")
        else:
            for task in tasks:
                with st.expander(
                    f"{'🟢' if task['is_active'] else '⚪'} {task['name']} - {task['schedule_value']}",
                    expanded=False
                ):
                    col1, col2, col3 = st.columns([2, 2, 1])

                    with col1:
                        st.write(f"**Kategori:** {task['category']}")
                        st.write(f"**Markalar:** {', '.join(task['brands'])}")
                        st.write(f"**Platformlar:** {', '.join(task['platforms'])}")

                    with col2:
                        st.write(f"**Schedule:** {task['schedule_value']}")
                        st.write(f"**Toplam Çalışma:** {task['total_runs']}")
                        st.write(f"**Bulunan Ürün:** {task['total_products_found']}")

                        if task['last_run_at']:
                            st.write(f"**Son Çalışma:** {task['last_run_at'][:19]}")

                    with col3:
                        if st.button("▶️ Şimdi Çalıştır", key=f"run_{task['id']}", use_container_width=True):
                            with st.spinner("Task çalışıyor..."):
                                result = scheduler.run_task_now(task['id'])
                                if result.get('success'):
                                    st.success(f"✅ {result['products_found']} ürün bulundu!")
                                else:
                                    st.error(result.get('error', 'Bilinmeyen hata'))
                            st.rerun()

                        if task['is_active']:
                            if st.button("⏸️ Duraklat", key=f"pause_{task['id']}", use_container_width=True):
                                scheduler.pause_task(task['id'])
                                st.rerun()
                        else:
                            if st.button("▶️ Devam Et", key=f"resume_{task['id']}", use_container_width=True):
                                scheduler.resume_task(task['id'])
                                st.rerun()

                        if st.button("🗑️ Sil", key=f"delete_{task['id']}", use_container_width=True):
                            scheduler.remove_task(task['id'])
                            st.rerun()

                    st.markdown("---")
                    st.write("**Son Çalışmalar:**")

                    runs = scheduler.get_task_runs(task['id'], limit=5)

                    if runs:
                        runs_df = pd.DataFrame(runs)
                        runs_df = runs_df[['started_at', 'status', 'products_found', 'duration_seconds']]
                        runs_df.columns = ['Başlangıç', 'Durum', 'Ürün', 'Süre']
                        runs_df['Süre'] = runs_df['Süre'].apply(format_scheduler_duration)
                        st.dataframe(runs_df, use_container_width=True)
                    else:
                        st.write("Henüz çalışma yok")

    # ===== CREATE TASK TAB =====
    with scheduler_tab[1]:
        st.subheader("Yeni Task Oluştur")

        with st.form("create_scheduler_task_form"):
            task_name = st.text_input(
                "Task Adı",
                placeholder="örn: Herren Mäntel Premium Brands"
            )

            col1, col2 = st.columns(2)

            with col1:
                st.markdown("#### Kategori")
                category_options = get_scheduler_category_options()
                selected_category_display = st.selectbox(
                    "Kategori Seç",
                    options=list(category_options.keys())
                )
                selected_category = category_options.get(selected_category_display)

            with col2:
                st.markdown("#### Zamanlama")
                schedule_type = st.selectbox(
                    "Zamanlama Tipi",
                    ["Her X saatte", "Her X dakikada", "Günlük"]
                )

                if schedule_type == "Her X saatte":
                    hours = st.slider("Saat", 1, 24, 4)
                    schedule_value = f"{hours}h"
                elif schedule_type == "Her X dakikada":
                    minutes = st.slider("Dakika", 15, 120, 30)
                    schedule_value = f"{minutes}m"
                else:
                    schedule_value = "24h"

            st.markdown("#### Markalar")
            brand_options = get_scheduler_brand_options()

            col1, col2 = st.columns(2)
            with col1:
                selected_brands_display = st.multiselect(
                    "Marka Seç",
                    options=list(brand_options.keys()),
                    default=list(brand_options.keys())[:3] if brand_options else []
                )
            with col2:
                custom_brands = st.text_input(
                    "Özel Markalar (virgülle ayır)",
                    placeholder="Marka1, Marka2"
                )

            selected_brands = [brand_options[b] for b in selected_brands_display]
            if custom_brands:
                custom_list = [b.strip() for b in custom_brands.split(',') if b.strip()]
                selected_brands.extend(custom_list)

            st.markdown("#### Platformlar")
            platform_options = get_scheduler_platform_options()

            selected_platforms_display = st.multiselect(
                "Platform Seç",
                options=list(platform_options.keys()),
                default=[k for k in list(platform_options.keys()) if '✓' in k][:2]
            )
            selected_platforms = [platform_options[p] for p in selected_platforms_display]

            st.markdown("#### Filtreler (Opsiyonel)")
            col1, col2 = st.columns(2)

            with col1:
                price_min = st.number_input("Min Fiyat (€)", min_value=0, value=0)
            with col2:
                price_max = st.number_input("Max Fiyat (€)", min_value=0, value=0)

            filters = {}
            if price_min > 0:
                filters['price_min'] = price_min
            if price_max > 0:
                filters['price_max'] = price_max

            submitted = st.form_submit_button("Task Oluştur", use_container_width=True)

            if submitted:
                if not task_name:
                    st.error("Lütfen task adı girin")
                elif not selected_brands:
                    st.error("En az bir marka seçin")
                elif not selected_platforms:
                    st.error("En az bir platform seçin")
                else:
                    task_id = scheduler.add_task(
                        name=task_name,
                        category=selected_category,
                        brands=selected_brands,
                        platforms=selected_platforms,
                        filters=filters if filters else None,
                        schedule=schedule_value
                    )

                    st.success(f"✅ Task oluşturuldu! ID: {task_id}")
                    st.balloons()

    # ===== PRODUCTS TAB =====
    with scheduler_tab[2]:
        st.subheader("Kazınan Ürünler")

        col1, col2, col3 = st.columns(3)

        with col1:
            tasks = scheduler.get_tasks()
            task_options = {"Tüm Tasklar": None}
            task_options.update({t['name']: t['id'] for t in tasks})
            selected_task_filter = st.selectbox("Task'a Göre Filtrele", list(task_options.keys()))
            task_id_filter = task_options[selected_task_filter]

        with col2:
            platform_filter = st.selectbox(
                "Platforma Göre Filtrele",
                ["Tüm Platformlar", "willhaben", "ebay", "kleinanzeigen", "vinted"]
            )
            platform_filter = None if platform_filter == "Tüm Platformlar" else platform_filter

        with col3:
            limit = st.slider("Max Ürün", 10, 500, 100)

        products = scheduler.get_products(
            task_id=task_id_filter,
            platform=platform_filter,
            limit=limit
        )

        if not products:
            st.info("Henüz ürün bulunamadı. Bir task çalıştırarak ürün kazıyın.")
        else:
            st.write(f"**{len(products)} ürün bulundu**")

            cols = st.columns(4)
            for i, product in enumerate(products):
                with cols[i % 4]:
                    with st.container():
                        if product.get('image'):
                            st.image(product['image'], use_container_width=True)
                        else:
                            st.image("https://via.placeholder.com/200x200?text=No+Image", use_container_width=True)

                        title = product['title'][:50] + '...' if len(product['title']) > 50 else product['title']
                        st.write(f"**{title}**")

                        if product.get('price'):
                            st.write(f"💰 {product['price']} {product.get('currency', 'EUR')}")

                        platform = product.get('platform', 'unknown')
                        st.caption(f"📍 {platform}")

                        if product.get('url'):
                            st.markdown(f"[Görüntüle →]({product['url']})")

                        st.divider()

    # ===== STATISTICS TAB =====
    with scheduler_tab[3]:
        st.subheader("İstatistikler & Analiz")

        status = scheduler.get_status()
        tasks = scheduler.get_tasks()

        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric("Toplam Task", status['total_tasks'])
        with col2:
            st.metric("Aktif Task", status['active_tasks'])
        with col3:
            total_runs = sum(t['total_runs'] for t in tasks)
            st.metric("Toplam Çalışma", total_runs)
        with col4:
            total_products = sum(t['total_products_found'] for t in tasks)
            st.metric("Toplam Ürün", total_products)

        st.divider()

        if tasks:
            st.markdown("#### Task Performansı")

            task_data = []
            for task in tasks:
                task_data.append({
                    'Task': task['name'],
                    'Kategori': task['category'],
                    'Çalışma': task['total_runs'],
                    'Ürün': task['total_products_found'],
                    'Ort/Çalışma': round(task['total_products_found'] / max(task['total_runs'], 1), 1),
                    'Durum': '🟢' if task['is_active'] else '⚪'
                })

            df = pd.DataFrame(task_data)
            st.dataframe(df, use_container_width=True)

            if len(task_data) > 0:
                try:
                    import plotly.express as px

                    fig = px.bar(
                        df,
                        x='Task',
                        y='Ürün',
                        color='Kategori',
                        title='Task Başına Ürün Sayısı'
                    )
                    st.plotly_chart(fig, use_container_width=True)
                except ImportError:
                    st.info("Grafik için plotly gerekli: pip install plotly")

        st.divider()
        st.markdown("#### Mevcut Scraper'lar")

        available = status.get('available_scrapers', [])
        if available:
            cols = st.columns(len(available))
            for i, scraper in enumerate(available):
                with cols[i]:
                    st.success(f"✓ {scraper}")
        else:
            st.info("Henüz scraper yüklenmemiş")


# ==================== DELETED PRODUCTS PAGE ====================

def render_deleted_products_page():
    """Silinen Ürünler sayfası - Sistemin çalıştığını izleme"""
    st.title("🗑️ Silinen Ürünler")
    st.caption("Satılmış veya artık mevcut olmayan ürünlerin kaydı")

    # Connect to database
    conn = sqlite3.connect(DB_PATH)

    # Check if deleted_products table exists, create if not
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS deleted_products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_id INTEGER,
            title TEXT,
            source_url TEXT,
            deletion_reason TEXT,
            deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            deleted_from TEXT,
            verified INTEGER DEFAULT 0,
            verification_date TIMESTAMP
        )
    """)
    conn.commit()

    # Add verified column if it doesn't exist (for older databases)
    try:
        cursor.execute("ALTER TABLE deleted_products ADD COLUMN verified INTEGER DEFAULT 0")
        conn.commit()
    except:
        pass  # Column already exists
    try:
        cursor.execute("ALTER TABLE deleted_products ADD COLUMN verification_date TIMESTAMP")
        conn.commit()
    except:
        pass  # Column already exists

    # Get stats
    cursor.execute("SELECT COUNT(*) FROM deleted_products")
    total_deleted = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM deleted_products WHERE verified = 1")
    verified_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM deleted_products WHERE deletion_reason LIKE '%sold%' OR deletion_reason LIKE '%Sold%' OR deletion_reason LIKE '%verkauft%'")
    sold_count = cursor.fetchone()[0]

    # Stats row
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Toplam Silinen", total_deleted)
    col2.metric("Satıldı", sold_count, help="Satıldı olarak işaretlenen")
    col3.metric("Doğrulandı", verified_count, help="URL kontrol edildi")
    col4.metric("Bekliyor", total_deleted - verified_count)

    st.divider()

    # Filters
    col1, col2, col3 = st.columns([2, 2, 1])
    with col1:
        filter_reason = st.selectbox(
            "Silinme Nedeni",
            ["Tümü", "Satıldı", "Mevcut Değil", "404", "Manuel"]
        )
    with col2:
        filter_from = st.selectbox(
            "Nereden Silindi",
            ["Tümü", "Favoriler", "CSS Berlin", "Her İkisi"]
        )
    with col3:
        show_unverified = st.checkbox("Sadece Doğrulanmamış", value=False)

    # Build query
    query = "SELECT * FROM deleted_products WHERE 1=1"
    params = []

    if filter_reason != "Tümü":
        if filter_reason == "Satıldı":
            query += " AND (deletion_reason LIKE ? OR deletion_reason LIKE ?)"
            params.extend(['%sold%', '%verkauft%'])
        elif filter_reason == "Mevcut Değil":
            query += " AND deletion_reason LIKE ?"
            params.append('%nicht mehr%')
        elif filter_reason == "404":
            query += " AND deletion_reason LIKE ?"
            params.append('%404%')
        elif filter_reason == "Manuel":
            query += " AND deletion_reason LIKE ?"
            params.append('%manuel%')

    if filter_from != "Tümü":
        query += " AND deleted_from LIKE ?"
        params.append(f'%{filter_from}%')

    if show_unverified:
        query += " AND verified = 0"

    query += " ORDER BY deleted_at DESC LIMIT 100"

    # Fetch data
    df = pd.read_sql_query(query, conn, params=params)

    if df.empty:
        st.info("📭 Henüz silinen ürün kaydı yok")

        # Add sample data button for testing
        if st.button("🧪 Test Verisi Ekle"):
            test_data = [
                (1, "Nike Air Max 90", "https://www.ebay.de/itm/123456", "Sold: verkauft", "Favoriler", 1),
                (2, "Adidas Superstar", "https://www.vinted.de/items/789", "404 Not Found", "CSS Berlin", 0),
                (3, "Tommy Hilfiger Pullover", "https://www.kleinanzeigen.de/s-anzeige/111", "Sold: reserviert", "Her İkisi", 1),
            ]
            for data in test_data:
                cursor.execute("""
                    INSERT INTO deleted_products (original_id, title, source_url, deletion_reason, deleted_from, verified)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, data)
            conn.commit()
            st.success("Test verileri eklendi!")
            st.rerun()
    else:
        # Display as table
        st.dataframe(
            df[['id', 'title', 'source_url', 'deletion_reason', 'deleted_at', 'deleted_from', 'verified']],
            column_config={
                'id': st.column_config.NumberColumn('ID', width='small'),
                'title': st.column_config.TextColumn('Başlık', width='medium'),
                'source_url': st.column_config.LinkColumn('Kaynak URL', width='large'),
                'deletion_reason': st.column_config.TextColumn('Silinme Nedeni', width='medium'),
                'deleted_at': st.column_config.DatetimeColumn('Tarih', width='medium'),
                'deleted_from': st.column_config.TextColumn('Nereden', width='small'),
                'verified': st.column_config.CheckboxColumn('Doğrulandı', width='small')
            },
            use_container_width=True,
            hide_index=True
        )

        # Verification section
        st.divider()
        st.subheader("🔍 URL Doğrulama")

        col1, col2 = st.columns([3, 1])
        with col1:
            st.caption("Seçilen ürünlerin kaynak URL'lerini kontrol ederek gerçekten satılmış/mevcut değil olduğunu doğrulayın.")
        with col2:
            if st.button("🔍 Tümünü Doğrula", type="primary"):
                unverified = df[df['verified'] == 0]
                if unverified.empty:
                    st.info("Tüm ürünler zaten doğrulanmış")
                else:
                    progress = st.progress(0)
                    status_text = st.empty()

                    for idx, (_, row) in enumerate(unverified.iterrows()):
                        status_text.text(f"Kontrol ediliyor: {row['title'][:30]}...")
                        progress.progress((idx + 1) / len(unverified))

                        # Check URL
                        try:
                            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
                            response = requests.get(row['source_url'], headers=headers, timeout=10, allow_redirects=True)

                            # Mark as verified
                            cursor.execute("""
                                UPDATE deleted_products
                                SET verified = 1, verification_date = ?
                                WHERE id = ?
                            """, (datetime.now().isoformat(), row['id']))
                            conn.commit()

                        except Exception as e:
                            pass  # Still mark as verified (we tried)

                    st.success(f"✅ {len(unverified)} ürün doğrulandı!")
                    st.rerun()

        # Manual entry section
        st.divider()
        with st.expander("➕ Manuel Kayıt Ekle"):
            col1, col2 = st.columns(2)
            with col1:
                manual_title = st.text_input("Ürün Başlığı")
                manual_url = st.text_input("Kaynak URL")
            with col2:
                manual_reason = st.selectbox(
                    "Silinme Nedeni",
                    ["Sold: verkauft", "404 Not Found", "Mevcut değil", "Manuel silindi"]
                )
                manual_from = st.selectbox(
                    "Nereden Silindi",
                    ["Favoriler", "CSS Berlin", "Her İkisi"]
                )

            if st.button("Kaydet"):
                if manual_title and manual_url:
                    cursor.execute("""
                        INSERT INTO deleted_products (title, source_url, deletion_reason, deleted_from)
                        VALUES (?, ?, ?, ?)
                    """, (manual_title, manual_url, manual_reason, manual_from))
                    conn.commit()
                    st.success("Kayıt eklendi!")
                    st.rerun()
                else:
                    st.warning("Başlık ve URL gerekli")

    conn.close()


# ==================== MAIN ====================

def main():
    """Main application entry point - TATANGA v3.0"""
    page = render_sidebar()

    if "Arama" in page:
        render_search_page()
    elif "Gelen Kutusu" in page:
        render_inbox_page()
    elif "Favoriler" in page:
        render_favorites_page()
    elif "Magazalar" in page:
        render_stores_page()
    elif "Silinen" in page:
        render_deleted_products_page()


if __name__ == "__main__":
    main()
