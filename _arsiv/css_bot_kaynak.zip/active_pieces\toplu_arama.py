#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Toplu Platform Araması
Tüm platformlarda çoklu anahtar kelime araması yapar

Özellikler:
- Anahtar kelimeleri her platformun diline çevirir
- TÜM ÜRÜNLERİ ÇEK - Filtreleme sonradan yapılır
- Tekrar eden ürünleri filtreler
- Sonuçları düzenli şekilde gösterir
"""

import sys
import json
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Set
from dataclasses import dataclass

# Output log for Windows compatibility
LOG_FILE = Path(__file__).parent / 'storage' / 'arama_log.txt'
LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

def log(msg: str):
    """Print and log message"""
    try:
        print(msg)
    except:
        pass
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(msg + '\n')

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent))

from integrations.universal_scraper import UniversalScraper, CONDITION_MAP

# ============================================================================
# KEYWORD TRANSLATIONS
# ============================================================================

# Anahtar kelime çevirileri (her dil için)
KEYWORD_TRANSLATIONS = {
    'timberland stiefel': {
        'de': 'timberland stiefel',
        'en': 'timberland boots',
        'fr': 'bottes timberland',
        'es': 'botas timberland',
        'it': 'stivali timberland',
        'nl': 'timberland laarzen',
        'pl': 'buty timberland',
        'sv': 'timberland stövlar',
        'da': 'timberland støvler',
        'no': 'timberland støvler',
        'cs': 'boty timberland',
        'fi': 'timberland saappaat',
    },
    'guess mont': {
        'de': 'guess mantel',
        'en': 'guess coat',
        'fr': 'manteau guess',
        'es': 'abrigo guess',
        'it': 'cappotto guess',
        'nl': 'guess jas',
        'pl': 'plaszcz guess',
        'sv': 'guess kappa',
        'da': 'guess frakke',
        'no': 'guess jakke',
        'cs': 'kabat guess',
        'fi': 'guess takki',
    },
    'ugg damen stiefel': {
        'de': 'ugg damen stiefel',
        'en': 'ugg women boots',
        'fr': 'bottes ugg femme',
        'es': 'botas ugg mujer',
        'it': 'stivali ugg donna',
        'nl': 'ugg dames laarzen',
        'pl': 'buty ugg damskie',
        'sv': 'ugg dam stövlar',
        'da': 'ugg dame støvler',
        'no': 'ugg dame støvler',
        'cs': 'boty ugg dámské',
        'fi': 'ugg naisten saappaat',
    },
    'columbia stiefel': {
        'de': 'columbia stiefel',
        'en': 'columbia boots',
        'fr': 'bottes columbia',
        'es': 'botas columbia',
        'it': 'stivali columbia',
        'nl': 'columbia laarzen',
        'pl': 'buty columbia',
        'sv': 'columbia stövlar',
        'da': 'columbia støvler',
        'no': 'columbia støvler',
        'cs': 'boty columbia',
        'fi': 'columbia saappaat',
    },
    'adidas terrex herren schuhe': {
        'de': 'adidas terrex herren',
        'en': 'adidas terrex men shoes',
        'fr': 'chaussures adidas terrex homme',
        'es': 'zapatillas adidas terrex hombre',
        'it': 'scarpe adidas terrex uomo',
        'nl': 'adidas terrex heren schoenen',
        'pl': 'buty adidas terrex meskie',
        'sv': 'adidas terrex herr skor',
        'da': 'adidas terrex herre sko',
        'no': 'adidas terrex herre sko',
        'cs': 'boty adidas terrex pánské',
        'fi': 'adidas terrex miesten kengät',
    },
    'tommy hilfiger mantel': {
        'de': 'tommy hilfiger mantel',
        'en': 'tommy hilfiger coat',
        'fr': 'manteau tommy hilfiger',
        'es': 'abrigo tommy hilfiger',
        'it': 'cappotto tommy hilfiger',
        'nl': 'tommy hilfiger jas',
        'pl': 'plaszcz tommy hilfiger',
        'sv': 'tommy hilfiger kappa',
        'da': 'tommy hilfiger frakke',
        'no': 'tommy hilfiger jakke',
        'cs': 'kabat tommy hilfiger',
        'fi': 'tommy hilfiger takki',
    },
    'burberry mantel': {
        'de': 'burberry mantel',
        'en': 'burberry coat',
        'fr': 'manteau burberry',
        'es': 'abrigo burberry',
        'it': 'cappotto burberry',
        'nl': 'burberry jas',
        'pl': 'plaszcz burberry',
        'sv': 'burberry kappa',
        'da': 'burberry frakke',
        'no': 'burberry jakke',
        'cs': 'kabat burberry',
        'fi': 'burberry takki',
    },
    'zara mantel': {
        'de': 'zara mantel',
        'en': 'zara coat',
        'fr': 'manteau zara',
        'es': 'abrigo zara',
        'it': 'cappotto zara',
        'nl': 'zara jas',
        'pl': 'plaszcz zara',
        'sv': 'zara kappa',
        'da': 'zara frakke',
        'no': 'zara jakke',
        'cs': 'kabat zara',
        'fi': 'zara takki',
    },
    'calvin klein mantel': {
        'de': 'calvin klein mantel',
        'en': 'calvin klein coat',
        'fr': 'manteau calvin klein',
        'es': 'abrigo calvin klein',
        'it': 'cappotto calvin klein',
        'nl': 'calvin klein jas',
        'pl': 'plaszcz calvin klein',
        'sv': 'calvin klein kappa',
        'da': 'calvin klein frakke',
        'no': 'calvin klein jakke',
        'cs': 'kabat calvin klein',
        'fi': 'calvin klein takki',
    },
}

# Platform -> Dil eşleştirmesi
PLATFORM_LANGUAGES = {
    'vinted_de': 'de',
    'vinted_fr': 'fr',
    'vinted_uk': 'en',
    'vinted_es': 'es',
    'vinted_it': 'it',
    'vinted_nl': 'nl',
    'vinted_be': 'nl',
    'vinted_pl': 'pl',
    'vinted_cz': 'cs',
    'vinted_at': 'de',
    'vinted_se': 'sv',
    'vinted_dk': 'da',
    'vinted_no': 'no',
    'ebay_de': 'de',
    'ebay_uk': 'en',
    'kleinanzeigen': 'de',
    'willhaben': 'de',
    'tradera': 'sv',
    'shpock_de': 'de',
    'shpock_at': 'de',
    'shpock_uk': 'en',
    'leboncoin': 'fr',
    'finn_no': 'no',
    'blocket_se': 'sv',
    'tori_fi': 'fi',
    'dba_dk': 'da',
    # YENİ: Sellpy ve Percentil
    'sellpy_de': 'de',
    'percentil_de': 'de',
}

# Aktif platformlar (arama yapilacak)
# TUM PLATFORMLAR - Maksimum veri toplama
ACTIVE_PLATFORMS = [
    # Vinted (13 ülke) - en büyük pazar
    'vinted_de', 'vinted_fr', 'vinted_uk', 'vinted_es', 'vinted_it',
    'vinted_nl', 'vinted_be', 'vinted_pl', 'vinted_cz', 'vinted_at',
    'vinted_se', 'vinted_dk', 'vinted_no',
    # Shpock (3 ülke)
    'shpock_de', 'shpock_at', 'shpock_uk',
    # Leboncoin (Fransa)
    'leboncoin',
    # YENİ: Sellpy (Premium ikinci el moda)
    'sellpy_de',
    # YENİ: Percentil (Çocuk ve yetişkin ikinci el)
    'percentil_de',
]


@dataclass
class SearchResult:
    """Arama sonucu"""
    title: str
    price: float
    currency: str
    url: str
    platform: str
    condition: str
    brand: str
    image_url: str
    seller_name: str
    search_query: str
    fingerprint: str  # Tekrar tespiti için


def generate_fingerprint(title: str, price: float, brand: str) -> str:
    """Ürün parmak izi oluştur (tekrar tespiti için)"""
    # Başlıktan marka ve gereksiz kelimeleri temizle
    clean_title = title.lower()
    for word in ['neu', 'new', 'neuf', 'nuevo', 'nuovo', 'nieuw', 'nowy', 'ny', 'uusi']:
        clean_title = clean_title.replace(word, '')

    # Hash oluştur
    data = f"{clean_title[:50]}|{price:.0f}|{brand.lower()}"
    return hashlib.md5(data.encode()).hexdigest()[:12]


def get_translated_keyword(keyword: str, platform: str) -> str:
    """Anahtar kelimeyi platform diline çevir"""
    lang = PLATFORM_LANGUAGES.get(platform, 'en')
    translations = KEYWORD_TRANSLATIONS.get(keyword, {})
    return translations.get(lang, keyword)


def is_very_good_condition(condition: str, platform: str) -> bool:
    """Ürün durumunun 'çok iyi' olup olmadığını kontrol et"""
    if not condition:
        return True  # Condition yoksa kabul et

    condition_lower = condition.lower()

    # Platform bazlı kontrol
    platform_conditions = CONDITION_MAP.get(platform, {})
    very_good_value = platform_conditions.get('very_good', '').lower()
    like_new_value = platform_conditions.get('like_new', '').lower()
    new_value = platform_conditions.get('new', '').lower()

    # Çok iyi, yeni gibi veya yeni kabul edilir
    acceptable = [very_good_value, like_new_value, new_value]

    # Genel terimler
    general_good = [
        'sehr gut', 'very good', 'très bon', 'muy bueno', 'ottime',
        'zeer goed', 'bardzo dobry', 'mycket bra', 'meget god', 'veldig bra',
        'velmi dobrý', 'hyvä', 'erinomainen',
        'neu', 'new', 'neuf', 'nuevo', 'nuovo', 'nieuw', 'nowy', 'ny', 'uusi',
        'wie neu', 'like new', 'comme neuf', 'como nuevo', 'come nuovo'
    ]

    for term in acceptable + general_good:
        if term and term in condition_lower:
            return True

    return False


def run_multi_platform_search():
    """Çoklu platform araması çalıştır"""
    # Clear log file
    with open(LOG_FILE, 'w', encoding='utf-8') as f:
        f.write(f"ARAMA BASLANGICI: {datetime.now()}\n\n")

    log("=" * 80)
    log("  TATANGA - TOPLU PLATFORM ARAMASI")
    log("  TUM URUNLER - Filtresiz Arama (Condition filtresi KAPALI)")
    log("=" * 80)
    log("")

    # Aranacak anahtar kelimeler
    keywords = list(KEYWORD_TRANSLATIONS.keys())

    log(f"Aranacak Urunler ({len(keywords)} adet):")
    for kw in keywords:
        log(f"  - {kw}")
    log("")

    log(f"Aranacak Platformlar ({len(ACTIVE_PLATFORMS)} adet):")
    for p in ACTIVE_PLATFORMS:
        log(f"  - {p}")
    log("")

    # Scraper baslat
    scraper = UniversalScraper(max_workers=2)

    all_results: List[SearchResult] = []
    seen_fingerprints: Set[str] = set()

    total_searches = len(keywords) * len(ACTIVE_PLATFORMS)
    current = 0

    log("Arama basliyor...")
    log("-" * 80)

    for keyword in keywords:
        log(f"\n[{keyword.upper()}] araniyor...")

        for platform in ACTIVE_PLATFORMS:
            current += 1

            # Cevrilmis anahtar kelime
            translated = get_translated_keyword(keyword, platform)

            try:
                # Arama yap - TUM URUNLERI CEK (condition filtresi YOK)
                results = scraper.search(
                    platform=platform,
                    query=translated,
                    filters={},  # CONDITION FILTRESI KALDIRILDI
                    max_results=50  # Daha fazla sonuc al
                )

                found = 0
                for item in results:
                    # TUM URUNLERI AL - Condition filtresi KAPALI
                    # Condition bilgisini sakla ama filtreleme
                    condition = item.get('condition', '')
                    # NOT: is_very_good_condition kontrolu KALDIRILDI
                    # Tum urunler alinacak, filtreleme sonradan yapilacak

                    # Parmak izi olustur
                    title = item.get('title', '')
                    # None-safe price conversion
                    raw_price = item.get('price')
                    price = float(raw_price) if raw_price is not None else 0.0
                    brand = item.get('brand', keyword.split()[0])

                    fingerprint = generate_fingerprint(title, price, brand)

                    # Tekrar kontrolu
                    if fingerprint in seen_fingerprints:
                        continue

                    seen_fingerprints.add(fingerprint)

                    # Sonuc ekle
                    result = SearchResult(
                        title=title,
                        price=price,
                        currency=item.get('currency', 'EUR'),
                        url=item.get('url', ''),
                        platform=platform,
                        condition=condition,
                        brand=brand,
                        image_url=item.get('image', ''),
                        seller_name=item.get('seller_name', ''),
                        search_query=keyword,
                        fingerprint=fingerprint
                    )
                    all_results.append(result)
                    found += 1

                log(f"  [{current}/{total_searches}] {platform}: '{translated}' -> {found} yeni urun")

            except Exception as e:
                log(f"  [{current}/{total_searches}] {platform}: '{translated}' -> HATA: {e}")

    log("")
    log("=" * 80)
    log(f"  ARAMA TAMAMLANDI!")
    log(f"  Toplam {len(all_results)} benzersiz urun bulundu")
    log("=" * 80)
    log("")

    # Sonuclari kategorize et
    results_by_brand = {}
    for result in all_results:
        brand = result.search_query
        if brand not in results_by_brand:
            results_by_brand[brand] = []
        results_by_brand[brand].append(result)

    # Sonuclari goster
    for brand, items in results_by_brand.items():
        log(f"\n{'='*60}")
        log(f"  {brand.upper()} ({len(items)} urun)")
        log(f"{'='*60}")

        # Fiyata gore sirala
        items.sort(key=lambda x: x.price)

        for i, item in enumerate(items[:20], 1):  # Her kategoriden max 20 urun
            log(f"\n  [{i}] {item.title[:60]}...")
            log(f"      Fiyat: {item.price:.2f} {item.currency}")
            log(f"      Platform: {item.platform}")
            log(f"      Durum: {item.condition}")
            log(f"      URL: {item.url[:70]}...")

    # JSON olarak kaydet
    output_file = Path(__file__).parent / 'storage' / 'arama_sonuclari.json'
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump([{
            'title': r.title,
            'price': r.price,
            'currency': r.currency,
            'url': r.url,
            'platform': r.platform,
            'condition': r.condition,
            'brand': r.brand,
            'image_url': r.image_url,
            'search_query': r.search_query
        } for r in all_results], f, ensure_ascii=False, indent=2)

    log(f"\n\nSonuclar kaydedildi: {output_file}")

    return all_results


if __name__ == '__main__':
    results = run_multi_platform_search()
