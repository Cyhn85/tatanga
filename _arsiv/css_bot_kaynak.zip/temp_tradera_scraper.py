"""
TATANGA V3 - Tradera Human Scraper
Insan-benzeri davranislarla Tradera'dan urun kazima
ONEMLI: Acik artirma ve sabit fiyat (Jetzt kaufen) ayirimi yapilir!
"""
from .human_scraper_base import HumanScraper, LOG_DIR
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
from typing import List, Dict, Optional
import time
import random
import re


class TraderaScraper(HumanScraper):
    """Tradera icin insan-benzeri scraper - acik artirma filtreleme destekli"""

    BASE_URL = "https://www.tradera.com"

    # Listing tipleri
    LISTING_TYPE_AUCTION = "auction"
    LISTING_TYPE_BUY_NOW = "buy_now"
    LISTING_TYPE_HYBRID = "hybrid"  # Hem acik artirma hem hemen al

    def __init__(self, headless: bool = True):
        super().__init__("tradera", headless)
        self.products_found = []
        self.visited_urls = set()

    def close_cookie_banner(self, selectors: list = None):
        """Tradera cookie banner'i kapat (Isveccce: Godkaenn)"""
        tradera_selectors = [
            "//button[contains(text(), 'Godkaenn')]",
            "//button[contains(text(), 'Accept')]",
            "//button[contains(text(), 'Alle akzeptieren')]",
            "button[class*='consent'][class*='accept']",
            "#onetrust-accept-btn-handler",
            "button[id*='accept']",
            ".cookie-consent button",
            "[data-testid='accept-cookies']",
        ]
        return super().close_cookie_banner(tradera_selectors + (selectors or []))

    def close_save_search_popup(self):
        """Save Search popup kapat (arama sonrasi cikar)"""
        popup_selectors = [
            "//button[contains(@class, 'close')]",
            "[data-testid='close-button']",
            "button[aria-label='Close']",
            "button[aria-label='Stang']",  # Isveccce
            ".modal-close",
            ".popup-close",
            "//div[contains(@class, 'modal')]//button",
        ]

        for selector in popup_selectors:
            try:
                if selector.startswith('//'):
                    btn = self.driver.find_element(By.XPATH, selector)
                else:
                    btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.log(f"Save search popup kapatiliyor: {selector}")
                    self.human_click(btn)
                    self.random_delay(0.5, 1)
                    return True
            except:
                pass
        return False

    def go_to_homepage(self):
        """Tradera ana sayfasina git"""
        self.log("Tradera ana sayfasina gidiliyor...")
        self.visit_url(self.BASE_URL)
        self.screenshot("homepage")

        self.random_delay(1, 2)
        self.close_cookie_banner()

    def search(self, query: str):
        """Arama yap"""
        self.log(f"Arama yapiliyor: '{query}'")

        # Search URL ile direkt git
        search_url = f"{self.BASE_URL}/search?q={query.replace(' ', '%20')}"
        self.visit_url(search_url)

        self.random_delay(2, 3)
        self.close_cookie_banner()
        self.close_save_search_popup()

        self.screenshot("search_results")
        return True

    def build_search_url(self, query: str, page: int = 1,
                         min_price: float = None, max_price: float = None,
                         buy_now_only: bool = False,
                         auction_only: bool = False) -> str:
        """Tradera arama URL'si olustur"""
        import urllib.parse

        params = {"q": query}

        if page > 1:
            params["page"] = page
        if min_price is not None:
            params["minPrice"] = int(min_price)
        if max_price is not None:
            params["maxPrice"] = int(max_price)
        # Tradera filtre parametreleri (tahmini - gercek site incelenecek)
        if buy_now_only:
            params["buyNow"] = "true"
        if auction_only:
            params["auction"] = "true"

        query_string = urllib.parse.urlencode(params)
        return f"{self.BASE_URL}/search?{query_string}"

    def get_product_elements(self) -> list:
        """Sayfadaki urun elementlerini al"""
        selectors = [
            ".search-result-item",
            "[data-testid='search-item']",
            ".product-card",
            "article[class*='item']",
            ".item-card",
            "a[href*='/item/']",
        ]

        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    self.log(f"{len(elements)} urun elementi bulundu ({selector})")
                    return elements
            except:
                pass

        return []

    def is_buy_now_available(self, element) -> bool:
        """Urun 'Jetzt kaufen' secenegine sahip mi?"""
        buy_now_indicators = [
            ".//button[contains(text(), 'Jetzt kaufen')]",
            ".//span[contains(text(), 'oder jetzt kaufen')]",
            ".//span[contains(text(), 'Kop nu')]",  # Isveccce
            ".//span[contains(text(), 'Buy now')]",
            ".//*[contains(@class, 'buy-now')]",
            ".//*[contains(@class, 'buyNow')]",
        ]

        for xpath in buy_now_indicators:
            try:
                el = element.find_element(By.XPATH, xpath)
                if el:
                    return True
            except:
                pass
        return False

    def is_auction(self, element) -> bool:
        """Urun acik artirma mi?"""
        auction_indicators = [
            ".//span[contains(text(), 'Gebot')]",
            ".//span[contains(text(), 'bid')]",
            ".//span[contains(text(), 'bud')]",  # Isveccce
            ".//*[contains(@class, 'auction')]",
            ".//*[contains(@class, 'bid')]",
            ".//span[contains(text(), 'Auktion')]",
        ]

        for xpath in auction_indicators:
            try:
                el = element.find_element(By.XPATH, xpath)
                if el:
                    return True
            except:
                pass
        return False

    def get_listing_type(self, element) -> str:
        """Ilan tipini belirle"""
        has_buy_now = self.is_buy_now_available(element)
        has_auction = self.is_auction(element)

        if has_buy_now and has_auction:
            return self.LISTING_TYPE_HYBRID
        elif has_buy_now:
            return self.LISTING_TYPE_BUY_NOW
        elif has_auction:
            return self.LISTING_TYPE_AUCTION
        else:
            return self.LISTING_TYPE_BUY_NOW  # Default

    def get_buy_now_price(self, element) -> Optional[float]:
        """Hemen al fiyatini cikar (acik artirma fiyatini degil!)"""
        buy_now_price_selectors = [
            ".//button[contains(text(), 'Jetzt kaufen')]//span[contains(text(), 'EUR')]",
            ".//button[contains(text(), 'Kop nu')]//span",
            ".//*[contains(@class, 'buy-now-price')]",
            ".//*[contains(@class, 'fixed-price')]",
        ]

        for xpath in buy_now_price_selectors:
            try:
                el = element.find_element(By.XPATH, xpath)
                text = el.text
                price_match = re.search(r'([\d.,]+)\s*(?:EUR|SEK|kr|€)', text)
                if price_match:
                    return float(price_match.group(1).replace('.', '').replace(',', '.'))
            except:
                pass
        return None

    def get_auction_price(self, element) -> Optional[float]:
        """Mevcut acik artirma fiyatini cikar"""
        auction_price_selectors = [
            ".//*[contains(@class, 'current-bid')]",
            ".//*[contains(@class, 'bid-price')]",
            ".//span[contains(text(), 'Gebot')]/following-sibling::*",
        ]

        for xpath in auction_price_selectors:
            try:
                el = element.find_element(By.XPATH, xpath)
                text = el.text
                price_match = re.search(r'([\d.,]+)\s*(?:EUR|SEK|kr|€)', text)
                if price_match:
                    return float(price_match.group(1).replace('.', '').replace(',', '.'))
            except:
                pass
        return None

    def extract_product_data(self, element, skip_auctions: bool = True) -> Optional[Dict]:
        """Urun elementinden veri cikar"""
        try:
            # Listing tipini belirle
            listing_type = self.get_listing_type(element)

            # Acik artirma filtresi
            if skip_auctions and listing_type == self.LISTING_TYPE_AUCTION:
                self.log("Sadece acik artirma - atlaniyor", "debug")
                return None

            # URL
            url = None
            try:
                link = element.find_element(By.CSS_SELECTOR, "a[href*='/item/']")
                url = link.get_attribute("href")
            except:
                try:
                    link = element.find_element(By.CSS_SELECTOR, "a")
                    url = link.get_attribute("href")
                except:
                    try:
                        url = element.get_attribute("href")
                    except:
                        pass

            if not url or '/item/' not in url:
                return None

            # Product ID
            product_id = None
            match = re.search(r'/item/([a-zA-Z0-9-]+)', url)
            if match:
                product_id = match.group(1)

            if not product_id:
                return None

            # Title
            title = ""
            title_selectors = ["h3", ".item-title", "[class*='title']", "img[alt]"]
            for sel in title_selectors:
                try:
                    title_el = element.find_element(By.CSS_SELECTOR, sel)
                    if sel == "img[alt]":
                        title = title_el.get_attribute("alt") or ""
                    else:
                        title = title_el.text.strip()
                    if title:
                        break
                except:
                    pass

            # Fiyatlar - tip bazli
            price = None
            buy_now_price = None
            auction_price = None

            if listing_type in [self.LISTING_TYPE_BUY_NOW, self.LISTING_TYPE_HYBRID]:
                buy_now_price = self.get_buy_now_price(element)
                price = buy_now_price

            if listing_type in [self.LISTING_TYPE_AUCTION, self.LISTING_TYPE_HYBRID]:
                auction_price = self.get_auction_price(element)
                if not price:
                    price = auction_price

            # Fallback: genel fiyat
            if not price:
                price_selectors = [".price", "[class*='price']", "[data-testid='price']", "span"]
                for sel in price_selectors:
                    try:
                        price_el = element.find_element(By.CSS_SELECTOR, sel)
                        price_text = price_el.text
                        price_match = re.search(r'([\d.,]+)\s*(?:EUR|SEK|kr|€)', price_text)
                        if price_match:
                            price = float(price_match.group(1).replace('.', '').replace(',', '.'))
                            break
                    except:
                        pass

            # Image
            image_url = None
            try:
                img = element.find_element(By.CSS_SELECTOR, "img[src*='tradera']")
                image_url = img.get_attribute("src") or img.get_attribute("data-src")
            except:
                try:
                    img = element.find_element(By.CSS_SELECTOR, "img")
                    image_url = img.get_attribute("src")
                except:
                    pass

            return {
                "product_id": product_id,
                "url": url,
                "title": title,
                "price": price,
                "buy_now_price": buy_now_price,
                "auction_price": auction_price,
                "listing_type": listing_type,
                "is_auction": listing_type == self.LISTING_TYPE_AUCTION,
                "has_buy_now": listing_type in [self.LISTING_TYPE_BUY_NOW, self.LISTING_TYPE_HYBRID],
                "image": image_url,
                "platform": "tradera",
                "scraped_at": datetime.now().isoformat()
            }

        except Exception as e:
            self.log(f"Urun verisi cikarma hatasi: {e}", "debug")
            return None

    def load_more_products(self) -> bool:
        """Daha fazla urun yukle"""
        initial_count = len(self.get_product_elements())
        self.log(f"Mevcut urun sayisi: {initial_count}")

        # Scroll to bottom
        for attempt in range(3):
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            self.random_delay(1.5, 2.5)

            # Check popup
            self.close_save_search_popup()

            new_count = len(self.get_product_elements())
            if new_count > initial_count:
                self.log(f"Scroll ile yuklendi: {initial_count} -> {new_count}")
                return True

        # Load more button
        load_more_selectors = [
            "button[data-testid='load-more']",
            "//button[contains(text(), 'Visa fler')]",  # Isveccce
            "//button[contains(text(), 'Load more')]",
            "//button[contains(text(), 'Mehr laden')]",
            ".load-more button",
        ]

        for selector in load_more_selectors:
            try:
                if selector.startswith('//'):
                    btn = self.driver.find_element(By.XPATH, selector)
                else:
                    btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.log(f"Load more bulundu: {selector}")
                    self.human_click(btn)
                    self.random_delay(2, 4)

                    new_count = len(self.get_product_elements())
                    if new_count > initial_count:
                        return True
            except:
                pass

        self.log("Daha fazla urun yuklenemedi")
        return False

    def extract_all_products(self, skip_auctions: bool = True) -> List[Dict]:
        """Sayfadaki tum urunleri cikar"""
        elements = self.get_product_elements()
        products = []
        skipped_auctions = 0

        for element in elements:
            product = self.extract_product_data(element, skip_auctions=skip_auctions)
            if product:
                if product["url"] not in [p["url"] for p in self.products_found]:
                    products.append(product)
                    self.products_found.append(product)
            elif skip_auctions:
                skipped_auctions += 1

        self.log(f"{len(products)} yeni urun cikarildi (Toplam: {len(self.products_found)})")
        if skipped_auctions > 0:
            self.log(f"{skipped_auctions} acik artirma ilani atlandi")
        return products

    def scrape_page(self, url: str, skip_auctions: bool = True) -> List[Dict]:
        """Tek bir sayfayi kazi"""
        self.log(f"Sayfa aciliyor: {url}")
        self.visit_url(url)

        self.close_cookie_banner()
        self.close_save_search_popup()

        return self.extract_all_products(skip_auctions=skip_auctions)

    def scrape(self, query: str, max_products: int = None, max_pages: int = 10,
               min_price: float = None, max_price: float = None,
               skip_auctions: bool = True, buy_now_only: bool = False,
               **kwargs) -> List[Dict]:
        """
        Ana kazima fonksiyonu

        Args:
            query: Arama kelimesi
            max_products: Maksimum urun sayisi
            max_pages: Maksimum sayfa sayisi
            min_price: Minimum fiyat
            max_price: Maksimum fiyat
            skip_auctions: Sadece acik artirma ilanlarini atla (default: True)
            buy_now_only: Sadece hemen al secenegi olan urunleri al (default: False)
        """
        self.log("=== TRADERA KAZIMA BASLIYOR ===")
        self.log(f"Arama: {query}")
        self.log(f"Max urun: {max_products or 'Sinirsiz'}")
        self.log(f"Fiyat: {min_price} - {max_price}")
        self.log(f"Acik artirma atla: {skip_auctions}")
        self.log(f"Sadece hemen al: {buy_now_only}")

        # buy_now_only true ise, skip_auctions da true olmali
        if buy_now_only:
            skip_auctions = True

        try:
            for page in range(1, max_pages + 1):
                url = self.build_search_url(
                    query=query,
                    page=page,
                    min_price=min_price,
                    max_price=max_price,
                    buy_now_only=buy_now_only
                )

                self.log(f"Sayfa {page}/{max_pages}")

                before_count = len(self.products_found)
                self.scrape_page(url, skip_auctions=skip_auctions)
                after_count = len(self.products_found)

                new_products = after_count - before_count
                self.log(f"+{new_products} yeni urun (Toplam: {after_count})")

                # Limit kontrolu
                if max_products and len(self.products_found) >= max_products:
                    self.log(f"Maksimum urun sayisina ulasildi: {max_products}")
                    break

                # Bos sayfa
                if new_products == 0:
                    self.log("Bos sayfa, kazima durduruluyor...")
                    break

                self.random_delay(2, 4)

            self.log("=== TRADERA KAZIMA TAMAMLANDI ===")
            self.log(f"Toplam urun: {len(self.products_found)}")

            # Istatistikler
            buy_now_count = len([p for p in self.products_found if p.get("has_buy_now")])
            auction_count = len([p for p in self.products_found if p.get("is_auction")])
            self.log(f"Hemen Al: {buy_now_count} | Acik Artirma: {auction_count}")

            return self.products_found

        except Exception as e:
            self.log(f"Kazima hatasi: {e}", "error")
            self.screenshot("error")
            raise


def run_tradera_scrape(query: str, max_products: int = None, headless: bool = True,
                       skip_auctions: bool = True) -> List[Dict]:
    """Tradera kazima islemini calistir"""
    with TraderaScraper(headless=headless) as scraper:
        return scraper.scrape(query, max_products=max_products, skip_auctions=skip_auctions)


if __name__ == "__main__":
    import sys

    query = sys.argv[1] if len(sys.argv) > 1 else "nike"
    max_items = int(sys.argv[2]) if len(sys.argv) > 2 else 20

    print(f"Tradera kazima basliyor: {query}")
    products = run_tradera_scrape(query, max_products=max_items, headless=True, skip_auctions=True)

    print(f"\n{len(products)} urun bulundu:")
    for p in products[:5]:
        listing = "Hemen Al" if p.get("has_buy_now") else "Acik Artirma"
        print(f"  - {p['title'][:30]} | {p['price']} | {listing} | {p['url']}")
