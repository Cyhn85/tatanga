#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Import today's scraping results with correct prices and images"""

import json
import sqlite3
from datetime import datetime
from pathlib import Path
import re

db_path = Path('storage/tatanga.db')
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

def parse_price(price_str):
    """Parse price from various formats"""
    if price_str is None:
        return 0.0
    if isinstance(price_str, (int, float)):
        # Check if it looks like cents (e.g., 7143 should be 71.43)
        if price_str > 1000:
            return price_str / 100
        return float(price_str)

    # String parsing
    price_str = str(price_str).strip()

    # Remove currency symbols
    price_str = price_str.replace('EUR', '').replace('€', '').replace('VB', '').strip()

    # Handle German format: 71,43 or 7.143,00
    if ',' in price_str and '.' in price_str:
        # 7.143,00 format
        price_str = price_str.replace('.', '').replace(',', '.')
    elif ',' in price_str:
        # 71,43 format
        price_str = price_str.replace(',', '.')

    # Extract number
    match = re.search(r'([\d.]+)', price_str)
    if match:
        try:
            return float(match.group(1))
        except:
            return 0.0
    return 0.0

# Bugunku kazima dosyalari - V4 with correct prices
files = [
    ('storage/vinted_tommy_test.json', 'vinted_de'),
    ('storage/kleinanzeigen_v4_test.json', 'kleinanzeigen'),  # V4 with correct prices!
    ('storage/ebay_api_tommy_test.json', 'ebay_de'),
]

batch_id = f'today_{datetime.now().strftime("%Y%m%d_%H%M%S")}'
total_imported = 0

for file_path, default_platform in files:
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        products = data if isinstance(data, list) else data.get('products', data.get('results', []))

        imported = 0
        for item in products:
            try:
                # Parse price correctly
                raw_price = item.get('price_value', item.get('price', 0))
                price = parse_price(raw_price)

                # Skip if price is unrealistic (> 5000 EUR for clothing)
                if price > 5000:
                    price = price / 100  # Likely cents

                # Get image URL
                image = item.get('image', item.get('thumbnail', ''))
                if not image:
                    images_list = item.get('images', [])
                    if images_list:
                        image = images_list[0] if isinstance(images_list[0], str) else ''

                # Platform
                platform = item.get('platform', default_platform)

                cursor.execute('''
                    INSERT OR IGNORE INTO products
                    (title, url, price, currency, platform, images, condition, location, batch_id, is_in_inbox, scraped_at)
                    VALUES (?, ?, ?, 'EUR', ?, ?, ?, ?, ?, 1, ?)
                ''', (
                    item.get('title', ''),
                    item.get('url', ''),
                    price,
                    platform,
                    json.dumps([image]) if image else '[]',
                    item.get('condition', ''),
                    item.get('location', ''),
                    batch_id,
                    datetime.now().isoformat()
                ))
                if cursor.rowcount > 0:
                    imported += 1
            except Exception as e:
                continue

        print(f'{file_path}: {imported} urun eklendi')
        total_imported += imported

    except FileNotFoundError:
        print(f'{file_path}: Dosya bulunamadi')
    except Exception as e:
        print(f'{file_path}: Hata - {e}')

conn.commit()

# Show some sample data to verify prices
cursor.execute('SELECT title, price, platform, images FROM products LIMIT 10')
print('\n=== ORNEK VERILER ===')
for row in cursor.fetchall():
    title = row[0][:40] if row[0] else '?'
    price = row[1]
    platform = row[2]
    has_image = 'Resim VAR' if row[3] and row[3] != '[]' and row[3] != '[""]' else 'Resim YOK'
    print(f'{title}... | {price:.2f} EUR | {platform} | {has_image}')

# Count
cursor.execute('SELECT COUNT(*) FROM products WHERE is_in_inbox = 1')
inbox_count = cursor.fetchone()[0]
print(f'\nToplam gelen kutusu: {inbox_count}')

conn.close()