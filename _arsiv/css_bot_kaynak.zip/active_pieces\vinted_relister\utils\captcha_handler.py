# CAPTCHA Handler - Detects CAPTCHA and notifies user via Telegram
# Waits for manual resolution before continuing

import os
import sys
import time
from datetime import datetime
from typing import Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

# CAPTCHA Detection Patterns (STRICT - only real CAPTCHAs)
CAPTCHA_INDICATORS = [
    # German texts - CAPTCHA specific
    'wir vergewissern uns, dass wir es wirklich mit ihnen',
    'nicht mit einem roboter',
    'puzzle zu vervollständigen',
    'nach rechts schieben, um das puzzle',
    'sicherheitsprüfung',
    # English texts - CAPTCHA specific
    'verify you are human',
    'prove you are not a robot',
    'complete the puzzle',
    'slide to verify',
    'drag the slider',
]

# Exclude these - NOT CAPTCHA (cookie popups, privacy settings, etc.)
CAPTCHA_EXCLUDES = [
    'privatsphäre',
    'datenschutz',
    'cookie',
    'einstellungen',
    'akzeptieren',
    'privacy',
    'consent',
    'preferences',
]

# CAPTCHA Element Selectors
CAPTCHA_SELECTORS = [
    '[class*="captcha"]',
    '[id*="captcha"]',
    '[class*="challenge"]',
    '[data-testid*="captcha"]',
    'iframe[src*="captcha"]',
    'iframe[src*="challenge"]',
    'iframe[src*="recaptcha"]',
    'iframe[src*="hcaptcha"]',
    '.slider-captcha',
    '.puzzle-captcha',
]


class CaptchaHandler:
    def __init__(self, telegram_notify: bool = True):
        self.telegram_notify = telegram_notify
        self.waiting_for_resolution = False
        self.captcha_count = 0
        print('[OK] CaptchaHandler initialized')

    def detect_captcha(self, page) -> Tuple[bool, str]:
        """Detect if CAPTCHA is present on page (excludes cookie popups)"""
        try:
            page_text = page.content().lower()

            # First check: If page contains exclude patterns, it's NOT a CAPTCHA
            # (cookie consent, privacy settings, etc.)
            for exclude in CAPTCHA_EXCLUDES:
                if exclude in page_text:
                    # Found exclude pattern - check if CAPTCHA indicator is ALSO present
                    # Only return CAPTCHA if we see real CAPTCHA-specific text
                    has_real_captcha = any(
                        ind in page_text for ind in [
                            'puzzle zu vervollständigen',
                            'nach rechts schieben, um das puzzle',
                            'nicht mit einem roboter'
                        ]
                    )
                    if not has_real_captcha:
                        return False, f'Excluded (likely cookie popup): {exclude}'

            # Method 1: Check page text for CAPTCHA indicators
            for indicator in CAPTCHA_INDICATORS:
                if indicator in page_text:
                    return True, f'Text match: {indicator}'

            # Method 2: Check for CAPTCHA elements
            for selector in CAPTCHA_SELECTORS:
                try:
                    element = page.query_selector(selector)
                    if element and element.is_visible():
                        return True, f'Element found: {selector}'
                except:
                    continue

            # Method 3: Check for iframes (CAPTCHA often in iframe)
            iframes = page.query_selector_all('iframe')
            for iframe in iframes:
                src = iframe.get_attribute('src') or ''
                if any(x in src.lower() for x in ['captcha', 'challenge', 'recaptcha', 'hcaptcha']):
                    return True, f'CAPTCHA iframe: {src[:50]}'

            return False, 'No CAPTCHA detected'

        except Exception as e:
            return False, f'Detection error: {e}'

    def handle_captcha(self, page, screenshot_path: Optional[str] = None,
                       timeout_minutes: int = 10) -> bool:
        """
        Handle CAPTCHA: notify user and wait for resolution
        Returns True if CAPTCHA was resolved, False if timeout
        """
        self.captcha_count += 1
        self.waiting_for_resolution = True

        print('\n' + '=' * 50)
        print('⚠️  CAPTCHA DETECTED!')
        print('=' * 50)

        # Take screenshot if path provided
        if screenshot_path:
            try:
                page.screenshot(path=screenshot_path)
                print(f'[SS] Screenshot: {screenshot_path}')
            except:
                pass

        # Send Telegram notification
        if self.telegram_notify:
            self._send_telegram_alert(page.url, screenshot_path)

        # Wait for manual resolution
        print(f'\n[WAIT] Waiting for manual CAPTCHA resolution...')
        print(f'       Timeout: {timeout_minutes} minutes')
        print(f'       Resolve in browser, then CAPTCHA will auto-detect completion\n')

        start_time = time.time()
        check_interval = 5  # Check every 5 seconds

        while time.time() - start_time < timeout_minutes * 60:
            # Check if CAPTCHA is still present
            is_captcha, _ = self.detect_captcha(page)

            if not is_captcha:
                elapsed = int(time.time() - start_time)
                print(f'\n[OK] CAPTCHA resolved! (took {elapsed}s)')
                self.waiting_for_resolution = False

                # Notify success
                if self.telegram_notify:
                    self._send_telegram_success(elapsed)

                return True

            # Show waiting indicator
            remaining = timeout_minutes * 60 - (time.time() - start_time)
            print(f'  [{int(remaining)}s remaining] Still waiting...', end='\r')

            time.sleep(check_interval)

        # Timeout
        print(f'\n[TIMEOUT] CAPTCHA not resolved within {timeout_minutes} minutes')
        self.waiting_for_resolution = False

        if self.telegram_notify:
            self._send_telegram_timeout()

        return False

    def _send_telegram_alert(self, url: str, screenshot_path: Optional[str] = None):
        """Send CAPTCHA alert to Telegram"""
        try:
            import requests

            message = f"""🚨 *CAPTCHA ALERT*

⏰ Time: {datetime.now().strftime('%H:%M:%S')}
🔗 URL: {url}
📊 Total CAPTCHAs: {self.captcha_count}

*Action Required:*
1. Open browser
2. Solve CAPTCHA manually
3. Bot will auto-continue

⏱ Timeout: 10 minutes"""

            # Send text message
            requests.post(
                f'https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage',
                data={
                    'chat_id': TELEGRAM_CHAT_ID,
                    'text': message,
                    'parse_mode': 'Markdown'
                },
                timeout=10
            )

            print('[TG] CAPTCHA alert sent')

        except Exception as e:
            print(f'[TG] Alert failed: {e}')

    def _send_telegram_success(self, elapsed_seconds: int):
        """Send CAPTCHA resolved notification"""
        try:
            import requests

            message = f"""✅ *CAPTCHA RESOLVED*

⏱ Took: {elapsed_seconds} seconds
🔄 Continuing automation..."""

            requests.post(
                f'https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage',
                data={
                    'chat_id': TELEGRAM_CHAT_ID,
                    'text': message,
                    'parse_mode': 'Markdown'
                },
                timeout=10
            )

        except:
            pass

    def _send_telegram_timeout(self):
        """Send CAPTCHA timeout notification"""
        try:
            import requests

            message = f"""⏰ *CAPTCHA TIMEOUT*

CAPTCHA was not resolved within timeout.
Automation paused.

Please check the system."""

            requests.post(
                f'https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage',
                data={
                    'chat_id': TELEGRAM_CHAT_ID,
                    'text': message,
                    'parse_mode': 'Markdown'
                },
                timeout=10
            )

        except:
            pass

    def get_stats(self) -> dict:
        """Get CAPTCHA statistics"""
        return {
            'total_captchas': self.captcha_count,
            'waiting': self.waiting_for_resolution
        }


# Singleton
_handler = None

def get_captcha_handler() -> CaptchaHandler:
    global _handler
    if _handler is None:
        _handler = CaptchaHandler()
    return _handler


if __name__ == '__main__':
    print('CAPTCHA Handler Test')
    handler = get_captcha_handler()
    print(f'Stats: {handler.get_stats()}')
