#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Scraper Logger & Metrics
Detailed logging and performance tracking for debugging

Features:
- Platform-specific metrics (found vs passed filter)
- Search history tracking
- Error logging with context
- JSON metrics export
- Summary report generation

Author: TATANGA Team
Version: 1.0.0
"""

import sys
import io
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass, field, asdict
from collections import defaultdict

# Fix Windows console encoding
if sys.platform == 'win32':
    if not isinstance(sys.stdout, io.TextIOWrapper) or sys.stdout.encoding != 'utf-8':
        try:
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        except AttributeError:
            pass


# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class SearchMetrics:
    """Metrics for a single search operation"""
    platform: str
    query: str
    found: int = 0
    passed_filter: int = 0
    filtered_out: int = 0
    errors: int = 0
    duration_ms: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    @property
    def filter_rate(self) -> str:
        """Calculate filter pass rate"""
        if self.found == 0:
            return "0.0%"
        return f"{(self.passed_filter / self.found * 100):.1f}%"


@dataclass
class PlatformStats:
    """Aggregated statistics for a platform"""
    platform: str
    total_searches: int = 0
    total_found: int = 0
    total_passed: int = 0
    total_errors: int = 0
    avg_results_per_search: float = 0.0
    avg_filter_rate: float = 0.0

    def update(self, metrics: SearchMetrics):
        """Update stats with new search metrics"""
        self.total_searches += 1
        self.total_found += metrics.found
        self.total_passed += metrics.passed_filter
        self.total_errors += metrics.errors
        self.avg_results_per_search = self.total_found / self.total_searches
        if self.total_found > 0:
            self.avg_filter_rate = self.total_passed / self.total_found * 100


# ============================================================================
# SCRAPER LOGGER
# ============================================================================

class ScraperLogger:
    """
    Centralized logging and metrics for all scrapers

    Tracks:
    - Per-search metrics (found, filtered, errors)
    - Per-platform aggregates
    - Search history
    - Error log with context
    """

    def __init__(self, storage_dir: Path = None):
        """
        Initialize logger

        Args:
            storage_dir: Directory for log files
        """
        if storage_dir is None:
            storage_dir = Path(__file__).parent.parent / "storage"

        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        self.log_file = self.storage_dir / "scraper_debug.log"
        self.metrics_file = self.storage_dir / "scraper_metrics.json"

        # In-memory tracking
        self.search_history: List[SearchMetrics] = []
        self.platform_stats: Dict[str, PlatformStats] = {}
        self.error_log: List[Dict] = []

        # Session info
        self.session_start = datetime.now()
        self.session_id = self.session_start.strftime("%Y%m%d_%H%M%S")

        self._write_log(f"\n{'='*80}")
        self._write_log(f"SCRAPER SESSION STARTED: {self.session_start}")
        self._write_log(f"Session ID: {self.session_id}")
        self._write_log(f"{'='*80}\n")

    def _write_log(self, message: str):
        """Write message to log file"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(f"[{timestamp}] {message}\n")

    def log_search_start(self, platform: str, query: str):
        """Log search start"""
        self._write_log(f"SEARCH START | {platform} | query='{query}'")

    def log_search_result(
        self,
        platform: str,
        query: str,
        found: int,
        passed_filter: int,
        duration_ms: float = 0.0,
        error: str = None
    ):
        """
        Log search result and update metrics

        Args:
            platform: Platform name
            query: Search query
            found: Total products found
            passed_filter: Products that passed condition filter
            duration_ms: Search duration in milliseconds
            error: Error message if search failed
        """
        metrics = SearchMetrics(
            platform=platform,
            query=query,
            found=found,
            passed_filter=passed_filter,
            filtered_out=found - passed_filter,
            errors=1 if error else 0,
            duration_ms=duration_ms
        )

        self.search_history.append(metrics)

        # Update platform stats
        if platform not in self.platform_stats:
            self.platform_stats[platform] = PlatformStats(platform=platform)
        self.platform_stats[platform].update(metrics)

        # Log to file
        status = "ERROR" if error else "OK"
        log_msg = (
            f"SEARCH {status} | {platform} | query='{query}' | "
            f"found={found} | passed={passed_filter} ({metrics.filter_rate}) | "
            f"time={duration_ms:.0f}ms"
        )
        if error:
            log_msg += f" | error={error}"

        self._write_log(log_msg)

        # Log error if present
        if error:
            self.log_error(platform, query, error)

    def log_error(self, platform: str, query: str, error: str, context: Dict = None):
        """Log an error with context"""
        error_entry = {
            'timestamp': datetime.now().isoformat(),
            'platform': platform,
            'query': query,
            'error': error,
            'context': context or {}
        }
        self.error_log.append(error_entry)
        self._write_log(f"ERROR | {platform} | {error}")

    def log_info(self, message: str):
        """Log informational message"""
        self._write_log(f"INFO | {message}")

    def log_warning(self, message: str):
        """Log warning message"""
        self._write_log(f"WARNING | {message}")

    def get_platform_summary(self, platform: str) -> Optional[Dict]:
        """Get summary for a specific platform"""
        if platform not in self.platform_stats:
            return None
        stats = self.platform_stats[platform]
        return {
            'platform': stats.platform,
            'searches': stats.total_searches,
            'found': stats.total_found,
            'passed': stats.total_passed,
            'errors': stats.total_errors,
            'avg_per_search': round(stats.avg_results_per_search, 1),
            'filter_rate': f"{stats.avg_filter_rate:.1f}%"
        }

    def get_all_platform_summary(self) -> Dict[str, Dict]:
        """Get summary for all platforms"""
        return {
            platform: self.get_platform_summary(platform)
            for platform in self.platform_stats
        }

    def generate_report(self) -> str:
        """Generate human-readable summary report"""
        lines = []
        lines.append("=" * 80)
        lines.append("SCRAPER SESSION REPORT")
        lines.append(f"Session: {self.session_id}")
        lines.append(f"Duration: {datetime.now() - self.session_start}")
        lines.append("=" * 80)
        lines.append("")

        # Overall stats
        total_searches = len(self.search_history)
        total_found = sum(m.found for m in self.search_history)
        total_passed = sum(m.passed_filter for m in self.search_history)
        total_errors = len(self.error_log)

        lines.append("OVERALL STATISTICS:")
        lines.append(f"  Total searches: {total_searches}")
        lines.append(f"  Total products found: {total_found}")
        lines.append(f"  Total passed filter: {total_passed}")
        lines.append(f"  Overall filter rate: {total_passed/total_found*100:.1f}%" if total_found > 0 else "  Overall filter rate: 0%")
        lines.append(f"  Total errors: {total_errors}")
        lines.append("")

        # Per-platform breakdown
        lines.append("PER-PLATFORM BREAKDOWN:")
        lines.append("-" * 80)
        lines.append(f"{'Platform':<20} {'Searches':>10} {'Found':>10} {'Passed':>10} {'Rate':>10} {'Errors':>10}")
        lines.append("-" * 80)

        for platform, stats in sorted(self.platform_stats.items()):
            lines.append(
                f"{platform:<20} {stats.total_searches:>10} {stats.total_found:>10} "
                f"{stats.total_passed:>10} {stats.avg_filter_rate:>9.1f}% {stats.total_errors:>10}"
            )

        lines.append("-" * 80)
        lines.append("")

        # Top errors
        if self.error_log:
            lines.append("RECENT ERRORS:")
            for err in self.error_log[-5:]:
                lines.append(f"  [{err['platform']}] {err['error'][:60]}...")
            lines.append("")

        lines.append("=" * 80)

        return "\n".join(lines)

    def save_metrics(self):
        """Save metrics to JSON file"""
        data = {
            'session_id': self.session_id,
            'session_start': self.session_start.isoformat(),
            'session_end': datetime.now().isoformat(),
            'platform_stats': {
                platform: asdict(stats)
                for platform, stats in self.platform_stats.items()
            },
            'search_history': [asdict(m) for m in self.search_history[-100:]],  # Last 100
            'error_count': len(self.error_log),
            'recent_errors': self.error_log[-10:]  # Last 10 errors
        }

        with open(self.metrics_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        self._write_log(f"Metrics saved to {self.metrics_file}")

    def print_summary(self):
        """Print summary to console"""
        report = self.generate_report()
        print(report)

        # Also write to log
        for line in report.split('\n'):
            self._write_log(line)

    def close(self):
        """Close logger and save metrics"""
        self._write_log(f"\n{'='*80}")
        self._write_log(f"SCRAPER SESSION ENDED: {datetime.now()}")
        self._write_log(f"{'='*80}\n")
        self.save_metrics()


# ============================================================================
# SINGLETON INSTANCE
# ============================================================================

_logger_instance: Optional[ScraperLogger] = None


def get_scraper_logger() -> ScraperLogger:
    """Get or create singleton logger instance"""
    global _logger_instance
    if _logger_instance is None:
        _logger_instance = ScraperLogger()
    return _logger_instance


def reset_logger():
    """Reset logger for new session"""
    global _logger_instance
    if _logger_instance:
        _logger_instance.close()
    _logger_instance = ScraperLogger()
    return _logger_instance


# ============================================================================
# TEST
# ============================================================================

if __name__ == '__main__':
    print("=" * 70)
    print("TATANGA - Scraper Logger Test")
    print("=" * 70)

    logger = ScraperLogger()

    # Simulate some searches
    test_data = [
        ('vinted_de', 'timberland stiefel', 10, 2),
        ('vinted_de', 'ugg boots', 10, 1),
        ('vinted_fr', 'bottes timberland', 10, 3),
        ('leboncoin', 'bottes timberland', 10, 9),
        ('shpock_de', 'timberland stiefel', 0, 0),
        ('vinted_uk', 'timberland boots', 10, 2),
    ]

    for platform, query, found, passed in test_data:
        logger.log_search_start(platform, query)
        logger.log_search_result(platform, query, found, passed, duration_ms=1500)

    # Log an error
    logger.log_error('shpock_de', 'test query', 'Cloudflare blocked', {'status_code': 403})

    # Print summary
    print("\n")
    logger.print_summary()

    # Save metrics
    logger.close()
    print(f"\nMetrics saved to: {logger.metrics_file}")
