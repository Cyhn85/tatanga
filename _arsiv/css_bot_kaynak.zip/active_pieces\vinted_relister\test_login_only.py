# Test ONLY login - no upload
import os
import sys
import time
sys.stdout.reconfigure(encoding='utf-8')

from playwright.sync_api import sync_playwright

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROFILE_DIR = os.path.join(BASE_DIR, 'playwright_profiles', 'cssberlin_test')
os.makedirs(PROFILE_DIR, exist_ok=True)
DATA_DIR = os.path.join(BASE_DIR, 'data')
os.makedirs(DATA_DIR, exist_ok=True)

VINTED_EMAIL = "cssberlin@hotmail.com"
VINTED_PASSWORD = "Cssberlin200231"

def test_login():
    print("=" * 60)
    print("TEST: LOGIN ONLY")
    print("=" * 60)

    with sync_playwright() as pw:
        browser = pw.chromium.launch_persistent_context(
            user_data_dir=PROFILE_DIR,
            headless=False,
            viewport={'width': 1400, 'height': 900},
            locale='de-DE'
        )

        page = browser.pages[0] if browser.pages else browser.new_page()

        # Step 0: Go to Vinted
        print("\n[STEP 0] Going to vinted.de...")
        page.goto('https://www.vinted.de/', wait_until='networkidle', timeout=60000)
        time.sleep(2)
        page.screenshot(path=os.path.join(DATA_DIR, 'test_step0.png'))

        # Accept cookies FIRST
        print("\n[COOKIES] Looking for cookie consent...")
        try:
            # Try multiple cookie accept buttons
            cookie_selectors = [
                'button#onetrust-accept-btn-handler',
                'button:has-text("Alle akzeptieren")',
                'button:has-text("Alle zulassen")',
                'button:has-text("Accept All")',
                '[data-testid="cookie-consent-accept"]'
            ]
            for sel in cookie_selectors:
                btn = page.query_selector(sel)
                if btn and btn.is_visible():
                    btn.click()
                    print(f"  [OK] Clicked cookie button: {sel}")
                    time.sleep(2)
                    break
            else:
                print("  [INFO] No cookie popup found or already accepted")
        except Exception as e:
            print(f"  [WARN] Cookie handling: {e}")

        page.screenshot(path=os.path.join(DATA_DIR, 'test_step0b.png'))

        # Check if already logged in
        header_btn = page.query_selector('a:has-text("Registrieren | Einloggen")')
        if not header_btn:
            print("[OK] Already logged in!")
            page.screenshot(path=os.path.join(DATA_DIR, 'test_logged_in.png'))
            browser.close()
            return True

        # Step 1: Click header button to open popup
        print("\n[STEP 1] Clicking header button...")
        header_btn.click()
        time.sleep(3)
        page.screenshot(path=os.path.join(DATA_DIR, 'test_step1.png'))
        print("  Screenshot: test_step1.png")

        # Step 2: Click "Einloggen" in popup
        print("\n[STEP 2] Looking for 'Einloggen' in popup...")
        try:
            einloggen = page.get_by_text('Einloggen', exact=True)
            if einloggen.count() > 0:
                einloggen.first.click()
                print("  [OK] Clicked Einloggen")
                time.sleep(3)
            else:
                print("  [ERROR] Einloggen not found!")
        except Exception as e:
            print(f"  [ERROR] {e}")
        page.screenshot(path=os.path.join(DATA_DIR, 'test_step2.png'))
        print("  Screenshot: test_step2.png")

        # Step 3: Click "E-Mail" option
        print("\n[STEP 3] Clicking E-Mail option...")
        try:
            # Try multiple selectors
            email_btn = page.query_selector('[data-testid*="email"]')
            if not email_btn:
                email_btn = page.get_by_text('E-Mail', exact=True)
                if email_btn.count() > 0:
                    email_btn = email_btn.first
                else:
                    email_btn = None
            if email_btn:
                email_btn.click()
                print("  [OK] Clicked E-Mail")
                time.sleep(3)
            else:
                print("  [WARN] E-Mail button not found")
        except Exception as e:
            print(f"  [ERROR] {e}")
        page.screenshot(path=os.path.join(DATA_DIR, 'test_step3.png'))
        print("  Screenshot: test_step3.png")

        # Step 4: Fill email
        print("\n[STEP 4] Filling email...")
        email_input = page.query_selector('input[type="email"], input[name="email"], input[placeholder*="E-Mail"], input[placeholder*="Mitgliedsname"]')
        if email_input:
            email_input.fill(VINTED_EMAIL)
            print(f"  [OK] Email entered: {VINTED_EMAIL}")
        else:
            print("  [ERROR] Email input not found!")
            # List all inputs for debug
            inputs = page.query_selector_all('input')
            print(f"  Found {len(inputs)} inputs:")
            for inp in inputs[:5]:
                print(f"    - type={inp.get_attribute('type')} name={inp.get_attribute('name')} placeholder={inp.get_attribute('placeholder')}")
        time.sleep(1)
        page.screenshot(path=os.path.join(DATA_DIR, 'test_step4.png'))
        print("  Screenshot: test_step4.png")

        # Step 5: Fill password
        print("\n[STEP 5] Filling password...")
        password_input = page.query_selector('input[type="password"]')
        if password_input:
            password_input.fill(VINTED_PASSWORD)
            print("  [OK] Password entered")
        else:
            print("  [ERROR] Password input not found!")
        time.sleep(1)
        page.screenshot(path=os.path.join(DATA_DIR, 'test_step5.png'))
        print("  Screenshot: test_step5.png")

        # Step 6: Click submit
        print("\n[STEP 6] Clicking submit...")
        submit_btn = page.query_selector('button[type="submit"]')
        if submit_btn:
            submit_btn.click()
            print("  [OK] Clicked submit")
            time.sleep(5)
        else:
            print("  [ERROR] Submit button not found!")
        page.screenshot(path=os.path.join(DATA_DIR, 'test_step6.png'))
        print("  Screenshot: test_step6.png")

        # Final check
        print("\n[FINAL CHECK]")
        print(f"  URL: {page.url}")
        header_btn_after = page.query_selector('a:has-text("Registrieren | Einloggen")')
        if header_btn_after:
            print("  [FAIL] Still not logged in - header button visible")
            success = False
        else:
            print("  [OK] Logged in! Header button gone")
            success = True

        page.screenshot(path=os.path.join(DATA_DIR, 'test_final.png'))
        print("  Screenshot: test_final.png")

        print("\n" + "=" * 60)
        print(f"RESULT: {'SUCCESS' if success else 'FAILED'}")
        print("=" * 60)

        print("\nBrowser closing in 5 seconds...")
        time.sleep(5)
        browser.close()

        return success

if __name__ == '__main__':
    test_login()
