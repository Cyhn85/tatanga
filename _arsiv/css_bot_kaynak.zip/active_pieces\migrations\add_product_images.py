#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Database Migration: Add product_images table
Adds support for multi-image products with processing status.
"""

import sqlite3
import sys
from pathlib import Path
from datetime import datetime

# Database path
DB_PATH = Path(__file__).parent.parent / "tatanga.db"


def run_migration():
    """Run the database migration."""
    print("=" * 60)
    print("TATANGA - Database Migration")
    print("Adding product_images table and updating products table")
    print("=" * 60)

    if not DB_PATH.exists():
        print(f"ERROR: Database not found at {DB_PATH}")
        return False

    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()

    try:
        # 1. Add new columns to products table (if not exist)
        print("\n[1/3] Updating products table...")

        # Check existing columns
        cursor.execute("PRAGMA table_info(products)")
        existing_columns = {row[1] for row in cursor.fetchall()}

        new_columns = [
            ("image_count", "INTEGER DEFAULT 0"),
            ("images_processed", "BOOLEAN DEFAULT 0"),
            ("original_images", "TEXT"),  # JSON array of original URLs
            ("processed_images", "TEXT"),  # JSON array of processed paths
            ("source_category", "TEXT"),
            ("source_condition", "TEXT"),
        ]

        for col_name, col_def in new_columns:
            if col_name not in existing_columns:
                cursor.execute(f"ALTER TABLE products ADD COLUMN {col_name} {col_def}")
                print(f"  Added column: {col_name}")
            else:
                print(f"  Column exists: {col_name}")

        # 2. Create product_images table
        print("\n[2/3] Creating product_images table...")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS product_images (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                image_index INTEGER DEFAULT 0,
                original_url TEXT,
                processed_path TEXT,
                manipulation_level TEXT DEFAULT 'medium',
                file_size INTEGER,
                width INTEGER,
                height INTEGER,
                is_primary BOOLEAN DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
            )
        """)
        print("  Table created: product_images")

        # Create index
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_product_images_product
            ON product_images(product_id)
        """)
        print("  Index created: idx_product_images_product")

        # 3. Create publish_history table (if not exists)
        print("\n[3/3] Creating publish_history table...")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS publish_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                platform TEXT NOT NULL,
                publish_status TEXT DEFAULT 'pending',
                external_listing_id TEXT,
                external_listing_url TEXT,
                publish_price REAL,
                publish_currency TEXT DEFAULT 'EUR',
                category_used TEXT,
                condition_used TEXT,
                images_count INTEGER DEFAULT 0,
                error_message TEXT,
                published_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
            )
        """)
        print("  Table created: publish_history")

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_publish_history_product
            ON publish_history(product_id)
        """)
        print("  Index created: idx_publish_history_product")

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_publish_history_platform
            ON publish_history(platform)
        """)
        print("  Index created: idx_publish_history_platform")

        # Commit changes
        conn.commit()
        print("\n" + "=" * 60)
        print("Migration completed successfully!")
        print("=" * 60)
        return True

    except Exception as e:
        conn.rollback()
        print(f"\nERROR: Migration failed - {e}")
        import traceback
        traceback.print_exc()
        return False

    finally:
        conn.close()


def check_migration_status():
    """Check if migration has been applied."""
    if not DB_PATH.exists():
        return False

    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()

    try:
        # Check for product_images table
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='product_images'
        """)
        has_product_images = cursor.fetchone() is not None

        # Check for image_count column
        cursor.execute("PRAGMA table_info(products)")
        columns = {row[1] for row in cursor.fetchall()}
        has_image_count = 'image_count' in columns

        return has_product_images and has_image_count

    finally:
        conn.close()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--check":
        status = check_migration_status()
        print(f"Migration applied: {status}")
        sys.exit(0 if status else 1)

    success = run_migration()
    sys.exit(0 if success else 1)
