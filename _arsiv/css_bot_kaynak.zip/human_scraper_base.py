"""
TATANGA V3 - Base Human Scraper
Tüm platformlar için temel insan-benzeri davranışlar
"""
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
from pathlib import Path
import time
import random
import logging
import os

# Log klasörü
LOG_DIR = Path("/opt/tatanga/backend/logs/scraper")
LOG_DIR.mkdir(parents=True, exist_ok=True)


class HumanScraper:
    """İnsan-benzeri davranışlara sahip temel scraper sınıfı"""

    def __init__(self, platform: str, headless: bool = True):
        self.platform = platform
        self.headless = headless
        self.driver = None
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.step_count = 0

        # Logger kurulumu
        self.logger = logging.getLogger(f"TATANGA.{platform}")
        self.logger.setLevel(logging.DEBUG)

        # Dosya handler
        log_file = LOG_DIR / f"{platform}_{self.session_id}.log"
        fh = logging.FileHandler(log_file, encoding='utf-8')
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(fh)

        # Console handler
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        ch.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
        self.logger.addHandler(ch)

        self.logger.info(f"=== {platform.upper()} SCRAPER BAŞLATILDI ===")
        self.logger.info(f"Session ID: {self.session_id}")

    def init_driver(self):
        """Chrome driver'ı başlat"""
        if self.driver:
            return

        self.logger.info("Chrome driver başlatılıyor...")

        options = uc.ChromeOptions()

        if self.headless:
            options.add_argument("--headless=new")

        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--lang=de-DE")

        # Rastgele user agent
        user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        ]
        options.add_argument(f"--user-agent={random.choice(user_agents)}")

        self.driver = uc.Chrome(options=options)
        self.driver.implicitly_wait(5)

        self.logger.info("Chrome driver başlatıldı")
        self.screenshot("driver_started")

    def screenshot(self, name: str):
        """Screenshot al ve kaydet"""
        if not self.driver:
            return

        self.step_count += 1
        filename = f"{self.platform}_{self.session_id}_step{self.step_count:02d}_{name}.png"
        filepath = LOG_DIR / filename

        try:
            self.driver.save_screenshot(str(filepath))
            self.logger.debug(f"Screenshot: {filename}")
        except Exception as e:
            self.logger.warning(f"Screenshot hatası: {e}")

    def log(self, message: str, level: str = "info"):
        """Log mesajı yaz"""
        if level == "debug":
            self.logger.debug(message)
        elif level == "warning":
            self.logger.warning(message)
        elif level == "error":
            self.logger.error(message)
        else:
            self.logger.info(message)

    # ============ İNSAN BENZERİ DAVRANIŞLAR ============

    def random_delay(self, min_sec: float = 0.5, max_sec: float = 2.0):
        """Rastgele bekleme"""
        delay = random.uniform(min_sec, max_sec)
        time.sleep(delay)

    def human_type(self, element, text: str, make_mistakes: bool = True):
        """
        İnsan gibi yazma - yavaş, bazen yanlış yazıp düzeltme
        """
        self.log(f"Yazılıyor: '{text}'")

        for i, char in enumerate(text):
            # Rastgele hız
            time.sleep(random.uniform(0.05, 0.2))

            # %10 ihtimalle yanlış karakter yaz ve düzelt
            if make_mistakes and random.random() < 0.1 and i < len(text) - 1:
                wrong_char = random.choice('abcdefghijklmnopqrstuvwxyz')
                element.send_keys(wrong_char)
                time.sleep(random.uniform(0.1, 0.3))
                element.send_keys(Keys.BACKSPACE)
                time.sleep(random.uniform(0.05, 0.15))

            element.send_keys(char)

            # Bazen kısa duraklama
            if random.random() < 0.1:
                time.sleep(random.uniform(0.2, 0.5))

    def human_scroll(self, direction: str = "down", amount: int = None):
        """
        İnsan gibi scroll - değişken hız, bazen duraklar
        """
        if amount is None:
            amount = random.randint(300, 700)

        if direction == "up":
            amount = -amount

        # Parçalı scroll
        chunks = random.randint(3, 6)
        chunk_size = amount // chunks

        for _ in range(chunks):
            self.driver.execute_script(f"window.scrollBy(0, {chunk_size})")
            time.sleep(random.uniform(0.05, 0.15))

            # %20 ihtimalle duraklama (okuma simülasyonu)
            if random.random() < 0.2:
                time.sleep(random.uniform(0.3, 0.8))

    def mouse_zigzag(self, target_element=None):
        """
        Mouse'u zigzag yaparak hareket ettir
        """
        try:
            actions = ActionChains(self.driver)

            # Rastgele ara noktalar
            points = random.randint(2, 4)
            for _ in range(points):
                x_offset = random.randint(-50, 50)
                y_offset = random.randint(-30, 30)
                actions.move_by_offset(x_offset, y_offset)
                actions.pause(random.uniform(0.05, 0.15))

            # Hedef elemente git
            if target_element:
                actions.move_to_element(target_element)

            actions.perform()

            # Küçük son düzeltmeler
            time.sleep(random.uniform(0.1, 0.2))

        except Exception as e:
            self.log(f"Mouse zigzag hatası: {e}", "debug")

    def human_click(self, element):
        """
        İnsan gibi tıklama - önce yaklaş, sonra tıkla
        """
        try:
            # Elemente scroll
            self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
            time.sleep(random.uniform(0.2, 0.5))

            # Mouse zigzag ile yaklaş
            self.mouse_zigzag(element)
            time.sleep(random.uniform(0.1, 0.3))

            # Tıkla
            element.click()

            self.random_delay(0.3, 0.8)

        except Exception as e:
            self.log(f"Tıklama hatası: {e}", "warning")
            # Fallback: JavaScript click
            try:
                self.driver.execute_script("arguments[0].click();", element)
            except:
                raise

    def scroll_to_bottom(self, max_scrolls: int = 10, check_new_content: bool = True):
        """
        Sayfanın sonuna kadar scroll - infinite scroll için
        """
        last_height = self.driver.execute_script("return document.body.scrollHeight")
        scroll_count = 0

        while scroll_count < max_scrolls:
            # İnsan gibi scroll
            self.human_scroll("down", random.randint(500, 900))
            self.random_delay(1, 2)

            # %30 ihtimalle ekstra duraklama (okuma)
            if random.random() < 0.3:
                self.random_delay(1, 3)

            scroll_count += 1

            if check_new_content:
                new_height = self.driver.execute_script("return document.body.scrollHeight")
                if new_height == last_height:
                    self.log(f"Sayfa sonu - {scroll_count} scroll yapıldı")
                    break
                last_height = new_height

        return scroll_count

    def close_cookie_banner(self, selectors: list = None):
        """
        Cookie banner'ı kapat
        """
        default_selectors = [
            "#onetrust-accept-btn-handler",
            "#gdpr-banner-accept",
            "[data-testid='cookie-accept']",
            "#didomi-notice-agree-button",
            "button[id*='accept']",
            "[class*='cookie'] button[class*='accept']",
            "button[class*='consent']",
        ]

        selectors = selectors or default_selectors

        for selector in selectors:
            try:
                btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.log(f"Cookie banner bulundu: {selector}")
                    self.human_click(btn)
                    self.screenshot("cookie_closed")
                    return True
            except:
                pass

        self.log("Cookie banner bulunamadı veya zaten kapalı", "debug")
        return False

    def go_back(self):
        """Tarayıcıda geri git"""
        self.log("Geri gidiliyor...")
        self.driver.back()
        self.random_delay(1, 2)
        self.screenshot("back")

    def visit_url(self, url: str):
        """URL'e git"""
        self.log(f"URL: {url}")
        self.driver.get(url)
        self.random_delay(2, 4)
        self.screenshot("page_loaded")

    def close(self):
        """Driver'ı kapat"""
        if self.driver:
            try:
                self.driver.quit()
                self.log("Driver kapatıldı")
            except:
                pass
            self.driver = None

    def __enter__(self):
        self.init_driver()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
