"""
TATANGA V3 - Celery Worker
"""
import sys
import os

# Add backend to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from celery import Celery
from datetime import datetime
import logging

celery_app = Celery(
    "tatanga_worker",
    broker="redis://localhost:6379/0",
    backend="redis://localhost:6379/1"
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Europe/Berlin",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=600,
    worker_prefetch_multiplier=1,
    worker_concurrency=2,
)

logger = logging.getLogger("TATANGA.celery")


@celery_app.task(bind=True, name="tatanga.scrape")
def scrape_task(self, platform: str, query: str, max_pages: int = 3, max_items: int = 50):
    from services.scraper_service import run_scrape_task

    logger.info(f"Starting scrape: {platform} - {query}")
    self.update_state(state="PROGRESS", meta={"status": "scraping", "platform": platform})

    try:
        result = run_scrape_task(platform, query, max_pages, max_items)
        items_found = result.get("stats", {}).get("items_found", 0)
        logger.info(f"Completed: {items_found} items")
        return result
    except Exception as e:
        logger.error(f"Failed: {e}")
        return {"status": "error", "error": str(e), "platform": platform, "query": query}


@celery_app.task(name="tatanga.url_monitor")
def url_monitor_task():
    """Check all active tracked URLs"""
    from services.url_checker import URLChecker
    from sqlalchemy import create_engine, text
    from config import DATABASE_URL

    logger.info("URL monitor running")

    # Use sync database connection for Celery
    sync_db_url = DATABASE_URL.replace("+asyncpg", "")
    engine = create_engine(sync_db_url)

    checked = 0
    updated = 0

    try:
        with engine.connect() as conn:
            # Get active URLs to check
            result = conn.execute(text("""
                SELECT id, product_id, source_url
                FROM url_tracking
                WHERE status = 'active'
                ORDER BY last_checked ASC NULLS FIRST
                LIMIT 20
            """))
            urls_to_check = result.fetchall()

            checker = URLChecker()

            for row in urls_to_check:
                tracking_id, product_id, source_url = row
                check_result = checker.check_url(source_url)
                checked += 1

                # Update database
                conn.execute(text("""
                    UPDATE url_tracking
                    SET status = :status,
                        last_checked = NOW(),
                        check_count = check_count + 1,
                        last_error = :error
                    WHERE id = :id
                """), {
                    "status": check_result["status"],
                    "error": check_result.get("error"),
                    "id": tracking_id
                })

                if check_result["status"] != "active":
                    updated += 1
                    logger.info(f"URL status changed: {tracking_id} -> {check_result['status']}")

            conn.commit()

    except Exception as e:
        logger.error(f"URL monitor error: {e}")
        return {"status": "error", "error": str(e)}
    finally:
        engine.dispose()

    return {
        "status": "ok",
        "checked_at": datetime.now().isoformat(),
        "urls_checked": checked,
        "status_changes": updated
    }


celery_app.conf.beat_schedule = {
    "url-monitor-every-5-minutes": {
        "task": "tatanga.url_monitor",
        "schedule": 300.0,
    },
}

if __name__ == "__main__":
    celery_app.start()
