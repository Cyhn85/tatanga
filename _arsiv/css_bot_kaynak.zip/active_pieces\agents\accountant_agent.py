#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MUHASEBECI AJAN - Accounting Agent
Automated accounting and invoice management system

Features:
- Sales tracking (satış takibi)
- Purchase tracking (alım takibi)
- Expense tracking (masraf takibi)
- Invoice parsing from images/screenshots (görüntü/SS fatura okuma)
- Multi-store accounting (çoklu mağaza muhasebesi)
- Telegram notifications (Telegram bildirimleri)
- Financial reports (mali raporlar)
- Tax calculations (vergi hesaplamaları)

Author: TATANGA Team
Version: 1.0
"""

import sys
import json
import sqlite3
import base64
import re
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from decimal import Decimal, ROUND_HALF_UP

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.logger import ModuleLogger
from agents.base_agent import BaseAgent, AgentConfig, AgentStatus


# ============================================================================
# DATA MODELS
# ============================================================================

class TransactionType(Enum):
    """Transaction types"""
    SALE = "sale"  # Satış
    PURCHASE = "purchase"  # Alım
    EXPENSE = "expense"  # Masraf
    REFUND = "refund"  # İade
    SHIPPING = "shipping"  # Kargo
    FEE = "fee"  # Platform komisyonu
    TAX = "tax"  # Vergi


class PaymentMethod(Enum):
    """Payment methods"""
    CASH = "cash"  # Nakit
    CARD = "card"  # Kart
    BANK_TRANSFER = "bank_transfer"  # Havale/EFT
    PAYPAL = "paypal"
    PLATFORM = "platform"  # Platform üzerinden
    OTHER = "other"


class InvoiceStatus(Enum):
    """Invoice status"""
    PENDING = "pending"  # Beklemede
    PAID = "paid"  # Ödendi
    PARTIAL = "partial"  # Kısmi ödeme
    OVERDUE = "overdue"  # Vadesi geçmiş
    CANCELLED = "cancelled"  # İptal


@dataclass
class Transaction:
    """Financial transaction"""
    id: int = None
    transaction_type: TransactionType = TransactionType.SALE
    store_name: str = ""
    platform: str = ""
    description: str = ""
    amount: Decimal = Decimal("0.00")
    currency: str = "EUR"
    tax_amount: Decimal = Decimal("0.00")
    tax_rate: Decimal = Decimal("0.19")  # 19% default
    net_amount: Decimal = Decimal("0.00")
    payment_method: PaymentMethod = PaymentMethod.PLATFORM
    reference_id: str = ""  # Order ID, Invoice ID, etc.
    category: str = ""
    notes: str = ""
    invoice_path: str = ""  # Path to invoice file
    created_at: datetime = None
    updated_at: datetime = None

    def calculate_net(self):
        """Calculate net amount from gross"""
        self.net_amount = self.amount - self.tax_amount

    def calculate_tax(self):
        """Calculate tax from gross amount"""
        self.tax_amount = (self.amount * self.tax_rate) / (1 + self.tax_rate)
        self.tax_amount = self.tax_amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        self.calculate_net()


@dataclass
class Invoice:
    """Invoice record"""
    id: int = None
    invoice_number: str = ""
    invoice_type: TransactionType = TransactionType.SALE
    status: InvoiceStatus = InvoiceStatus.PENDING
    store_name: str = ""
    platform: str = ""
    customer_name: str = ""
    customer_address: str = ""
    items: List[Dict] = field(default_factory=list)
    subtotal: Decimal = Decimal("0.00")
    tax_amount: Decimal = Decimal("0.00")
    total: Decimal = Decimal("0.00")
    currency: str = "EUR"
    issue_date: datetime = None
    due_date: datetime = None
    paid_date: datetime = None
    payment_method: PaymentMethod = None
    notes: str = ""
    file_path: str = ""  # Uploaded invoice file
    ocr_text: str = ""  # Extracted text from image
    created_at: datetime = None


@dataclass
class ExpenseCategory:
    """Expense category"""
    id: int = None
    name: str = ""
    name_tr: str = ""  # Turkish name
    description: str = ""
    tax_deductible: bool = True
    default_tax_rate: Decimal = Decimal("0.19")


# Default expense categories
DEFAULT_EXPENSE_CATEGORIES = [
    ExpenseCategory(name="shipping", name_tr="Kargo", description="Shipping and delivery costs", tax_deductible=True),
    ExpenseCategory(name="packaging", name_tr="Ambalaj", description="Packaging materials", tax_deductible=True),
    ExpenseCategory(name="platform_fees", name_tr="Platform Komisyonu", description="Platform fees and commissions", tax_deductible=True),
    ExpenseCategory(name="payment_fees", name_tr="Ödeme Komisyonu", description="Payment processing fees", tax_deductible=True),
    ExpenseCategory(name="inventory", name_tr="Stok/Ürün Alımı", description="Inventory purchases", tax_deductible=True),
    ExpenseCategory(name="marketing", name_tr="Reklam/Pazarlama", description="Marketing and advertising", tax_deductible=True),
    ExpenseCategory(name="software", name_tr="Yazılım", description="Software subscriptions", tax_deductible=True),
    ExpenseCategory(name="office", name_tr="Ofis Giderleri", description="Office supplies and expenses", tax_deductible=True),
    ExpenseCategory(name="travel", name_tr="Seyahat", description="Travel expenses", tax_deductible=True),
    ExpenseCategory(name="utilities", name_tr="Faturalar", description="Utilities (electricity, internet)", tax_deductible=True),
    ExpenseCategory(name="other", name_tr="Diğer", description="Other expenses", tax_deductible=True),
]


# ============================================================================
# ACCOUNTANT AGENT
# ============================================================================

class AccountantAgent(BaseAgent):
    """
    Muhasebeci Ajan - Automated accounting agent

    Features:
    - Automatic transaction recording from store sales
    - Invoice parsing from images/screenshots using OCR/AI
    - Expense tracking and categorization
    - Financial reports and summaries
    - Telegram notifications for important events
    - Multi-currency support
    - Tax calculations (VAT/KDV)
    """

    # Tax rates by country
    TAX_RATES = {
        'DE': Decimal("0.19"),  # Germany 19%
        'FR': Decimal("0.20"),  # France 20%
        'UK': Decimal("0.20"),  # UK 20%
        'ES': Decimal("0.21"),  # Spain 21%
        'IT': Decimal("0.22"),  # Italy 22%
        'NL': Decimal("0.21"),  # Netherlands 21%
        'AT': Decimal("0.20"),  # Austria 20%
        'TR': Decimal("0.20"),  # Turkey 20%
    }

    def __init__(self, interval_seconds: int = 300):
        """
        Initialize Accountant Agent

        Args:
            interval_seconds: Check interval (default 5 minutes)
        """
        config = AgentConfig(
            name="accountant",
            interval_seconds=interval_seconds,
            max_retries=3
        )
        super().__init__(config)

        self.logger = ModuleLogger('accountant_agent')

        # Database path
        self.db_path = Path(__file__).parent.parent / 'storage' / 'accounting.db'
        self._init_db()

        # Telegram settings
        self.telegram_enabled = True
        self.telegram_chat_id = None

        # Store configurations
        self.stores: Dict[str, Dict] = {}

        self.logger.info("Accountant Agent initialized")

    def _init_db(self):
        """Initialize accounting database"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Transactions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_type TEXT NOT NULL,
                store_name TEXT,
                platform TEXT,
                description TEXT,
                amount REAL NOT NULL,
                currency TEXT DEFAULT 'EUR',
                tax_amount REAL DEFAULT 0,
                tax_rate REAL DEFAULT 0.19,
                net_amount REAL,
                payment_method TEXT,
                reference_id TEXT,
                category TEXT,
                notes TEXT,
                invoice_path TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Invoices table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS invoices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_number TEXT UNIQUE,
                invoice_type TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                store_name TEXT,
                platform TEXT,
                customer_name TEXT,
                customer_address TEXT,
                items_json TEXT,
                subtotal REAL,
                tax_amount REAL,
                total REAL,
                currency TEXT DEFAULT 'EUR',
                issue_date DATE,
                due_date DATE,
                paid_date DATE,
                payment_method TEXT,
                notes TEXT,
                file_path TEXT,
                ocr_text TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Expense categories
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS expense_categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                name_tr TEXT,
                description TEXT,
                tax_deductible INTEGER DEFAULT 1,
                default_tax_rate REAL DEFAULT 0.19
            )
        """)

        # Monthly summaries (cache)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS monthly_summaries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                year INTEGER NOT NULL,
                month INTEGER NOT NULL,
                store_name TEXT,
                total_sales REAL DEFAULT 0,
                total_purchases REAL DEFAULT 0,
                total_expenses REAL DEFAULT 0,
                total_tax_collected REAL DEFAULT 0,
                total_tax_paid REAL DEFAULT 0,
                net_profit REAL DEFAULT 0,
                transaction_count INTEGER DEFAULT 0,
                currency TEXT DEFAULT 'EUR',
                calculated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(year, month, store_name)
            )
        """)

        # Stores table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS stores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                platform TEXT,
                country TEXT DEFAULT 'DE',
                tax_rate REAL DEFAULT 0.19,
                currency TEXT DEFAULT 'EUR',
                is_active INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Insert default expense categories
        for cat in DEFAULT_EXPENSE_CATEGORIES:
            try:
                cursor.execute("""
                    INSERT OR IGNORE INTO expense_categories (name, name_tr, description, tax_deductible, default_tax_rate)
                    VALUES (?, ?, ?, ?, ?)
                """, (cat.name, cat.name_tr, cat.description, 1 if cat.tax_deductible else 0, float(cat.default_tax_rate)))
            except:
                pass

        conn.commit()
        conn.close()

        self.logger.info("Accounting database initialized")

    # ========================================================================
    # AGENT METHODS
    # ========================================================================

    async def process(self):
        """Main agent processing loop"""
        try:
            # Check for new sales from stores
            await self._check_store_sales()

            # Check for overdue invoices
            await self._check_overdue_invoices()

            # Update monthly summaries
            self._update_monthly_summary()

            self.logger.debug("Accountant agent cycle completed")

        except Exception as e:
            self.logger.error(f"Accountant agent error: {e}")
            raise

    async def _check_store_sales(self):
        """Check for new sales from connected stores"""
        # This would integrate with StoreAgent
        pass

    async def _check_overdue_invoices(self):
        """Check for overdue invoices and send notifications"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, invoice_number, customer_name, total, due_date
            FROM invoices
            WHERE status = 'pending' AND due_date < date('now')
        """)

        overdue = cursor.fetchall()
        conn.close()

        for inv in overdue:
            self.logger.warning(f"Overdue invoice: {inv[1]} - {inv[2]} - {inv[3]} EUR")
            # Update status
            self._update_invoice_status(inv[0], InvoiceStatus.OVERDUE)
            # Send notification
            if self.telegram_enabled:
                await self._notify_overdue(inv)

    async def _notify_overdue(self, invoice_data: tuple):
        """Send Telegram notification for overdue invoice"""
        # Would integrate with Telegram bot
        pass

    # ========================================================================
    # TRANSACTION MANAGEMENT
    # ========================================================================

    def record_sale(
        self,
        amount: float,
        store_name: str,
        platform: str = None,
        description: str = "",
        reference_id: str = "",
        payment_method: PaymentMethod = PaymentMethod.PLATFORM,
        tax_rate: float = None,
        currency: str = "EUR",
        notes: str = ""
    ) -> int:
        """
        Record a sale transaction

        Args:
            amount: Sale amount (gross)
            store_name: Store name
            platform: Platform (vinted_de, ebay_uk, etc.)
            description: Sale description
            reference_id: Order/transaction ID
            payment_method: Payment method
            tax_rate: Tax rate (uses store default if None)
            currency: Currency code
            notes: Additional notes

        Returns:
            Transaction ID
        """
        if tax_rate is None:
            tax_rate = self._get_store_tax_rate(store_name)

        amount_dec = Decimal(str(amount))
        tax_rate_dec = Decimal(str(tax_rate))

        # Calculate tax (from gross)
        tax_amount = (amount_dec * tax_rate_dec) / (1 + tax_rate_dec)
        tax_amount = tax_amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        net_amount = amount_dec - tax_amount

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO transactions (
                transaction_type, store_name, platform, description,
                amount, currency, tax_amount, tax_rate, net_amount,
                payment_method, reference_id, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            TransactionType.SALE.value, store_name, platform, description,
            float(amount_dec), currency, float(tax_amount), float(tax_rate_dec), float(net_amount),
            payment_method.value, reference_id, notes
        ))

        transaction_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Sale recorded: {amount} {currency} from {store_name} (ID: {transaction_id})")
        return transaction_id

    def record_purchase(
        self,
        amount: float,
        description: str,
        store_name: str = None,
        platform: str = None,
        reference_id: str = "",
        payment_method: PaymentMethod = PaymentMethod.PLATFORM,
        tax_rate: float = 0.19,
        currency: str = "EUR",
        invoice_path: str = "",
        notes: str = ""
    ) -> int:
        """
        Record a purchase (inventory acquisition)

        Args:
            amount: Purchase amount (gross)
            description: Item description
            store_name: Store making purchase
            platform: Source platform
            reference_id: Order ID
            payment_method: Payment method
            tax_rate: Tax rate
            currency: Currency
            invoice_path: Path to invoice file
            notes: Notes

        Returns:
            Transaction ID
        """
        amount_dec = Decimal(str(amount))
        tax_rate_dec = Decimal(str(tax_rate))

        tax_amount = (amount_dec * tax_rate_dec) / (1 + tax_rate_dec)
        tax_amount = tax_amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        net_amount = amount_dec - tax_amount

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO transactions (
                transaction_type, store_name, platform, description,
                amount, currency, tax_amount, tax_rate, net_amount,
                payment_method, reference_id, invoice_path, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            TransactionType.PURCHASE.value, store_name, platform, description,
            float(amount_dec), currency, float(tax_amount), float(tax_rate_dec), float(net_amount),
            payment_method.value, reference_id, invoice_path, notes
        ))

        transaction_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Purchase recorded: {amount} {currency} - {description} (ID: {transaction_id})")
        return transaction_id

    def record_expense(
        self,
        amount: float,
        category: str,
        description: str,
        store_name: str = None,
        payment_method: PaymentMethod = PaymentMethod.BANK_TRANSFER,
        tax_rate: float = 0.19,
        currency: str = "EUR",
        invoice_path: str = "",
        reference_id: str = "",
        notes: str = ""
    ) -> int:
        """
        Record an expense

        Args:
            amount: Expense amount
            category: Expense category
            description: Description
            store_name: Related store
            payment_method: Payment method
            tax_rate: Tax rate
            currency: Currency
            invoice_path: Invoice file path
            reference_id: Reference/invoice number
            notes: Notes

        Returns:
            Transaction ID
        """
        amount_dec = Decimal(str(amount))
        tax_rate_dec = Decimal(str(tax_rate))

        tax_amount = (amount_dec * tax_rate_dec) / (1 + tax_rate_dec)
        tax_amount = tax_amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        net_amount = amount_dec - tax_amount

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO transactions (
                transaction_type, store_name, description, category,
                amount, currency, tax_amount, tax_rate, net_amount,
                payment_method, reference_id, invoice_path, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            TransactionType.EXPENSE.value, store_name, description, category,
            float(amount_dec), currency, float(tax_amount), float(tax_rate_dec), float(net_amount),
            payment_method.value, reference_id, invoice_path, notes
        ))

        transaction_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Expense recorded: {amount} {currency} - {category} (ID: {transaction_id})")
        return transaction_id

    # ========================================================================
    # INVOICE MANAGEMENT
    # ========================================================================

    def create_invoice(
        self,
        invoice_type: TransactionType,
        store_name: str,
        customer_name: str,
        items: List[Dict],
        customer_address: str = "",
        platform: str = None,
        due_days: int = 14,
        notes: str = ""
    ) -> Tuple[int, str]:
        """
        Create a new invoice

        Args:
            invoice_type: Type (SALE, PURCHASE)
            store_name: Store name
            customer_name: Customer/vendor name
            items: List of items [{name, quantity, unit_price, tax_rate}]
            customer_address: Address
            platform: Platform
            due_days: Days until due
            notes: Notes

        Returns:
            (invoice_id, invoice_number)
        """
        # Generate invoice number
        invoice_number = self._generate_invoice_number(store_name, invoice_type)

        # Calculate totals
        subtotal = Decimal("0.00")
        tax_total = Decimal("0.00")

        for item in items:
            qty = Decimal(str(item.get('quantity', 1)))
            price = Decimal(str(item.get('unit_price', 0)))
            tax_rate = Decimal(str(item.get('tax_rate', 0.19)))

            line_total = qty * price
            line_tax = (line_total * tax_rate) / (1 + tax_rate)

            subtotal += line_total - line_tax
            tax_total += line_tax

        total = subtotal + tax_total

        issue_date = datetime.now()
        due_date = issue_date + timedelta(days=due_days)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO invoices (
                invoice_number, invoice_type, status, store_name, platform,
                customer_name, customer_address, items_json,
                subtotal, tax_amount, total, currency,
                issue_date, due_date, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            invoice_number, invoice_type.value, InvoiceStatus.PENDING.value,
            store_name, platform, customer_name, customer_address,
            json.dumps(items), float(subtotal), float(tax_total), float(total),
            'EUR', issue_date.date().isoformat(), due_date.date().isoformat(), notes
        ))

        invoice_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Invoice created: {invoice_number} - {total} EUR")
        return invoice_id, invoice_number

    def _generate_invoice_number(self, store_name: str, invoice_type: TransactionType) -> str:
        """Generate unique invoice number"""
        prefix = "INV" if invoice_type == TransactionType.SALE else "PUR"
        store_code = store_name[:3].upper() if store_name else "GEN"
        date_code = datetime.now().strftime("%Y%m")

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Get next sequence number
        cursor.execute("""
            SELECT COUNT(*) + 1 FROM invoices
            WHERE invoice_number LIKE ?
        """, (f"{prefix}-{store_code}-{date_code}%",))

        seq = cursor.fetchone()[0]
        conn.close()

        return f"{prefix}-{store_code}-{date_code}-{seq:04d}"

    def _update_invoice_status(self, invoice_id: int, status: InvoiceStatus):
        """Update invoice status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE invoices SET status = ? WHERE id = ?
        """, (status.value, invoice_id))

        conn.commit()
        conn.close()

    def mark_invoice_paid(
        self,
        invoice_id: int,
        payment_method: PaymentMethod,
        paid_date: datetime = None
    ):
        """Mark invoice as paid"""
        if paid_date is None:
            paid_date = datetime.now()

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE invoices
            SET status = ?, payment_method = ?, paid_date = ?
            WHERE id = ?
        """, (InvoiceStatus.PAID.value, payment_method.value, paid_date.date().isoformat(), invoice_id))

        conn.commit()
        conn.close()

        self.logger.info(f"Invoice {invoice_id} marked as paid")

    # ========================================================================
    # IMAGE/OCR INVOICE PARSING
    # ========================================================================

    def parse_invoice_image(self, image_path: str) -> Dict:
        """
        Parse invoice from image using OCR/AI

        Args:
            image_path: Path to invoice image

        Returns:
            Extracted invoice data
        """
        try:
            # Try using Groq vision or similar
            extracted = self._extract_invoice_with_ai(image_path)
            return extracted
        except Exception as e:
            self.logger.error(f"Invoice parsing failed: {e}")
            return {}

    def _extract_invoice_with_ai(self, image_path: str) -> Dict:
        """Extract invoice data using AI vision"""
        try:
            import httpx

            # Read and encode image
            with open(image_path, 'rb') as f:
                image_data = base64.b64encode(f.read()).decode('utf-8')

            # Determine image type
            ext = Path(image_path).suffix.lower()
            media_type = {
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.png': 'image/png',
                '.gif': 'image/gif',
                '.webp': 'image/webp'
            }.get(ext, 'image/jpeg')

            # Use Groq or similar API for extraction
            # This is a template - actual implementation depends on available API
            prompt = """
            Analyze this invoice image and extract the following information in JSON format:
            {
                "invoice_number": "",
                "date": "YYYY-MM-DD",
                "vendor_name": "",
                "vendor_address": "",
                "items": [{"name": "", "quantity": 1, "unit_price": 0.00}],
                "subtotal": 0.00,
                "tax_amount": 0.00,
                "total": 0.00,
                "currency": "EUR"
            }
            Only return the JSON, no other text.
            """

            # Placeholder for actual API call
            # Would use Groq, Claude, or similar vision API

            return {
                'success': False,
                'message': 'AI vision extraction not configured',
                'raw_text': ''
            }

        except Exception as e:
            self.logger.error(f"AI extraction error: {e}")
            return {'success': False, 'error': str(e)}

    def record_from_text(self, text: str, transaction_type: TransactionType = None) -> Dict:
        """
        Record transaction from text input

        Parses natural language like:
        - "Satış: 49.99 EUR, Vinted DE, sipariş #12345"
        - "Masraf: 15 EUR, kargo, DHL"
        - "Alım: 25 EUR, vintage ceket, Kleinanzeigen"

        Args:
            text: Natural language transaction description
            transaction_type: Override auto-detected type

        Returns:
            Created transaction info
        """
        # Parse text for transaction details
        parsed = self._parse_transaction_text(text)

        if not parsed.get('amount'):
            return {'success': False, 'error': 'Could not parse amount'}

        # Detect or use provided type
        if transaction_type is None:
            transaction_type = parsed.get('type', TransactionType.EXPENSE)

        # Record based on type
        try:
            if transaction_type == TransactionType.SALE:
                tid = self.record_sale(
                    amount=parsed['amount'],
                    store_name=parsed.get('store', ''),
                    platform=parsed.get('platform', ''),
                    description=parsed.get('description', ''),
                    reference_id=parsed.get('reference', ''),
                    notes=text
                )
            elif transaction_type == TransactionType.PURCHASE:
                tid = self.record_purchase(
                    amount=parsed['amount'],
                    description=parsed.get('description', ''),
                    platform=parsed.get('platform', ''),
                    reference_id=parsed.get('reference', ''),
                    notes=text
                )
            else:
                tid = self.record_expense(
                    amount=parsed['amount'],
                    category=parsed.get('category', 'other'),
                    description=parsed.get('description', ''),
                    notes=text
                )

            return {'success': True, 'transaction_id': tid, 'parsed': parsed}

        except Exception as e:
            return {'success': False, 'error': str(e)}

    def _parse_transaction_text(self, text: str) -> Dict:
        """Parse transaction from natural language text"""
        result = {}

        text_lower = text.lower()

        # Detect type
        if any(w in text_lower for w in ['satış', 'sale', 'sold', 'sattım']):
            result['type'] = TransactionType.SALE
        elif any(w in text_lower for w in ['alım', 'purchase', 'bought', 'aldım']):
            result['type'] = TransactionType.PURCHASE
        elif any(w in text_lower for w in ['masraf', 'expense', 'gider', 'harcama']):
            result['type'] = TransactionType.EXPENSE
        else:
            result['type'] = TransactionType.EXPENSE

        # Extract amount
        amount_patterns = [
            r'(\d+[.,]\d{2})\s*(eur|euro|€|tl|gbp|usd)',
            r'(€|£|\$)\s*(\d+[.,]\d{2})',
            r'(\d+[.,]\d{2})',
            r'(\d+)\s*(eur|euro|€|tl)'
        ]

        for pattern in amount_patterns:
            match = re.search(pattern, text_lower)
            if match:
                amount_str = match.group(1).replace(',', '.')
                result['amount'] = float(amount_str)
                break

        # Extract reference/order ID
        ref_patterns = [
            r'#(\w+)',
            r'sipariş\s*[:#]?\s*(\w+)',
            r'order\s*[:#]?\s*(\w+)',
            r'fatura\s*[:#]?\s*(\w+)'
        ]

        for pattern in ref_patterns:
            match = re.search(pattern, text_lower)
            if match:
                result['reference'] = match.group(1)
                break

        # Detect platform
        platforms = {
            'vinted': 'vinted',
            'ebay': 'ebay',
            'kleinanzeigen': 'kleinanzeigen',
            'shpock': 'shpock',
            'leboncoin': 'leboncoin',
            'cssberlin': 'cssberlin'
        }

        for key, platform in platforms.items():
            if key in text_lower:
                result['platform'] = platform
                break

        # Detect expense category
        categories = {
            'kargo': 'shipping', 'shipping': 'shipping', 'dhl': 'shipping', 'ups': 'shipping',
            'komisyon': 'platform_fees', 'fee': 'platform_fees',
            'ambalaj': 'packaging', 'packaging': 'packaging',
            'reklam': 'marketing', 'marketing': 'marketing',
            'yazılım': 'software', 'software': 'software',
        }

        for key, category in categories.items():
            if key in text_lower:
                result['category'] = category
                break

        # Rest is description
        result['description'] = text[:100]

        return result

    # ========================================================================
    # REPORTS
    # ========================================================================

    def get_daily_summary(self, date: datetime = None, store_name: str = None) -> Dict:
        """Get daily financial summary"""
        if date is None:
            date = datetime.now()

        date_str = date.strftime('%Y-%m-%d')

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Build query
        store_filter = "AND store_name = ?" if store_name else ""
        params = [date_str, date_str]
        if store_name:
            params.extend([store_name, store_name, store_name])

        # Sales
        cursor.execute(f"""
            SELECT COALESCE(SUM(amount), 0), COALESCE(SUM(tax_amount), 0), COUNT(*)
            FROM transactions
            WHERE transaction_type = 'sale'
            AND DATE(created_at) = ?
            {store_filter.replace('?', '?') if store_name else ''}
        """, [date_str] + ([store_name] if store_name else []))
        sales = cursor.fetchone()

        # Purchases
        cursor.execute(f"""
            SELECT COALESCE(SUM(amount), 0), COALESCE(SUM(tax_amount), 0), COUNT(*)
            FROM transactions
            WHERE transaction_type = 'purchase'
            AND DATE(created_at) = ?
            {store_filter.replace('?', '?') if store_name else ''}
        """, [date_str] + ([store_name] if store_name else []))
        purchases = cursor.fetchone()

        # Expenses
        cursor.execute(f"""
            SELECT COALESCE(SUM(amount), 0), COALESCE(SUM(tax_amount), 0), COUNT(*)
            FROM transactions
            WHERE transaction_type = 'expense'
            AND DATE(created_at) = ?
            {store_filter.replace('?', '?') if store_name else ''}
        """, [date_str] + ([store_name] if store_name else []))
        expenses = cursor.fetchone()

        conn.close()

        net_profit = sales[0] - purchases[0] - expenses[0]

        return {
            'date': date_str,
            'store': store_name or 'ALL',
            'sales': {
                'total': round(sales[0], 2),
                'tax': round(sales[1], 2),
                'count': sales[2]
            },
            'purchases': {
                'total': round(purchases[0], 2),
                'tax': round(purchases[1], 2),
                'count': purchases[2]
            },
            'expenses': {
                'total': round(expenses[0], 2),
                'tax': round(expenses[1], 2),
                'count': expenses[2]
            },
            'net_profit': round(net_profit, 2),
            'tax_balance': round(sales[1] - purchases[1] - expenses[1], 2)
        }

    def get_monthly_summary(self, year: int = None, month: int = None, store_name: str = None) -> Dict:
        """Get monthly financial summary"""
        if year is None:
            year = datetime.now().year
        if month is None:
            month = datetime.now().month

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        store_filter = "AND store_name = ?" if store_name else ""

        # Sales
        cursor.execute(f"""
            SELECT COALESCE(SUM(amount), 0), COALESCE(SUM(tax_amount), 0), COALESCE(SUM(net_amount), 0), COUNT(*)
            FROM transactions
            WHERE transaction_type = 'sale'
            AND strftime('%Y', created_at) = ?
            AND strftime('%m', created_at) = ?
            {store_filter}
        """, [str(year), f"{month:02d}"] + ([store_name] if store_name else []))
        sales = cursor.fetchone()

        # Purchases
        cursor.execute(f"""
            SELECT COALESCE(SUM(amount), 0), COALESCE(SUM(tax_amount), 0), COUNT(*)
            FROM transactions
            WHERE transaction_type = 'purchase'
            AND strftime('%Y', created_at) = ?
            AND strftime('%m', created_at) = ?
            {store_filter}
        """, [str(year), f"{month:02d}"] + ([store_name] if store_name else []))
        purchases = cursor.fetchone()

        # Expenses by category
        cursor.execute(f"""
            SELECT category, COALESCE(SUM(amount), 0), COUNT(*)
            FROM transactions
            WHERE transaction_type = 'expense'
            AND strftime('%Y', created_at) = ?
            AND strftime('%m', created_at) = ?
            {store_filter}
            GROUP BY category
        """, [str(year), f"{month:02d}"] + ([store_name] if store_name else []))
        expense_breakdown = {row[0]: {'total': round(row[1], 2), 'count': row[2]} for row in cursor.fetchall()}

        total_expenses = sum(e['total'] for e in expense_breakdown.values())

        conn.close()

        gross_profit = sales[0] - purchases[0]
        net_profit = gross_profit - total_expenses

        return {
            'period': f"{year}-{month:02d}",
            'store': store_name or 'ALL',
            'sales': {
                'gross': round(sales[0], 2),
                'tax_collected': round(sales[1], 2),
                'net': round(sales[2], 2),
                'count': sales[3]
            },
            'purchases': {
                'total': round(purchases[0], 2),
                'tax_paid': round(purchases[1], 2),
                'count': purchases[2]
            },
            'expenses': {
                'total': round(total_expenses, 2),
                'breakdown': expense_breakdown
            },
            'profit': {
                'gross': round(gross_profit, 2),
                'net': round(net_profit, 2)
            },
            'tax': {
                'collected': round(sales[1], 2),
                'deductible': round(purchases[1], 2),
                'balance': round(sales[1] - purchases[1], 2)
            }
        }

    def _update_monthly_summary(self):
        """Update cached monthly summary"""
        now = datetime.now()
        summary = self.get_monthly_summary(now.year, now.month)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO monthly_summaries (
                year, month, store_name, total_sales, total_purchases,
                total_expenses, total_tax_collected, total_tax_paid, net_profit, transaction_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(year, month, store_name) DO UPDATE SET
                total_sales = excluded.total_sales,
                total_purchases = excluded.total_purchases,
                total_expenses = excluded.total_expenses,
                total_tax_collected = excluded.total_tax_collected,
                total_tax_paid = excluded.total_tax_paid,
                net_profit = excluded.net_profit,
                transaction_count = excluded.transaction_count,
                calculated_at = CURRENT_TIMESTAMP
        """, (
            now.year, now.month, 'ALL',
            summary['sales']['gross'], summary['purchases']['total'],
            summary['expenses']['total'], summary['tax']['collected'],
            summary['tax']['deductible'], summary['profit']['net'],
            summary['sales']['count'] + summary['purchases']['count']
        ))

        conn.commit()
        conn.close()

    # ========================================================================
    # STORE MANAGEMENT
    # ========================================================================

    def add_store(
        self,
        name: str,
        platform: str = None,
        country: str = 'DE',
        currency: str = 'EUR'
    ) -> bool:
        """Add a store for accounting"""
        tax_rate = self.TAX_RATES.get(country, Decimal("0.19"))

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT INTO stores (name, platform, country, tax_rate, currency)
                VALUES (?, ?, ?, ?, ?)
            """, (name, platform, country, float(tax_rate), currency))
            conn.commit()
            self.logger.info(f"Store added: {name}")
            return True
        except sqlite3.IntegrityError:
            self.logger.warning(f"Store already exists: {name}")
            return False
        finally:
            conn.close()

    def get_stores(self) -> List[Dict]:
        """Get all stores"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT name, platform, country, tax_rate, currency, is_active
            FROM stores ORDER BY name
        """)

        stores = [
            {
                'name': row[0],
                'platform': row[1],
                'country': row[2],
                'tax_rate': row[3],
                'currency': row[4],
                'is_active': bool(row[5])
            }
            for row in cursor.fetchall()
        ]

        conn.close()
        return stores

    def _get_store_tax_rate(self, store_name: str) -> float:
        """Get tax rate for store"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("SELECT tax_rate FROM stores WHERE name = ?", (store_name,))
        row = cursor.fetchone()
        conn.close()

        return row[0] if row else 0.19

    # ========================================================================
    # TRANSACTIONS LIST
    # ========================================================================

    def get_transactions(
        self,
        transaction_type: TransactionType = None,
        store_name: str = None,
        start_date: datetime = None,
        end_date: datetime = None,
        limit: int = 100
    ) -> List[Dict]:
        """Get transactions with filters"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        query = "SELECT * FROM transactions WHERE 1=1"
        params = []

        if transaction_type:
            query += " AND transaction_type = ?"
            params.append(transaction_type.value)

        if store_name:
            query += " AND store_name = ?"
            params.append(store_name)

        if start_date:
            query += " AND created_at >= ?"
            params.append(start_date.isoformat())

        if end_date:
            query += " AND created_at <= ?"
            params.append(end_date.isoformat())

        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)

        cursor.execute(query, params)
        columns = [desc[0] for desc in cursor.description]
        transactions = [dict(zip(columns, row)) for row in cursor.fetchall()]

        conn.close()
        return transactions

    def get_expense_categories(self) -> List[Dict]:
        """Get expense categories"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM expense_categories ORDER BY name")
        columns = [desc[0] for desc in cursor.description]
        categories = [dict(zip(columns, row)) for row in cursor.fetchall()]

        conn.close()
        return categories


# ============================================================================
# CLI TEST
# ============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("MUHASEBECI AJAN - Accountant Agent Test")
    print("=" * 60)

    agent = AccountantAgent()

    # Add test store
    agent.add_store("cssberlin", "website", "DE", "EUR")
    agent.add_store("vinted_de", "vinted", "DE", "EUR")

    # Test sales
    print("\nRecording test transactions...")
    sale_id = agent.record_sale(
        amount=49.99,
        store_name="vinted_de",
        platform="vinted_de",
        description="Vintage Levi's Jacket",
        reference_id="VT123456"
    )
    print(f"Sale recorded: ID {sale_id}")

    # Test expense
    expense_id = agent.record_expense(
        amount=5.99,
        category="shipping",
        description="DHL shipping label",
        store_name="vinted_de"
    )
    print(f"Expense recorded: ID {expense_id}")

    # Test text parsing
    print("\nTesting text parsing...")
    result = agent.record_from_text("Satış: 35.50 EUR, Vinted DE, sipariş #VT789")
    print(f"Text parsing result: {result}")

    # Get summaries
    print("\nDaily Summary:")
    daily = agent.get_daily_summary()
    print(f"  Sales: {daily['sales']['total']} EUR ({daily['sales']['count']} transactions)")
    print(f"  Expenses: {daily['expenses']['total']} EUR")
    print(f"  Net Profit: {daily['net_profit']} EUR")

    print("\nMonthly Summary:")
    monthly = agent.get_monthly_summary()
    print(f"  Period: {monthly['period']}")
    print(f"  Gross Sales: {monthly['sales']['gross']} EUR")
    print(f"  Net Profit: {monthly['profit']['net']} EUR")
    print(f"  Tax Balance: {monthly['tax']['balance']} EUR")

    print("\nExpense Categories:")
    for cat in agent.get_expense_categories()[:5]:
        print(f"  - {cat['name_tr']} ({cat['name']})")

    print("\n" + "=" * 60)