# -*- coding: utf-8 -*-
"""
EBAY DE V2 SCRAPER - Pagination + Robotic + Extended Delays
============================================================
- Full pagination support
- Extended delays: +5 seconds between actions
- Robotic scroll patterns
- Cookie consent handling
- Target: 1200+ products
"""

import sys
import io

# Safe stdout wrapper for Windows - skip if already wrapped or in special environment
if sys.platform == 'win32':
    try:
        if hasattr(sys.stdout, 'buffer') and not isinstance(sys.stdout, io.TextIOWrapper):
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    except (AttributeError, ValueError, OSError):
        pass

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import random
import json
import re
from typing import List, Dict, Optional
from datetime import datetime
from urllib.parse import quote_plus


class EbayDeV2Scraper:
    """
    eBay DE V2 - Enhanced scraper with pagination and robotic behavior
    """

    BASE_URL = "https://www.ebay.de"

    def __init__(self, headless: bool = False):
        self.headless = headless
        self.driver = None
        self.all_products = []
        self.base_delay = 4  # Base delay (reduced from 7 for faster scraping)

    def _random_delay(self, min_extra: float = 0, max_extra: float = 3) -> None:
        """Extended random delay with Gaussian distribution"""
        base = self.base_delay
        extra = random.gauss((min_extra + max_extra) / 2, (max_extra - min_extra) / 4)
        extra = max(min_extra, min(max_extra, extra))
        delay = base + extra
        print(f"    [WAIT] Waiting {delay:.1f}s...")
        time.sleep(delay)

    def _human_scroll(self) -> None:
        """Human-like scroll pattern - smooth and variable"""
        print(f"    [SCROLL] Human scroll pattern...")

        total_height = self.driver.execute_script("return document.body.scrollHeight")
        current_position = 0

        while current_position < total_height:
            scroll_amount = random.randint(200, 500)
            self.driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
            current_position += scroll_amount
            time.sleep(random.uniform(0.5, 1.2))

            if random.random() < 0.2:
                back_scroll = random.randint(50, 150)
                self.driver.execute_script(f"window.scrollBy(0, -{back_scroll});")
                current_position -= back_scroll
                time.sleep(random.uniform(0.3, 0.7))

            if random.random() < 0.15:
                time.sleep(random.uniform(1.5, 3))

            total_height = self.driver.execute_script("return document.body.scrollHeight")

        self.driver.execute_script(f"window.scrollTo(0, {random.randint(100, 500)});")
        time.sleep(0.5)

    def _robotic_scroll(self, scroll_count: int = 5) -> None:
        """Robotic scroll pattern to load lazy content"""
        print(f"    [ROBOT] Robotic scroll ({scroll_count}x)...")

        for i in range(scroll_count):
            scroll_amount = random.randint(300, 700)
            self.driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
            time.sleep(random.uniform(0.8, 1.5))

            if random.random() < 0.3:
                self.driver.execute_script(f"window.scrollBy(0, -{random.randint(50, 150)});")
                time.sleep(random.uniform(0.3, 0.6))

        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(1.5)

    def _handle_cookies(self) -> None:
        """Handle cookie consent popup"""
        print("    [COOKIE] Checking for cookie consent...")

        cookie_selectors = [
            "#gdpr-banner-accept",
            "button#onetrust-accept-btn-handler",
            "#consent-page button",
            "button[data-testid='gdpr-banner-accept']",
            ".btn--accept",
            "button.consent-accept",
            "#consentDialog button[id*='accept']",
        ]

        cookie_texts = ['Akzeptieren', 'Alle akzeptieren', 'Accept All', 'OK', 'Einverstanden']

        for selector in cookie_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for elem in elements:
                    if elem.is_displayed():
                        elem.click()
                        print(f"    [OK] Cookie accepted via: {selector[:30]}...")
                        time.sleep(2)
                        return
            except:
                continue

        for text in cookie_texts:
            try:
                elements = self.driver.find_elements(By.XPATH, f"//button[contains(text(), '{text}')]")
                for elem in elements:
                    if elem.is_displayed():
                        elem.click()
                        print(f"    [OK] Cookie accepted via text: {text}")
                        time.sleep(2)
                        return
            except:
                continue

    def _init_driver(self) -> None:
        """Initialize undetected Chrome driver"""
        print("[START] Initializing Chrome driver...")

        options = uc.ChromeOptions()

        if self.headless:
            options.add_argument('--headless=new')

        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_argument('--window-size=1920,1080')
        options.add_argument('--lang=de-DE')

        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        ]
        options.add_argument(f'--user-agent={random.choice(user_agents)}')

        # Use webdriver-manager to get correct chromedriver version
        driver_path = ChromeDriverManager().install()
        self.driver = uc.Chrome(options=options, driver_executable_path=driver_path)
        self.driver.implicitly_wait(10)
        print("[OK] Driver initialized")

    def _extract_products_from_page(self) -> List[Dict]:
        """Extract products from current page - V2 extraction with stale element fix"""
        products = []

        # eBay product card selectors
        selectors = [
            "li[data-viewport]",
            ".s-card",
            ".srp-results li",
            "li.s-item",
        ]

        # Find items with first matching selector
        items = []
        used_selector = None
        for selector in selectors:
            items = self.driver.find_elements(By.CSS_SELECTOR, selector)
            if items:
                used_selector = selector
                print(f"    [FOUND] Found {len(items)} items with selector: {selector[:40]}...")
                break

        if not items:
            return products

        # Process each item - re-find elements to avoid stale references
        total_items = len(items)
        print(f"    [EXTRACT] Processing {total_items} items...", flush=True)
        for idx in range(total_items):
            try:
                # Progress every 10 items
                if idx > 0 and idx % 10 == 0:
                    print(f"    [PROGRESS] {idx}/{total_items} items processed...", flush=True)

                # Re-find items to avoid stale element reference
                items_fresh = self.driver.find_elements(By.CSS_SELECTOR, used_selector)
                if idx >= len(items_fresh):
                    break
                item = items_fresh[idx]

                product = {}

                # URL - from a[href*="/itm/"]
                link_elems = item.find_elements(By.CSS_SELECTOR, 'a[href*="/itm/"]')
                if link_elems:
                    href = link_elems[0].get_attribute('href')
                    if href:
                        product['url'] = href

                # Title - from img alt attribute
                img_elems = item.find_elements(By.CSS_SELECTOR, 'img.s-card__image, img[alt]')
                if img_elems:
                    alt_text = img_elems[0].get_attribute('alt')
                    if alt_text:
                        product['title'] = alt_text.strip()
                    # Image URL
                    img_src = img_elems[0].get_attribute('src')
                    if img_src:
                        product['image'] = img_src

                # Fallback title from link title attribute
                if not product.get('title') and link_elems:
                    title_attr = link_elems[0].get_attribute('title')
                    if title_attr:
                        product['title'] = title_attr.strip()

                # Price - from span with price class
                price_elems = item.find_elements(By.CSS_SELECTOR, 'span[class*="price"], .s-item__price')
                if price_elems:
                    price_text = price_elems[0].text.strip()
                    if price_text:
                        product['price'] = price_text
                        # Extract numeric value
                        price_match = re.search(r'([\d.,]+)', price_text.replace('.', '').replace(',', '.'))
                        if price_match:
                            try:
                                # Handle EUR format
                                price_str = price_match.group(1)
                                product['price_value'] = float(price_str)
                            except:
                                pass

                # Condition - from secondary info
                cond_elems = item.find_elements(By.CSS_SELECTOR, '.SECONDARY_INFO, .s-item__subtitle')
                if cond_elems:
                    cond_text = cond_elems[0].text.strip()
                    if cond_text:
                        product['condition'] = cond_text

                # Listing ID from data-listingid
                listing_id = item.get_attribute('data-listingid')
                if listing_id:
                    product['listing_id'] = listing_id

                # Metadata
                product['platform'] = 'ebay_de'
                product['country'] = 'DE'
                product['scraped_at'] = datetime.now().isoformat()

                # Validate: must have URL and title, and not be a placeholder
                if product.get('url') and product.get('title'):
                    # Skip placeholder items
                    title_lower = product['title'].lower()
                    if 'shop on ebay' in title_lower or title_lower == 'shop on ebay':
                        continue

                    # Skip auctions (double-check even if LH_BIN=1 filter is used)
                    item_text = item.text.lower() if item.text else ''
                    auction_indicators = ['gebot', 'gebote', 'bieten', 'auktion', 'bid', 'bids', 'auction']
                    is_auction = any(ind in item_text for ind in auction_indicators)
                    if is_auction:
                        continue  # Skip auction items

                    # Mark as Buy It Now
                    product['listing_type'] = 'buy_it_now'

                    products.append(product)

            except Exception as e:
                continue

        print(f"    [EXTRACT] Extracted {len(products)} valid products from {total_items} items", flush=True)
        return products

    def _go_to_next_page(self, current_page: int) -> bool:
        """Navigate to next page"""
        try:
            # Method 1: Click pagination button
            next_buttons = self.driver.find_elements(By.CSS_SELECTOR,
                "a.pagination__next, a[rel='next'], .pagination__item--next a, a[aria-label*='Nächste']"
            )

            for btn in next_buttons:
                if btn.is_displayed() and btn.is_enabled():
                    href = btn.get_attribute('href')
                    if href:
                        self._robotic_scroll(2)
                        btn.click()
                        print(f"    [->] Clicked next page button")
                        return True

            # Method 2: URL pagination - eBay uses _pgn parameter
            current_url = self.driver.current_url
            if '_pgn=' in current_url:
                new_url = re.sub(r'_pgn=\d+', f'_pgn={current_page + 1}', current_url)
            else:
                separator = '&' if '?' in current_url else '?'
                new_url = f"{current_url}{separator}_pgn={current_page + 1}"

            self.driver.get(new_url)
            print(f"    [->] Navigated to page {current_page + 1} via URL")
            return True

        except Exception as e:
            print(f"    [ERROR] Pagination failed: {e}")
            return False

    def scrape_ebay(self, query: str,
                    max_pages: int = 20,
                    condition: str = None,
                    buy_it_now_only: bool = True) -> List[Dict]:
        """
        Scrape eBay DE with pagination

        Args:
            query: Search term
            max_pages: Maximum number of pages to scrape
            condition: Filter by condition (new, used, etc.)
            buy_it_now_only: Only include "Buy It Now" listings (no auctions) - DEFAULT TRUE
        """
        if not self.driver:
            self._init_driver()

        all_results = []
        seen_urls = set()

        print(f"\n{'='*60}")
        print(f"[SHOP] EBAY DE - Searching: '{query}'")
        print(f"   Max pages: {max_pages}")
        if condition:
            print(f"   Condition filter: {condition}")
        if buy_it_now_only:
            print(f"   [FILTER] Sofort-Kaufen only (no auctions)")
        print(f"{'='*60}")

        # Build search URL
        search_url = f"{self.BASE_URL}/sch/i.html?_nkw={quote_plus(query)}&_sacat=0"

        # Add "Buy It Now" filter (SOFORT-KAUFEN) - filters out auctions
        if buy_it_now_only:
            search_url += "&LH_BIN=1"

        # Add condition filter
        if condition:
            condition_map = {
                'new': '&LH_ItemCondition=1000',
                'used': '&LH_ItemCondition=3000',
                'refurbished': '&LH_ItemCondition=2500',
            }
            search_url += condition_map.get(condition.lower(), '')

        print(f"   URL: {search_url}")

        # Navigate to search
        self.driver.get(search_url)
        self._random_delay(2, 4)

        # Handle cookies
        self._handle_cookies()
        self._random_delay(1, 2)

        # Paginate through results
        for page in range(1, max_pages + 1):
            print(f"\n   [PAGE] Page {page}/{max_pages}")

            # Wait for page to load
            try:
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, 'li[data-viewport], .s-card'))
                )
            except:
                print(f"    [WARN] Page load timeout")

            self._random_delay(1, 3)

            # Human-like scroll
            self._human_scroll()

            # Robotic scroll for remaining content
            self._robotic_scroll(3)

            # Extract products
            products = self._extract_products_from_page()

            # Filter duplicates
            new_products = []
            for p in products:
                url = p.get('url', '')
                if url and url not in seen_urls:
                    seen_urls.add(url)
                    new_products.append(p)

            all_results.extend(new_products)
            print(f"   [OK] Got {len(new_products)} new products (Total: {len(all_results)})")

            # Check if we should continue
            if len(new_products) == 0:
                print(f"   [WARN] No new products, stopping pagination")
                break

            # Go to next page
            if page < max_pages:
                if not self._go_to_next_page(page):
                    print(f"   [WARN] No more pages available")
                    break
                self._random_delay(2, 4)

        print(f"\n{'='*60}")
        print(f"[RESULT] EBAY DE TOTAL: {len(all_results)} products")
        print(f"{'='*60}")

        return all_results

    def close(self):
        """Close the driver"""
        if self.driver:
            self.driver.quit()
            self.driver = None
            print("[CLOSE] Driver closed")


# Quick test function
def test_ebay_de():
    """Test eBay DE scraper"""
    scraper = EbayDeV2Scraper(headless=False)

    try:
        results = scraper.scrape_ebay(
            query="dyson airwrap",
            max_pages=3,
            condition=None
        )

        print(f"\n[STATS] Test Results:")
        print(f"   Total products: {len(results)}")

        # Save results
        filename = f"ebay_de_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"   Saved to: {filename}")

        if results:
            print(f"\n   Sample products:")
            for i, sample in enumerate(results[:5]):
                print(f"\n   [{i+1}] {sample.get('title', 'N/A')[:50]}")
                print(f"       Price: {sample.get('price', 'N/A')}")
                print(f"       Condition: {sample.get('condition', 'N/A')}")

        return results

    finally:
        scraper.close()


if __name__ == "__main__":
    test_ebay_de()