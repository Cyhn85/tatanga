# TATANGA - Quick Start Guide
## Get Started in 5 Minutes

**Goal:** Scrape your first product and upload it to a marketplace.

---

## Prerequisites (2 minutes)

### Required Software:
```bash
# Check if you have Python 3.8+
python --version

# Check if you have Chrome browser installed
chrome --version  # or check manually
```

### Install TATANGA:
```bash
# 1. Navigate to TATANGA directory
cd "c:\Users\cyhnsrgc\Desktop\CSS BOT"

# 2. Create virtual environment (optional but recommended)
python -m venv venv

# 3. Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# 4. Install dependencies
pip install -r requirements.txt

# 5. Install ChromeDriver
# Windows: Download from https://chromedriver.chromium.org/
# Place chromedriver.exe in PATH or project root
# Linux: sudo apt-get install chromium-chromedriver
```

---

## Option 1: GUI Mode (Recommended for Beginners)

### Step 1: Launch DIS LOGISTIK (Scraping GUI)
```bash
python dis_logistik.py
```

### Step 2: Scrape Your First Product

1. **Select Platform:** Choose "eBay Kleinanzeigen" (fully supported)
2. **Enter URL:** Paste a product URL
   ```
   Example: https://www.kleinanzeigen.de/s-anzeige/tommy-hilfiger-uhr/2345678901
   ```
3. **Click "Scrape"** → Wait 20-30 seconds
4. **Check Result:** Product appears in table below

### Step 3: Launch IC LOGISTIK (Upload GUI)
```bash
# Open new terminal
python ic_logistik.py
```

### Step 4: Configure Your First Store

1. **Click "Add Account"**
2. **Select Platform:** Choose "eBay" (easiest to set up)
3. **Enter Credentials:**
   - Store Name: `My eBay Store`
   - App ID: Your eBay App ID (see Setup section below)
   - Cert ID: Your eBay Cert ID
   - Dev ID: Your eBay Dev ID
   - User Token: (optional for testing)
4. **Click "Save"**

### Step 5: Upload Product

1. **Select Product:** Check the product you scraped
2. **Select Store:** Check "My eBay Store"
3. **Click "Upload Selected"** → Wait 10-20 seconds
4. **Check Result:** Status shows "Success" or "Failed"

**Done!** 🎉 You've scraped and uploaded your first product.

---

## Option 2: Command-Line Mode (For Advanced Users)

### Quick Test Script:

Create a file `quick_test.py`:

```python
#!/usr/bin/env python3
"""Quick test of TATANGA core functionality"""

import sys
from pathlib import Path

# Add active_pieces to path
sys.path.insert(0, str(Path(__file__).parent / 'active_pieces'))

# Step 1: Import connectors
from integrations.kleinanzeigen_connector import KleinanzeigenConnector

print("=== TATANGA Quick Test ===\n")

# Step 2: Initialize connector
print("1. Initializing Kleinanzeigen connector...")
connector = KleinanzeigenConnector()
print("   ✓ Connector ready\n")

# Step 3: Scrape a product
print("2. Scraping product...")
url = "https://www.kleinanzeigen.de/s-anzeige/tommy-hilfiger-uhr/2345678901"  # Replace with real URL
result = connector.scrape_product(url)

if result.get('success'):
    print("   ✓ Scraping successful!")
    print(f"   Title: {result['title']}")
    print(f"   Price: {result['price']}")
    print(f"   Platform: {result['platform']}")
else:
    print(f"   ✗ Scraping failed: {result.get('error')}")

# Step 4: Check stats
print("\n3. Connector stats:")
stats = connector.get_stats()
for key, value in stats.items():
    print(f"   {key}: {value}")

print("\n=== Test Complete ===")
```

**Run it:**
```bash
python quick_test.py
```

---

## eBay API Setup (Required for Uploads)

### Get eBay Developer Credentials (5 minutes):

1. **Go to:** https://developer.ebay.com/
2. **Sign up** for developer account (free)
3. **Create app:**
   - Name: "TATANGA CSS Berlin"
   - Environment: Start with "Sandbox" for testing
4. **Get credentials:**
   - App ID (Client ID)
   - Cert ID (Client Secret)
   - Dev ID (Device ID)
5. **Copy to:** `active_pieces/config/credentials.py`

```python
# credentials.py
API_KEYS = {
    'ebay_app_id': 'YOUR_APP_ID_HERE',
    'ebay_cert_id': 'YOUR_CERT_ID_HERE',
    'ebay_dev_id': 'YOUR_DEV_ID_HERE',
}
```

### Get User Token (OAuth):

**Option A: Use eBay's OAuth tool (easiest)**
1. Go to: https://developer.ebay.com/my/auth/
2. Click "Get a User Token"
3. Sign in with your selling account
4. Copy token → Use in IC LOGISTIK GUI

**Option B: Programmatic OAuth (advanced)**
```python
from integrations.ebay_connector import eBayConnector

# Initialize connector
ebay = eBayConnector(
    app_id='YOUR_APP_ID',
    cert_id='YOUR_CERT_ID',
    dev_id='YOUR_DEV_ID',
    sandbox=True  # Use sandbox for testing
)

# Get authorization URL
auth_url = ebay.get_authorization_url('https://your-callback-url.com')
print(f"Visit this URL to authorize: {auth_url}")

# After user visits URL and authorizes, eBay redirects with code
# Exchange code for token
tokens = ebay.get_user_token(authorization_code='CODE_FROM_REDIRECT',
                              redirect_uri='https://your-callback-url.com')

print(f"Access Token: {tokens['access_token']}")
print(f"Refresh Token: {tokens['refresh_token']}")
```

---

## Supported Platforms (Current Status)

| Platform | Scraping | Uploading | Setup Difficulty |
|----------|----------|-----------|------------------|
| eBay Kleinanzeigen | ✅ Full | ✅ Full | ⭐ Easy |
| eBay (all countries) | ❌ No | ✅ Full | ⭐⭐ Medium (OAuth) |
| Tradera (Sweden) | ✅ Full | ✅ Full | ⭐⭐ Medium (API key) |
| Willhaben (Austria) | ⚠️ Beta | ⚠️ Beta | ⭐ Easy |
| Vinted | ❌ Coming Soon | ❌ Coming Soon | - |
| 19 others | ❌ Not Yet | ❌ Not Yet | - |

**Recommendation:** Start with Kleinanzeigen (scraping) and eBay (uploading).

---

## Common Issues & Solutions

### Issue 1: "ChromeDriver not found"

**Error:**
```
selenium.common.exceptions.WebDriverException: 'chromedriver' executable needs to be in PATH
```

**Solution:**
```bash
# Windows:
1. Download ChromeDriver: https://chromedriver.chromium.org/downloads
2. Match your Chrome version (check chrome://version/)
3. Place chromedriver.exe in project root OR C:\Windows\System32

# Linux:
sudo apt-get install chromium-chromedriver

# Mac:
brew install chromedriver
```

### Issue 2: "Module not found: groq"

**Error:**
```
ModuleNotFoundError: No module named 'groq'
```

**Solution:**
```bash
pip install groq
# or
pip install -r requirements.txt
```

### Issue 3: "Database locked"

**Error:**
```
sqlite3.OperationalError: database is locked
```

**Solution:**
```bash
# Close all TATANGA applications (DIS + IC GUIs)
# If still locked, restart Python

# Or delete and recreate database:
rm tatanga.db
python dis_logistik.py  # Will recreate automatically
```

### Issue 4: "eBay OAuth token expired"

**Error:**
```
{'success': False, 'error': 'Token expired'}
```

**Solution:**
```python
# Tokens expire after 2 hours (access token)
# Use refresh token to get new access token:

from integrations.ebay_connector import eBayConnector

ebay = eBayConnector(
    app_id='YOUR_APP_ID',
    cert_id='YOUR_CERT_ID',
    dev_id='YOUR_DEV_ID',
    refresh_token='YOUR_REFRESH_TOKEN'
)

# This will automatically get new access token:
ebay.refresh_access_token()
```

### Issue 5: "Duplicate product detected"

**Message:**
```
Product already scraped from this URL (48 hours ago)
```

**Solution:**
```python
# This is intentional (duplicate prevention)
# To force re-scrape, use force=True:

connector = KleinanzeigenConnector()
result = connector.scrape_product(url, force=True)
```

---

## Next Steps

Once you've successfully scraped and uploaded your first product:

### 1. Read Full Documentation
- **TATANGA_KULLANIM_KILAVUZU.md** - Comprehensive Turkish user manual (15,000 words)
- **TECHNICAL_DOCUMENTATION.md** - Developer reference (10,000 words)
- **DEPLOYMENT_GUIDE.md** - Production server setup (8,000 words)
- **GAP_ANALYSIS_REPORT.md** - System status and roadmap (10,000 words)

### 2. Configure More Platforms
- Set up Tradera account (Sweden market)
- Configure Willhaben (Austria market)
- Add eBay UK, FR, US accounts (multi-country)

### 3. Automate Workflows
```python
# Example: Automated daily scraping + upload

from integrations.kleinanzeigen_connector import KleinanzeigenConnector
from integrations.ebay_multicountry_connector import create_ebay_uk_connector

# List of URLs to scrape
urls = [
    "https://www.kleinanzeigen.de/...",
    "https://www.kleinanzeigen.de/...",
]

# Scrape all
kleinanzeigen = KleinanzeigenConnector()
for url in urls:
    result = kleinanzeigen.scrape_product(url)
    if result['success']:
        print(f"✓ Scraped: {result['title']}")

# Upload to eBay UK
ebay_uk = create_ebay_uk_connector({
    'app_id': 'YOUR_APP_ID',
    'cert_id': 'YOUR_CERT_ID',
    'dev_id': 'YOUR_DEV_ID',
    'user_token': 'YOUR_TOKEN'
})

# Get products from database and upload
products = kleinanzeigen.get_recent_products(limit=10)
for product in products:
    result = ebay_uk.upload_product(product, account_data)
    if result['success']:
        print(f"✓ Uploaded: {product['title']} → {result['url']}")
```

### 4. Set Up Telegram Notifications
```python
# Edit active_pieces/integrations/telegram_bot.py

TELEGRAM_CONFIG = {
    'bot_token': 'YOUR_BOT_TOKEN_FROM_BOTFATHER',
    'channels': {
        'germany': '@your_channel',
        'general': '@your_main_channel'
    }
}

# Send test message
from integrations.telegram_bot import send_product_alert

send_product_alert(
    product={'title': 'Test Product', 'price': '99.99', 'url': 'https://...'},
    channel='general'
)
```

### 5. Deploy to Server (Optional)
```bash
# Follow DEPLOYMENT_GUIDE.md for Hetzner server setup
# Server IP: 195.201.146.224

# Quick deployment:
ssh root@195.201.146.224
cd /opt
git clone YOUR_TATANGA_REPO
cd tatanga
./scripts/deploy.sh

# Enable services:
systemctl enable tatanga-webhook
systemctl start tatanga-webhook
```

---

## Performance Tips

### 1. Speed Up Scraping
```python
# Reuse browser instance instead of creating new one each time
connector = KleinanzeigenConnector()
connector.init_browser()  # Start browser once

for url in urls:
    result = connector.scrape_product(url)  # Reuses browser
    print(result['title'])

connector.close_browser()  # Close when done
```

### 2. Batch Uploads
```python
# Upload multiple products in parallel
from concurrent.futures import ThreadPoolExecutor

def upload_one(product):
    return ebay.upload_product(product, account_data)

with ThreadPoolExecutor(max_workers=3) as executor:
    results = executor.map(upload_one, products)

for result in results:
    print(result)
```

### 3. Cache Translations
```python
# Translation cache is automatic
# First translation: 2-3 seconds
# Cached translation: <10ms (375x faster)

from integrations.smart_translator import SmartTranslator

translator = SmartTranslator()

# First call - hits API
text_en = translator.translate("Schönes Kleid", target_lang='en')  # 2 sec

# Second call - from cache
text_en = translator.translate("Schönes Kleid", target_lang='en')  # <10ms
```

---

## Learning Resources

### Sample Code Snippets

**Example 1: Scrape and print product details**
```python
from integrations.kleinanzeigen_connector import KleinanzeigenConnector

connector = KleinanzeigenConnector()
result = connector.scrape_product("https://www.kleinanzeigen.de/s-anzeige/...")

if result['success']:
    print(f"""
    Product Details:
    ----------------
    Title: {result['title']}
    Price: {result['price']}
    Description: {result['description'][:100]}...
    Images: {len(result['images'])} photos
    Platform: {result['platform']}
    """)
```

**Example 2: Search database for products**
```python
import sqlite3

conn = sqlite3.connect('tatanga.db')
cursor = conn.cursor()

# Search by keyword
cursor.execute("""
    SELECT title, price, source_url
    FROM products
    WHERE title LIKE ?
    ORDER BY created_at DESC
    LIMIT 10
""", ('%Tommy Hilfiger%',))

for title, price, url in cursor.fetchall():
    print(f"{title} - {price} - {url}")
```

**Example 3: Check for duplicates**
```python
from integrations.universal_connector import UniversalPlatformConnector

connector = KleinanzeigenConnector()

# This automatically checks duplicates:
result = connector.scrape_product(url)

if not result['success'] and 'duplicate' in result.get('error', '').lower():
    print("This product was already scraped!")
    print(f"Original scrape: {result.get('original_scrape_date')}")
```

**Example 4: Translate product to multiple languages**
```python
from integrations.smart_translator import SmartTranslator

translator = SmartTranslator()

product_title = "Tommy Hilfiger Herrenuhr - Neuwertig"

languages = ['en', 'fr', 'es', 'it']
for lang in languages:
    translated = translator.translate(product_title, target_lang=lang)
    print(f"{lang.upper()}: {translated}")

# Output:
# EN: Tommy Hilfiger Men's Watch - Like New
# FR: Montre Tommy Hilfiger pour Homme - Comme Neuf
# ES: Reloj Tommy Hilfiger para Hombre - Como Nuevo
# IT: Orologio Tommy Hilfiger da Uomo - Come Nuovo
```

---

## Testing Your Setup

### Run System Check:
```bash
python -c "
import sys
print('Python version:', sys.version)

try:
    import selenium
    print('✓ Selenium installed:', selenium.__version__)
except:
    print('✗ Selenium NOT installed')

try:
    import groq
    print('✓ Groq installed')
except:
    print('✗ Groq NOT installed')

try:
    from selenium import webdriver
    driver = webdriver.Chrome()
    print('✓ ChromeDriver working')
    driver.quit()
except Exception as e:
    print('✗ ChromeDriver issue:', e)
"
```

Expected output:
```
Python version: 3.10.x
✓ Selenium installed: 4.x.x
✓ Groq installed
✓ ChromeDriver working
```

---

## Help & Support

### Option 1: Read Documentation
- Start with this guide (you're here!)
- Read TATANGA_KULLANIM_KILAVUZU.md for detailed Turkish instructions
- Check TECHNICAL_DOCUMENTATION.md for API reference

### Option 2: Check Logs
```bash
# GUIs create log files:
cat dis_logistik.log
cat ic_logistik.log

# Or in Python:
import logging
logging.basicConfig(level=logging.DEBUG)
# Now all operations will print debug info
```

### Option 3: Run in Debug Mode
```python
# Add this to top of any script:
import logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Now you'll see detailed logs:
# 2025-11-26 10:30:45 - kleinanzeigen - DEBUG - Starting scrape...
# 2025-11-26 10:30:47 - kleinanzeigen - DEBUG - Found title: Tommy...
```

### Option 4: Test Individual Components
```python
# Test database connection
import sqlite3
conn = sqlite3.connect('tatanga.db')
print("✓ Database connection works")

# Test Groq API
from integrations.smart_translator import SmartTranslator
translator = SmartTranslator()
result = translator.translate("Hello", target_lang='de')
print(f"✓ Translation works: {result}")

# Test eBay API
from integrations.ebay_connector import eBayConnector
ebay = eBayConnector(app_id='...', cert_id='...', dev_id='...', sandbox=True)
print("✓ eBay connector initialized")
```

---

## Summary: Fastest Path to First Success

**Total Time: ~5 minutes**

1. **Install (2 min):**
   ```bash
   cd "CSS BOT"
   pip install -r requirements.txt
   ```

2. **Launch GUI (30 sec):**
   ```bash
   python dis_logistik.py
   ```

3. **Scrape Product (1 min):**
   - Select "eBay Kleinanzeigen"
   - Paste URL: `https://www.kleinanzeigen.de/s-anzeige/...`
   - Click "Scrape"

4. **Verify (30 sec):**
   - Check product appears in table
   - Note title, price, images

**Done!** You've successfully used TATANGA.

**Next:** Set up eBay account → Launch IC LOGISTIK → Upload your product.

---

## Quick Reference Card

### Essential Commands:
```bash
# Start scraping GUI
python dis_logistik.py

# Start upload GUI
python ic_logistik.py

# Run test script
python quick_test.py

# Check system status
python -c "from integrations.kleinanzeigen_connector import KleinanzeigenConnector; print('✓ System OK')"
```

### Essential Files:
```
CSS BOT/
├── dis_logistik.py              # Scraping GUI
├── ic_logistik.py               # Upload GUI
├── tatanga.db                   # Main database
├── requirements.txt             # Python dependencies
├── active_pieces/
│   ├── config/credentials.py    # API keys
│   └── integrations/            # Platform connectors
└── QUICK_START_GUIDE.md         # This file!
```

### Essential Database Tables:
```sql
products             -- All scraped products
store_accounts       -- Your platform accounts
product_transfers    -- Upload history
translation_cache    -- Cached translations
kleinanzeigen_selectors  -- Adaptive learning data
```

---

**You're ready to use TATANGA!** 🚀

For detailed documentation, see:
- 📘 **TATANGA_KULLANIM_KILAVUZU.md** - Complete user manual (Turkish)
- 📗 **TECHNICAL_DOCUMENTATION.md** - Developer reference (English)
- 📙 **DEPLOYMENT_GUIDE.md** - Server setup (English)
- 📕 **GAP_ANALYSIS_REPORT.md** - System status (English)
