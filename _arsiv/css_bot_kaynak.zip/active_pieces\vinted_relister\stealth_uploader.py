# Vinted Stealth Uploader - Uses undetected-chromedriver
# Avoids bot detection by patching Chrome automation flags

import os
import sys
import time
import random

sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from utils.database import db
from config import STATUS_VALIDATED, STATUS_UPLOADED

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
os.makedirs(DATA_DIR, exist_ok=True)


def human_type(element, text):
    """Type like a human"""
    for char in text:
        element.send_keys(char)
        time.sleep(random.uniform(0.05, 0.15))
    time.sleep(0.5)


def random_delay(min_s=1, max_s=3):
    time.sleep(random.uniform(min_s, max_s))


def wait_for_user(msg="ENTER'a basin..."):
    input(f"\n>>> {msg}")


def upload_product(driver, product):
    """Upload single product"""
    title = product.get('processed_title', product.get('raw_title', ''))
    desc = product.get('processed_description', product.get('raw_description', ''))
    price = product.get('price', 0)
    images_path = product.get('processed_images_path', product.get('raw_images_path', ''))

    print(f"\n{'='*50}")
    print(f"  {title[:45]}...")
    print(f"  Fiyat: {price} EUR")
    print(f"{'='*50}")

    # Go to upload page
    print("\n[1] Upload sayfasi...")
    driver.get('https://www.vinted.de/items/new')
    time.sleep(3)

    # Upload images
    print("[2] Resimler...")
    if images_path and os.path.exists(images_path):
        images = [os.path.join(images_path, f) for f in os.listdir(images_path)
                  if f.lower().endswith(('.jpg', '.jpeg', '.png'))][:5]
        if images:
            try:
                file_input = driver.find_element(By.CSS_SELECTOR, 'input[type="file"]')
                file_input.send_keys('\n'.join(images))
                print(f"    {len(images)} resim yukleniyor...")
                time.sleep(5)
            except Exception as e:
                print(f"    [WARN] Resim yuklenemedi: {e}")

    random_delay(1, 2)

    # Fill title
    print("[3] Baslik...")
    try:
        title_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR,
                '[data-testid="title-input"], input[name="title"], #title'))
        )
        title_input.clear()
        human_type(title_input, title)
        print(f"    OK: {title[:30]}...")
    except Exception as e:
        print(f"    [WARN] {e}")

    time.sleep(2)  # Category suggestion
    random_delay(1, 2)

    # Fill description
    print("[4] Aciklama...")
    try:
        desc_input = driver.find_element(By.CSS_SELECTOR,
            '[data-testid="description-textarea"], textarea[name="description"], #description')
        desc_input.clear()
        desc_input.send_keys(desc)  # Paste for speed
        print(f"    OK ({len(desc)} karakter)")
    except Exception as e:
        print(f"    [WARN] {e}")

    random_delay(1, 2)

    # Fill price
    print("[5] Fiyat...")
    try:
        price_input = driver.find_element(By.CSS_SELECTOR,
            '[data-testid="price-input"], input[name="price"], #price')
        price_input.clear()
        price_input.send_keys(str(int(price)))
        print(f"    OK: {price} EUR")
    except Exception as e:
        print(f"    [WARN] {e}")

    # Screenshot
    ss = os.path.join(DATA_DIR, f'stealth_{product["id"]}.png')
    driver.save_screenshot(ss)
    print(f"\n    Screenshot: {ss}")

    # User check
    print("\n" + "="*50)
    print("  FORMU KONTROL ET!")
    print("  Kategori, beden vs. sec")
    print("="*50)

    confirm = input("\nYayinla? (y/n): ").strip().lower()
    if confirm != 'y':
        print("[SKIP]")
        return False

    # Publish
    print("[6] Yayinlaniyor...")
    try:
        publish_btn = driver.find_element(By.XPATH,
            "//button[contains(text(),'Hochladen') or contains(text(),'hochladen')]")
        publish_btn.click()
        time.sleep(5)
        print("[OK] Yayinla tiklandi!")
    except Exception as e:
        print(f"    [WARN] Buton bulunamadi: {e}")
        # Try submit
        try:
            driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]').click()
        except:
            pass

    return True


def main():
    print("=" * 60)
    print("  VINTED STEALTH UPLOADER")
    print("  undetected-chromedriver ile bot algılama atlatılır")
    print("=" * 60)

    products = db.get_products_by_status(STATUS_VALIDATED)
    print(f"\n{len(products)} urun hazir")

    if not products:
        print("Yuklenecek urun yok!")
        return

    print("\n[*] Chrome aciliyor (stealth mode)...")

    # Chrome options
    options = uc.ChromeOptions()
    options.add_argument('--lang=de-DE')
    options.add_argument('--start-maximized')

    # Use undetected Chrome
    driver = uc.Chrome(options=options, use_subprocess=True)

    try:
        # Go to Vinted
        print("[*] Vinted.de...")
        driver.get('https://www.vinted.de/')
        time.sleep(3)

        # Check login
        try:
            driver.find_element(By.XPATH, "//*[contains(text(),'Einloggen')]")
            print("\n[!] LOGIN GEREKLI!")
            print("    Tarayicida manuel giris yap:")
            print("    Email: cssberlin@hotmail.com")
            print("    Sifre: Css200231")
            wait_for_user("Login sonrasi ENTER...")
        except:
            print("[OK] Zaten giris yapilmis!")

        # Upload products
        uploaded = 0
        for i, p in enumerate(products):
            print(f"\n### URUN {i+1}/{len(products)} ###")

            try:
                if upload_product(driver, p):
                    db.update_product(p['id'], {'status': STATUS_UPLOADED, 'target_store': 'cssberlin'})
                    db.add_log(p['id'], 'upload', 'success', 'Stealth uploader')
                    uploaded += 1

                if i < len(products) - 1:
                    wait_for_user("Sonraki urun icin ENTER...")

            except Exception as e:
                print(f"[ERROR] {e}")
                if input("Devam? (y/n): ").lower() != 'y':
                    break

        print(f"\n{'='*60}")
        print(f"  BITTI: {uploaded}/{len(products)}")
        print(f"{'='*60}")

    finally:
        wait_for_user("Tarayiciyi kapatmak icin ENTER...")
        driver.quit()


if __name__ == '__main__':
    main()
