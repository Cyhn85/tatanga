"""
CSS Berlin Backend API
FastAPI backend for cssberlin.de e-commerce platform
With Email Verification System
"""

from __future__ import annotations

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timedelta
from typing import Optional
from pydantic import BaseModel, EmailStr
import os
import logging

from database import get_db, engine, Base
from models import User, Product, Offer, Message, Order, Shipment
from schemas import (
    UserCreate, UserResponse, UserLogin, Token,
    ProductCreate, ProductResponse, ProductUpdate,
    OfferCreate, OfferResponse, OfferUpdate,
    MessageCreate, MessageResponse,
    ShipmentCreate, ShipmentResponse, ShipmentUpdate
)
from auth import (
    get_password_hash, verify_password,
    create_access_token, get_current_user,
    ACCESS_TOKEN_EXPIRE_MINUTES
)
from email_service import (
    generate_verification_code,
    send_verification_email,
    send_password_reset_email,
    send_welcome_email
)

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="CSS Berlin API",
    description="Backend API for CSS Berlin - Second-hand Fashion Marketplace",
    version="2.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:8080",
        "http://127.0.0.1:5500",
        "https://cssberlin.de",
        "https://www.cssberlin.de",
        "https://css-berlin.pages.dev",
        "https://cssberlin-website.pages.dev"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Additional Pydantic models for email verification
class VerifyEmailRequest(BaseModel):
    email: EmailStr
    code: str


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    email: EmailStr
    code: str
    new_password: str


class ResendVerificationRequest(BaseModel):
    email: EmailStr


# Create database tables on startup
@app.on_event("startup")
async def startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables created successfully")


# Health check
@app.get("/")
async def root():
    return {
        "status": "online",
        "service": "CSS Berlin API",
        "version": "2.0.0",
        "timestamp": datetime.utcnow().isoformat()
    }


@app.get("/health")
async def health_check():
    return {"status": "healthy", "database": "connected"}


# ============== AUTH ENDPOINTS ==============

@app.post("/api/auth/register", response_model=UserResponse)
async def register(user_data: UserCreate, db: AsyncSession = Depends(get_db)):
    """Register a new user and send verification email"""
    from sqlalchemy import select

    # Check if email exists
    result = await db.execute(select(User).where(User.email == user_data.email))
    existing_user = result.scalar_one_or_none()

    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Diese E-Mail-Adresse ist bereits registriert"
        )

    # Generate verification code
    verification_code = generate_verification_code()
    verification_expires = datetime.utcnow() + timedelta(hours=24)

    # Create user
    hashed_password = get_password_hash(user_data.password)
    db_user = User(
        email=user_data.email,
        hashed_password=hashed_password,
        first_name=user_data.first_name,
        last_name=user_data.last_name,
        is_verified=False,
        verification_code=verification_code,
        verification_code_expires=verification_expires
    )

    db.add(db_user)
    await db.commit()
    await db.refresh(db_user)

    # Send verification email (async, don't block on failure)
    try:
        await send_verification_email(
            to_email=db_user.email,
            first_name=db_user.first_name,
            verification_code=verification_code
        )
        logger.info(f"Verification email sent to {db_user.email}")
    except Exception as e:
        logger.error(f"Failed to send verification email: {e}")
        # Don't fail registration if email fails

    return db_user


@app.post("/api/auth/verify-email")
async def verify_email(request: VerifyEmailRequest, db: AsyncSession = Depends(get_db)):
    """Verify user email with code"""
    from sqlalchemy import select

    # Find user
    result = await db.execute(select(User).where(User.email == request.email))
    user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Benutzer nicht gefunden"
        )

    if user.is_verified:
        return {"success": True, "message": "E-Mail bereits bestätigt"}

    # Check code
    if user.verification_code != request.code:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Ungültiger Bestätigungscode"
        )

    # Check expiration
    if user.verification_code_expires and user.verification_code_expires < datetime.utcnow():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Bestätigungscode abgelaufen. Bitte fordern Sie einen neuen an."
        )

    # Verify user
    user.is_verified = True
    user.verification_code = None
    user.verification_code_expires = None

    await db.commit()

    # Send welcome email
    try:
        await send_welcome_email(user.email, user.first_name)
    except Exception as e:
        logger.error(f"Failed to send welcome email: {e}")

    return {
        "success": True,
        "message": "E-Mail erfolgreich bestätigt! Sie können sich jetzt anmelden."
    }


@app.post("/api/auth/resend-verification")
async def resend_verification(request: ResendVerificationRequest, db: AsyncSession = Depends(get_db)):
    """Resend verification email"""
    from sqlalchemy import select

    result = await db.execute(select(User).where(User.email == request.email))
    user = result.scalar_one_or_none()

    if not user:
        # Don't reveal if email exists
        return {"success": True, "message": "Falls ein Konto existiert, wurde eine neue E-Mail gesendet."}

    if user.is_verified:
        return {"success": True, "message": "E-Mail bereits bestätigt."}

    # Generate new code
    verification_code = generate_verification_code()
    user.verification_code = verification_code
    user.verification_code_expires = datetime.utcnow() + timedelta(hours=24)

    await db.commit()

    # Send email
    try:
        await send_verification_email(user.email, user.first_name, verification_code)
        logger.info(f"Resent verification email to {user.email}")
    except Exception as e:
        logger.error(f"Failed to resend verification email: {e}")

    return {"success": True, "message": "Falls ein Konto existiert, wurde eine neue E-Mail gesendet."}


@app.post("/api/auth/forgot-password")
async def forgot_password(request: ForgotPasswordRequest, db: AsyncSession = Depends(get_db)):
    """Send password reset email"""
    from sqlalchemy import select

    result = await db.execute(select(User).where(User.email == request.email))
    user = result.scalar_one_or_none()

    # Always return success (security - don't reveal if email exists)
    if user:
        # Generate reset code
        reset_code = generate_verification_code()
        user.reset_code = reset_code
        user.reset_code_expires = datetime.utcnow() + timedelta(hours=1)

        await db.commit()

        # Send reset email
        try:
            await send_password_reset_email(user.email, user.first_name, reset_code)
            logger.info(f"Password reset email sent to {user.email}")
        except Exception as e:
            logger.error(f"Failed to send password reset email: {e}")

    return {
        "success": True,
        "message": "Falls ein Konto mit dieser E-Mail existiert, wurde ein Reset-Link gesendet."
    }


@app.post("/api/auth/reset-password")
async def reset_password(request: ResetPasswordRequest, db: AsyncSession = Depends(get_db)):
    """Reset password with code"""
    from sqlalchemy import select

    result = await db.execute(select(User).where(User.email == request.email))
    user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Benutzer nicht gefunden"
        )

    # Check code
    if user.reset_code != request.code:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Ungültiger Reset-Code"
        )

    # Check expiration
    if user.reset_code_expires and user.reset_code_expires < datetime.utcnow():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Reset-Code abgelaufen. Bitte fordern Sie einen neuen an."
        )

    # Update password
    user.hashed_password = get_password_hash(request.new_password)
    user.reset_code = None
    user.reset_code_expires = None

    await db.commit()

    return {
        "success": True,
        "message": "Passwort erfolgreich geändert. Sie können sich jetzt anmelden."
    }


@app.post("/api/auth/login", response_model=Token)
async def login(form_data: UserLogin, db: AsyncSession = Depends(get_db)):
    """Login and get access token"""
    from sqlalchemy import select

    # Find user
    result = await db.execute(select(User).where(User.email == form_data.email))
    user = result.scalar_one_or_none()

    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="E-Mail oder Passwort ist falsch",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # Check if verified
    if not user.is_verified:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bitte bestätigen Sie zuerst Ihre E-Mail-Adresse"
        )

    # Create access token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email, "user_id": user.id},
        expires_delta=access_token_expires
    )

    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "email": user.email,
            "first_name": user.first_name,
            "last_name": user.last_name
        }
    }


@app.get("/api/auth/me", response_model=UserResponse)
async def get_current_user_info(current_user: User = Depends(get_current_user)):
    """Get current user info"""
    return current_user


# Google OAuth Request Model
class GoogleAuthRequest(BaseModel):
    credential: str


# Google OAuth Client ID - Replace with your actual Client ID
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "123456789-abcdefghijklmnop.apps.googleusercontent.com")


@app.post("/api/auth/google")
async def google_auth(request: GoogleAuthRequest, db: AsyncSession = Depends(get_db)):
    """
    Google OAuth authentication
    Verifies Google ID token and creates/logs in user
    """
    from google.oauth2 import id_token
    from google.auth.transport import requests as google_requests
    from sqlalchemy import select
    import secrets

    try:
        # Verify the Google ID token
        idinfo = id_token.verify_oauth2_token(
            request.credential,
            google_requests.Request(),
            GOOGLE_CLIENT_ID
        )

        # Token is valid, get user info
        google_email = idinfo.get('email')
        google_first_name = idinfo.get('given_name', '')
        google_last_name = idinfo.get('family_name', '')
        email_verified = idinfo.get('email_verified', False)

        if not google_email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Keine E-Mail-Adresse von Google erhalten"
            )

        # Check if user already exists
        result = await db.execute(select(User).where(User.email == google_email))
        user = result.scalar_one_or_none()

        if user:
            # User exists, log them in
            # Update verification status if needed
            if email_verified and not user.is_verified:
                user.is_verified = True
                await db.commit()
        else:
            # Create new user with Google info
            # Generate a random password since they'll use Google to login
            random_password = secrets.token_urlsafe(32)

            user = User(
                email=google_email,
                hashed_password=get_password_hash(random_password),
                first_name=google_first_name or "Google",
                last_name=google_last_name or "User",
                is_active=True,
                is_verified=email_verified  # Trust Google's verification
            )
            db.add(user)
            await db.commit()
            await db.refresh(user)

            # Send welcome email for new users
            try:
                await send_welcome_email(google_email, google_first_name or "Nutzer")
            except Exception as e:
                logger.warning(f"Failed to send welcome email: {e}")

        # Generate our JWT token
        access_token = create_access_token(
            data={"sub": user.email},
            expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        )

        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": user.id,
                "email": user.email,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "is_verified": user.is_verified
            }
        }

    except ValueError as e:
        # Invalid token
        logger.error(f"Google token verification failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Ungültiges Google-Token"
        )
    except Exception as e:
        logger.error(f"Google auth error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Google-Authentifizierung fehlgeschlagen"
        )


# ============== PRODUCT ENDPOINTS ==============

@app.get("/api/products")
async def get_products(
    skip: int = 0,
    limit: int = 20,
    category: Optional[str] = None,
    brand: Optional[str] = None,
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Get all products with optional filters"""
    from sqlalchemy import select, or_

    query = select(Product).where(Product.is_active == True)

    if category:
        query = query.where(Product.category == category)
    if brand:
        query = query.where(Product.brand.ilike(f"%{brand}%"))
    if search:
        query = query.where(
            or_(
                Product.name.ilike(f"%{search}%"),
                Product.description.ilike(f"%{search}%"),
                Product.brand.ilike(f"%{search}%")
            )
        )

    query = query.order_by(Product.created_at.desc()).offset(skip).limit(limit)
    result = await db.execute(query)
    products = result.scalars().all()

    return {"products": products, "total": len(products)}


@app.get("/api/products/{product_id}", response_model=ProductResponse)
async def get_product(product_id: int, db: AsyncSession = Depends(get_db)):
    """Get single product by ID"""
    from sqlalchemy import select

    result = await db.execute(select(Product).where(Product.id == product_id))
    product = result.scalar_one_or_none()

    if not product:
        raise HTTPException(status_code=404, detail="Produkt nicht gefunden")

    return product


@app.post("/api/products", response_model=ProductResponse)
async def create_product(
    product_data: ProductCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create a new product listing"""
    db_product = Product(
        **product_data.dict(),
        seller_id=current_user.id
    )

    db.add(db_product)
    await db.commit()
    await db.refresh(db_product)

    return db_product


@app.put("/api/products/{product_id}", response_model=ProductResponse)
async def update_product(
    product_id: int,
    product_data: ProductUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update a product"""
    from sqlalchemy import select

    result = await db.execute(select(Product).where(Product.id == product_id))
    product = result.scalar_one_or_none()

    if not product:
        raise HTTPException(status_code=404, detail="Produkt nicht gefunden")

    if product.seller_id != current_user.id:
        raise HTTPException(status_code=403, detail="Nicht berechtigt")

    for key, value in product_data.dict(exclude_unset=True).items():
        setattr(product, key, value)

    await db.commit()
    await db.refresh(product)

    return product


@app.delete("/api/products/{product_id}")
async def delete_product(
    product_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Delete a product"""
    from sqlalchemy import select

    result = await db.execute(select(Product).where(Product.id == product_id))
    product = result.scalar_one_or_none()

    if not product:
        raise HTTPException(status_code=404, detail="Produkt nicht gefunden")

    if product.seller_id != current_user.id:
        raise HTTPException(status_code=403, detail="Nicht berechtigt")

    product.is_active = False
    await db.commit()

    return {"success": True, "message": "Produkt gelöscht"}


# ============== OFFER ENDPOINTS ==============

@app.post("/api/offers", response_model=OfferResponse)
async def create_offer(
    offer_data: OfferCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create a new price offer"""
    from sqlalchemy import select

    # Get product
    result = await db.execute(select(Product).where(Product.id == offer_data.product_id))
    product = result.scalar_one_or_none()

    if not product:
        raise HTTPException(status_code=404, detail="Produkt nicht gefunden")

    if product.seller_id == current_user.id:
        raise HTTPException(status_code=400, detail="Sie können nicht für Ihr eigenes Produkt bieten")

    # Create offer
    db_offer = Offer(
        product_id=offer_data.product_id,
        buyer_id=current_user.id,
        seller_id=product.seller_id,
        offer_amount=offer_data.offer_amount,
        message=offer_data.message,
        status="pending",
        expires_at=datetime.utcnow() + timedelta(days=2)
    )

    db.add(db_offer)
    await db.commit()
    await db.refresh(db_offer)

    return db_offer


@app.get("/api/offers")
async def get_user_offers(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get all offers for current user (as buyer or seller)"""
    from sqlalchemy import select, or_

    query = select(Offer).where(
        or_(
            Offer.buyer_id == current_user.id,
            Offer.seller_id == current_user.id
        )
    ).order_by(Offer.created_at.desc())

    result = await db.execute(query)
    offers = result.scalars().all()

    # Enrich with product data
    enriched_offers = []
    for offer in offers:
        prod_result = await db.execute(select(Product).where(Product.id == offer.product_id))
        product = prod_result.scalar_one_or_none()

        offer_dict = {
            "id": offer.id,
            "product_id": offer.product_id,
            "product_name": product.name if product else "Unknown",
            "product_price": product.price if product else 0,
            "product_image": product.images[0] if product and product.images else None,
            "buyer_id": offer.buyer_id,
            "seller_id": offer.seller_id,
            "offer_amount": offer.offer_amount,
            "counter_amount": offer.counter_amount,
            "status": offer.status,
            "message": offer.message,
            "created_at": offer.created_at.isoformat(),
            "expires_at": offer.expires_at.isoformat() if offer.expires_at else None
        }
        enriched_offers.append(offer_dict)

    return {"offers": enriched_offers}


@app.put("/api/offers/{offer_id}/accept")
async def accept_offer(
    offer_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Accept an offer"""
    from sqlalchemy import select

    result = await db.execute(select(Offer).where(Offer.id == offer_id))
    offer = result.scalar_one_or_none()

    if not offer:
        raise HTTPException(status_code=404, detail="Angebot nicht gefunden")

    # Check authorization
    if offer.seller_id != current_user.id and offer.buyer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Nicht berechtigt")

    offer.status = "accepted"
    await db.commit()
    await db.refresh(offer)

    # Get product info for response
    prod_result = await db.execute(select(Product).where(Product.id == offer.product_id))
    product = prod_result.scalar_one_or_none()

    return {
        "success": True,
        "message": "Angebot angenommen",
        "offer": {
            "id": offer.id,
            "product_id": offer.product_id,
            "product_name": product.name if product else "Unknown",
            "product_price": product.price if product else 0,
            "product_image": product.images[0] if product and product.images else None,
            "offer_amount": offer.offer_amount,
            "counter_amount": offer.counter_amount,
            "status": offer.status
        }
    }


@app.put("/api/offers/{offer_id}/counter")
async def counter_offer(
    offer_id: int,
    counter_data: dict,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Send counter offer"""
    from sqlalchemy import select

    result = await db.execute(select(Offer).where(Offer.id == offer_id))
    offer = result.scalar_one_or_none()

    if not offer:
        raise HTTPException(status_code=404, detail="Angebot nicht gefunden")

    if offer.seller_id != current_user.id:
        raise HTTPException(status_code=403, detail="Nur der Verkäufer kann Gegenangebote machen")

    offer.counter_amount = counter_data.get("counter_amount")
    offer.status = "countered"
    offer.expires_at = datetime.utcnow() + timedelta(days=2)

    await db.commit()

    return {"success": True, "message": "Gegenangebot gesendet"}


@app.put("/api/offers/{offer_id}/decline")
async def decline_offer(
    offer_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Decline an offer"""
    from sqlalchemy import select

    result = await db.execute(select(Offer).where(Offer.id == offer_id))
    offer = result.scalar_one_or_none()

    if not offer:
        raise HTTPException(status_code=404, detail="Angebot nicht gefunden")

    if offer.seller_id != current_user.id and offer.buyer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Nicht berechtigt")

    offer.status = "declined"
    await db.commit()

    return {"success": True, "message": "Angebot abgelehnt"}


# ============== MESSAGE ENDPOINTS ==============

@app.post("/api/messages", response_model=MessageResponse)
async def send_message(
    message_data: MessageCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Send a message"""
    db_message = Message(
        sender_id=current_user.id,
        receiver_id=message_data.receiver_id,
        product_id=message_data.product_id,
        content=message_data.content
    )

    db.add(db_message)
    await db.commit()
    await db.refresh(db_message)

    return db_message


@app.get("/api/messages/{user_id}")
async def get_conversation(
    user_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get messages between current user and another user"""
    from sqlalchemy import select, or_, and_

    query = select(Message).where(
        or_(
            and_(Message.sender_id == current_user.id, Message.receiver_id == user_id),
            and_(Message.sender_id == user_id, Message.receiver_id == current_user.id)
        )
    ).order_by(Message.created_at.asc())

    result = await db.execute(query)
    messages = result.scalars().all()

    return {"messages": messages}


# ============== SHIPMENT ENDPOINTS ==============

# Carrier tracking URLs
CARRIER_TRACKING_URLS = {
    "dhl": "https://www.dhl.de/de/privatkunden/pakete-empfangen/verfolgen.html?piececode=",
    "hermes": "https://www.myhermes.de/empfangen/sendungsverfolgung/?tracking=",
    "dpd": "https://tracking.dpd.de/status/de_DE/parcel/",
    "gls": "https://gls-group.eu/DE/de/paketverfolgung?match="
}


@app.post("/api/shipments", response_model=ShipmentResponse)
async def create_shipment(
    shipment_data: ShipmentCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create shipment for an order (seller only)"""
    from sqlalchemy import select

    # Get order
    result = await db.execute(select(Order).where(Order.id == shipment_data.order_id))
    order = result.scalar_one_or_none()

    if not order:
        raise HTTPException(status_code=404, detail="Bestellung nicht gefunden")

    # Get product to verify seller
    prod_result = await db.execute(select(Product).where(Product.id == order.product_id))
    product = prod_result.scalar_one_or_none()

    if not product or product.seller_id != current_user.id:
        raise HTTPException(status_code=403, detail="Nur der Verkäufer kann den Versand erstellen")

    # Check if shipment already exists
    existing = await db.execute(select(Shipment).where(Shipment.order_id == order.id))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Versand existiert bereits für diese Bestellung")

    # Create shipment
    db_shipment = Shipment(
        order_id=order.id,
        seller_id=current_user.id,
        buyer_id=order.buyer_id,
        carrier=shipment_data.carrier.lower(),
        tracking_number=shipment_data.tracking_number,
        weight_kg=shipment_data.weight_kg,
        package_size=shipment_data.package_size,
        status="pending",
        tracking_history=[{
            "status": "pending",
            "location": "Berlin",
            "timestamp": datetime.utcnow().isoformat(),
            "description": "Versandetikett erstellt"
        }]
    )

    db.add(db_shipment)

    # Update order status
    order.status = "shipped"

    await db.commit()
    await db.refresh(db_shipment)

    return db_shipment


@app.get("/api/shipments")
async def get_user_shipments(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get all shipments for current user (as buyer or seller)"""
    from sqlalchemy import select, or_

    query = select(Shipment).where(
        or_(
            Shipment.buyer_id == current_user.id,
            Shipment.seller_id == current_user.id
        )
    ).order_by(Shipment.created_at.desc())

    result = await db.execute(query)
    shipments = result.scalars().all()

    # Enrich with product and order data
    enriched_shipments = []
    for shipment in shipments:
        # Get order
        order_result = await db.execute(select(Order).where(Order.id == shipment.order_id))
        order = order_result.scalar_one_or_none()

        # Get product
        product = None
        if order:
            prod_result = await db.execute(select(Product).where(Product.id == order.product_id))
            product = prod_result.scalar_one_or_none()

        # Get buyer info
        buyer_result = await db.execute(select(User).where(User.id == shipment.buyer_id))
        buyer = buyer_result.scalar_one_or_none()

        # Get seller info
        seller_result = await db.execute(select(User).where(User.id == shipment.seller_id))
        seller = seller_result.scalar_one_or_none()

        shipment_dict = {
            "id": shipment.id,
            "order_id": shipment.order_id,
            "carrier": shipment.carrier,
            "tracking_number": shipment.tracking_number,
            "tracking_url": f"{CARRIER_TRACKING_URLS.get(shipment.carrier, '')}{shipment.tracking_number or ''}",
            "status": shipment.status,
            "shipped_at": shipment.shipped_at.isoformat() if shipment.shipped_at else None,
            "delivered_at": shipment.delivered_at.isoformat() if shipment.delivered_at else None,
            "estimated_delivery": shipment.estimated_delivery.isoformat() if shipment.estimated_delivery else None,
            "last_location": shipment.last_location,
            "tracking_history": shipment.tracking_history or [],
            "created_at": shipment.created_at.isoformat(),
            "product_name": product.name if product else "Unknown",
            "product_image": product.images[0] if product and product.images else None,
            "product_price": order.total_amount if order else 0,
            "seller_name": f"{seller.first_name} {seller.last_name}" if seller else "Unknown",
            "buyer_name": f"{buyer.first_name} {buyer.last_name}" if buyer else "Unknown",
            "is_seller": shipment.seller_id == current_user.id,
            "shipping_address": order.shipping_address if order else None
        }
        enriched_shipments.append(shipment_dict)

    return {"shipments": enriched_shipments}


@app.get("/api/shipments/{shipment_id}")
async def get_shipment(
    shipment_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get single shipment details"""
    from sqlalchemy import select

    result = await db.execute(select(Shipment).where(Shipment.id == shipment_id))
    shipment = result.scalar_one_or_none()

    if not shipment:
        raise HTTPException(status_code=404, detail="Versand nicht gefunden")

    # Check authorization
    if shipment.buyer_id != current_user.id and shipment.seller_id != current_user.id:
        raise HTTPException(status_code=403, detail="Nicht berechtigt")

    # Get order
    order_result = await db.execute(select(Order).where(Order.id == shipment.order_id))
    order = order_result.scalar_one_or_none()

    # Get product
    product = None
    if order:
        prod_result = await db.execute(select(Product).where(Product.id == order.product_id))
        product = prod_result.scalar_one_or_none()

    # Get users
    buyer_result = await db.execute(select(User).where(User.id == shipment.buyer_id))
    buyer = buyer_result.scalar_one_or_none()

    seller_result = await db.execute(select(User).where(User.id == shipment.seller_id))
    seller = seller_result.scalar_one_or_none()

    return {
        "id": shipment.id,
        "order_id": shipment.order_id,
        "carrier": shipment.carrier,
        "tracking_number": shipment.tracking_number,
        "tracking_url": f"{CARRIER_TRACKING_URLS.get(shipment.carrier, '')}{shipment.tracking_number or ''}",
        "status": shipment.status,
        "shipped_at": shipment.shipped_at.isoformat() if shipment.shipped_at else None,
        "in_transit_at": shipment.in_transit_at.isoformat() if shipment.in_transit_at else None,
        "out_for_delivery_at": shipment.out_for_delivery_at.isoformat() if shipment.out_for_delivery_at else None,
        "delivered_at": shipment.delivered_at.isoformat() if shipment.delivered_at else None,
        "estimated_delivery": shipment.estimated_delivery.isoformat() if shipment.estimated_delivery else None,
        "last_location": shipment.last_location,
        "tracking_history": shipment.tracking_history or [],
        "weight_kg": shipment.weight_kg,
        "package_size": shipment.package_size,
        "created_at": shipment.created_at.isoformat(),
        "product_name": product.name if product else "Unknown",
        "product_image": product.images[0] if product and product.images else None,
        "product_price": order.total_amount if order else 0,
        "seller_name": f"{seller.first_name} {seller.last_name}" if seller else "Unknown",
        "buyer_name": f"{buyer.first_name} {buyer.last_name}" if buyer else "Unknown",
        "is_seller": shipment.seller_id == current_user.id,
        "shipping_address": order.shipping_address if order else None
    }


@app.put("/api/shipments/{shipment_id}")
async def update_shipment(
    shipment_id: int,
    update_data: ShipmentUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update shipment (add tracking number, update status)"""
    from sqlalchemy import select

    result = await db.execute(select(Shipment).where(Shipment.id == shipment_id))
    shipment = result.scalar_one_or_none()

    if not shipment:
        raise HTTPException(status_code=404, detail="Versand nicht gefunden")

    if shipment.seller_id != current_user.id:
        raise HTTPException(status_code=403, detail="Nur der Verkäufer kann den Versand aktualisieren")

    # Update fields
    if update_data.tracking_number:
        shipment.tracking_number = update_data.tracking_number

    if update_data.status:
        old_status = shipment.status
        shipment.status = update_data.status

        # Update timestamp based on status
        now = datetime.utcnow()
        if update_data.status == "shipped" and not shipment.shipped_at:
            shipment.shipped_at = now
        elif update_data.status == "in_transit" and not shipment.in_transit_at:
            shipment.in_transit_at = now
        elif update_data.status == "out_for_delivery" and not shipment.out_for_delivery_at:
            shipment.out_for_delivery_at = now
        elif update_data.status == "delivered" and not shipment.delivered_at:
            shipment.delivered_at = now

        # Add to tracking history
        history = shipment.tracking_history or []
        history.append({
            "status": update_data.status,
            "location": update_data.last_location or shipment.last_location or "Berlin",
            "timestamp": now.isoformat(),
            "description": f"Status geändert: {old_status} -> {update_data.status}"
        })
        shipment.tracking_history = history

    if update_data.last_location:
        shipment.last_location = update_data.last_location

    if update_data.estimated_delivery:
        shipment.estimated_delivery = update_data.estimated_delivery

    await db.commit()
    await db.refresh(shipment)

    return {
        "success": True,
        "message": "Versand aktualisiert",
        "shipment": {
            "id": shipment.id,
            "status": shipment.status,
            "tracking_number": shipment.tracking_number,
            "tracking_url": f"{CARRIER_TRACKING_URLS.get(shipment.carrier, '')}{shipment.tracking_number or ''}"
        }
    }


@app.get("/api/shipments/track/{tracking_number}")
async def track_shipment_public(tracking_number: str, db: AsyncSession = Depends(get_db)):
    """Public tracking endpoint - no auth required"""
    from sqlalchemy import select

    result = await db.execute(
        select(Shipment).where(Shipment.tracking_number == tracking_number)
    )
    shipment = result.scalar_one_or_none()

    if not shipment:
        raise HTTPException(status_code=404, detail="Sendung nicht gefunden")

    # Get order for product info
    order_result = await db.execute(select(Order).where(Order.id == shipment.order_id))
    order = order_result.scalar_one_or_none()

    product = None
    if order:
        prod_result = await db.execute(select(Product).where(Product.id == order.product_id))
        product = prod_result.scalar_one_or_none()

    return {
        "tracking_number": shipment.tracking_number,
        "carrier": shipment.carrier,
        "tracking_url": f"{CARRIER_TRACKING_URLS.get(shipment.carrier, '')}{shipment.tracking_number or ''}",
        "status": shipment.status,
        "shipped_at": shipment.shipped_at.isoformat() if shipment.shipped_at else None,
        "delivered_at": shipment.delivered_at.isoformat() if shipment.delivered_at else None,
        "estimated_delivery": shipment.estimated_delivery.isoformat() if shipment.estimated_delivery else None,
        "last_location": shipment.last_location,
        "tracking_history": shipment.tracking_history or [],
        "product_name": product.name if product else "Paket"
    }


@app.get("/api/carriers")
async def get_carriers():
    """Get available carriers and their info"""
    return {
        "carriers": [
            {
                "id": "dhl",
                "name": "DHL",
                "logo": "https://www.dhl.de/static/de/images/dhl-logo.svg",
                "tracking_url_base": CARRIER_TRACKING_URLS["dhl"],
                "estimated_days": "1-3"
            },
            {
                "id": "hermes",
                "name": "Hermes",
                "logo": "https://www.myhermes.de/assets/hermes-logo.svg",
                "tracking_url_base": CARRIER_TRACKING_URLS["hermes"],
                "estimated_days": "2-4"
            },
            {
                "id": "dpd",
                "name": "DPD",
                "logo": "https://www.dpd.com/de/de/logo/",
                "tracking_url_base": CARRIER_TRACKING_URLS["dpd"],
                "estimated_days": "1-3"
            },
            {
                "id": "gls",
                "name": "GLS",
                "logo": "https://gls-group.eu/logo.svg",
                "tracking_url_base": CARRIER_TRACKING_URLS["gls"],
                "estimated_days": "1-3"
            }
        ]
    }


# ============== FAVORITES ENDPOINTS ==============

@app.post("/api/favorites/{product_id}")
async def add_to_favorites(
    product_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Add product to user's favorites"""
    from sqlalchemy import select, and_
    from models import Favorite

    # Check if product exists
    product = await db.get(Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Produkt nicht gefunden")

    # Check if already in favorites
    result = await db.execute(
        select(Favorite).where(
            and_(Favorite.user_id == current_user.id, Favorite.product_id == product_id)
        )
    )
    existing = result.scalar_one_or_none()

    if existing:
        return {"message": "Bereits in Favoriten", "favorite_id": existing.id}

    # Add to favorites
    favorite = Favorite(user_id=current_user.id, product_id=product_id)
    db.add(favorite)
    await db.commit()
    await db.refresh(favorite)

    return {"message": "Zu Favoriten hinzugefügt", "favorite_id": favorite.id}


@app.delete("/api/favorites/{product_id}")
async def remove_from_favorites(
    product_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Remove product from user's favorites"""
    from sqlalchemy import select, and_, delete
    from models import Favorite

    result = await db.execute(
        delete(Favorite).where(
            and_(Favorite.user_id == current_user.id, Favorite.product_id == product_id)
        )
    )
    await db.commit()

    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="Nicht in Favoriten gefunden")

    return {"message": "Aus Favoriten entfernt"}


@app.get("/api/favorites")
async def get_favorites(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get user's favorite products"""
    from sqlalchemy import select
    from models import Favorite

    query = select(Favorite).where(Favorite.user_id == current_user.id)
    result = await db.execute(query)
    favorites = result.scalars().all()

    # Get product details
    products = []
    for fav in favorites:
        product = await db.get(Product, fav.product_id)
        if product and product.is_active:
            products.append(product)

    return {"favorites": products}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)