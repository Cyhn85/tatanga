#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Image Format Fixer
Görsel format uyumsuzluğunu çözen utility.

Problem:
- Vinted, eBay gibi siteler WebP formatında görsel gönderiyor
- Ama URL'de .jpg uzantısı olabiliyor
- Bu Claude API'de "Image does not match the provided media type" hatasına yol açıyor

Çözüm:
- Magic bytes ile gerçek formatı tespit et
- WebP/AVIF/HEIC → JPEG dönüşümü yap
- Tüm görsellerin gerçek JPEG olmasını garanti et

Author: TATANGA Team
Version: 1.0.0
"""

import os
import io
from pathlib import Path
from typing import Optional, Tuple, Union

# PIL import
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


# Format magic bytes
FORMAT_SIGNATURES = {
    'jpeg': [b'\xff\xd8\xff'],
    'png': [b'\x89PNG\r\n\x1a\n'],
    'webp': [b'RIFF'],  # RIFF....WEBP
    'gif': [b'GIF87a', b'GIF89a'],
    'bmp': [b'BM'],
    'avif': [b'\x00\x00\x00\x1c', b'\x00\x00\x00\x18', b'\x00\x00\x00 '],  # ftyp container
    'heic': [b'\x00\x00\x00\x1c', b'\x00\x00\x00\x18'],  # ftyp heic
}


def detect_image_format(file_path: Union[str, Path]) -> str:
    """
    Dosyanın gerçek görsel formatını magic bytes ile tespit et.

    Args:
        file_path: Görsel dosya yolu

    Returns:
        Format string: 'jpeg', 'png', 'webp', 'gif', 'avif', 'heic', 'unknown'
    """
    try:
        with open(file_path, 'rb') as f:
            header = f.read(32)

        # JPEG check
        if header[:3] == b'\xff\xd8\xff':
            return 'jpeg'

        # PNG check
        if header[:8] == b'\x89PNG\r\n\x1a\n':
            return 'png'

        # WebP check (RIFF....WEBP)
        if header[:4] == b'RIFF' and header[8:12] == b'WEBP':
            return 'webp'

        # GIF check
        if header[:6] in [b'GIF87a', b'GIF89a']:
            return 'gif'

        # BMP check
        if header[:2] == b'BM':
            return 'bmp'

        # AVIF/HEIC check (ftyp container)
        if header[4:8] == b'ftyp':
            brand = header[8:12].decode('latin-1', errors='ignore').lower()
            if 'avif' in brand:
                return 'avif'
            elif 'heic' in brand or 'heix' in brand or 'mif1' in brand:
                return 'heic'
            # Generic ISO Base Media File Format
            return 'avif'  # Assume AVIF for unknown ftyp

        return 'unknown'

    except Exception as e:
        return 'unknown'


def detect_format_from_bytes(data: bytes) -> str:
    """
    Bytes verisinden görsel formatını tespit et.

    Args:
        data: Görsel bytes verisi

    Returns:
        Format string
    """
    header = data[:32] if len(data) >= 32 else data

    if header[:3] == b'\xff\xd8\xff':
        return 'jpeg'
    elif header[:8] == b'\x89PNG\r\n\x1a\n':
        return 'png'
    elif header[:4] == b'RIFF' and len(header) > 11 and header[8:12] == b'WEBP':
        return 'webp'
    elif header[:6] in [b'GIF87a', b'GIF89a']:
        return 'gif'
    elif header[:2] == b'BM':
        return 'bmp'
    elif len(header) > 11 and header[4:8] == b'ftyp':
        brand = header[8:12].decode('latin-1', errors='ignore').lower()
        if 'avif' in brand:
            return 'avif'
        elif 'heic' in brand or 'heix' in brand:
            return 'heic'
        return 'avif'

    return 'unknown'


def convert_to_jpeg(
    input_path: Union[str, Path],
    output_path: Union[str, Path] = None,
    quality: int = 95
) -> Optional[Path]:
    """
    Herhangi bir görsel formatını JPEG'e dönüştür.

    Args:
        input_path: Kaynak görsel yolu
        output_path: Hedef JPEG yolu (None ise input_path.jpg olarak kaydedilir)
        quality: JPEG kalitesi (1-100)

    Returns:
        Oluşturulan JPEG dosyasının Path'i veya None
    """
    if not PIL_AVAILABLE:
        raise ImportError("PIL/Pillow is required for image conversion. Install with: pip install Pillow")

    input_path = Path(input_path)

    if output_path is None:
        output_path = input_path.with_suffix('.jpg')
    else:
        output_path = Path(output_path)

    try:
        # Detect actual format
        actual_format = detect_image_format(input_path)

        # Open image
        img = Image.open(input_path)

        # Convert to RGB if necessary (handles RGBA, P mode, etc.)
        if img.mode in ('RGBA', 'LA', 'P'):
            # Create white background for transparency
            background = Image.new('RGB', img.size, (255, 255, 255))
            if img.mode == 'P':
                img = img.convert('RGBA')
            background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
            img = background
        elif img.mode != 'RGB':
            img = img.convert('RGB')

        # Save as JPEG
        img.save(output_path, 'JPEG', quality=quality, optimize=True)

        return output_path

    except Exception as e:
        print(f"Error converting {input_path}: {e}")
        return None


def convert_bytes_to_jpeg(
    data: bytes,
    quality: int = 95
) -> Optional[bytes]:
    """
    Bytes verisini JPEG formatına dönüştür.

    Args:
        data: Görsel bytes verisi
        quality: JPEG kalitesi

    Returns:
        JPEG bytes verisi veya None
    """
    if not PIL_AVAILABLE:
        raise ImportError("PIL/Pillow is required")

    try:
        # Open from bytes
        img = Image.open(io.BytesIO(data))

        # Convert to RGB
        if img.mode in ('RGBA', 'LA', 'P'):
            background = Image.new('RGB', img.size, (255, 255, 255))
            if img.mode == 'P':
                img = img.convert('RGBA')
            background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
            img = background
        elif img.mode != 'RGB':
            img = img.convert('RGB')

        # Save to bytes
        output = io.BytesIO()
        img.save(output, 'JPEG', quality=quality, optimize=True)
        return output.getvalue()

    except Exception as e:
        print(f"Error converting bytes: {e}")
        return None


def fix_image_extension(file_path: Union[str, Path]) -> Tuple[Path, str, str]:
    """
    Dosya uzantısını gerçek formata göre düzelt.

    Args:
        file_path: Görsel dosya yolu

    Returns:
        Tuple[yeni_path, eski_format, yeni_format]
    """
    file_path = Path(file_path)
    actual_format = detect_image_format(file_path)
    current_ext = file_path.suffix.lower().lstrip('.')

    # Format to extension mapping
    format_to_ext = {
        'jpeg': 'jpg',
        'png': 'png',
        'webp': 'webp',
        'gif': 'gif',
        'bmp': 'bmp',
        'avif': 'avif',
        'heic': 'heic',
    }

    expected_ext = format_to_ext.get(actual_format, current_ext)

    if current_ext in ['jpg', 'jpeg']:
        current_ext = 'jpeg'

    if actual_format != 'unknown' and actual_format != current_ext:
        new_path = file_path.with_suffix(f'.{expected_ext}')
        file_path.rename(new_path)
        return new_path, current_ext, expected_ext

    return file_path, current_ext, current_ext


def ensure_jpeg(
    file_path: Union[str, Path],
    delete_original: bool = True
) -> Optional[Path]:
    """
    Dosyanın gerçek JPEG olmasını garanti et.
    WebP, AVIF, HEIC gibi formatları JPEG'e dönüştürür.

    Args:
        file_path: Görsel dosya yolu
        delete_original: Orijinal dosyayı sil

    Returns:
        JPEG dosya yolu veya None
    """
    file_path = Path(file_path)
    actual_format = detect_image_format(file_path)

    if actual_format == 'jpeg':
        # Already JPEG, just ensure extension is correct
        if file_path.suffix.lower() not in ['.jpg', '.jpeg']:
            new_path = file_path.with_suffix('.jpg')
            file_path.rename(new_path)
            return new_path
        return file_path

    if actual_format == 'unknown':
        return None

    # Convert to JPEG
    output_path = file_path.with_suffix('.jpg')
    result = convert_to_jpeg(file_path, output_path)

    if result and delete_original and file_path != output_path:
        try:
            file_path.unlink()
        except:
            pass

    return result


def fix_all_images_in_folder(
    folder_path: Union[str, Path],
    convert_to_jpeg_: bool = True,
    delete_originals: bool = True
) -> dict:
    """
    Klasördeki tüm görsellerin formatını düzelt.

    Args:
        folder_path: Klasör yolu
        convert_to_jpeg_: Tüm görselleri JPEG'e dönüştür
        delete_originals: Orijinal dosyaları sil

    Returns:
        İstatistikler dict'i
    """
    folder_path = Path(folder_path)
    stats = {
        'total': 0,
        'already_jpeg': 0,
        'converted': 0,
        'failed': 0,
        'formats_found': {}
    }

    extensions = ['.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.avif', '.heic']

    for ext in extensions:
        for file_path in folder_path.glob(f'*{ext}'):
            if not file_path.is_file():
                continue

            stats['total'] += 1
            actual_format = detect_image_format(file_path)

            # Track formats found
            stats['formats_found'][actual_format] = stats['formats_found'].get(actual_format, 0) + 1

            if actual_format == 'jpeg':
                stats['already_jpeg'] += 1
                # Fix extension if wrong
                if file_path.suffix.lower() not in ['.jpg', '.jpeg']:
                    new_path = file_path.with_suffix('.jpg')
                    file_path.rename(new_path)
            elif convert_to_jpeg_:
                result = ensure_jpeg(file_path, delete_original=delete_originals)
                if result:
                    stats['converted'] += 1
                else:
                    stats['failed'] += 1

    return stats


def validate_image_for_api(file_path: Union[str, Path]) -> Tuple[bool, str, str]:
    """
    Görselin API'ye gönderilmeye uygun olup olmadığını kontrol et.

    Args:
        file_path: Görsel dosya yolu

    Returns:
        Tuple[is_valid, actual_format, expected_mime_type]
    """
    file_path = Path(file_path)
    ext = file_path.suffix.lower()
    actual_format = detect_image_format(file_path)

    # Extension to expected format
    ext_to_format = {
        '.jpg': 'jpeg',
        '.jpeg': 'jpeg',
        '.png': 'png',
        '.gif': 'gif',
        '.webp': 'webp',
    }

    expected_format = ext_to_format.get(ext, 'unknown')

    # Format to MIME type
    format_to_mime = {
        'jpeg': 'image/jpeg',
        'png': 'image/png',
        'gif': 'image/gif',
        'webp': 'image/webp',
    }

    is_valid = actual_format == expected_format
    mime_type = format_to_mime.get(actual_format, f'image/{actual_format}')

    return is_valid, actual_format, mime_type


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("TATANGA - Image Format Fixer")
    print("=" * 70)

    print(f"\nPIL Available: {PIL_AVAILABLE}")

    # Test with existing problematic image
    test_path = Path(r"c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces\output\vinted_listings")

    if test_path.exists():
        print(f"\nScanning: {test_path}")

        for img_folder in test_path.iterdir():
            if img_folder.is_dir():
                images_dir = img_folder / "images"
                if images_dir.exists():
                    print(f"\n  Folder: {img_folder.name}")
                    for img_file in images_dir.iterdir():
                        if img_file.is_file():
                            fmt = detect_image_format(img_file)
                            ext = img_file.suffix
                            valid, actual, mime = validate_image_for_api(img_file)
                            status = "✓" if valid else "⚠️ MISMATCH"
                            print(f"    {img_file.name}: ext={ext}, actual={fmt} {status}")

    print("\n" + "=" * 70)
    print("Usage:")
    print("  from integrations.image_format_fixer import ensure_jpeg, detect_image_format")
    print("  ")
    print("  # Fix single image")
    print("  ensure_jpeg('image.jpg')  # Converts WebP → JPEG if needed")
    print("  ")
    print("  # Fix all images in folder")
    print("  fix_all_images_in_folder('output/images/')")
    print("=" * 70)
