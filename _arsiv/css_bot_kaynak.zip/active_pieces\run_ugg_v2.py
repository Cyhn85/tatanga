# -*- coding: utf-8 -*-
"""
UGG Stiefel V2 Scraper Runner
==============================
Kleinanzeigen ve eBay V2 scraperlarını kullanarak UGG Stiefel araması yapar.
"""

import sys
import json
import sqlite3
from pathlib import Path
from datetime import datetime

# V2 Scraperları import et
sys.path.insert(0, str(Path(__file__).parent))

from kleinanzeigen_v2_scraper import KleinanzeigenV2Scraper
from ebay_de_v2_scraper import EbayDeV2Scraper

DB_PATH = Path(__file__).parent / 'storage' / 'tatanga.db'


def save_to_db(products: list, batch_id: str) -> int:
    """Ürünleri veritabanına kaydet"""
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()

    saved = 0
    for p in products:
        try:
            # Images handling
            images = p.get('images', [p.get('image', '')])
            if not isinstance(images, list):
                images = [images] if images else []
            images_json = json.dumps(images)

            cursor.execute('''
                INSERT OR IGNORE INTO products
                (title, url, price, currency, platform, images, location, batch_id, is_in_inbox, scraped_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
            ''', (
                p.get('title', '')[:500],
                p.get('url', ''),
                p.get('price_value', 0),
                'EUR',
                p.get('platform', 'unknown'),
                images_json,
                p.get('location', ''),
                batch_id,
                datetime.now().isoformat()
            ))
            saved += 1
        except Exception as e:
            print(f'  [SAVE ERROR] {e}')

    conn.commit()
    conn.close()
    return saved


def main():
    print('=' * 60)
    print('V2 SCRAPERS - UGG Stiefel Search')
    print('Platforms: Kleinanzeigen + eBay DE')
    print('=' * 60)

    batch_id = f'ugg_v2_{datetime.now().strftime("%Y%m%d_%H%M%S")}'
    all_results = []

    # ============================================
    # 1. KLEINANZEIGEN
    # ============================================
    print('\n[KLEINANZEIGEN] Starting...')
    try:
        scraper = KleinanzeigenV2Scraper(headless=False, fast_mode=True)
        results = scraper.scrape_kleinanzeigen(
            query='UGG Stiefel',
            max_pages=10,
            visit_random_products=False
        )
        scraper.close()

        # Platform bilgisi ekle
        for p in results:
            p['platform'] = 'kleinanzeigen'

        all_results.extend(results)
        print(f'[KLEINANZEIGEN] Found {len(results)} products')

    except Exception as e:
        print(f'[KLEINANZEIGEN] Error: {e}')
        import traceback
        traceback.print_exc()

    # ============================================
    # 2. EBAY DE
    # ============================================
    print('\n[EBAY] Starting...')
    try:
        scraper = EbayDeV2Scraper(headless=False)
        results = scraper.scrape_ebay(
            query='UGG Stiefel',
            max_pages=10,
            condition=None
        )
        scraper.close()

        # Platform bilgisi ekle
        for p in results:
            p['platform'] = 'ebay_de'

        all_results.extend(results)
        print(f'[EBAY] Found {len(results)} products')

    except Exception as e:
        print(f'[EBAY] Error: {e}')
        import traceback
        traceback.print_exc()

    # ============================================
    # 3. VERİTABANINA KAYDET
    # ============================================
    print('\n[DB] Saving to database...')
    saved = save_to_db(all_results, batch_id)

    # Sonuçları JSON olarak da kaydet
    output_file = Path(__file__).parent / f'ugg_results_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)

    print('\n' + '=' * 60)
    print('RESULTS')
    print('=' * 60)
    print(f'Total products: {len(all_results)}')
    print(f'Saved to DB: {saved}')
    print(f'Batch ID: {batch_id}')
    print(f'JSON file: {output_file}')
    print('=' * 60)

    return all_results


if __name__ == '__main__':
    main()
