#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Communication Manager
Manages all messaging, reviews, and notifications

Features:
- Platform messaging (send/receive)
- Review reading and responding
- Multi-language support
- Auto-reply templates
- Telegram notifications
- Translation integration

Author: TATANGA Team
Version: 1.0
"""

import sys
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path
import sqlite3
import json

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")


class CommunicationManager:
    """
    Communication Manager - Handles all messaging and reviews

    Responsibilities:
    1. Send/receive platform messages
    2. Read and respond to reviews
    3. Manage message templates by language
    4. Auto-translate messages
    5. Urgent notification handling
    """

    # Message templates by language
    MESSAGE_TEMPLATES = {
        'initial_inquiry': {
            'de': "Hallo! Ist dieser Artikel noch verfügbar? Ich bin interessiert.",
            'en': "Hello! Is this item still available? I'm interested.",
            'fr': "Bonjour! Cet article est-il toujours disponible? Je suis intéressé(e).",
            'es': "¡Hola! ¿Este artículo sigue disponible? Estoy interesado/a.",
            'it': "Ciao! Questo articolo è ancora disponibile? Sono interessato/a.",
            'nl': "Hallo! Is dit artikel nog beschikbaar? Ik ben geïnteresseerd.",
            'pl': "Cześć! Czy ten przedmiot jest nadal dostępny? Jestem zainteresowany/a.",
            'sv': "Hej! Är denna artikel fortfarande tillgänglig? Jag är intresserad.",
            'da': "Hej! Er denne vare stadig tilgængelig? Jeg er interesseret.",
            'no': "Hei! Er denne varen fortsatt tilgjengelig? Jeg er interessert.",
        },
        'price_negotiation': {
            'de': "Wäre ein Preis von {price} € möglich?",
            'en': "Would a price of {price} be possible?",
            'fr': "Serait-il possible d'avoir un prix de {price} €?",
            'es': "¿Sería posible un precio de {price} €?",
            'it': "Sarebbe possibile un prezzo di {price} €?",
        },
        'thank_you': {
            'de': "Vielen Dank! Ich freue mich auf die Ware.",
            'en': "Thank you! I look forward to receiving the item.",
            'fr': "Merci beaucoup! J'ai hâte de recevoir l'article.",
            'es': "¡Muchas gracias! Espero recibir el artículo.",
            'it': "Grazie mille! Non vedo l'ora di ricevere l'articolo.",
        },
        'review_positive': {
            'de': "Vielen Dank für Ihren Einkauf! Wir freuen uns über Ihre positive Bewertung.",
            'en': "Thank you for your purchase! We appreciate your positive feedback.",
            'fr': "Merci pour votre achat! Nous apprécions votre avis positif.",
            'es': "¡Gracias por su compra! Apreciamos su valoración positiva.",
            'it': "Grazie per il suo acquisto! Apprezziamo il suo feedback positivo.",
        },
        'review_negative': {
            'de': "Vielen Dank für Ihr Feedback. Es tut uns leid, dass Sie nicht zufrieden waren. Bitte kontaktieren Sie uns für eine Lösung.",
            'en': "Thank you for your feedback. We're sorry you weren't satisfied. Please contact us to resolve this.",
            'fr': "Merci pour votre retour. Nous sommes désolés que vous n'ayez pas été satisfait. Veuillez nous contacter pour trouver une solution.",
            'es': "Gracias por sus comentarios. Lamentamos que no haya quedado satisfecho. Por favor, contáctenos para resolver esto.",
            'it': "Grazie per il suo feedback. Ci dispiace che non sia rimasto soddisfatto. La preghiamo di contattarci per risolvere la situazione.",
        }
    }

    # Urgent keywords to trigger notifications
    URGENT_KEYWORDS = {
        'de': ['dringend', 'sofort', 'problem', 'defekt', 'kaputt', 'rückgabe', 'erstattung'],
        'en': ['urgent', 'immediately', 'problem', 'defect', 'broken', 'return', 'refund'],
        'fr': ['urgent', 'immédiatement', 'problème', 'défaut', 'cassé', 'retour', 'remboursement'],
        'es': ['urgente', 'inmediatamente', 'problema', 'defecto', 'roto', 'devolución', 'reembolso'],
        'it': ['urgente', 'immediatamente', 'problema', 'difetto', 'rotto', 'reso', 'rimborso'],
    }

    def __init__(self, ceo_agent):
        """
        Initialize Communication Manager

        Args:
            ceo_agent: Reference to CEO Agent
        """
        self.ceo = ceo_agent
        self.logger = ModuleLogger("communication_manager")

        # Database
        self.db_path = Path(__file__).parent.parent.parent / 'storage' / 'communication.db'
        self._init_database()

        # Translation service
        self.translator = None

        # Statistics
        self.stats = {
            'messages_sent': 0,
            'messages_received': 0,
            'reviews_responded': 0,
            'urgent_notifications': 0
        }

        self.logger.info("Communication Manager initialized")

    def _init_database(self):
        """Initialize communication database"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Messages table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                conversation_id TEXT,
                sender_id TEXT,
                sender_name TEXT,
                receiver_id TEXT,
                direction TEXT NOT NULL,
                content TEXT NOT NULL,
                content_translated TEXT,
                language TEXT,
                is_read BOOLEAN DEFAULT 0,
                is_urgent BOOLEAN DEFAULT 0,
                related_product_id TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                replied_at DATETIME
            )
        """)

        # Reviews table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                review_id TEXT,
                product_id TEXT,
                reviewer_name TEXT,
                rating INTEGER,
                content TEXT,
                content_translated TEXT,
                language TEXT,
                our_response TEXT,
                responded_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Templates table (custom templates)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS custom_templates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                template_type TEXT NOT NULL,
                language TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(template_type, language)
            )
        """)

        conn.commit()
        conn.close()

    # ==================== MESSAGING ====================

    async def send_message(self,
                          platform: str,
                          recipient_id: str,
                          content: str,
                          product_id: str = None,
                          language: str = 'en') -> Dict:
        """
        Send a message to a seller/buyer

        Args:
            platform: Platform ID
            recipient_id: Recipient user ID
            content: Message content
            product_id: Related product ID
            language: Target language

        Returns:
            Send result
        """
        self.logger.info(f"Sending message on {platform} to {recipient_id}")

        try:
            # Get platform connector
            scraping_manager = self.ceo.get_manager(self.ceo.ManagerType.SCRAPING) if hasattr(self.ceo, 'ManagerType') else None

            if scraping_manager and platform in scraping_manager.scrapers:
                scraper = scraping_manager.scrapers[platform]

                if hasattr(scraper, 'send_message'):
                    result = await scraper.send_message(recipient_id, content)

                    # Save to database
                    self._save_message({
                        'platform': platform,
                        'sender_id': 'self',
                        'receiver_id': recipient_id,
                        'direction': 'outgoing',
                        'content': content,
                        'language': language,
                        'related_product_id': product_id
                    })

                    self.stats['messages_sent'] += 1
                    self.ceo.metrics.messages_sent += 1

                    return {'success': True, 'result': result}

            return {'success': False, 'error': 'Platform messaging not available'}

        except Exception as e:
            self.logger.error(f"Failed to send message on {platform}", exception=str(e))
            return {'success': False, 'error': str(e)}

    async def send_template_message(self,
                                    platform: str,
                                    recipient_id: str,
                                    template_type: str,
                                    language: str = 'en',
                                    variables: Dict = None) -> Dict:
        """
        Send a message using a template

        Args:
            platform: Platform ID
            recipient_id: Recipient user ID
            template_type: Template type (initial_inquiry, price_negotiation, etc.)
            language: Target language
            variables: Template variables

        Returns:
            Send result
        """
        # Get template
        template = self._get_template(template_type, language)
        if not template:
            return {'success': False, 'error': f'Template not found: {template_type}'}

        # Fill variables
        if variables:
            content = template.format(**variables)
        else:
            content = template

        return await self.send_message(platform, recipient_id, content, language=language)

    def _get_template(self, template_type: str, language: str) -> Optional[str]:
        """Get message template for language"""
        # First check custom templates
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                "SELECT content FROM custom_templates WHERE template_type = ? AND language = ?",
                (template_type, language)
            )
            row = cursor.fetchone()
            conn.close()
            if row:
                return row[0]
        except:
            pass

        # Fall back to built-in templates
        templates = self.MESSAGE_TEMPLATES.get(template_type, {})
        lang_code = language.split('-')[0] if '-' in language else language
        return templates.get(lang_code, templates.get('en'))

    def _save_message(self, message_data: Dict):
        """Save message to database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO messages
                (platform, conversation_id, sender_id, receiver_id, direction,
                 content, content_translated, language, related_product_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                message_data.get('platform'),
                message_data.get('conversation_id'),
                message_data.get('sender_id'),
                message_data.get('receiver_id'),
                message_data.get('direction'),
                message_data.get('content'),
                message_data.get('content_translated'),
                message_data.get('language'),
                message_data.get('related_product_id')
            ))

            conn.commit()
            conn.close()
        except Exception as e:
            self.logger.error("Failed to save message", exception=str(e))

    async def check_all_messages(self) -> Dict:
        """
        Check for new messages across all platforms

        Returns:
            New messages summary
        """
        self.logger.info("Checking messages on all platforms...")

        results = {
            'total_new': 0,
            'urgent': 0,
            'by_platform': {}
        }

        platforms = self.ceo.PLATFORMS if hasattr(self.ceo, 'PLATFORMS') else {}

        for platform_id in platforms.keys():
            try:
                messages = await self._fetch_platform_messages(platform_id)

                for msg in messages:
                    # Translate if needed
                    if msg.get('language') and msg['language'] not in ['en', 'de']:
                        msg['content_translated'] = await self._translate(
                            msg['content'],
                            source_lang=msg['language'],
                            target_lang='en'
                        )

                    # Check if urgent
                    is_urgent = self._check_urgent(msg)
                    msg['is_urgent'] = is_urgent

                    # Save message
                    self._save_message({
                        **msg,
                        'platform': platform_id,
                        'direction': 'incoming'
                    })

                    results['total_new'] += 1
                    if is_urgent:
                        results['urgent'] += 1
                        await self._handle_urgent_message(msg, platform_id)

                results['by_platform'][platform_id] = len(messages)
                self.stats['messages_received'] += len(messages)

            except Exception as e:
                self.logger.error(f"Failed to check messages on {platform_id}", exception=str(e))

        # Update CEO metrics
        self.ceo.metrics.messages_received += results['total_new']

        return results

    async def _fetch_platform_messages(self, platform_id: str) -> List[Dict]:
        """Fetch messages from a platform"""
        scraping_manager = self.ceo.get_manager(self.ceo.ManagerType.SCRAPING) if hasattr(self.ceo, 'ManagerType') else None

        if scraping_manager and platform_id in scraping_manager.scrapers:
            scraper = scraping_manager.scrapers[platform_id]

            if hasattr(scraper, 'get_messages'):
                return await scraper.get_messages()

        return []

    def _check_urgent(self, message: Dict) -> bool:
        """Check if message is urgent based on keywords"""
        content = message.get('content', '').lower()
        language = message.get('language', 'en')
        lang_code = language.split('-')[0] if '-' in language else language

        keywords = self.URGENT_KEYWORDS.get(lang_code, self.URGENT_KEYWORDS['en'])

        for keyword in keywords:
            if keyword in content:
                return True

        return False

    async def _handle_urgent_message(self, message: Dict, platform: str):
        """Handle urgent message - send notification"""
        self.stats['urgent_notifications'] += 1

        notification = (
            f"🚨 *Acil Mesaj - {platform}*\n\n"
            f"Gönderen: {message.get('sender_name', 'Unknown')}\n"
            f"İçerik: {message.get('content', '')[:200]}\n"
            f"Dil: {message.get('language', 'unknown')}"
        )

        if message.get('content_translated'):
            notification += f"\n\nÇeviri: {message['content_translated'][:200]}"

        await self.ceo.send_telegram_notification(notification, priority='high')

    # ==================== REVIEWS ====================

    async def check_reviews(self, platform: str = None) -> Dict:
        """
        Check for new reviews

        Args:
            platform: Specific platform or all

        Returns:
            New reviews summary
        """
        self.logger.info("Checking reviews...")

        platforms = [platform] if platform else list(self.ceo.PLATFORMS.keys()) if hasattr(self.ceo, 'PLATFORMS') else []
        results = {'total': 0, 'by_platform': {}}

        for p in platforms:
            try:
                reviews = await self._fetch_platform_reviews(p)
                for review in reviews:
                    self._save_review(review, p)
                results['by_platform'][p] = len(reviews)
                results['total'] += len(reviews)
            except Exception as e:
                self.logger.error(f"Failed to check reviews on {p}", exception=str(e))

        return results

    async def _fetch_platform_reviews(self, platform: str) -> List[Dict]:
        """Fetch reviews from a platform"""
        # Similar to messages, would need platform connector
        return []

    def _save_review(self, review: Dict, platform: str):
        """Save review to database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO reviews
                (platform, review_id, product_id, reviewer_name, rating, content, language)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                platform,
                review.get('id'),
                review.get('product_id'),
                review.get('reviewer_name'),
                review.get('rating'),
                review.get('content'),
                review.get('language')
            ))

            conn.commit()
            conn.close()
        except Exception as e:
            self.logger.error("Failed to save review", exception=str(e))

    async def respond_to_review(self,
                                review_id: int,
                                response: str = None,
                                auto_generate: bool = True) -> Dict:
        """
        Respond to a review

        Args:
            review_id: Database review ID
            response: Custom response (or auto-generate)
            auto_generate: Generate response based on rating

        Returns:
            Response result
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            cursor.execute("SELECT * FROM reviews WHERE id = ?", (review_id,))
            review = dict(cursor.fetchone())
            conn.close()

            if not review:
                return {'success': False, 'error': 'Review not found'}

            # Generate response if not provided
            if not response and auto_generate:
                rating = review.get('rating', 3)
                language = review.get('language', 'en')
                lang_code = language.split('-')[0] if '-' in language else language

                if rating >= 4:
                    response = self.MESSAGE_TEMPLATES['review_positive'].get(
                        lang_code,
                        self.MESSAGE_TEMPLATES['review_positive']['en']
                    )
                else:
                    response = self.MESSAGE_TEMPLATES['review_negative'].get(
                        lang_code,
                        self.MESSAGE_TEMPLATES['review_negative']['en']
                    )

            # Send response via platform
            # (would need platform connector)

            # Save response
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE reviews SET our_response = ?, responded_at = ? WHERE id = ?
            """, (response, datetime.now().isoformat(), review_id))
            conn.commit()
            conn.close()

            self.stats['reviews_responded'] += 1

            return {'success': True, 'response': response}

        except Exception as e:
            self.logger.error("Failed to respond to review", exception=str(e))
            return {'success': False, 'error': str(e)}

    # ==================== TRANSLATION ====================

    async def _translate(self, text: str, source_lang: str, target_lang: str) -> str:
        """Translate text"""
        try:
            # Try to use translation service
            if not self.translator:
                from services.translation_service import TranslationService
                self.translator = TranslationService()

            return await self.translator.translate(text, source_lang, target_lang)
        except:
            return text

    # ==================== INBOX/OUTBOX ====================

    async def get_inbox(self, platform: str = None, limit: int = 50) -> List[Dict]:
        """Get incoming messages"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            if platform:
                cursor.execute("""
                    SELECT * FROM messages
                    WHERE direction = 'incoming' AND platform = ?
                    ORDER BY created_at DESC LIMIT ?
                """, (platform, limit))
            else:
                cursor.execute("""
                    SELECT * FROM messages
                    WHERE direction = 'incoming'
                    ORDER BY created_at DESC LIMIT ?
                """, (limit,))

            rows = cursor.fetchall()
            conn.close()

            return [dict(row) for row in rows]

        except Exception as e:
            self.logger.error("Failed to get inbox", exception=str(e))
            return []

    async def get_unread_count(self) -> int:
        """Get count of unread messages"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                "SELECT COUNT(*) FROM messages WHERE direction = 'incoming' AND is_read = 0"
            )
            count = cursor.fetchone()[0]
            conn.close()
            return count
        except:
            return 0

    # ==================== STATUS ====================

    def get_status(self) -> Dict:
        """Get manager status"""
        return {
            'status': 'healthy',
            'stats': self.stats
        }


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("COMMUNICATION MANAGER TEST")
    print("=" * 60)

    class MockCEO:
        class ManagerType:
            SCRAPING = 'scraping'
        PLATFORMS = {'vinted_de': {}}

        def get_manager(self, t):
            return None

        async def send_telegram_notification(self, msg, priority):
            print(f"[TELEGRAM] {msg}")

        class metrics:
            messages_sent = 0
            messages_received = 0

    async def test():
        ceo = MockCEO()
        manager = CommunicationManager(ceo)

        # Test template
        template = manager._get_template('initial_inquiry', 'de')
        print(f"\nGerman template: {template}")

        template_en = manager._get_template('initial_inquiry', 'en')
        print(f"English template: {template_en}")

        print(f"\nStatus: {manager.get_status()}")
        print("\n✅ Communication Manager test complete!")

    asyncio.run(test())
    print("=" * 60)
