#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TRANSLATOR AGENT - 24/7 AI Translation Worker
Continuous keyword and listing translation service

Features:
- Monitors translation queue
- Pre-translates keywords for search
- Translates listings for cross-platform publishing
- Caches translations for efficiency
- Groq AI powered (llama-3.3-70b)
- Database-backed queue

Author: TATANGA Team
Version: 1.0
"""

import sys
import asyncio
import sqlite3
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents.base_agent import BaseAgent, AgentConfig
from integrations.smart_translator import SmartTranslator
from integrations.keyword_translator import KeywordTranslator, PreSearchTranslator


class TranslatorAgent(BaseAgent):
    """
    24/7 Translation Agent

    Monitors a translation queue and processes translation requests
    for keywords, titles, and descriptions.

    Usage:
        # Start as background service
        agent = TranslatorAgent()
        agent.start()

        # Queue translation requests
        agent.queue_keyword_translation("deri ceket", ["vinted_de", "vinted_fr"])
        agent.queue_listing_translation(product_id=123, target_platform="tradera")

        # Stop agent
        agent.stop()
    """

    def __init__(self, interval_seconds: int = 10):
        """
        Initialize Translator Agent

        Args:
            interval_seconds: How often to check the queue
        """
        config = AgentConfig(
            name="translator",
            interval_seconds=interval_seconds,
            max_retries=3,
            retry_delay_seconds=5
        )
        super().__init__(config)

        # Initialize translators
        self.smart_translator = SmartTranslator()
        self.keyword_translator = KeywordTranslator()
        self.pre_search = PreSearchTranslator()

        # Queue database
        self.queue_db = Path(__file__).parent.parent / 'storage' / 'translation_queue.db'
        self._init_queue_db()

        # Processing stats
        self.processed_count = 0
        self.failed_count = 0

    def _init_queue_db(self):
        """Initialize translation queue database"""
        self.queue_db.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        # Translation queue table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS translation_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_type TEXT NOT NULL,
                source_text TEXT NOT NULL,
                source_lang TEXT,
                target_platforms TEXT NOT NULL,
                priority INTEGER DEFAULT 5,
                status TEXT DEFAULT 'pending',
                result TEXT,
                error_message TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                processed_at DATETIME,
                product_id INTEGER
            )
        """)

        # Index for pending items
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_queue_status_priority
            ON translation_queue(status, priority DESC, created_at)
        """)

        conn.commit()
        conn.close()

    async def setup(self):
        """Setup hook - called before first process"""
        self.logger.info("Translator Agent starting up")

        # Check Groq API availability
        if not self.smart_translator.groq:
            self.logger.warning("Groq API not available - translations will fail!")
        else:
            self.logger.info("Groq API ready")

    async def process(self) -> Dict[str, Any]:
        """
        Main processing loop - check queue and process translations

        Returns:
            Processing result summary
        """
        results = {
            'processed': 0,
            'failed': 0,
            'skipped': 0
        }

        # Get pending items from queue
        items = self._get_pending_items(limit=10)

        if not items:
            return {'status': 'idle', 'message': 'No pending translations'}

        self.logger.info(f"Processing {len(items)} translation requests")

        for item in items:
            try:
                # Mark as processing
                self._update_status(item['id'], 'processing')

                # Process based on type
                if item['request_type'] == 'keyword':
                    result = await self._process_keyword(item)
                elif item['request_type'] == 'listing':
                    result = await self._process_listing(item)
                else:
                    result = {'error': f"Unknown request type: {item['request_type']}"}

                # Save result
                if 'error' in result:
                    self._mark_failed(item['id'], result['error'])
                    results['failed'] += 1
                    self.failed_count += 1
                else:
                    self._mark_completed(item['id'], result)
                    results['processed'] += 1
                    self.processed_count += 1

            except Exception as e:
                self._mark_failed(item['id'], str(e))
                results['failed'] += 1
                self.failed_count += 1
                self.logger.error(f"Translation error: {e}")

        results['total_processed'] = self.processed_count
        results['total_failed'] = self.failed_count

        return results

    async def _process_keyword(self, item: Dict) -> Dict:
        """Process keyword translation request"""
        source_text = item['source_text']
        target_platforms = json.loads(item['target_platforms'])

        self.logger.info(f"Translating keyword: '{source_text}' -> {len(target_platforms)} platforms")

        translations = self.keyword_translator.translate(
            source_text,
            platforms=target_platforms
        )

        return {
            'keyword': source_text,
            'translations': translations
        }

    async def _process_listing(self, item: Dict) -> Dict:
        """Process listing translation request"""
        product_id = item.get('product_id')
        target_platforms = json.loads(item['target_platforms'])

        if not product_id:
            return {'error': 'No product_id provided'}

        # Get product from database
        product = self._get_product(product_id)
        if not product:
            return {'error': f'Product not found: {product_id}'}

        self.logger.info(f"Translating listing {product_id}: '{product['title'][:30]}...'")

        results = {}
        for platform in target_platforms:
            try:
                translation = self.smart_translator.translate_for_listing(
                    title=product['title'],
                    description=product['description'],
                    target_platform=platform,
                    source_platform=product.get('source_platform', 'ebay_de')
                )
                results[platform] = translation
            except Exception as e:
                results[platform] = {'error': str(e)}

        return {
            'product_id': product_id,
            'translations': results
        }

    def _get_product(self, product_id: int) -> Optional[Dict]:
        """Get product from main database"""
        db_path = Path(__file__).parent.parent / 'tatanga.db'

        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()

            cursor.execute("""
                SELECT title, description, source_platform
                FROM products
                WHERE id = ?
            """, (product_id,))

            row = cursor.fetchone()
            conn.close()

            if row:
                return {
                    'title': row[0],
                    'description': row[1],
                    'source_platform': row[2]
                }
            return None

        except Exception as e:
            self.logger.error(f"Database error: {e}")
            return None

    def _get_pending_items(self, limit: int = 10) -> List[Dict]:
        """Get pending translation items from queue"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, request_type, source_text, source_lang, target_platforms,
                   priority, product_id
            FROM translation_queue
            WHERE status = 'pending'
            ORDER BY priority DESC, created_at
            LIMIT ?
        """, (limit,))

        rows = cursor.fetchall()
        conn.close()

        return [
            {
                'id': row[0],
                'request_type': row[1],
                'source_text': row[2],
                'source_lang': row[3],
                'target_platforms': row[4],
                'priority': row[5],
                'product_id': row[6]
            }
            for row in rows
        ]

    def _update_status(self, item_id: int, status: str):
        """Update item status"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE translation_queue SET status = ? WHERE id = ?",
            (status, item_id)
        )
        conn.commit()
        conn.close()

    def _mark_completed(self, item_id: int, result: Dict):
        """Mark item as completed"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE translation_queue
            SET status = 'completed', result = ?, processed_at = datetime('now')
            WHERE id = ?
        """, (json.dumps(result), item_id))
        conn.commit()
        conn.close()

    def _mark_failed(self, item_id: int, error: str):
        """Mark item as failed"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE translation_queue
            SET status = 'failed', error_message = ?, processed_at = datetime('now')
            WHERE id = ?
        """, (error, item_id))
        conn.commit()
        conn.close()

    # ========================================================================
    # PUBLIC API - Queue Translation Requests
    # ========================================================================

    def queue_keyword_translation(
        self,
        keyword: str,
        target_platforms: List[str],
        priority: int = 5
    ) -> int:
        """
        Queue a keyword for translation

        Args:
            keyword: Search keyword to translate
            target_platforms: List of target platforms
            priority: Priority (1-10, higher = more urgent)

        Returns:
            Queue item ID
        """
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO translation_queue
            (request_type, source_text, target_platforms, priority)
            VALUES ('keyword', ?, ?, ?)
        """, (keyword, json.dumps(target_platforms), priority))

        item_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Queued keyword translation: '{keyword}' (ID: {item_id})")
        return item_id

    def queue_listing_translation(
        self,
        product_id: int,
        target_platforms: List[str],
        priority: int = 5
    ) -> int:
        """
        Queue a product listing for translation

        Args:
            product_id: Product ID in database
            target_platforms: List of target platforms
            priority: Priority (1-10, higher = more urgent)

        Returns:
            Queue item ID
        """
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO translation_queue
            (request_type, source_text, target_platforms, priority, product_id)
            VALUES ('listing', '', ?, ?, ?)
        """, (json.dumps(target_platforms), priority, product_id))

        item_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Queued listing translation: product {product_id} (ID: {item_id})")
        return item_id

    def translate_keyword_now(
        self,
        keyword: str,
        target_platforms: List[str]
    ) -> Dict[str, str]:
        """
        Translate keyword immediately (synchronous)

        Args:
            keyword: Search keyword
            target_platforms: List of target platforms

        Returns:
            Dictionary mapping platform to translated keyword
        """
        return self.keyword_translator.translate(keyword, platforms=target_platforms)

    def translate_for_platform(self, keyword: str, platform: str) -> str:
        """
        Translate keyword for a single platform (synchronous)

        Args:
            keyword: Search keyword
            platform: Target platform

        Returns:
            Translated keyword
        """
        return self.pre_search.for_platform(keyword, platform)

    def get_queue_stats(self) -> Dict:
        """Get queue statistics"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT status, COUNT(*) as count
            FROM translation_queue
            GROUP BY status
        """)

        stats = {row[0]: row[1] for row in cursor.fetchall()}
        conn.close()

        return {
            'pending': stats.get('pending', 0),
            'processing': stats.get('processing', 0),
            'completed': stats.get('completed', 0),
            'failed': stats.get('failed', 0),
            'total_processed_this_session': self.processed_count,
            'total_failed_this_session': self.failed_count
        }

    def clear_completed(self, older_than_hours: int = 24) -> int:
        """Clear completed items older than specified hours"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            DELETE FROM translation_queue
            WHERE status = 'completed'
            AND datetime(processed_at, ? || ' hours') < datetime('now')
        """, (f'+{older_than_hours}',))

        deleted = cursor.rowcount
        conn.commit()
        conn.close()

        return deleted


# Test
if __name__ == "__main__":
    import time

    print("=" * 60)
    print("TRANSLATOR AGENT - TEST")
    print("=" * 60)
    print()

    # Create agent
    agent = TranslatorAgent(interval_seconds=5)

    print("Testing immediate translation:")
    print("-" * 40)

    # Test keyword translation
    keyword = "deri ceket"
    platforms = ['vinted_de', 'vinted_fr', 'ebay_uk']

    print(f"Keyword: {keyword}")
    print(f"Platforms: {platforms}")

    translations = agent.translate_keyword_now(keyword, platforms)
    for platform, translated in translations.items():
        print(f"  {platform}: {translated}")

    print()
    print("Testing single platform:")
    print("-" * 40)

    test_keywords = ["ayakkabı", "leather jacket", "Winterjacke"]
    for kw in test_keywords:
        result = agent.translate_for_platform(kw, 'vinted_de')
        print(f"  {kw} -> {result}")

    print()
    print("Testing queue:")
    print("-" * 40)

    # Queue some translations
    id1 = agent.queue_keyword_translation("kırmızı elbise", ['vinted_de', 'leboncoin'])
    id2 = agent.queue_keyword_translation("spor ayakkabı", ['finn_no', 'blocket_se'], priority=8)

    print(f"Queued item IDs: {id1}, {id2}")
    print()

    # Check queue stats
    stats = agent.get_queue_stats()
    print("Queue stats:")
    for key, value in stats.items():
        print(f"  {key}: {value}")

    print()
    print("=" * 60)
    print("Agent test completed!")
    print("To run as background service: agent.start()")
    print("=" * 60)
