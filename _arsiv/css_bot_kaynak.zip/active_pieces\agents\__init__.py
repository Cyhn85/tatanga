#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA AI AGENT SYSTEM - ENTERPRISE EDITION
24/7 Background Workers for Automation

CEO Agent Architecture:
- CEOAgent: Central orchestrator for 36 platform scraping
- ScrapingManager: 36 parallel scraping operations
- SalesManager: Favorites, sales tracking, cleanup
- CommunicationManager: Messaging, reviews, notifications
- LogisticsManager: Shipping, carrier APIs, tracking
- AccountingManager: Invoices, financial reporting

Support Agents:
- VisionAgent: AI-powered image analysis (GPT-4V/Claude)
- SelfHealingSystem: Automatic error detection and repair
- TelegramBot: Remote control interface

Legacy Agents:
- BaseAgent: Base class for all agents
- TranslatorAgent: Keyword/description translation (7/24)
- FOFImageAgent: Image analysis and background processing
- InboxAgent: Incoming messages handler
- OutboxAgent: Outgoing message queue
- StoreAgent: Store notifications
- PlatformAgent: Platform events
- AccountantAgent: Accounting and invoice management
- ScreenshotAgent: AI-powered visual scraping
- CargoAgent: Cargo tracking (DHL, Hermes, GLS, DPD)
- LearningEngine: Self-learning infrastructure
- MobileFarmManager: Android phone farm management

Orchestration:
- AgentOrchestrator: Central agent management and coordination

Author: TATANGA Team
Version: 2.0
"""

from .base_agent import BaseAgent, AgentStatus, AgentConfig, SimpleAgent

# CEO Agent Architecture (Enterprise)
try:
    from .ceo_agent import CEOAgent, ManagerType, OperationPriority, SystemMetrics
    from .managers import (
        ScrapingManager, SalesManager, CommunicationManager,
        LogisticsManager, AccountingManager
    )
    from .vision_agent import VisionAgent
    from .self_healing import SelfHealingSystem, ErrorType
    from .telegram_bot import TelegramBot
    CEO_AVAILABLE = True
except ImportError as e:
    CEO_AVAILABLE = False
    print(f"CEO Agent components not fully available: {e}")

# Legacy Agents
from .translator_agent import TranslatorAgent
from .fof_image_agent import FOFImageAgent, ImageScenario, ProcessingStrategy
from .inbox_agent import InboxAgent
from .outbox_agent import OutboxAgent
from .store_agent import StoreAgent, NotificationType
from .platform_agent import PlatformAgent, EventType
from .accountant_agent import AccountantAgent, TransactionType, PaymentMethod, InvoiceStatus
from .screenshot_agent import ScreenshotAgent, PageStatus, AnalysisType, ScreenshotResult, AnalysisResult
from .cargo_agent import CargoAgent, CarrierType, ShipmentStatus, TrackingDirection, TrackingResult
from .learning_engine import LearningEngine, LearningType, LearnedPattern, LearningInsight, get_learning_engine
from .mobile_farm import MobileFarmManager, DeviceStatus, TaskType, TaskPriority, Device, MobileTask, get_mobile_farm
from .orchestrator import AgentOrchestrator, get_orchestrator

__all__ = [
    # Base
    'BaseAgent',
    'AgentStatus',
    'AgentConfig',
    'SimpleAgent',
    # CEO Agent Architecture (Enterprise)
    'CEOAgent',
    'ManagerType',
    'OperationPriority',
    'SystemMetrics',
    'ScrapingManager',
    'SalesManager',
    'CommunicationManager',
    'LogisticsManager',
    'AccountingManager',
    'VisionAgent',
    'SelfHealingSystem',
    'ErrorType',
    'TelegramBot',
    'CEO_AVAILABLE',
    # Legacy Agents
    'TranslatorAgent',
    'FOFImageAgent',
    'ImageScenario',
    'ProcessingStrategy',
    # Factory System Agents
    'InboxAgent',
    'OutboxAgent',
    'StoreAgent',
    'NotificationType',
    'PlatformAgent',
    'EventType',
    # Accounting Agent
    'AccountantAgent',
    'TransactionType',
    'PaymentMethod',
    'InvoiceStatus',
    # Screenshot Agent
    'ScreenshotAgent',
    'PageStatus',
    'AnalysisType',
    'ScreenshotResult',
    'AnalysisResult',
    # Cargo Agent
    'CargoAgent',
    'CarrierType',
    'ShipmentStatus',
    'TrackingDirection',
    'TrackingResult',
    # Learning Engine
    'LearningEngine',
    'LearningType',
    'LearnedPattern',
    'LearningInsight',
    'get_learning_engine',
    # Mobile Farm
    'MobileFarmManager',
    'DeviceStatus',
    'TaskType',
    'TaskPriority',
    'Device',
    'MobileTask',
    'get_mobile_farm',
    # Orchestrator
    'AgentOrchestrator',
    'get_orchestrator',
]
