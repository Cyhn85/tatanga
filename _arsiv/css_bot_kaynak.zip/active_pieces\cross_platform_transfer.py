#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Cross-Platform Transfer Engine
Transfer products from ANY platform(s) to ANY platform(s) + stores

Architecture:
    Source Platforms (1-N)
        ↓
    Product Selection (M products)
        ↓
    Target Stores (1-K stores + CSSBerlin)
        ↓
    Transfer Matrix: M × K unique listings
        ↓
    For each listing:
        1. Image Manipulation (unique per target)
        2. SEO Variation (unique per target)
        3. Upload to target store
        4. Track in database

Example:
    Sources: Vinted (10 products) + eBay (5 products)
    Targets: eBay Shop1, eBay Shop2, Kleinanzeigen Shop1, CSSBerlin
    Result: 15 products × 4 targets = 60 unique listings

Performance:
    - Parallel processing: 5 workers
    - Estimated time: 15-20 seconds per listing
    - 60 listings = ~15-20 minutes total
"""

import sys, io
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

import sqlite3
from pathlib import Path
import time
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import json
import hashlib

sys.path.insert(0, str(Path(__file__).parent))
from core.logger import ModuleLogger
from config.credentials import DATABASE, TELEGRAM, API_KEYS
from integrations.image_manipulator import ImageManipulator
from integrations.hash_tester import HashTester
from integrations.groq_seo_generator import GroqSEOGenerator
from integrations.platform_connectors import PlatformConnectors

try:
    from integrations.cssberlin_adapter import CSSBerlinAdapter
except ImportError:
    CSSBerlinAdapter = None

# Platform connectors (real implementations)
try:
    from integrations.smart_translator import SmartTranslator
except ImportError:
    SmartTranslator = None

try:
    from integrations.ebay_connector import eBayConnector
except ImportError:
    eBayConnector = None

try:
    from integrations.tradera_connector import TraderaConnector
except ImportError:
    TraderaConnector = None

try:
    from integrations.kleinanzeigen_connector import KleinanzeigenConnector
except ImportError:
    KleinanzeigenConnector = None


class CrossPlatformTransfer:
    """
    Cross-platform transfer engine

    Usage:
        engine = CrossPlatformTransfer()

        # Define transfer
        transfer_config = {
            'sources': ['vinted_de', 'ebay_de'],
            'product_ids': [1, 2, 3, 4, 5],  # Optional: specific products
            'targets': [
                {'platform': 'ebay_de', 'store': 'shop1'},
                {'platform': 'ebay_de', 'store': 'shop2'},
                {'platform': 'kleinanzeigen', 'store': 'shop1'},
            ],
            'cssberlin_auto': True,  # Always include CSSBerlin
            'manipulation_level': 'aggressive',
            'seo_style': 'balanced'
        }

        # Execute
        result = engine.execute_transfer(transfer_config, progress_callback=callback)
    """

    def __init__(self):
        self.module_name = 'cross_platform_transfer'
        self.logger = ModuleLogger(self.module_name)

        # Database
        self.db_path = Path(DATABASE['db_path'])

        # Components
        self.connector = PlatformConnectors()
        self.manipulator = ImageManipulator()
        self.hash_tester = HashTester()
        self.seo_generator = GroqSEOGenerator()

        # CSSBerlin adapter
        self.cssberlin_adapter = None
        if CSSBerlinAdapter:
            try:
                config = {
                    'github_repo_path': 'C:/Users/cyhnsrgc/Desktop/CSS-Berlin-Website',
                    'github_branch': 'main',
                    'products_folder': 'products',
                    'base_url': 'https://cssberlin.de'
                }
                self.cssberlin_adapter = CSSBerlinAdapter(config)
                self.logger.info("CSSBerlin adapter initialized")
            except Exception as e:
                self.logger.warning("CSSBerlin adapter unavailable", exception=e)

        # Smart Translator (for cross-language platforms)
        self.translator = None
        if SmartTranslator:
            try:
                self.translator = SmartTranslator()
                self.logger.info("Smart Translator initialized")
            except Exception as e:
                self.logger.warning("Smart Translator unavailable", exception=e)

        # Storage
        self.storage_dir = Path(__file__).parent / 'storage'
        self.temp_dir = self.storage_dir / 'temp_transfer'
        self.temp_dir.mkdir(parents=True, exist_ok=True)

        # Performance
        self.max_workers = 5  # Parallel transfer threads

        # Stats
        self.transfer_stats = {
            'total_listings': 0,
            'successful': 0,
            'failed': 0,
            'start_time': None,
            'end_time': None
        }

    def get_db_connection(self):
        """Get database connection"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            return conn
        except Exception as e:
            self.logger.error("Database bağlantı hatası", exception=e)
            return None

    def execute_transfer(self, transfer_config, progress_callback=None):
        """
        Execute cross-platform transfer

        Args:
            transfer_config: Transfer configuration dict
            progress_callback: Function called with progress updates

        Returns:
            dict: Transfer result with stats
        """
        self.logger.start_run("Cross-Platform Transfer")
        self.transfer_stats['start_time'] = time.time()

        try:
            # Step 1: Load source products
            self.logger.info("📥 Kaynak ürünler yükleniyor...")
            source_products = self._load_source_products(
                transfer_config['sources'],
                transfer_config.get('product_ids')
            )

            if not source_products:
                self.logger.error("Kaynak ürün bulunamadı!")
                return {'success': False, 'error': 'No source products'}

            self.logger.success(f"✅ {len(source_products)} kaynak ürün yüklendi")

            if progress_callback:
                progress_callback({
                    'stage': 'load_sources',
                    'progress': 100,
                    'message': f'{len(source_products)} ürün yüklendi'
                })

            # Step 2: Prepare target stores
            targets = transfer_config['targets']

            # Always add CSSBerlin
            if transfer_config.get('cssberlin_auto', True):
                cssberlin_target = {'platform': 'cssberlin', 'store': 'main'}
                if cssberlin_target not in targets:
                    targets.append(cssberlin_target)

            self.logger.info(f"🎯 Hedef mağazalar: {len(targets)}")

            # Step 3: Calculate transfer matrix
            total_listings = len(source_products) * len(targets)
            self.transfer_stats['total_listings'] = total_listings

            self.logger.info(
                f"📊 Transfer Matrix: {len(source_products)} ürün × {len(targets)} hedef = {total_listings} ilan"
            )

            if progress_callback:
                progress_callback({
                    'stage': 'prepare_matrix',
                    'progress': 100,
                    'message': f'{total_listings} benzersiz ilan oluşturulacak'
                })

            # Step 4: Generate transfer tasks
            transfer_tasks = self._generate_transfer_tasks(
                source_products,
                targets,
                transfer_config
            )

            # Step 5: Execute transfers in parallel
            self.logger.info("🚀 Paralel transfer başlıyor...")

            results = []
            completed = 0

            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = {
                    executor.submit(self._execute_single_transfer, task): task
                    for task in transfer_tasks
                }

                for future in as_completed(futures):
                    task = futures[future]
                    try:
                        result = future.result()
                        results.append(result)

                        if result['success']:
                            self.transfer_stats['successful'] += 1
                        else:
                            self.transfer_stats['failed'] += 1

                        completed += 1
                        progress = int((completed / total_listings) * 100)

                        if progress_callback:
                            progress_callback({
                                'stage': 'transfer',
                                'progress': progress,
                                'message': f'{completed}/{total_listings} ilan tamamlandı',
                                'current_task': task
                            })

                        self.logger.info(
                            f"[{completed}/{total_listings}] Transfer tamamlandı",
                            product=task['product_title'][:30],
                            target=task['target_store'],
                            success=result['success']
                        )

                    except Exception as e:
                        self.logger.error("Transfer hatası", exception=e, task=task)
                        self.transfer_stats['failed'] += 1

            # Step 6: Summary
            self.transfer_stats['end_time'] = time.time()
            duration = self.transfer_stats['end_time'] - self.transfer_stats['start_time']

            summary = {
                'success': True,
                'total_listings': total_listings,
                'successful': self.transfer_stats['successful'],
                'failed': self.transfer_stats['failed'],
                'duration_seconds': duration,
                'duration_formatted': self._format_duration(duration),
                'results': results
            }

            self.logger.success(
                "✅ Cross-Platform Transfer Tamamlandı",
                total=total_listings,
                successful=self.transfer_stats['successful'],
                failed=self.transfer_stats['failed'],
                duration=summary['duration_formatted']
            )

            # Send Telegram notification
            self._send_telegram_notification(summary)

            if progress_callback:
                progress_callback({
                    'stage': 'complete',
                    'progress': 100,
                    'message': 'Transfer tamamlandı!',
                    'summary': summary
                })

            self.logger.end_run(success=True)
            return summary

        except Exception as e:
            self.logger.error("Transfer engine hatası", exception=e)
            self.logger.end_run(success=False)

            return {
                'success': False,
                'error': str(e)
            }

    def _load_source_products(self, source_platforms, product_ids=None):
        """Load products from source platforms"""
        all_products = []

        if product_ids:
            # Load specific products from database
            conn = self.get_db_connection()
            if conn:
                placeholders = ','.join('?' * len(product_ids))
                query = f"SELECT * FROM products WHERE id IN ({placeholders})"
                cursor = conn.execute(query, product_ids)
                rows = cursor.fetchall()

                for row in rows:
                    all_products.append(dict(row))

                conn.close()

        else:
            # Load from platforms using hybrid approach
            results = self.connector.scrape_multiple_platforms(
                source_platforms,
                limit_per_platform=20
            )

            for platform, products in results.items():
                all_products.extend(products)

        return all_products

    def _generate_transfer_tasks(self, source_products, targets, config):
        """Generate transfer task list"""
        tasks = []

        for product in source_products:
            for target in targets:
                task = {
                    'product_id': product.get('id'),
                    'product_title': product.get('title', 'Untitled'),
                    'product_description': product.get('description', ''),
                    'product_price': product.get('price', 0),
                    'product_images': product.get('image_urls', '').split(',') if product.get('image_urls') else [],
                    'source_platform': product.get('platform', 'unknown'),
                    'target_platform': target['platform'],
                    'target_store': target['store'],
                    'manipulation_level': config.get('manipulation_level', 'aggressive'),
                    'seo_style': config.get('seo_style', 'balanced')
                }

                tasks.append(task)

        return tasks

    def _execute_single_transfer(self, task):
        """Execute single product transfer"""
        start_time = time.time()

        try:
            product_id = task['product_id']
            target_platform = task['target_platform']
            target_store = task['target_store']

            # Step 1: Download images
            image_paths = self._download_images(task['product_images'], product_id)

            # Step 2: Manipulate images
            manipulated_images = []
            for img_path in image_paths:
                manipulated_img = self.manipulator.process_single(
                    img_path,
                    manipulation_level=task['manipulation_level']
                )

                if manipulated_img:
                    # Save
                    output_path = self.temp_dir / f"{product_id}_{target_store}_{Path(img_path).name}"
                    manipulated_img.save(output_path, quality=95)
                    manipulated_images.append(str(output_path))

            # Step 3: Generate SEO variation
            seo_variation = self.seo_generator.generate_variation(
                original_title=task['product_title'],
                original_description=task['product_description'],
                platform=target_platform,
                language='de',
                variation_style=task['seo_style']
            )

            # Step 4: Upload to target platform
            upload_result = self._upload_to_platform(
                platform=target_platform,
                store=target_store,
                title=seo_variation['title'],
                description=seo_variation['description'],
                price=task['product_price'],
                images=manipulated_images
            )

            # Step 5: Track in database
            if upload_result['success']:
                self._save_transfer_record(task, seo_variation, upload_result)

            duration = time.time() - start_time

            return {
                'success': upload_result['success'],
                'task': task,
                'seo_variation': seo_variation,
                'upload_result': upload_result,
                'duration': duration
            }

        except Exception as e:
            self.logger.error("Single transfer hatası", exception=e, task=task)
            return {
                'success': False,
                'task': task,
                'error': str(e)
            }

    def _download_images(self, image_urls, product_id):
        """Download product images"""
        downloaded = []

        for idx, url in enumerate(image_urls[:5], 1):  # Max 5 images
            try:
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    img_path = self.temp_dir / f"product_{product_id}_img_{idx}.jpg"
                    img_path.write_bytes(response.content)
                    downloaded.append(str(img_path))
            except Exception as e:
                self.logger.warning("Image download hatası", url=url, exception=e)

        return downloaded

    def _upload_to_platform(self, platform, store, title, description, price, images):
        """Upload product to target platform"""
        # Placeholder: Implement actual upload logic for each platform

        if platform == 'cssberlin':
            # Use CSSBerlin API
            return self._upload_to_cssberlin(store, title, description, price, images)

        elif platform == 'ebay_de':
            # Use eBay API
            return self._upload_to_ebay(store, title, description, price, images)

        elif platform == 'kleinanzeigen':
            # Use Kleinanzeigen API/Selenium
            return self._upload_to_kleinanzeigen(store, title, description, price, images)

        elif platform == 'tradera':
            # Use Tradera API with Swedish translation
            return self._upload_to_tradera(store, title, description, price, images)

        else:
            # Placeholder
            self.logger.warning("Platform upload henüz implement edilmedi", platform=platform)
            return {
                'success': False,
                'error': 'Platform not implemented'
            }

    def _upload_to_cssberlin(self, store, title, description, price, images):
        """Upload to CSS Berlin via HTML generation + Git push"""

        if not self.cssberlin_adapter:
            self.logger.error("CSSBerlin adapter not available")
            return {
                'success': False,
                'error': 'CSSBerlin adapter not initialized'
            }

        try:
            # Prepare product data for cssberlin_adapter
            product_data = {
                'title': title,
                'description': description,
                'price': str(price),
                'images': images,  # List of local file paths
                'delivery_time': '7-10',
                'category': '',
                'brand': '',
                'original_url': f'DIS_{int(time.time())}'
            }

            # Create product page (HTML + Git push)
            result = self.cssberlin_adapter.create_product_page(product_data)

            if result['success']:
                self.logger.success(
                    "CSSBerlin product published",
                    url=result['live_url']
                )
                return {
                    'success': True,
                    'listing_id': result['html_file'],
                    'url': result['live_url']
                }
            else:
                self.logger.error("CSSBerlin publish failed", error=result['message'])
                return {
                    'success': False,
                    'error': result['message']
                }

        except Exception as e:
            self.logger.error("CSSBerlin upload exception", exception=e)
            return {
                'success': False,
                'error': str(e)
            }

    def _upload_to_ebay(self, store, title, description, price, images):
        """Upload to eBay using real eBay Inventory API"""

        if not eBayConnector:
            self.logger.error("eBay connector not available")
            return {
                'success': False,
                'error': 'eBay connector not installed'
            }

        try:
            # Get store credentials from database
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT credentials FROM store_accounts
                WHERE platform = 'ebay_de' AND store_name = ?
            """, (store,))

            row = cursor.fetchone()
            conn.close()

            if not row:
                return {
                    'success': False,
                    'error': f'No credentials found for eBay store: {store}'
                }

            # Parse credentials
            import json
            creds = json.loads(row[0])

            # Initialize eBay connector
            ebay = eBayConnector(
                app_id=creds.get('app_id') or API_KEYS.get('ebay_app_id'),
                cert_id=creds.get('cert_id') or API_KEYS.get('ebay_cert_id'),
                dev_id=creds.get('dev_id') or API_KEYS.get('ebay_dev_id'),
                user_token=creds.get('user_token'),
                refresh_token=creds.get('refresh_token'),
                sandbox=API_KEYS.get('ebay_sandbox', True)
            )

            # Check if translation needed (German platform, no translation)
            # But SmartTranslator can still enhance SEO

            # Prepare listing data
            listing_data = {
                'title': title[:80],  # eBay max 80 chars
                'description': description,
                'price': float(price),
                'quantity': 1,
                'condition': 'USED_EXCELLENT',
                'category_id': '11450',  # Default category
                'images': images[:12]  # eBay max 12 images
            }

            # Create listing
            result = ebay.create_listing(listing_data)

            if result['success']:
                self.logger.info("eBay listing created", listing_id=result.get('listing_id'))
            else:
                self.logger.error("eBay listing failed", error=result.get('error'))

            return result

        except Exception as e:
            self.logger.error("eBay upload exception", exception=e)
            return {
                'success': False,
                'error': str(e)
            }

    def _upload_to_kleinanzeigen(self, store, title, description, price, images):
        """Upload to Kleinanzeigen using adaptive Selenium automation"""

        if not KleinanzeigenConnector:
            self.logger.error("Kleinanzeigen connector not available")
            return {
                'success': False,
                'error': 'Kleinanzeigen connector not installed'
            }

        try:
            # Get store credentials from database
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT credentials FROM store_accounts
                WHERE platform = 'kleinanzeigen' AND store_name = ?
            """, (store,))

            row = cursor.fetchone()
            conn.close()

            if not row:
                return {
                    'success': False,
                    'error': f'No credentials found for Kleinanzeigen store: {store}'
                }

            # Parse credentials
            import json
            creds = json.loads(row[0])

            # Initialize Kleinanzeigen connector (adaptive system)
            kleinanzeigen = KleinanzeigenConnector(
                email=creds.get('email'),
                password=creds.get('password'),
                headless=True
            )

            # Prepare listing data
            listing_data = {
                'title': title[:100],  # Kleinanzeigen max 100 chars
                'description': description,
                'price': float(price),
                'images': images[:20]  # Kleinanzeigen max 20 images
            }

            # Create listing
            result = kleinanzeigen.create_listing(listing_data)

            # Close browser
            kleinanzeigen.close()

            if result['success']:
                self.logger.info("Kleinanzeigen listing created", listing_id=result.get('listing_id'))
            else:
                self.logger.error("Kleinanzeigen listing failed", error=result.get('error'))

            return result

        except Exception as e:
            self.logger.error("Kleinanzeigen upload exception", exception=e)
            return {
                'success': False,
                'error': str(e)
            }

    def _upload_to_tradera(self, store, title, description, price, images):
        """Upload to Tradera (Swedish marketplace) with auto-translation"""

        if not TraderaConnector:
            self.logger.error("Tradera connector not available")
            return {
                'success': False,
                'error': 'Tradera connector not installed'
            }

        try:
            # Get store credentials from database
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT credentials FROM store_accounts
                WHERE platform = 'tradera' AND store_name = ?
            """, (store,))

            row = cursor.fetchone()
            conn.close()

            if not row:
                return {
                    'success': False,
                    'error': f'No credentials found for Tradera store: {store}'
                }

            # Parse credentials
            import json
            creds = json.loads(row[0])

            # Initialize Tradera connector
            tradera = TraderaConnector(
                app_id=creds.get('app_id') or API_KEYS.get('tradera_app_id'),
                app_key=creds.get('app_key') or API_KEYS.get('tradera_app_key'),
                token=creds.get('token') or API_KEYS.get('tradera_token')
            )

            # Check if translation needed (German → Swedish)
            needs_translation = False
            if self.translator:
                needs_translation = self.translator.needs_translation('ebay_de', 'tradera')

            # Translate if needed
            if needs_translation and self.translator:
                try:
                    translated = self.translator.translate_for_listing(
                        title=title,
                        description=description,
                        target_platform='tradera'
                    )
                    title = translated['title']
                    description = translated['description']
                    self.logger.info("Tradera content translated DE→SV")
                except Exception as e:
                    self.logger.warning("Translation failed, using original", exception=e)

            # Prepare listing data
            listing_data = {
                'title': title[:75],  # Tradera max 75 chars
                'description': description,
                'price': float(price),
                'images': images[:8]  # Tradera max 8 images
            }

            # Create listing (TraderaConnector handles auto-translation internally too)
            result = tradera.create_listing(listing_data, auto_translate=False)  # We already translated

            if result['success']:
                self.logger.info("Tradera listing created", listing_id=result.get('listing_id'))
            else:
                self.logger.error("Tradera listing failed", error=result.get('error'))

            return result

        except Exception as e:
            self.logger.error("Tradera upload exception", exception=e)
            return {
                'success': False,
                'error': str(e)
            }

    def _save_transfer_record(self, task, seo_variation, upload_result):
        """Save transfer record to database"""
        conn = self.get_db_connection()
        if not conn:
            return

        try:
            # Insert into transfer_history table (create if not exists)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS transfer_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_product_id INTEGER,
                    source_platform TEXT,
                    target_platform TEXT,
                    target_store TEXT,
                    original_title TEXT,
                    new_title TEXT,
                    new_description TEXT,
                    listing_id TEXT,
                    listing_url TEXT,
                    transferred_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)

            conn.execute("""
                INSERT INTO transfer_history
                (source_product_id, source_platform, target_platform, target_store,
                 original_title, new_title, new_description, listing_id, listing_url)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                task['product_id'],
                task['source_platform'],
                task['target_platform'],
                task['target_store'],
                task['product_title'],
                seo_variation['title'],
                seo_variation['description'],
                upload_result.get('listing_id'),
                upload_result.get('url')
            ))

            conn.commit()

        except Exception as e:
            self.logger.error("Database kayıt hatası", exception=e)

        finally:
            conn.close()

    def _send_telegram_notification(self, summary):
        """Send Telegram notification"""
        bot_token = TELEGRAM.get('bot_token')
        chat_id = TELEGRAM.get('chat_id')

        if not bot_token or not chat_id:
            return

        try:
            message = f"""
🎉 <b>Transfer Tamamlandı!</b>

📊 <b>Özet:</b>
• Toplam: {summary['total_listings']} ilan
• Başarılı: {summary['successful']} ✅
• Başarısız: {summary['failed']} ❌
• Süre: {summary['duration_formatted']}

🚀 TATANGA Cross-Platform Transfer
            """

            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            requests.post(url, json={
                'chat_id': chat_id,
                'text': message,
                'parse_mode': 'HTML'
            }, timeout=5)

        except Exception as e:
            self.logger.warning("Telegram bildirimi gönderilemedi", exception=e)

    def _format_duration(self, seconds):
        """Format duration in human-readable format"""
        if seconds < 60:
            return f"{int(seconds)}s"
        elif seconds < 3600:
            minutes = int(seconds / 60)
            secs = int(seconds % 60)
            return f"{minutes}m {secs}s"
        else:
            hours = int(seconds / 3600)
            minutes = int((seconds % 3600) / 60)
            return f"{hours}h {minutes}m"


if __name__ == "__main__":
    print("\n" + "="*80)
    print("🔄 TATANGA CROSS-PLATFORM TRANSFER ENGINE")
    print("="*80)
    print("\nKullanım:")
    print("  engine = CrossPlatformTransfer()")
    print("  ")
    print("  transfer_config = {")
    print("      'sources': ['vinted_de', 'ebay_de'],")
    print("      'targets': [")
    print("          {'platform': 'ebay_de', 'store': 'shop1'},")
    print("          {'platform': 'kleinanzeigen', 'store': 'shop1'},")
    print("      ],")
    print("      'cssberlin_auto': True,")
    print("      'manipulation_level': 'aggressive',")
    print("      'seo_style': 'balanced'")
    print("  }")
    print("  ")
    print("  result = engine.execute_transfer(transfer_config)")
    print("\nÖzellikler:")
    print("  ✅ Multi-source → Multi-target transfer")
    print("  ✅ Paralel işleme (5 worker)")
    print("  ✅ Resim manipülasyonu (her hedef için farklı)")
    print("  ✅ SEO varyasyonu (her hedef için farklı)")
    print("  ✅ Progress tracking + Telegram bildirimi")
    print("  ✅ CSSBerlin otomatik dahil")
    print("="*80 + "\n")
