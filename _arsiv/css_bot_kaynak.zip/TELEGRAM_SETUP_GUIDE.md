# TELEGRAM BOT SETUP GUIDE
## 15-Minute Configuration for TATANGA AI Assistant

---

## 📋 Prerequisites
- Telegram app (mobile or desktop)
- 15 minutes of time

---

## 🤖 STEP 1: Create Your Bot (5 minutes)

### 1.1 Open @BotFather
1. Open Telegram
2. Search for `@BotFather` (official Telegram bot)
3. Start conversation: `/start`

### 1.2 Create New Bot
1. Send command: `/newbot`
2. BotFather will ask for bot name:
   ```
   Name: TATANGA Bot
   ```
3. BotFather will ask for username (must end with 'bot'):
   ```
   Username: tatanga_css_bot
   ```
   (Or any unique name like: `css_berlin_bot`, `tatanga_assistant_bot`, etc.)

### 1.3 Get Bot Token
BotFather will respond with:
```
Done! Congratulations on your new bot. You will find it at t.me/tatanga_css_bot
You can now add a description, about section and profile picture for your bot.

Use this token to access the HTTP API:
1234567890:ABCdefGHIjklMNOpqrsTUVwxyz1234567890

Keep your token secure and store it safely, it can be used by anyone to control your bot.
```

**⚠️ CRITICAL:** Copy this token! You'll need it in Step 3.

Example token format: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz1234567890`

---

## 💬 STEP 2: Get Your Chat ID (3 minutes)

### 2.1 Start Your Bot
1. Click the link BotFather provided (t.me/your_bot_name)
2. Click `START` or send `/start` to your bot
3. Your bot won't respond yet (not configured), but that's OK

### 2.2 Get Chat ID
**Option A: Use @userinfobot (Easiest)**
1. Search for `@userinfobot` in Telegram
2. Start conversation: `/start`
3. Bot will respond with your user info:
   ```
   Id: 123456789
   First name: Your Name
   Username: @your_username
   Language: en
   ```
4. **Copy the `Id` number** (this is your chat_id)

**Option B: Use Raw API (Alternative)**
1. Replace `YOUR_BOT_TOKEN` with your token from Step 1:
2. Open this URL in browser:
   ```
   https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates
   ```
3. Look for `"chat":{"id":123456789}` in the response
4. Copy the ID number

---

## ⚙️ STEP 3: Configure TATANGA (2 minutes)

### 3.1 Open Credentials File
Navigate to:
```
c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces\config\credentials.py
```

### 3.2 Update Telegram Section
Find the `TELEGRAM` section (around line 50) and update:

**BEFORE:**
```python
TELEGRAM = {
    'bot_token': '',  # Empty
    'chat_id': '',    # Empty
}
```

**AFTER:**
```python
TELEGRAM = {
    'bot_token': '1234567890:ABCdefGHIjklMNOpqrsTUVwxyz1234567890',  # Your token from Step 1
    'chat_id': '123456789',  # Your chat_id from Step 2
}
```

### 3.3 Save File
- Press `Ctrl+S` to save
- Close editor

---

## 🧪 STEP 4: Test Your Bot (5 minutes)

### 4.1 Run Test Script
```bash
cd "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python test_telegram_bot.py
```

**Expected Output:**
```
================================================================================
TELEGRAM BOT TEST
================================================================================

✓ Bot token found
✓ Chat ID found
✓ Sending test message...
✓ Test message sent successfully!

Check your Telegram - you should see a test message from your bot.

================================================================================
✅ Configuration Successful!
================================================================================

Your bot is ready! Features available:
  • Real-time notifications
  • LiveScore AI insights
  • Product performance alerts
  • Seller risk warnings
  • Interactive buttons

To start the bot server:
  python active_pieces/integrations/telegram_bot.py
```

### 4.2 Verify in Telegram
Open Telegram and check for message from your bot:
```
🤖 TATANGA Bot Test

This is a test message to verify your bot configuration.

✅ Bot is working correctly!
✅ Notifications will be sent to this chat.

Available Commands:
/start - Initialize bot
/status - System status
/stats - Statistics
/transfer - Transfer history
/stores - Store list
/help - Help message

🧠 LiveScore AI Features:
• Product performance scoring
• Seller risk analysis
• Platform effectiveness tracking
• Intelligent recommendations
```

---

## 🚀 STEP 5: Start Your Bot (Optional - For Testing)

### 5.1 Run Bot Server
```bash
cd "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python integrations/telegram_bot.py
```

**Bot will start and display:**
```
================================================================================
🤖 TATANGA TELEGRAM BOT
================================================================================

Bot Username: @tatanga_css_bot
Chat ID: 123456789

Commands:
  /start - Initialize
  /status - System status
  /stats - Statistics
  /transfer - Transfer history
  /stores - Store list
  /help - Help

Status: RUNNING ✓
Press Ctrl+C to stop
================================================================================
```

### 5.2 Test Commands
In Telegram, send to your bot:
- `/start` - Bot should greet you
- `/status` - Bot should show system status
- `/help` - Bot should show help message

---

## 🎯 PHASE 4 AI FEATURES (Already Implemented!)

Your bot now has access to LiveScore Engine AI:

### Intelligent Notifications:
```
📊 PERFORMANCE UPDATE

📦 Nike Air Max 90
🔥 Score: 85 → 92 (+7)

📈 Stats:
• Views today: 45 (+12)
• Messages: 3
• Grade: A

💡 Recommendation:
Product is hot! Consider:
• Raising price by €5
• Creating similar listings

[VIEW DETAILS] [RAISE PRICE]
```

### Seller Risk Alerts:
```
🚨 SELLER RISK ALERT

👤 Seller: @suspicious_seller
📦 Product: MacBook Pro 13"
⚠️ Risk Score: 85/100 (HIGH)

🔍 Risk Factors:
• Requests off-platform payment
• Pushes WhatsApp contact
• Vague responses

❌ RECOMMENDATION: Decline or proceed with caution

[VIEW CONVERSATION] [BLOCK SELLER]
```

### Daily Performance Reports:
```
📊 DAILY PERFORMANCE REPORT
Date: 26.11.2025

🔥 TOP PERFORMERS (3)
1. Nike Air Max 90 → Score: 92 (A)
   💡 Raise price to €55 (+€5)

2. Adidas Yeezy → Score: 88 (A)
   💡 Duplicate to eBay UK

⚠️ ATTENTION NEEDED (2)
1. Reebok Classic → Score: 35 (D)
   💡 Drop price to €35 (-€10)

[VIEW FULL REPORT]
```

---

## ❓ TROUBLESHOOTING

### Issue: "Unauthorized" Error
**Cause:** Invalid bot token

**Solution:**
1. Go back to @BotFather
2. Send `/mybots`
3. Select your bot
4. Click "API Token"
5. Copy the correct token
6. Update `credentials.py`

### Issue: Bot doesn't send messages
**Cause:** Wrong chat_id

**Solution:**
1. Make sure you started the bot (clicked START)
2. Use @userinfobot to get correct chat_id
3. Update `credentials.py` with correct chat_id
4. Restart test script

### Issue: "Chat not found"
**Cause:** Bot hasn't been started by user

**Solution:**
1. Open your bot in Telegram (click t.me/your_bot_name)
2. Click START button
3. Try test script again

---

## 📚 NEXT STEPS

After successful configuration:

1. **Keep bot running 24/7 (Option A: Local)**
   ```bash
   cd "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
   python integrations/telegram_bot.py
   ```
   Leave terminal open

2. **Deploy to Hetzner (Option B: Production - Recommended)**
   - Follow [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)
   - Bot will run as systemd service
   - Automatic restart on failure
   - Runs 24/7 even if PC is off

3. **Integrate with Active Pieces**
   - Create workflows that send notifications
   - Use `/api/activepieces/` endpoints
   - Trigger Telegram messages automatically

---

## ✅ CHECKLIST

- [ ] Created bot via @BotFather
- [ ] Got bot token
- [ ] Got chat_id from @userinfobot
- [ ] Updated credentials.py
- [ ] Ran test_telegram_bot.py
- [ ] Received test message in Telegram
- [ ] Tested bot commands (/start, /status, /help)
- [ ] Bot is running or deployed to Hetzner

**Congratulations! Your TATANGA AI Assistant is ready!** 🎉

---

## 📞 SUPPORT

If you encounter issues:
1. Check this guide again
2. Verify credentials.py has correct token and chat_id
3. Make sure you clicked START on your bot
4. Test with `python test_telegram_bot.py`

**Estimated Total Time:** 10-15 minutes
