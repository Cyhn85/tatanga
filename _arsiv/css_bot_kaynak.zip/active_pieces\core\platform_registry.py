#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Platform Registry
============================
Merkezi platform-ulke-dil haritasi.
Tum kazima sistemleri bu registry'yi kullanir.
"""

from typing import Dict, List, Optional
from dataclasses import dataclass


@dataclass
class PlatformInfo:
    """Platform bilgisi"""
    domain: str
    country: str
    language: str
    currency: str
    name: str
    scraper_type: str  # vinted, ebay, kleinanzeigen, etc.
    is_active: bool = True


# =============================================================================
# MERKEZI PLATFORM REGISTRY
# =============================================================================

PLATFORM_REGISTRY: Dict[str, Dict] = {
    # -------------------------------------------------------------------------
    # VINTED (13 Ulke)
    # -------------------------------------------------------------------------
    'vinted.de': {
        'country': 'DE',
        'language': 'de',
        'currency': 'EUR',
        'name': 'Vinted Almanya',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.de/catalog?search_text={query}',
    },
    'vinted.fr': {
        'country': 'FR',
        'language': 'fr',
        'currency': 'EUR',
        'name': 'Vinted Fransa',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.fr/catalog?search_text={query}',
    },
    'vinted.co.uk': {
        'country': 'GB',
        'language': 'en',
        'currency': 'GBP',
        'name': 'Vinted Ingiltere',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.co.uk/catalog?search_text={query}',
    },
    'vinted.es': {
        'country': 'ES',
        'language': 'es',
        'currency': 'EUR',
        'name': 'Vinted Ispanya',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.es/catalog?search_text={query}',
    },
    'vinted.it': {
        'country': 'IT',
        'language': 'it',
        'currency': 'EUR',
        'name': 'Vinted Italya',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.it/catalog?search_text={query}',
    },
    'vinted.nl': {
        'country': 'NL',
        'language': 'nl',
        'currency': 'EUR',
        'name': 'Vinted Hollanda',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.nl/catalog?search_text={query}',
    },
    'vinted.be': {
        'country': 'BE',
        'language': 'nl',
        'currency': 'EUR',
        'name': 'Vinted Belcika',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.be/catalog?search_text={query}',
    },
    'vinted.pl': {
        'country': 'PL',
        'language': 'pl',
        'currency': 'PLN',
        'name': 'Vinted Polonya',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.pl/catalog?search_text={query}',
    },
    'vinted.cz': {
        'country': 'CZ',
        'language': 'cs',
        'currency': 'CZK',
        'name': 'Vinted Cekya',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.cz/catalog?search_text={query}',
    },
    'vinted.at': {
        'country': 'AT',
        'language': 'de',
        'currency': 'EUR',
        'name': 'Vinted Avusturya',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.at/catalog?search_text={query}',
    },
    'vinted.se': {
        'country': 'SE',
        'language': 'sv',
        'currency': 'SEK',
        'name': 'Vinted Isvec',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.se/catalog?search_text={query}',
    },
    'vinted.dk': {
        'country': 'DK',
        'language': 'da',
        'currency': 'DKK',
        'name': 'Vinted Danimarka',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.dk/catalog?search_text={query}',
    },
    'vinted.no': {
        'country': 'NO',
        'language': 'no',
        'currency': 'NOK',
        'name': 'Vinted Norvec',
        'scraper_type': 'vinted',
        'search_url': 'https://www.vinted.no/catalog?search_text={query}',
    },

    # -------------------------------------------------------------------------
    # EBAY (10 Pazar)
    # -------------------------------------------------------------------------
    'ebay.de': {
        'country': 'DE',
        'language': 'de',
        'currency': 'EUR',
        'name': 'eBay Almanya',
        'scraper_type': 'ebay',
        'search_url': 'https://www.ebay.de/sch/i.html?_nkw={query}&LH_BIN=1',
    },
    'ebay.co.uk': {
        'country': 'GB',
        'language': 'en',
        'currency': 'GBP',
        'name': 'eBay Ingiltere',
        'scraper_type': 'ebay',
        'search_url': 'https://www.ebay.co.uk/sch/i.html?_nkw={query}&LH_BIN=1',
    },
    'ebay.fr': {
        'country': 'FR',
        'language': 'fr',
        'currency': 'EUR',
        'name': 'eBay Fransa',
        'scraper_type': 'ebay',
        'search_url': 'https://www.ebay.fr/sch/i.html?_nkw={query}&LH_BIN=1',
    },
    'ebay.es': {
        'country': 'ES',
        'language': 'es',
        'currency': 'EUR',
        'name': 'eBay Ispanya',
        'scraper_type': 'ebay',
        'search_url': 'https://www.ebay.es/sch/i.html?_nkw={query}&LH_BIN=1',
    },
    'ebay.it': {
        'country': 'IT',
        'language': 'it',
        'currency': 'EUR',
        'name': 'eBay Italya',
        'scraper_type': 'ebay',
        'search_url': 'https://www.ebay.it/sch/i.html?_nkw={query}&LH_BIN=1',
    },
    'ebay.nl': {
        'country': 'NL',
        'language': 'nl',
        'currency': 'EUR',
        'name': 'eBay Hollanda',
        'scraper_type': 'ebay',
        'search_url': 'https://www.ebay.nl/sch/i.html?_nkw={query}&LH_BIN=1',
    },
    'ebay.at': {
        'country': 'AT',
        'language': 'de',
        'currency': 'EUR',
        'name': 'eBay Avusturya',
        'scraper_type': 'ebay',
        'search_url': 'https://www.ebay.at/sch/i.html?_nkw={query}&LH_BIN=1',
    },
    'ebay.pl': {
        'country': 'PL',
        'language': 'pl',
        'currency': 'PLN',
        'name': 'eBay Polonya',
        'scraper_type': 'ebay',
        'search_url': 'https://www.ebay.pl/sch/i.html?_nkw={query}&LH_BIN=1',
    },
    'ebay.com': {
        'country': 'US',
        'language': 'en',
        'currency': 'USD',
        'name': 'eBay Amerika',
        'scraper_type': 'ebay',
        'search_url': 'https://www.ebay.com/sch/i.html?_nkw={query}&LH_BIN=1',
    },

    # -------------------------------------------------------------------------
    # ALMANCA PLATFORMLAR
    # -------------------------------------------------------------------------
    'kleinanzeigen.de': {
        'country': 'DE',
        'language': 'de',
        'currency': 'EUR',
        'name': 'Kleinanzeigen',
        'scraper_type': 'kleinanzeigen',
        'search_url': 'https://www.kleinanzeigen.de/s-{query}/k0',
    },
    'willhaben.at': {
        'country': 'AT',
        'language': 'de',
        'currency': 'EUR',
        'name': 'Willhaben',
        'scraper_type': 'willhaben',
        'search_url': 'https://www.willhaben.at/iad/kaufen-und-verkaufen/marktplatz?keyword={query}',
    },
    'sellpy.de': {
        'country': 'DE',
        'language': 'de',
        'currency': 'EUR',
        'name': 'Sellpy Almanya',
        'scraper_type': 'sellpy',
        'search_url': 'https://www.sellpy.de/search?q={query}',
    },
    'percentil.de': {
        'country': 'DE',
        'language': 'de',
        'currency': 'EUR',
        'name': 'Percentil Almanya',
        'scraper_type': 'percentil',
        'search_url': 'https://www.percentil.de/search?q={query}',
    },

    # -------------------------------------------------------------------------
    # FRANSIZCA PLATFORMLAR
    # -------------------------------------------------------------------------
    'leboncoin.fr': {
        'country': 'FR',
        'language': 'fr',
        'currency': 'EUR',
        'name': 'Leboncoin',
        'scraper_type': 'leboncoin',
        'search_url': 'https://www.leboncoin.fr/recherche?text={query}',
    },

    # -------------------------------------------------------------------------
    # HOLLANDACA PLATFORMLAR
    # -------------------------------------------------------------------------
    'marktplaats.nl': {
        'country': 'NL',
        'language': 'nl',
        'currency': 'EUR',
        'name': 'Marktplaats',
        'scraper_type': 'marktplaats',
        'search_url': 'https://www.marktplaats.nl/q/{query}/',
    },

    # -------------------------------------------------------------------------
    # ISKANDINAV PLATFORMLAR
    # -------------------------------------------------------------------------
    'tradera.com': {
        'country': 'SE',
        'language': 'sv',
        'currency': 'SEK',
        'name': 'Tradera',
        'scraper_type': 'tradera',
        'search_url': 'https://www.tradera.com/search?q={query}',
    },
    'blocket.se': {
        'country': 'SE',
        'language': 'sv',
        'currency': 'SEK',
        'name': 'Blocket',
        'scraper_type': 'blocket',
        'search_url': 'https://www.blocket.se/annonser?q={query}',
    },
    'finn.no': {
        'country': 'NO',
        'language': 'no',
        'currency': 'NOK',
        'name': 'Finn.no',
        'scraper_type': 'finn',
        'search_url': 'https://www.finn.no/bap/forsale/search.html?q={query}',
    },
    'dba.dk': {
        'country': 'DK',
        'language': 'da',
        'currency': 'DKK',
        'name': 'DBA',
        'scraper_type': 'dba',
        'search_url': 'https://www.dba.dk/soeg/?soeg={query}',
    },
    'tori.fi': {
        'country': 'FI',
        'language': 'fi',
        'currency': 'EUR',
        'name': 'Tori.fi',
        'scraper_type': 'tori',
        'search_url': 'https://www.tori.fi/koko_suomi?q={query}',
    },

    # -------------------------------------------------------------------------
    # DIGER PLATFORMLAR
    # -------------------------------------------------------------------------
    'shpock.com': {
        'country': 'DE',
        'language': 'de',
        'currency': 'EUR',
        'name': 'Shpock',
        'scraper_type': 'shpock',
        'search_url': 'https://www.shpock.com/de-de/results?q={query}',
    },
}


# =============================================================================
# PLATFORM ALIASES (Kisa isimler)
# =============================================================================

PLATFORM_ALIASES: Dict[str, str] = {
    # Vinted
    'vinted': 'vinted.de',
    'vinted_de': 'vinted.de',
    'vinted_fr': 'vinted.fr',
    'vinted_uk': 'vinted.co.uk',
    'vinted_es': 'vinted.es',
    'vinted_it': 'vinted.it',
    'vinted_nl': 'vinted.nl',
    'vinted_be': 'vinted.be',
    'vinted_pl': 'vinted.pl',
    'vinted_cz': 'vinted.cz',
    'vinted_at': 'vinted.at',
    'vinted_se': 'vinted.se',
    'vinted_dk': 'vinted.dk',
    'vinted_no': 'vinted.no',

    # eBay
    'ebay': 'ebay.de',
    'ebay_de': 'ebay.de',
    'ebay_uk': 'ebay.co.uk',
    'ebay_fr': 'ebay.fr',
    'ebay_es': 'ebay.es',
    'ebay_it': 'ebay.it',
    'ebay_nl': 'ebay.nl',
    'ebay_at': 'ebay.at',
    'ebay_pl': 'ebay.pl',
    'ebay_com': 'ebay.com',
    'ebay_us': 'ebay.com',

    # Diger
    'kleinanzeigen': 'kleinanzeigen.de',
    'ka': 'kleinanzeigen.de',
    'willhaben': 'willhaben.at',
    'leboncoin': 'leboncoin.fr',
    'marktplaats': 'marktplaats.nl',
    'tradera': 'tradera.com',
    'blocket': 'blocket.se',
    'finn': 'finn.no',
    'dba': 'dba.dk',
    'tori': 'tori.fi',
    'shpock': 'shpock.com',
    'sellpy': 'sellpy.de',
    'percentil': 'percentil.de',
}


# =============================================================================
# DIL GRUPLARI
# =============================================================================

LANGUAGE_GROUPS: Dict[str, List[str]] = {
    'de': ['vinted.de', 'vinted.at', 'ebay.de', 'ebay.at', 'kleinanzeigen.de', 'willhaben.at', 'sellpy.de', 'percentil.de', 'shpock.com'],
    'en': ['vinted.co.uk', 'ebay.co.uk', 'ebay.com'],
    'fr': ['vinted.fr', 'ebay.fr', 'leboncoin.fr'],
    'es': ['vinted.es', 'ebay.es'],
    'it': ['vinted.it', 'ebay.it'],
    'nl': ['vinted.nl', 'vinted.be', 'ebay.nl', 'marktplaats.nl'],
    'pl': ['vinted.pl', 'ebay.pl'],
    'cs': ['vinted.cz'],
    'sv': ['vinted.se', 'tradera.com', 'blocket.se'],
    'da': ['vinted.dk', 'dba.dk'],
    'no': ['vinted.no', 'finn.no'],
    'fi': ['tori.fi'],
}


# =============================================================================
# YARDIMCI FONKSIYONLAR
# =============================================================================

def get_platform_info(platform: str) -> Optional[Dict]:
    """Platform bilgisini al (alias destekli)"""
    # Normalize platform name
    platform = platform.lower().strip()

    # Check aliases first
    if platform in PLATFORM_ALIASES:
        platform = PLATFORM_ALIASES[platform]

    return PLATFORM_REGISTRY.get(platform)


def get_platform_language(platform: str) -> str:
    """Platformun dilini al"""
    info = get_platform_info(platform)
    return info['language'] if info else 'de'  # Default: Almanca


def get_platform_country(platform: str) -> str:
    """Platformun ulkesini al"""
    info = get_platform_info(platform)
    return info['country'] if info else 'DE'  # Default: Almanya


def get_platforms_by_language(language: str) -> List[str]:
    """Belirli dildeki platformlari al"""
    return LANGUAGE_GROUPS.get(language, [])


def resolve_platform(platform_input: str) -> str:
    """Platform adini normalize et ve domain'e cevir"""
    platform = platform_input.lower().strip()

    # Remove common suffixes
    platform = platform.replace("'de", "").replace("'da", "").replace("'te", "")

    # Check aliases
    if platform in PLATFORM_ALIASES:
        return PLATFORM_ALIASES[platform]

    # Check direct registry
    if platform in PLATFORM_REGISTRY:
        return platform

    # Try with common TLDs
    for tld in ['.de', '.fr', '.co.uk', '.com', '.nl', '.at', '.se', '.no', '.dk', '.fi']:
        if platform + tld in PLATFORM_REGISTRY:
            return platform + tld

    return platform


def get_all_platforms() -> List[str]:
    """Tum platform domain'lerini al"""
    return list(PLATFORM_REGISTRY.keys())


def get_search_url(platform: str, query: str) -> str:
    """Platformun arama URL'sini olustur"""
    from urllib.parse import quote_plus

    info = get_platform_info(platform)
    if not info:
        return ""

    search_url = info.get('search_url', '')
    return search_url.format(query=quote_plus(query))


# =============================================================================
# DİL İSİMLERİ (UI için)
# =============================================================================

LANGUAGE_NAMES: Dict[str, Dict[str, str]] = {
    'de': {'native': 'Deutsch', 'english': 'German', 'turkish': 'Almanca'},
    'en': {'native': 'English', 'english': 'English', 'turkish': 'Ingilizce'},
    'fr': {'native': 'Francais', 'english': 'French', 'turkish': 'Fransizca'},
    'es': {'native': 'Espanol', 'english': 'Spanish', 'turkish': 'Ispanyolca'},
    'it': {'native': 'Italiano', 'english': 'Italian', 'turkish': 'Italyanca'},
    'nl': {'native': 'Nederlands', 'english': 'Dutch', 'turkish': 'Hollandaca'},
    'pl': {'native': 'Polski', 'english': 'Polish', 'turkish': 'Lehce'},
    'cs': {'native': 'Cestina', 'english': 'Czech', 'turkish': 'Cekce'},
    'sv': {'native': 'Svenska', 'english': 'Swedish', 'turkish': 'Isvecce'},
    'da': {'native': 'Dansk', 'english': 'Danish', 'turkish': 'Danca'},
    'no': {'native': 'Norsk', 'english': 'Norwegian', 'turkish': 'Norvecce'},
    'fi': {'native': 'Suomi', 'english': 'Finnish', 'turkish': 'Fince'},
}


# =============================================================================
# TEST
# =============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("TATANGA Platform Registry Test")
    print("=" * 60)

    # Test platform resolution
    test_inputs = [
        'ebay',
        'vinted.de',
        'vinted_fr',
        'tori',
        'kleinanzeigen',
        "ebay.de'de",
    ]

    for inp in test_inputs:
        resolved = resolve_platform(inp)
        info = get_platform_info(resolved)
        if info:
            print(f"\n{inp} -> {resolved}")
            print(f"  Ulke: {info['country']}")
            print(f"  Dil: {info['language']} ({LANGUAGE_NAMES.get(info['language'], {}).get('turkish', '?')})")
            print(f"  Para: {info['currency']}")

    print("\n" + "=" * 60)
    print(f"Toplam Platform: {len(PLATFORM_REGISTRY)}")
    print(f"Toplam Dil: {len(LANGUAGE_GROUPS)}")
    print("=" * 60)
