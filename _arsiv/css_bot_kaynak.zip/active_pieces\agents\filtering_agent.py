#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Filtering Agent
Profit/Risk scoring and automatic product filtering

Features:
- Profit margin calculation
- Risk assessment
- Rule-based filtering (auto-approve/reject)
- Arbitrage configuration support
- Event Bus integration

Decisions:
- auto_approve: High profit, clean condition -> Favorilere ekle
- auto_reject: Low profit, bad condition -> Atla
- needs_review: Potential profit, needs human check -> Gelen Kutusu
- risky: Conflict detected, needs careful review -> Riskli Kutusu

Author: TATANGA Team
Version: 2.0
"""

import sys
import asyncio
import sqlite3
import json
import re
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from core.event_bus import get_event_bus, emit, subscribe, on
except ImportError:
    def get_event_bus(): return None
    async def emit(*args, **kwargs): pass
    def subscribe(*args, **kwargs): pass
    def on(*args, **kwargs): return lambda f: f

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")
        def debug(self, msg, **kwargs):
            self.logger.debug(f"{msg} {kwargs}")


class FilteringAgent:
    """
    Filtering Agent - Profit/Risk Assessment

    Evaluates normalized products and makes filtering decisions:
    1. Calculates profit margin based on benchmark price
    2. Applies filtering rules (auto-approve, auto-reject)
    3. Detects risky products (conflicts, low confidence)
    4. Routes products to appropriate queues
    """

    # Decision types
    DECISIONS = {
        'auto_approve': 'Otomatik onaylandı - Favorilere eklendi',
        'auto_reject': 'Otomatik reddedildi - Atlandı',
        'needs_review': 'İnceleme gerekli - Gelen Kutusuna',
        'risky': 'Riskli ürün - Dikkatli inceleme gerekli'
    }

    def __init__(self, db_path: str = None):
        """
        Initialize Filtering Agent

        Args:
            db_path: Path to database
        """
        if db_path:
            self.db_path = Path(db_path)
        else:
            self.db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'

        self.logger = ModuleLogger("filtering_agent")
        self.event_bus = get_event_bus()

        # Statistics
        self.stats = {
            'products_filtered': 0,
            'auto_approved': 0,
            'auto_rejected': 0,
            'needs_review': 0,
            'risky': 0,
            'rules_applied': 0
        }

        # Cache for rules
        self._rules_cache = None
        self._rules_loaded_at = None

        # Register event handlers
        self._register_handlers()

        self.logger.info("Filtering Agent initialized")

    def _register_handlers(self):
        """Register event bus handlers"""
        if self.event_bus:
            subscribe('product_normalized', self._handle_normalized_product)

    async def _handle_normalized_product(self, event):
        """Handle product_normalized event"""
        product = event.data
        arbitrage_config = event.data.get('arbitrage_config', {})

        decision, reason, score_data = await self.filter(product, arbitrage_config)

        # Emit appropriate event based on decision
        result = {
            **product,
            'filter_decision': decision,
            'filter_reason': reason,
            **score_data
        }

        if decision == 'auto_approve':
            await emit('product_approved_auto', result, source='filtering_agent')
        elif decision == 'risky':
            await emit('product_needs_review', {**result, 'queue': 'risky'}, source='filtering_agent')
        elif decision == 'needs_review':
            await emit('product_needs_review', {**result, 'queue': 'inbox'}, source='filtering_agent')
        # auto_reject: no event emitted, product is silently dropped

        # Save score to database
        await self._save_product_score(product, decision, reason, score_data)

    async def filter(self, product: Dict, arbitrage_config: Dict = None) -> Tuple[str, str, Dict]:
        """
        Filter a normalized product

        Args:
            product: Normalized product data
            arbitrage_config: Arbitrage search configuration

        Returns:
            (decision, reason, score_data)
        """
        if arbitrage_config is None:
            arbitrage_config = self._get_default_config()

        score = product.get('normalized_score', 3)
        is_conflicting = product.get('is_conflicting', False)
        confidence = product.get('confidence', 0.5)
        price = product.get('price', 0)

        # Get config values
        min_score = arbitrage_config.get('min_condition_score', 3)
        max_score = arbitrage_config.get('max_condition_score', 5)
        benchmark_price = arbitrage_config.get('benchmark_price', 0)
        min_profit_margin = arbitrage_config.get('min_profit_margin', 0.30)
        max_price = arbitrage_config.get('max_price', float('inf'))
        min_price = arbitrage_config.get('min_price', 0)

        # Calculate profit
        profit_amount = 0
        profit_margin = 0

        if benchmark_price > 0:
            profit_amount = benchmark_price - price
            profit_margin = profit_amount / benchmark_price

        score_data = {
            'profit_amount': round(profit_amount, 2),
            'profit_margin': round(profit_margin, 4),
            'benchmark_price': benchmark_price
        }

        self.stats['products_filtered'] += 1

        # RULE 1: Score out of range -> Auto Reject
        if score < min_score:
            self.stats['auto_rejected'] += 1
            return 'auto_reject', f'Durum skoru çok düşük: {score}/{min_score}', score_data

        if score > max_score:
            self.stats['auto_rejected'] += 1
            return 'auto_reject', f'Durum skoru aralık dışı: {score}>{max_score}', score_data

        # RULE 2: Price out of range -> Auto Reject
        if price < min_price:
            self.stats['auto_rejected'] += 1
            return 'auto_reject', f'Fiyat çok düşük: {price}<{min_price}', score_data

        if price > max_price:
            self.stats['auto_rejected'] += 1
            return 'auto_reject', f'Fiyat çok yüksek: {price}>{max_price}', score_data

        # RULE 3: Conflict detected -> Risky
        if is_conflicting:
            self.stats['risky'] += 1
            return 'risky', f"Çatışma: {product.get('conflict_reason', 'Bilinmiyor')}", score_data

        # RULE 4: Low confidence -> Needs Review
        if confidence < 0.5:
            self.stats['needs_review'] += 1
            return 'needs_review', f'Düşük güven: {confidence:.0%}', score_data

        # RULE 5: Profit margin check
        if benchmark_price > 0:
            if profit_margin < 0:
                self.stats['auto_rejected'] += 1
                return 'auto_reject', f'Zarar: {profit_amount:.0f}€', score_data

            if profit_margin < min_profit_margin:
                if profit_margin < min_profit_margin * 0.5:
                    self.stats['auto_rejected'] += 1
                    return 'auto_reject', f'Çok düşük marj: %{profit_margin*100:.0f}', score_data
                else:
                    self.stats['needs_review'] += 1
                    return 'needs_review', f'Düşük marj: %{profit_margin*100:.0f}', score_data

        # RULE 6: Apply custom rules from database
        rule_decision = await self._apply_custom_rules(product, score_data)
        if rule_decision:
            decision, reason = rule_decision
            self.stats[decision.replace('-', '_')] = self.stats.get(decision.replace('-', '_'), 0) + 1
            self.stats['rules_applied'] += 1
            return decision, reason, score_data

        # RULE 7: High score + Good margin -> Auto Approve
        if score >= 4 and (benchmark_price == 0 or profit_margin >= min_profit_margin):
            self.stats['auto_approved'] += 1
            if profit_margin > 0:
                return 'auto_approve', f'İyi durum + Kâr: {profit_amount:.0f}€ (%{profit_margin*100:.0f})', score_data
            else:
                return 'auto_approve', f'İyi durum: {score}/5', score_data

        # DEFAULT: Needs Review
        self.stats['needs_review'] += 1
        return 'needs_review', f'Potansiyel kâr: {profit_amount:.0f}€', score_data

    def _get_default_config(self) -> Dict:
        """Get default arbitrage configuration"""
        return {
            'min_condition_score': 3,
            'max_condition_score': 5,
            'benchmark_price': 0,  # 0 = no benchmark
            'min_profit_margin': 0.30,
            'max_price': 500,
            'min_price': 5
        }

    async def _apply_custom_rules(self, product: Dict, score_data: Dict) -> Optional[Tuple[str, str]]:
        """
        Apply custom filtering rules from database

        Returns:
            (decision, reason) or None if no rule matches
        """
        rules = self._get_rules()

        for rule in rules:
            if not rule['is_active']:
                continue

            if self._evaluate_rule(rule, product, score_data):
                # Update hit count
                self._update_rule_hit(rule['id'])

                action = rule['action']
                if action == 'reject':
                    return 'auto_reject', f"Kural: {rule['name']}"
                elif action == 'approve':
                    return 'auto_approve', f"Kural: {rule['name']}"
                elif action == 'review':
                    return 'needs_review', f"Kural: {rule['name']}"

        return None

    def _get_rules(self) -> List[Dict]:
        """Get filtering rules from database with caching"""
        # Cache for 5 minutes
        if self._rules_cache and self._rules_loaded_at:
            elapsed = (datetime.now() - self._rules_loaded_at).seconds
            if elapsed < 300:
                return self._rules_cache

        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                SELECT id, name, rule_type, condition_field, condition_operator,
                       condition_value, action, priority, is_active
                FROM filtering_rules
                ORDER BY priority DESC
            """)

            rows = cursor.fetchall()
            conn.close()

            self._rules_cache = [
                {
                    'id': row[0],
                    'name': row[1],
                    'rule_type': row[2],
                    'field': row[3],
                    'operator': row[4],
                    'value': row[5],
                    'action': row[6],
                    'priority': row[7],
                    'is_active': bool(row[8])
                }
                for row in rows
            ]
            self._rules_loaded_at = datetime.now()

            return self._rules_cache

        except Exception as e:
            self.logger.error("Failed to load rules", exception=str(e))
            return []

    def _evaluate_rule(self, rule: Dict, product: Dict, score_data: Dict) -> bool:
        """Evaluate if a rule matches the product"""
        field = rule['field']
        operator = rule['operator']
        value = rule['value']

        # Get field value from product or score_data
        if field in product:
            actual_value = product[field]
        elif field in score_data:
            actual_value = score_data[field]
        else:
            return False

        try:
            # Numeric comparisons
            if operator in ['<', '>', '<=', '>=', '=', '!=']:
                actual_num = float(actual_value) if actual_value else 0
                target_num = float(value)

                if operator == '<':
                    return actual_num < target_num
                elif operator == '>':
                    return actual_num > target_num
                elif operator == '<=':
                    return actual_num <= target_num
                elif operator == '>=':
                    return actual_num >= target_num
                elif operator == '=':
                    return actual_num == target_num
                elif operator == '!=':
                    return actual_num != target_num

            # String operations
            elif operator == 'contains':
                keywords = [kw.strip().lower() for kw in value.split(',')]
                actual_str = str(actual_value).lower()
                return any(kw in actual_str for kw in keywords)

            elif operator == 'not_contains':
                keywords = [kw.strip().lower() for kw in value.split(',')]
                actual_str = str(actual_value).lower()
                return not any(kw in actual_str for kw in keywords)

            elif operator == 'in':
                values = [v.strip().lower() for v in value.split(',')]
                return str(actual_value).lower() in values

            elif operator == 'not_in':
                values = [v.strip().lower() for v in value.split(',')]
                return str(actual_value).lower() not in values

            elif operator == 'matches':
                return bool(re.match(value, str(actual_value), re.IGNORECASE))

        except (ValueError, TypeError) as e:
            self.logger.warning(f"Rule evaluation error: {e}")

        return False

    def _update_rule_hit(self, rule_id: int):
        """Update rule hit count"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                UPDATE filtering_rules
                SET hit_count = hit_count + 1, last_hit = ?
                WHERE id = ?
            """, (datetime.now(), rule_id))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error("Failed to update rule hit", exception=str(e))

    async def _save_product_score(self, product: Dict, decision: str, reason: str, score_data: Dict):
        """Save product score to database"""
        try:
            product_id = product.get('id')
            if not product_id:
                return

            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO product_scores
                (product_id, normalized_score, confidence, is_conflicting, conflict_reason,
                 profit_amount, profit_margin, benchmark_price, filter_decision, filter_reason,
                 is_approved, is_rejected, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(product_id) DO UPDATE SET
                    normalized_score = ?,
                    confidence = ?,
                    is_conflicting = ?,
                    conflict_reason = ?,
                    profit_amount = ?,
                    profit_margin = ?,
                    benchmark_price = ?,
                    filter_decision = ?,
                    filter_reason = ?,
                    is_approved = ?,
                    is_rejected = ?,
                    updated_at = ?
            """, (
                product_id,
                product.get('normalized_score'),
                product.get('confidence'),
                product.get('is_conflicting', False),
                product.get('conflict_reason'),
                score_data.get('profit_amount'),
                score_data.get('profit_margin'),
                score_data.get('benchmark_price'),
                decision,
                reason,
                decision == 'auto_approve',
                decision == 'auto_reject',
                datetime.now(),
                # For update
                product.get('normalized_score'),
                product.get('confidence'),
                product.get('is_conflicting', False),
                product.get('conflict_reason'),
                score_data.get('profit_amount'),
                score_data.get('profit_margin'),
                score_data.get('benchmark_price'),
                decision,
                reason,
                decision == 'auto_approve',
                decision == 'auto_reject',
                datetime.now()
            ))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error("Failed to save product score", exception=str(e))

    async def add_rule(self, name: str, rule_type: str, field: str, operator: str,
                       value: str, action: str, priority: int = 0) -> bool:
        """Add a new filtering rule"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO filtering_rules
                (name, rule_type, condition_field, condition_operator, condition_value, action, priority)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (name, rule_type, field, operator, value, action, priority))

            conn.commit()
            conn.close()

            # Clear cache
            self._rules_cache = None

            self.logger.info(f"Added rule: {name}")
            return True

        except Exception as e:
            self.logger.error("Failed to add rule", exception=str(e))
            return False

    def get_stats(self) -> Dict:
        """Get agent statistics"""
        return {
            **self.stats,
            'rules_count': len(self._get_rules())
        }


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("FILTERING AGENT TEST")
    print("=" * 60)

    async def test():
        agent = FilteringAgent()

        # Arbitrage config for Levi's 501
        config = {
            'min_condition_score': 3,
            'max_condition_score': 5,
            'benchmark_price': 90,  # Reference selling price
            'min_profit_margin': 0.40,  # 40% minimum
            'max_price': 100,
            'min_price': 10
        }

        # Test products (already normalized)
        test_products = [
            {
                'id': 1,
                'title': 'Levi\'s 501 Jeans - Perfect',
                'normalized_score': 5,
                'is_conflicting': False,
                'confidence': 1.0,
                'price': 35.0  # Profit: 55€ (61%)
            },
            {
                'id': 2,
                'title': 'Levi\'s 501 Jeans - Good',
                'normalized_score': 4,
                'is_conflicting': False,
                'confidence': 0.9,
                'price': 45.0  # Profit: 45€ (50%)
            },
            {
                'id': 3,
                'title': 'Levi\'s 501 Jeans - Risky',
                'normalized_score': 4,
                'is_conflicting': True,
                'conflict_reason': 'Description mentions "riss"',
                'confidence': 0.5,
                'price': 30.0  # Good price but conflict
            },
            {
                'id': 4,
                'title': 'Levi\'s 501 Jeans - Low Margin',
                'normalized_score': 4,
                'is_conflicting': False,
                'confidence': 0.8,
                'price': 70.0  # Profit: 20€ (22%) - below 40%
            },
            {
                'id': 5,
                'title': 'Levi\'s 501 Jeans - Bad Condition',
                'normalized_score': 2,
                'is_conflicting': False,
                'confidence': 0.9,
                'price': 25.0  # Good price but bad condition
            },
            {
                'id': 6,
                'title': 'Levi\'s 501 Jeans - Overpriced',
                'normalized_score': 5,
                'is_conflicting': False,
                'confidence': 1.0,
                'price': 95.0  # Loss: -5€
            }
        ]

        print(f"\nArbitrage Config:")
        print(f"  Benchmark Price: {config['benchmark_price']}€")
        print(f"  Min Profit Margin: {config['min_profit_margin']*100:.0f}%")
        print(f"  Condition Range: {config['min_condition_score']}-{config['max_condition_score']}")

        print("\nFiltering products:")
        print("-" * 60)

        for product in test_products:
            decision, reason, score_data = await agent.filter(product, config)

            print(f"\n{product['title']}")
            print(f"  Price: {product['price']}€ | Score: {product['normalized_score']}/5")
            print(f"  Profit: {score_data['profit_amount']:.0f}€ ({score_data['profit_margin']*100:.0f}%)")
            print(f"  Decision: {decision.upper()}")
            print(f"  Reason: {reason}")

        print(f"\n" + "-" * 60)
        print(f"Stats: {agent.get_stats()}")
        print("\n" + "=" * 60)
        print("FILTERING AGENT TEST COMPLETE")
        print("=" * 60)

    asyncio.run(test())
