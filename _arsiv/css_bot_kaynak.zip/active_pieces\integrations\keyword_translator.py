#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
KEYWORD TRANSLATOR - Pre-Search Translation System
Translates search keywords before platform searches

Features:
- Auto-detect source language (TR/EN/DE/etc)
- Translate to target platform's native language
- Batch translation for multiple platforms
- SQLite caching for performance
- Groq AI for quality translations
- Brand name preservation

Author: TATANGA Team
Version: 1.0
"""

import sys
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from integrations.smart_translator import SmartTranslator

# Platform groups for batch translation
PLATFORM_GROUPS = {
    'all': [
        'vinted_de', 'vinted_fr', 'vinted_uk', 'vinted_es', 'vinted_it',
        'vinted_nl', 'vinted_be', 'vinted_at', 'vinted_pl', 'vinted_cz',
        'vinted_se', 'vinted_dk', 'vinted_no',
        'ebay_de', 'ebay_uk',
        'kleinanzeigen', 'willhaben', 'tradera',
        'shpock_de', 'shpock_uk', 'shpock_at',
        'leboncoin',
        'finn_no', 'blocket_se', 'tori_fi', 'dba_dk'
    ],
    'vinted': [
        'vinted_de', 'vinted_fr', 'vinted_uk', 'vinted_es', 'vinted_it',
        'vinted_nl', 'vinted_be', 'vinted_at', 'vinted_pl', 'vinted_cz',
        'vinted_se', 'vinted_dk', 'vinted_no'
    ],
    'german': ['vinted_de', 'ebay_de', 'kleinanzeigen', 'willhaben', 'shpock_de', 'shpock_at'],
    'nordic': ['vinted_se', 'vinted_dk', 'vinted_no', 'tradera', 'finn_no', 'blocket_se', 'tori_fi', 'dba_dk'],
    'french': ['vinted_fr', 'leboncoin'],
    'english': ['vinted_uk', 'ebay_uk', 'shpock_uk'],
}


class KeywordTranslator:
    """
    Pre-search keyword translation system

    Automatically translates search keywords to each platform's
    native language before performing searches.

    Usage:
        translator = KeywordTranslator()

        # Single keyword, multiple platforms
        results = translator.translate("deri ceket", platforms=['vinted_de', 'vinted_fr'])
        # {'vinted_de': 'Lederjacke', 'vinted_fr': 'veste en cuir'}

        # Use platform groups
        results = translator.translate("ayakkabı", group='german')
        # {'vinted_de': 'Schuhe', 'ebay_de': 'Schuhe', 'kleinanzeigen': 'Schuhe', ...}

        # Multiple keywords
        results = translator.translate_batch(
            ["deri ceket", "spor ayakkabı"],
            platforms=['vinted_de', 'vinted_fr']
        )
    """

    def __init__(self, groq_api_key: str = None):
        """
        Initialize Keyword Translator

        Args:
            groq_api_key: Optional Groq API key (uses config if not provided)
        """
        self.translator = SmartTranslator(groq_api_key)
        self.platform_groups = PLATFORM_GROUPS

        # Translation history for debugging
        self.history = []

    def translate(
        self,
        keyword: str,
        platforms: List[str] = None,
        group: str = None
    ) -> Dict[str, str]:
        """
        Translate keyword for specified platforms

        Args:
            keyword: Search keyword in any language
            platforms: List of target platforms (optional)
            group: Platform group name (optional)

        Returns:
            Dictionary mapping platform to translated keyword

        Examples:
            # With platform list
            >>> translate("Nike ayakkabı", platforms=['vinted_de', 'vinted_fr'])
            {'vinted_de': 'Nike Schuhe', 'vinted_fr': 'Nike chaussures'}

            # With group
            >>> translate("deri ceket", group='german')
            {'vinted_de': 'Lederjacke', 'ebay_de': 'Lederjacke', ...}
        """
        # Determine target platforms
        if group and group in self.platform_groups:
            target_platforms = self.platform_groups[group]
        elif platforms:
            target_platforms = platforms
        else:
            # Default: all platforms
            target_platforms = self.platform_groups['all']

        # Detect source language
        source_lang = self.translator.detect_language(keyword)

        # Translate for each platform
        results = self.translator.translate_keyword_smart(keyword, target_platforms)

        # Log to history
        self.history.append({
            'timestamp': datetime.now().isoformat(),
            'keyword': keyword,
            'source_lang': source_lang,
            'platforms': list(results.keys()),
            'translations': results
        })

        return results

    def translate_batch(
        self,
        keywords: List[str],
        platforms: List[str] = None,
        group: str = None
    ) -> Dict[str, Dict[str, str]]:
        """
        Translate multiple keywords for specified platforms

        Args:
            keywords: List of search keywords
            platforms: List of target platforms (optional)
            group: Platform group name (optional)

        Returns:
            Dictionary mapping each keyword to its translations
            {
                'deri ceket': {'vinted_de': 'Lederjacke', 'vinted_fr': 'veste en cuir'},
                'spor ayakkabı': {'vinted_de': 'Sportschuhe', 'vinted_fr': 'chaussures de sport'}
            }
        """
        results = {}
        for keyword in keywords:
            results[keyword] = self.translate(keyword, platforms, group)
        return results

    def get_group_platforms(self, group: str) -> List[str]:
        """Get list of platforms in a group"""
        return self.platform_groups.get(group, [])

    def get_available_groups(self) -> List[str]:
        """Get list of available platform groups"""
        return list(self.platform_groups.keys())

    def get_stats(self) -> Dict:
        """Get translation statistics"""
        translator_stats = self.translator.get_stats()
        return {
            **translator_stats,
            'history_count': len(self.history),
            'available_groups': self.get_available_groups()
        }

    def get_history(self, limit: int = 10) -> List[Dict]:
        """Get recent translation history"""
        return self.history[-limit:]

    def clear_history(self):
        """Clear translation history"""
        self.history = []


class PreSearchTranslator:
    """
    Wrapper for easy pre-search translation integration

    Usage in scraper:
        pre_translator = PreSearchTranslator()

        # Before search
        search_query = "deri ceket"
        platform = "vinted_de"
        translated = pre_translator.for_platform(search_query, platform)
        # Now search with 'translated' instead of original query
    """

    def __init__(self):
        self.translator = KeywordTranslator()

    def for_platform(self, keyword: str, platform: str) -> str:
        """
        Translate keyword for a single platform

        Args:
            keyword: Search keyword
            platform: Target platform

        Returns:
            Translated keyword for that platform
        """
        results = self.translator.translate(keyword, platforms=[platform])
        return results.get(platform, keyword)

    def for_platforms(self, keyword: str, platforms: List[str]) -> Dict[str, str]:
        """
        Translate keyword for multiple platforms

        Args:
            keyword: Search keyword
            platforms: List of target platforms

        Returns:
            Dictionary mapping platform to translated keyword
        """
        return self.translator.translate(keyword, platforms=platforms)

    def for_group(self, keyword: str, group: str) -> Dict[str, str]:
        """
        Translate keyword for a platform group

        Args:
            keyword: Search keyword
            group: Platform group name

        Returns:
            Dictionary mapping platform to translated keyword
        """
        return self.translator.translate(keyword, group=group)


# Test / Example usage
if __name__ == "__main__":
    print("=" * 60)
    print("KEYWORD TRANSLATOR - TEST")
    print("=" * 60)
    print()

    # Initialize
    translator = KeywordTranslator()

    if not translator.translator.groq:
        print("ERROR: Groq API not initialized!")
        print("Please set your Groq API key in config/credentials.py")
        sys.exit(1)

    print("✓ Translator initialized")
    print()

    # Test 1: Turkish keyword → German platforms
    print("TEST 1: Turkish → German platforms")
    print("-" * 40)
    keyword_tr = "deri ceket"
    print(f"Original (TR): {keyword_tr}")

    results = translator.translate(keyword_tr, group='german')
    for platform, translated in results.items():
        print(f"  {platform}: {translated}")
    print()

    # Test 2: Turkish keyword → All Vinted countries
    print("TEST 2: Turkish → Vinted (all countries)")
    print("-" * 40)
    keyword_tr2 = "spor ayakkabı"
    print(f"Original (TR): {keyword_tr2}")

    results = translator.translate(keyword_tr2, group='vinted')
    for platform, translated in list(results.items())[:5]:  # Show first 5
        print(f"  {platform}: {translated}")
    print(f"  ... and {len(results) - 5} more platforms")
    print()

    # Test 3: English keyword → Nordic platforms
    print("TEST 3: English → Nordic platforms")
    print("-" * 40)
    keyword_en = "leather jacket"
    print(f"Original (EN): {keyword_en}")

    results = translator.translate(keyword_en, group='nordic')
    for platform, translated in results.items():
        print(f"  {platform}: {translated}")
    print()

    # Test 4: PreSearchTranslator usage
    print("TEST 4: PreSearchTranslator (single platform)")
    print("-" * 40)
    pre = PreSearchTranslator()
    keyword = "kırmızı elbise"
    print(f"Original: {keyword}")
    print(f"For vinted_fr: {pre.for_platform(keyword, 'vinted_fr')}")
    print(f"For vinted_de: {pre.for_platform(keyword, 'vinted_de')}")
    print(f"For ebay_uk: {pre.for_platform(keyword, 'ebay_uk')}")
    print()

    # Stats
    print("TRANSLATION STATS:")
    print("-" * 40)
    stats = translator.get_stats()
    for key, value in stats.items():
        print(f"{key}: {value}")
    print()

    print("=" * 60)
    print("✓ All tests completed!")
    print("=" * 60)
