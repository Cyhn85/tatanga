#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Telegram Bot
Remote control interface for the CEO Agent system

Features:
- Command interface for system control
- Real-time notifications
- Status reporting
- Scraping control
- Report generation

Commands:
    /start - Bot başlat
    /status - Sistem durumu
    /health - Sağlık kontrolü
    /scrape <platform> <query> - Kazıma başlat
    /stop - Tüm operasyonları durdur
    /platforms - Platform listesi
    /favorites - Favori ürünler
    /report <daily|weekly|monthly> - Rapor al
    /sales - Satış raporu
    /messages - Okunmamış mesajlar
    /track <tracking_number> - Kargo takibi
    /arbitraj - Arbitraj araması başlat
    /benchmark <query> - Referans fiyat öğren
    /inbox - Gelen kutusu (onay bekleyenler)
    /risky - Riskli ürünler
    /approve <id> - Ürünü onayla
    /reject <id> - Ürünü reddet
    /help - Yardım

Author: TATANGA Team
Version: 1.0
"""

import sys
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path
import os

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")

try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import (
        Application, CommandHandler, MessageHandler, CallbackQueryHandler,
        ContextTypes, filters
    )
    TELEGRAM_AVAILABLE = True
except ImportError:
    TELEGRAM_AVAILABLE = False
    Update = None
    ContextTypes = None


class TelegramBot:
    """
    Telegram Bot for TATANGA Enterprise remote control

    Provides:
    - Command interface for system management
    - Real-time notifications
    - Interactive keyboards
    - Report delivery
    """

    HELP_TEXT = """
🤖 *TATANGA Enterprise Bot*

*Sistem Komutları:*
/status - Sistem durumu
/health - Sağlık kontrolü
/start - Bot'u başlat
/stop - Tüm operasyonları durdur
/restart - Sistemi yeniden başlat

*Kazıma Komutları:*
/scrape <platform> <sorgu> - Kazıma başlat
/scrape\\_all <sorgu> - Tüm platformlarda ara
/scrape\\_status - Kazıma durumu
/platforms - Platform listesi

*Arbitraj & Filtreleme:*
/arbitraj - Arbitraj araması başlat
/benchmark <sorgu> - Referans fiyat öğren
/inbox - Gelen kutusu (onay bekleyenler)
/risky - Riskli ürünler
/approve <id> - Ürünü onayla
/reject <id> - Ürünü reddet

*Favori & Satış:*
/favorites - Favori ürünler
/favorites\\_check - Favori durumlarını kontrol et
/sales - Satış raporu

*İletişim:*
/messages - Okunmamış mesajlar
/urgent - Acil bildirimler

*Kargo & Muhasebe:*
/track <takip\\_no> - Kargo takibi
/shipments - Aktif kargolar
/invoices - Fatura listesi

*Raporlar:*
/report daily - Günlük rapor
/report weekly - Haftalık rapor
/report monthly - Aylık rapor

/help - Bu yardım mesajı
"""

    def __init__(self,
                 token: str,
                 admin_chat_id: str,
                 ceo_agent=None):
        """
        Initialize Telegram Bot

        Args:
            token: Telegram bot token
            admin_chat_id: Admin chat ID for notifications
            ceo_agent: Reference to CEO Agent
        """
        self.token = token
        self.admin_chat_id = admin_chat_id
        self.ceo = ceo_agent
        self.logger = ModuleLogger("telegram_bot")

        self.app = None
        self.running = False

        # Authorized users (can add more)
        self.authorized_users = set()
        if admin_chat_id:
            self.authorized_users.add(admin_chat_id)

        # Command handlers registry
        self.command_handlers: Dict[str, Callable] = {}

        self.logger.info("Telegram Bot initialized")

    async def start(self):
        """Start the Telegram bot"""
        if not TELEGRAM_AVAILABLE:
            self.logger.warning("python-telegram-bot not installed")
            return

        if not self.token:
            self.logger.warning("Telegram token not provided")
            return

        try:
            # Build application
            self.app = Application.builder().token(self.token).build()

            # Register handlers
            self._register_handlers()

            # Start polling
            await self.app.initialize()
            await self.app.start()
            await self.app.updater.start_polling()

            self.running = True
            self.logger.info("Telegram bot started")

            # Send startup notification
            await self.send_message(
                self.admin_chat_id,
                "🤖 *TATANGA Bot Aktif*\n\nSistem başarıyla başlatıldı.\n/help komutunu kullanın."
            )

        except Exception as e:
            self.logger.error("Failed to start Telegram bot", exception=str(e))

    async def stop(self):
        """Stop the Telegram bot"""
        if self.app and self.running:
            await self.app.updater.stop()
            await self.app.stop()
            await self.app.shutdown()
            self.running = False
            self.logger.info("Telegram bot stopped")

    def _register_handlers(self):
        """Register command handlers"""
        if not self.app:
            return

        # System commands
        self.app.add_handler(CommandHandler("start", self._cmd_start))
        self.app.add_handler(CommandHandler("help", self._cmd_help))
        self.app.add_handler(CommandHandler("status", self._cmd_status))
        self.app.add_handler(CommandHandler("health", self._cmd_health))
        self.app.add_handler(CommandHandler("stop", self._cmd_stop))

        # Scraping commands
        self.app.add_handler(CommandHandler("scrape", self._cmd_scrape))
        self.app.add_handler(CommandHandler("scrape_all", self._cmd_scrape_all))
        self.app.add_handler(CommandHandler("scrape_status", self._cmd_scrape_status))
        self.app.add_handler(CommandHandler("platforms", self._cmd_platforms))

        # Arbitraj & Filtering
        self.app.add_handler(CommandHandler("arbitraj", self._cmd_arbitraj))
        self.app.add_handler(CommandHandler("benchmark", self._cmd_benchmark))
        self.app.add_handler(CommandHandler("inbox", self._cmd_inbox))
        self.app.add_handler(CommandHandler("risky", self._cmd_risky))
        self.app.add_handler(CommandHandler("approve", self._cmd_approve))
        self.app.add_handler(CommandHandler("reject", self._cmd_reject))

        # Favorites & Sales
        self.app.add_handler(CommandHandler("favorites", self._cmd_favorites))
        self.app.add_handler(CommandHandler("favorites_check", self._cmd_favorites_check))
        self.app.add_handler(CommandHandler("sales", self._cmd_sales))

        # Communication
        self.app.add_handler(CommandHandler("messages", self._cmd_messages))
        self.app.add_handler(CommandHandler("urgent", self._cmd_urgent))

        # Logistics
        self.app.add_handler(CommandHandler("track", self._cmd_track))
        self.app.add_handler(CommandHandler("shipments", self._cmd_shipments))
        self.app.add_handler(CommandHandler("invoices", self._cmd_invoices))

        # Reports
        self.app.add_handler(CommandHandler("report", self._cmd_report))

        # Callback query handler (for inline keyboards)
        self.app.add_handler(CallbackQueryHandler(self._handle_callback))

        # Error handler
        self.app.add_error_handler(self._error_handler)

    def _is_authorized(self, user_id: str) -> bool:
        """Check if user is authorized"""
        return str(user_id) in self.authorized_users or not self.authorized_users

    # ==================== COMMAND HANDLERS ====================

    async def _cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        user_id = str(update.effective_user.id)

        if not self._is_authorized(user_id):
            await update.message.reply_text("⛔ Yetkisiz erişim.")
            return

        await update.message.reply_text(
            "🤖 *TATANGA Enterprise Bot'a Hoşgeldiniz!*\n\n"
            "36 platformda paralel kazıma, satış ve lojistik yönetimi.\n\n"
            "/help komutunu kullanarak tüm komutları görebilirsiniz.",
            parse_mode='Markdown'
        )

    async def _cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        await update.message.reply_text(self.HELP_TEXT, parse_mode='Markdown')

    async def _cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /status command"""
        if not self._is_authorized(str(update.effective_user.id)):
            await update.message.reply_text("⛔ Yetkisiz erişim.")
            return

        if self.ceo:
            status = self.ceo.get_system_status()

            message = (
                f"🤖 *TATANGA Sistem Durumu*\n\n"
                f"*Durum:* {status.get('status', 'unknown')}\n"
                f"*Uptime:* {status.get('uptime_hours', 0):.1f} saat\n"
                f"*Platform Sayısı:* {status.get('platforms_count', 0)}\n"
                f"*İşlem Kuyruğu:* {status.get('operation_queue_size', 0)}\n"
                f"*Telegram:* {'✅' if status.get('telegram_connected') else '❌'}\n"
                f"*Self-Healing:* {'✅' if status.get('healing_enabled') else '❌'}\n\n"
                f"*Metrikler:*\n"
                f"• Toplam Kazıma: {status.get('metrics', {}).get('total_scrapes', 0)}\n"
                f"• Bulunan Ürün: {status.get('metrics', {}).get('products_found', 0)}\n"
                f"• Başarı Oranı: {status.get('metrics', {}).get('success_rate', 0)}%"
            )
        else:
            message = "❌ CEO Agent bağlantısı yok"

        await update.message.reply_text(message, parse_mode='Markdown')

    async def _cmd_health(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /health command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        if self.ceo:
            health = await self.ceo._health_check()

            lines = ["🏥 *Sistem Sağlığı*\n"]
            lines.append(f"CEO: {health.get('ceo', 'unknown')}")
            lines.append(f"Telegram: {health.get('telegram', 'unknown')}")

            lines.append("\n*Manager'lar:*")
            for name, status in health.get('managers', {}).items():
                emoji = '✅' if status == 'healthy' else '❌'
                lines.append(f"  {emoji} {name}: {status}")

            message = '\n'.join(lines)
        else:
            message = "❌ CEO Agent bağlantısı yok"

        await update.message.reply_text(message, parse_mode='Markdown')

    async def _cmd_stop(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /stop command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        if self.ceo:
            await self.ceo.stop_scraping('all')
            await update.message.reply_text("⏹️ Tüm operasyonlar durduruldu.")
        else:
            await update.message.reply_text("❌ CEO Agent bağlantısı yok")

    async def _cmd_scrape(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /scrape command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        args = context.args
        if len(args) < 2:
            await update.message.reply_text(
                "Kullanım: /scrape <platform> <sorgu>\n"
                "Örnek: /scrape vinted_de nike shoes"
            )
            return

        platform = args[0]
        query = ' '.join(args[1:])

        if self.ceo:
            await update.message.reply_text(f"🔍 Kazıma başlatılıyor: {platform}...")

            result = await self.ceo.start_scraping(platform, query, limit=50)

            if result.get('success'):
                await update.message.reply_text(
                    f"✅ Kazıma başlatıldı\n"
                    f"Platform: {platform}\n"
                    f"Sorgu: {query}\n"
                    f"Kuyrukta: {result.get('queued', 0)} operasyon"
                )
            else:
                await update.message.reply_text(f"❌ Hata: {result.get('error')}")

    async def _cmd_scrape_all(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /scrape_all command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        query = ' '.join(context.args) if context.args else None

        if not query:
            await update.message.reply_text("Kullanım: /scrape_all <sorgu>")
            return

        if self.ceo:
            await update.message.reply_text(f"🔍 36 platformda kazıma başlatılıyor: {query}...")

            result = await self.ceo.start_scraping('all', query, limit=30)

            if result.get('success'):
                await update.message.reply_text(
                    f"✅ Tüm platformlarda kazıma başlatıldı\n"
                    f"Sorgu: {query}\n"
                    f"Platform Sayısı: {len(result.get('platforms', []))}"
                )
            else:
                await update.message.reply_text(f"❌ Hata: {result.get('error')}")

    async def _cmd_scrape_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /scrape_status command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        # Would get status from ScrapingManager
        await update.message.reply_text("📊 Kazıma durumu kontrolü yakında eklenecek.")

    # ==================== ARBITRAJ COMMANDS ====================

    async def _cmd_arbitraj(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /arbitraj command - Start arbitrage search"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        # Interactive mode if no args
        if not context.args:
            keyboard = [
                [InlineKeyboardButton("📝 Yeni Arbitraj", callback_data="arbitraj_new")],
                [InlineKeyboardButton("📋 Kayıtlı Aramalar", callback_data="arbitraj_list")],
                [InlineKeyboardButton("📊 İstatistikler", callback_data="arbitraj_stats")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)

            await update.message.reply_text(
                "🔍 *Arbitraj Araması*\n\n"
                "Bir seçenek belirleyin veya doğrudan arama yapın:\n\n"
                "`/arbitraj <ürün> <referans_fiyat> <min_skor> <min_marj>`\n\n"
                "Örnek:\n"
                "`/arbitraj \"Levi's 501\" 90 3 40`\n"
                "_(90€ referans, 3+ skor, %40 min kâr)_",
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
            return

        # Parse arguments
        try:
            query = context.args[0]
            benchmark_price = float(context.args[1]) if len(context.args) > 1 else 0
            min_score = int(context.args[2]) if len(context.args) > 2 else 3
            min_margin = float(context.args[3]) / 100 if len(context.args) > 3 else 0.30

            # Create arbitrage config
            config = {
                'query': query,
                'benchmark_price': benchmark_price,
                'min_condition_score': min_score,
                'max_condition_score': 5,
                'min_profit_margin': min_margin,
                'platforms': ['vinted_de', 'vinted_uk', 'vinted_fr', 'ebay_de', 'ebay_uk']
            }

            await update.message.reply_text(
                f"🚀 *Arbitraj Araması Başlatıldı*\n\n"
                f"*Ürün:* {query}\n"
                f"*Referans Fiyat:* {benchmark_price}€\n"
                f"*Min Skor:* {min_score}/5\n"
                f"*Min Kâr Marjı:* %{min_margin*100:.0f}\n"
                f"*Max Alış Fiyatı:* {benchmark_price * (1 - min_margin):.0f}€\n\n"
                f"_Sonuçlar /inbox ve /risky komutlarında görünecek._",
                parse_mode='Markdown'
            )

            # Emit event to start arbitrage search
            try:
                from core.event_bus import emit
                await emit('scrape_requested', {
                    'query': query,
                    'arbitrage_config': config,
                    'source': 'telegram'
                }, source='telegram_bot')
            except ImportError:
                pass

        except (ValueError, IndexError) as e:
            await update.message.reply_text(
                "❌ Hatalı format.\n\n"
                "Kullanım: `/arbitraj <ürün> <referans_fiyat> <min_skor> <min_marj>`\n"
                "Örnek: `/arbitraj \"Levi's 501\" 90 3 40`",
                parse_mode='Markdown'
            )

    async def _cmd_benchmark(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /benchmark command - Get reference prices"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        if not context.args:
            await update.message.reply_text(
                "Kullanım: `/benchmark <ürün_adı>`\n"
                "Örnek: `/benchmark Nike Air Force 1`",
                parse_mode='Markdown'
            )
            return

        query = ' '.join(context.args)

        await update.message.reply_text(f"🔍 Referans fiyat araştırılıyor: {query}...")

        try:
            from agents.benchmark_service import BenchmarkService
            service = BenchmarkService()

            # Try to get existing benchmark
            benchmark = await service.get_benchmark(query)

            if benchmark and benchmark.get('avg_price', 0) > 0:
                await update.message.reply_text(
                    f"📊 *Benchmark: {query}*\n\n"
                    f"*Ortalama Fiyat:* {benchmark['avg_price']}€\n"
                    f"*Fiyat Aralığı:* {benchmark['min_price']}€ - {benchmark['max_price']}€\n"
                    f"*Örnek Sayısı:* {benchmark['sample_count']}\n"
                    f"*Güncelleme:* {benchmark.get('last_updated', 'N/A')}\n\n"
                    f"*Önerilen Alış Fiyatları:*\n"
                    f"  • %30 kâr: max {benchmark['avg_price'] * 0.70:.0f}€\n"
                    f"  • %40 kâr: max {benchmark['avg_price'] * 0.60:.0f}€\n"
                    f"  • %50 kâr: max {benchmark['avg_price'] * 0.50:.0f}€",
                    parse_mode='Markdown'
                )
            else:
                await update.message.reply_text(
                    f"⚠️ *{query}* için benchmark verisi bulunamadı.\n\n"
                    f"Satılmış ürünler kazınarak referans fiyat oluşturulabilir.\n"
                    f"_Bu özellik yakında eklenecek._",
                    parse_mode='Markdown'
                )

        except ImportError:
            await update.message.reply_text("❌ BenchmarkService yüklenemedi.")
        except Exception as e:
            await update.message.reply_text(f"❌ Hata: {str(e)}")

    async def _cmd_inbox(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /inbox command - Show products needing review"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        try:
            import sqlite3
            db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()

            cursor.execute("""
                SELECT ps.id, p.title, p.platform, p.price, ps.normalized_score,
                       ps.profit_amount, ps.profit_margin, ps.filter_reason
                FROM product_scores ps
                JOIN products p ON ps.product_id = p.id
                WHERE ps.filter_decision = 'needs_review'
                AND ps.is_approved = 0 AND ps.is_rejected = 0
                ORDER BY ps.profit_margin DESC
                LIMIT 10
            """)

            rows = cursor.fetchall()
            conn.close()

            if not rows:
                await update.message.reply_text("📥 Gelen kutusu boş - onay bekleyen ürün yok.")
                return

            lines = ["📥 *Gelen Kutusu (İnceleme Bekleyen)*\n"]

            for row in rows:
                score_id, title, platform, price, score, profit, margin, reason = row
                lines.append(
                    f"*{title[:30]}...*\n"
                    f"  📍 {platform} | 💰 {price}€ | ⭐ {score}/5\n"
                    f"  💵 Kâr: {profit:.0f}€ ({margin*100:.0f}%)\n"
                    f"  📝 {reason}\n"
                    f"  `/approve {score_id}` | `/reject {score_id}`\n"
                )

            await update.message.reply_text('\n'.join(lines), parse_mode='Markdown')

        except Exception as e:
            await update.message.reply_text(f"❌ Hata: {str(e)}")

    async def _cmd_risky(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /risky command - Show risky products"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        try:
            import sqlite3
            db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()

            cursor.execute("""
                SELECT ps.id, p.title, p.platform, p.price, ps.normalized_score,
                       ps.conflict_reason, ps.profit_amount
                FROM product_scores ps
                JOIN products p ON ps.product_id = p.id
                WHERE ps.filter_decision = 'risky'
                AND ps.is_approved = 0 AND ps.is_rejected = 0
                ORDER BY ps.created_at DESC
                LIMIT 10
            """)

            rows = cursor.fetchall()
            conn.close()

            if not rows:
                await update.message.reply_text("⚠️ Riskli ürün kutusu boş.")
                return

            lines = ["⚠️ *Riskli Ürünler (Çatışma Tespit Edildi)*\n"]

            for row in rows:
                score_id, title, platform, price, score, conflict, profit = row
                lines.append(
                    f"*{title[:30]}...*\n"
                    f"  📍 {platform} | 💰 {price}€ | ⭐ {score}/5\n"
                    f"  ⚠️ {conflict or 'Belirsiz risk'}\n"
                    f"  💵 Potansiyel kâr: {profit:.0f}€\n"
                    f"  `/approve {score_id}` | `/reject {score_id}`\n"
                )

            await update.message.reply_text('\n'.join(lines), parse_mode='Markdown')

        except Exception as e:
            await update.message.reply_text(f"❌ Hata: {str(e)}")

    async def _cmd_approve(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /approve command - Approve a product"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        if not context.args:
            await update.message.reply_text("Kullanım: `/approve <id>`", parse_mode='Markdown')
            return

        try:
            score_id = int(context.args[0])

            import sqlite3
            db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()

            cursor.execute("""
                UPDATE product_scores
                SET is_approved = 1, approved_by = 'telegram', approved_at = ?, updated_at = ?
                WHERE id = ?
            """, (datetime.now(), datetime.now(), score_id))

            if cursor.rowcount > 0:
                # Also add to favorites
                cursor.execute("""
                    INSERT OR IGNORE INTO favorites (product_id, user_id, added_at)
                    SELECT product_id, 'telegram', ?
                    FROM product_scores WHERE id = ?
                """, (datetime.now(), score_id))

                conn.commit()
                await update.message.reply_text(f"✅ Ürün #{score_id} onaylandı ve favorilere eklendi.")

                # Emit event
                try:
                    from core.event_bus import emit
                    await emit('product_approved_manual', {'score_id': score_id}, source='telegram_bot')
                except ImportError:
                    pass
            else:
                await update.message.reply_text(f"❌ Ürün #{score_id} bulunamadı.")

            conn.close()

        except ValueError:
            await update.message.reply_text("❌ Geçersiz ID.")
        except Exception as e:
            await update.message.reply_text(f"❌ Hata: {str(e)}")

    async def _cmd_reject(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /reject command - Reject a product"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        if not context.args:
            await update.message.reply_text("Kullanım: `/reject <id>`", parse_mode='Markdown')
            return

        try:
            score_id = int(context.args[0])

            import sqlite3
            db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()

            cursor.execute("""
                UPDATE product_scores
                SET is_rejected = 1, rejected_by = 'telegram', rejected_at = ?, updated_at = ?
                WHERE id = ?
            """, (datetime.now(), datetime.now(), score_id))

            if cursor.rowcount > 0:
                conn.commit()
                await update.message.reply_text(f"❌ Ürün #{score_id} reddedildi.")
            else:
                await update.message.reply_text(f"❌ Ürün #{score_id} bulunamadı.")

            conn.close()

        except ValueError:
            await update.message.reply_text("❌ Geçersiz ID.")
        except Exception as e:
            await update.message.reply_text(f"❌ Hata: {str(e)}")

    async def _cmd_platforms(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /platforms command"""
        if not self.ceo:
            await update.message.reply_text("❌ CEO Agent bağlantısı yok")
            return

        platforms = self.ceo.get_platform_list()

        by_type = {}
        for p in platforms:
            ptype = p['platform']
            if ptype not in by_type:
                by_type[ptype] = []
            by_type[ptype].append(p['country'])

        lines = ["📦 *Desteklenen Platformlar:*\n"]
        for platform, countries in by_type.items():
            lines.append(f"*{platform.upper()}* ({len(countries)} ülke)")
            lines.append(f"  └ {', '.join(countries)}")

        lines.append(f"\n*Toplam:* {len(platforms)} platform")

        await update.message.reply_text('\n'.join(lines), parse_mode='Markdown')

    async def _cmd_favorites(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /favorites command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        # Would get from SalesManager
        await update.message.reply_text("⭐ Favori listesi yakında eklenecek.")

    async def _cmd_favorites_check(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /favorites_check command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        await update.message.reply_text("🔄 Favori ürün kontrolleri yakında eklenecek.")

    async def _cmd_sales(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /sales command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        # Would get from AccountingManager
        await update.message.reply_text("💰 Satış raporu yakında eklenecek.")

    async def _cmd_messages(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /messages command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        # Would get from CommunicationManager
        await update.message.reply_text("📬 Mesaj listesi yakında eklenecek.")

    async def _cmd_urgent(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /urgent command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        await update.message.reply_text("🚨 Acil bildirim ayarları yakında eklenecek.")

    async def _cmd_track(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /track command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        if not context.args:
            await update.message.reply_text("Kullanım: /track <takip_numarası>")
            return

        tracking_number = context.args[0]

        # Would call LogisticsManager
        await update.message.reply_text(f"📦 Kargo takibi: {tracking_number}\n\n(Detaylar yakında eklenecek)")

    async def _cmd_shipments(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /shipments command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        await update.message.reply_text("🚚 Aktif kargo listesi yakında eklenecek.")

    async def _cmd_invoices(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /invoices command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        await update.message.reply_text("🧾 Fatura listesi yakında eklenecek.")

    async def _cmd_report(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /report command"""
        if not self._is_authorized(str(update.effective_user.id)):
            return

        period = context.args[0] if context.args else 'daily'

        if period not in ['daily', 'weekly', 'monthly']:
            await update.message.reply_text("Kullanım: /report <daily|weekly|monthly>")
            return

        await update.message.reply_text(f"📊 {period.capitalize()} rapor hazırlanıyor...")

        if self.ceo:
            report = await self.ceo._generate_daily_report()
            # Report sent via notification in the method
        else:
            await update.message.reply_text("❌ CEO Agent bağlantısı yok")

    async def _handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle inline keyboard callbacks"""
        query = update.callback_query
        await query.answer()

        data = query.data

        # Handle different callback types
        if data.startswith('scrape_'):
            platform = data.replace('scrape_', '')
            await query.edit_message_text(f"Kazıma başlatılıyor: {platform}...")

    async def _error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle errors"""
        self.logger.error(f"Telegram error: {context.error}")

    # ==================== NOTIFICATION METHODS ====================

    async def send_message(self, chat_id: str, text: str, parse_mode: str = 'Markdown') -> bool:
        """Send a message to a chat"""
        if not self.app or not self.running:
            return False

        try:
            await self.app.bot.send_message(
                chat_id=chat_id,
                text=text,
                parse_mode=parse_mode
            )
            return True
        except Exception as e:
            self.logger.error("Failed to send message", exception=str(e))
            return False

    async def send_document(self, chat_id: str, document_path: str, caption: str = None) -> bool:
        """Send a document to a chat"""
        if not self.app or not self.running:
            return False

        try:
            with open(document_path, 'rb') as f:
                await self.app.bot.send_document(
                    chat_id=chat_id,
                    document=f,
                    caption=caption
                )
            return True
        except Exception as e:
            self.logger.error("Failed to send document", exception=str(e))
            return False

    async def send_urgent_notification(self, message: str):
        """Send urgent notification to admin"""
        formatted = f"🚨 *ACİL BİLDİRİM*\n\n{message}\n\n⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        await self.send_message(self.admin_chat_id, formatted)


# ==================== STANDALONE BOT ====================

class StandaloneTelegramBot(TelegramBot):
    """Standalone version that can run without CEO Agent"""

    def __init__(self, token: str, admin_chat_id: str):
        super().__init__(token, admin_chat_id, ceo_agent=None)

    async def run(self):
        """Run the bot standalone"""
        await self.start()

        # Keep running
        while self.running:
            await asyncio.sleep(1)


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("TELEGRAM BOT TEST")
    print("=" * 60)

    # Test without actual Telegram connection
    class MockCEO:
        def get_system_status(self):
            return {
                'status': 'running',
                'uptime_hours': 24.5,
                'platforms_count': 36,
                'operation_queue_size': 5,
                'telegram_connected': True,
                'healing_enabled': True,
                'metrics': {
                    'total_scrapes': 1250,
                    'products_found': 8500,
                    'success_rate': 95.5
                }
            }

        async def _health_check(self):
            return {
                'ceo': 'healthy',
                'telegram': 'connected',
                'managers': {
                    'scraping': 'healthy',
                    'sales': 'healthy',
                    'communication': 'healthy',
                    'logistics': 'healthy',
                    'accounting': 'healthy'
                }
            }

        def get_platform_list(self):
            return [
                {'platform': 'vinted', 'country': 'de'},
                {'platform': 'vinted', 'country': 'fr'},
                {'platform': 'ebay', 'country': 'de'},
            ]

        async def start_scraping(self, platform, query, limit):
            return {'success': True, 'platforms': [platform], 'queued': 1}

        async def stop_scraping(self, platform):
            pass

        async def _generate_daily_report(self):
            return {'date': '2024-01-01'}

    async def test():
        token = os.getenv('TELEGRAM_BOT_TOKEN', 'test_token')
        admin_id = os.getenv('TELEGRAM_ADMIN_CHAT_ID', 'test_chat')

        bot = TelegramBot(token, admin_id, MockCEO())

        print(f"\nBot initialized")
        print(f"Help text preview:\n{bot.HELP_TEXT[:500]}...")
        print(f"\nTelegram available: {TELEGRAM_AVAILABLE}")

        print("\n✅ Telegram Bot test complete!")

    asyncio.run(test())
    print("=" * 60)
