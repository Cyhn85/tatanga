#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Lojistik Tahmin Ajanı
Satıcı konumuna göre tahmini kargo süresini hesaplar

Bu ajan, ürünün satıcı konumundan merkez depoya (Almanya)
tahmini teslimat süresini hesaplar.

Author: TATANGA Team
Version: 1.0
"""

import re
from typing import Dict, Optional, Tuple
from datetime import datetime
import sqlite3
from pathlib import Path


class LogisticsEstimatorAgent:
    """
    Lojistik Tahmin Ajanı

    Satıcının konumuna göre merkeze (Almanya) tahmini kargo süresini hesaplar.
    Platform bazlı kargo süreleri ve ülke mesafelerine göre tahmin yapar.
    """

    # Merkez depo lokasyonu
    HUB_COUNTRY = 'DE'  # Almanya
    HUB_CITY = 'Berlin'

    # Ülke kodları -> Ülke adları eşlemesi
    COUNTRY_CODES = {
        'DE': 'Germany', 'AT': 'Austria', 'CH': 'Switzerland',
        'NL': 'Netherlands', 'BE': 'Belgium', 'LU': 'Luxembourg',
        'FR': 'France', 'IT': 'Italy', 'ES': 'Spain', 'PT': 'Portugal',
        'UK': 'United Kingdom', 'GB': 'United Kingdom',
        'IE': 'Ireland', 'DK': 'Denmark', 'SE': 'Sweden',
        'NO': 'Norway', 'FI': 'Finland', 'PL': 'Poland',
        'CZ': 'Czech Republic', 'SK': 'Slovakia', 'HU': 'Hungary',
        'RO': 'Romania', 'BG': 'Bulgaria', 'GR': 'Greece',
        'HR': 'Croatia', 'SI': 'Slovenia', 'LT': 'Lithuania',
        'LV': 'Latvia', 'EE': 'Estonia',
    }

    # Almanya'ya olan tahmini kargo süreleri (gün)
    # Format: (min_gün, max_gün, ortalama_gün)
    SHIPPING_DAYS = {
        # Almanya içi
        'DE': (1, 3, 2),

        # Komşu ülkeler (1-3 gün)
        'AT': (2, 4, 3),
        'CH': (2, 4, 3),
        'NL': (2, 3, 2),
        'BE': (2, 3, 2),
        'LU': (2, 3, 2),
        'DK': (2, 4, 3),
        'PL': (2, 4, 3),
        'CZ': (2, 4, 3),

        # Orta mesafe (3-5 gün)
        'FR': (3, 5, 4),
        'UK': (3, 6, 4),
        'GB': (3, 6, 4),
        'SE': (3, 5, 4),
        'IT': (4, 6, 5),
        'HU': (3, 5, 4),
        'SK': (3, 5, 4),

        # Uzak mesafe (5-7+ gün)
        'ES': (5, 8, 6),
        'PT': (5, 8, 6),
        'NO': (4, 7, 5),
        'FI': (5, 8, 6),
        'IE': (4, 7, 5),
        'GR': (6, 10, 7),
        'RO': (5, 8, 6),
        'BG': (5, 8, 6),
        'HR': (4, 6, 5),
        'SI': (3, 5, 4),
        'LT': (4, 6, 5),
        'LV': (4, 7, 5),
        'EE': (5, 7, 6),
    }

    # Platform bazlı kargo hızı çarpanları
    PLATFORM_MULTIPLIERS = {
        'vinted': 1.0,       # Standart
        'ebay': 0.9,         # Biraz daha hızlı (profesyonel satıcılar)
        'kleinanzeigen': 1.2, # Biraz daha yavaş (amatör satıcılar)
        'willhaben': 1.1,
        'leboncoin': 1.1,
        'tradera': 1.0,
        'shpock': 1.1,
        'finn': 1.0,
        'blocket': 1.0,
    }

    # Almanca şehir -> Ülke eşlemesi (yaygın şehirler)
    CITY_TO_COUNTRY = {
        # Almanya
        'berlin': 'DE', 'münchen': 'DE', 'munich': 'DE', 'hamburg': 'DE',
        'köln': 'DE', 'cologne': 'DE', 'frankfurt': 'DE', 'stuttgart': 'DE',
        'düsseldorf': 'DE', 'dortmund': 'DE', 'essen': 'DE', 'leipzig': 'DE',
        'bremen': 'DE', 'dresden': 'DE', 'hannover': 'DE', 'nürnberg': 'DE',

        # Avusturya
        'wien': 'AT', 'vienna': 'AT', 'graz': 'AT', 'linz': 'AT', 'salzburg': 'AT',
        'innsbruck': 'AT',

        # İsviçre
        'zürich': 'CH', 'zurich': 'CH', 'genf': 'CH', 'geneva': 'CH',
        'basel': 'CH', 'bern': 'CH',

        # Hollanda
        'amsterdam': 'NL', 'rotterdam': 'NL', 'den haag': 'NL', 'utrecht': 'NL',

        # Belçika
        'brüssel': 'BE', 'brussels': 'BE', 'antwerpen': 'BE', 'gent': 'BE',

        # Fransa
        'paris': 'FR', 'lyon': 'FR', 'marseille': 'FR', 'toulouse': 'FR',
        'nizza': 'FR', 'nice': 'FR', 'bordeaux': 'FR', 'lille': 'FR',

        # İtalya
        'rom': 'IT', 'rome': 'IT', 'mailand': 'IT', 'milan': 'IT',
        'florenz': 'IT', 'florence': 'IT', 'venedig': 'IT', 'venice': 'IT',
        'neapel': 'IT', 'naples': 'IT', 'turin': 'IT',

        # İspanya
        'madrid': 'ES', 'barcelona': 'ES', 'valencia': 'ES', 'sevilla': 'ES',

        # İngiltere
        'london': 'GB', 'manchester': 'GB', 'birmingham': 'GB', 'liverpool': 'GB',
        'glasgow': 'GB', 'edinburgh': 'GB',

        # İskandinav
        'stockholm': 'SE', 'göteborg': 'SE', 'malmö': 'SE',
        'oslo': 'NO', 'bergen': 'NO',
        'kopenhagen': 'DK', 'copenhagen': 'DK',
        'helsinki': 'FI',

        # Doğu Avrupa
        'warschau': 'PL', 'warsaw': 'PL', 'krakau': 'PL', 'krakow': 'PL',
        'prag': 'CZ', 'prague': 'CZ', 'brünn': 'CZ', 'brno': 'CZ',
        'budapest': 'HU',
        'bukarest': 'RO', 'bucharest': 'RO',
        'sofia': 'BG',
        'athen': 'GR', 'athens': 'GR',
    }

    def __init__(self, db_path: str = None):
        """
        Initialize Logistics Estimator Agent

        Args:
            db_path: Path to SQLite database
        """
        if db_path is None:
            db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'
        self.db_path = Path(db_path)

    def estimate_shipping(self, product: Dict) -> Dict:
        """
        Ürün için tahmini kargo süresini hesapla

        Args:
            product: Ürün bilgileri dict
                - location: Satıcı konumu (şehir, ülke)
                - platform: Platform adı
                - country: Ülke kodu (varsa)

        Returns:
            Dict with:
                - estimated_days: Tahmini gün (ortalama)
                - min_days: Minimum gün
                - max_days: Maximum gün
                - origin_country: Tespit edilen kaynak ülke
                - confidence: Tahmin güveni (0-1)
        """
        location = product.get('location', '')
        platform = product.get('platform', 'vinted').lower()
        country_code = product.get('country', '').upper()

        # Ülke kodunu tespit et
        detected_country, confidence = self._detect_country(location, country_code, platform)

        if detected_country and detected_country in self.SHIPPING_DAYS:
            min_days, max_days, avg_days = self.SHIPPING_DAYS[detected_country]

            # Platform çarpanı uygula
            multiplier = self._get_platform_multiplier(platform)

            min_days = max(1, int(min_days * multiplier))
            max_days = int(max_days * multiplier)
            avg_days = int(avg_days * multiplier)

            return {
                'estimated_days': avg_days,
                'min_days': min_days,
                'max_days': max_days,
                'origin_country': detected_country,
                'origin_country_name': self.COUNTRY_CODES.get(detected_country, detected_country),
                'confidence': confidence,
                'hub_country': self.HUB_COUNTRY,
                'shipping_category': self._get_shipping_category(avg_days)
            }

        # Bilinmeyen ülke - varsayılan değerler
        return {
            'estimated_days': 5,
            'min_days': 3,
            'max_days': 10,
            'origin_country': 'UNKNOWN',
            'origin_country_name': 'Unknown',
            'confidence': 0.3,
            'hub_country': self.HUB_COUNTRY,
            'shipping_category': 'medium'
        }

    def _detect_country(self, location: str, country_code: str, platform: str) -> Tuple[str, float]:
        """
        Konum bilgisinden ülke kodunu tespit et

        Returns:
            Tuple of (country_code, confidence)
        """
        # 1. Direkt ülke kodu varsa kullan
        if country_code and len(country_code) == 2:
            country_code = country_code.upper()
            if country_code in self.SHIPPING_DAYS:
                return country_code, 1.0

        # 2. Platform adından ülke çıkar (örn: vinted_de -> DE)
        if '_' in platform:
            suffix = platform.split('_')[-1].upper()
            if len(suffix) == 2 and suffix in self.SHIPPING_DAYS:
                return suffix, 0.9

        if not location:
            return None, 0.0

        location_lower = location.lower().strip()

        # 3. Konum içinde ülke kodu ara (örn: "Berlin, DE")
        for code in self.COUNTRY_CODES.keys():
            if f', {code.lower()}' in location_lower or location_lower.endswith(f' {code.lower()}'):
                return code, 0.95

        # 4. Konum içinde ülke adı ara
        for code, name in self.COUNTRY_CODES.items():
            if name.lower() in location_lower:
                return code, 0.9

        # 5. Şehir adından ülke tespit et
        for city, country in self.CITY_TO_COUNTRY.items():
            if city in location_lower:
                return country, 0.85

        # 6. Almanca ülke adları
        german_country_names = {
            'deutschland': 'DE', 'österreich': 'AT', 'schweiz': 'CH',
            'frankreich': 'FR', 'italien': 'IT', 'spanien': 'ES',
            'niederlande': 'NL', 'belgien': 'BE', 'polen': 'PL',
            'tschechien': 'CZ', 'ungarn': 'HU', 'dänemark': 'DK',
            'schweden': 'SE', 'norwegen': 'NO', 'finnland': 'FI',
            'griechenland': 'GR', 'portugal': 'PT', 'irland': 'IE',
            'großbritannien': 'GB', 'england': 'GB',
        }

        for name, code in german_country_names.items():
            if name in location_lower:
                return code, 0.9

        return None, 0.0

    def _get_platform_multiplier(self, platform: str) -> float:
        """Platform bazlı kargo hızı çarpanını döndür"""
        # Platform adından ana platformu çıkar (vinted_de -> vinted)
        base_platform = platform.split('_')[0].lower()
        return self.PLATFORM_MULTIPLIERS.get(base_platform, 1.0)

    def _get_shipping_category(self, days: int) -> str:
        """Kargo süresine göre kategori döndür"""
        if days <= 2:
            return 'fast'      # Hızlı (1-2 gün)
        elif days <= 4:
            return 'medium'    # Orta (3-4 gün)
        elif days <= 6:
            return 'slow'      # Yavaş (5-6 gün)
        else:
            return 'very_slow' # Çok yavaş (7+ gün)

    def enrich_product(self, product: Dict) -> Dict:
        """
        Ürünü lojistik bilgileriyle zenginleştir

        Args:
            product: Ham ürün verisi

        Returns:
            Zenginleştirilmiş ürün verisi
        """
        shipping_info = self.estimate_shipping(product)

        return {
            **product,
            'estimated_shipping_days': shipping_info['estimated_days'],
            'shipping_min_days': shipping_info['min_days'],
            'shipping_max_days': shipping_info['max_days'],
            'shipping_origin_country': shipping_info['origin_country'],
            'shipping_category': shipping_info['shipping_category'],
            'shipping_confidence': shipping_info['confidence']
        }

    def batch_enrich(self, products: list) -> list:
        """
        Birden fazla ürünü zenginleştir

        Args:
            products: Ürün listesi

        Returns:
            Zenginleştirilmiş ürün listesi
        """
        return [self.enrich_product(p) for p in products]

    def get_shipping_stats(self, batch_id: str = None) -> Dict:
        """
        Kargo istatistiklerini getir

        Args:
            batch_id: Parti ID (opsiyonel)

        Returns:
            Kargo kategorilerine göre ürün sayıları
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        query = """
            SELECT
                shipping_origin_country,
                COUNT(*) as count,
                AVG(estimated_shipping_days) as avg_days
            FROM products
            WHERE is_in_inbox = 1
        """

        if batch_id:
            query += f" AND batch_id = '{batch_id}'"

        query += " GROUP BY shipping_origin_country ORDER BY count DESC"

        try:
            cursor.execute(query)
            rows = cursor.fetchall()

            stats = {
                'by_country': {},
                'by_category': {'fast': 0, 'medium': 0, 'slow': 0, 'very_slow': 0},
                'total': 0
            }

            for country, count, avg_days in rows:
                if country:
                    stats['by_country'][country] = {
                        'count': count,
                        'avg_days': round(avg_days, 1) if avg_days else 0
                    }
                    stats['total'] += count

                    # Kategoriye ekle
                    category = self._get_shipping_category(int(avg_days) if avg_days else 5)
                    stats['by_category'][category] += count

            return stats

        except Exception as e:
            return {'error': str(e)}
        finally:
            conn.close()


# ==================== TEST ====================

if __name__ == "__main__":
    print("=" * 60)
    print("LOGISTICS ESTIMATOR AGENT TEST")
    print("=" * 60)

    agent = LogisticsEstimatorAgent()

    # Test ürünleri
    test_products = [
        {'location': 'Berlin, Deutschland', 'platform': 'vinted_de'},
        {'location': 'Wien', 'platform': 'willhaben'},
        {'location': 'Paris, France', 'platform': 'vinted_fr'},
        {'location': 'Stockholm', 'platform': 'tradera'},
        {'location': 'Madrid', 'platform': 'vinted_es'},
        {'location': 'London, UK', 'platform': 'ebay_uk'},
        {'location': 'Unknown City', 'platform': 'vinted'},
        {'location': '', 'platform': 'vinted_de', 'country': 'DE'},
    ]

    print("\nShipping Estimates:")
    print("-" * 60)

    for product in test_products:
        result = agent.estimate_shipping(product)
        print(f"\nLocation: {product.get('location', 'N/A')}")
        print(f"Platform: {product.get('platform')}")
        print(f"  -> Country: {result['origin_country']} ({result['origin_country_name']})")
        print(f"  -> Days: {result['min_days']}-{result['max_days']} (avg: {result['estimated_days']})")
        print(f"  -> Category: {result['shipping_category']}")
        print(f"  -> Confidence: {result['confidence']:.0%}")

    print("\n" + "=" * 60)
    print("Logistics Estimator Agent test completed!")