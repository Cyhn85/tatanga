# Vinted Relister Configuration
import os
import sys

# Add active_pieces directory to path for imports
ACTIVE_PIECES_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ACTIVE_PIECES_DIR)

# Import credentials from TATANGA
try:
    from config.credentials import API_KEYS, TELEGRAM
    GROQ_API_KEY = API_KEYS.get('groq_api_key', '')
    TELEGRAM_BOT_TOKEN = TELEGRAM.get('bot_token', '')
    TELEGRAM_CHAT_ID = TELEGRAM.get('chat_id', '')
except ImportError:
    # Fallback - try direct import
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("credentials", os.path.join(ACTIVE_PIECES_DIR, "config", "credentials.py"))
        credentials = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(credentials)
        GROQ_API_KEY = credentials.API_KEYS.get('groq_api_key', '')
        TELEGRAM_BOT_TOKEN = credentials.TELEGRAM.get('bot_token', '')
        TELEGRAM_CHAT_ID = credentials.TELEGRAM.get('chat_id', '')
    except:
        GROQ_API_KEY = ''
        TELEGRAM_BOT_TOKEN = ''
        TELEGRAM_CHAT_ID = ''

# Gemini API from videocu_v1
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', 'AIzaSyBwA4VQVEUROtcK9XZ228bAoCvRuHQ2LoE')

# Vinted URLs
VINTED_BASE_URL = 'https://www.vinted.de'
VINTED_PROFILE_URL = 'https://www.vinted.de/member/293217988'
VINTED_UPLOAD_URL = 'https://www.vinted.de/items/new'

# Chrome Settings
CHROME_USER_DATA = r'C:\Users\cyhnsrgc\AppData\Local\Google\Chrome\User Data'
CHROME_PROFILE = 'Default'

# Project Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
RAW_DIR = os.path.join(DATA_DIR, 'raw')
PROCESSED_DIR = os.path.join(DATA_DIR, 'processed')
FINAL_DIR = os.path.join(DATA_DIR, 'final')
STORES_DIR = os.path.join(BASE_DIR, 'stores')
DATABASE_PATH = os.path.join(BASE_DIR, 'vinted_products.db')

# NConvert Path (doğru konum: tools/nconvert/NConvert/nconvert.exe)
NCONVERT_PATH = os.path.join(os.path.dirname(os.path.dirname(BASE_DIR)), 'tools', 'nconvert', 'NConvert', 'nconvert.exe')

# API Settings
GROQ_MODEL = 'llama-3.3-70b-versatile'
GEMINI_MODEL = 'gemini-1.5-flash'

# Upload Settings
DAILY_UPLOAD_LIMIT = 15
UPLOAD_START_HOUR = 16
UPLOAD_END_HOUR = 17

# Human-like Delays (seconds)
DELAY_BETWEEN_FIELDS = (2, 5)  # Random delay between form fields
DELAY_BETWEEN_CHARS = (0.05, 0.15)  # Random delay between keystrokes
DELAY_BETWEEN_PRODUCTS = (180, 300)  # 3-5 minutes between product uploads
PAGE_LOAD_WAIT = (3, 6)  # Wait for page loads

# Image Processing Settings
IMAGE_ROTATION_RANGE = (1.2, 1.8)  # Degrees for same store
IMAGE_ROTATION_RANGE_MULTI = (3.0, 5.0)  # Degrees for different store
IMAGE_CONTRAST_RANGE = (2, 5)  # Percentage for same store
IMAGE_CONTRAST_RANGE_MULTI = (5, 10)  # Percentage for different store
IMAGE_QUALITY = 95  # JPEG quality

# Status Codes
STATUS_RAW = 0
STATUS_IMAGE_DONE = 1
STATUS_SEO_DONE = 2
STATUS_VALIDATED = 3
STATUS_PENDING_APPROVAL = 4
STATUS_UPLOADED = 5

# Ports
API_PORT = 8504
DASHBOARD_PORT = 8505

# Proxy Settings (Mobile Proxy for IP Isolation)
MOBILE_PROXY_ENABLED = True
MOBILE_PROXY_HOST = "192.168.43.1"
MOBILE_PROXY_PORT = 8080

# Store-Proxy Configuration
# Each store can have its own proxy settings for IP isolation
STORE_PROXY_CONFIG = {
    'cyhn85': None,  # Home internet - no proxy
    'cssberlin': {
        'host': '192.168.43.1',
        'port': 8080,
        'type': 'http'
    }
}
