#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Smart Warning System
Intelligent warning and notification system for GUI integration

Warning Types:
1. Performance Warnings - Selenium platforms slower than API
2. Duplicate Warnings - Product already exists in database
3. Closed Platform Warnings - No API available, Selenium required
4. Rate Limit Warnings - API quota exceeded or approaching limit
"""

import sys
import io
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import json
from pathlib import Path
import sqlite3

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')


class WarningLevel:
    """Warning severity levels"""
    INFO = "info"           # Informational, no action needed
    WARNING = "warning"     # Warning, user should be aware
    ERROR = "error"         # Error, operation may fail
    CRITICAL = "critical"   # Critical, operation will fail


class WarningCategory:
    """Warning categories"""
    PERFORMANCE = "performance"
    DUPLICATE = "duplicate"
    PLATFORM = "platform"
    RATE_LIMIT = "rate_limit"
    AUTHENTICATION = "authentication"
    NETWORK = "network"


class Warning:
    """
    Warning object with all details
    """
    def __init__(
        self,
        level: str,
        category: str,
        title: str,
        message: str,
        platform: str = None,
        action_required: bool = False,
        actions: List[Dict] = None,
        details: Dict = None
    ):
        self.level = level
        self.category = category
        self.title = title
        self.message = message
        self.platform = platform
        self.action_required = action_required
        self.actions = actions or []
        self.details = details or {}
        self.timestamp = datetime.now()

    def to_dict(self) -> Dict:
        """Convert to dictionary for GUI"""
        return {
            'level': self.level,
            'category': self.category,
            'title': self.title,
            'message': self.message,
            'platform': self.platform,
            'action_required': self.action_required,
            'actions': self.actions,
            'details': self.details,
            'timestamp': self.timestamp.isoformat()
        }

    def get_icon(self) -> str:
        """Get emoji icon for warning level"""
        icons = {
            WarningLevel.INFO: "ℹ️",
            WarningLevel.WARNING: "⚠️",
            WarningLevel.ERROR: "❌",
            WarningLevel.CRITICAL: "🔴"
        }
        return icons.get(self.level, "❓")

    def __str__(self) -> str:
        """String representation for console"""
        return f"{self.get_icon()} [{self.level.upper()}] {self.title}: {self.message}"


class SmartWarningSystem:
    """
    Intelligent warning system with context-aware notifications
    """

    def __init__(self, db_path: str = None, capabilities_path: str = None):
        if db_path is None:
            db_path = Path(__file__).parent / 'tatanga.db'
        if capabilities_path is None:
            capabilities_path = Path(__file__).parent / 'config' / 'platform_capabilities.json'

        self.db_path = db_path
        self.capabilities_path = capabilities_path

        # Load platform capabilities
        self.platform_capabilities = {}
        if Path(capabilities_path).exists():
            with open(capabilities_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.platform_capabilities = data.get('platforms', {})

        # Initialize warning log table
        self._init_warning_log()

    def _init_warning_log(self):
        """Initialize warning log table in database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS warning_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                level TEXT,
                category TEXT,
                title TEXT,
                message TEXT,
                platform TEXT,
                details TEXT,
                shown_to_user BOOLEAN DEFAULT 0,
                dismissed BOOLEAN DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        conn.commit()
        conn.close()

    # ========================================================================
    # WARNING TYPE 1: PERFORMANCE WARNINGS
    # ========================================================================

    def check_performance_warning(self, platform: str, operation: str = "scrape") -> Optional[Warning]:
        """
        Check if platform requires slow Selenium instead of fast API

        Args:
            platform: Platform key (e.g., 'vinted_de', 'willhaben')
            operation: 'scrape' or 'upload'

        Returns:
            Warning object if performance warning needed, None otherwise
        """
        if platform not in self.platform_capabilities:
            return None

        platform_data = self.platform_capabilities[platform]

        # Check if API available
        api_available = platform_data.get('api_available', False)
        selenium_required = platform_data.get('selenium_required', False)
        selenium_complexity = platform_data.get('selenium_complexity', 'medium')

        # No warning if API available
        if api_available and not selenium_required:
            return None

        # Generate warning for Selenium-based platforms
        speed = platform_data.get('speed', 'unknown')

        if speed == 'slow' or selenium_complexity == 'high':
            level = WarningLevel.WARNING
            estimated_time = "30-60 seconds per product"
            complexity_note = "High complexity (CAPTCHA, anti-bot protection)"
        elif selenium_complexity == 'medium':
            level = WarningLevel.INFO
            estimated_time = "10-20 seconds per product"
            complexity_note = "Medium complexity (standard Selenium automation)"
        else:
            level = WarningLevel.INFO
            estimated_time = "5-10 seconds per product"
            complexity_note = "Low complexity (simple automation)"

        message = (
            f"{platform_data['name']} does not have an official API. "
            f"Operations will use Selenium automation. "
            f"Estimated time: {estimated_time}. "
            f"{complexity_note}"
        )

        actions = [
            {
                'label': 'Continue Anyway',
                'action': 'continue',
                'primary': True
            },
            {
                'label': 'Learn More',
                'action': 'show_info',
                'url': platform_data.get('url', '')
            }
        ]

        return Warning(
            level=level,
            category=WarningCategory.PERFORMANCE,
            title=f"Performance Notice: {platform_data['name']}",
            message=message,
            platform=platform,
            action_required=False,
            actions=actions,
            details={
                'speed': speed,
                'selenium_complexity': selenium_complexity,
                'estimated_time': estimated_time,
                'api_available': False
            }
        )

    # ========================================================================
    # WARNING TYPE 2: DUPLICATE WARNINGS
    # ========================================================================

    def create_duplicate_warning(
        self,
        product_data: Dict,
        existing_product_id: int,
        detection_method: str,
        reason: str
    ) -> Warning:
        """
        Create warning for duplicate product detection

        Args:
            product_data: New product data
            existing_product_id: ID of existing product in database
            detection_method: 'url', 'platform_id', 'image_hash', 'content', 'cooldown'
            reason: Detailed reason string

        Returns:
            Warning object with duplicate details
        """
        # Get existing product details from database
        existing_product = self._get_product_details(existing_product_id)

        # Determine warning level based on detection method
        if detection_method in ['url', 'platform_id']:
            level = WarningLevel.ERROR  # Exact duplicate
        elif detection_method == 'cooldown':
            level = WarningLevel.WARNING  # Recently scraped
        else:
            level = WarningLevel.WARNING  # Similar product

        # Create user-friendly message
        method_names = {
            'url': 'exact URL match',
            'platform_id': 'platform item ID match',
            'image_hash': 'similar images detected',
            'content': 'similar title and price',
            'cooldown': 'recently scraped (cooldown active)'
        }

        method_name = method_names.get(detection_method, detection_method)

        message = (
            f"This product appears to be a duplicate. "
            f"Detection method: {method_name}. "
            f"An existing product (ID: {existing_product_id}) was found in the database. "
            f"{reason}"
        )

        actions = [
            {
                'label': 'View Existing Product',
                'action': 'view_product',
                'product_id': existing_product_id,
                'primary': True
            },
            {
                'label': 'Force Add Anyway',
                'action': 'force_add',
                'warning': 'This will create a duplicate entry'
            },
            {
                'label': 'Cancel',
                'action': 'cancel'
            }
        ]

        details = {
            'detection_method': detection_method,
            'existing_product_id': existing_product_id,
            'new_product': {
                'url': product_data.get('url', ''),
                'title': product_data.get('title', ''),
                'price': product_data.get('price', 0)
            }
        }

        if existing_product:
            details['existing_product'] = existing_product

        return Warning(
            level=level,
            category=WarningCategory.DUPLICATE,
            title="Duplicate Product Detected",
            message=message,
            platform=product_data.get('platform', ''),
            action_required=True,
            actions=actions,
            details=details
        )

    def _get_product_details(self, product_id: int) -> Optional[Dict]:
        """Get product details from database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute('''
                SELECT id, title, price, source_platform, source_url, created_at
                FROM products WHERE id = ?
            ''', (product_id,))

            row = cursor.fetchone()
            conn.close()

            if row:
                return {
                    'id': row[0],
                    'title': row[1],
                    'price': row[2],
                    'platform': row[3],
                    'url': row[4],
                    'created_at': row[5]
                }
        except:
            pass

        return None

    # ========================================================================
    # WARNING TYPE 3: CLOSED PLATFORM WARNINGS (Educational)
    # ========================================================================

    def create_closed_platform_warning(self, platform: str, first_use: bool = False) -> Optional[Warning]:
        """
        Create educational warning for platforms without official API

        Args:
            platform: Platform key
            first_use: True if this is user's first time using this platform

        Returns:
            Warning object with educational content
        """
        if platform not in self.platform_capabilities:
            return None

        platform_data = self.platform_capabilities[platform]

        # Only show for platforms without official API
        if platform_data.get('api_available', False) and platform_data.get('api_type') == 'official':
            return None

        # Check if user has seen this warning before
        if not first_use and self._has_seen_platform_warning(platform):
            return None

        api_type = platform_data.get('api_type', 'none')
        selenium_complexity = platform_data.get('selenium_complexity', 'medium')

        if api_type == 'none':
            title = f"About {platform_data['name']}: No Official API"
            message = (
                f"{platform_data['name']} does not provide an official API for developers. "
                f"TATANGA uses Selenium browser automation to interact with this platform. "
                f"This approach is slower but reliable. "
                f"Complexity level: {selenium_complexity}."
            )
        else:  # unofficial API
            title = f"About {platform_data['name']}: Unofficial API"
            message = (
                f"{platform_data['name']} has an unofficial API that we've reverse-engineered. "
                f"This method is faster than Selenium but may break if the platform updates. "
                f"TATANGA will automatically fall back to Selenium if the API fails."
            )

        # Educational content
        educational_notes = []

        if selenium_complexity == 'high':
            educational_notes.append(
                "⚠️ High Complexity: This platform has anti-bot protection (CAPTCHA, Cloudflare). "
                "Operations may require manual intervention."
            )

        if platform_data.get('duplicate_risk') == 'high':
            educational_notes.append(
                "🔍 High Duplicate Risk: Many products on this platform are cross-posted. "
                "Our 5-layer duplicate detection is active."
            )

        if platform_data.get('speed') == 'slow':
            educational_notes.append(
                "🐌 Slower Operations: Expect 30-60 seconds per product due to Selenium automation."
            )

        actions = [
            {
                'label': 'I Understand, Continue',
                'action': 'continue',
                'primary': True
            },
            {
                'label': "Don't Show Again",
                'action': 'dismiss_forever'
            }
        ]

        return Warning(
            level=WarningLevel.INFO,
            category=WarningCategory.PLATFORM,
            title=title,
            message=message + "\n\n" + "\n".join(educational_notes),
            platform=platform,
            action_required=True,
            actions=actions,
            details={
                'api_type': api_type,
                'selenium_complexity': selenium_complexity,
                'speed': platform_data.get('speed'),
                'duplicate_risk': platform_data.get('duplicate_risk'),
                'notes': platform_data.get('notes', '')
            }
        )

    def _has_seen_platform_warning(self, platform: str) -> bool:
        """Check if user has already seen warning for this platform"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute('''
                SELECT COUNT(*) FROM warning_log
                WHERE platform = ? AND category = 'platform' AND dismissed = 1
            ''', (platform,))

            count = cursor.fetchone()[0]
            conn.close()

            return count > 0
        except:
            return False

    # ========================================================================
    # WARNING TYPE 4: RATE LIMIT WARNINGS
    # ========================================================================

    def check_rate_limit_warning(
        self,
        platform: str,
        requests_made: int,
        requests_limit: int,
        time_window: str = "hour"
    ) -> Optional[Warning]:
        """
        Check if approaching or exceeded API rate limit

        Args:
            platform: Platform key
            requests_made: Number of requests made in time window
            requests_limit: Maximum requests allowed
            time_window: Time window (e.g., "hour", "day")

        Returns:
            Warning object if rate limit warning needed
        """
        usage_percentage = (requests_made / requests_limit) * 100

        # No warning if usage < 70%
        if usage_percentage < 70:
            return None

        # Determine warning level
        if usage_percentage >= 100:
            level = WarningLevel.CRITICAL
            title = f"Rate Limit Exceeded: {platform}"
            message = (
                f"You have exceeded the rate limit for {platform}. "
                f"{requests_made}/{requests_limit} requests used in the last {time_window}. "
                f"Further requests will be blocked. Please wait before continuing."
            )
            actions = [
                {
                    'label': 'Wait and Retry',
                    'action': 'wait_retry',
                    'primary': True
                },
                {
                    'label': 'Cancel Operation',
                    'action': 'cancel'
                }
            ]
        elif usage_percentage >= 90:
            level = WarningLevel.ERROR
            title = f"Rate Limit Warning: {platform}"
            message = (
                f"You are approaching the rate limit for {platform}. "
                f"{requests_made}/{requests_limit} requests used ({usage_percentage:.0f}%). "
                f"Only {requests_limit - requests_made} requests remaining."
            )
            actions = [
                {
                    'label': 'Continue Carefully',
                    'action': 'continue',
                    'primary': True
                },
                {
                    'label': 'Pause Operations',
                    'action': 'pause'
                }
            ]
        else:  # 70-89%
            level = WarningLevel.WARNING
            title = f"Rate Limit Notice: {platform}"
            message = (
                f"You have used {requests_made}/{requests_limit} requests ({usage_percentage:.0f}%) "
                f"for {platform} in the last {time_window}."
            )
            actions = [
                {
                    'label': 'Continue',
                    'action': 'continue',
                    'primary': True
                }
            ]

        return Warning(
            level=level,
            category=WarningCategory.RATE_LIMIT,
            title=title,
            message=message,
            platform=platform,
            action_required=(usage_percentage >= 90),
            actions=actions,
            details={
                'requests_made': requests_made,
                'requests_limit': requests_limit,
                'usage_percentage': usage_percentage,
                'time_window': time_window
            }
        )

    # ========================================================================
    # WARNING MANAGEMENT
    # ========================================================================

    def log_warning(self, warning: Warning):
        """Log warning to database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute('''
                INSERT INTO warning_log (level, category, title, message, platform, details)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                warning.level,
                warning.category,
                warning.title,
                warning.message,
                warning.platform,
                json.dumps(warning.details)
            ))

            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Error logging warning: {e}")

    def get_recent_warnings(self, limit: int = 10) -> List[Warning]:
        """Get recent warnings from log"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute('''
                SELECT level, category, title, message, platform, details, created_at
                FROM warning_log
                ORDER BY created_at DESC
                LIMIT ?
            ''', (limit,))

            warnings = []
            for row in cursor.fetchall():
                details = json.loads(row[5]) if row[5] else {}
                warning = Warning(
                    level=row[0],
                    category=row[1],
                    title=row[2],
                    message=row[3],
                    platform=row[4],
                    details=details
                )
                warning.timestamp = datetime.fromisoformat(row[6])
                warnings.append(warning)

            conn.close()
            return warnings
        except:
            return []

    def dismiss_warning(self, warning_id: int):
        """Mark warning as dismissed"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute('''
                UPDATE warning_log
                SET dismissed = 1
                WHERE id = ?
            ''', (warning_id,))

            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Error dismissing warning: {e}")

    # ========================================================================
    # GUI INTEGRATION HELPERS
    # ========================================================================

    def get_platform_warnings_batch(self, platforms: List[str]) -> Dict[str, List[Warning]]:
        """
        Get all relevant warnings for multiple platforms at once

        Args:
            platforms: List of platform keys

        Returns:
            Dictionary mapping platform to list of warnings
        """
        warnings_by_platform = {}

        for platform in platforms:
            warnings = []

            # Check performance warning
            perf_warning = self.check_performance_warning(platform)
            if perf_warning:
                warnings.append(perf_warning)

            # Check closed platform warning (first use)
            closed_warning = self.create_closed_platform_warning(platform, first_use=True)
            if closed_warning:
                warnings.append(closed_warning)

            if warnings:
                warnings_by_platform[platform] = warnings

        return warnings_by_platform

    def format_warning_for_gui(self, warning: Warning) -> Dict:
        """
        Format warning for GUI display (Tkinter messagebox compatible)

        Returns:
            {
                'type': 'info'/'warning'/'error',
                'title': str,
                'message': str,
                'icon': str
            }
        """
        # Map warning levels to Tkinter message types
        type_map = {
            WarningLevel.INFO: 'info',
            WarningLevel.WARNING: 'warning',
            WarningLevel.ERROR: 'error',
            WarningLevel.CRITICAL: 'error'
        }

        return {
            'type': type_map.get(warning.level, 'info'),
            'title': warning.title,
            'message': warning.message,
            'icon': warning.get_icon(),
            'details': warning.details,
            'actions': warning.actions
        }


# ============================================================================
# TESTING
# ============================================================================

if __name__ == '__main__':
    print("TATANGA - Smart Warning System Test\n")
    print("="*70)

    # Initialize warning system
    warning_system = SmartWarningSystem()

    # Test 1: Performance Warning
    print("\n🧪 Test 1: Performance Warning (Vinted Germany)")
    warning = warning_system.check_performance_warning('vinted_de')
    if warning:
        print(warning)
        print(f"  Actions: {[a['label'] for a in warning.actions]}")

    # Test 2: Performance Warning (eBay - no warning expected)
    print("\n🧪 Test 2: Performance Warning (eBay UK - should be None)")
    warning = warning_system.check_performance_warning('ebay_uk')
    if warning:
        print(warning)
    else:
        print("  ✓ No warning (eBay has official API)")

    # Test 3: Duplicate Warning
    print("\n🧪 Test 3: Duplicate Warning")
    test_product = {
        'url': 'https://example.com/product/123',
        'title': 'Nike Air Max 90',
        'price': 89.99,
        'platform': 'kleinanzeigen'
    }
    warning = warning_system.create_duplicate_warning(
        product_data=test_product,
        existing_product_id=456,
        detection_method='url',
        reason='Exact URL match found'
    )
    print(warning)
    print(f"  Actions: {[a['label'] for a in warning.actions]}")

    # Test 4: Closed Platform Warning
    print("\n🧪 Test 4: Closed Platform Warning (Willhaben)")
    warning = warning_system.create_closed_platform_warning('willhaben', first_use=True)
    if warning:
        print(warning)
        print(f"  Actions: {[a['label'] for a in warning.actions]}")

    # Test 5: Rate Limit Warning
    print("\n🧪 Test 5: Rate Limit Warning (75% usage)")
    warning = warning_system.check_rate_limit_warning(
        platform='ebay_de',
        requests_made=750,
        requests_limit=1000,
        time_window='hour'
    )
    if warning:
        print(warning)

    print("\n🧪 Test 6: Rate Limit Critical (105% usage)")
    warning = warning_system.check_rate_limit_warning(
        platform='ebay_de',
        requests_made=1050,
        requests_limit=1000,
        time_window='hour'
    )
    if warning:
        print(warning)

    # Test 7: Batch Warnings
    print("\n🧪 Test 7: Batch Platform Warnings")
    platforms = ['vinted_de', 'ebay_uk', 'willhaben']
    batch_warnings = warning_system.get_platform_warnings_batch(platforms)
    for platform, warnings in batch_warnings.items():
        print(f"\n  {platform}: {len(warnings)} warning(s)")
        for w in warnings:
            print(f"    - {w.title}")

    print("\n" + "="*70)
    print("✓ All warning system tests complete!")
