#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Manager Agents
"""

from .scraping_manager import ScrapingManager
from .sales_manager import SalesManager
from .communication_manager import CommunicationManager
from .logistics_manager import LogisticsManager
from .accounting_manager import AccountingManager

__all__ = [
    'ScrapingManager',
    'SalesManager',
    'CommunicationManager',
    'LogisticsManager',
    'AccountingManager'
]
