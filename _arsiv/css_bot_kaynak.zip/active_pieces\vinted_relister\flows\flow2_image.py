# Flow 2: Image Processor - Contrast Enhancement + Background Removal
# Keeps original image orientation, applies professional enhancements
# v2.0 - Improved: Light grey background, drop shadow, artifact cleaning
import sys, os
from PIL import Image, ImageEnhance, ImageFilter, ImageOps, ImageDraw
import numpy as np
import cv2
import random
import io
import hashlib

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')

from config import (RAW_DIR, PROCESSED_DIR, STATUS_RAW, STATUS_IMAGE_DONE,
                    IMAGE_CONTRAST_RANGE)
from utils.database import db

# ============================================================================
# CONFIGURATION - Easily adjustable settings
# ============================================================================
# Gradient Background: Orange → Green (CSS Berlin branded)
GRADIENT_ENABLED = True
GRADIENT_START = (255, 140, 0)   # Orange (turuncu)
GRADIENT_END = (76, 175, 80)     # Green (yeşil)
GRADIENT_DIRECTION = 'diagonal'  # 'horizontal', 'vertical', 'diagonal'

# BACKGROUND REMOVAL - DISABLED (ürün bütünlüğünü bozuyor)
# Bunun yerine orijinal resmi gradient çerçeve içine yerleştir
BG_REMOVAL_ENABLED = False  # Arka plan kaldırma KAPALI

# Gradient frame settings (arka plan kaldırma kapalıyken)
FRAME_PADDING_PERCENT = 5  # Kenarlardan %5 boşluk
FRAME_BORDER_WIDTH = 15    # Gradient border kalınlığı (piksel)

# DUPLICATE PREVENTION - Vinted'ın resmi tanımasını engelle
DUPLICATE_PREVENTION = True
ROTATION_RANGE = (-3, 3)      # -3° ile +3° arası rastgele rotasyon
CONTRAST_RANGE = (0.97, 1.03) # %3 kontrast değişimi
BRIGHTNESS_RANGE = (0.98, 1.02) # %2 parlaklık değişimi
HORIZONTAL_FLIP_CHANCE = 0.3  # %30 ihtimalle yatay çevir
CROP_PERCENT = 2              # Kenarlardan %2 kırp (zoom efekti)

# Fallback solid color (if gradient disabled)
BG_COLOR = (240, 240, 240)  # #F0F0F0 - açık gri

# Drop shadow settings - DISABLED for frame mode
SHADOW_ENABLED = False
SHADOW_OFFSET = (8, 8)
SHADOW_BLUR = 15
SHADOW_COLOR = (80, 80, 80)

# Artifact cleaning - remove small isolated objects
ARTIFACT_CLEANING = True
MIN_OBJECT_AREA_RATIO = 0.02  # Ana objenin %2'sinden küçük parçaları sil

# Label detection - detect and flag label/tag images
LABEL_DETECTION = True

# Contrast/Color enhancement - DISABLED (background removal + ID change is enough)
CONTRAST_ENHANCEMENT = False  # Renkleri değiştirme, orijinal kalsın

# Background removal method
BG_METHOD = 'opencv'  # 'opencv' or 'rembg'

# Try to import rembg (optional - may have DLL issues on Windows)
REMBG_AVAILABLE = False
REMBG_SESSION = None
try:
    from rembg import remove as rembg_remove, new_session
    # Use isnet-general-use model for better quality
    REMBG_SESSION = new_session('isnet-general-use')
    REMBG_AVAILABLE = True
    BG_METHOD = 'rembg'
    print('[OK] rembg (isnet-general-use) loaded for AI background removal')
except:
    print('[INFO] Using OpenCV GrabCut for background removal')


class ImageProcessor:
    def __init__(self):
        os.makedirs(PROCESSED_DIR, exist_ok=True)
        self.bg_removal_enabled = True  # Always enabled with OpenCV fallback
        self.method = BG_METHOD
        self.bg_color = BG_COLOR
        self.gradient_enabled = GRADIENT_ENABLED
        print(f'[OK] Background removal ({self.method})')
        if self.gradient_enabled:
            print(f'[OK] Gradient background: Orange→Green ({GRADIENT_DIRECTION})')
        else:
            print(f'[OK] Background color: RGB{self.bg_color}')
        if SHADOW_ENABLED:
            print(f'[OK] Drop shadow enabled')
        if ARTIFACT_CLEANING:
            print(f'[OK] Artifact cleaning enabled')
        if CONTRAST_ENHANCEMENT:
            print(f'[OK] Contrast enhancement enabled')
        else:
            print(f'[OK] Original colors preserved (no contrast/color changes)')
        if DUPLICATE_PREVENTION:
            print(f'[OK] Duplicate prevention: rotation, flip, contrast, brightness, crop, noise')

    def create_gradient_background(self, size: tuple) -> Image.Image:
        """Create gradient background image (Orange → Green)"""
        width, height = size
        gradient = Image.new('RGB', size)

        r1, g1, b1 = GRADIENT_START  # Orange
        r2, g2, b2 = GRADIENT_END    # Green

        if GRADIENT_DIRECTION == 'horizontal':
            for x in range(width):
                ratio = x / width
                r = int(r1 + (r2 - r1) * ratio)
                g = int(g1 + (g2 - g1) * ratio)
                b = int(b1 + (b2 - b1) * ratio)
                for y in range(height):
                    gradient.putpixel((x, y), (r, g, b))
        elif GRADIENT_DIRECTION == 'vertical':
            for y in range(height):
                ratio = y / height
                r = int(r1 + (r2 - r1) * ratio)
                g = int(g1 + (g2 - g1) * ratio)
                b = int(b1 + (b2 - b1) * ratio)
                for x in range(width):
                    gradient.putpixel((x, y), (r, g, b))
        else:  # diagonal (default)
            for y in range(height):
                for x in range(width):
                    # Diagonal ratio: combine x and y position
                    ratio = (x / width + y / height) / 2
                    r = int(r1 + (r2 - r1) * ratio)
                    g = int(g1 + (g2 - g1) * ratio)
                    b = int(b1 + (b2 - b1) * ratio)
                    gradient.putpixel((x, y), (r, g, b))

        return gradient

    def create_gradient_background_fast(self, size: tuple) -> Image.Image:
        """Fast gradient creation using numpy"""
        width, height = size

        r1, g1, b1 = GRADIENT_START
        r2, g2, b2 = GRADIENT_END

        if GRADIENT_DIRECTION == 'horizontal':
            gradient_array = np.zeros((height, width, 3), dtype=np.uint8)
            for x in range(width):
                ratio = x / width
                gradient_array[:, x, 0] = int(r1 + (r2 - r1) * ratio)
                gradient_array[:, x, 1] = int(g1 + (g2 - g1) * ratio)
                gradient_array[:, x, 2] = int(b1 + (b2 - b1) * ratio)
        elif GRADIENT_DIRECTION == 'vertical':
            gradient_array = np.zeros((height, width, 3), dtype=np.uint8)
            for y in range(height):
                ratio = y / height
                gradient_array[y, :, 0] = int(r1 + (r2 - r1) * ratio)
                gradient_array[y, :, 1] = int(g1 + (g2 - g1) * ratio)
                gradient_array[y, :, 2] = int(b1 + (b2 - b1) * ratio)
        else:  # diagonal
            x_ratio = np.linspace(0, 1, width)
            y_ratio = np.linspace(0, 1, height)
            xx, yy = np.meshgrid(x_ratio, y_ratio)
            ratio = (xx + yy) / 2

            gradient_array = np.zeros((height, width, 3), dtype=np.uint8)
            gradient_array[:, :, 0] = (r1 + (r2 - r1) * ratio).astype(np.uint8)
            gradient_array[:, :, 1] = (g1 + (g2 - g1) * ratio).astype(np.uint8)
            gradient_array[:, :, 2] = (b1 + (b2 - b1) * ratio).astype(np.uint8)

        return Image.fromarray(gradient_array)

    def is_label_image(self, img: Image.Image) -> bool:
        """Detect if image is a label/tag (barcode, size tag, etc.)"""
        if not LABEL_DETECTION:
            return False

        try:
            # Convert to grayscale
            gray = img.convert('L')
            img_array = np.array(gray)

            # Labels typically have:
            # 1. High text/line density
            # 2. Rectangular shapes
            # 3. Barcode patterns (vertical lines)

            # Check for barcode-like patterns (many vertical edges)
            edges = cv2.Canny(img_array, 50, 150)
            vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 5))
            vertical_lines = cv2.morphologyEx(edges, cv2.MORPH_OPEN, vertical_kernel)

            # Count vertical line density
            line_density = np.sum(vertical_lines > 0) / (img_array.shape[0] * img_array.shape[1])

            # If more than 5% of image is vertical lines = likely barcode
            if line_density > 0.05:
                return True

            # Check aspect ratio - labels are often square or slightly rectangular
            h, w = img_array.shape
            aspect = max(h, w) / min(h, w)

            # Very square images with lots of edges = likely label
            if aspect < 1.3:
                edge_density = np.sum(edges > 0) / (h * w)
                if edge_density > 0.15:
                    return True

            return False
        except:
            return False

    def clean_artifacts(self, mask: np.ndarray) -> np.ndarray:
        """Remove small isolated objects from mask"""
        if not ARTIFACT_CLEANING:
            return mask

        try:
            # Find all connected components
            num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
                mask, connectivity=8
            )

            if num_labels <= 1:
                return mask

            # Find the largest component (main object)
            # Skip label 0 (background)
            areas = stats[1:, cv2.CC_STAT_AREA]
            if len(areas) == 0:
                return mask

            max_area = np.max(areas)
            min_allowed_area = max_area * MIN_OBJECT_AREA_RATIO

            # Create cleaned mask
            cleaned_mask = np.zeros_like(mask)

            for i in range(1, num_labels):
                area = stats[i, cv2.CC_STAT_AREA]
                if area >= min_allowed_area:
                    cleaned_mask[labels == i] = 1

            return cleaned_mask.astype(np.uint8)

        except Exception as e:
            print(f'    [WARN] Artifact cleaning failed: {e}')
            return mask

    def add_drop_shadow(self, img: Image.Image, mask: Image.Image) -> Image.Image:
        """Add drop shadow to product
        img: RGBA image with transparency OR RGB image
        mask: L mode mask (white = foreground)
        Returns: RGB image with background and shadow
        """
        if not SHADOW_ENABLED:
            # Just composite with background, no shadow
            return self.composite_with_background(img, mask)

        try:
            # Create shadow layer
            shadow_layer = Image.new('RGBA', img.size, (*SHADOW_COLOR, 120))
            shadow_layer.putalpha(mask)

            # Apply gaussian blur to shadow
            shadow_layer = shadow_layer.filter(ImageFilter.GaussianBlur(radius=SHADOW_BLUR))

            # Create result with gradient or solid background
            if self.gradient_enabled:
                bg = self.create_gradient_background_fast(img.size)
                result = bg.convert('RGBA')
            else:
                result = Image.new('RGBA', img.size, (*self.bg_color, 255))

            # Paste shadow with offset
            result.paste(shadow_layer, SHADOW_OFFSET, shadow_layer)

            # Paste original image on top
            if img.mode == 'RGBA':
                # Use image's own alpha
                result = Image.alpha_composite(result, img)
            else:
                # Use provided mask
                img_rgba = img.convert('RGBA')
                img_rgba.putalpha(mask)
                result = Image.alpha_composite(result, img_rgba)

            return result.convert('RGB')

        except Exception as e:
            print(f'    [WARN] Drop shadow failed: {e}')
            return self.composite_with_background(img, mask)

    def composite_with_background(self, img: Image.Image, mask: Image.Image) -> Image.Image:
        """Composite image with gradient or solid background (no shadow)"""
        try:
            # Use gradient or solid background
            if self.gradient_enabled:
                bg = self.create_gradient_background_fast(img.size).convert('RGBA')
            else:
                bg = Image.new('RGBA', img.size, (*self.bg_color, 255))

            if img.mode == 'RGBA':
                result = Image.alpha_composite(bg, img)
            else:
                img_rgba = img.convert('RGBA')
                img_rgba.putalpha(mask)
                result = Image.alpha_composite(bg, img_rgba)

            return result.convert('RGB')
        except:
            return img.convert('RGB') if img.mode != 'RGB' else img

    def remove_background_opencv(self, img: Image.Image) -> tuple:
        """Remove background using OpenCV GrabCut algorithm
        Returns: (result_image, mask_image) tuple
        """
        try:
            # Convert PIL to OpenCV
            img_array = np.array(img.convert('RGB'))
            img_cv = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)

            h, w = img_cv.shape[:2]

            # Create mask
            mask = np.zeros((h, w), np.uint8)

            # Background model
            bgd_model = np.zeros((1, 65), np.float64)
            fgd_model = np.zeros((1, 65), np.float64)

            # Define rectangle for foreground (leave 5% margin)
            margin = int(min(h, w) * 0.05)
            rect = (margin, margin, w - 2*margin, h - 2*margin)

            # Apply GrabCut
            cv2.grabCut(img_cv, mask, rect, bgd_model, fgd_model, 5, cv2.GC_INIT_WITH_RECT)

            # Create binary mask (0,2 = background, 1,3 = foreground)
            mask2 = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')

            # Clean artifacts - remove small isolated objects
            mask2 = self.clean_artifacts(mask2)

            # Apply mask
            img_cv = img_cv * mask2[:, :, np.newaxis]

            # Create background with configured color
            bg = np.ones_like(img_cv) * np.array(self.bg_color[::-1])  # BGR

            # Combine: where mask is 0, use background
            result = np.where(mask2[:, :, np.newaxis] == 1, img_cv, bg)

            # Convert back to PIL
            result_rgb = cv2.cvtColor(result.astype(np.uint8), cv2.COLOR_BGR2RGB)
            result_img = Image.fromarray(result_rgb)

            # Create PIL mask for shadow
            pil_mask = Image.fromarray((mask2 * 255).astype(np.uint8))

            return result_img, pil_mask

        except Exception as e:
            print(f'    [WARN] OpenCV BG removal failed: {e}')
            if img.mode != 'RGB':
                img = img.convert('RGB')
            # Return image with full mask (no transparency)
            return img, Image.new('L', img.size, 255)

    def remove_background_rembg(self, img: Image.Image) -> tuple:
        """Remove background using rembg (AI-based) with isnet-general-use model
        Returns: (rgba_image, mask_image) tuple - RGBA with transparency, NOT composited
        """
        try:
            # Use isnet-general-use session for better quality
            result_img = rembg_remove(img, session=REMBG_SESSION)

            if result_img.mode != 'RGBA':
                result_img = result_img.convert('RGBA')

            # Extract alpha channel as mask
            r, g, b, a = result_img.split()
            mask_array = np.array(a)

            # Clean artifacts from mask
            mask_binary = (mask_array > 128).astype(np.uint8)
            mask_cleaned = self.clean_artifacts(mask_binary)
            pil_mask = Image.fromarray((mask_cleaned * 255).astype(np.uint8))

            # Apply cleaned mask back to image
            result_img.putalpha(pil_mask)

            # Return RGBA image (NOT composited) and mask
            return result_img, pil_mask

        except Exception as e:
            print(f'    [WARN] rembg failed: {e}')
            # Fallback to OpenCV
            return self.remove_background_opencv(img)

    def remove_background(self, img: Image.Image) -> tuple:
        """Remove background using best available method
        Returns: (result_image, mask_image) tuple
        """
        if self.method == 'rembg' and REMBG_AVAILABLE:
            return self.remove_background_rembg(img)
        else:
            return self.remove_background_opencv(img)

    def apply_contrast_enhancement(self, img: Image.Image) -> Image.Image:
        """Apply professional contrast and color enhancement - NO rotation/perspective"""

        # Ensure RGB mode
        if img.mode != 'RGB':
            if img.mode == 'RGBA':
                white_bg = Image.new('RGB', img.size, (255, 255, 255))
                white_bg.paste(img, mask=img.split()[3])
                img = white_bg
            else:
                img = img.convert('RGB')

        # 1. Contrast enhancement (noticeable but natural: 105-115%)
        contrast = random.uniform(1.05, 1.15)
        img = ImageEnhance.Contrast(img).enhance(contrast)

        # 2. Brightness adjustment (subtle: 100-105%)
        brightness = random.uniform(1.0, 1.05)
        img = ImageEnhance.Brightness(img).enhance(brightness)

        # 3. Color saturation boost (105-115% for vibrant look)
        saturation = random.uniform(1.05, 1.15)
        img = ImageEnhance.Color(img).enhance(saturation)

        # 4. Sharpening for professional look
        img = img.filter(ImageFilter.UnsharpMask(radius=1.5, percent=80, threshold=2))

        # 5. Auto-adjust levels (optional - makes colors pop)
        img = ImageOps.autocontrast(img, cutoff=1)

        return img

    def add_gradient_frame(self, img: Image.Image) -> Image.Image:
        """Add gradient frame around image (no background removal)
        Preserves product integrity - just adds branded frame
        """
        try:
            # Ensure RGB
            if img.mode != 'RGB':
                if img.mode == 'RGBA':
                    white_bg = Image.new('RGB', img.size, (255, 255, 255))
                    white_bg.paste(img, mask=img.split()[3])
                    img = white_bg
                else:
                    img = img.convert('RGB')

            # Calculate new size with padding
            orig_w, orig_h = img.size
            padding = int(min(orig_w, orig_h) * FRAME_PADDING_PERCENT / 100)
            border = FRAME_BORDER_WIDTH

            new_w = orig_w + 2 * (padding + border)
            new_h = orig_h + 2 * (padding + border)

            # Create gradient background
            if self.gradient_enabled:
                result = self.create_gradient_background_fast((new_w, new_h))
            else:
                result = Image.new('RGB', (new_w, new_h), self.bg_color)

            # Create inner white/light area for the image
            inner_x = border
            inner_y = border
            inner_w = orig_w + 2 * padding
            inner_h = orig_h + 2 * padding

            # Draw inner rectangle (slightly lighter than white for depth)
            inner_bg = Image.new('RGB', (inner_w, inner_h), (252, 252, 252))
            result.paste(inner_bg, (inner_x, inner_y))

            # Paste original image centered
            img_x = border + padding
            img_y = border + padding
            result.paste(img, (img_x, img_y))

            return result

        except Exception as e:
            print(f'    [WARN] Frame failed: {e}')
            return img

    def apply_duplicate_prevention(self, img: Image.Image) -> Image.Image:
        """Apply transformations to prevent Vinted duplicate detection

        Applies subtle but effective changes:
        - Random rotation (-3 to +3 degrees)
        - Contrast adjustment (97-103%)
        - Brightness adjustment (98-102%)
        - Random horizontal flip (30% chance)
        - Small crop/zoom (2% from edges)

        These changes are imperceptible to humans but break image hash matching.
        """
        if not DUPLICATE_PREVENTION:
            return img

        try:
            # Ensure RGB
            if img.mode != 'RGB':
                if img.mode == 'RGBA':
                    white_bg = Image.new('RGB', img.size, (255, 255, 255))
                    white_bg.paste(img, mask=img.split()[3])
                    img = white_bg
                else:
                    img = img.convert('RGB')

            orig_w, orig_h = img.size

            # 1. Random rotation (-3 to +3 degrees)
            rotation = random.uniform(*ROTATION_RANGE)
            img = img.rotate(rotation, resample=Image.BICUBIC, expand=False, fillcolor=(255, 255, 255))

            # 2. Random horizontal flip (30% chance)
            if random.random() < HORIZONTAL_FLIP_CHANCE:
                img = ImageOps.mirror(img)

            # 3. Contrast adjustment (97-103%)
            contrast_factor = random.uniform(*CONTRAST_RANGE)
            img = ImageEnhance.Contrast(img).enhance(contrast_factor)

            # 4. Brightness adjustment (98-102%)
            brightness_factor = random.uniform(*BRIGHTNESS_RANGE)
            img = ImageEnhance.Brightness(img).enhance(brightness_factor)

            # 5. Crop/zoom effect (2% from edges)
            if CROP_PERCENT > 0:
                crop_px_w = int(orig_w * CROP_PERCENT / 100)
                crop_px_h = int(orig_h * CROP_PERCENT / 100)

                # Crop from edges
                cropped = img.crop((crop_px_w, crop_px_h, orig_w - crop_px_w, orig_h - crop_px_h))

                # Resize back to original size (zoom effect)
                img = cropped.resize((orig_w, orig_h), Image.LANCZOS)

            # 6. Add tiny noise to break exact hash (imperceptible)
            img_array = np.array(img)
            noise = np.random.randint(-2, 3, img_array.shape, dtype=np.int16)
            img_array = np.clip(img_array.astype(np.int16) + noise, 0, 255).astype(np.uint8)
            img = Image.fromarray(img_array)

            return img

        except Exception as e:
            print(f'    [WARN] Duplicate prevention failed: {e}')
            return img

    def process_image(self, src_path: str, dst_path: str) -> tuple:
        """Process single image - gradient frame OR background removal
        Returns: (success: bool, is_label: bool)
        """
        try:
            img = Image.open(src_path)

            # Step 0: Check if this is a label/tag image
            if self.is_label_image(img):
                print('[LABEL]', end=' ')
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                img.save(dst_path, 'JPEG', quality=95)
                return True, True

            # Step 1: Apply duplicate prevention FIRST (before any framing)
            # This ensures each image has unique characteristics
            if DUPLICATE_PREVENTION:
                img = self.apply_duplicate_prevention(img)

            # Step 2: Choose processing method
            if BG_REMOVAL_ENABLED:
                # Method 1: Background removal (may damage product)
                result_img, mask = self.remove_background(img)
                result_img = self.add_drop_shadow(result_img, mask)
            else:
                # Method 2: Gradient frame (preserves product integrity)
                result_img = self.add_gradient_frame(img)

            # Step 3: Apply contrast enhancement only if enabled
            if CONTRAST_ENHANCEMENT:
                result_img = self.apply_contrast_enhancement(result_img)

            # Save with high quality
            result_img.save(dst_path, 'JPEG', quality=95)
            return True, False

        except Exception as e:
            print(f'    [ERR] {e}')
            return False, False

    def process_product(self, product_id: int) -> bool:
        """Process all images for a product"""
        product = db.get_product(product_id)
        if not product:
            return False

        raw_path = product.get('raw_images_path', '')
        if not raw_path or not os.path.exists(raw_path):
            print(f'  [SKIP] No images: {product_id}')
            return False

        vinted_id = product.get('vinted_id', str(product_id))
        proc_path = os.path.join(PROCESSED_DIR, vinted_id)
        os.makedirs(proc_path, exist_ok=True)

        count = 0
        label_count = 0
        files = sorted([f for f in os.listdir(raw_path) if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp'))])

        for i, fname in enumerate(files):
            src = os.path.join(raw_path, fname)
            dst_name = os.path.splitext(fname)[0] + '.jpg'
            dst = os.path.join(proc_path, dst_name)

            print(f'    [{i+1}/{len(files)}] {fname}...', end=' ')
            success, is_label = self.process_image(src, dst)
            if success:
                count += 1
                if is_label:
                    label_count += 1
                print('OK')
            else:
                print('FAIL')

        if count > 0:
            db.update_product(product_id, {
                'processed_images_path': proc_path,
                'status': STATUS_IMAGE_DONE,
                'image_count': count
            })
            features = [f'BG:{self.method}', 'Shadow' if SHADOW_ENABLED else '', 'ArtifactClean' if ARTIFACT_CLEANING else '']
            features = [f for f in features if f]
            mode = ' + '.join(features)
            log_msg = f'{count} images ({label_count} labels): {mode}'
            db.add_log(product_id, 'image', 'success', log_msg)
            print(f'  [OK] Product {product_id}: {count} images ({label_count} labels)')
            return True

        return False

    def run(self) -> int:
        """Process all RAW status products"""
        print('=' * 60)
        print('IMAGE PROCESSOR v2.1 - Original Colors')
        print('=' * 60)
        print(f'Background: {self.method.upper()} removal → RGB{self.bg_color}')
        print(f'Features: Shadow={SHADOW_ENABLED}, ArtifactClean={ARTIFACT_CLEANING}, Contrast={CONTRAST_ENHANCEMENT}')
        print()

        products = db.get_products_by_status(STATUS_RAW)
        print(f'{len(products)} products to process')

        done = 0
        for p in products:
            title = p.get('raw_title', '')[:40]
            print(f'\n[{done+1}/{len(products)}] {title}')
            if self.process_product(p['id']):
                done += 1

        print(f'\n{"="*60}')
        print(f'DONE: {done}/{len(products)} products processed')
        print('=' * 60)
        return done


def main():
    return ImageProcessor().run()


if __name__ == '__main__':
    main()
