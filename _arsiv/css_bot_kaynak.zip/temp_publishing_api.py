"""
TATANGA V3 - Publishing API
Manage product publications to target platforms
Now with real CSS Berlin integration!
"""
from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, func
from database import get_db
from models import Publication, Product, Favorite
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
import random
import asyncio

# Import CSS Berlin connector
try:
    from connectors.cssberlin import publish_to_cssberlin
    CSSBERLIN_AVAILABLE = True
except ImportError:
    CSSBERLIN_AVAILABLE = False
    print("[WARNING] CSS Berlin connector not available")

router = APIRouter()


def generate_pub_id():
    date_str = datetime.now().strftime("%Y%m%d")
    seq = str(random.randint(1, 9999)).zfill(4)
    return f"PUB-{date_str}-{seq}"


class CreatePublicationRequest(BaseModel):
    product_id: int
    platform: str
    listing_url: Optional[str] = None
    platform_listing_id: Optional[str] = None
    sale_price: Optional[float] = None
    seo_title: Optional[str] = None
    seo_description: Optional[str] = None


class UpdatePublicationRequest(BaseModel):
    listing_url: Optional[str] = None
    platform_listing_id: Optional[str] = None
    status: Optional[str] = None
    sale_price: Optional[float] = None


class PublishRequest(BaseModel):
    """Request to publish a product to multiple platforms"""
    product_id: int
    platforms: List[str]
    sale_price: float
    seo_title: Optional[str] = None
    seo_description: Optional[str] = None


async def publish_to_platform(
    platform: str,
    product_data: dict,
    images: List[str]
) -> dict:
    """Publish to a specific platform"""
    platform_lower = platform.lower()

    if platform_lower in ["cssberlin", "cssberlin.de", "css"]:
        if CSSBERLIN_AVAILABLE:
            return await publish_to_cssberlin(product_data, images)
        else:
            return {"success": False, "error": "CSS Berlin connector not available"}

    elif platform_lower == "vinted":
        return {"success": False, "error": "Vinted auto-publish not yet implemented"}

    elif platform_lower == "ebay":
        return {"success": False, "error": "eBay auto-publish not yet implemented"}

    elif platform_lower == "kleinanzeigen":
        return {"success": False, "error": "Kleinanzeigen auto-publish not yet implemented"}

    else:
        return {"success": False, "error": f"Unknown platform: {platform}"}


@router.get("/")
async def get_publications(
    status: Optional[str] = None,
    platform: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """Get all publications with optional filters"""
    query = select(Publication).order_by(desc(Publication.published_at))

    if status:
        query = query.where(Publication.status == status)
    if platform:
        query = query.where(Publication.platform == platform)

    query = query.offset(skip).limit(limit)
    result = await db.execute(query)
    publications = result.scalars().all()

    response = []
    for pub in publications:
        prod_result = await db.execute(select(Product).where(Product.id == pub.product_id))
        product = prod_result.scalar_one_or_none()

        product_image = None
        if product and product.images:
            images = product.images if isinstance(product.images, list) else []
            if images:
                product_image = images[0]

        response.append({
            "id": pub.id,
            "pub_id": pub.pub_id,
            "product_id": pub.product_id,
            "product_title": product.title if product else None,
            "product_image": product_image,
            "platform": pub.platform,
            "listing_url": pub.listing_url,
            "platform_listing_id": pub.platform_listing_id,
            "status": pub.status,
            "sale_price": float(pub.sale_price) if pub.sale_price else None,
            "published_at": pub.published_at,
            "sold_at": pub.sold_at
        })

    return response


@router.post("/")
async def create_publication(
    request: CreatePublicationRequest,
    db: AsyncSession = Depends(get_db)
):
    """Create a new publication record (without auto-publish)"""
    prod_result = await db.execute(select(Product).where(Product.id == request.product_id))
    product = prod_result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    existing = await db.execute(
        select(Publication).where(
            Publication.product_id == request.product_id,
            Publication.platform == request.platform,
            Publication.status == "active"
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Product already published on this platform")

    publication = Publication(
        product_id=request.product_id,
        pub_id=generate_pub_id(),
        platform=request.platform,
        listing_url=request.listing_url,
        platform_listing_id=request.platform_listing_id,
        sale_price=request.sale_price,
        status="active"
    )

    db.add(publication)
    product.status = "published"

    await db.commit()
    await db.refresh(publication)

    return {
        "message": "Publication created",
        "pub_id": publication.pub_id,
        "publication_id": publication.id
    }


@router.post("/publish")
async def publish_product(
    request: PublishRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    Publish a product to multiple platforms with real API integration
    This is the main endpoint for actual publishing!
    """
    prod_result = await db.execute(select(Product).where(Product.id == request.product_id))
    product = prod_result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    product_data = {
        "title": request.seo_title or product.title,
        "name": product.title,
        "brand": product.brand or "Unbekannt",
        "category": product.category or "Damen",
        "condition": product.condition or "Gut",
        "size": product.size or "M",
        "price": request.sale_price,
        "description": request.seo_description or product.description or ""
    }

    images = product.images if isinstance(product.images, list) else []

    results = []
    publications_created = []

    for platform in request.platforms:
        existing = await db.execute(
            select(Publication).where(
                Publication.product_id == request.product_id,
                Publication.platform == platform,
                Publication.status == "active"
            )
        )
        if existing.scalar_one_or_none():
            results.append({
                "platform": platform,
                "success": False,
                "error": "Already published on this platform"
            })
            continue

        result = await publish_to_platform(platform, product_data, images)
        results.append(result)

        if result.get("success"):
            publication = Publication(
                product_id=request.product_id,
                pub_id=generate_pub_id(),
                platform=platform,
                listing_url=result.get("listing_url"),
                platform_listing_id=result.get("product_id"),
                sale_price=request.sale_price,
                status="active"
            )
            db.add(publication)
            publications_created.append(publication)

    if publications_created:
        product.status = "published"
        await db.commit()

        for pub in publications_created:
            await db.refresh(pub)

    return {
        "message": f"Published to {len([r for r in results if r.get('success')])} of {len(request.platforms)} platforms",
        "results": results,
        "publications": [
            {"pub_id": p.pub_id, "platform": p.platform, "listing_url": p.listing_url}
            for p in publications_created
        ]
    }


@router.get("/stats")
async def get_publishing_stats(db: AsyncSession = Depends(get_db)):
    """Get publishing statistics"""
    total = await db.execute(select(func.count()).select_from(Publication))
    active = await db.execute(
        select(func.count()).select_from(Publication).where(Publication.status == "active")
    )
    sold = await db.execute(
        select(func.count()).select_from(Publication).where(Publication.status == "sold")
    )

    revenue_result = await db.execute(
        select(func.sum(Publication.sale_price))
        .where(Publication.status == "sold")
    )
    total_revenue = revenue_result.scalar() or 0

    platform_stats = []
    platforms = ["cssberlin", "vinted", "ebay", "kleinanzeigen", "willhaben"]
    for platform in platforms:
        count_result = await db.execute(
            select(func.count())
            .select_from(Publication)
            .where(Publication.platform == platform)
        )
        active_result = await db.execute(
            select(func.count())
            .select_from(Publication)
            .where(Publication.platform == platform, Publication.status == "active")
        )
        platform_stats.append({
            "platform": platform,
            "total": count_result.scalar(),
            "active": active_result.scalar()
        })

    return {
        "total_publications": total.scalar(),
        "active": active.scalar(),
        "sold": sold.scalar(),
        "total_revenue": float(total_revenue),
        "platforms": platform_stats,
        "connectors": {
            "cssberlin": CSSBERLIN_AVAILABLE,
            "vinted": False,
            "ebay": False,
            "kleinanzeigen": False
        }
    }


@router.get("/ready-to-publish")
async def get_ready_to_publish(db: AsyncSession = Depends(get_db)):
    """Get favorites that are ready to be published"""
    fav_result = await db.execute(
        select(Favorite)
        .where(Favorite.processed == False)
        .order_by(desc(Favorite.added_at))
    )
    favorites = fav_result.scalars().all()

    ready_items = []
    for fav in favorites:
        prod_result = await db.execute(select(Product).where(Product.id == fav.product_id))
        product = prod_result.scalar_one_or_none()
        if product:
            ready_items.append({
                "favorite_id": fav.id,
                "fav_id": fav.fav_id,
                "product_id": product.id,
                "title": product.title,
                "source_url": product.source_url,
                "original_price": float(product.price) if product.price else None,
                "suggested_price": float(fav.suggested_price) if fav.suggested_price else None,
                "manual_price": float(fav.manual_price) if fav.manual_price else None,
                "images": product.images
            })

    return ready_items


@router.get("/{publication_id}")
async def get_publication(publication_id: int, db: AsyncSession = Depends(get_db)):
    """Get a specific publication"""
    result = await db.execute(select(Publication).where(Publication.id == publication_id))
    publication = result.scalar_one_or_none()
    if not publication:
        raise HTTPException(status_code=404, detail="Publication not found")
    return publication


@router.patch("/{publication_id}")
async def update_publication(
    publication_id: int,
    request: UpdatePublicationRequest,
    db: AsyncSession = Depends(get_db)
):
    """Update a publication"""
    result = await db.execute(select(Publication).where(Publication.id == publication_id))
    publication = result.scalar_one_or_none()
    if not publication:
        raise HTTPException(status_code=404, detail="Publication not found")

    if request.listing_url:
        publication.listing_url = request.listing_url
    if request.platform_listing_id:
        publication.platform_listing_id = request.platform_listing_id
    if request.status:
        publication.status = request.status
    if request.sale_price is not None:
        publication.sale_price = request.sale_price

    await db.commit()
    return {"message": "Publication updated"}


@router.post("/{publication_id}/sold")
async def mark_as_sold(
    publication_id: int,
    sale_price: Optional[float] = None,
    db: AsyncSession = Depends(get_db)
):
    """Mark a publication as sold"""
    result = await db.execute(select(Publication).where(Publication.id == publication_id))
    publication = result.scalar_one_or_none()
    if not publication:
        raise HTTPException(status_code=404, detail="Publication not found")

    publication.status = "sold"
    publication.sold_at = datetime.utcnow()
    if sale_price is not None:
        publication.sale_price = sale_price

    prod_result = await db.execute(select(Product).where(Product.id == publication.product_id))
    product = prod_result.scalar_one_or_none()
    if product:
        product.status = "sold"

    await db.commit()
    return {"message": "Publication marked as sold"}


@router.delete("/{publication_id}")
async def delete_publication(publication_id: int, db: AsyncSession = Depends(get_db)):
    """Delete a publication"""
    result = await db.execute(select(Publication).where(Publication.id == publication_id))
    publication = result.scalar_one_or_none()
    if not publication:
        raise HTTPException(status_code=404, detail="Publication not found")

    await db.delete(publication)
    await db.commit()
    return {"message": "Publication deleted"}
