"""
TATANGA V3 - Sellpy Human Scraper
İnsan-benzeri davranışlarla Sellpy'den ürün kazıma
"""
from human_scraper_base import HumanScraper, LOG_DIR
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from datetime import datetime
from typing import List, Dict, Optional
import time
import random
import re
import urllib.parse


class SellpyScraper(HumanScraper):
    """Sellpy için insan-benzeri scraper"""

    BASE_URL = "https://www.sellpy.de"

    # Sıralama seçenekleri
    SORT_OPTIONS = {
        "relevance": "relevance",
        "newest": "newest",
        "price_low": "price-low",
        "price_high": "price-high",
    }

    # Durum filtreleri
    CONDITIONS = {
        "new": "new",
        "very_good": "very-good",
        "good": "good",
    }

    def __init__(self, headless: bool = True):
        super().__init__("sellpy", headless)
        self.products_found = []
        self.visited_urls = set()

    def build_search_url(self, query: str, page: int = 1,
                         min_price: float = None, max_price: float = None,
                         condition: str = None, sort: str = None) -> str:
        """
        Sellpy arama URL'si oluştur
        """
        params = {
            "q": query,
        }

        if page > 1:
            params["page"] = page
        if min_price:
            params["minPrice"] = int(min_price)
        if max_price:
            params["maxPrice"] = int(max_price)
        if condition and condition in self.CONDITIONS:
            params["condition"] = self.CONDITIONS[condition]
        if sort and sort in self.SORT_OPTIONS:
            params["sort"] = self.SORT_OPTIONS[sort]

        query_string = urllib.parse.urlencode(params)
        return f"{self.BASE_URL}/search?{query_string}"

    def go_to_homepage(self):
        """Sellpy ana sayfasına git"""
        self.log("Sellpy ana sayfasına gidiliyor...")
        self.visit_url(self.BASE_URL)
        self.screenshot("homepage")
        self.random_delay(1, 2)
        self.close_cookie_banner()

    def close_cookie_banner(self, selectors: list = None):
        """Sellpy cookie banner'ı kapat"""
        sellpy_selectors = [
            "[data-testid='cookie-accept']",
            "button[id*='accept']",
            "#onetrust-accept-btn-handler",
            "[class*='cookie'] button",
            "button:contains('Akzeptieren')",
        ]
        super().close_cookie_banner(sellpy_selectors + (selectors or []))

    def get_product_elements(self) -> list:
        """Sayfadaki ürün elementlerini al"""
        selectors = [
            "[data-testid='product-card']",
            ".product-card",
            "article[class*='product']",
            "[class*='ProductCard']",
            "a[href*='/item/']",
        ]

        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    self.log(f"{len(elements)} ürün elementi bulundu ({selector})")
                    return elements
            except:
                pass

        return []

    def extract_product_data(self, element) -> Optional[Dict]:
        """Ürün elementinden veri çıkar"""
        try:
            # URL
            url = None
            try:
                if element.tag_name == "a":
                    url = element.get_attribute("href")
                else:
                    link = element.find_element(By.CSS_SELECTOR, "a[href*='/item/']")
                    url = link.get_attribute("href")
            except:
                pass

            if not url:
                return None

            # Full URL oluştur
            if url.startswith("/"):
                url = f"{self.BASE_URL}{url}"

            # Zaten gördük mü?
            if url in self.visited_urls:
                return None
            self.visited_urls.add(url)

            # Başlık
            title = None
            title_selectors = [
                "[data-testid='product-title']",
                ".product-title",
                "h3",
                "h2",
                "[class*='title']",
            ]
            for sel in title_selectors:
                try:
                    title_elem = element.find_element(By.CSS_SELECTOR, sel)
                    title = title_elem.text.strip()
                    if title:
                        break
                except:
                    pass

            if not title:
                try:
                    title = element.text.split("\n")[0].strip()
                except:
                    pass

            if not title:
                return None

            # Fiyat
            price = None
            price_selectors = [
                "[data-testid='product-price']",
                ".product-price",
                "[class*='Price']",
                "span[class*='price']",
            ]
            for sel in price_selectors:
                try:
                    price_elem = element.find_element(By.CSS_SELECTOR, sel)
                    price_text = price_elem.text
                    # "15,00 €" veya "15 €"
                    price_match = re.search(r"([\d.,]+)\s*€", price_text)
                    if price_match:
                        price = float(price_match.group(1).replace(".", "").replace(",", "."))
                        break
                except:
                    pass

            # Resim
            image_url = None
            try:
                img = element.find_element(By.CSS_SELECTOR, "img")
                image_url = img.get_attribute("src") or img.get_attribute("data-src")
            except:
                pass

            # Marka
            brand = None
            try:
                brand_elem = element.find_element(By.CSS_SELECTOR, "[data-testid='product-brand'], .brand")
                brand = brand_elem.text.strip()
            except:
                pass

            # Beden
            size = None
            try:
                size_elem = element.find_element(By.CSS_SELECTOR, "[data-testid='product-size'], .size")
                size = size_elem.text.strip()
            except:
                pass

            return {
                "url": url,
                "title": title,
                "price": price,
                "brand": brand,
                "size": size,
                "image": image_url,
                "platform": "sellpy",
                "scraped_at": datetime.now().isoformat()
            }

        except Exception as e:
            self.log(f"Ürün verisi çıkarma hatası: {e}", "debug")
            return None

    def extract_all_products(self) -> List[Dict]:
        """Sayfadaki tüm ürünleri çıkar"""
        elements = self.get_product_elements()
        products = []

        for element in elements:
            product = self.extract_product_data(element)
            if product and product["url"] not in [p["url"] for p in self.products_found]:
                products.append(product)
                self.products_found.append(product)

        self.log(f"{len(products)} yeni ürün çıkarıldı (Toplam: {len(self.products_found)})")
        return products

    def load_more_products(self) -> bool:
        """Daha fazla ürün yükle (infinite scroll)"""
        initial_count = len(self.get_product_elements())

        # Scroll
        for _ in range(3):
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            self.random_delay(1.5, 2.5)

            new_count = len(self.get_product_elements())
            if new_count > initial_count:
                self.log(f"Yeni ürünler yüklendi: {initial_count} -> {new_count}")
                return True

        # Load more butonu
        load_more_selectors = [
            "button[data-testid='load-more']",
            "[class*='load-more'] button",
            "button:contains('mehr')",
        ]

        for selector in load_more_selectors:
            try:
                btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.human_click(btn)
                    self.random_delay(2, 4)
                    return True
            except:
                pass

        return False

    def visit_random_product(self, visit_seller: bool = True) -> Optional[Dict]:
        """
        Rastgele bir ürüne git ve satıcı/marka profilini ziyaret et
        """
        elements = self.get_product_elements()
        if not elements:
            self.log("Ürün elementi bulunamadı")
            return None

        random_elements = random.sample(elements[:min(10, len(elements))], 1)
        element = random_elements[0]

        product_data = self.extract_product_data(element)
        if not product_data:
            return None

        self.log(f"=== RASTGELE ÜRÜN ZİYARETİ ===")
        self.log(f"Ürün: {product_data['title'][:50]}...")

        self.mouse_zigzag(element)
        self.random_delay(0.3, 0.6)

        self.visit_url(product_data["url"])
        self.random_delay(2, 4)
        self.screenshot("product_page")

        self.human_scroll("down", random.randint(200, 400))
        self.random_delay(1, 2)

        self.human_scroll("down", random.randint(100, 300))
        self.random_delay(0.5, 1.5)

        # Sellpy'de satıcı yok ama marka kategorisine bakabiliriz
        if visit_seller:
            self._visit_brand_page()

        self.random_delay(1, 2)
        self.go_back()
        self.random_delay(1, 2)

        self.log(f"=== RASTGELE ZİYARET TAMAMLANDI ===")
        return product_data

    def _visit_brand_page(self) -> bool:
        """Sellpy marka sayfasını ziyaret et"""
        brand_selectors = [
            "a[href*='/brand/']",
            "a[href*='/brands/']",
            "[data-testid='brand-link']",
            ".product-brand a",
            "[class*='brand'] a",
        ]

        for selector in brand_selectors:
            try:
                links = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for link in links:
                    if link.is_displayed():
                        href = link.get_attribute("href") or ""
                        if "brand" in href:
                            self.log(f"Marka sayfasına gidiliyor: {href[:50]}...")
                            self.mouse_zigzag(link)
                            self.human_click(link)
                            self.random_delay(2, 4)
                            self.screenshot("brand_page")

                            self.human_scroll("down", random.randint(300, 500))
                            self.random_delay(1, 3)

                            self.go_back()
                            self.random_delay(1, 2)
                            self.log("Marka sayfası ziyareti tamamlandı")
                            return True
            except:
                continue

        self.log("Marka sayfası bulunamadı", "debug")
        return False

    def scrape(self, query: str, max_products: int = None, max_pages: int = None,
               visit_products: bool = True, min_price: float = None,
               max_price: float = None, condition: str = None,
               conditions: list = None, sort: str = "newest") -> List[Dict]:
        """
        Ana kazıma fonksiyonu
        condition: Tek durum (str) - "sehr gut", "gut" vb.
        conditions: Çoklu durum listesi ["sehr gut", "gut"] - ilk eleman kullanılır
        """
        self.log(f"=== KAZIMA BAŞLIYOR ===")
        self.log(f"Arama: {query}")
        self.log(f"Max ürün: {max_products or 'Sınırsız'}")

        try:
            page = 1

            # İlk sayfa URL'si
            url = self.build_search_url(
                query=query,
                page=page,
                min_price=min_price,
                max_price=max_price,
                condition=condition,
                sort=sort
            )

            self.log(f"--- Sayfa {page} ---")
            self.visit_url(url)
            self.close_cookie_banner()
            self.random_delay(2, 3)

            # === İLK SAYFA: HER ZAMAN BİR ÜRÜN VE MARKA SAYFASI ZİYARET ET ===
            self.log("=== İLK SAYFA RASTGELE GEZİNME ===")
            self.human_scroll("down", random.randint(300, 500))
            self.random_delay(1, 2)

            self.log("İlk sayfa: Rastgele ürün ziyareti...")
            self.visit_random_product(visit_seller=True)

            while True:
                self.log(f"--- Sayfa {page} ---")

                # Scroll yap
                self.human_scroll("down", random.randint(300, 500))
                self.random_delay(1, 2)

                # Zigzag mouse hareketi
                if random.random() < 0.3:
                    try:
                        elements = self.get_product_elements()
                        if elements:
                            random_elem = random.choice(elements[:5])
                            self.mouse_zigzag(random_elem)
                    except:
                        pass

                # Ürünleri çıkar
                before_count = len(self.products_found)
                self.extract_all_products()
                after_count = len(self.products_found)
                new_products = after_count - before_count

                self.log(f"+{new_products} yeni ürün (Toplam: {after_count})")

                # Limit kontrolü
                if max_products and len(self.products_found) >= max_products:
                    self.log(f"Maksimum ürün sayısına ulaşıldı: {max_products}")
                    break

                if max_pages and page >= max_pages:
                    self.log(f"Maksimum sayfa sayısına ulaşıldı: {max_pages}")
                    break

                # Boş sayfa kontrolü
                if new_products == 0:
                    self.log("Boş sayfa, kazıma durduruluyor...")
                    break

                # Sonraki sayfalarda rastgele ürün ziyareti (%30 ihtimalle)
                if visit_products and page > 1 and random.random() < 0.3:
                    self.visit_random_product(visit_seller=True)

                # İnsansı bekleme
                self.random_delay(2, 4)

                # Sonraki sayfa
                page += 1
                url = self.build_search_url(
                    query=query,
                    page=page,
                    min_price=min_price,
                    max_price=max_price,
                    condition=condition,
                    sort=sort
                )
                self.visit_url(url)
                self.random_delay(2, 3)

            self.log(f"=== KAZIMA TAMAMLANDI ===")
            self.log(f"Toplam ürün: {len(self.products_found)}")
            self.screenshot("scraping_complete")

            return self.products_found

        except Exception as e:
            self.log(f"Kazıma hatası: {e}", "error")
            self.screenshot("error")
            raise


def run_sellpy_scrape(query: str, max_products: int = None, headless: bool = True) -> List[Dict]:
    """Sellpy kazıma işlemini çalıştır"""
    with SellpyScraper(headless=headless) as scraper:
        return scraper.scrape(query, max_products=max_products)


if __name__ == "__main__":
    import sys

    query = sys.argv[1] if len(sys.argv) > 1 else "nike"
    max_items = int(sys.argv[2]) if len(sys.argv) > 2 else 50

    print(f"Sellpy kazıma başlıyor: {query}")
    products = run_sellpy_scrape(query, max_products=max_items, headless=True)

    print(f"\n{len(products)} ürün bulundu:")
    for p in products[:5]:
        print(f"  - {p['title'][:40]} | {p['price']} EUR | {p['url']}")
