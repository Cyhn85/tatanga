# Flow 3: SEO Content Optimizer
# Optimizes title AND description with SEO hashtags
# v2.0 - Added sustainability/climate awareness messaging
import sys, os, json, time
import requests
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')

from config import GROQ_API_KEY, GROQ_MODEL, STATUS_IMAGE_DONE, STATUS_SEO_DONE
from utils.database import db

# ============================================================================
# SUSTAINABILITY MESSAGE (German) - Climate Awareness
# ============================================================================
SUSTAINABILITY_PARAGRAPH = """
🌍 Warum Second Hand? Mit diesem Artikel trägst du aktiv zum Klimaschutz bei!
Gebrauchte Kleidung und Accessoires sparen wertvolle Ressourcen und reduzieren
den CO₂-Fußabdruck. Ein gut erhaltenes Second-Hand-Stück schont nicht nur deinen
Geldbeutel, sondern auch unseren Planeten. Gemeinsam für eine nachhaltigere Zukunft! ♻️
"""

# Climate/Sustainability SEO Hashtags
CLIMATE_HASHTAGS = [
    '#SecondHand', '#Nachhaltigkeit', '#Sustainability', '#ClimateSmart',
    '#Recycling', '#CO2Footprint', '#Umweltschutz', '#CircularFashion',
    '#VintageStyle', '#SustainableFashion', '#GreenLiving', '#EcoFriendly'
]


class SEOGenerator:
    def __init__(self):
        self.api_key = GROQ_API_KEY
        self.model = GROQ_MODEL

    def call_groq(self, prompt: str, max_tokens: int = 500) -> str:
        """Call Groq API with prompt"""
        try:
            resp = requests.post(
                'https://api.groq.com/openai/v1/chat/completions',
                headers={
                    'Authorization': f'Bearer {self.api_key}',
                    'Content-Type': 'application/json'
                },
                json={
                    'model': self.model,
                    'messages': [{'role': 'user', 'content': prompt}],
                    'temperature': 0.3,
                    'max_tokens': max_tokens
                },
                timeout=30
            )
            if resp.status_code == 200:
                return resp.json()['choices'][0]['message']['content'].strip()
            else:
                print(f'  [ERR] Groq API: {resp.status_code}')
        except Exception as e:
            print(f'  [ERR] Groq: {e}')
        return ''

    def generate_seo_title(self, product: dict) -> str:
        """Generate SEO-optimized title"""
        title = product.get('raw_title', '')
        brand = product.get('brand', '')
        size = product.get('size', '')
        color = product.get('color', '')
        extra = product.get('extra_fields', {})

        if isinstance(extra, str):
            try:
                extra = json.loads(extra)
            except:
                extra = {}

        specs = []
        if extra.get('modell'):
            specs.append(extra['modell'])
        if extra.get('speicher'):
            specs.append(extra['speicher'])
        if size:
            specs.append(f"Gr. {size}")
        if color:
            specs.append(color)
        specs_text = ", ".join(specs) if specs else ""

        prompt = f"""Du bist ein Vinted SEO-Experte. Erstelle einen KURZEN, prägnanten Titel.

Original Titel: {title}
Marke: {brand}
Details: {specs_text}

REGELN:
1. Max 60 Zeichen
2. Format: Marke + Produkttyp + wichtigstes Merkmal
3. KEINE Füllwörter (elegant, schön, toll, original, praktisch)
4. Nur die wichtigsten Infos

Beispiele:
- "Huawei P30 Lite 128GB Blau"
- "Adidas Laufschuhe Gr. 46"

Antworte NUR mit dem neuen Titel."""

        new_title = self.call_groq(prompt, 100)
        if new_title:
            new_title = new_title.strip('"\'')
            if len(new_title) > 70:
                new_title = new_title[:67] + '...'
            return new_title
        return title[:70] if len(title) > 70 else title

    def generate_seo_description(self, product: dict) -> str:
        """Generate SEO-optimized description with hashtags + sustainability message"""
        raw_desc = product.get('raw_description', '')
        brand = product.get('brand', '')
        size = product.get('size', '')
        color = product.get('color', '')
        condition = product.get('condition', '')
        extra = product.get('extra_fields', {})

        if isinstance(extra, str):
            try:
                extra = json.loads(extra)
            except:
                extra = {}

        model = extra.get('modell', '')

        prompt = f"""Du bist ein Vinted SEO-Experte. Schreibe die Produktbeschreibung neu.

ORIGINAL BESCHREIBUNG:
{raw_desc}

PRODUKTINFOS:
- Marke: {brand}
- Modell: {model}
- Größe: {size}
- Farbe: {color}
- Zustand: {condition}

AUFGABE:
1. Schreibe die Beschreibung in natürlichem Deutsch neu
2. Behalte alle wichtigen Infos aus dem Original
3. Mache es lesbarer und ansprechender
4. Max 400 Zeichen für die Beschreibung
5. KEINE Hashtags hinzufügen (werden später ergänzt)

Antworte NUR mit der neuen Beschreibung (ohne Hashtags)."""

        new_desc = self.call_groq(prompt, 350)

        if new_desc:
            new_desc = new_desc.strip('"\'')
        else:
            new_desc = raw_desc

        # Build brand/product hashtags
        product_hashtags = []
        if brand:
            product_hashtags.append(f"#{brand.replace(' ', '')}")
        if model:
            product_hashtags.append(f"#{model.replace(' ', '')}")
        product_hashtags.append('#VintedDE')

        # Combine: description + sustainability + hashtags
        import random
        climate_tags = random.sample(CLIMATE_HASHTAGS, min(5, len(CLIMATE_HASHTAGS)))
        all_hashtags = product_hashtags + climate_tags

        final_description = f"""{new_desc}

{SUSTAINABILITY_PARAGRAPH.strip()}

{' '.join(all_hashtags)}"""

        return final_description

    def process_product(self, product_id: int) -> bool:
        """Process a single product for SEO - title AND description"""
        product = db.get_product(product_id)
        if not product:
            return False

        raw_title = product.get('raw_title', '')
        raw_description = product.get('raw_description', '')

        # Generate SEO title
        new_title = self.generate_seo_title(product)
        time.sleep(0.5)  # Rate limit between calls

        # Generate SEO description with hashtags
        new_description = self.generate_seo_description(product)

        db.update_product(product_id, {
            'processed_title': new_title,
            'processed_description': new_description,
            'status': STATUS_SEO_DONE
        })

        db.add_log(product_id, 'seo', 'success', 'Title + Description + Hashtags optimized')
        print(f'  [OK] {product_id}:')
        print(f'       Title: {new_title[:50]}')
        print(f'       Desc: {new_description[:80]}...')
        return True

    def run(self) -> int:
        """Process all IMAGE_DONE status products"""
        print('=' * 60)
        print('SEO OPTIMIZER - Title + Description + Hashtags')
        print('=' * 60)

        products = db.get_products_by_status(STATUS_IMAGE_DONE)
        print(f'{len(products)} products to process\n')

        done = 0
        for p in products:
            title = p.get('raw_title', '')[:40]
            print(f'[{done+1}/{len(products)}] {title}')
            if self.process_product(p['id']):
                done += 1
            time.sleep(1)  # Rate limit

        print(f'\n{"="*60}')
        print(f'DONE: {done}/{len(products)} products SEO optimized')
        print('=' * 60)
        return done


def main():
    return SEOGenerator().run()


if __name__ == '__main__':
    main()
