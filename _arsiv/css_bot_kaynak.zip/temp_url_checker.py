"""
TATANGA V3 - URL Checker Service
Periodically checks source URLs for availability
"""
import requests
from typing import Dict, List, Optional
from datetime import datetime
import logging
import re

logger = logging.getLogger("TATANGA.url_checker")

class URLChecker:
    """Lightweight URL checker - no browser needed for simple status checks"""

    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
        "Accept-Language": "de-DE,de;q=0.9,en;q=0.8"
    }

    # Status patterns for different platforms
    SOLD_PATTERNS = {
        "vinted": [
            r"sold|verkauft|vendu",
            r"nicht mehr verf",
            r"leider nicht mehr"
        ],
        "ebay": [
            r"Dieser Artikel wurde beendet",
            r"Angebot beendet",
            r"ist nicht mehr verf"
        ],
        "kleinanzeigen": [
            r"Diese Anzeige ist deaktiviert",
            r"Anzeige ist beendet",
            r"nicht mehr verf"
        ]
    }

    def detect_platform(self, url: str) -> Optional[str]:
        """Detect platform from URL"""
        url_lower = url.lower()
        if "vinted" in url_lower:
            return "vinted"
        elif "ebay" in url_lower:
            return "ebay"
        elif "kleinanzeigen" in url_lower:
            return "kleinanzeigen"
        return None

    def check_url(self, url: str) -> Dict:
        """Check if URL is still active"""
        result = {
            "url": url,
            "status": "unknown",
            "checked_at": datetime.now().isoformat(),
            "http_code": None,
            "error": None
        }

        try:
            response = requests.get(url, headers=self.HEADERS, timeout=15, allow_redirects=True)
            result["http_code"] = response.status_code

            if response.status_code == 404:
                result["status"] = "removed"
            elif response.status_code == 410:
                result["status"] = "removed"
            elif response.status_code >= 400:
                result["status"] = "error"
                result["error"] = f"HTTP {response.status_code}"
            else:
                # Check content for sold/removed patterns
                platform = self.detect_platform(url)
                content = response.text.lower()

                if platform and platform in self.SOLD_PATTERNS:
                    for pattern in self.SOLD_PATTERNS[platform]:
                        if re.search(pattern, content, re.IGNORECASE):
                            result["status"] = "sold"
                            break
                    else:
                        result["status"] = "active"
                else:
                    result["status"] = "active"

        except requests.Timeout:
            result["status"] = "error"
            result["error"] = "Connection timeout"
        except requests.ConnectionError:
            result["status"] = "error"
            result["error"] = "Connection failed"
        except Exception as e:
            result["status"] = "error"
            result["error"] = str(e)

        return result

    def check_urls(self, urls: List[str]) -> List[Dict]:
        """Check multiple URLs"""
        results = []
        for url in urls:
            logger.info(f"Checking URL: {url[:50]}...")
            result = self.check_url(url)
            results.append(result)
            logger.info(f"Status: {result['status']}")
        return results


def check_tracked_urls(db_urls: List[Dict]) -> List[Dict]:
    """
    Check list of tracked URLs from database
    db_urls format: [{"id": 1, "source_url": "...", "product_id": 1}, ...]
    """
    checker = URLChecker()
    results = []

    for item in db_urls:
        check_result = checker.check_url(item["source_url"])
        results.append({
            "tracking_id": item["id"],
            "product_id": item["product_id"],
            **check_result
        })

    return results
