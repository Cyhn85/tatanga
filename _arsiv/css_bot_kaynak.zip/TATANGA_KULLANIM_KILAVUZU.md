# TATANGA - Kapsamlı Kullanım Kılavuzu

**Versiyon:** 2.0
**Tarih:** 26 Kasım 2025
**Dil:** Türkçe

---

## 📑 İçindekiler

1. [Giriş ve Sistem Mimarisi](#1-giriş-ve-sistem-mimarisi)
2. [Kurulum ve İlk Yapılandırma](#2-kurulum-ve-i̇lk-yapılandırma)
3. [Platform Bağlayıcıları](#3-platform-bağlayıcıları)
4. [Mağaza Yönetimi](#4-mağaza-yönetimi)
5. [Ürün Transferi (IC Logistik)](#5-ürün-transferi-ic-logistik)
6. [SEO ve Çeviri Sistemi](#6-seo-ve-çeviri-sistemi)
7. [Görsel Manipülasyon](#7-görsel-manipülasyon)
8. [Duplikasyon Önleme](#8-duplikasyon-önleme)
9. [Telegram Entegrasyonu](#9-telegram-entegrasyonu)
10. [Sorun Giderme](#10-sorun-giderme)
11. [API Referansı](#11-api-referansı)
12. [Sık Sorulan Sorular](#12-sık-sorulan-sorular)

---

## 1. Giriş ve Sistem Mimarisi

### 1.1 TATANGA Nedir?

TATANGA (Turkish Automated Trading And Network Growth Automation), çoklu e-ticaret platformları arasında otomatik ürün transferi ve yönetimi sağlayan profesyonel bir yazılımdır.

**Ana Özellikler:**
- 🔄 Çoklu platform desteği (eBay, Tradera, Kleinanzeigen, Willhaben, CSSBerlin.de)
- 🤖 Yapay zeka destekli çeviri ve SEO optimizasyonu
- 🖼️ Otomatik görsel manipülasyonu (8 teknik)
- 🔒 5 katmanlı duplikasyon önleme sistemi
- 📊 Gerçek zamanlı izleme ve analitik
- 🏪 Sınırsız mağaza hesabı desteği
- 🌍 18 platform, 14 ülke desteği

### 1.2 Dual-Logistics Mimarisi

TATANGA iki ana lojistik modeline sahiptir:

#### DIS LOGISTIK (Dış Lojistik) - Kazıma Modülü
**Amaç:** Rakip platformlardan ürün bilgisi toplamak

```
[Rakip Platformlar] → [Scraper] → [Veritabanı] → [Analiz]
      eBay DE              |           |              |
      Kleinanzeigen        |           |              |
      Willhaben      ------+           |              |
      Vinted                           |              |
                                       ↓              ↓
                              [Fiyat Analizi]  [Stok Takibi]
```

**Özellikler:**
- Selenium/API bazlı kazıma
- Otomatik fiyat karşılaştırma
- Stok durumu takibi
- Duplikasyon kontrolü

#### IC LOGISTIK (İç Lojistik) - Dağıtım Modülü
**Amaç:** Kendi ürünlerinizi birden fazla platforma dağıtmak

```
[Kaynak Ürün] → [Manipülasyon] → [SEO] → [Çeviri] → [Çoklu Platform]
  CSSBerlin          |              |        |              |
     |          8 Teknik        AI SEO   Groq AI       eBay DE
     |          Görsel        Generator  12 Dil        eBay UK
     |       Değiştirme                              Tradera
     |                                              Kleinanzeigen
     └─────────────────────────────────────────→  CSSBerlin.de
```

**Özellikler:**
- Tek ürünü 10+ platforma yayınlama
- Otomatik görsel manipülasyonu
- Platform bazlı SEO optimizasyonu
- Çoklu dil desteği
- Fiyat stratejileri

### 1.3 Sistem Bileşenleri

```
TATANGA/
│
├── Backend (Python)
│   ├── Platform Connectors (eBay, Tradera, Kleinanzeigen, Willhaben)
│   ├── Smart Translator (Groq AI - 12 dil)
│   ├── Image Manipulator (8 teknik)
│   ├── SEO Generator (Groq AI)
│   ├── Duplicate Detector (5 katman)
│   └── Database Manager (SQLite)
│
├── Frontend (GitHub Pages)
│   ├── CSSBerlin.de (statik site)
│   ├── Bootstrap 5 templates
│   └── Responsive design
│
├── GUI (Tkinter)
│   ├── Main Dashboard
│   ├── Store Manager
│   ├── IC Logistik GUI
│   └── Transfer Dashboard
│
└── Infrastructure
    ├── Telegram Bot (bildirimler)
    ├── Webhook Server (Flask)
    ├── Hetzner Server (optional)
    └── GitHub Actions (CI/CD)
```

### 1.4 Teknik Spesifikasyonlar

**Minimum Gereksinimler:**
- İşletim Sistemi: Windows 10/11 veya Linux
- Python: 3.7+
- RAM: 4 GB
- Disk: 2 GB boş alan
- İnternet: Stabil bağlantı

**Önerilen:**
- RAM: 8 GB+
- CPU: 4 core+
- SSD: 10 GB
- İnternet: 10 Mbps+

**Desteklenen Tarayıcılar (Selenium):**
- Chrome/Chromium (önerilen)
- Firefox
- Edge

---

## 2. Kurulum ve İlk Yapılandırma

### 2.1 Python Kurulumu

**Adım 1: Python 3.7+ Yükleyin**

Windows:
```bash
# Python.org'dan indir ve PATH'e ekle
python --version  # Test et
```

Linux/Mac:
```bash
sudo apt install python3 python3-pip  # Ubuntu/Debian
brew install python3  # Mac
```

**Adım 2: Gerekli Kütüphaneleri Yükleyin**

```bash
cd "c:\Users\cyhnsrgc\Desktop\CSS BOT"
pip install -r requirements_tatanga.txt
```

**requirements_tatanga.txt içeriği:**
```
requests>=2.28.0
selenium>=4.10.0
Pillow>=9.5.0
cryptography>=41.0.0
python-telegram-bot>=20.0
Flask>=2.3.0
Jinja2>=3.1.2
matplotlib>=3.7.0
groq>=0.4.0
imagehash>=4.3.1
```

### 2.2 ChromeDriver Kurulumu (Selenium İçin)

**Windows:**
```bash
# 1. Chrome versiyonunu kontrol edin
chrome://version/

# 2. Uygun ChromeDriver indirin
# https://chromedriver.chromium.org/downloads

# 3. PATH'e ekleyin veya proje klasörüne koyun
```

**Linux:**
```bash
# Ubuntu/Debian
sudo apt install chromium-chromedriver

# Veya manuel
wget https://chromedriver.storage.googleapis.com/LATEST_RELEASE
wget https://chromedriver.storage.googleapis.com/$(cat LATEST_RELEASE)/chromedriver_linux64.zip
unzip chromedriver_linux64.zip
sudo mv chromedriver /usr/local/bin/
```

### 2.3 İlk Çalıştırma

**Adım 1: TATANGA Dashboard'u Başlatın**

Windows:
```bash
# Çift tıklayın:
LAUNCH_TATANGA.bat

# Veya komut satırı:
python TATANGA_DASHBOARD.py
```

Linux/Mac:
```bash
python3 TATANGA_DASHBOARD.py
```

**Adım 2: İlk Açılış Ekranı**

Dashboard açıldığında 5 tab göreceksiniz:
1. **Dashboard** - Sistem özeti
2. **Stores** - Mağaza yönetimi
3. **Transfers** - Transfer takibi
4. **Analytics** - Analitik grafikler
5. **Settings** - Ayarlar

### 2.4 API Anahtarlarının Yapılandırılması

**Dosya:** `active_pieces/config/credentials.py`

#### 2.4.1 Groq API (Çeviri + SEO)

```python
API_KEYS = {
    # Groq API - Çeviri ve SEO için gerekli
    'groq_api_key': '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',
    # ✅ ÇALIŞIYOR - Bu anahtar kullanıma hazır
}
```

**Yeni anahtar almak için:**
1. https://groq.com adresine gidin
2. Ücretsiz hesap oluşturun
3. API Keys bölümünden yeni anahtar oluşturun
4. `credentials.py` dosyasına ekleyin

#### 2.4.2 eBay API (Almanya, İngiltere, Fransa)

```python
API_KEYS = {
    # eBay Sandbox (Test için)
    'ebay_app_id': 'CeyhunSa-CSSBerli-SBX-93bf8600b-91aff958',
    'ebay_cert_id': 'SBX-3bf8600bfc30-6d2c-4729-9a1b-8a92',
    'ebay_dev_id': '71b50976-387c-481a-a569-5b1a169fe4e0',
    'ebay_sandbox': True,  # Test modu

    # eBay Production (Gerçek listeler için)
    'ebay_app_id_prod': 'CeyhunSa-CSSBerli-PRD-60ddfec83-a7ea6bd2',
    'ebay_cert_id_prod': 'PRD-0ddfec839912-0f9c-4a23-94ac-be6b',
    # Not: Production için OAuth token almanız gerekir
}
```

**eBay OAuth Token Alma:**

```python
# Terminal'de çalıştırın:
python active_pieces/integrations/ebay_connector.py

# 1. Tarayıcıda açılan URL'ye gidin
# 2. eBay hesabınızla giriş yapın
# 3. İzin verin
# 4. Redirect URL'den code parametresini kopyalayın
# 5. Code'u programa girin
# 6. Token otomatik kaydedilir
```

#### 2.4.3 Tradera API (İsveç)

```python
API_KEYS = {
    # Tradera API
    'tradera_app_id': '5535',
    'tradera_app_key': '2b6f2423-674f-4526-852a-c841b7f3ef2f',
    'tradera_token': '',  # İlk kullanımda otomatik oluşturulur
}
```

**Yeni anahtar almak için:**
1. https://api.tradera.com adresine gidin
2. Developer hesabı oluşturun
3. App ID ve App Key alın

#### 2.4.4 Telegram Bot

```python
TELEGRAM = {
    'bot_token': '',  # @BotFather'dan alın
    'chat_id': '',    # @userinfobot'tan alın

    # Bildirim ayarları
    'notifications_enabled': True,
    'notify_on_transfer': True,
    'notify_on_message': True,
    'notify_on_sale': True,
}
```

**Telegram Bot Kurulumu (10 dakika):**

1. **Bot Oluşturma:**
   ```
   Telegram'da @BotFather'ı arayın
   /newbot komutunu gönderin
   Bot adı girin: "CSS Berlin Bot"
   Bot username girin: "cssberlin_notify_bot"
   Bot token'ı kopyalayın
   ```

2. **Chat ID Alma:**
   ```
   @userinfobot'u arayın
   /start komutunu gönderin
   Chat ID'nizi kopyalayın
   ```

3. **Yapılandırma:**
   ```python
   TELEGRAM = {
       'bot_token': '8222444116:AAG5D2xc7-7EOGYIX1s0Tx0jM2m5nOWG1dw',
       'chat_id': '5149567290',
   }
   ```

4. **Test:**
   ```bash
   python active_pieces/integrations/telegram_bot.py
   # Telegram'dan /start gönderin
   ```

### 2.5 Veritabanı İlk Kurulum

TATANGA otomatik olarak 3 SQLite veritabanı oluşturur:

```
active_pieces/storage/
├── tatanga.db              # Ana veritabanı
├── translation_cache.db    # Çeviri önbelleği
└── kleinanzeigen_selectors.db  # Adaptif selectors
```

**Manuel oluşturma (gerekirse):**
```python
python
>>> from active_pieces.core.database import init_database
>>> init_database()
>>> # Tablolar otomatik oluşturuldu
```

### 2.6 İlk Mağaza Hesabı Ekleme

**Adım 1: Store Manager'ı Açın**

Dashboard → **Stores** tab

**Adım 2: Yeni Hesap Ekle**

1. **Add Store** butonuna tıklayın
2. Platform seçin (örnek: eBay DE)
3. Hesap bilgilerini girin:
   ```
   Store Name: EbayDE_Main
   Email: ceyhuns.sorguc@gmail.com
   Password: F@ceb00k2002?
   Status: Active
   Priority: 1
   ```
4. **Save** butonuna tıklayın

**Güvenlik Notu:**
Şifreler Fernet encryption ile şifrelenir ve `tatanga.db` içinde güvenli saklanır.

---

## 3. Platform Bağlayıcıları

TATANGA 6 platform bağlayıcısı ile gelir. Her biri farklı özelliklere sahiptir.

### 3.1 eBay Bağlayıcısı (Almanya, İngiltere, Fransa)

**Dosya:** `active_pieces/integrations/ebay_connector.py`
**Satır:** 594 lines
**Durum:** ✅ Production-Ready

#### Özellikler

- **API Tipi:** Resmi eBay Inventory API v1
- **Kimlik Doğrulama:** OAuth 2.0 (auto-refresh)
- **Desteklenen İşlemler:**
  - Ürün listeleme (3-step: inventory → offer → publish)
  - Görsel yükleme (max 12)
  - Fiyat güncelleme
  - Stok güncelleme
  - Liste silme

#### Kullanım

**Python Kodu:**
```python
from integrations.ebay_connector import eBayConnector

# Bağlayıcı oluştur
ebay = eBayConnector(
    app_id='CeyhunSa-CSSBerli-PRD-60ddfec83-a7ea6bd2',
    cert_id='PRD-0ddfec839912-0f9c-4a23-94ac-be6b',
    dev_id='71b50976-387c-481a-a569-5b1a169fe4e0',
    user_token='v^1.1#i^1#...',  # OAuth token
    refresh_token='v^1.1#i^1#...',  # Refresh token
    sandbox=False  # Production
)

# Ürün listele
listing_data = {
    'title': 'Nike Air Max 90 Herren Schuhe Gr. 42',
    'description': 'Neuwertige Nike Air Max 90 in Größe 42...',
    'price': 89.99,
    'currency': 'EUR',
    'quantity': 1,
    'condition': 'USED_EXCELLENT',
    'category_id': '11450',  # Clothing, Shoes & Accessories
    'images': [
        'https://example.com/image1.jpg',
        'https://example.com/image2.jpg'
    ]
}

result = ebay.create_listing(listing_data)

if result['success']:
    print(f"Başarılı! URL: {result['url']}")
    print(f"Listing ID: {result['listing_id']}")
else:
    print(f"Hata: {result['error']}")
```

**GUI Kullanımı:**

1. IC Logistik GUI'yi açın
2. Sol panelden ürün seçin
3. Sağ panelden "eBay DE:Main" hesabını seçin
4. **Transfer** butonuna tıklayın
5. Otomatik:
   - Görsel manipülasyonu
   - SEO optimizasyonu
   - eBay'e yükleme
   - Sonuç bildirimi

#### OAuth Token Yenileme

eBay token'ları 2 saat sonra expire olur. TATANGA otomatik yeniler:

```python
# Otomatik yenileme (her API çağrısından önce)
if ebay.needs_token_refresh():
    ebay.refresh_access_token()
    print("Token yenilendi!")
```

#### Hata Kodları

| Kod | Anlamı | Çözüm |
|-----|--------|-------|
| 401 | Unauthorized | Token expire - yenile |
| 403 | Forbidden | Yetkisiz işlem - scope kontrol et |
| 500 | Server Error | eBay sunucu hatası - tekrar dene |
| 21916328 | Duplicate listing | Ürün zaten mevcut |

### 3.2 Tradera Bağlayıcısı (İsveç)

**Dosya:** `active_pieces/integrations/tradera_connector.py`
**Satır:** 380 lines
**Durum:** ✅ Production-Ready

#### Özellikler

- **API Tipi:** Resmi Tradera API v3
- **Kimlik Doğrulama:** API Key + OAuth
- **Otomatik Çeviri:** Almanca → İsveççe (Groq AI)
- **Limitler:**
  - Başlık: Max 75 karakter
  - Görseller: Max 8
  - Açıklama: Sınırsız

#### Kullanım

**Python Kodu:**
```python
from integrations.tradera_connector import TraderaConnector

# Bağlayıcı oluştur
tradera = TraderaConnector(
    app_id='5535',
    app_key='2b6f2423-674f-4526-852a-c841b7f3ef2f',
    token=''  # İlk çalıştırmada otomatik oluşturulur
)

# Otomatik çeviriyle ürün ara
results = tradera.search_products(
    keywords='Nike Schuhe',  # Almanca
    auto_translate=True  # → "Nike skor" (İsveççe)
)

# Otomatik çeviriyle listele
listing_data = {
    'title': 'Nike Air Max 90 Herren Gr. 42',  # Almanca
    'description': 'Neuwertige Schuhe...',  # Almanca
    'price': 899.00,  # SEK (İsveç Kronu)
    'images': ['https://...']
}

result = tradera.create_listing(
    listing_data,
    auto_translate=True  # Otomatik DE→SV
)

# Başlık otomatik çevrilir: "Nike Air Max 90 Herr Storlek 42"
```

#### Çeviri Önbelleği

İlk çeviri Groq AI kullanır, sonraki aynı metinler önbellekten gelir:

```python
# İlk çeviri
tradera.translate('Nike Schuhe', 'de', 'sv')
# → Groq API çağrısı (0.5 saniye)

# İkinci çeviri (aynı metin)
tradera.translate('Nike Schuhe', 'de', 'sv')
# → Önbellekten (0.001 saniye)
```

Önbellek TTL: 30 gün

### 3.3 Kleinanzeigen Bağlayıcısı (Almanya)

**Dosya:** `active_pieces/integrations/kleinanzeigen_connector.py`
**Satır:** 721 lines
**Durum:** ✅ Production-Ready + ADAPTIVE

#### Özellikler

- **Yöntem:** Selenium WebDriver (API yok)
- **Karmaşıklık:** Yüksek
- **Özel Özellik:** 🧠 **Self-Learning Selector Engine**
- **Veritabanı:** `kleinanzeigen_selectors.db` (23 strateji)

#### Adaptif Öğrenme Sistemi

Kleinanzeigen'in en önemli özelliği **asla aynı hatayı tekrarlamamasıdır**:

```python
# Örnek: İlk denemede başarısız olan selector
selector_engine.try_selector('title_field', 'id', 'ad-title')
# → Başarısız! (sayfa değişmiş)

# Sistem otomatik başka selector dener
selector_engine.try_selector('title_field', 'xpath', '//input[@name="title"]')
# → Başarılı!

# Sonuç: Başarısız selector devre dışı bırakılır
# Bir daha DENENMEZError!
```

**Selector Veritabanı:**
```sql
SELECT * FROM selector_strategies
WHERE element_type = 'title_field';

| selector_type | selector_value          | success_count | failure_count | is_active |
|---------------|-------------------------|---------------|---------------|-----------|
| id            | ad-title                | 0             | 5             | 0 (❌)    |
| xpath         | //input[@name='title']  | 247           | 0             | 1 (✅)    |
| css           | input[data-qa='title']  | 89            | 1             | 1 (✅)    |
```

#### Kullanım

**Python Kodu:**
```python
from integrations.kleinanzeigen_connector import KleinanzeigenConnector

# Bağlayıcı oluştur
kleinanzeigen = KleinanzeigenConnector(
    headless=False,  # Tarayıcıyı göster
    profile_path='c:/selenium/profiles/kleinanzeigen'
)

# Login
kleinanzeigen.login(
    email='ceyhunsabahattinsorguc@gmail.com',
    password='F@ceb00k2002?'
)

# Ürün listele (adaptif sistem kullanır)
listing_data = {
    'title': 'Nike Air Max 90 Gr. 42',
    'description': 'Neuwertig, nur 2x getragen...',
    'price': 89.99,
    'category': 'Herrenschuhe',
    'location': '13593 Berlin',
    'images': ['path/to/image1.jpg', 'path/to/image2.jpg']
}

result = kleinanzeigen.create_listing(listing_data)

# Selector engine otomatik en iyi yöntemi seçer
# Başarısız yöntemler asla tekrarlanmaz!

kleinanzeigen.close()
```

#### Log-Based Learning

Sistem ayrıca geçmiş loglardan öğrenebilir:

```python
# Geçmiş logları analiz et
stats = kleinanzeigen.learn_from_past_logs('logs/')

print(stats)
# {
#     'log_files_analyzed': 15,
#     'failures_found': 23,
#     'strategies_updated': 18,
#     'new_patterns_discovered': 5
# }
```

### 3.4 Willhaben Bağlayıcısı (Avusturya)

**Dosya:** `active_pieces/integrations/willhaben_connector.py`
**Satır:** 570 lines
**Durum:** ✅ Framework Complete

#### Özellikler

- **Dil:** Almanca (çeviri gerekmez)
- **Yöntem:** Selenium (unofficial API mevcut)
- **Karmaşıklık:** Orta
- **Pazar:** Avusturya (Almanya'ya yakın)

#### Kullanım

**Python Kodu:**
```python
from integrations.willhaben_connector import WillhabenConnector

# Bağlayıcı oluştur
willhaben = WillhabenConnector(
    headless=True,
    proxy={'host': '100.64.0.2', 'port': 8080}  # Optional
)

# Ürün kazı
result = willhaben.scrape_product(
    'https://www.willhaben.at/iad/kaufen-und-verkaufen/d/nike-air-max-12345'
)

if result['success']:
    print(f"Başlık: {result['title']}")
    print(f"Fiyat: €{result['price']}")
    print(f"Konum: {result['location']}")
    print(f"Görseller: {len(result['images'])}")

# Ürün yükleme
account = {
    'email': 'ceyhuns.sorguc@gmail.com',
    'password': 'F@ceb00k2002?',
    'location': {'plz': '13593', 'city': 'Berlin'}
}

result = willhaben.upload_product(
    product_id=123,
    target_account='main',
    auto_translate=False  # Almanca, gerek yok
)

willhaben.close()
```

### 3.5 CSSBerlin Adapter (GitHub Pages)

**Dosya:** `active_pieces/integrations/cssberlin_adapter.py`
**Satır:** 421 lines
**Durum:** ✅ Production-Ready

#### Özellikler

- **Platform:** GitHub Pages (statik site)
- **URL:** https://cssberlin.de
- **Template:** Bootstrap 5 responsive
- **SEO:** Open Graph + Twitter Cards
- **Deployment:** Otomatik Git push

#### Kullanım

**Python Kodu:**
```python
from integrations.cssberlin_adapter import CSSBerlinAdapter

# Adapter oluştur
cssberlin = CSSBerlinAdapter(
    repo_path='C:/Users/cyhnsrgc/Desktop/CSS-Berlin-Website',
    branch='main'
)

# Ürün sayfası oluştur
product_data = {
    'title': 'Nike Air Max 90 Herren Gr. 42',
    'description': 'Neuwertige Nike Air Max 90...',
    'price': 89.99,
    'images': [
        'https://i.ebayimg.com/image1.jpg',
        'https://i.ebayimg.com/image2.jpg'
    ],
    'category': 'Herrenschuhe'
}

result = cssberlin.create_product_page(product_data)

if result['success']:
    print(f"Sayfa oluşturuldu: {result['url']}")
    # Örnek: https://cssberlin.de/products/nike-air-max-90-herren-gr-42.html

    print(f"Git commit: {result['commit_id']}")
    # Otomatik commit + push yapıldı!
```

**Workflow:**
```
Product Data → Jinja2 Template → HTML File
                                     ↓
                            Git Add + Commit
                                     ↓
                                 Git Push
                                     ↓
                          GitHub Pages Deploy
                                     ↓
                         https://cssberlin.de/products/...
```

---

## 4. Mağaza Yönetimi

### 4.1 Store Manager GUI Kullanımı

**Başlatma:**
```bash
python TATANGA_DASHBOARD.py
# → Stores tab
```

#### 4.1.1 Yeni Mağaza Ekleme

**Adım adım:**

1. **Add Store** butonuna tıklayın

2. **Platform Seçin:**
   - eBay DE, eBay UK, eBay FR
   - Tradera
   - Kleinanzeigen
   - Willhaben
   - Vinted DE, FR, UK, etc.

3. **Hesap Bilgilerini Girin:**
   ```
   Store Name: [Benzersiz isim]
   Platform: [Seçilen platform]
   Email: [Hesap emaili]
   Password: [Hesap şifresi]
   Status: Active / Inactive
   Priority: 1-10 (1 = En yüksek)
   ```

4. **Additional Info (platform bazlı):**

   **eBay:**
   ```json
   {
     "user_token": "v^1.1#i^1#...",
     "refresh_token": "v^1.1#i^1#...",
     "token_expiry": "2025-11-26T15:30:00"
   }
   ```

   **Kleinanzeigen:**
   ```json
   {
     "profile_name": "Ceyhun",
     "location": "13593 Berlin",
     "phone": "+491632634020"
   }
   ```

5. **Save** butonuna tıklayın

**Güvenlik:**
- Şifreler Fernet encryption ile şifrelenir
- Token'lar encrypted olarak saklanır
- Veritabanı: `tatanga.db` (table: `store_accounts`)

#### 4.1.2 Mağaza Düzenleme

1. Listeden mağaza seçin
2. **Edit** butonuna tıklayın
3. Bilgileri güncelleyin
4. **Save** butonuna tıklayın

#### 4.1.3 Mağaza Silme

⚠️ **DİKKAT:** Bu işlem geri alınamaz!

1. Listeden mağaza seçin
2. **Delete** butonuna tıklayın
3. Onay dialogunda **Yes** seçin

#### 4.1.4 Login Test

API destekleyen platformlarda login testi yapabilirsiniz:

1. Mağaza seçin
2. **Test Login** butonuna tıklayın
3. Sonuç:
   - ✅ **Success:** Bağlantı başarılı
   - ❌ **Failed:** Hatalı kimlik veya expired token

### 4.2 Çoklu Mağaza Stratejileri

#### 4.2.1 Priority Sistemi

Her mağazaya 1-10 arası priority atayabilirsiniz:

```python
# Örnek: 3 eBay hesabı
Hesap 1: Priority 1 (Ana hesap - 50 feedback)
Hesap 2: Priority 2 (Yedek - 20 feedback)
Hesap 3: Priority 3 (Yeni - 0 feedback)
```

**Kullanım:**
IC Logistik otomatik en yüksek priority'li aktif hesabı seçer.

#### 4.2.2 Rotation Stratejisi

Birden fazla hesap kullanarak eBay/platform limitlerini aşın:

```python
# Örnek: Günlük 100 listing limiti
Hesap 1: 100 listing (limit doldu)
  → Otomatik Priority 2'ye geç
Hesap 2: 100 listing (limit doldu)
  → Otomatik Priority 3'e geç
```

**Yapılandırma:**
```python
# config/transfer_settings.py
TRANSFER_SETTINGS = {
    'rotation_enabled': True,
    'max_listings_per_account_daily': 100,
    'auto_switch_on_limit': True
}
```

### 4.3 Platform-Specific Notlar

#### eBay
- OAuth token 2 saat geçerli
- Refresh token 18 ay geçerli
- Sandbox vs Production farklı account

#### Kleinanzeigen
- Email verification gerekli
- Telefon onayı gerekebilir
- VPN kullanımı önerilir (Almanya dışından)

#### Tradera
- İsveç banka hesabı gerekli (satış ödemesi için)
- SSL sertifika onayı gerekebilir

---

## 5. Ürün Transferi (IC Logistik)

IC Logistik, kendi ürünlerinizi birden fazla platforma otomatik dağıtır.

### 5.1 IC Logistik GUI Kullanımı

**Başlatma:**
```bash
python active_pieces/ic_logistik_gui.py
```

**Veya Dashboard'dan:**
```
TATANGA Dashboard → IC Logistik butonuna tıklayın
```

#### 5.1.1 Arayüz Bileşenleri

```
┌─────────────────────────────────────────────────────────┐
│  IC LOGISTIK - Internal Transfer System                │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────┐          ┌──────────────────────────┐│
│  │   PRODUCTS   │          │    TARGET PLATFORMS      ││
│  │              │          │                          ││
│  │ □ Product 1  │          │ □ eBay DE:Main          ││
│  │ □ Product 2  │   ────>  │ □ eBay UK:Secondary     ││
│  │ □ Product 3  │          │ □ Tradera:Main          ││
│  │ □ Product 4  │          │ □ Kleinanzeigen:Main    ││
│  │ ...          │          │ □ CSSBerlin             ││
│  └──────────────┘          └──────────────────────────┘│
│                                                         │
│  ┌──────────────────────────────────────────────────┐ │
│  │             TRANSFER SETTINGS                     │ │
│  │ Image Manipulation: [✓] Enabled                   │ │
│  │ SEO Variation:      [✓] Enabled                   │ │
│  │ Price Strategy:     [▼] Same / +10% / -5% / ...  │ │
│  │ Auto-Translation:   [✓] Enabled                   │ │
│  └──────────────────────────────────────────────────┘ │
│                                                         │
│             [Start Transfer] [Stop] [Clear Log]        │
│                                                         │
│  ┌──────────────────────────────────────────────────┐ │
│  │              TRANSFER LOG                         │ │
│  │ 15:30:45 - Product 1 → eBay DE:Main ... Success  │ │
│  │ 15:30:48 - Manipulating images (8 techniques)... │ │
│  │ 15:30:52 - Generating SEO (Groq AI)...           │ │
│  │ 15:30:55 - Product 1 → Tradera:Main ... Success  │ │
│  │ ...                                                │ │
│  └──────────────────────────────────────────────────┘ │
│                                                         │
│  Progress: ████████████░░░░░ 75% (3/4 platforms)      │
└─────────────────────────────────────────────────────────┘
```

#### 5.1.2 Transfer İşlemi (Adım Adım)

**1. Ürün Seçimi:**
- Sol panelden transfer edilecek ürünleri seçin
- Çoklu seçim: Ctrl + Click
- Tümünü seç: Ctrl + A

**2. Platform Seçimi:**
- Sağ panelden hedef platformları seçin
- Her platform için hesap seçin (dropdown)
- Örnek: "eBay DE:Main" veya "eBay DE:Secondary"

**3. Ayarlar:**

   **Image Manipulation:** (Önerilen: ✓)
   ```
   8 teknik uygulanır:
   - Gaussian noise
   - Brightness/Contrast
   - Color temperature
   - Rotation + crop
   - Border addition
   - JPEG recompression
   - Perspective transform
   - EXIF stripping
   ```

   **SEO Variation:** (Önerilen: ✓)
   ```
   Platform bazlı SEO:
   - eBay: Anahtar kelime yoğun başlık
   - Tradera: İsveççe optimize
   - Kleinanzeigen: Yerel arama optimize
   ```

   **Price Strategy:**
   ```
   - Same: Aynı fiyat
   - +10%: %10 daha pahalı
   - -5%: %5 daha ucuz
   - Custom: Manuel fiyat
   ```

   **Auto-Translation:** (Önerilen: ✓)
   ```
   Otomatik dil algılama:
   - DE → SV (Tradera için)
   - DE → EN (eBay UK için)
   - DE → FR (eBay FR için)
   ```

**4. Transfer Başlat:**
- **Start Transfer** butonuna tıklayın
- Otomatik işlem başlar:

```
[15:30:45] Starting transfer for Product 1...
[15:30:46] Target platforms: 4 (eBay DE, eBay UK, Tradera, CSSBerlin)
[15:30:47]
[15:30:47] ─── eBay DE:Main ───
[15:30:48] Manipulating images (8 techniques)...
[15:30:50] ✓ 3 images processed
[15:30:51] Generating SEO variation...
[15:30:52] ✓ Title: "Nike Air Max 90 Herrenschuhe Gr. 42 Neuwertig Sportschuhe"
[15:30:53] Uploading to eBay...
[15:30:57] ✓ Success! URL: https://www.ebay.de/itm/123456789
[15:30:57]
[15:30:58] ─── eBay UK:Secondary ───
[15:30:59] Translating DE → EN...
[15:31:00] ✓ Title: "Nike Air Max 90 Men's Shoes Size 42 Like New Sports Shoes"
[15:31:01] Uploading to eBay UK...
[15:31:05] ✓ Success! URL: https://www.ebay.co.uk/itm/987654321
[15:31:05]
[15:31:06] ─── Tradera:Main ───
[15:31:07] Translating DE → SV...
[15:31:08] ✓ Title: "Nike Air Max 90 Herrskor Storlek 42 Som Nya Sportskor"
[15:31:09] Uploading to Tradera...
[15:31:12] ✓ Success! URL: https://www.tradera.com/item/555666777
[15:31:12]
[15:31:13] ─── CSSBerlin.de ───
[15:31:14] Generating HTML page...
[15:31:15] Git commit + push...
[15:31:18] ✓ Success! URL: https://cssberlin.de/products/nike-air-max-90-gr-42.html
[15:31:18]
[15:31:19] ══════════════════════════════════════
[15:31:19] Transfer Complete!
[15:31:19] Success: 4/4 platforms
[15:31:19] Time: 34 seconds
[15:31:19] ══════════════════════════════════════
```

### 5.2 Batch Transfer (Toplu)

Birden fazla ürünü aynı anda transfer edebilirsiniz:

**Örnek: 50 ürün → 5 platform = 250 listing**

```python
# Python kodu
from active_pieces.cross_platform_transfer import CrossPlatformTransfer

transfer = CrossPlatformTransfer()

# 50 ürün seç
product_ids = list(range(1, 51))

# 5 platform seç
targets = [
    'ebay_de:Main',
    'ebay_uk:Secondary',
    'tradera:Main',
    'kleinanzeigen:Main',
    'cssberlin'
]

# Toplu transfer başlat (parallel workers: 5)
results = transfer.batch_transfer(
    product_ids=product_ids,
    targets=targets,
    workers=5  # 5 işlem paralel çalışır
)

# Sonuçlar
print(f"Success: {results['success_count']}")
print(f"Failed: {results['failed_count']}")
print(f"Total Time: {results['elapsed_time']} seconds")
```

**Tahmini Süreler:**
```
1 ürün → 1 platform:   ~8-10 saniye
1 ürün → 5 platform:   ~20-25 saniye (parallel)
50 ürün → 5 platform:  ~25-30 dakika (parallel workers: 5)
```

### 5.3 Transfer Monitoring

Transfer esnasında gerçek zamanlı izleme:

**Dashboard Tab:**
```
Active Transfers: 3
├─ Product 1 → eBay DE     [████████░░] 80%
├─ Product 2 → Tradera     [██████░░░░] 60%
└─ Product 3 → Kleinanzeig [██░░░░░░░░] 20%

Completed Today: 47
Success Rate: 96% (45/47)
Average Time: 18 seconds/transfer
```

**Telegram Bildirimleri:**
```
🚀 Transfer Started
Product: Nike Air Max 90
Platforms: eBay DE, Tradera

✓ eBay DE - Success
https://www.ebay.de/itm/123456

✓ Tradera - Success
https://www.tradera.com/item/555666

🎉 All transfers complete!
2/2 platforms successful
```

---

## 6. SEO ve Çeviri Sistemi

TATANGA'nın en güçlü özelliklerinden biri yapay zeka destekli SEO ve çeviri sistemidir.

### 6.1 Smart Translator (Groq AI)

**Dosya:** `active_pieces/integrations/smart_translator.py`
**Motor:** Groq (Llama-3.3-70b-versatile)
**Desteklenen Diller:** 12 (DE, EN, SV, FR, TR, PL, ES, NL, CS, IT, NO, DK)

#### 6.1.1 Otomatik Dil Algılama

```python
from integrations.smart_translator import SmartTranslator

translator = SmartTranslator()

# Kaynak dili otomatik algıla
text = "Nike Air Max 90 Herrenschuhe"
detected = translator.detect_language(text)
print(detected)  # → 'de' (Almanca)
```

#### 6.1.2 Çeviri (Tek Metin)

```python
# Basit çeviri
translated = translator.translate(
    text="Nike Air Max 90 Herrenschuhe Gr. 42",
    source_lang='de',
    target_lang='sv'  # İsveççe
)

print(translated)
# → "Nike Air Max 90 Herrskor Storlek 42"
```

#### 6.1.3 Listing Çevirisi (Başlık + Açıklama)

```python
# Tam listing çevirisi
result = translator.translate_for_listing(
    title="Nike Air Max 90 Herrenschuhe Gr. 42 Neuwertig",
    description="""
    Verkaufe neuwertige Nike Air Max 90 in Größe 42.
    Nur 2x getragen, keine Gebrauchsspuren.
    Originalverpackung vorhanden.
    Versand innerhalb 24h.
    """,
    target_platform='tradera'  # Otomatik DE→SV
)

print(result['title'])
# → "Nike Air Max 90 Herrskor Storlek 42 Som Nya"

print(result['description'])
# → "Säljer nästan nya Nike Air Max 90 i storlek 42.
#     Endast burna 2 gånger, inga användningsspår.
#     Originalförpackning finns.
#     Frakt inom 24 timmar."
```

#### 6.1.4 Marka İsimlerini Koruma

Translator marka isimlerini korur:

```python
text = "Nike Air Max 90 mit Adidas Tasche"
translated = translator.translate(text, 'de', 'sv')

print(translated)
# → "Nike Air Max 90 med Adidas väska"
#    ^^^^ marka isimleri değişmedi
```

#### 6.1.5 Önbellek Sistemi

İlk çeviri API kullanır, sonraki aynı metinler önbellekten gelir:

```python
import time

# İlk çeviri
start = time.time()
translator.translate("Nike Schuhe", 'de', 'sv')
elapsed = time.time() - start
print(f"İlk çeviri: {elapsed:.2f}s")  # → 0.45s (API)

# İkinci çeviri (aynı metin)
start = time.time()
translator.translate("Nike Schuhe", 'de', 'sv')
elapsed = time.time() - start
print(f"Önbellekten: {elapsed:.4f}s")  # → 0.0012s (önbellek)
```

**Önbellek İstatistikleri:**
```python
stats = translator.get_cache_stats()
print(stats)
# {
#     'total_cached': 1247,
#     'cache_hits': 3891,
#     'cache_misses': 1247,
#     'hit_rate': 75.7%,
#     'cache_size_mb': 2.3
# }
```

### 6.2 SEO Generator (Groq AI)

**Dosya:** `active_pieces/integrations/groq_seo_generator.py`
**Amaç:** Platform bazlı SEO optimizasyonu

#### 6.2.1 SEO Varyasyon Stilleri

3 stil mevcuttur:

**Conservative (Muhafazakar):**
```python
original = "Nike Air Max 90 Gr. 42"

seo = generator.generate_seo_variation(
    original,
    style='conservative'
)

print(seo['title'])
# → "Nike Air Max 90 Herrenschuhe Größe 42"
#    (Sadece küçük eklemeler)
```

**Balanced (Dengeli) - Önerilen:**
```python
seo = generator.generate_seo_variation(
    original,
    style='balanced'
)

print(seo['title'])
# → "Nike Air Max 90 Herrenschuhe Gr. 42 Neuwertig Sportschuhe"
#    (Anahtar kelimeler eklendi)
```

**Aggressive (Agresif):**
```python
seo = generator.generate_seo_variation(
    original,
    style='aggressive'
)

print(seo['title'])
# → "Nike Air Max 90 Herrenschuhe Gr. 42 Neuwertig Sportschuhe Turnschuhe Sneaker"
#    (Maksimum anahtar kelime)
```

#### 6.2.2 Platform-Specific SEO

Her platform için özel SEO:

```python
# eBay için
seo_ebay = generator.generate_for_platform(
    title="Nike Air Max 90 Gr. 42",
    platform='ebay_de'
)

print(seo_ebay['title'])
# → "Nike Air Max 90 Herrenschuhe Größe 42 ⭐ Neuwertig ⭐ Sportschuhe Turnschuhe"
#    (eBay anahtar kelime yoğun + emoji)

# Kleinanzeigen için
seo_kleinanzeigen = generator.generate_for_platform(
    title="Nike Air Max 90 Gr. 42",
    platform='kleinanzeigen'
)

print(seo_kleinanzeigen['title'])
# → "Nike Air Max 90 Herrenschuhe Größe 42 in Berlin"
#    (Yerel arama optimize)

# Tradera için
seo_tradera = generator.generate_for_platform(
    title="Nike Air Max 90 Gr. 42",
    platform='tradera'
)

print(seo_tradera['title'])
# → "Nike Air Max 90 Herrskor Storlek 42"
#    (İsveççe + doğal dil)
```

#### 6.2.3 Açıklama Genişletme

Kısa açıklamalar otomatik genişletilir:

```python
short_desc = "Nike Air Max 90, Gr. 42, neuwertig"

expanded = generator.expand_description(
    short_desc,
    target_length=250,  # Min 250 kelime
    style='balanced'
)

print(expanded)
# → """
# Nike Air Max 90 in Größe 42 - Neuwertig
#
# Biete hier meine neuwertigen Nike Air Max 90 Herrenschuhe in Größe 42 an.
# Die Schuhe wurden nur sehr selten getragen und befinden sich in einem
# hervorragenden Zustand. Keine sichtbaren Gebrauchsspuren.
#
# Details:
# - Marke: Nike
# - Modell: Air Max 90
# - Größe: 42 (entspricht UK 8, US 9)
# - Farbe: [Aus Bild erkannt]
# - Zustand: Neuwertig (9/10)
#
# Die Nike Air Max 90 sind zeitlose Sneaker-Klassiker mit der
# charakteristischen Air-Dämpfung...
# [250+ Wörter]
# """
```

### 6.3 Çeviri + SEO Kombine Kullanım

En güçlü özellik: Otomatik çeviri + SEO:

```python
# Almanca ürün → İsveççe Tradera (SEO optimize)
result = translator.translate_for_listing(
    title="Nike Air Max 90 Gr. 42",
    description="Neuwertige Schuhe, nur 2x getragen",
    target_platform='tradera',
    apply_seo=True  # ← SEO aktif
)

print(result['title'])
# → "Nike Air Max 90 Herrskor Storlek 42 Som Nya Sportskor"
#    ↑ İsveççe + SEO optimize

print(result['seo_keywords'])
# → ['Nike', 'Air Max', 'Herrskor', 'Storlek 42', 'Sportskor', 'Sneakers']
```

---

## 7. Görsel Manipülasyon

Her transfer edilen ürün için görseller otomatik manipüle edilir. Bu, platformların duplikasyon algılamasını atlatır.

### 7.1 8 Manipülasyon Tekniği

**Dosya:** `active_pieces/integrations/image_manipulator.py`

#### 7.1.1 Gaussian Noise (Gürültü Ekleme)

```python
from integrations.image_manipulator import ImageManipulator

manipulator = ImageManipulator()

# Teknik 1: Gaussian Noise
result = manipulator.add_gaussian_noise(
    'image.jpg',
    intensity=10  # 1-50 arası
)

# Her piksel hafifçe değişir
# Gözle fark edilmez ama hash değişir
```

#### 7.1.2 Brightness & Contrast

```python
# Teknik 2: Parlaklık ve kontrast
result = manipulator.adjust_brightness_contrast(
    'image.jpg',
    brightness_delta=0.05,  # ±0.2 arası
    contrast_factor=1.05    # 0.8-1.2 arası
)

# Görsel kalitesi değişmez
# Ama dijital imza değişir
```

#### 7.1.3 Color Temperature

```python
# Teknik 3: Renk sıcaklığı
result = manipulator.adjust_color_temperature(
    'image.jpg',
    temperature=5  # -50 (soğuk) +50 (sıcak)
)

# Hafif sarılaşma/mavileşme
# Gözle zor fark edilir
```

#### 7.1.4 Rotation & Crop

```python
# Teknik 4: Döndür ve kırp
result = manipulator.rotate_and_crop(
    'image.jpg',
    angle=2  # ±5 derece
)

# Çok küçük rotasyon
# Kenarlar otomatik kırpılır
```

#### 7.1.5 Border Addition

```python
# Teknik 5: Kenarlık ekle
result = manipulator.add_border(
    'image.jpg',
    border_width=10,  # piksel
    border_color='#FFFFFF'  # Beyaz
)

# İnce beyaz çerçeve
# Profesyonel görünüm
```

#### 7.1.6 JPEG Recompression

```python
# Teknik 6: JPEG yeniden sıkıştır
result = manipulator.recompress_jpeg(
    'image.jpg',
    quality=95  # 90-98 arası
)

# Görsel kalitesi aynı
# Ama dosya yapısı değişir
```

#### 7.1.7 Perspective Transform

```python
# Teknik 7: Perspektif dönüşümü
result = manipulator.perspective_transform(
    'image.jpg',
    intensity=0.02  # 0.01-0.05 arası
)

# Çok hafif 3D efekt
# Gözle zor fark edilir
```

#### 7.1.8 EXIF Stripping

```python
# Teknik 8: EXIF verilerini temizle
result = manipulator.strip_exif(
    'image.jpg'
)

# Kamera bilgileri, konum, tarih silinir
# Dosya boyutu küçülür
```

### 7.2 Kombine Manipülasyon

Tüm teknikleri aynı anda uygulama:

```python
# Agresif manipülasyon (8 teknik)
result = manipulator.manipulate_image(
    'image.jpg',
    level='aggressive',  # conservative/balanced/aggressive
    output_path='image_manipulated.jpg'
)

print(result)
# {
#     'success': True,
#     'techniques_applied': [
#         'gaussian_noise',
#         'brightness_contrast',
#         'color_temperature',
#         'rotation_crop',
#         'border_addition',
#         'jpeg_recompression',
#         'perspective_transform',
#         'exif_stripping'
#     ],
#     'original_size': 245678,
#     'new_size': 238912,
#     'hash_changed': True,
#     'visual_difference': '0.3%'  # Gözle fark edilmez
# }
```

### 7.3 Otomatik Batch İşleme

Transfer esnasında otomatik manipülasyon:

```python
# IC Logistik GUI → Image Manipulation: [✓] Enabled

# Otomatik:
for image in product_images:
    manipulated = manipulator.manipulate_image(
        image,
        level='balanced'
    )
    upload_to_platform(manipulated)
```

**Sonuç:**
```
Orijinal Görsel Hash:     a3f5d8c2e1b9
Manipüle Görsel Hash:     7d2c9a1f4e6b
Hash Benzerliği:          %12 (Farklı görsel olarak algılanır)
Görsel Benzerliği:        %99.7 (İnsan gözüne aynı)
```

---

## 8. Duplikasyon Önleme

TATANGA'nın en kritik özelliği: **SIFIR duplikasyon garantisi**

**Dosya:** `active_pieces/duplicate_detector.py`

### 8.1 5 Katmanlı Tespit Sistemi

```
Ürün Geldi
    ↓
┌───────────────┐
│ Katman 1:     │ → URL exact match (<1ms)
│ URL Check     │    Database index
└───────┬───────┘
        │ Benzersiz? ✓
        ↓
┌───────────────┐
│ Katman 2:     │ → Platform + Item ID match (<1ms)
│ Platform ID   │    Database index
└───────┬───────┘
        │ Benzersiz? ✓
        ↓
┌───────────────┐
│ Katman 3:     │ → Image perceptual hash (~100ms)
│ Image Hash    │    pHash + average hash
└───────┬───────┘
        │ Benzersiz? ✓
        ↓
┌───────────────┐
│ Katman 4:     │ → Title + Price similarity (~50ms)
│ Content Sim   │    Levenshtein distance
└───────┬───────┘
        │ Benzersiz? ✓
        ↓
┌───────────────┐
│ Katman 5:     │ → Scrape cooldown check (<1ms)
│ Cooldown      │    24 saat bekleme
└───────┬───────┘
        │ Tüm testleri geçti? ✓
        ↓
   ✅ Ürün Ekle
```

### 8.2 Katman Detayları

#### Katman 1: URL Exact Match

**Amaç:** Aynı URL'den tekrar kazıma engelle

```python
from duplicate_detector import DuplicateDetector

detector = DuplicateDetector()

# URL kontrolü
is_duplicate, existing_id, reason = detector.check_by_url(
    'https://www.kleinanzeigen.de/s-anzeige/nike-air-max/12345678'
)

if is_duplicate:
    print(f"Duplikasyon! Mevcut ID: {existing_id}")
    print(f"Sebep: {reason}")
    # → "Exact URL match"
```

**URL Normalizasyonu:**
```python
# Tracking parametreleri temizlenir:
original = 'https://ebay.de/itm/123?utm_source=twitter&fbclid=xyz'
normalized = detector._normalize_url(original)
# → 'https://ebay.de/itm/123'

# Sonuç: Aynı ürün farklı source'lardan gelirse tespit edilir
```

#### Katman 2: Platform + Item ID Match

**Amaç:** Platform-specific ID'ye göre kontrol

```python
# Örnek: eBay item ID
is_duplicate, existing_id, reason = detector.check_by_platform_id(
    platform='ebay_de',
    item_id='123456789'
)

# Eğer bu item ID daha önce kaydedildiyse:
# → is_duplicate = True
# → reason = "Platform ID match: ebay_de:123456789"
```

#### Katman 3: Image Perceptual Hash Match

**Amaç:** Görsel benzerliğine göre kontrol

```python
# Görsel hash karşılaştırma
is_duplicate, existing_id, reason = detector.check_by_image_hash(
    image_urls=[
        'https://example.com/image1.jpg',
        'https://example.com/image2.jpg'
    ],
    threshold=5  # Hamming distance (0-10 önerilir)
)

# Algoritmalar:
# - pHash (perceptual hash)
# - Average hash
# - Hamming distance karşılaştırma

# Eğer benzer görsel bulunursa:
# → is_duplicate = True
# → reason = "Similar image detected (distance: 3)"
```

**Hash Hesaplama:**
```python
# Görsel hash'i hesapla ve önbelleğe al
img_hash = detector._compute_image_hash('https://example.com/image.jpg')

print(img_hash)
# {
#     'average_hash': 'a3f5d8c2e1b9abcd',
#     'phash': 'f4e2d1c9b8a73f5e'
# }

# Önbellekte saklanır (tekrar hesaplanmaz)
```

**Hamming Distance:**
```python
hash1 = 'a3f5d8c2e1b9abcd'
hash2 = 'a3f5d8c2e1b9abce'  # Son karakter farklı

distance = detector._hamming_distance(hash1, hash2)
print(distance)  # → 1 (çok benzer!)

# Threshold = 5:
# - Distance 0-5: Duplikasyon (çok benzer)
# - Distance 6+: Benzersiz (farklı)
```

#### Katman 4: Title + Price Similarity

**Amaç:** İçerik benzerliğine göre kontrol

```python
# Başlık + fiyat benzerliği
is_duplicate, existing_id, reason = detector.check_by_content_similarity(
    title="Nike Air Max 90 Herrenschuhe Größe 42",
    price=89.99,
    platform='kleinanzeigen',
    title_threshold=0.85,  # %85 benzerlik
    price_tolerance=0.10   # %10 fiyat toleransı
)

# Algoritma:
# 1. Aynı platformdaki ürünleri bul
# 2. Fiyat toleransı içinde olanları filtrele (€81-€99 arası)
# 3. Başlık benzerliği hesapla (Levenshtein)
# 4. Threshold üstü benzerlik varsa duplikasyon
```

**Levenshtein Distance:**
```python
title1 = "Nike Air Max 90 Herrenschuhe Größe 42"
title2 = "Nike Air Max 90 Herren Schuhe Gr. 42"

similarity = detector._title_similarity(title1, title2)
print(similarity)  # → 0.92 (%92 benzer!)

# Normalizasyon:
# - Küçük harfe çevir
# - Özel karakterleri temizle
# - Boşlukları düzenle
#
# "nike air max 90 herrenschuhe größe 42"
# "nike air max 90 herren schuhe gr 42"
# → Levenshtein distance: 8
# → Similarity: 1 - (8 / max_length) = 0.92
```

#### Katman 5: Scrape Cooldown

**Amaç:** Aynı ürünü kısa sürede tekrar kazımayı engelle

```python
# Cooldown kontrolü
is_in_cooldown, last_scraped, reason = detector.check_scrape_cooldown(
    url='https://www.kleinanzeigen.de/s-anzeige/nike-air-max/12345678',
    platform='kleinanzeigen',
    cooldown_hours=24  # 24 saat bekleme
)

if is_in_cooldown:
    print(f"Son kazıma: {last_scraped}")
    print(f"Sebep: {reason}")
    # → "Scraped 3 times. Cooldown: 18.5h remaining"
```

**Cooldown Tracking:**
```sql
-- Database: scrape_cooldown table
SELECT * FROM scrape_cooldown WHERE source_url = '...';

| source_url     | last_scraped        | scrape_count |
|----------------|---------------------|--------------|
| https://...    | 2025-11-26 10:30:00 | 3            |

-- Eğer last_scraped + 24h > now():
-- → Cooldown aktif, tekrar kazıma
