#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Event Bus (Mesaj Kuyruğu)
Event-driven mimari için merkezi olay yönetim sistemi

Events:
- scrape_requested: Kazıma talebi
- raw_product_found: Ham ürün bulundu
- product_normalized: Ürün normalize edildi
- product_scored: Kâr/risk skoru hesaplandı
- product_needs_review: İnsan onayı gerekli
- product_approved_auto: Otomatik onaylandı
- product_approved_manual: Manuel onaylandı
- product_rejected: Reddedildi
- action_requested: Aksiyon talebi (mesaj, kargo, fatura)
- selector_failed: Selector hatası (self-healing trigger)
- operation_retry: Operasyon yeniden deneme

Author: TATANGA Team
Version: 2.0
"""

import asyncio
import json
import uuid
from datetime import datetime
from typing import Dict, List, Callable, Any, Optional
from collections import defaultdict
from pathlib import Path
import sqlite3
import threading


class Event:
    """Tek bir olay"""

    def __init__(self, event_type: str, data: Dict, source: str = None):
        self.id = str(uuid.uuid4())
        self.type = event_type
        self.data = data
        self.source = source or 'unknown'
        self.timestamp = datetime.now()
        self.processed = False
        self.error = None

    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'type': self.type,
            'data': self.data,
            'source': self.source,
            'timestamp': self.timestamp.isoformat(),
            'processed': self.processed,
            'error': self.error
        }

    @classmethod
    def from_dict(cls, data: Dict) -> 'Event':
        event = cls(
            event_type=data['type'],
            data=data['data'],
            source=data.get('source')
        )
        event.id = data['id']
        event.timestamp = datetime.fromisoformat(data['timestamp'])
        event.processed = data.get('processed', False)
        event.error = data.get('error')
        return event


class EventBus:
    """
    Merkezi Olay Yönetim Sistemi (Event Bus)

    Tüm ajanlar bu bus üzerinden iletişim kurar.
    Publisher-Subscriber pattern kullanır.
    """

    # Desteklenen olay tipleri
    EVENT_TYPES = [
        'scrape_requested',
        'raw_product_found',
        'product_normalized',
        'product_scored',
        'product_needs_review',
        'product_approved_auto',
        'product_approved_manual',
        'product_rejected',
        'action_requested',
        'selector_failed',
        'operation_retry',
        'system_health',
        'error_occurred'
    ]

    def __init__(self, db_path: str = None, persist_events: bool = True):
        """
        Initialize Event Bus

        Args:
            db_path: SQLite veritabanı yolu (event log için)
            persist_events: Olayları veritabanına kaydet
        """
        self._subscribers: Dict[str, List[Callable]] = defaultdict(list)
        self._queue: asyncio.Queue = None
        self._running = False
        self._persist = persist_events
        self._lock = threading.Lock()

        # Event log veritabanı
        if db_path:
            self.db_path = Path(db_path)
        else:
            self.db_path = Path(__file__).parent.parent / 'storage' / 'events.db'

        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        # İstatistikler
        self.stats = {
            'events_emitted': 0,
            'events_processed': 0,
            'events_failed': 0,
            'by_type': defaultdict(int)
        }

        if self._persist:
            self._init_database()

    def _init_database(self):
        """Event log veritabanı oluştur"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS event_log (
                id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                data TEXT NOT NULL,
                source TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                processed BOOLEAN DEFAULT 0,
                error TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_event_type ON event_log(event_type)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_event_timestamp ON event_log(timestamp DESC)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_event_processed ON event_log(processed)
        """)

        conn.commit()
        conn.close()

    def subscribe(self, event_type: str, handler: Callable):
        """
        Olaya abone ol

        Args:
            event_type: Olay tipi ('*' tüm olaylar için)
            handler: async callback fonksiyonu
        """
        with self._lock:
            self._subscribers[event_type].append(handler)

    def unsubscribe(self, event_type: str, handler: Callable):
        """Abonelikten çık"""
        with self._lock:
            if handler in self._subscribers[event_type]:
                self._subscribers[event_type].remove(handler)

    async def emit(self, event_type: str, data: Dict, source: str = None) -> Event:
        """
        Olay yayınla

        Args:
            event_type: Olay tipi
            data: Olay verisi
            source: Kaynak ajan/modül

        Returns:
            Oluşturulan Event nesnesi
        """
        event = Event(event_type, data, source)

        # İstatistik güncelle
        self.stats['events_emitted'] += 1
        self.stats['by_type'][event_type] += 1

        # Veritabanına kaydet
        if self._persist:
            self._save_event(event)

        # Handler'ları çağır
        await self._dispatch(event)

        return event

    async def _dispatch(self, event: Event):
        """Olayı ilgili handler'lara dağıt"""
        handlers = []

        with self._lock:
            # Spesifik event type handler'ları
            handlers.extend(self._subscribers.get(event.type, []))
            # Wildcard handler'lar
            handlers.extend(self._subscribers.get('*', []))

        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(event)
                else:
                    handler(event)
                event.processed = True
                self.stats['events_processed'] += 1
            except Exception as e:
                event.error = str(e)
                self.stats['events_failed'] += 1
                print(f"[EventBus] Handler error for {event.type}: {e}")

        # Güncelle
        if self._persist:
            self._update_event(event)

    def _save_event(self, event: Event):
        """Olayı veritabanına kaydet"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO event_log (id, event_type, data, source, timestamp)
                VALUES (?, ?, ?, ?, ?)
            """, (
                event.id,
                event.type,
                json.dumps(event.data, ensure_ascii=False),
                event.source,
                event.timestamp.isoformat()
            ))

            conn.commit()
            conn.close()
        except Exception as e:
            print(f"[EventBus] DB save error: {e}")

    def _update_event(self, event: Event):
        """Olay durumunu güncelle"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                UPDATE event_log
                SET processed = ?, error = ?
                WHERE id = ?
            """, (event.processed, event.error, event.id))

            conn.commit()
            conn.close()
        except Exception as e:
            print(f"[EventBus] DB update error: {e}")

    def get_recent_events(self, event_type: str = None, limit: int = 100) -> List[Dict]:
        """Son olayları getir"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        if event_type:
            cursor.execute("""
                SELECT * FROM event_log
                WHERE event_type = ?
                ORDER BY timestamp DESC
                LIMIT ?
            """, (event_type, limit))
        else:
            cursor.execute("""
                SELECT * FROM event_log
                ORDER BY timestamp DESC
                LIMIT ?
            """, (limit,))

        rows = cursor.fetchall()
        conn.close()

        events = []
        for row in rows:
            events.append({
                'id': row[0],
                'type': row[1],
                'data': json.loads(row[2]),
                'source': row[3],
                'timestamp': row[4],
                'processed': bool(row[5]),
                'error': row[6]
            })

        return events

    def get_pending_events(self, event_type: str = None) -> List[Dict]:
        """İşlenmemiş olayları getir"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        if event_type:
            cursor.execute("""
                SELECT * FROM event_log
                WHERE processed = 0 AND event_type = ?
                ORDER BY timestamp ASC
            """, (event_type,))
        else:
            cursor.execute("""
                SELECT * FROM event_log
                WHERE processed = 0
                ORDER BY timestamp ASC
            """)

        rows = cursor.fetchall()
        conn.close()

        events = []
        for row in rows:
            events.append({
                'id': row[0],
                'type': row[1],
                'data': json.loads(row[2]),
                'source': row[3],
                'timestamp': row[4]
            })

        return events

    def get_stats(self) -> Dict:
        """İstatistikleri getir"""
        return {
            **self.stats,
            'by_type': dict(self.stats['by_type']),
            'subscribers': {k: len(v) for k, v in self._subscribers.items()}
        }

    async def replay_events(self, event_type: str = None, since: datetime = None):
        """Geçmiş olayları yeniden oynat (recovery için)"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        query = "SELECT * FROM event_log WHERE 1=1"
        params = []

        if event_type:
            query += " AND event_type = ?"
            params.append(event_type)

        if since:
            query += " AND timestamp >= ?"
            params.append(since.isoformat())

        query += " ORDER BY timestamp ASC"

        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()

        for row in rows:
            event = Event(
                event_type=row[1],
                data=json.loads(row[2]),
                source=row[3]
            )
            event.id = row[0]
            await self._dispatch(event)


# Singleton instance
_event_bus_instance: Optional[EventBus] = None


def get_event_bus() -> EventBus:
    """Global EventBus instance'ı al"""
    global _event_bus_instance
    if _event_bus_instance is None:
        _event_bus_instance = EventBus()
    return _event_bus_instance


# ==================== CONVENIENCE FUNCTIONS ====================

async def emit(event_type: str, data: Dict, source: str = None) -> Event:
    """Kısayol: Olay yayınla"""
    return await get_event_bus().emit(event_type, data, source)


def subscribe(event_type: str, handler: Callable):
    """Kısayol: Olaya abone ol"""
    get_event_bus().subscribe(event_type, handler)


def on(event_type: str):
    """Decorator: Event handler tanımla"""
    def decorator(func):
        subscribe(event_type, func)
        return func
    return decorator


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("EVENT BUS TEST")
    print("=" * 60)

    async def test():
        bus = EventBus()

        # Test handler
        received_events = []

        async def test_handler(event: Event):
            received_events.append(event)
            print(f"  [Handler] Received: {event.type} - {event.data}")

        # Subscribe
        bus.subscribe('raw_product_found', test_handler)
        bus.subscribe('*', lambda e: print(f"  [Wildcard] {e.type}"))

        # Emit events
        print("\nEmitting events...")

        await bus.emit('scrape_requested', {
            'query': 'Nike Air Force',
            'platforms': ['vinted_de', 'ebay_uk'],
            'config': {'min_score': 3, 'max_score': 5}
        }, source='telegram_bot')

        await bus.emit('raw_product_found', {
            'platform': 'vinted_de',
            'title': 'Nike Air Force 1',
            'price': 45.0,
            'condition': 'Sehr gut',
            'url': 'https://vinted.de/items/123456'
        }, source='scraping_manager')

        await bus.emit('product_normalized', {
            'product_id': 123,
            'normalized_score': 4,
            'is_conflicting': False
        }, source='condition_agent')

        # Stats
        print(f"\nStats: {bus.get_stats()}")

        # Recent events
        print(f"\nRecent events: {len(bus.get_recent_events())}")

        print(f"\nReceived {len(received_events)} events via handler")
        print("\n" + "=" * 60)
        print("EVENT BUS TEST COMPLETE")
        print("=" * 60)

    asyncio.run(test())
