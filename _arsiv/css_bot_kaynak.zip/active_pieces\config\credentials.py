#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Configuration & Credentials
Store all API keys, database paths, and system configuration
"""

from pathlib import Path

# ============================================================================
# DATABASE CONFIGURATION
# ============================================================================

DATABASE = {
    'db_path': str(Path(__file__).parent.parent / 'tatanga.db'),
    'backup_enabled': True,
    'backup_interval_hours': 24
}

# ============================================================================
# API KEYS
# ============================================================================

API_KEYS = {
    # Groq API (Free - AI SEO generation + Translation)
    # Get your key at: https://groq.com
    'groq_api_key': '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',  # ✅ WORKING

    # eBay API (Germany, UK, US, etc.)
    # Using SANDBOX for testing, PRODUCTION credentials also available
    # Get your keys at: https://developer.ebay.com
    'ebay_app_id': 'CeyhunSa-CSSBerli-SBX-93bf8600b-91aff958',  # Sandbox App ID
    'ebay_cert_id': 'SBX-3bf8600bfc30-6d2c-4729-9a1b-8a92',     # Sandbox Cert ID
    'ebay_dev_id': '71b50976-387c-481a-a569-5b1a169fe4e0',      # Dev ID (same for both)
    'ebay_sandbox': True,       # Use sandbox for testing

    # Production eBay credentials (use after sandbox testing succeeds)
    'ebay_app_id_prod': 'CeyhunSa-CSSBerli-PRD-60ddfec83-a7ea6bd2',  # Production App ID
    'ebay_cert_id_prod': 'PRD-0ddfec839912-0f9c-4a23-94ac-be6b',     # Production Cert ID

    # Tradera API (Sweden) - EXISTING ACCOUNT ✅
    # Get your key at: https://api.tradera.com
    'tradera_app_id': '5535',                                   # ✅ WORKING
    'tradera_app_key': '2b6f2423-674f-4526-852a-c841b7f3ef2f',  # ✅ WORKING
    'tradera_token': '',        # OAuth token (will be generated on first use)

    # Leboncoin API (France)
    'leboncoin_api_key': '',    # If available

    # Willhaben API (Austria) - May need Selenium
    'willhaben_api_key': '',    # Limited API access

    # Shpock API
    'shpock_api_key': '',       # Check availability

    # Vinted - No official API (use Selenium)
    'vinted_api_key': '',       # Not available - will use scraping

    # Kleinanzeigen - No official API (use Selenium)
    'kleinanzeigen_api_key': '', # Not available - will use Selenium

    # ============================================================================
    # CAPTCHA SOLVING SERVICES
    # ============================================================================
    # 2captcha.com - $2.99/1000 captchas
    # Get API key at: https://2captcha.com/enterpage
    '2captcha_api_key': '',

    # Anti-Captcha - $2/1000 captchas
    # Get API key at: https://anti-captcha.com
    'anti-captcha_api_key': '',

    # CapSolver - $0.8/1000 captchas (cheapest)
    # Get API key at: https://capsolver.com
    'capsolver_api_key': '',

    # ============================================================================
    # PROFESSIONAL SCRAPING SERVICES
    # ============================================================================
    # ScraperAPI - 1000 free requests/month
    # Get API key at: https://www.scraperapi.com
    'scraperapi_api_key': '',

    # Bright Data (formerly Luminati) - Enterprise
    # Get credentials at: https://brightdata.com
    'brightdata_customer_id': '',
    'brightdata_zone': 'residential',
    'brightdata_password': '',

    # Oxylabs - Enterprise
    # Get credentials at: https://oxylabs.io
    'oxylabs_username': '',
    'oxylabs_api_key': '',

    # Smartproxy - Affordable option
    # Get credentials at: https://smartproxy.com
    'smartproxy_username': '',
    'smartproxy_password': ''
}

# ============================================================================
# TELEGRAM BOT CONFIGURATION
# ============================================================================

TELEGRAM = {
    # Get your bot token from @BotFather on Telegram
    'bot_token': '8222444116:AAG5D2xc7-7EOGYIX1s0Tx0jM2m5nOWG1dw',

    # Your Telegram chat ID (get from @userinfobot)
    'chat_id': '5149567290',

    # Notification settings
    'notifications_enabled': True,
    'notify_on_transfer': True,
    'notify_on_message': True,
    'notify_on_sale': True,
    'notify_on_stock_change': True
}

# ============================================================================
# CSSBERLIN.DE CONFIGURATION
# ============================================================================

CSSBERLIN = {
    # Local path to CSS-Berlin-Website GitHub repository
    'github_repo_path': 'C:/Users/cyhnsrgc/Desktop/CSS-Berlin-Website',

    # GitHub branch to push to
    'github_branch': 'main',

    # Products folder within the repo
    'products_folder': 'products',

    # Live website URL
    'base_url': 'https://cssberlin.de',

    # Template file (relative to repo root)
    'template_file': 'templates/cssberlin_product_modern.html',

    # Auto-include cssberlin.de in all transfers
    'auto_include': True,

    # Git commit message prefix
    'commit_prefix': 'TATANGA'
}

# ============================================================================
# IMAGE MANIPULATION SETTINGS
# ============================================================================

IMAGE_MANIPULATION = {
    # Manipulation levels: conservative, balanced, aggressive
    'default_level': 'aggressive',

    # Techniques to use (8 available)
    'techniques': [
        'gaussian_noise',
        'brightness_contrast',
        'color_temperature',
        'rotation_crop',
        'border_addition',
        'jpeg_recompression',
        'perspective_transform',
        'exif_stripping'
    ],

    # Quality settings
    'jpeg_quality': 95,
    'resize_max_dimension': 1920
}

# ============================================================================
# SEO GENERATION SETTINGS
# ============================================================================

SEO_SETTINGS = {
    # SEO variation styles: conservative, balanced, aggressive
    'default_style': 'balanced',

    # Languages supported
    'default_language': 'de',
    'supported_languages': ['de', 'en', 'tr', 'fr'],

    # Title settings
    'title_min_length': 60,
    'title_max_length': 80,

    # Description settings
    'description_min_words': 150,
    'description_max_words': 300,

    # Caching
    'cache_enabled': True,
    'cache_ttl_hours': 24
}

# ============================================================================
# STOCK MONITORING SETTINGS
# ============================================================================

STOCK_MONITOR = {
    # Check interval in hours
    'default_interval_hours': 4,

    # Auto-deactivate if out of stock
    'auto_deactivate': True,

    # Keywords to detect out of stock
    'out_of_stock_keywords': [
        'sold out',
        'out of stock',
        'nicht verfügbar',
        'verkauft',
        'ausverkauft',
        'nicht mehr verfügbar',
        'product not found',
        'item removed'
    ],

    # Request timeout
    'request_timeout_seconds': 10,

    # Retry settings
    'max_retries': 3,
    'retry_delay_seconds': 5
}

# ============================================================================
# PLATFORM LANGUAGE MAPPING
# ============================================================================

PLATFORM_LANGUAGES = {
    # German platforms
    'ebay_de': 'de',
    'kleinanzeigen': 'de',
    'willhaben': 'de',          # Austria (German)
    'shpock': 'de',             # Primary German
    'cssberlin': 'de',

    # French platforms
    'leboncoin': 'fr',
    'vinted_fr': 'fr',
    'ebay_fr': 'fr',

    # Swedish platforms
    'tradera': 'sv',
    'vinted_se': 'sv',

    # English platforms
    'vinted_uk': 'en',
    'ebay_uk': 'en',
    'ebay_us': 'en',

    # Other European
    'vinted_pl': 'pl',          # Polish
    'vinted_es': 'es',          # Spanish
    'vinted_nl': 'nl',          # Dutch
    'vinted_be': 'nl',          # Belgian (Dutch/French)
    'vinted_cz': 'cs',          # Czech
    'vinted_at': 'de',          # Austrian (German)
}

# ============================================================================
# OAUTH TOKEN STORAGE
# ============================================================================

OAUTH_TOKENS = {
    # OAuth tokens are stored encrypted in database
    # This config defines storage locations and refresh settings

    'storage_path': str(Path(__file__).parent.parent / 'storage' / 'oauth_tokens.db'),
    'encryption_enabled': True,
    'auto_refresh': True,
    'refresh_before_expire_minutes': 30,

    # Platform-specific OAuth settings
    'platforms': {
        'ebay': {
            'auth_url': 'https://auth.ebay.com/oauth2/authorize',
            'token_url': 'https://api.ebay.com/identity/v1/oauth2/token',
            'scope': 'https://api.ebay.com/oauth/api_scope https://api.ebay.com/oauth/api_scope/sell.inventory',
            'token_lifetime_seconds': 7200
        },
        'tradera': {
            'auth_url': 'https://api.tradera.com/oauth/authorize',
            'token_url': 'https://api.tradera.com/oauth/token',
            'token_lifetime_seconds': 3600
        }
    }
}

# ============================================================================
# PLATFORM STORE ACCOUNTS
# ============================================================================

STORE_ACCOUNTS = {
    # Store accounts are managed through Store Manager GUI
    # Credentials are encrypted and stored in database
    # This is just for documentation

    'encryption_enabled': True,
    'encryption_key_path': str(Path(__file__).parent.parent / 'storage' / 'encryption.key')
}

# ============================================================================
# TRANSFER SETTINGS
# ============================================================================

TRANSFER_SETTINGS = {
    # Parallel transfer workers
    'max_workers': 5,

    # Estimated time per listing (seconds)
    'estimated_time_per_listing': 20,

    # Max images per product
    'max_images': 5,

    # Retry settings
    'max_retries': 3,
    'retry_delay_seconds': 10
}

# ============================================================================
# ACTIVE PIECES WEBHOOK SETTINGS
# ============================================================================

ACTIVEPIECES = {
    # Webhook server settings
    'host': '0.0.0.0',
    'port': 5000,
    'debug': False,

    # Webhook endpoints
    'base_url': 'http://localhost:5000',
    'webhook_secret': ''  # Optional: Add a secret for webhook authentication
}

# ============================================================================
# LOGGING SETTINGS
# ============================================================================

LOGGING = {
    'log_dir': str(Path(__file__).parent.parent / 'logs'),
    'log_level': 'INFO',  # DEBUG, INFO, WARNING, ERROR
    'log_to_file': True,
    'log_to_console': True,
    'max_log_size_mb': 10,
    'backup_count': 5
}

# ============================================================================
# SYSTEM SETTINGS
# ============================================================================

SYSTEM = {
    'app_name': 'TATANGA',
    'app_version': '2.0',
    'app_description': 'Dual-Logistics E-Commerce Automation Platform',
    'developer': 'TATANGA Team',
    'website': 'https://cssberlin.de'
}
