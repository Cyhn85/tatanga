# Telegram Bot utility for Vinted Relister
import sys
import os
import socket
import requests
from typing import Optional, Dict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, MOBILE_PROXY_HOST, MOBILE_PROXY_PORT

class TelegramBot:
    """Telegram bot for notifications and control"""

    def __init__(self, token: str = None, chat_id: str = None):
        self.token = token or TELEGRAM_BOT_TOKEN
        self.chat_id = chat_id or TELEGRAM_CHAT_ID
        self.api_url = f"https://api.telegram.org/bot{self.token}"

    def send_message(self, text: str, parse_mode: str = "HTML") -> bool:
        """Send a message to the configured chat"""
        if not self.token or not self.chat_id:
            print("[TELEGRAM] Token or chat_id not configured")
            return False

        try:
            response = requests.post(
                f"{self.api_url}/sendMessage",
                json={
                    "chat_id": self.chat_id,
                    "text": text,
                    "parse_mode": parse_mode
                },
                timeout=10
            )
            return response.status_code == 200
        except Exception as e:
            print(f"[TELEGRAM ERROR] {e}")
            return False

    def send_photo(self, photo_path: str, caption: str = "") -> bool:
        """Send a photo to the configured chat"""
        if not self.token or not self.chat_id:
            return False

        try:
            with open(photo_path, 'rb') as photo:
                response = requests.post(
                    f"{self.api_url}/sendPhoto",
                    data={"chat_id": self.chat_id, "caption": caption, "parse_mode": "HTML"},
                    files={"photo": photo},
                    timeout=30
                )
            return response.status_code == 200
        except Exception as e:
            print(f"[TELEGRAM ERROR] {e}")
            return False

    def notify_scrape_complete(self, count: int, store: str):
        """Notify when scraping is complete"""
        text = f"""<b>SCRAPE TAMAMLANDI</b>

Magaza: {store}
Urun sayisi: {count}

Simdi resim isleme basliyor..."""
        return self.send_message(text)

    def notify_ready_for_upload(self, count: int, target_store: str):
        """Notify when products are ready for upload - request hotspot switch"""
        text = f"""<b>YUKLEME HAZIR</b>

{count} urun yuklemeye hazir!
Hedef: {target_store}

<b>LUTFEN MOBIL HOTSPOT'A GECIN!</b>

Baglanti yaptiktan sonra /upload komutunu gonderin."""
        return self.send_message(text)

    def notify_upload_complete(self, count: int, target_store: str):
        """Notify when upload is complete"""
        text = f"""<b>YUKLEME TAMAMLANDI</b>

{count} urun basariyla yuklendi!
Hedef: {target_store}

Artik ev WiFi'sine donebilirsiniz."""
        return self.send_message(text)

    def notify_error(self, error: str, step: str):
        """Notify about an error"""
        text = f"""<b>HATA</b>

Adim: {step}
Hata: {error}"""
        return self.send_message(text)

    def check_proxy_status(self) -> bool:
        """Check if mobile proxy is available"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            result = sock.connect_ex((MOBILE_PROXY_HOST, MOBILE_PROXY_PORT))
            sock.close()
            return result == 0
        except:
            return False

    def notify_proxy_status(self, target_store: str, product_count: int) -> bool:
        """Send proxy status warning before upload"""
        proxy_ok = self.check_proxy_status()
        status = "✅ AKTIF" if proxy_ok else "❌ KAPALI"
        addr = f"{MOBILE_PROXY_HOST}:{MOBILE_PROXY_PORT}"

        if proxy_ok:
            warning = "✅ Proxy aktif - Hedefe güvenli bağlantı sağlandı"
        else:
            warning = "⚠️ UYARI: Proxy bağlı değil!\n📱 Lütfen mobile hotspot'u açın!"

        text = f"""🔒 <b>PROXY DURUMU</b>
━━━━━━━━━━━━━━━━━━

📡 <b>Mobile Proxy:</b> {status}
🌐 <b>Adres:</b> {addr}

{warning}

━━━━━━━━━━━━━━━━━━
🎯 <b>Hedef:</b> Vinted.de ({target_store})
📦 <b>Yüklenecek:</b> {product_count} ürün
"""
        return self.send_message(text)

    def send_product_review(self, product: Dict, image_path: Optional[str] = None) -> bool:
        """Send product review with image"""
        title = product.get('processed_title') or product.get('raw_title', 'N/A')
        desc = product.get('processed_description') or product.get('raw_description', '')
        desc_short = desc[:300] + '...' if len(desc) > 300 else desc

        # Count images
        proc_path = product.get('processed_images_path', '')
        img_count = 0
        if proc_path and os.path.exists(proc_path):
            img_count = len([f for f in os.listdir(proc_path) if f.endswith('.jpg')])

        text = f"""📦 <b>ÜRÜN İNCELEME</b>
━━━━━━━━━━━━━━━━━━

📌 <b>Başlık:</b> {title}

📝 <b>Açıklama:</b>
{desc_short}

💰 <b>Fiyat:</b> {product.get('price', 0):.2f}€
🏷️ <b>Marka:</b> {product.get('brand', 'N/A')}
📏 <b>Beden:</b> {product.get('size', 'N/A')}

🖼️ <b>Resim:</b> {img_count} adet (temizlenmiş)
🆔 <b>ID:</b> {product.get('id')}

━━━━━━━━━━━━━━━━━━
✅ Contaminated resimler temizlendi
"""
        # Resim gönderme devre dışı - API 400 hatasını önlemek için sadece metin
        return self.send_message(text)


# Global instance
_bot = None

def get_bot() -> TelegramBot:
    """Get or create global bot instance"""
    global _bot
    if _bot is None:
        _bot = TelegramBot()
    return _bot

def send_telegram_message(text: str) -> bool:
    """Quick function to send a message"""
    return get_bot().send_message(text)

def notify_hotspot_switch(count: int, target_store: str) -> bool:
    """Notify user to switch to mobile hotspot"""
    return get_bot().notify_ready_for_upload(count, target_store)

def notify_proxy_status(target_store: str, product_count: int) -> bool:
    """Send proxy status warning"""
    return get_bot().notify_proxy_status(target_store, product_count)

def send_product_review(product: Dict, image_path: Optional[str] = None) -> bool:
    """Send product review with image"""
    return get_bot().send_product_review(product, image_path)


if __name__ == "__main__":
    # Test
    bot = TelegramBot()
    if bot.send_message("Test mesaji - Vinted Relister"):
        print("[OK] Telegram mesaji gonderildi")
    else:
        print("[FAIL] Telegram mesaji gonderilemedi")
