#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Groq SEO Generator
Generate unique SEO variations for multi-store publishing

Features:
- Title variations (different keywords, order, style)
- Description variations (different tone, length, bullet points)
- Site name barrier (filter "vinted", "ebay", "kleinanzeigen", etc.)
- Multi-language support (DE, TR, EN)
- Caching for faster repeated requests
- Free tier: 14,400 requests/day (Groq Llama)
"""

import sys, io
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

import re
import json
from groq import Groq
from pathlib import Path
import hashlib
import time

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.logger import ModuleLogger
from config.credentials import API_KEYS


class GroqSEOGenerator:
    """
    SEO content generator using Groq API (free)

    Usage:
        generator = GroqSEOGenerator()
        result = generator.generate_variation(
            original_title="Nike Air Max 90 Sneaker Weiß Gr. 42",
            original_description="Neuwertig, nur 2x getragen...",
            platform="ebay_de",
            language="de"
        )

    Returns:
        {
            'title': 'Air Max 90 Sportschuhe Weiß 42 Nike Turnschuhe',
            'description': 'Top Zustand! Kaum getragen...',
            'keywords': ['sneaker', 'sportschuhe', 'nike', 'air max'],
            'filtered_words': ['vinted', 'kleinanzeigen']
        }
    """

    def __init__(self):
        self.module_name = 'groq_seo_generator'
        self.logger = ModuleLogger(self.module_name)

        # API Key
        api_key = API_KEYS.get('groq_api_key', '')
        if not api_key:
            self.logger.warning("Groq API key boş! SEO varyasyonları devre dışı.")
            self.client = None
        else:
            self.client = Groq(api_key=api_key)

        # Model
        self.model = "llama-3.3-70b-versatile"  # Free, fast, good quality

        # Cache
        self.cache = {}
        self.cache_file = Path(__file__).parent.parent / 'storage' / 'seo_cache.json'
        self.load_cache()

        # Banned words (site names)
        self.banned_words = [
            'vinted', 'vinted.de', 'vinted.com',
            'ebay', 'ebay.de', 'ebay-kleinanzeigen',
            'kleinanzeigen', 'kleinanzeigen.de',
            'willhaben', 'tradera', 'cssberlin',
            'marketplace', 'marktplaats',
            # Add domain patterns
            '.de', '.com', '.fr', '.be', '.nl', '.at', '.se', '.ch'
        ]

        # Rate limit tracking
        self.request_count = 0
        self.daily_limit = 14400
        self.last_reset = time.time()

    def load_cache(self):
        """Load cache from disk"""
        if self.cache_file.exists():
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    self.cache = json.load(f)
                self.logger.info("SEO cache yüklendi", entries=len(self.cache))
            except Exception as e:
                self.logger.error("Cache yüklenemedi", exception=e)
                self.cache = {}

    def save_cache(self):
        """Save cache to disk"""
        try:
            self.cache_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.cache, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self.logger.error("Cache kaydedilemedi", exception=e)

    def get_cache_key(self, original_title, original_description, platform, language):
        """Generate cache key"""
        data = f"{original_title}|{original_description}|{platform}|{language}"
        return hashlib.md5(data.encode('utf-8')).hexdigest()

    def check_rate_limit(self):
        """Check if rate limit reached"""
        # Reset counter daily
        current_time = time.time()
        if current_time - self.last_reset > 86400:  # 24 hours
            self.request_count = 0
            self.last_reset = current_time

        if self.request_count >= self.daily_limit:
            self.logger.warning("Groq günlük limit aşıldı", limit=self.daily_limit)
            return False

        return True

    def filter_banned_words(self, text):
        """Remove site names and domains from text"""
        if not text:
            return text

        filtered = text
        removed_words = []

        for word in self.banned_words:
            pattern = re.compile(re.escape(word), re.IGNORECASE)
            if pattern.search(filtered):
                filtered = pattern.sub('', filtered)
                removed_words.append(word)

        # Clean up extra spaces
        filtered = re.sub(r'\s+', ' ', filtered).strip()

        if removed_words:
            self.logger.info("Yasaklı kelimeler filtrelendi", words=removed_words)

        return filtered

    def generate_variation(self, original_title, original_description, platform="ebay_de", language="de", variation_style="balanced"):
        """
        Generate SEO variation

        Args:
            original_title: Original product title
            original_description: Original product description
            platform: Target platform (ebay_de, vinted_de, kleinanzeigen, etc.)
            language: Content language (de, en, tr)
            variation_style: 'conservative', 'balanced', 'aggressive'

        Returns:
            dict: {'title', 'description', 'keywords', 'filtered_words'}
        """
        # Check cache first
        cache_key = self.get_cache_key(original_title, original_description, platform, language)
        if cache_key in self.cache:
            self.logger.info("Cache'den yüklendi", title=original_title[:30])
            return self.cache[cache_key]

        # Check API client
        if not self.client:
            self.logger.warning("Groq API yok, orijinal içerik döndürülüyor")
            return {
                'title': original_title,
                'description': original_description,
                'keywords': [],
                'filtered_words': []
            }

        # Check rate limit
        if not self.check_rate_limit():
            self.logger.warning("Rate limit aşıldı, orijinal içerik döndürülüyor")
            return {
                'title': original_title,
                'description': original_description,
                'keywords': [],
                'filtered_words': []
            }

        try:
            # Build prompt
            prompt = self.build_prompt(
                original_title,
                original_description,
                platform,
                language,
                variation_style
            )

            # Call Groq API
            self.logger.info("Groq API çağrılıyor", style=variation_style, lang=language)

            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert e-commerce SEO copywriter. Generate unique, compelling product variations that maintain accuracy while improving discoverability."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.8,  # Creative but controlled
                max_tokens=500,
                top_p=0.9
            )

            # Parse response
            content = response.choices[0].message.content.strip()
            result = self.parse_groq_response(content)

            # Filter banned words
            result['title'] = self.filter_banned_words(result['title'])
            result['description'] = self.filter_banned_words(result['description'])

            # Add filtered words list
            result['filtered_words'] = [w for w in self.banned_words if w.lower() in original_title.lower() or w.lower() in original_description.lower()]

            # Cache result
            self.cache[cache_key] = result
            self.save_cache()

            # Update rate limit
            self.request_count += 1

            self.logger.success(
                "SEO varyasyon oluşturuldu",
                title=result['title'][:40],
                keywords=len(result['keywords'])
            )

            return result

        except Exception as e:
            self.logger.error("Groq API hatası", exception=e)

            # Fallback: return filtered original
            return {
                'title': self.filter_banned_words(original_title),
                'description': self.filter_banned_words(original_description),
                'keywords': [],
                'filtered_words': []
            }

    def build_prompt(self, title, description, platform, language, style):
        """Build Groq prompt"""
        style_instructions = {
            'conservative': "Make minimal changes, only rearrange word order and use synonyms",
            'balanced': "Rewrite with different structure, new keywords, maintain meaning",
            'aggressive': "Completely rewrite with new angle, different tone, creative variations"
        }

        language_names = {
            'de': 'German',
            'en': 'English',
            'tr': 'Turkish'
        }

        platform_context = {
            'ebay_de': 'eBay Germany (formal, detailed, trust-building)',
            'vinted_de': 'Vinted Germany (casual, trendy, social)',
            'kleinanzeigen': 'Kleinanzeigen (local, friendly, practical)',
            'willhaben': 'Willhaben Austria (casual, trustworthy)',
            'tradera': 'Tradera Sweden (clean, minimalist)'
        }

        prompt = f"""Generate a unique SEO variation for this product:

ORIGINAL TITLE: {title}
ORIGINAL DESCRIPTION: {description}

TARGET PLATFORM: {platform_context.get(platform, platform)}
LANGUAGE: {language_names.get(language, language)}
VARIATION STYLE: {style_instructions.get(style, style)}

REQUIREMENTS:
1. Title: 60-80 characters, keyword-rich, platform-appropriate
2. Description: 150-300 words, persuasive, detailed
3. Keywords: Extract 5-8 main keywords
4. IMPORTANT: Remove ALL site names (Vinted, eBay, Kleinanzeigen, domains like .de, .com)
5. Maintain product accuracy (brand, size, color, condition)
6. Use natural {language_names.get(language)} language

RESPONSE FORMAT (JSON):
{{
    "title": "New unique title here",
    "description": "New unique description here",
    "keywords": ["keyword1", "keyword2", "keyword3"]
}}"""

        return prompt

    def parse_groq_response(self, content):
        """Parse Groq API response"""
        try:
            # Try JSON parsing
            if '{' in content and '}' in content:
                json_start = content.find('{')
                json_end = content.rfind('}') + 1
                json_str = content[json_start:json_end]
                data = json.loads(json_str)

                return {
                    'title': data.get('title', ''),
                    'description': data.get('description', ''),
                    'keywords': data.get('keywords', [])
                }

        except Exception as e:
            self.logger.warning("JSON parse hatası, regex fallback", exception=e)

        # Fallback: regex parsing
        title_match = re.search(r'"title"\s*:\s*"([^"]+)"', content)
        desc_match = re.search(r'"description"\s*:\s*"([^"]+)"', content)
        keywords_match = re.findall(r'"([^"]+)"', content)

        return {
            'title': title_match.group(1) if title_match else '',
            'description': desc_match.group(1) if desc_match else '',
            'keywords': keywords_match[:8] if keywords_match else []
        }

    def generate_bulk_variations(self, products, platform="ebay_de", language="de", style="balanced"):
        """
        Generate variations for multiple products

        Args:
            products: List of dicts with 'title', 'description'

        Returns:
            list: List of variation results
        """
        results = []

        self.logger.info("Bulk SEO generation başladı", count=len(products))

        for idx, product in enumerate(products, 1):
            self.logger.info(f"İşleniyor [{idx}/{len(products)}]", title=product.get('title', '')[:30])

            try:
                variation = self.generate_variation(
                    original_title=product.get('title', ''),
                    original_description=product.get('description', ''),
                    platform=platform,
                    language=language,
                    variation_style=style
                )

                results.append({
                    'original': product,
                    'variation': variation,
                    'success': True
                })

            except Exception as e:
                self.logger.error("Variation hatası", exception=e, product=product.get('title', '')[:30])
                results.append({
                    'original': product,
                    'variation': None,
                    'success': False
                })

        success_count = sum(1 for r in results if r['success'])

        self.logger.success(
            "Bulk generation tamamlandı",
            total=len(products),
            success=success_count,
            cache_size=len(self.cache)
        )

        return results

    def get_stats(self):
        """Get generator statistics"""
        return {
            'cache_entries': len(self.cache),
            'requests_today': self.request_count,
            'daily_limit': self.daily_limit,
            'remaining': self.daily_limit - self.request_count
        }


if __name__ == "__main__":
    print("\n" + "="*80)
    print("🎯 TATANGA GROQ SEO GENERATOR")
    print("="*80)
    print("\nKullanım:")
    print("  generator = GroqSEOGenerator()")
    print("  result = generator.generate_variation(")
    print("      original_title='Nike Air Max 90...',")
    print("      original_description='Neuwertig...',")
    print("      platform='ebay_de',")
    print("      language='de'")
    print("  )")
    print("\nVariation Styles:")
    print("  conservative → Minimal değişiklik, güvenli")
    print("  balanced     → Orta seviye, optimize edilmiş")
    print("  aggressive   → Tamamen farklı, yaratıcı")
    print("\nRate Limit:")
    print("  14,400 requests/day (Groq free tier)")
    print("="*80 + "\n")

    # Test
    generator = GroqSEOGenerator()

    # Check if API key exists
    if not generator.client:
        print("⚠️  Groq API key bulunamadı!")
        print("   config/credentials.py dosyasına API key ekleyin")
        print("   Ücretsiz key: https://console.groq.com/keys")
    else:
        print("✅ Groq API aktif")
        stats = generator.get_stats()
        print(f"📊 Cache: {stats['cache_entries']} entries")
        print(f"📊 Günlük kalan: {stats['remaining']}/{stats['daily_limit']}")
