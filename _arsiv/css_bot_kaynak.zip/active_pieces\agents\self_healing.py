#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Self-Healing System
Automatic error detection, analysis, and repair

Features:
- Continuous error monitoring
- Pattern-based error classification
- Automatic repair strategies
- Selector auto-update via Vision AI (ONLY for selector repair!)
- Session refresh
- Proxy rotation
- Failed operation restart
- Event Bus Integration (emit/subscribe)

IMPORTANT: Vision AI is used ONLY for selector repair, NOT for data extraction!
Data extraction is handled by traditional scrapers.

Author: TATANGA Team
Version: 2.0 (Event-Driven)
"""

import sys
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path
import sqlite3
import json
import re
import traceback

sys.path.insert(0, str(Path(__file__).parent.parent))

# Event Bus Integration
try:
    from core.event_bus import get_event_bus, emit, subscribe
except ImportError:
    def get_event_bus(): return None
    async def emit(*args, **kwargs): pass
    def subscribe(*args, **kwargs): pass

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")


class ErrorType:
    """Error type classifications"""
    SELECTOR_FAILED = 'selector_failed'
    TIMEOUT = 'timeout'
    BLOCKED = 'blocked'
    RATE_LIMITED = 'rate_limited'
    LOGIN_FAILED = 'login_failed'
    SESSION_EXPIRED = 'session_expired'
    CAPTCHA = 'captcha'
    NETWORK = 'network'
    API_ERROR = 'api_error'
    UNKNOWN = 'unknown'


class SelfHealingSystem:
    """
    Self-Healing System - Automatic error detection and repair

    Monitors system errors and attempts automatic recovery:
    1. Selector failures → Vision AI selector update
    2. Timeouts → Increase timeout, retry
    3. Blocked → Proxy rotation
    4. Rate limited → Backoff strategy
    5. Login failed → Session refresh
    6. Session expired → Re-login
    7. Captcha → Notify admin (can't auto-solve)
    """

    # Error patterns for classification
    ERROR_PATTERNS = {
        ErrorType.SELECTOR_FAILED: [
            r'no such element',
            r'element not found',
            r'unable to locate',
            r'selector.*failed',
            r'stale element',
        ],
        ErrorType.TIMEOUT: [
            r'timeout',
            r'timed out',
            r'time.*exceeded',
            r'deadline exceeded',
        ],
        ErrorType.BLOCKED: [
            r'403',
            r'forbidden',
            r'access denied',
            r'blocked',
            r'banned',
        ],
        ErrorType.RATE_LIMITED: [
            r'429',
            r'too many requests',
            r'rate limit',
            r'throttl',
        ],
        ErrorType.LOGIN_FAILED: [
            r'login failed',
            r'invalid credentials',
            r'authentication failed',
            r'incorrect password',
        ],
        ErrorType.SESSION_EXPIRED: [
            r'session expired',
            r'please log in',
            r'not authenticated',
            r'unauthorized',
            r'401',
        ],
        ErrorType.CAPTCHA: [
            r'captcha',
            r'verify.*human',
            r'robot',
            r'recaptcha',
        ],
        ErrorType.NETWORK: [
            r'connection.*refused',
            r'network.*error',
            r'dns.*failed',
            r'unreachable',
        ],
        ErrorType.API_ERROR: [
            r'api.*error',
            r'invalid.*response',
            r'json.*error',
            r'500',
            r'502',
            r'503',
        ],
    }

    # Repair strategies per error type
    REPAIR_STRATEGIES = {
        ErrorType.SELECTOR_FAILED: ['update_selector', 'try_alternative_selector', 'screenshot_fallback'],
        ErrorType.TIMEOUT: ['increase_timeout', 'retry', 'use_faster_proxy'],
        ErrorType.BLOCKED: ['rotate_proxy', 'change_user_agent', 'wait_and_retry'],
        ErrorType.RATE_LIMITED: ['exponential_backoff', 'rotate_account', 'reduce_frequency'],
        ErrorType.LOGIN_FAILED: ['verify_credentials', 'refresh_session', 'notify_admin'],
        ErrorType.SESSION_EXPIRED: ['refresh_session', 're_login', 'clear_cookies'],
        ErrorType.CAPTCHA: ['notify_admin', 'try_different_account'],
        ErrorType.NETWORK: ['retry', 'rotate_proxy', 'wait_and_retry'],
        ErrorType.API_ERROR: ['retry', 'refresh_token', 'notify_admin'],
        ErrorType.UNKNOWN: ['retry', 'log_for_analysis', 'notify_admin'],
    }

    def __init__(self, ceo_agent=None):
        """
        Initialize Self-Healing System with Event Bus Integration

        Args:
            ceo_agent: Reference to CEO Agent (optional, can work standalone)
        """
        self.ceo = ceo_agent
        self.logger = ModuleLogger("self_healing")

        # Event Bus
        self.event_bus = get_event_bus()

        # Database
        self.db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'

        # Vision agent for selector updates ONLY (NOT for data extraction!)
        self.vision_agent = None

        # Configuration
        self.config = {
            'monitor_interval': 300,  # 5 minutes
            'max_auto_repairs': 5,    # Max repairs per error type per hour
            'retry_delay': 30,        # Base retry delay in seconds
            'max_retries': 3,
            'notify_after_failures': 3,
            'vision_only_for_selectors': True,  # IMPORTANT: Vision AI only for selector repair
        }

        # Statistics
        self.stats = {
            'errors_detected': 0,
            'errors_classified': 0,
            'repairs_attempted': 0,
            'repairs_successful': 0,
            'selectors_repaired': 0,
            'vision_calls': 0,
            'notifications_sent': 0
        }

        # Recent repairs (to prevent loops)
        self.recent_repairs: Dict[str, List[datetime]] = {}

        # Pending retry operations
        self.pending_retries: List[Dict] = []

        self.running = False

        # Subscribe to events
        self._setup_event_subscriptions()

        self.logger.info("Self-Healing System initialized (Event-Driven v2.0)")

    def _setup_event_subscriptions(self):
        """Setup Event Bus subscriptions"""
        if self.event_bus:
            # Subscribe to selector failures
            subscribe('selector_failed', self._handle_selector_failed)

            # Subscribe to general errors
            subscribe('error_occurred', self._handle_error_occurred)

            # Subscribe to retry requests
            subscribe('operation_retry', self._handle_operation_retry)

            self.logger.info("Event subscriptions configured")

    async def _handle_selector_failed(self, event):
        """
        Handle selector_failed events from scrapers

        This is where Vision AI is used - ONLY for finding new selectors,
        NOT for extracting data!
        """
        data = event.data
        platform = data.get('platform')
        selector = data.get('selector')
        element_type = data.get('element_type')
        url = data.get('url')
        screenshot = data.get('screenshot')  # bytes

        self.logger.info(f"Selector failed event: {platform} - {element_type}")
        self.stats['errors_detected'] += 1

        # Log error to database
        self.log_error(
            agent_name='scraper',
            platform=platform,
            error_message=f"Selector failed: {selector}",
            error_type=ErrorType.SELECTOR_FAILED,
            url=url,
            selector=selector,
            context={'element_type': element_type}
        )

        # Attempt selector repair using Vision AI
        if screenshot:
            new_selector = await self._repair_selector_with_vision(
                screenshot=screenshot,
                element_type=element_type,
                description=f"{element_type} element on {platform}"
            )

            if new_selector:
                # Emit success event
                await emit('selector_repaired', {
                    'platform': platform,
                    'old_selector': selector,
                    'new_selector': new_selector,
                    'element_type': element_type
                }, source='self_healing')

                self.stats['selectors_repaired'] += 1
                return

        # If Vision AI fails, try alternative selectors from database
        success = await self._try_alternative_selector({
            'platform': platform,
            'selector': selector,
            'context': json.dumps({'element_type': element_type, 'page_type': 'search'})
        })

        if not success:
            # Emit notification event
            await emit('system_health', {
                'component': 'selector',
                'status': 'degraded',
                'platform': platform,
                'message': f"Selector repair failed for {element_type}"
            }, source='self_healing')

    async def _handle_error_occurred(self, event):
        """Handle general error events"""
        data = event.data

        self.log_error(
            agent_name=data.get('agent', 'unknown'),
            platform=data.get('platform', 'unknown'),
            error_message=data.get('message', 'Unknown error'),
            error_type=data.get('type'),
            stack_trace=data.get('stack_trace'),
            url=data.get('url'),
            context=data.get('context')
        )

    async def _handle_operation_retry(self, event):
        """Handle operation retry requests"""
        data = event.data
        self.pending_retries.append({
            'data': data,
            'timestamp': datetime.now(),
            'attempts': 0
        })
        self.logger.info(f"Operation queued for retry: {data.get('operation')}")

    async def start(self):
        """Start the self-healing monitor"""
        self.running = True
        self.logger.info("Self-Healing System started (Event-Driven)")

        # Emit system start event
        await emit('system_health', {
            'component': 'self_healing',
            'status': 'running',
            'message': 'Self-Healing System started'
        }, source='self_healing')

        while self.running:
            try:
                # Monitor database errors
                await self.monitor_and_heal()

                # Process pending retries
                await self._process_pending_retries()

            except Exception as e:
                self.logger.error("Monitor cycle error", exception=str(e))
                await emit('error_occurred', {
                    'agent': 'self_healing',
                    'message': str(e),
                    'stack_trace': traceback.format_exc()
                }, source='self_healing')

            await asyncio.sleep(self.config['monitor_interval'])

    async def _process_pending_retries(self):
        """Process pending retry operations"""
        if not self.pending_retries:
            return

        now = datetime.now()
        to_remove = []

        for i, retry in enumerate(self.pending_retries):
            # Check if enough time has passed
            wait_time = self.config['retry_delay'] * (2 ** retry['attempts'])  # Exponential backoff
            if (now - retry['timestamp']).total_seconds() < wait_time:
                continue

            data = retry['data']
            retry['attempts'] += 1

            if retry['attempts'] > self.config['max_retries']:
                self.logger.warning(f"Max retries exceeded for: {data.get('operation')}")
                to_remove.append(i)
                continue

            # Emit retry event
            await emit('scrape_requested', {
                'query': data.get('query'),
                'platform': data.get('platform'),
                'is_retry': True,
                'retry_count': retry['attempts']
            }, source='self_healing')

            retry['timestamp'] = now

        # Remove completed retries
        for i in sorted(to_remove, reverse=True):
            self.pending_retries.pop(i)

    async def stop(self):
        """Stop the self-healing monitor"""
        self.running = False

        # Emit system stop event
        await emit('system_health', {
            'component': 'self_healing',
            'status': 'stopped',
            'message': 'Self-Healing System stopped',
            'stats': self.get_stats()
        }, source='self_healing')

        self.logger.info("Self-Healing System stopped")

    async def monitor_and_heal(self):
        """Main monitoring and healing cycle"""
        # 1. Get recent errors from database
        errors = self._get_unresolved_errors()

        for error in errors:
            self.stats['errors_detected'] += 1

            # 2. Classify error
            error_type = self._classify_error(error)
            self.stats['errors_classified'] += 1

            # 3. Check if we should attempt repair
            if self._should_attempt_repair(error_type, error.get('platform')):

                # 4. Attempt repair
                success = await self._attempt_repair(error, error_type)

                if success:
                    self._mark_error_resolved(error['id'], 'auto_healed')
                    self.stats['repairs_successful'] += 1
                else:
                    # Notify admin after multiple failures
                    failure_count = self._get_failure_count(error_type, error.get('platform'))
                    if failure_count >= self.config['notify_after_failures']:
                        await self._notify_admin(error, error_type)

    def _get_unresolved_errors(self, limit: int = 50) -> List[Dict]:
        """Get unresolved errors from database"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            cursor.execute("""
                SELECT * FROM error_log
                WHERE is_resolved = 0
                ORDER BY created_at DESC
                LIMIT ?
            """, (limit,))

            rows = cursor.fetchall()
            conn.close()

            return [dict(row) for row in rows]

        except Exception as e:
            self.logger.error("Failed to get errors", exception=str(e))
            return []

    def _classify_error(self, error: Dict) -> str:
        """
        Classify error based on error message patterns

        Args:
            error: Error record from database

        Returns:
            Error type classification
        """
        message = (error.get('error_message', '') + ' ' + error.get('stack_trace', '')).lower()

        for error_type, patterns in self.ERROR_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, message, re.IGNORECASE):
                    return error_type

        return ErrorType.UNKNOWN

    def _should_attempt_repair(self, error_type: str, platform: str) -> bool:
        """
        Check if we should attempt automatic repair

        Prevents repair loops by limiting repairs per time window.

        Args:
            error_type: Type of error
            platform: Platform where error occurred

        Returns:
            Whether to attempt repair
        """
        key = f"{error_type}:{platform}"
        now = datetime.now()
        hour_ago = now - timedelta(hours=1)

        # Get recent repairs for this error type
        recent = self.recent_repairs.get(key, [])
        recent = [t for t in recent if t > hour_ago]
        self.recent_repairs[key] = recent

        return len(recent) < self.config['max_auto_repairs']

    async def _attempt_repair(self, error: Dict, error_type: str) -> bool:
        """
        Attempt to repair an error

        Args:
            error: Error record
            error_type: Classified error type

        Returns:
            Whether repair was successful
        """
        self.stats['repairs_attempted'] += 1
        platform = error.get('platform')

        # Record this repair attempt
        key = f"{error_type}:{platform}"
        if key not in self.recent_repairs:
            self.recent_repairs[key] = []
        self.recent_repairs[key].append(datetime.now())

        # Get repair strategies for this error type
        strategies = self.REPAIR_STRATEGIES.get(error_type, ['retry'])

        for strategy in strategies:
            self.logger.info(f"Attempting repair: {strategy} for {error_type}")

            try:
                success = await self._execute_strategy(strategy, error, error_type)

                if success:
                    self.logger.info(f"Repair successful: {strategy}")
                    return True

            except Exception as e:
                self.logger.error(f"Repair strategy failed: {strategy}", exception=str(e))

        return False

    async def _execute_strategy(self, strategy: str, error: Dict, error_type: str) -> bool:
        """
        Execute a specific repair strategy

        Args:
            strategy: Strategy name
            error: Error record
            error_type: Error type

        Returns:
            Whether strategy was successful
        """
        platform = error.get('platform')

        if strategy == 'update_selector':
            return await self._update_selector(error)

        elif strategy == 'try_alternative_selector':
            return await self._try_alternative_selector(error)

        elif strategy == 'screenshot_fallback':
            return await self._enable_screenshot_fallback(platform)

        elif strategy == 'increase_timeout':
            return self._increase_timeout(platform)

        elif strategy == 'retry':
            return await self._retry_operation(error)

        elif strategy == 'rotate_proxy':
            return await self._rotate_proxy(platform)

        elif strategy == 'change_user_agent':
            return await self._change_user_agent(platform)

        elif strategy == 'wait_and_retry':
            await asyncio.sleep(self.config['retry_delay'])
            return await self._retry_operation(error)

        elif strategy == 'exponential_backoff':
            return await self._apply_backoff(platform)

        elif strategy == 'rotate_account':
            return await self._rotate_account(platform)

        elif strategy == 'refresh_session':
            return await self._refresh_session(platform)

        elif strategy == 're_login':
            return await self._re_login(platform)

        elif strategy == 'clear_cookies':
            return self._clear_cookies(platform)

        elif strategy == 'refresh_token':
            return await self._refresh_token(platform)

        elif strategy == 'notify_admin':
            await self._notify_admin(error, error_type)
            return False  # Not a repair, just notification

        elif strategy == 'log_for_analysis':
            self._log_for_analysis(error)
            return False

        return False

    # ==================== REPAIR STRATEGY IMPLEMENTATIONS ====================

    async def _repair_selector_with_vision(self, screenshot: bytes,
                                           element_type: str,
                                           description: str) -> Optional[str]:
        """
        Repair a broken selector using Vision AI

        IMPORTANT: This is the ONLY place Vision AI should be used!
        Vision AI is a "selector repairman", NOT a data extractor.

        Args:
            screenshot: Screenshot bytes of the page
            element_type: Type of element (button, link, input, etc.)
            description: Description of what element we're looking for

        Returns:
            New CSS selector or None if repair failed
        """
        if not self.config.get('vision_only_for_selectors', True):
            self.logger.warning("Vision AI usage is restricted to selector repair only!")
            return None

        # Lazy load Vision Agent
        if not self.vision_agent:
            try:
                from agents.vision_agent import VisionAgent
                self.vision_agent = VisionAgent()
            except ImportError:
                self.logger.error("VisionAgent not available")
                return None

        try:
            self.stats['vision_calls'] += 1

            # Use Vision AI ONLY for finding selectors
            # NOT for extract_product_data or detect_product_urls!
            new_selector = await self.vision_agent.find_selector(
                screenshot=screenshot,
                element_type=element_type,
                description=description
            )

            if new_selector:
                self.logger.info(f"Vision AI found new selector: {new_selector}")

                # Save to database for future use
                await self._save_new_selector(
                    element_type=element_type,
                    selector=new_selector,
                    source='vision_ai'
                )

                return new_selector

            return None

        except Exception as e:
            self.logger.error("Vision AI selector repair failed", exception=str(e))
            return None

    async def _save_new_selector(self, element_type: str, selector: str,
                                  platform: str = None, source: str = 'vision_ai'):
        """Save newly discovered selector to database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT OR REPLACE INTO selectors
                (platform, page_type, element_type, selector, is_active, source, last_updated)
                VALUES (?, 'search', ?, ?, 1, ?, ?)
            """, (platform or 'unknown', element_type, selector, source, datetime.now().isoformat()))

            conn.commit()
            conn.close()

            self.logger.info(f"Saved new selector: {selector}")

        except Exception as e:
            self.logger.error("Failed to save selector", exception=str(e))

    async def _update_selector(self, error: Dict) -> bool:
        """
        Update failed selector using Vision AI

        This method is called from the repair strategy system.
        It uses _repair_selector_with_vision internally.
        """
        context = json.loads(error.get('context', '{}')) if error.get('context') else {}
        element_type = context.get('element_type', 'unknown')
        screenshot = context.get('screenshot')  # May be stored as base64

        if not screenshot:
            # No screenshot available, try alternative selectors instead
            return await self._try_alternative_selector(error)

        # Decode base64 if necessary
        if isinstance(screenshot, str):
            import base64
            try:
                screenshot = base64.b64decode(screenshot)
            except:
                return False

        new_selector = await self._repair_selector_with_vision(
            screenshot=screenshot,
            element_type=element_type,
            description=f"{element_type} on {error.get('platform')}"
        )

        if new_selector:
            # Emit selector repaired event
            await emit('selector_repaired', {
                'platform': error.get('platform'),
                'old_selector': error.get('selector'),
                'new_selector': new_selector,
                'element_type': element_type
            }, source='self_healing')

            self.stats['selectors_repaired'] += 1
            return True

        return False

    async def _try_alternative_selector(self, error: Dict) -> bool:
        """Try alternative selectors from database"""
        platform = error.get('platform')
        context = json.loads(error.get('context', '{}')) if error.get('context') else {}
        page_type = context.get('page_type', 'search')
        element_type = context.get('element_type', 'item')

        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            # Get alternative selectors
            cursor.execute("""
                SELECT selector FROM selectors
                WHERE platform = ? AND page_type = ? AND element_type = ?
                AND is_active = 1
                ORDER BY success_rate DESC
                LIMIT 5
            """, (platform, page_type, element_type))

            alternatives = [row[0] for row in cursor.fetchall()]
            conn.close()

            # Would test each alternative
            # For now, return success if alternatives exist
            return len(alternatives) > 0

        except Exception as e:
            self.logger.error("Alternative selector failed", exception=str(e))
            return False

    async def _enable_screenshot_fallback(self, platform: str) -> bool:
        """Enable screenshot fallback for platform"""
        if self.ceo:
            scraping_manager = self.ceo.get_manager(self.ceo.ManagerType.SCRAPING) if hasattr(self.ceo, 'ManagerType') else None
            if scraping_manager:
                # Enable fallback mode
                scraping_manager.screenshot_fallback_enabled = True
                return True
        return False

    def _increase_timeout(self, platform: str) -> bool:
        """Increase timeout for platform"""
        # Would update platform config
        return True

    async def _retry_operation(self, error: Dict) -> bool:
        """Retry the failed operation"""
        # Would re-queue the operation
        return True

    async def _rotate_proxy(self, platform: str) -> bool:
        """Rotate to a different proxy"""
        # Would update proxy settings
        return True

    async def _change_user_agent(self, platform: str) -> bool:
        """Change user agent"""
        # Would update user agent
        return True

    async def _apply_backoff(self, platform: str) -> bool:
        """Apply exponential backoff"""
        # Would adjust rate limiting
        return True

    async def _rotate_account(self, platform: str) -> bool:
        """Rotate to different account"""
        # Would switch accounts
        return True

    async def _refresh_session(self, platform: str) -> bool:
        """Refresh session cookies"""
        # Would refresh session
        return True

    async def _re_login(self, platform: str) -> bool:
        """Re-login to platform"""
        # Would perform login
        return True

    def _clear_cookies(self, platform: str) -> bool:
        """Clear cookies for platform"""
        # Would clear cookies
        return True

    async def _refresh_token(self, platform: str) -> bool:
        """Refresh API token"""
        # Would refresh token
        return True

    def _log_for_analysis(self, error: Dict):
        """Log error for manual analysis"""
        self.logger.warning(f"Error logged for analysis: {error.get('error_type')}")

    # ==================== DATABASE OPERATIONS ====================

    def _mark_error_resolved(self, error_id: int, resolution: str):
        """Mark error as resolved in database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                UPDATE error_log SET
                    is_resolved = 1,
                    resolution = ?,
                    resolved_at = ?,
                    auto_healed = 1
                WHERE id = ?
            """, (resolution, datetime.now().isoformat(), error_id))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error("Failed to mark error resolved", exception=str(e))

    def _get_failure_count(self, error_type: str, platform: str) -> int:
        """Get count of recent failures for error type"""
        key = f"{error_type}:{platform}"
        return len(self.recent_repairs.get(key, []))

    async def _notify_admin(self, error: Dict, error_type: str):
        """Send notification to admin about unresolved error via Event Bus"""
        self.stats['notifications_sent'] += 1

        message = (
            f"⚠️ *Self-Healing Başarısız*\n\n"
            f"Hata Tipi: `{error_type}`\n"
            f"Platform: {error.get('platform', 'unknown')}\n"
            f"Mesaj: {error.get('error_message', 'N/A')[:200]}\n\n"
            f"Manuel müdahale gerekli."
        )

        # Emit notification via Event Bus (Telegram Bot subscribes to this)
        await emit('admin_notification', {
            'message': message,
            'priority': 'high',
            'error_type': error_type,
            'platform': error.get('platform'),
            'requires_action': True
        }, source='self_healing')

        # Also emit system health degraded event
        await emit('system_health', {
            'component': 'scraping',
            'status': 'degraded',
            'platform': error.get('platform'),
            'error_type': error_type,
            'message': f"Self-healing failed for {error_type}"
        }, source='self_healing')

        # Legacy CEO support (if available)
        if self.ceo and hasattr(self.ceo, 'send_telegram_notification'):
            await self.ceo.send_telegram_notification(message, priority='high')

    # ==================== PUBLIC API ====================

    def log_error(self,
                  agent_name: str,
                  platform: str,
                  error_message: str,
                  error_type: str = None,
                  stack_trace: str = None,
                  url: str = None,
                  selector: str = None,
                  context: Dict = None):
        """
        Log an error for monitoring

        Args:
            agent_name: Name of the agent that encountered error
            platform: Platform where error occurred
            error_message: Error message
            error_type: Optional pre-classified error type
            stack_trace: Optional stack trace
            url: URL where error occurred
            selector: Selector that failed
            context: Additional context
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO error_log
                (agent_name, platform, error_type, error_message, stack_trace, url, selector, context)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                agent_name,
                platform,
                error_type or ErrorType.UNKNOWN,
                error_message,
                stack_trace,
                url,
                selector,
                json.dumps(context) if context else None
            ))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error("Failed to log error", exception=str(e))

    def get_stats(self) -> Dict:
        """Get self-healing statistics"""
        return {
            **self.stats,
            'success_rate': round(
                self.stats['repairs_successful'] / max(1, self.stats['repairs_attempted']) * 100, 2
            ),
            'pending_retries': len(self.pending_retries),
            'recent_repairs_count': sum(len(r) for r in self.recent_repairs.values())
        }

    # ==================== SCRAPER INTEGRATION HELPERS ====================

    async def report_selector_failure(self, platform: str, selector: str,
                                      element_type: str, url: str = None,
                                      screenshot: bytes = None):
        """
        Helper method for scrapers to report selector failures

        Scrapers should call this when a selector fails instead of
        directly emitting events.

        Args:
            platform: Platform name (e.g., 'vinted_de')
            selector: The CSS selector that failed
            element_type: Type of element (e.g., 'product_card', 'price', 'title')
            url: URL where the failure occurred
            screenshot: Screenshot bytes for Vision AI repair
        """
        await emit('selector_failed', {
            'platform': platform,
            'selector': selector,
            'element_type': element_type,
            'url': url,
            'screenshot': screenshot
        }, source='scraper')

    async def report_scraping_error(self, platform: str, error_message: str,
                                    error_type: str = None, url: str = None,
                                    context: Dict = None):
        """
        Helper method for scrapers to report general errors

        Args:
            platform: Platform name
            error_message: Error message
            error_type: Error type (use ErrorType constants)
            url: URL where error occurred
            context: Additional context
        """
        await emit('error_occurred', {
            'agent': 'scraper',
            'platform': platform,
            'message': error_message,
            'type': error_type or ErrorType.UNKNOWN,
            'url': url,
            'context': context
        }, source='scraper')

    async def request_operation_retry(self, operation: str, platform: str,
                                      query: str = None, context: Dict = None):
        """
        Request retry of a failed operation

        Args:
            operation: Operation name (e.g., 'search', 'fetch_product')
            platform: Platform name
            query: Search query (if applicable)
            context: Additional context
        """
        await emit('operation_retry', {
            'operation': operation,
            'platform': platform,
            'query': query,
            'context': context
        }, source='scraper')


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("SELF-HEALING SYSTEM TEST (Event-Driven v2.0)")
    print("=" * 60)

    async def test():
        healing = SelfHealingSystem()

        # Test error classification
        test_errors = [
            "Element not found: .product-title",
            "Request timed out after 30 seconds",
            "403 Forbidden - Access Denied",
            "429 Too Many Requests",
            "Login failed: Invalid credentials",
            "Session expired, please log in again",
            "Captcha verification required",
            "Connection refused by host",
            "API Error: Invalid response format",
            "Unknown error occurred"
        ]

        print("\n1. Error Classification Tests:")
        print("-" * 40)
        for error_msg in test_errors:
            error_type = healing._classify_error({'error_message': error_msg})
            print(f"  '{error_msg[:40]}...' -> {error_type}")

        print(f"\n2. Repair Strategies:")
        print("-" * 40)
        for error_type, strategies in SelfHealingSystem.REPAIR_STRATEGIES.items():
            print(f"  {error_type}: {', '.join(strategies)}")

        print(f"\n3. Event Bus Integration:")
        print("-" * 40)
        print(f"  Event Bus connected: {healing.event_bus is not None}")
        print(f"  Vision AI for selectors only: {healing.config.get('vision_only_for_selectors')}")

        # Test helper methods
        print(f"\n4. Testing Scraper Integration Helpers:")
        print("-" * 40)

        # Simulate selector failure report
        print("  Simulating selector failure report...")
        await healing.report_selector_failure(
            platform='vinted_de',
            selector='.product-card',
            element_type='product_card',
            url='https://vinted.de/catalog?search=nike'
        )
        print("  ✓ report_selector_failure() called")

        # Simulate scraping error report
        print("  Simulating scraping error report...")
        await healing.report_scraping_error(
            platform='vinted_de',
            error_message='Connection timeout',
            error_type=ErrorType.TIMEOUT
        )
        print("  ✓ report_scraping_error() called")

        # Simulate retry request
        print("  Simulating operation retry request...")
        await healing.request_operation_retry(
            operation='search',
            platform='vinted_de',
            query='nike air max'
        )
        print("  ✓ request_operation_retry() called")

        print(f"\n5. Statistics:")
        print("-" * 40)
        stats = healing.get_stats()
        for key, value in stats.items():
            print(f"  {key}: {value}")

        print("\n" + "=" * 60)
        print("✅ SELF-HEALING SYSTEM TEST COMPLETE")
        print("=" * 60)
        print("\nKey Features:")
        print("  • Event Bus integration for decoupled communication")
        print("  • Vision AI used ONLY for selector repair (not data extraction)")
        print("  • Automatic retry with exponential backoff")
        print("  • Helper methods for scraper integration")
        print("  • Real-time event emission for monitoring")

    asyncio.run(test())
