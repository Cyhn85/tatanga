#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Accounting Manager
Manages invoices, financial tracking, and reporting

Features:
- Invoice downloading and archiving
- Sales and purchase tracking
- Profit/loss calculation
- Multi-currency support
- Financial reporting
- Tax calculation helpers

Author: TATANGA Team
Version: 1.0
"""

import sys
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from pathlib import Path
import sqlite3
import json
import os

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")


class AccountingManager:
    """
    Accounting Manager - Handles all financial operations

    Responsibilities:
    1. Download and archive invoices
    2. Track sales and purchases
    3. Calculate profits/losses
    4. Generate financial reports
    5. Multi-currency handling
    """

    # Platform fee percentages (approximate)
    PLATFORM_FEES = {
        'vinted': 0.05,       # 5% buyer protection fee
        'ebay': 0.13,         # ~13% (fees vary by category)
        'kleinanzeigen': 0.0, # No fees for basic listings
        'willhaben': 0.0,     # No fees for private sellers
        'leboncoin': 0.0,     # No fees for basic
        'shpock': 0.0,        # No fees
        'tradera': 0.10,      # 10% final value fee
        'sellpy': 0.40,       # 40% (consignment model)
        'percentil': 0.35,    # 35% (consignment model)
    }

    # Currency conversion rates (would be fetched from API in production)
    CURRENCY_RATES = {
        'EUR': 1.0,
        'GBP': 1.17,
        'USD': 0.92,
        'SEK': 0.087,
        'DKK': 0.134,
        'NOK': 0.086,
        'PLN': 0.22,
        'CZK': 0.041,
        'CHF': 1.05,
    }

    def __init__(self, ceo_agent):
        """
        Initialize Accounting Manager

        Args:
            ceo_agent: Reference to CEO Agent
        """
        self.ceo = ceo_agent
        self.logger = ModuleLogger("accounting_manager")

        # Database
        self.db_path = Path(__file__).parent.parent.parent / 'storage' / 'accounting.db'
        self._init_database()

        # Invoice archive path
        self.archive_path = Path(__file__).parent.parent.parent / 'storage' / 'invoices'
        self.archive_path.mkdir(parents=True, exist_ok=True)

        # Statistics
        self.stats = {
            'invoices_archived': 0,
            'total_revenue': 0.0,
            'total_costs': 0.0,
            'total_profit': 0.0
        }

        self.logger.info("Accounting Manager initialized")

    def _init_database(self):
        """Initialize accounting database"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Transactions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                platform TEXT,
                order_id TEXT,
                product_id TEXT,
                description TEXT,
                amount REAL NOT NULL,
                currency TEXT DEFAULT 'EUR',
                amount_eur REAL,
                platform_fee REAL DEFAULT 0,
                shipping_cost REAL DEFAULT 0,
                net_amount REAL,
                counterparty TEXT,
                transaction_date DATE DEFAULT CURRENT_DATE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Invoices table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS invoices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                order_id TEXT,
                invoice_number TEXT,
                invoice_type TEXT,
                amount REAL,
                currency TEXT,
                file_path TEXT,
                downloaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(platform, invoice_number)
            )
        """)

        # Monthly summaries
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS monthly_summaries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                year INTEGER NOT NULL,
                month INTEGER NOT NULL,
                total_sales REAL DEFAULT 0,
                total_purchases REAL DEFAULT 0,
                total_fees REAL DEFAULT 0,
                total_shipping REAL DEFAULT 0,
                net_profit REAL DEFAULT 0,
                transactions_count INTEGER DEFAULT 0,
                currency TEXT DEFAULT 'EUR',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(year, month)
            )
        """)

        # Platform earnings breakdown
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS platform_earnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                year INTEGER NOT NULL,
                month INTEGER NOT NULL,
                sales_count INTEGER DEFAULT 0,
                sales_amount REAL DEFAULT 0,
                fees_paid REAL DEFAULT 0,
                net_earnings REAL DEFAULT 0,
                UNIQUE(platform, year, month)
            )
        """)

        conn.commit()
        conn.close()

    # ==================== TRANSACTIONS ====================

    async def record_sale(self, sale_data: Dict) -> Dict:
        """
        Record a sale transaction

        Args:
            sale_data: Sale details

        Returns:
            Transaction result
        """
        try:
            amount = sale_data.get('amount', 0)
            currency = sale_data.get('currency', 'EUR')
            platform = sale_data.get('platform', 'unknown')

            # Convert to EUR
            amount_eur = self._convert_to_eur(amount, currency)

            # Calculate platform fee
            fee_rate = self.PLATFORM_FEES.get(platform.split('_')[0], 0.10)
            platform_fee = amount_eur * fee_rate

            # Calculate shipping
            shipping_cost = sale_data.get('shipping_cost', 0)

            # Calculate net
            net_amount = amount_eur - platform_fee - shipping_cost

            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO transactions
                (type, platform, order_id, product_id, description, amount, currency,
                 amount_eur, platform_fee, shipping_cost, net_amount, counterparty, transaction_date)
                VALUES ('sale', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                platform,
                sale_data.get('order_id'),
                sale_data.get('product_id'),
                sale_data.get('description'),
                amount,
                currency,
                amount_eur,
                platform_fee,
                shipping_cost,
                net_amount,
                sale_data.get('buyer'),
                sale_data.get('date', datetime.now().date().isoformat())
            ))

            conn.commit()
            conn.close()

            # Update stats
            self.stats['total_revenue'] += amount_eur
            self.stats['total_profit'] += net_amount

            self.logger.info(f"Sale recorded: {amount} {currency} ({amount_eur:.2f} EUR)")

            return {
                'success': True,
                'amount_eur': amount_eur,
                'platform_fee': platform_fee,
                'net_amount': net_amount
            }

        except Exception as e:
            self.logger.error("Failed to record sale", exception=str(e))
            return {'success': False, 'error': str(e)}

    async def record_purchase(self, purchase_data: Dict) -> Dict:
        """
        Record a purchase transaction

        Args:
            purchase_data: Purchase details

        Returns:
            Transaction result
        """
        try:
            amount = purchase_data.get('amount', 0)
            currency = purchase_data.get('currency', 'EUR')

            # Convert to EUR
            amount_eur = self._convert_to_eur(amount, currency)

            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO transactions
                (type, platform, order_id, product_id, description, amount, currency,
                 amount_eur, shipping_cost, net_amount, counterparty, transaction_date)
                VALUES ('purchase', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                purchase_data.get('platform'),
                purchase_data.get('order_id'),
                purchase_data.get('product_id'),
                purchase_data.get('description'),
                amount,
                currency,
                amount_eur,
                purchase_data.get('shipping_cost', 0),
                -amount_eur,  # Negative for purchases
                purchase_data.get('seller'),
                purchase_data.get('date', datetime.now().date().isoformat())
            ))

            conn.commit()
            conn.close()

            # Update stats
            self.stats['total_costs'] += amount_eur
            self.stats['total_profit'] -= amount_eur

            return {
                'success': True,
                'amount_eur': amount_eur
            }

        except Exception as e:
            self.logger.error("Failed to record purchase", exception=str(e))
            return {'success': False, 'error': str(e)}

    def _convert_to_eur(self, amount: float, currency: str) -> float:
        """Convert amount to EUR"""
        if currency == 'EUR':
            return amount

        rate = self.CURRENCY_RATES.get(currency, 1.0)
        return amount * rate

    # ==================== INVOICES ====================

    async def download_invoice(self, platform: str, order_id: str) -> Dict:
        """
        Download and archive an invoice

        Args:
            platform: Platform ID
            order_id: Order ID

        Returns:
            Download result with file path
        """
        self.logger.info(f"Downloading invoice for order {order_id} from {platform}")

        try:
            # Get platform connector
            scraping_manager = self.ceo.get_manager(self.ceo.ManagerType.SCRAPING) if hasattr(self.ceo, 'ManagerType') else None

            invoice_data = None

            if scraping_manager and platform in scraping_manager.scrapers:
                scraper = scraping_manager.scrapers[platform]

                if hasattr(scraper, 'download_invoice'):
                    invoice_data = await scraper.download_invoice(order_id)

            if not invoice_data:
                # Create placeholder record
                invoice_data = {
                    'invoice_number': f"{platform}_{order_id}",
                    'content': None,
                    'amount': None
                }

            # Create archive path
            platform_dir = self.archive_path / platform
            platform_dir.mkdir(exist_ok=True)

            file_name = f"{order_id}_{datetime.now().strftime('%Y%m%d')}.pdf"
            file_path = platform_dir / file_name

            # Save invoice if we have content
            if invoice_data.get('content'):
                with open(file_path, 'wb') as f:
                    f.write(invoice_data['content'])

            # Save to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT OR REPLACE INTO invoices
                (platform, order_id, invoice_number, amount, file_path)
                VALUES (?, ?, ?, ?, ?)
            """, (
                platform,
                order_id,
                invoice_data.get('invoice_number'),
                invoice_data.get('amount'),
                str(file_path) if invoice_data.get('content') else None
            ))

            conn.commit()
            conn.close()

            # Update stats
            self.stats['invoices_archived'] += 1
            self.ceo.metrics.invoices_archived += 1

            return {
                'success': True,
                'file_path': str(file_path) if invoice_data.get('content') else None,
                'invoice_number': invoice_data.get('invoice_number')
            }

        except Exception as e:
            self.logger.error("Failed to download invoice", exception=str(e))
            return {'success': False, 'error': str(e)}

    async def get_invoices(self, platform: str = None, limit: int = 50) -> List[Dict]:
        """Get archived invoices"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            if platform:
                cursor.execute("""
                    SELECT * FROM invoices WHERE platform = ?
                    ORDER BY downloaded_at DESC LIMIT ?
                """, (platform, limit))
            else:
                cursor.execute("""
                    SELECT * FROM invoices
                    ORDER BY downloaded_at DESC LIMIT ?
                """, (limit,))

            rows = cursor.fetchall()
            conn.close()

            return [dict(row) for row in rows]

        except Exception as e:
            self.logger.error("Failed to get invoices", exception=str(e))
            return []

    # ==================== REPORTS ====================

    async def generate_report(self, period: str = 'monthly', year: int = None, month: int = None) -> Dict:
        """
        Generate financial report

        Args:
            period: 'daily', 'weekly', 'monthly', 'yearly'
            year: Year for report
            month: Month for report (if monthly)

        Returns:
            Financial report
        """
        self.logger.info(f"Generating {period} report")

        now = datetime.now()
        year = year or now.year
        month = month or now.month

        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            # Determine date range
            if period == 'daily':
                start_date = now.date()
                end_date = start_date
            elif period == 'weekly':
                start_date = (now - timedelta(days=7)).date()
                end_date = now.date()
            elif period == 'monthly':
                start_date = datetime(year, month, 1).date()
                if month == 12:
                    end_date = datetime(year + 1, 1, 1).date() - timedelta(days=1)
                else:
                    end_date = datetime(year, month + 1, 1).date() - timedelta(days=1)
            else:  # yearly
                start_date = datetime(year, 1, 1).date()
                end_date = datetime(year, 12, 31).date()

            # Get totals
            cursor.execute("""
                SELECT
                    SUM(CASE WHEN type = 'sale' THEN amount_eur ELSE 0 END) as total_sales,
                    SUM(CASE WHEN type = 'purchase' THEN amount_eur ELSE 0 END) as total_purchases,
                    SUM(platform_fee) as total_fees,
                    SUM(shipping_cost) as total_shipping,
                    SUM(net_amount) as net_total,
                    COUNT(*) as transaction_count
                FROM transactions
                WHERE transaction_date BETWEEN ? AND ?
            """, (start_date.isoformat(), end_date.isoformat()))

            totals = dict(cursor.fetchone())

            # Get by platform
            cursor.execute("""
                SELECT
                    platform,
                    SUM(CASE WHEN type = 'sale' THEN amount_eur ELSE 0 END) as sales,
                    SUM(platform_fee) as fees,
                    COUNT(CASE WHEN type = 'sale' THEN 1 END) as sales_count
                FROM transactions
                WHERE transaction_date BETWEEN ? AND ?
                GROUP BY platform
            """, (start_date.isoformat(), end_date.isoformat()))

            by_platform = [dict(row) for row in cursor.fetchall()]

            conn.close()

            report = {
                'period': period,
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat(),
                'totals': {
                    'sales': totals['total_sales'] or 0,
                    'purchases': totals['total_purchases'] or 0,
                    'platform_fees': totals['total_fees'] or 0,
                    'shipping': totals['total_shipping'] or 0,
                    'net_profit': totals['net_total'] or 0,
                    'transactions': totals['transaction_count'] or 0
                },
                'by_platform': by_platform,
                'currency': 'EUR',
                'generated_at': datetime.now().isoformat()
            }

            # Send summary via Telegram
            summary = (
                f"📊 *Financial Report - {period.capitalize()}*\n\n"
                f"Period: {start_date} - {end_date}\n"
                f"Sales: €{report['totals']['sales']:.2f}\n"
                f"Purchases: €{report['totals']['purchases']:.2f}\n"
                f"Platform Fees: €{report['totals']['platform_fees']:.2f}\n"
                f"Shipping: €{report['totals']['shipping']:.2f}\n"
                f"*Net Profit: €{report['totals']['net_profit']:.2f}*\n"
                f"Transactions: {report['totals']['transactions']}"
            )

            await self.ceo.send_telegram_notification(summary, priority='normal')

            return report

        except Exception as e:
            self.logger.error("Failed to generate report", exception=str(e))
            return {'error': str(e)}

    async def get_profit_loss(self, year: int = None, month: int = None) -> Dict:
        """
        Get profit/loss summary

        Args:
            year: Year
            month: Month (optional)

        Returns:
            P&L summary
        """
        now = datetime.now()
        year = year or now.year

        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            if month:
                cursor.execute("""
                    SELECT
                        SUM(CASE WHEN type = 'sale' THEN net_amount ELSE 0 END) as gross_profit,
                        SUM(CASE WHEN type = 'purchase' THEN ABS(net_amount) ELSE 0 END) as cost_of_goods,
                        SUM(platform_fee) as platform_fees,
                        SUM(shipping_cost) as shipping_costs
                    FROM transactions
                    WHERE strftime('%Y', transaction_date) = ?
                    AND strftime('%m', transaction_date) = ?
                """, (str(year), str(month).zfill(2)))
            else:
                cursor.execute("""
                    SELECT
                        SUM(CASE WHEN type = 'sale' THEN net_amount ELSE 0 END) as gross_profit,
                        SUM(CASE WHEN type = 'purchase' THEN ABS(net_amount) ELSE 0 END) as cost_of_goods,
                        SUM(platform_fee) as platform_fees,
                        SUM(shipping_cost) as shipping_costs
                    FROM transactions
                    WHERE strftime('%Y', transaction_date) = ?
                """, (str(year),))

            row = cursor.fetchone()
            conn.close()

            gross_profit = row[0] or 0
            cost_of_goods = row[1] or 0
            platform_fees = row[2] or 0
            shipping_costs = row[3] or 0

            net_profit = gross_profit - cost_of_goods

            return {
                'year': year,
                'month': month,
                'gross_profit': round(gross_profit, 2),
                'cost_of_goods': round(cost_of_goods, 2),
                'platform_fees': round(platform_fees, 2),
                'shipping_costs': round(shipping_costs, 2),
                'net_profit': round(net_profit, 2),
                'profit_margin': round((net_profit / gross_profit * 100) if gross_profit > 0 else 0, 1)
            }

        except Exception as e:
            self.logger.error("Failed to get P&L", exception=str(e))
            return {'error': str(e)}

    # ==================== STATUS ====================

    def get_status(self) -> Dict:
        """Get manager status"""
        return {
            'status': 'healthy',
            'stats': self.stats,
            'archive_path': str(self.archive_path)
        }


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("ACCOUNTING MANAGER TEST")
    print("=" * 60)

    class MockCEO:
        class ManagerType:
            SCRAPING = 'scraping'

        def get_manager(self, t):
            return None

        async def send_telegram_notification(self, msg, priority):
            print(f"[TELEGRAM] {msg}")

        class metrics:
            invoices_archived = 0

    async def test():
        ceo = MockCEO()
        manager = AccountingManager(ceo)

        # Test record sale
        result = await manager.record_sale({
            'platform': 'vinted_de',
            'order_id': 'TEST001',
            'product_id': 'PROD001',
            'description': 'Nike Air Max',
            'amount': 50.0,
            'currency': 'EUR',
            'shipping_cost': 5.99,
            'buyer': 'TestBuyer'
        })
        print(f"\nSale recorded: {result}")

        # Test P&L
        pnl = await manager.get_profit_loss()
        print(f"\nP&L: {pnl}")

        # Test report
        report = await manager.generate_report('monthly')
        print(f"\nReport totals: {report.get('totals', {})}")

        print(f"\nStatus: {manager.get_status()}")
        print("\n✅ Accounting Manager test complete!")

    asyncio.run(test())
    print("=" * 60)
