# Vinted Relister API
# FastAPI backend for the automation pipeline (Port 8504)

import os
import sys
import asyncio
from datetime import datetime
from typing import Optional, Dict, List
from contextlib import asynccontextmanager

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from config import API_PORT, DAILY_UPLOAD_LIMIT, UPLOAD_START_HOUR, UPLOAD_END_HOUR
from utils.database import db
from utils.telegram_handler import send_telegram_message, send_daily_report


# Background task status tracking
task_status = {
    'scraper': {'running': False, 'last_run': None, 'result': None},
    'image_processor': {'running': False, 'last_run': None, 'result': None},
    'seo_rewriter': {'running': False, 'last_run': None, 'result': None},
    'validator': {'running': False, 'last_run': None, 'result': None},
    'uploader': {'running': False, 'last_run': None, 'result': None}
}


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    # Startup
    print("Vinted Relister API starting...")
    await send_telegram_message("🚀 <b>Vinted Relister API başlatıldı</b>\nPort: 8504")
    yield
    # Shutdown
    print("Vinted Relister API shutting down...")


app = FastAPI(
    title="Vinted Relister API",
    description="API for Vinted product automation pipeline",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Pydantic Models
class StoreCreate(BaseModel):
    store_name: str
    profile_url: str
    chrome_profile: str = "Default"
    is_source: bool = False
    daily_limit: int = 15
    upload_start_hour: int = 16
    upload_end_hour: int = 17


class ProductUpdate(BaseModel):
    processed_title: Optional[str] = None
    processed_description: Optional[str] = None
    price: Optional[float] = None
    telegram_approved: Optional[bool] = None
    status: Optional[int] = None


class FlowConfig(BaseModel):
    store_name: Optional[str] = None
    limit: Optional[int] = None
    style: Optional[str] = "balanced"
    only_approved: bool = True


# Health & Status Endpoints
@app.get("/")
async def root():
    """API health check"""
    return {
        "status": "online",
        "service": "Vinted Relister API",
        "version": "1.0.0",
        "port": API_PORT,
        "timestamp": datetime.now().isoformat()
    }


@app.get("/health")
async def health():
    """Detailed health check"""
    stats = db.get_statistics()
    return {
        "status": "healthy",
        "database": "connected",
        "products": stats.get('total_products', 0),
        "upload_window": f"{UPLOAD_START_HOUR}:00 - {UPLOAD_END_HOUR}:00",
        "daily_limit": DAILY_UPLOAD_LIMIT
    }


@app.get("/stats")
async def get_statistics():
    """Get pipeline statistics"""
    stats = db.get_statistics()
    return {
        "total_products": stats.get('total_products', 0),
        "raw": stats.get('raw', 0),
        "image_done": stats.get('image_done', 0),
        "seo_done": stats.get('seo_done', 0),
        "validated": stats.get('validated', 0),
        "uploaded": stats.get('uploaded', 0),
        "api_usage": {
            "groq": db.get_api_usage('groq'),
            "gemini": db.get_api_usage('gemini')
        },
        "task_status": task_status
    }


# Product Endpoints
@app.get("/products")
async def get_products(status: Optional[int] = None, limit: int = 100):
    """Get all products or filter by status"""
    if status is not None:
        products = db.get_products_by_status(status)
    else:
        products = db.get_all_products()
    return {"count": len(products[:limit]), "products": products[:limit]}


@app.get("/products/{product_id}")
async def get_product(product_id: int):
    """Get single product by ID"""
    product = db.get_product(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product


@app.patch("/products/{product_id}")
async def update_product(product_id: int, update: ProductUpdate):
    """Update product fields"""
    product = db.get_product(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    update_data = {k: v for k, v in update.dict().items() if v is not None}
    if update_data:
        db.update_product(product_id, update_data)

    return {"status": "updated", "product_id": product_id}


@app.post("/products/{product_id}/approve")
async def approve_product(product_id: int):
    """Approve product for upload"""
    product = db.get_product(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    db.update_product(product_id, {'telegram_approved': 1})
    db.add_log(product_id, 'approval', 'success', 'Product approved via API')

    return {"status": "approved", "product_id": product_id}


@app.post("/products/{product_id}/reject")
async def reject_product(product_id: int):
    """Reject product (skip from pipeline)"""
    product = db.get_product(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    db.update_product(product_id, {'telegram_approved': 0, 'status': -1})
    db.add_log(product_id, 'rejection', 'success', 'Product rejected via API')

    return {"status": "rejected", "product_id": product_id}


# Store Endpoints
@app.get("/stores")
async def get_stores():
    """Get all stores"""
    stores = db.get_stores()
    return {"count": len(stores), "stores": stores}


@app.post("/stores")
async def create_store(store: StoreCreate):
    """Create new store"""
    db.add_store(store.dict())
    return {"status": "created", "store_name": store.store_name}


@app.get("/stores/{store_name}")
async def get_store(store_name: str):
    """Get store by name"""
    stores = db.get_stores()
    store = next((s for s in stores if s.get('store_name') == store_name), None)
    if not store:
        raise HTTPException(status_code=404, detail="Store not found")
    return store


@app.post("/stores/{store_name}/test-login")
async def test_store_login(store_name: str, background_tasks: BackgroundTasks):
    """Test if store login is active"""
    stores = db.get_stores()
    store = next((s for s in stores if s.get('store_name') == store_name), None)
    if not store:
        raise HTTPException(status_code=404, detail="Store not found")

    # This would launch browser and check login status
    # For now, return placeholder
    return {
        "status": "test_initiated",
        "store_name": store_name,
        "message": "Login test started in background"
    }


# Flow Execution Endpoints
async def run_flow_background(flow_name: str, flow_func, **kwargs):
    """Run a flow in background and track status"""
    task_status[flow_name]['running'] = True
    task_status[flow_name]['last_run'] = datetime.now().isoformat()

    try:
        result = await flow_func(**kwargs)
        task_status[flow_name]['result'] = result
    except Exception as e:
        task_status[flow_name]['result'] = {'error': str(e)}
    finally:
        task_status[flow_name]['running'] = False


@app.post("/flows/scraper")
async def run_scraper(config: FlowConfig, background_tasks: BackgroundTasks):
    """Start scraper flow"""
    if task_status['scraper']['running']:
        raise HTTPException(status_code=409, detail="Scraper already running")

    from flows.flow1_scraper import run_scraper
    background_tasks.add_task(run_flow_background, 'scraper', run_scraper)

    return {"status": "started", "flow": "scraper"}


@app.post("/flows/image-processor")
async def run_image_processor(config: FlowConfig, background_tasks: BackgroundTasks):
    """Start image processing flow"""
    if task_status['image_processor']['running']:
        raise HTTPException(status_code=409, detail="Image processor already running")

    from flows.flow2_image import run_image_processor
    background_tasks.add_task(run_flow_background, 'image_processor', run_image_processor)

    return {"status": "started", "flow": "image_processor"}


@app.post("/flows/seo-rewriter")
async def run_seo_rewriter(config: FlowConfig, background_tasks: BackgroundTasks):
    """Start SEO rewriter flow"""
    if task_status['seo_rewriter']['running']:
        raise HTTPException(status_code=409, detail="SEO rewriter already running")

    from flows.flow3_seo import run_seo_rewriter
    background_tasks.add_task(
        run_flow_background,
        'seo_rewriter',
        run_seo_rewriter,
        style=config.style
    )

    return {"status": "started", "flow": "seo_rewriter", "style": config.style}


@app.post("/flows/validator")
async def run_validator(config: FlowConfig, background_tasks: BackgroundTasks):
    """Start validator flow"""
    if task_status['validator']['running']:
        raise HTTPException(status_code=409, detail="Validator already running")

    from flows.flow4_validator import run_validator
    background_tasks.add_task(run_flow_background, 'validator', run_validator)

    return {"status": "started", "flow": "validator"}


@app.post("/flows/uploader")
async def run_uploader(config: FlowConfig, background_tasks: BackgroundTasks):
    """Start uploader flow"""
    if task_status['uploader']['running']:
        raise HTTPException(status_code=409, detail="Uploader already running")

    # Check upload window
    now = datetime.now()
    if not (UPLOAD_START_HOUR <= now.hour < UPLOAD_END_HOUR):
        return {
            "status": "skipped",
            "reason": f"Outside upload window ({UPLOAD_START_HOUR}:00 - {UPLOAD_END_HOUR}:00)"
        }

    from flows.flow5_uploader import run_uploader
    background_tasks.add_task(
        run_flow_background,
        'uploader',
        run_uploader,
        only_approved=config.only_approved
    )

    return {"status": "started", "flow": "uploader"}


@app.post("/flows/run-all")
async def run_all_flows(config: FlowConfig, background_tasks: BackgroundTasks):
    """Run complete pipeline (scraper → image → seo → validator → uploader)"""
    running = [name for name, status in task_status.items() if status['running']]
    if running:
        raise HTTPException(
            status_code=409,
            detail=f"Flows already running: {', '.join(running)}"
        )

    async def run_pipeline():
        """Execute flows sequentially"""
        from flows.flow1_scraper import run_scraper
        from flows.flow2_image import run_image_processor
        from flows.flow3_seo import run_seo_rewriter
        from flows.flow4_validator import run_validator
        from flows.flow5_uploader import run_uploader

        results = {}

        # Flow 1: Scraper
        task_status['scraper']['running'] = True
        try:
            results['scraper'] = await run_scraper()
        finally:
            task_status['scraper']['running'] = False

        # Flow 2: Image Processor
        task_status['image_processor']['running'] = True
        try:
            results['image_processor'] = run_image_processor()
        finally:
            task_status['image_processor']['running'] = False

        # Flow 3: SEO Rewriter
        task_status['seo_rewriter']['running'] = True
        try:
            results['seo_rewriter'] = run_seo_rewriter(style=config.style)
        finally:
            task_status['seo_rewriter']['running'] = False

        # Flow 4: Validator
        task_status['validator']['running'] = True
        try:
            results['validator'] = run_validator()
        finally:
            task_status['validator']['running'] = False

        # Flow 5: Uploader (only during window)
        now = datetime.now()
        if UPLOAD_START_HOUR <= now.hour < UPLOAD_END_HOUR:
            task_status['uploader']['running'] = True
            try:
                results['uploader'] = await run_uploader(only_approved=config.only_approved)
            finally:
                task_status['uploader']['running'] = False
        else:
            results['uploader'] = {'skipped': 'Outside upload window'}

        # Send daily report
        stats = db.get_statistics()
        await send_daily_report(stats)

        return results

    background_tasks.add_task(run_pipeline)

    return {"status": "started", "flow": "full_pipeline"}


@app.get("/flows/status")
async def get_flow_status():
    """Get status of all flows"""
    return task_status


@app.post("/flows/stop/{flow_name}")
async def stop_flow(flow_name: str):
    """Stop a running flow (graceful)"""
    if flow_name not in task_status:
        raise HTTPException(status_code=404, detail="Flow not found")

    # Note: This is a graceful stop request, actual implementation
    # would need cancellation tokens in the flow functions
    task_status[flow_name]['running'] = False

    return {"status": "stop_requested", "flow": flow_name}


# Logs Endpoint
@app.get("/logs")
async def get_logs(limit: int = 100, action: Optional[str] = None):
    """Get activity logs"""
    logs = db.get_logs(limit=limit)
    if action:
        logs = [l for l in logs if l.get('action') == action]
    return {"count": len(logs), "logs": logs}


# Telegram Notification Endpoint
@app.post("/notify")
async def send_notification(message: str):
    """Send Telegram notification"""
    success = await send_telegram_message(message)
    return {"status": "sent" if success else "failed"}


# Main entry point
def main():
    import argparse
    import uvicorn

    parser = argparse.ArgumentParser(description='Vinted Relister API')
    parser.add_argument('--port', type=int, default=API_PORT, help='API port')
    parser.add_argument('--host', type=str, default='0.0.0.0', help='API host')
    parser.add_argument('--reload', action='store_true', help='Enable auto-reload')

    args = parser.parse_args()

    print(f"""
╔══════════════════════════════════════════════════════════╗
║           VINTED RELISTER API                            ║
║                                                          ║
║   Port: {args.port}                                          ║
║   Docs: http://localhost:{args.port}/docs                    ║
║   Health: http://localhost:{args.port}/health                ║
╚══════════════════════════════════════════════════════════╝
    """)

    uvicorn.run(
        "main:app",
        host=args.host,
        port=args.port,
        reload=args.reload
    )


if __name__ == '__main__':
    main()
