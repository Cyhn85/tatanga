# Database utilities for Vinted Relister
import sqlite3
import json
from datetime import datetime
from typing import List, Dict, Optional, Any
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DATABASE_PATH, STATUS_RAW

class VintedDatabase:
    def __init__(self, db_path: str = DATABASE_PATH):
        self.db_path = db_path
        self.init_database()

    def get_connection(self):
        return sqlite3.connect(self.db_path)

    def init_database(self):
        """Initialize database with required tables"""
        conn = self.get_connection()
        cursor = conn.cursor()

        # Products table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vinted_id TEXT UNIQUE,
                vinted_url TEXT,
                source_store TEXT DEFAULT 'cyhn85',
                target_store TEXT DEFAULT 'cyhn85',
                raw_title TEXT,
                raw_description TEXT,
                processed_title TEXT,
                processed_description TEXT,
                brand TEXT,
                model TEXT,
                size TEXT,
                color TEXT,
                price REAL,
                category TEXT,
                condition TEXT,
                shipping_size TEXT,
                extra_fields TEXT,
                raw_images_path TEXT,
                processed_images_path TEXT,
                final_images_path TEXT,
                image_count INTEGER DEFAULT 0,
                status INTEGER DEFAULT 0,
                telegram_approved INTEGER DEFAULT 0,
                validation_notes TEXT,
                variation_level TEXT DEFAULT 'balanced',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                scheduled_upload TIMESTAMP,
                uploaded_at TIMESTAMP,
                new_vinted_id TEXT
            )
        ''')

        # Stores table with login credentials and proxy settings
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS stores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                store_name TEXT UNIQUE,
                profile_url TEXT,
                chrome_profile TEXT DEFAULT 'Default',
                is_source INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                daily_limit INTEGER DEFAULT 15,
                upload_start_hour INTEGER DEFAULT 16,
                upload_end_hour INTEGER DEFAULT 17,
                login_email TEXT,
                login_password TEXT,
                login_type TEXT DEFAULT 'email',
                login_status TEXT DEFAULT 'unknown',
                last_login_check TIMESTAMP,
                proxy_enabled INTEGER DEFAULT 0,
                proxy_host TEXT,
                proxy_port INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Migration: Add credential columns if they don't exist
        try:
            cursor.execute('ALTER TABLE stores ADD COLUMN login_email TEXT')
        except:
            pass
        try:
            cursor.execute('ALTER TABLE stores ADD COLUMN login_password TEXT')
        except:
            pass
        try:
            cursor.execute('ALTER TABLE stores ADD COLUMN login_type TEXT DEFAULT "email"')
        except:
            pass
        try:
            cursor.execute('ALTER TABLE stores ADD COLUMN login_status TEXT DEFAULT "unknown"')
        except:
            pass
        try:
            cursor.execute('ALTER TABLE stores ADD COLUMN last_login_check TIMESTAMP')
        except:
            pass
        # Migration: Add proxy columns if they don't exist
        try:
            cursor.execute('ALTER TABLE stores ADD COLUMN proxy_enabled INTEGER DEFAULT 0')
        except:
            pass
        try:
            cursor.execute('ALTER TABLE stores ADD COLUMN proxy_host TEXT')
        except:
            pass
        try:
            cursor.execute('ALTER TABLE stores ADD COLUMN proxy_port INTEGER')
        except:
            pass

        # Logs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER,
                action TEXT,
                status TEXT,
                message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(id)
            )
        ''')

        # API usage tracking
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS api_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                api_name TEXT,
                requests_today INTEGER DEFAULT 0,
                last_request TIMESTAMP,
                date TEXT
            )
        ''')

        # Note: Default store removed - stores are added manually via Dashboard

        conn.commit()
        conn.close()

    # Product operations
    def add_product(self, product_data: Dict) -> int:
        """Add a new product to database"""
        conn = self.get_connection()
        cursor = conn.cursor()

        extra_fields = json.dumps(product_data.get('extra_fields', {}))

        cursor.execute('''
            INSERT OR REPLACE INTO products (
                vinted_id, vinted_url, source_store, raw_title, raw_description,
                brand, model, size, color, price, category, condition,
                shipping_size, extra_fields, raw_images_path, image_count, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            product_data.get('vinted_id'),
            product_data.get('vinted_url'),
            product_data.get('source_store', 'cyhn85'),
            product_data.get('raw_title'),
            product_data.get('raw_description'),
            product_data.get('brand'),
            product_data.get('model'),
            product_data.get('size'),
            product_data.get('color'),
            product_data.get('price'),
            product_data.get('category'),
            product_data.get('condition'),
            product_data.get('shipping_size'),
            extra_fields,
            product_data.get('raw_images_path'),
            product_data.get('image_count', 0),
            STATUS_RAW
        ))

        product_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return product_id

    def get_products_by_status(self, status: int) -> List[Dict]:
        """Get all products with a specific status"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute('SELECT * FROM products WHERE status = ? ORDER BY id', (status,))
        rows = cursor.fetchall()
        conn.close()

        return [dict(row) for row in rows]

    def get_product(self, product_id: int) -> Optional[Dict]:
        """Get a single product by ID"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute('SELECT * FROM products WHERE id = ?', (product_id,))
        row = cursor.fetchone()
        conn.close()

        return dict(row) if row else None

    def update_product(self, product_id: int, updates: Dict):
        """Update product fields"""
        conn = self.get_connection()
        cursor = conn.cursor()

        set_clause = ', '.join([f'{k} = ?' for k in updates.keys()])
        values = list(updates.values()) + [product_id]

        cursor.execute(f'UPDATE products SET {set_clause} WHERE id = ?', values)
        conn.commit()
        conn.close()

    def update_product_status(self, product_id: int, status: int):
        """Update product status"""
        self.update_product(product_id, {'status': status})

    def get_pending_uploads(self) -> List[Dict]:
        """Get products ready for upload (validated and approved)"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute('''
            SELECT * FROM products
            WHERE status = 3 AND telegram_approved = 1
            AND (scheduled_upload IS NULL OR scheduled_upload <= datetime('now'))
            ORDER BY id
        ''')
        rows = cursor.fetchall()
        conn.close()

        return [dict(row) for row in rows]

    def get_all_products(self) -> List[Dict]:
        """Get all products"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute('SELECT * FROM products ORDER BY id')
        rows = cursor.fetchall()
        conn.close()

        return [dict(row) for row in rows]

    def get_statistics(self) -> Dict:
        """Get database statistics"""
        conn = self.get_connection()
        cursor = conn.cursor()

        stats = {}

        cursor.execute('SELECT COUNT(*) FROM products')
        stats['total_products'] = cursor.fetchone()[0]

        cursor.execute('SELECT COUNT(*) FROM products WHERE status = 0')
        stats['raw'] = cursor.fetchone()[0]

        cursor.execute('SELECT COUNT(*) FROM products WHERE status = 1')
        stats['image_done'] = cursor.fetchone()[0]

        cursor.execute('SELECT COUNT(*) FROM products WHERE status = 2')
        stats['seo_done'] = cursor.fetchone()[0]

        cursor.execute('SELECT COUNT(*) FROM products WHERE status = 3')
        stats['validated'] = cursor.fetchone()[0]

        cursor.execute('SELECT COUNT(*) FROM products WHERE status = 4')
        stats['pending_approval'] = cursor.fetchone()[0]

        cursor.execute('SELECT COUNT(*) FROM products WHERE status = 5')
        stats['uploaded'] = cursor.fetchone()[0]

        cursor.execute('SELECT COUNT(*) FROM products WHERE telegram_approved = 1')
        stats['telegram_approved'] = cursor.fetchone()[0]

        conn.close()
        return stats

    # Store operations
    def add_store(self, store_data: Dict) -> int:
        """Add or update a store with credentials and proxy settings"""
        conn = self.get_connection()
        cursor = conn.cursor()

        # Use INSERT OR REPLACE to update if store_name exists
        cursor.execute('''
            INSERT OR REPLACE INTO stores (
                store_name, profile_url, chrome_profile, is_source,
                daily_limit, upload_start_hour, upload_end_hour,
                login_email, login_password, login_type, login_status,
                proxy_enabled, proxy_host, proxy_port
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            store_data.get('store_name'),
            store_data.get('profile_url'),
            store_data.get('chrome_profile', 'Default'),
            store_data.get('is_source', 0),
            store_data.get('daily_limit', 15),
            store_data.get('upload_start_hour', 16),
            store_data.get('upload_end_hour', 17),
            store_data.get('login_email', ''),
            store_data.get('login_password', ''),
            store_data.get('login_type', 'email'),
            store_data.get('login_status', 'unknown'),
            store_data.get('proxy_enabled', 0),
            store_data.get('proxy_host', ''),
            store_data.get('proxy_port', 0)
        ))

        store_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return store_id

    def update_store(self, store_id: int, updates: Dict):
        """Update store fields"""
        conn = self.get_connection()
        cursor = conn.cursor()

        set_clause = ', '.join([f'{k} = ?' for k in updates.keys()])
        values = list(updates.values()) + [store_id]

        cursor.execute(f'UPDATE stores SET {set_clause} WHERE id = ?', values)
        conn.commit()
        conn.close()

    def update_store_login_status(self, store_id: int, status: str):
        """Update store login status"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            UPDATE stores SET login_status = ?, last_login_check = datetime('now')
            WHERE id = ?
        ''', (status, store_id))

        conn.commit()
        conn.close()

    def get_store(self, store_id: int) -> Optional[Dict]:
        """Get a single store by ID"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute('SELECT * FROM stores WHERE id = ?', (store_id,))
        row = cursor.fetchone()
        conn.close()

        return dict(row) if row else None

    def get_store_by_name(self, store_name: str) -> Optional[Dict]:
        """Get a store by name"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute('SELECT * FROM stores WHERE store_name = ?', (store_name,))
        row = cursor.fetchone()
        conn.close()

        return dict(row) if row else None

    def delete_store(self, store_id: int):
        """Delete a store"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM stores WHERE id = ?', (store_id,))
        conn.commit()
        conn.close()

    def get_stores(self) -> List[Dict]:
        """Get all stores"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute('SELECT * FROM stores WHERE is_active = 1 ORDER BY id')
        rows = cursor.fetchall()
        conn.close()

        return [dict(row) for row in rows]

    # Log operations
    def add_log(self, product_id: int, action: str, status: str, message: str):
        """Add a log entry"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO logs (product_id, action, status, message)
            VALUES (?, ?, ?, ?)
        ''', (product_id, action, status, message))

        conn.commit()
        conn.close()

    def get_logs(self, limit: int = 100) -> List[Dict]:
        """Get recent logs"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute('''
            SELECT l.*, p.raw_title as product_title
            FROM logs l
            LEFT JOIN products p ON l.product_id = p.id
            ORDER BY l.created_at DESC
            LIMIT ?
        ''', (limit,))
        rows = cursor.fetchall()
        conn.close()

        return [dict(row) for row in rows]

    # API usage tracking
    def track_api_usage(self, api_name: str):
        """Track API usage for rate limiting"""
        conn = self.get_connection()
        cursor = conn.cursor()

        today = datetime.now().strftime('%Y-%m-%d')

        cursor.execute('''
            INSERT INTO api_usage (api_name, requests_today, last_request, date)
            VALUES (?, 1, datetime('now'), ?)
            ON CONFLICT(api_name, date) DO UPDATE SET
            requests_today = requests_today + 1,
            last_request = datetime('now')
        ''', (api_name, today))

        conn.commit()
        conn.close()

    def get_api_usage(self, api_name: str) -> int:
        """Get today's API usage"""
        conn = self.get_connection()
        cursor = conn.cursor()

        today = datetime.now().strftime('%Y-%m-%d')

        cursor.execute('''
            SELECT requests_today FROM api_usage
            WHERE api_name = ? AND date = ?
        ''', (api_name, today))

        row = cursor.fetchone()
        conn.close()

        return row[0] if row else 0


# Create global database instance
db = VintedDatabase()
