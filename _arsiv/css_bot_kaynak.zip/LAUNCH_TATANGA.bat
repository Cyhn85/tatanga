@echo off
title TATANGA Simple Launcher
cls
echo.
echo ====================================
echo    TATANGA SIMPLE LAUNCHER
echo ====================================
echo.
echo Starting TATANGA Control Center...
echo.

python TATANGA_SIMPLE.py

if errorlevel 1 (
    echo.
    echo ERROR: Failed to start TATANGA
    echo.
    pause
)
