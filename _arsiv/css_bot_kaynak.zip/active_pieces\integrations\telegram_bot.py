#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Telegram Bot
Interactive bot for monitoring and control

Features:
- Start/Stop commands
- Real-time notifications:
  * Transfer progress
  * Publishing status
  * Seller messages (with translation)
  * Product sold alerts
- Interactive buttons:
  * [DÜZELT] - Edit product
  * [OTOMATIK DEVAM] - Continue automatically
  * [BEKLET] - Put on hold
  * [SİTEYE GİT] - Open product URL
- Statistics and status commands
- Admin controls

Commands:
  /start - Start bot
  /status - System status
  /stats - Statistics
  /transfer - Transfer status
  /stores - Store list
  /help - Help

Example Notifications:
  📬 Mesaj Alındı!
  Satıcı: @seller123
  Ürün: Nike Air Max...

  🇩🇪 Orijinal:
  "Ist noch verfügbar"

  🇹🇷 Türkçe:
  "Hala mevcut mu"

  [DÜZELT] [OTOMATIK DEVAM] [BEKLET] [SİTEYE GİT]
"""

import sys, io
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters
import sqlite3
from pathlib import Path
import asyncio

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.logger import ModuleLogger
from config.credentials import TELEGRAM, DATABASE


class TatangaTelegramBot:
    """
    TATANGA Telegram Bot

    Usage:
        bot = TatangaTelegramBot()
        bot.run()  # Start bot (blocking)

        # Or use async
        await bot.send_notification(
            message="Transfer completed!",
            buttons=[
                [{'text': 'View', 'callback': 'view_transfer'}]
            ]
        )
    """

    def __init__(self):
        self.module_name = 'telegram_bot'
        self.logger = ModuleLogger(self.module_name)

        # Telegram config
        self.bot_token = TELEGRAM.get('bot_token')
        self.chat_id = TELEGRAM.get('chat_id')

        if not self.bot_token:
            self.logger.error("Telegram bot token bulunamadı!")
            raise ValueError("Telegram bot token required")

        # Application
        self.app = Application.builder().token(self.bot_token).build()

        # Database
        self.db_path = Path(DATABASE['db_path'])

        # Register handlers
        self.register_handlers()

    def register_handlers(self):
        """Register command and callback handlers"""
        # Commands
        self.app.add_handler(CommandHandler("start", self.cmd_start))
        self.app.add_handler(CommandHandler("status", self.cmd_status))
        self.app.add_handler(CommandHandler("stats", self.cmd_stats))
        self.app.add_handler(CommandHandler("transfer", self.cmd_transfer))
        self.app.add_handler(CommandHandler("stores", self.cmd_stores))
        self.app.add_handler(CommandHandler("help", self.cmd_help))

        # Callback queries (button clicks)
        self.app.add_handler(CallbackQueryHandler(self.handle_callback))

        self.logger.info("Telegram bot handlers kayıtlı")

    async def cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        await update.message.reply_text(
            "🤖 *TATANGA BOT*\n\n"
            "Hoş geldiniz! TATANGA dropshipping otomasyonu aktif.\n\n"
            "Komutlar:\n"
            "/status - Sistem durumu\n"
            "/stats - İstatistikler\n"
            "/transfer - Transfer durumu\n"
            "/stores - Mağaza listesi\n"
            "/help - Yardım",
            parse_mode='Markdown'
        )

        self.logger.info("/start komutu çalıştırıldı")

    async def cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /status command"""
        # Get system status
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("SELECT COUNT(*) FROM products")
        total_products = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM products WHERE is_favorite = 1")
        favorites = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM store_accounts WHERE is_active = 1")
        active_stores = cursor.fetchone()[0]

        conn.close()

        status_message = f"""
📊 *TATANGA DURUM*

🛒 Toplam Ürün: {total_products}
⭐ Favoriler: {favorites}
🏪 Aktif Mağazalar: {active_stores}

✅ Sistem çalışıyor
"""

        await update.message.reply_text(status_message, parse_mode='Markdown')
        self.logger.info("/status komutu çalıştırıldı")

    async def cmd_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /stats command"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Platform breakdown
        cursor.execute("""
            SELECT platform, COUNT(*) as count
            FROM products
            GROUP BY platform
            ORDER BY count DESC
        """)

        platforms = cursor.fetchall()

        # Transfer history
        cursor.execute("""
            SELECT COUNT(*) FROM transfer_history
            WHERE transferred_at >= datetime('now', '-7 days')
        """)
        transfers_7d = cursor.fetchone()[0]

        conn.close()

        stats_message = "📈 *İSTATİSTİKLER*\n\n"
        stats_message += "*Platformlar:*\n"

        for platform, count in platforms:
            stats_message += f"  • {platform}: {count} ürün\n"

        stats_message += f"\n*Son 7 Gün:*\n"
        stats_message += f"  • {transfers_7d} transfer\n"

        await update.message.reply_text(stats_message, parse_mode='Markdown')
        self.logger.info("/stats komutu çalıştırıldı")

    async def cmd_transfer(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /transfer command"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Recent transfers
        cursor.execute("""
            SELECT source_platform, target_platform, COUNT(*) as count
            FROM transfer_history
            WHERE transferred_at >= datetime('now', '-1 day')
            GROUP BY source_platform, target_platform
            ORDER BY count DESC
            LIMIT 10
        """)

        transfers = cursor.fetchall()
        conn.close()

        if not transfers:
            await update.message.reply_text("📊 Son 24 saatte transfer yok.")
            return

        transfer_message = "🔄 *SON TRANSFERLER (24 saat)*\n\n"

        for source, target, count in transfers:
            transfer_message += f"  • {source} → {target}: {count} ürün\n"

        await update.message.reply_text(transfer_message, parse_mode='Markdown')
        self.logger.info("/transfer komutu çalıştırıldı")

    async def cmd_stores(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /stores command"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT platform, store_name, is_active
            FROM store_accounts
            ORDER BY platform, store_name
        """)

        stores = cursor.fetchall()
        conn.close()

        if not stores:
            await update.message.reply_text("🏪 Henüz mağaza eklenmemiş.")
            return

        stores_message = "🏪 *MAĞAZALAR*\n\n"

        current_platform = None
        for platform, store_name, is_active in stores:
            if platform != current_platform:
                stores_message += f"\n*{platform.upper()}:*\n"
                current_platform = platform

            status_icon = "✅" if is_active else "❌"
            stores_message += f"  {status_icon} {store_name}\n"

        await update.message.reply_text(stores_message, parse_mode='Markdown')
        self.logger.info("/stores komutu çalıştırıldı")

    async def cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        help_message = """
🤖 *TATANGA BOT YARDIM*

*Komutlar:*
/start - Bot'u başlat
/status - Sistem durumu
/stats - İstatistikler
/transfer - Transfer geçmişi
/stores - Mağaza listesi
/help - Bu yardım mesajı

*Bildirimler:*
Bot aşağıdaki durumlarda otomatik bildirim gönderir:
  • Transfer tamamlandı
  • Ürün yayınlandı
  • Satıcı mesajı alındı
  • Ürün satıldı

*İnteraktif Butonlar:*
  [DÜZELT] - Ürünü düzenle
  [OTOMATIK DEVAM] - Devam et
  [BEKLET] - Beklet
  [SİTEYE GİT] - Ürüne git

Sorularınız için: @tatanga_support
"""

        await update.message.reply_text(help_message, parse_mode='Markdown')
        self.logger.info("/help komutu çalıştırıldı")

    async def handle_callback(self, query, context: ContextTypes.DEFAULT_TYPE):
        """Handle callback queries (button clicks)"""
        callback_data = query.data

        self.logger.info("Callback alındı", data=callback_data)

        if callback_data.startswith('edit_'):
            product_id = callback_data.split('_')[1]
            await query.answer("✏️ Düzenleme özelliği yakında...")

        elif callback_data.startswith('auto_continue_'):
            product_id = callback_data.split('_')[2]
            await query.answer("✅ Otomatik devam ediliyor...")

        elif callback_data.startswith('hold_'):
            product_id = callback_data.split('_')[1]
            await query.answer("⏸️ Ürün bekletildi")

        elif callback_data.startswith('goto_'):
            url = callback_data.split('_', 1)[1]
            await query.answer("🔗 Tarayıcıda açılıyor...")

        elif callback_data.startswith('view_transfer'):
            await query.answer("👁️ Transfer detayları görüntüleniyor...")

        else:
            await query.answer("Bilinmeyen komut")

    async def send_notification(self, message, buttons=None, parse_mode='Markdown'):
        """
        Send notification to user

        Args:
            message: Notification text
            buttons: List of button rows, each row is list of dicts with 'text' and 'callback'
                     Example: [[{'text': 'Button 1', 'callback': 'btn1'}], [{'text': 'Button 2', 'callback': 'btn2'}]]
            parse_mode: 'Markdown' or 'HTML'
        """
        if not self.chat_id:
            self.logger.warning("Chat ID yok, bildirim gönderilemedi")
            return

        try:
            # Build keyboard
            keyboard = None
            if buttons:
                keyboard_buttons = []
                for row in buttons:
                    button_row = [
                        InlineKeyboardButton(btn['text'], callback_data=btn['callback'])
                        for btn in row
                    ]
                    keyboard_buttons.append(button_row)

                keyboard = InlineKeyboardMarkup(keyboard_buttons)

            # Send message
            await self.app.bot.send_message(
                chat_id=self.chat_id,
                text=message,
                parse_mode=parse_mode,
                reply_markup=keyboard
            )

            self.logger.info("Telegram bildirimi gönderildi")

        except Exception as e:
            self.logger.error("Telegram bildirim hatası", exception=e)

    async def send_transfer_notification(self, total, successful, failed, duration):
        """Send transfer completion notification"""
        message = f"""
🎉 *TRANSFER TAMAMLANDI!*

📊 *Özet:*
  • Toplam: {total} ilan
  • Başarılı: {successful} ✅
  • Başarısız: {failed} ❌
  • Süre: {duration}

🚀 TATANGA Cross-Platform Transfer
"""

        buttons = [
            [
                {'text': '👁️ DETAYLARI GÖR', 'callback': 'view_transfer'},
                {'text': '📊 İSTATİSTİKLER', 'callback': 'stats'}
            ]
        ]

        await self.send_notification(message, buttons)

    async def send_seller_message_notification(self, seller, product_title, original_message, translated_message, product_url):
        """Send seller message notification"""
        message = f"""
📬 *MESAJ ALINDI!*

👤 Satıcı: {seller}
📦 Ürün: {product_title[:40]}...

🇩🇪 *Orijinal:*
"{original_message}"

🇹🇷 *Türkçe:*
"{translated_message}"
"""

        buttons = [
            [
                {'text': '✏️ DÜZELT', 'callback': f'edit_{product_url}'},
                {'text': '✅ OTOMATIK DEVAM', 'callback': f'auto_continue_{product_url}'}
            ],
            [
                {'text': '⏸️ BEKLET', 'callback': f'hold_{product_url}'},
                {'text': '🔗 SİTEYE GİT', 'callback': f'goto_{product_url}'}
            ]
        ]

        await self.send_notification(message, buttons)

    async def send_product_sold_notification(self, product_title, platform, price):
        """Send product sold notification"""
        message = f"""
💰 *ÜRÜN SATILDI!*

📦 Ürün: {product_title[:40]}...
🛒 Platform: {platform}
💵 Fiyat: €{price:.2f}

✅ Ürün tüm platformlardan otomatik kaldırıldı.
"""

        buttons = [
            [
                {'text': '📊 SATIŞ İSTATİSTİKLERİ', 'callback': 'sales_stats'}
            ]
        ]

        await self.send_notification(message, buttons)

    def run(self):
        """Start bot (blocking)"""
        self.logger.info("Telegram bot başlatılıyor...")
        self.app.run_polling()

    def run_async(self):
        """Start bot (async)"""
        self.logger.info("Telegram bot async başlatılıyor...")
        return self.app.run_polling()


if __name__ == "__main__":
    print("\n" + "="*80)
    print("🤖 TATANGA TELEGRAM BOT")
    print("="*80)
    print("\nKullanım:")
    print("  bot = TatangaTelegramBot()")
    print("  bot.run()  # Bot'u başlat")
    print("\nAsync kullanım:")
    print("  await bot.send_notification('Mesaj')")
    print("  await bot.send_transfer_notification(60, 58, 2, '15m 30s')")
    print("\nKomutlar:")
    print("  /start - Bot'u başlat")
    print("  /status - Sistem durumu")
    print("  /stats - İstatistikler")
    print("  /transfer - Transfer geçmişi")
    print("  /stores - Mağaza listesi")
    print("  /help - Yardım")
    print("="*80 + "\n")

    # Check config
    if not TELEGRAM.get('bot_token'):
        print("⚠️  Telegram bot token bulunamadı!")
        print("   config/credentials.py dosyasına bot token ekleyin")
        print("   Bot oluşturmak için: @BotFather")
    else:
        print("✅ Telegram bot token mevcut")
        print("🚀 Bot başlatılıyor...")

        try:
            bot = TatangaTelegramBot()
            bot.run()
        except KeyboardInterrupt:
            print("\n\n👋 Bot durduruldu")
        except Exception as e:
            print(f"\n\n❌ Hata: {e}")
