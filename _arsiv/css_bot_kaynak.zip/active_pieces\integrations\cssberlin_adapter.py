#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CSSBERLIN.DE ADAPTER
Automatically publish products to static cssberlin.de website
via HTML generation + Git push
"""

import os
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, List
import subprocess

# Try Jinja2 for templating
try:
    from jinja2 import Template, Environment, FileSystemLoader
    JINJA2_AVAILABLE = True
except ImportError:
    JINJA2_AVAILABLE = False
    print("Warning: jinja2 not available. Install with: pip install jinja2")

# Try GitPython for Git automation
try:
    from git import Repo
    GITPYTHON_AVAILABLE = True
except ImportError:
    GITPYTHON_AVAILABLE = False
    print("Warning: GitPython not available. Install with: pip install gitpython")


class CSSBerlinAdapter:
    """
    Adapter for publishing products to cssberlin.de static site
    """

    def __init__(self, config: Dict = None):
        """
        Initialize adapter

        Args:
            config: Configuration dictionary with:
                - github_repo_path: Local path to GitHub repo
                - github_branch: Branch name (default: main)
                - products_folder: Folder for product HTML files
                - template_file: Path to Jinja2 template
                - base_url: Live site URL
        """
        # Default config
        self.config = config or {}
        self.repo_path = Path(self.config.get('github_repo_path', 'C:/Users/cyhnsrgc/Desktop/CSS-Berlin-Website'))
        self.branch = self.config.get('github_branch', 'main')
        self.products_folder = self.config.get('products_folder', 'products')
        self.template_file = self.config.get('template_file', 'templates/cssberlin_product_modern.html')
        self.base_url = self.config.get('base_url', 'https://cssberlin.de')

        # Validate paths
        if not self.repo_path.exists():
            print(f"Warning: GitHub repo path does not exist: {self.repo_path}")

        # Git repo
        self.repo = None
        if GITPYTHON_AVAILABLE and self.repo_path.exists():
            try:
                self.repo = Repo(self.repo_path)
            except Exception as e:
                print(f"Warning: Could not initialize Git repo: {e}")

    def create_product_page(self, product_data: Dict) -> Dict:
        """
        Create a new product HTML page and commit to Git

        Args:
            product_data: Dictionary with product information:
                - title: Product title
                - description: Product description
                - price: Price in EUR
                - images: List of image URLs/paths
                - category: Product category (optional)
                - brand: Brand name (optional)
                - delivery_time: Delivery time in days (optional)
                - original_url: Source URL (optional)

        Returns:
            Dictionary with:
                - success: True/False
                - html_file: Generated HTML filename
                - live_url: Live URL on cssberlin.de
                - message: Success/error message
        """

        try:
            # Generate unique filename from title
            filename = self._generate_filename(product_data.get('title', 'product'))

            # Create products folder if not exists
            products_path = self.repo_path / self.products_folder
            products_path.mkdir(parents=True, exist_ok=True)

            # Generate HTML content
            html_content = self._generate_html(product_data)

            # Save HTML file
            html_file_path = products_path / f"{filename}.html"
            with open(html_file_path, 'w', encoding='utf-8') as f:
                f.write(html_content)

            print(f"✅ Created HTML: {html_file_path}")

            # Save images if provided as file objects
            if 'image_files' in product_data:
                self._save_images(product_data['image_files'], filename)

            # Git commit and push
            if self.repo:
                commit_result = self._git_commit_and_push(
                    files=[str(html_file_path.relative_to(self.repo_path))],
                    message=f"TATANGA: New product - {product_data.get('title', 'Untitled')}"
                )

                if commit_result['success']:
                    print(f"✅ Pushed to GitHub: {commit_result['message']}")
                else:
                    print(f"⚠️ Git push failed: {commit_result['message']}")
            else:
                print("⚠️ Git repo not available - manual push required")

            # Generate live URL
            live_url = f"{self.base_url}/{self.products_folder}/{filename}.html"

            return {
                'success': True,
                'html_file': filename,
                'live_url': live_url,
                'local_path': str(html_file_path),
                'message': 'Product page created successfully'
            }

        except Exception as e:
            return {
                'success': False,
                'html_file': None,
                'live_url': None,
                'message': f'Error creating product page: {str(e)}'
            }

    def _generate_filename(self, title: str) -> str:
        """Generate SEO-friendly filename from title"""

        # Convert to lowercase
        filename = title.lower()

        # Remove special characters
        filename = re.sub(r'[^a-z0-9\s-]', '', filename)

        # Replace spaces with hyphens
        filename = re.sub(r'\s+', '-', filename)

        # Remove consecutive hyphens
        filename = re.sub(r'-+', '-', filename)

        # Limit length
        filename = filename[:50]

        # Add unique suffix (timestamp)
        timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')

        return f"{filename}-{timestamp}"

    def _generate_html(self, product_data: Dict) -> str:
        """Generate HTML content using template"""

        if JINJA2_AVAILABLE:
            return self._generate_html_jinja2(product_data)
        else:
            return self._generate_html_manual(product_data)

    def _generate_html_jinja2(self, product_data: Dict) -> str:
        """Generate HTML using Jinja2 template"""

        template_path = self.repo_path / self.template_file

        if template_path.exists():
            # Load template from file
            env = Environment(loader=FileSystemLoader(template_path.parent))
            template = env.get_template(template_path.name)
        else:
            # Use default template
            template = Template(self._get_default_template())

        # Render template
        return template.render(**product_data)

    def _generate_html_manual(self, product_data: Dict) -> str:
        """Generate HTML manually (fallback)"""

        title = product_data.get('title', 'Untitled Product')
        description = product_data.get('description', '')
        price = product_data.get('price', '0.00')
        images = product_data.get('images', [])
        delivery_time = product_data.get('delivery_time', '7-10')

        # Simple HTML template
        html = f"""<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - CSS Berlin</title>
    <meta name="description" content="{description[:160]}">
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .product-title {{ font-size: 2em; margin-bottom: 20px; }}
        .product-gallery {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; margin: 20px 0; }}
        .product-gallery img {{ width: 100%; height: auto; border-radius: 8px; }}
        .product-price {{ font-size: 1.5em; color: #2d5016; font-weight: bold; margin: 20px 0; }}
        .product-delivery {{ color: #666; margin: 10px 0; }}
        .product-description {{ line-height: 1.6; white-space: pre-wrap; }}
        .buy-button {{ background: #2d5016; color: white; padding: 15px 30px; border: none; border-radius: 5px; font-size: 1.1em; cursor: pointer; }}
        .buy-button:hover {{ background: #1a3009; }}
    </style>
</head>
<body>
    <h1 class="product-title">{title}</h1>

    <div class="product-gallery">
"""

        # Add images
        for image_url in images:
            html += f'        <img src="{image_url}" alt="{title}">\n'

        html += f"""    </div>

    <div class="product-price">{price} €</div>
    <div class="product-delivery">Lieferzeit: {delivery_time} Werktage</div>

    <div class="product-description">
        {description}
    </div>

    <br><br>
    <button class="buy-button" onclick="alert('Kontaktieren Sie uns für den Kauf!')">Jetzt kaufen</button>

    <br><br>
    <a href="/index.html">← Zurück zur Startseite</a>
</body>
</html>
"""

        return html

    def _get_default_template(self) -> str:
        """Get default Jinja2 template"""

        return """<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }} - CSS Berlin</title>
    <meta name="description" content="{{ description[:160] }}">
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
        .product-title { font-size: 2em; margin-bottom: 20px; }
        .product-gallery { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; margin: 20px 0; }
        .product-gallery img { width: 100%; height: auto; border-radius: 8px; }
        .product-price { font-size: 1.5em; color: #2d5016; font-weight: bold; margin: 20px 0; }
        .product-delivery { color: #666; margin: 10px 0; }
        .product-description { line-height: 1.6; white-space: pre-wrap; }
        .buy-button { background: #2d5016; color: white; padding: 15px 30px; border: none; border-radius: 5px; font-size: 1.1em; cursor: pointer; }
        .buy-button:hover { background: #1a3009; }
    </style>
</head>
<body>
    <h1 class="product-title">{{ title }}</h1>

    <div class="product-gallery">
        {% for image in images %}
        <img src="{{ image }}" alt="{{ title }}">
        {% endfor %}
    </div>

    <div class="product-price">{{ price }} €</div>
    <div class="product-delivery">Lieferzeit: {{ delivery_time|default('7-10') }} Werktage</div>

    <div class="product-description">
        {{ description }}
    </div>

    <br><br>
    <button class="buy-button" onclick="alert('Kontaktieren Sie uns für den Kauf!')">Jetzt kaufen</button>

    <br><br>
    <a href="/index.html">← Zurück zur Startseite</a>
</body>
</html>
"""

    def _save_images(self, image_files: List, product_id: str):
        """Save product images to images folder"""

        images_path = self.repo_path / 'images' / 'products' / product_id
        images_path.mkdir(parents=True, exist_ok=True)

        for i, image_file in enumerate(image_files):
            image_path = images_path / f"image_{i+1}.jpg"
            # Save image file
            # This would need actual image file object
            pass

    def _git_commit_and_push(self, files: List[str], message: str) -> Dict:
        """
        Commit and push files to GitHub

        Args:
            files: List of file paths relative to repo root
            message: Commit message

        Returns:
            Dictionary with success status and message
        """

        try:
            if not self.repo:
                return {
                    'success': False,
                    'message': 'Git repo not initialized'
                }

            # Add files
            self.repo.index.add(files)

            # Commit
            commit = self.repo.index.commit(message)

            # Push
            origin = self.repo.remote(name='origin')
            origin.push(self.branch)

            return {
                'success': True,
                'message': f'Committed and pushed: {commit.hexsha[:7]}',
                'commit_sha': commit.hexsha
            }

        except Exception as e:
            # Fallback to subprocess if GitPython fails
            try:
                subprocess.run(['git', 'add', '.'], cwd=self.repo_path, check=True)
                subprocess.run(['git', 'commit', '-m', message], cwd=self.repo_path, check=True)
                subprocess.run(['git', 'push', 'origin', self.branch], cwd=self.repo_path, check=True)

                return {
                    'success': True,
                    'message': 'Committed and pushed via subprocess'
                }

            except subprocess.CalledProcessError as sub_e:
                return {
                    'success': False,
                    'message': f'Git error: {str(e)} | Subprocess error: {str(sub_e)}'
                }


# Test function
if __name__ == "__main__":
    print("="*60)
    print("CSSBERLIN.DE ADAPTER TEST")
    print("="*60)
    print()

    # Test configuration
    config = {
        'github_repo_path': 'C:/Users/cyhnsrgc/Desktop/CSS-Berlin-Website',
        'github_branch': 'main',
        'products_folder': 'products',
        'base_url': 'https://cssberlin.de'
    }

    adapter = CSSBerlinAdapter(config)

    # Test product data
    test_product = {
        'title': 'Nike Air Max 90 Sneaker Weiß Gr. 42',
        'description': '''Premium Nike Air Max 90 Sneaker in Weiß.

Zustand: Neuwertig
Größe: 42
Farbe: Weiß
Marke: Nike

Perfekt für den Alltag und Sport!''',
        'price': '89.99',
        'images': [
            '/images/products/nike-air-max-1.jpg',
            '/images/products/nike-air-max-2.jpg',
        ],
        'delivery_time': '7-10',
        'category': 'Schuhe',
        'brand': 'Nike'
    }

    print("Creating product page...")
    result = adapter.create_product_page(test_product)

    print()
    print("Result:")
    print(f"  Success: {result['success']}")
    print(f"  HTML File: {result['html_file']}")
    print(f"  Live URL: {result['live_url']}")
    print(f"  Message: {result['message']}")
    print()

    if result['success']:
        print(f"✅ Product page created successfully!")
        print(f"📄 Local: {result['local_path']}")
        print(f"🌐 Live: {result['live_url']}")
    else:
        print(f"❌ Failed: {result['message']}")
