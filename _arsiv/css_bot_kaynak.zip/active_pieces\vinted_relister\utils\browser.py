# Browser utilities for Vinted Relister
import asyncio
import random
import time
from typing import Optional, List, Tuple
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (
    CHROME_USER_DATA, CHROME_PROFILE,
    DELAY_BETWEEN_FIELDS, DELAY_BETWEEN_CHARS, PAGE_LOAD_WAIT
)

try:
    from playwright.async_api import async_playwright, Page, Browser, BrowserContext
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False
    print("Warning: Playwright not installed. Run: pip install playwright && playwright install chromium")


class HumanLikeBrowser:
    """Browser automation with human-like behavior to avoid detection"""

    def __init__(self, headless: bool = False):
        self.headless = headless
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def start(self):
        """Start browser with existing Chrome profile"""
        if not PLAYWRIGHT_AVAILABLE:
            raise ImportError("Playwright is not installed")

        self.playwright = await async_playwright().start()

        # Launch with existing Chrome user data to maintain login session
        self.browser = await self.playwright.chromium.launch_persistent_context(
            user_data_dir=CHROME_USER_DATA,
            channel='chrome',
            headless=self.headless,
            args=[
                f'--profile-directory={CHROME_PROFILE}',
                '--disable-blink-features=AutomationControlled',
                '--disable-features=IsolateOrigins,site-per-process',
            ],
            viewport={'width': 1920, 'height': 1080},
            locale='de-DE',
            timezone_id='Europe/Berlin'
        )

        self.page = self.browser.pages[0] if self.browser.pages else await self.browser.new_page()

        # Remove automation indicators
        await self.page.add_init_script('''
            Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
            Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3, 4, 5]});
        ''')

    async def close(self):
        """Close browser"""
        if self.browser:
            await self.browser.close()
        if hasattr(self, 'playwright'):
            await self.playwright.stop()

    async def goto(self, url: str, wait_for: str = 'networkidle'):
        """Navigate to URL with human-like delay"""
        await self.page.goto(url, wait_until=wait_for)
        await self.random_delay(*PAGE_LOAD_WAIT)

    async def random_delay(self, min_sec: float, max_sec: float):
        """Random delay between actions"""
        delay = random.uniform(min_sec, max_sec)
        await asyncio.sleep(delay)

    async def human_type(self, selector: str, text: str, clear_first: bool = True):
        """Type text with human-like speed and random delays"""
        element = await self.page.query_selector(selector)
        if not element:
            raise ValueError(f"Element not found: {selector}")

        if clear_first:
            await element.click()
            await self.page.keyboard.press('Control+a')
            await asyncio.sleep(0.1)
            await self.page.keyboard.press('Backspace')

        for char in text:
            await element.type(char, delay=random.uniform(*DELAY_BETWEEN_CHARS) * 1000)

    async def human_click(self, selector: str, move_mouse: bool = True):
        """Click with human-like mouse movement"""
        element = await self.page.query_selector(selector)
        if not element:
            raise ValueError(f"Element not found: {selector}")

        box = await element.bounding_box()
        if box and move_mouse:
            # Move mouse with bezier curve (human-like path)
            x = box['x'] + box['width'] / 2 + random.uniform(-5, 5)
            y = box['y'] + box['height'] / 2 + random.uniform(-5, 5)
            await self.page.mouse.move(x, y, steps=random.randint(10, 25))
            await asyncio.sleep(random.uniform(0.1, 0.3))

        await element.click()
        await self.random_delay(*DELAY_BETWEEN_FIELDS)

    async def scroll_to_element(self, selector: str):
        """Scroll to element smoothly"""
        await self.page.evaluate(f'''
            document.querySelector("{selector}")?.scrollIntoView({{
                behavior: 'smooth',
                block: 'center'
            }});
        ''')
        await self.random_delay(0.5, 1.5)

    async def wait_for_selector(self, selector: str, timeout: int = 30000):
        """Wait for element to appear"""
        return await self.page.wait_for_selector(selector, timeout=timeout)

    async def get_text(self, selector: str) -> Optional[str]:
        """Get text content of element"""
        element = await self.page.query_selector(selector)
        if element:
            return await element.text_content()
        return None

    async def get_attribute(self, selector: str, attribute: str) -> Optional[str]:
        """Get attribute of element"""
        element = await self.page.query_selector(selector)
        if element:
            return await element.get_attribute(attribute)
        return None

    async def get_all_elements(self, selector: str) -> List:
        """Get all matching elements"""
        return await self.page.query_selector_all(selector)

    async def upload_files(self, selector: str, file_paths: List[str]):
        """Upload files to input element"""
        element = await self.page.query_selector(selector)
        if element:
            await element.set_input_files(file_paths)
            await self.random_delay(1, 3)

    async def screenshot(self, path: str):
        """Take screenshot"""
        await self.page.screenshot(path=path, full_page=False)

    async def check_captcha(self) -> bool:
        """Check if captcha is present"""
        captcha_selectors = [
            'iframe[src*="captcha"]',
            'iframe[src*="recaptcha"]',
            '.captcha',
            '#captcha',
            '[class*="captcha"]'
        ]
        for selector in captcha_selectors:
            element = await self.page.query_selector(selector)
            if element:
                return True
        return False

    async def select_dropdown(self, selector: str, value: str):
        """Select option from dropdown"""
        await self.human_click(selector)
        await self.random_delay(0.5, 1)

        # Try to find and click the option
        option_selector = f'{selector} option[value="{value}"]'
        option = await self.page.query_selector(option_selector)
        if option:
            await self.page.select_option(selector, value)
        else:
            # Try clicking on visible option
            await self.page.click(f'text="{value}"')

        await self.random_delay(*DELAY_BETWEEN_FIELDS)


class SyncBrowser:
    """Synchronous wrapper for HumanLikeBrowser"""

    def __init__(self, headless: bool = False):
        self.headless = headless
        self.browser = None
        self.page = None

    def start(self):
        """Start browser synchronously"""
        if not PLAYWRIGHT_AVAILABLE:
            raise ImportError("Playwright is not installed")

        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch_persistent_context(
            user_data_dir=CHROME_USER_DATA,
            channel='chrome',
            headless=self.headless,
            args=[
                f'--profile-directory={CHROME_PROFILE}',
                '--disable-blink-features=AutomationControlled',
            ],
            viewport={'width': 1920, 'height': 1080},
            locale='de-DE',
            timezone_id='Europe/Berlin'
        )
        self.page = self.browser.pages[0] if self.browser.pages else self.browser.new_page()

        # Remove automation indicators
        self.page.add_init_script('''
            Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
        ''')

    def close(self):
        """Close browser"""
        if self.browser:
            self.browser.close()
        if self.playwright:
            self.playwright.stop()

    def goto(self, url: str):
        """Navigate to URL"""
        self.page.goto(url, wait_until='networkidle')
        time.sleep(random.uniform(*PAGE_LOAD_WAIT))

    def human_type(self, selector: str, text: str):
        """Type with human-like speed"""
        element = self.page.query_selector(selector)
        if element:
            element.click()
            self.page.keyboard.press('Control+a')
            self.page.keyboard.press('Backspace')
            for char in text:
                element.type(char, delay=random.uniform(*DELAY_BETWEEN_CHARS) * 1000)

    def human_click(self, selector: str):
        """Click element"""
        self.page.click(selector)
        time.sleep(random.uniform(*DELAY_BETWEEN_FIELDS))

    def screenshot(self, path: str):
        """Take screenshot"""
        self.page.screenshot(path=path)


class VintedLoginHandler:
    """Handle Vinted login flows - Email and Google"""

    VINTED_BASE_URL = 'https://www.vinted.de'

    # CSS Selectors for Vinted Login
    SELECTORS = {
        # Cookie consent
        'cookie_accept': 'button[data-testid="cookie-consent-banner-accept"]',
        'cookie_accept_all': 'text="Alle zulassen"',

        # Login button on main page
        'login_button': 'a[href*="select_type"]',
        'register_login': 'text="Registrieren | Einloggen"',

        # Login modal options
        'google_login': 'button[data-testid="google-button"]',
        'google_login_text': 'text="Weiter mit Google"',
        'facebook_login': 'text="Weiter mit Facebook"',
        'apple_login': 'text="Weiter mit Apple"',
        'email_login': 'a[data-testid="email-login-link"]',
        'email_login_text': 'text="E-Mail"',

        # Email login form
        'email_input': 'input[data-testid="email-input"]',
        'email_input_name': 'input[name="email"]',
        'password_input': 'input[data-testid="password-input"]',
        'password_input_name': 'input[name="password"]',
        'submit_button': 'button[data-testid="submit-button"]',
        'submit_button_text': 'button:has-text("Weiter")',

        # Logged in indicators
        'user_menu': '[data-testid="user-menu"]',
        'profile_link': 'a[href*="/member/"]',
        'inbox_link': 'a[href*="/inbox"]',
        'sell_button': 'a[href*="/items/new"]'
    }

    def __init__(self, browser: SyncBrowser):
        self.browser = browser
        self.page = browser.page

    def accept_cookies(self) -> bool:
        """Accept cookie consent if present"""
        try:
            # Try multiple selectors for cookie accept
            for selector in [self.SELECTORS['cookie_accept'], self.SELECTORS['cookie_accept_all']]:
                try:
                    element = self.page.query_selector(selector)
                    if element:
                        element.click()
                        time.sleep(1)
                        return True
                except:
                    continue
            return False
        except Exception as e:
            print(f"Cookie accept error: {e}")
            return False

    def is_logged_in(self) -> bool:
        """Check if user is already logged in"""
        try:
            # Multiple ways to detect login status
            indicators = [
                self.SELECTORS['user_menu'],
                self.SELECTORS['inbox_link'],
                self.SELECTORS['sell_button']
            ]

            for selector in indicators:
                try:
                    element = self.page.query_selector(selector)
                    if element:
                        return True
                except:
                    continue

            # Check if "Registrieren | Einloggen" is NOT visible (means logged in)
            login_btn = self.page.query_selector(self.SELECTORS['register_login'])
            if not login_btn:
                # Check URL for member page access
                if '/member/' in self.page.url or '/items/new' in self.page.url:
                    return True

            return False
        except:
            return False

    def open_login_modal(self) -> bool:
        """Open the login modal"""
        try:
            # Try clicking on login button
            for selector in [self.SELECTORS['register_login'], self.SELECTORS['login_button']]:
                try:
                    element = self.page.query_selector(selector)
                    if element:
                        element.click()
                        time.sleep(2)
                        return True
                except:
                    continue
            return False
        except Exception as e:
            print(f"Open login modal error: {e}")
            return False

    def login_with_email(self, email: str, password: str) -> dict:
        """
        Login to Vinted with email/password

        Flow:
        1. Go to vinted.de
        2. Accept cookies
        3. Click "Registrieren | Einloggen"
        4. Click "E-Mail" link
        5. Enter email
        6. Enter password
        7. Click "Weiter"
        """
        result = {'success': False, 'message': '', 'step': ''}

        try:
            # Step 1: Go to Vinted
            result['step'] = 'navigate'
            self.browser.goto(self.VINTED_BASE_URL)
            time.sleep(2)

            # Step 2: Accept cookies
            result['step'] = 'cookies'
            self.accept_cookies()
            time.sleep(1)

            # Check if already logged in
            if self.is_logged_in():
                result['success'] = True
                result['message'] = 'Zaten giris yapilmis'
                return result

            # Step 3: Open login modal
            result['step'] = 'open_modal'
            if not self.open_login_modal():
                result['message'] = 'Login butonu bulunamadi'
                return result
            time.sleep(2)

            # Step 4: Click E-Mail option
            result['step'] = 'email_option'
            email_clicked = False
            for selector in [self.SELECTORS['email_login'], self.SELECTORS['email_login_text']]:
                try:
                    element = self.page.query_selector(selector)
                    if element:
                        element.click()
                        email_clicked = True
                        time.sleep(2)
                        break
                except:
                    continue

            if not email_clicked:
                result['message'] = 'E-Mail secenegi bulunamadi'
                return result

            # Step 5: Enter email
            result['step'] = 'enter_email'
            email_input = None
            for selector in [self.SELECTORS['email_input'], self.SELECTORS['email_input_name'], 'input[placeholder*="E-Mail"]']:
                try:
                    email_input = self.page.query_selector(selector)
                    if email_input:
                        break
                except:
                    continue

            if not email_input:
                result['message'] = 'E-Mail alani bulunamadi'
                return result

            email_input.click()
            email_input.fill(email)
            time.sleep(0.5)

            # Step 6: Enter password
            result['step'] = 'enter_password'
            password_input = None
            for selector in [self.SELECTORS['password_input'], self.SELECTORS['password_input_name'], 'input[type="password"]']:
                try:
                    password_input = self.page.query_selector(selector)
                    if password_input:
                        break
                except:
                    continue

            if not password_input:
                result['message'] = 'Sifre alani bulunamadi'
                return result

            password_input.click()
            password_input.fill(password)
            time.sleep(0.5)

            # Step 7: Click submit
            result['step'] = 'submit'
            submit_clicked = False
            for selector in [self.SELECTORS['submit_button'], self.SELECTORS['submit_button_text']]:
                try:
                    submit_btn = self.page.query_selector(selector)
                    if submit_btn:
                        submit_btn.click()
                        submit_clicked = True
                        break
                except:
                    continue

            if not submit_clicked:
                result['message'] = 'Giris butonu bulunamadi'
                return result

            # Wait for login to complete
            time.sleep(5)

            # Check login success
            result['step'] = 'verify'
            if self.is_logged_in():
                result['success'] = True
                result['message'] = 'Basariyla giris yapildi'
            else:
                # Check for error messages
                error_selectors = ['[data-testid="error-message"]', '.error-message', '.alert-error']
                for sel in error_selectors:
                    try:
                        error = self.page.query_selector(sel)
                        if error:
                            result['message'] = f'Giris hatasi: {error.text_content()}'
                            return result
                    except:
                        continue
                result['message'] = 'Giris dogrulanamadi - sayfa kontrol edin'

            return result

        except Exception as e:
            result['message'] = f'Hata ({result["step"]}): {str(e)}'
            return result

    def login_with_google(self) -> dict:
        """
        Login to Vinted with Google (uses existing Chrome profile session)

        Flow:
        1. Go to vinted.de
        2. Accept cookies
        3. Click "Registrieren | Einloggen"
        4. Click "Weiter mit Google"
        5. Chrome profile handles Google auth
        """
        result = {'success': False, 'message': '', 'step': ''}

        try:
            # Step 1: Go to Vinted
            result['step'] = 'navigate'
            self.browser.goto(self.VINTED_BASE_URL)
            time.sleep(2)

            # Step 2: Accept cookies
            result['step'] = 'cookies'
            self.accept_cookies()
            time.sleep(1)

            # Check if already logged in
            if self.is_logged_in():
                result['success'] = True
                result['message'] = 'Zaten giris yapilmis'
                return result

            # Step 3: Open login modal
            result['step'] = 'open_modal'
            if not self.open_login_modal():
                result['message'] = 'Login butonu bulunamadi'
                return result
            time.sleep(2)

            # Step 4: Click Google login
            result['step'] = 'google_click'
            google_clicked = False
            for selector in [self.SELECTORS['google_login'], self.SELECTORS['google_login_text']]:
                try:
                    element = self.page.query_selector(selector)
                    if element:
                        element.click()
                        google_clicked = True
                        time.sleep(5)  # Google auth can take longer
                        break
                except:
                    continue

            if not google_clicked:
                result['message'] = 'Google secenegi bulunamadi'
                return result

            # Wait for Google auth popup/redirect
            time.sleep(10)

            # Check login success
            result['step'] = 'verify'
            # Navigate back to vinted if redirected
            if 'google.com' in self.page.url or 'accounts.google' in self.page.url:
                result['message'] = 'Google giris sayfasinda - manuel giris gerekebilir'
                return result

            if self.is_logged_in():
                result['success'] = True
                result['message'] = 'Google ile basariyla giris yapildi'
            else:
                result['message'] = 'Google giris dogrulanamadi'

            return result

        except Exception as e:
            result['message'] = f'Hata ({result["step"]}): {str(e)}'
            return result

    def check_login_status(self) -> dict:
        """Just check if currently logged in without attempting login"""
        result = {'logged_in': False, 'username': None, 'message': ''}

        try:
            self.browser.goto(self.VINTED_BASE_URL)
            time.sleep(3)

            # Accept cookies first
            self.accept_cookies()
            time.sleep(1)

            if self.is_logged_in():
                result['logged_in'] = True
                result['message'] = 'Aktif oturum mevcut'

                # Try to get username
                try:
                    profile_link = self.page.query_selector(self.SELECTORS['profile_link'])
                    if profile_link:
                        href = profile_link.get_attribute('href')
                        if href:
                            result['username'] = href.split('/')[-1]
                except:
                    pass
            else:
                result['message'] = 'Giris yapilmamis'

            return result

        except Exception as e:
            result['message'] = f'Kontrol hatasi: {str(e)}'
            return result


def test_vinted_login(chrome_profile: str, login_type: str, email: str = '', password: str = '',
                      proxy_host: str = '', proxy_port: int = 0) -> dict:
    """
    Standalone function to test Vinted login with optional proxy support

    Args:
        chrome_profile: Chrome profile name (e.g., "Default", "Profile 2")
        login_type: "email", "google", or "check"
        email: Email for email login
        password: Password for email login
        proxy_host: Proxy host IP (e.g., "192.168.43.1")
        proxy_port: Proxy port (e.g., 8080)

    Returns:
        dict with success status and message
    """
    result = {'success': False, 'message': '', 'login_type': login_type, 'proxy_used': False}

    browser = None
    try:
        # Create browser with specified profile
        browser = SyncBrowser(headless=False)

        # Build args list
        args = [
            f'--profile-directory={chrome_profile}',
            '--disable-blink-features=AutomationControlled',
        ]

        # Add proxy if configured
        if proxy_host and proxy_port:
            args.append(f'--proxy-server=http://{proxy_host}:{proxy_port}')
            result['proxy_used'] = True
            result['proxy'] = f'{proxy_host}:{proxy_port}'

        # Override chrome profile
        from config import CHROME_USER_DATA
        browser.playwright = sync_playwright().start()
        browser.browser = browser.playwright.chromium.launch_persistent_context(
            user_data_dir=CHROME_USER_DATA,
            channel='chrome',
            headless=False,
            args=args,
            viewport={'width': 1920, 'height': 1080},
            locale='de-DE',
            timezone_id='Europe/Berlin'
        )
        browser.page = browser.browser.pages[0] if browser.browser.pages else browser.browser.new_page()

        # Create login handler
        handler = VintedLoginHandler(browser)

        if login_type == 'check':
            check_result = handler.check_login_status()
            result['success'] = check_result['logged_in']
            result['message'] = check_result['message']
            result['username'] = check_result.get('username')

        elif login_type == 'email':
            if not email or not password:
                result['message'] = 'E-Mail ve sifre gerekli'
                return result
            login_result = handler.login_with_email(email, password)
            result['success'] = login_result['success']
            result['message'] = login_result['message']

        elif login_type == 'google':
            login_result = handler.login_with_google()
            result['success'] = login_result['success']
            result['message'] = login_result['message']

        else:
            result['message'] = f'Bilinmeyen login tipi: {login_type}'

    except Exception as e:
        import traceback
        error_msg = str(e) if str(e) else type(e).__name__
        result['message'] = f'Test hatasi: {error_msg}'
        result['traceback'] = traceback.format_exc()
        print(f"[BROWSER ERROR] {error_msg}")
        print(f"[TRACEBACK] {traceback.format_exc()}")

    finally:
        if browser:
            try:
                browser.close()
            except:
                pass

    return result
