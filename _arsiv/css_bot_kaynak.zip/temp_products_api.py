"""
TATANGA V3 - Products API
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from database import get_db
from models import Product
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
import random

router = APIRouter()


def generate_scr_id():
    date_str = datetime.now().strftime("%Y%m%d")
    seq = str(random.randint(1, 9999)).zfill(4)
    return f"SCR-{date_str}-{seq}"


class CreateProductRequest(BaseModel):
    title: str
    source_url: str
    platform: str
    price: Optional[float] = None
    shipping_cost: Optional[float] = None
    images: Optional[List[str]] = None
    category: Optional[str] = None
    brand: Optional[str] = None


class ProductResponse(BaseModel):
    id: int
    scr_id: str
    source_url: str
    source_platform: Optional[str]
    title: Optional[str]
    price: Optional[float]
    shipping_cost: Optional[float]
    images: List[dict]
    category: Optional[str]
    brand: Optional[str]
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


@router.get("/", response_model=List[ProductResponse])
async def get_products(
    status: Optional[str] = None,
    platform: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    query = select(Product).order_by(desc(Product.created_at))
    if status:
        query = query.where(Product.status == status)
    if platform:
        query = query.where(Product.source_platform == platform)
    query = query.offset(skip).limit(limit)

    result = await db.execute(query)
    return result.scalars().all()


@router.post("/")
async def create_product(request: CreateProductRequest, db: AsyncSession = Depends(get_db)):
    """Create a new product manually or from scraper"""
    # Check if URL already exists
    existing = await db.execute(
        select(Product).where(Product.source_url == request.source_url)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Product with this URL already exists")

    # Create images list
    images = []
    if request.images:
        for i, img_url in enumerate(request.images):
            images.append({"url": img_url, "position": i + 1})

    product = Product(
        scr_id=generate_scr_id(),
        source_url=request.source_url,
        source_platform=request.platform,
        title=request.title,
        price=request.price,
        shipping_cost=request.shipping_cost,
        images=images,
        category=request.category,
        brand=request.brand,
        status="inbox"
    )

    db.add(product)
    await db.commit()
    await db.refresh(product)

    return {
        "message": "Product created",
        "product_id": product.id,
        "scr_id": product.scr_id
    }


@router.get("/inbox")
async def get_inbox(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    query = select(Product).where(Product.status == "inbox").order_by(desc(Product.created_at)).offset(skip).limit(limit)
    result = await db.execute(query)
    return result.scalars().all()


@router.get("/{product_id}")
async def get_product(product_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Product).where(Product.id == product_id))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product


@router.patch("/{product_id}")
async def update_product(
    product_id: int,
    title: Optional[str] = None,
    price: Optional[float] = None,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Update product fields"""
    result = await db.execute(select(Product).where(Product.id == product_id))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    if title:
        product.title = title
    if price is not None:
        product.price = price
    if status:
        product.status = status

    await db.commit()
    return {"message": "Product updated"}


@router.delete("/{product_id}")
async def delete_product(product_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Product).where(Product.id == product_id))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    await db.delete(product)
    await db.commit()
    return {"message": "Product deleted"}
