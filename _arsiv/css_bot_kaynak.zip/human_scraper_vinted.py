"""
TATANGA V3 - Vinted Human Scraper
İnsan-benzeri davranışlarla Vinted'den ürün kazıma
"""
from human_scraper_base import HumanScraper, LOG_DIR
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
from typing import List, Dict, Optional
import time
import random
import re


class VintedScraper(HumanScraper):
    """Vinted için insan-benzeri scraper"""

    BASE_URL = "https://www.vinted.de"

    # Filtre kombinasyonları - 10 sayfa limitini aşmak için
    SORT_OPTIONS = ["newest_first", "price_low_to_high", "price_high_to_low", "relevance"]
    CONDITION_IDS = {
        "new_with_tags": 6,
        "new_without_tags": 1,
        "very_good": 2,
        "good": 3,
        "satisfactory": 4
    }

    # Almanca durum isimleri -> Vinted status_ids mapping
    CONDITION_MAPPING = {
        # Almanca
        "neu": [6, 1],              # Yeni (etiketli ve etiketsiz)
        "sehr_gut": [2],            # Sehr gut = very_good
        "sehr gut": [2],
        "gut": [3],                 # Gut = good
        "akzeptabel": [4],          # Akzeptabel = satisfactory
        # English
        "new": [6, 1],
        "very_good": [2],
        "good": [3],
        "acceptable": [4],
        "satisfactory": [4],
    }

    PRICE_RANGES = [
        (None, 10),
        (10, 25),
        (25, 50),
        (50, 100),
        (100, 200),
        (200, None)
    ]

    def translate_condition(self, condition: str) -> List[int]:
        """Almanca durum değerini Vinted status_ids'e çevir"""
        if not condition:
            return []
        condition_lower = condition.lower().replace(" ", "_")
        # Önce mapping'e bak
        if condition_lower in self.CONDITION_MAPPING:
            return self.CONDITION_MAPPING[condition_lower]
        # Direkt ID ise
        if condition_lower in self.CONDITION_IDS:
            return [self.CONDITION_IDS[condition_lower]]
        return []

    def __init__(self, headless: bool = True):
        super().__init__("vinted", headless)
        self.products_found = []
        self.visited_urls = set()

    def go_to_homepage(self):
        """Vinted ana sayfasına git"""
        self.log("Vinted ana sayfasına gidiliyor...")
        self.visit_url(self.BASE_URL)
        self.screenshot("homepage")

        # Cookie banner'ı kapat
        self.random_delay(1, 2)
        self.close_cookie_banner()

    def find_search_bar(self):
        """Arama çubuğunu bul"""
        search_selectors = [
            "input[data-testid='search-bar-input']",
            "input[placeholder*='Suche']",
            "input[placeholder*='search']",
            ".SearchBar input",
            "input[type='search']",
            "#search_text",
        ]

        for selector in search_selectors:
            try:
                element = self.driver.find_element(By.CSS_SELECTOR, selector)
                if element.is_displayed():
                    self.log(f"Arama çubuğu bulundu: {selector}")
                    return element
            except:
                pass

        self.log("Arama çubuğu bulunamadı!", "error")
        self.screenshot("search_bar_not_found")
        return None

    def search(self, query: str):
        """
        Arama yap - insansı yazma ile
        """
        self.log(f"Arama yapılıyor: '{query}'")

        search_bar = self.find_search_bar()
        if not search_bar:
            return False

        # Arama çubuğuna tıkla
        self.human_click(search_bar)
        self.random_delay(0.3, 0.7)

        # Temizle (varsa eski arama)
        search_bar.clear()
        self.random_delay(0.2, 0.4)

        # İnsan gibi yaz
        self.human_type(search_bar, query, make_mistakes=True)
        self.screenshot("search_typed")

        # Enter'a bas
        self.random_delay(0.5, 1.0)
        search_bar.send_keys(Keys.ENTER)

        self.log("Arama gönderildi, sonuçlar bekleniyor...")
        self.random_delay(3, 5)
        self.screenshot("search_results")

        return True

    def get_product_elements(self) -> list:
        """Sayfadaki ürün elementlerini al"""
        selectors = [
            "[data-testid='grid-item']",
            ".feed-grid__item",
            ".new-item-box__container",
        ]

        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    self.log(f"{len(elements)} ürün elementi bulundu ({selector})")
                    return elements
            except:
                pass

        return []

    def extract_product_data(self, element) -> Optional[Dict]:
        """Ürün elementinden veri çıkar"""
        try:
            # Resim elementinden veri al (en güvenilir)
            img = element.find_element(By.CSS_SELECTOR, "img[data-testid*='product-item']")
            alt_text = img.get_attribute("alt") or ""
            testid = img.get_attribute("data-testid") or ""

            # Product ID'yi al
            match = re.search(r"product-item-id-(\d+)", testid)
            if not match:
                return None

            product_id = match.group(1)
            url = f"{self.BASE_URL}/items/{product_id}"

            # Alt text'ten bilgi çıkar
            # Format: "Ürün adı, marke: Marka, zustand: Durum, 20,00 €"
            title = alt_text.split(",")[0].strip() if alt_text else ""

            # Fiyat
            price = None
            price_match = re.search(r"([\d.,]+)\s*(?:€|EUR)", alt_text)
            if price_match:
                try:
                    price = float(price_match.group(1).replace(".", "").replace(",", "."))
                except:
                    pass

            # Durum
            condition = None
            cond_match = re.search(r"zustand:\s*([^,]+)", alt_text, re.IGNORECASE)
            if cond_match:
                condition = cond_match.group(1).strip()

            # Resim URL
            image_url = img.get_attribute("src")

            return {
                "product_id": product_id,
                "url": url,
                "title": title,
                "price": price,
                "condition": condition,
                "image": image_url,
                "platform": "vinted",
                "scraped_at": datetime.now().isoformat()
            }

        except Exception as e:
            self.log(f"Ürün verisi çıkarma hatası: {e}", "debug")
            return None

    def visit_random_product(self) -> Optional[Dict]:
        """Rastgele bir ürüne git, satıcı profilini ziyaret et, geri dön"""
        elements = self.get_product_elements()
        if not elements:
            return None

        # Rastgele bir ürün seç (ilk 10'dan)
        random_elements = random.sample(elements[:min(10, len(elements))], 1)
        element = random_elements[0]

        product_data = self.extract_product_data(element)
        if not product_data or product_data["url"] in self.visited_urls:
            return None

        self.visited_urls.add(product_data["url"])

        self.log(f"Ürüne gidiliyor: {product_data['title'][:50]}...")

        # Ürün sayfasına git
        self.visit_url(product_data["url"])
        self.random_delay(2, 4)
        self.screenshot("product_page")

        # Biraz scroll yap (ürünü incele gibi)
        self.human_scroll("down", random.randint(200, 400))
        self.random_delay(1, 3)

        # Satıcı profiline git (%70 ihtimalle)
        if random.random() < 0.7:
            self._visit_seller_profile()

        # Geri dön
        self.go_back()  # Ürün sayfasına
        self.random_delay(1, 2)
        self.go_back()  # Arama sonuçlarına

        return product_data

    def _visit_seller_profile(self):
        """Satıcı profilini ziyaret et"""
        seller_selectors = [
            "[data-testid='user-profile-link']",
            "a[href*='/member/']",
            ".ItemBox__overlay a",
            "[class*='seller'] a",
        ]

        for selector in seller_selectors:
            try:
                link = self.driver.find_element(By.CSS_SELECTOR, selector)
                if link.is_displayed():
                    self.log("Satıcı profiline gidiliyor...")
                    self.human_click(link)
                    self.random_delay(2, 4)
                    self.screenshot("seller_profile")

                    # Biraz bekle ve scroll
                    self.human_scroll("down", random.randint(200, 400))
                    self.random_delay(1, 3)

                    # Geri dön
                    self.go_back()
                    return True
            except:
                pass

        self.log("Satıcı profili bulunamadı", "debug")
        return False

    def load_more_products(self) -> bool:
        """
        Daha fazla ürün yükle (Vinted infinite scroll)
        Geliştirilmiş versiyon - sayfanın sonuna kadar agresif scroll
        """
        initial_count = len(self.get_product_elements())
        self.log(f"Mevcut ürün sayısı: {initial_count}")

        # Sayfanın altına agresif scroll
        for attempt in range(3):
            # Sayfanın en altına git
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            self.random_delay(1.5, 2.5)

            # Biraz yukarı scroll (lazy load tetikle)
            self.driver.execute_script("window.scrollBy(0, -300);")
            self.random_delay(0.5, 1)

            # Tekrar aşağı
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            self.random_delay(2, 3)

            # Yeni ürün yüklendi mi kontrol
            new_count = len(self.get_product_elements())
            if new_count > initial_count:
                self.log(f"Scroll ile yüklendi: {initial_count} -> {new_count}")
                return True

        # "Load more" butonu dene
        load_more_selectors = [
            "button[data-testid='load-more']",
            "[class*='LoadMoreButton']",
            "[class*='load-more'] button",
            ".feed-grid__load-more button",
            "button[class*='mehr']",
        ]

        for selector in load_more_selectors:
            try:
                btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.log(f"Load more butonu bulundu: {selector}")
                    self.human_click(btn)
                    self.random_delay(3, 5)

                    new_count = len(self.get_product_elements())
                    if new_count > initial_count:
                        self.log(f"Buton ile yüklendi: {initial_count} -> {new_count}")
                        return True
            except:
                pass

        self.log("Daha fazla ürün yüklenemedi - sayfa sonu")
        return False

    def extract_all_products(self) -> List[Dict]:
        """Sayfadaki tüm ürünleri çıkar"""
        elements = self.get_product_elements()
        products = []

        for element in elements:
            product = self.extract_product_data(element)
            if product and product["url"] not in [p["url"] for p in self.products_found]:
                products.append(product)
                self.products_found.append(product)

        self.log(f"{len(products)} yeni ürün çıkarıldı (Toplam: {len(self.products_found)})")
        return products

    def build_search_url(self, query: str, page: int = 1,
                         price_from: int = None, price_to: int = None,
                         status_ids: List[int] = None, order: str = None) -> str:
        """
        Vinted arama URL'si oluştur

        Args:
            query: Arama kelimesi
            page: Sayfa numarası (1-10)
            price_from: Min fiyat
            price_to: Max fiyat
            status_ids: Durum ID'leri [6=yeni etiketli, 1=yeni, 2=çok iyi, 3=iyi, 4=kabul edilebilir]
            order: Sıralama (newest_first, price_low_to_high, price_high_to_low, relevance)
        """
        import urllib.parse

        params = {
            "search_text": query,
            "page": page
        }

        if price_from is not None:
            params["price_from"] = price_from
        if price_to is not None:
            params["price_to"] = price_to
        if status_ids:
            params["status_ids[]"] = status_ids
        if order:
            params["order"] = order

        # URL encode
        query_string = urllib.parse.urlencode(params, doseq=True)
        return f"{self.BASE_URL}/catalog?{query_string}"

    def scrape_page(self, url: str, visit_products: bool = True) -> List[Dict]:
        """
        Tek bir sayfayı kazı
        """
        self.log(f"Sayfa açılıyor: {url}")
        self.visit_url(url)

        # Cookie banner'ı kapat (ilk sayfada)
        self.close_cookie_banner()

        # Ürünleri çıkar
        products = self.extract_all_products()

        # Rastgele ürün ziyareti (%20 ihtimalle)
        if visit_products and random.random() < 0.2 and products:
            self.visit_random_product()

        return products

    def scrape(self, query: str, max_products: int = None, max_pages: int = None,
               visit_products: bool = True, use_filters: bool = True,
               condition: str = None, conditions: list = None) -> List[Dict]:
        """
        Ana kazıma fonksiyonu - URL tabanlı pagination ile

        Args:
            query: Arama kelimesi
            max_products: Maksimum ürün sayısı (None = sınırsız)
            max_pages: Maksimum sayfa sayısı per filtre (None = 10, Vinted limiti)
            visit_products: Rastgele ürünlere git
            use_filters: Filtre kombinasyonları kullan (10 sayfa limitini aşmak için)
            condition: Tek durum (str) - "sehr gut", "gut", "akzeptabel" vb.
            conditions: Çoklu durum listesi ["sehr gut", "gut"]
        """
        self.log(f"=== KAZIMA BAŞLIYOR ===")
        self.log(f"Arama: {query}")
        self.log(f"Max ürün: {max_products or 'Sınırsız'}")
        self.log(f"Filtreler: {'Evet' if use_filters else 'Hayır'}")

        # Durum filtresi varsa, status_ids'e çevir
        forced_status_ids = []
        if conditions:
            for cond in conditions:
                forced_status_ids.extend(self.translate_condition(cond))
        elif condition:
            forced_status_ids = self.translate_condition(condition)

        if forced_status_ids:
            self.log(f"Durum filtresi: {condition or conditions} -> status_ids: {forced_status_ids}")

        # Vinted max 10 sayfa gösteriyor
        pages_per_filter = min(max_pages or 10, 10)

        try:
            # Filtre kombinasyonlarını oluştur
            if use_filters:
                filter_combinations = self._generate_filter_combinations()
            else:
                filter_combinations = [{}]  # Filtresiz tek kombinasyon

            self.log(f"Toplam filtre kombinasyonu: {len(filter_combinations)}")

            for filter_idx, filters in enumerate(filter_combinations):
                self.log(f"--- Filtre {filter_idx + 1}/{len(filter_combinations)}: {filters} ---")

                for page in range(1, pages_per_filter + 1):
                    # URL oluştur - forced_status_ids varsa onu kullan
                    status_ids = forced_status_ids if forced_status_ids else filters.get("status_ids")
                    url = self.build_search_url(
                        query=query,
                        page=page,
                        price_from=filters.get("price_from"),
                        price_to=filters.get("price_to"),
                        status_ids=status_ids,
                        order=filters.get("order")
                    )

                    self.log(f"Sayfa {page}/{pages_per_filter}")

                    # Sayfayı kazı
                    before_count = len(self.products_found)
                    self.scrape_page(url, visit_products)
                    after_count = len(self.products_found)

                    new_products = after_count - before_count
                    self.log(f"+{new_products} yeni ürün (Toplam: {after_count})")

                    # Limit kontrolü
                    if max_products and len(self.products_found) >= max_products:
                        self.log(f"Maksimum ürün sayısına ulaşıldı: {max_products}")
                        break

                    # Boş sayfa = sonraki filtreye geç
                    if new_products == 0:
                        self.log("Boş sayfa, sonraki filtreye geçiliyor...")
                        break

                    # İnsansı bekleme
                    self.random_delay(2, 4)

                # Toplam limit kontrolü
                if max_products and len(self.products_found) >= max_products:
                    break

            self.log(f"=== KAZIMA TAMAMLANDI ===")
            self.log(f"Toplam ürün: {len(self.products_found)}")
            self.screenshot("scraping_complete")

            return self.products_found

        except Exception as e:
            self.log(f"Kazıma hatası: {e}", "error")
            self.screenshot("error")
            raise

    def _generate_filter_combinations(self) -> List[Dict]:
        """
        Filtre kombinasyonları oluştur
        Vinted 10 sayfa limitini aşmak için farklı filtre setleri
        """
        combinations = []

        # Önce filtresiz
        combinations.append({})

        # Fiyat aralıkları ile
        for price_range in self.PRICE_RANGES:
            combinations.append({
                "price_from": price_range[0],
                "price_to": price_range[1]
            })

        # Sıralama ile
        for order in self.SORT_OPTIONS:
            if order != "relevance":  # relevance default
                combinations.append({"order": order})

        # Durum ile
        for condition_name, condition_id in self.CONDITION_IDS.items():
            combinations.append({"status_ids": [condition_id]})

        # Fiyat + Sıralama kombinasyonları
        for price_range in self.PRICE_RANGES[:3]:  # İlk 3 fiyat aralığı
            for order in ["newest_first", "price_low_to_high"]:
                combinations.append({
                    "price_from": price_range[0],
                    "price_to": price_range[1],
                    "order": order
                })

        return combinations


def run_vinted_scrape(query: str, max_products: int = None, headless: bool = True) -> List[Dict]:
    """Vinted kazıma işlemini çalıştır"""
    with VintedScraper(headless=headless) as scraper:
        return scraper.scrape(query, max_products=max_products)


if __name__ == "__main__":
    # Test
    import sys

    query = sys.argv[1] if len(sys.argv) > 1 else "nike"
    max_items = int(sys.argv[2]) if len(sys.argv) > 2 else 20

    print(f"Vinted kazıma başlıyor: {query}")
    products = run_vinted_scrape(query, max_products=max_items, headless=True)

    print(f"\n{len(products)} ürün bulundu:")
    for p in products[:5]:
        print(f"  - {p['title'][:40]} | {p['price']} EUR | {p['url']}")
