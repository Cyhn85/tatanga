# Manuel Login - Session Kaydet
# Browser acilacak, sen login yap, CAPTCHA coz
# Session otomatik kaydedilecek

import os
import sys
import time
sys.stdout.reconfigure(encoding='utf-8')

from playwright.sync_api import sync_playwright

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROFILE_DIR = os.path.join(BASE_DIR, 'playwright_profiles', 'cssberlin')
os.makedirs(PROFILE_DIR, exist_ok=True)

def manual_login():
    print("=" * 60)
    print("MANUEL LOGIN - SESSION KAYDET")
    print("=" * 60)
    print()
    print(">>> CSSBERLIN MAGAZASI <<<")
    print()
    print("!!! HATIRLATMA !!!")
    print("  - Mobil Hotspot'a baglan!")
    print("  - Every Proxy'yi ac!")
    print()
    print("1. Browser acilacak")
    print("2. SEN manuel login yap")
    print("3. CAPTCHA'yi coz")
    print("4. Login tamamlaninca session kaydedilecek")
    print()
    print("=" * 60)

    with sync_playwright() as pw:
        browser = pw.chromium.launch_persistent_context(
            user_data_dir=PROFILE_DIR,
            headless=False,
            viewport={'width': 1400, 'height': 900},
            locale='de-DE',
            timezone_id='Europe/Berlin',
            args=[
                '--disable-blink-features=AutomationControlled',
                '--no-sandbox'
            ]
        )

        page = browser.pages[0] if browser.pages else browser.new_page()

        # Go to Vinted
        print("\n[1] Vinted.de aciliyor...")
        page.goto('https://www.vinted.de/', wait_until='networkidle', timeout=60000)
        time.sleep(2)

        # Accept cookies if shown
        try:
            cookie_btn = page.query_selector('button#onetrust-accept-btn-handler')
            if cookie_btn and cookie_btn.is_visible():
                cookie_btn.click()
                print("[OK] Cookies kabul edildi")
                time.sleep(1)
        except:
            pass

        # Check if already logged in
        header_btn = page.query_selector('a:has-text("Registrieren | Einloggen")')
        if not header_btn:
            print("\n[OK] Zaten giris yapilmis!")
            print("Session kaydedildi.")
            browser.close()
            return True

        print("\n" + "=" * 60)
        print("SIMDI SEN LOGIN YAP!")
        print("=" * 60)
        print()
        print("1. 'Registrieren | Einloggen' butonuna tikla")
        print("2. 'Einloggen' linkine tikla (popup'ta)")
        print("3. 'E-Mail' secenegini tikla")
        print("4. Email: cssberlin@hotmail.com")
        print("5. Sifre: Cssberlin200231")
        print("6. 'Weiter' butonuna tikla")
        print("7. CAPTCHA puzzle'i coz")
        print()
        print("Login tamamlaninca otomatik algilanacak...")
        print("=" * 60)

        # Wait for login
        max_wait = 900  # 15 dakika
        start = time.time()
        logged_in = False

        while time.time() - start < max_wait:
            time.sleep(3)
            elapsed = int(time.time() - start)

            # Check if logged in
            header_btn = page.query_selector('a:has-text("Registrieren | Einloggen")')
            if not header_btn:
                logged_in = True
                break

            print(f"[{elapsed}s] Bekliyor... (Login yapilmadi)")

        if logged_in:
            print("\n" + "=" * 60)
            print("LOGIN BASARILI!")
            print("=" * 60)
            print()
            print("Session kaydedildi: " + PROFILE_DIR)
            print()
            print("Artik auto_uploader.py otomatik calisacak!")
            print("=" * 60)

            # Save screenshot as proof
            page.screenshot(path=os.path.join(BASE_DIR, 'data', 'logged_in.png'))

            print("\nBrowser 30 saniye acik kalacak...")
            time.sleep(30)
            browser.close()
            return True
        else:
            print("\n[TIMEOUT] 5 dakika doldu, login tamamlanmadi")
            browser.close()
            return False


if __name__ == '__main__':
    manual_login()
