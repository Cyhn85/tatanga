#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Database Migration 002
Create LiveScore Engine Tables - Dynamic Intelligence Layer

Creates tables for:
- Product performance tracking
- Seller behavior analysis
- Platform analytics
- Negotiation tracking
- Action recommendations

Run AFTER migration 001 (products table must exist first)
"""

import sys
import sqlite3
from pathlib import Path
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.logger import get_logger

logger = get_logger("migration_002")


def run_migration(db_path: str = None):
    """
    Create all LiveScore-related tables

    Args:
        db_path: Path to tatanga.db (defaults to active_pieces/tatanga.db)
    """
    if db_path is None:
        db_path = Path(__file__).parent.parent / "tatanga.db"

    logger.start_run("Migration 002: Create LiveScore Tables")

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Verify products table exists (dependency)
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='products'
        """)

        if not cursor.fetchone():
            logger.error("Products table does not exist! Run migration 001 first.")
            logger.end_run(success=False, message="Missing dependency: products table")
            return False

        tables_created = 0

        # ====================================================================
        # TABLE 1: Product Performance
        # ====================================================================

        logger.info("Creating product_performance table...")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS product_performance (
                -- Link to products table
                product_id INTEGER PRIMARY KEY,

                -- View Metrics
                views_total INTEGER DEFAULT 0,
                views_today INTEGER DEFAULT 0,
                views_this_week INTEGER DEFAULT 0,
                views_last_updated DATETIME,

                -- Engagement Metrics
                messages_received INTEGER DEFAULT 0,
                favorites_count INTEGER DEFAULT 0,
                share_count INTEGER DEFAULT 0,

                -- Performance Scores (0-100)
                performance_score REAL DEFAULT 50.0,
                view_score REAL DEFAULT 0.0,
                engagement_score REAL DEFAULT 0.0,
                quality_score REAL DEFAULT 0.0,
                price_score REAL DEFAULT 0.0,
                platform_match_score REAL DEFAULT 0.0,

                -- Grade (A, B, C, D, F)
                performance_grade TEXT DEFAULT 'C',

                -- Trends
                score_trend TEXT DEFAULT 'stable',     -- 'up', 'down', 'stable'
                score_change_7d REAL DEFAULT 0.0,      -- Change over last 7 days

                -- Timestamps
                last_viewed_at DATETIME,
                last_message_at DATETIME,
                last_score_update DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
            );
        """)

        # Indexes for product_performance
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_perf_score ON product_performance(performance_score DESC)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_perf_grade ON product_performance(performance_grade)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_perf_trend ON product_performance(score_trend)")

        tables_created += 1
        logger.success("  product_performance table created")

        # ====================================================================
        # TABLE 2: Seller Performance
        # ====================================================================

        logger.info("Creating seller_performance table...")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS seller_performance (
                -- Composite primary key: platform + seller_id
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                seller_id TEXT NOT NULL,
                platform TEXT NOT NULL,

                -- Basic Info
                seller_name TEXT,
                seller_rating REAL,                    -- From platform (0-5 or 0-100)

                -- Conversation Stats
                total_conversations INTEGER DEFAULT 0,
                active_conversations INTEGER DEFAULT 0,
                completed_conversations INTEGER DEFAULT 0,

                -- Response Metrics
                avg_response_time_minutes INTEGER,     -- Average response time
                median_response_time_minutes INTEGER,
                fastest_response_minutes INTEGER,
                slowest_response_minutes INTEGER,
                response_rate REAL DEFAULT 0.0,        -- 0-1 (percentage responding)

                -- Message Quality
                positive_response_count INTEGER DEFAULT 0,
                negative_response_count INTEGER DEFAULT 0,
                neutral_response_count INTEGER DEFAULT 0,

                -- Risk Assessment
                risk_score REAL DEFAULT 50.0,          -- 0-100 (higher = more risky)
                risk_flags INTEGER DEFAULT 0,          -- Count of risk incidents
                off_platform_payment_requests INTEGER DEFAULT 0,
                whatsapp_pushes INTEGER DEFAULT 0,

                -- Performance Score (0-100)
                responsiveness_score REAL DEFAULT 50.0,

                -- Timestamps
                first_interaction DATETIME,
                last_interaction DATETIME,
                last_score_update DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

                UNIQUE(platform, seller_id)
            );
        """)

        # Indexes for seller_performance
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_seller_platform ON seller_performance(platform, seller_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_seller_risk ON seller_performance(risk_score DESC)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_seller_responsive ON seller_performance(responsiveness_score DESC)")

        tables_created += 1
        logger.success("  seller_performance table created")

        # ====================================================================
        # TABLE 3: Platform Analytics
        # ====================================================================

        logger.info("Creating platform_analytics table...")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS platform_analytics (
                platform TEXT PRIMARY KEY,             -- 'vinted_de', 'ebay_de', etc.

                -- Product Stats
                total_products INTEGER DEFAULT 0,
                active_products INTEGER DEFAULT 0,
                sold_products INTEGER DEFAULT 0,

                -- Engagement Stats
                total_views INTEGER DEFAULT 0,
                total_messages INTEGER DEFAULT 0,
                total_favorites INTEGER DEFAULT 0,

                -- Averages
                avg_views_per_product REAL DEFAULT 0.0,
                avg_messages_per_product REAL DEFAULT 0.0,
                avg_price REAL DEFAULT 0.0,

                -- Conversion Metrics
                conversion_rate REAL DEFAULT 0.0,      -- Sales / Total products
                message_rate REAL DEFAULT 0.0,         -- Messages / Products
                favorite_rate REAL DEFAULT 0.0,        -- Favorites / Products

                -- Time Metrics
                avg_days_to_sale REAL DEFAULT 0.0,
                avg_days_to_first_message REAL DEFAULT 0.0,

                -- Platform Performance Score (0-100)
                performance_score REAL DEFAULT 50.0,
                performance_grade TEXT DEFAULT 'C',

                -- Timestamps
                last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # Index for platform_analytics
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_platform_score ON platform_analytics(performance_score DESC)")

        tables_created += 1
        logger.success("  platform_analytics table created")

        # ====================================================================
        # TABLE 4: Negotiation Sessions
        # ====================================================================

        logger.info("Creating negotiation_sessions table...")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS negotiation_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                -- Links
                conversation_id INTEGER,               -- From existing conversations table
                product_id INTEGER NOT NULL,
                seller_id TEXT,

                -- Price Negotiation
                initial_price REAL,
                current_offer REAL,
                final_price REAL,                      -- If accepted
                price_drop_percent REAL,               -- Discount percentage

                -- Negotiation Dynamics
                counter_offers INTEGER DEFAULT 0,      -- Number of counter-offers
                buyer_offers INTEGER DEFAULT 0,        -- Offers from buyer
                seller_offers INTEGER DEFAULT 0,       -- Offers from seller

                -- Scores
                negotiation_score REAL DEFAULT 50.0,   -- Potential score 0-100
                buyer_enthusiasm_score REAL,           -- How interested buyer seems
                deal_likelihood REAL,                  -- Probability of closing (0-1)

                -- Status
                status TEXT DEFAULT 'active',          -- 'active', 'accepted', 'rejected', 'stalled', 'expired'

                -- Timestamps
                started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_offer_at DATETIME,
                closed_at DATETIME,

                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
            );
        """)

        # Indexes for negotiation_sessions
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_nego_product ON negotiation_sessions(product_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_nego_status ON negotiation_sessions(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_nego_score ON negotiation_sessions(negotiation_score DESC)")

        tables_created += 1
        logger.success("  negotiation_sessions table created")

        # ====================================================================
        # TABLE 5: Recommendation Log
        # ====================================================================

        logger.info("Creating recommendation_log table...")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS recommendation_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                -- Target Entity
                entity_type TEXT NOT NULL,             -- 'product', 'conversation', 'platform'
                entity_id INTEGER NOT NULL,

                -- Recommendation
                recommendation_type TEXT NOT NULL,     -- 'price_adjust', 'response_template', 'repost', etc.
                recommendation_text TEXT NOT NULL,
                recommendation_details TEXT,           -- JSON with detailed info

                -- Confidence and Priority
                confidence_score REAL DEFAULT 0.5,     -- 0-1
                priority TEXT DEFAULT 'medium',        -- 'low', 'medium', 'high', 'urgent'

                -- Action Tracking
                action_taken BOOLEAN DEFAULT 0,
                action_taken_at DATETIME,
                action_result TEXT,                    -- 'success', 'failed', 'ignored'

                -- Timestamps
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                expires_at DATETIME                    -- Recommendation expiration
            );
        """)

        # Indexes for recommendation_log
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_reco_entity ON recommendation_log(entity_type, entity_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_reco_type ON recommendation_log(recommendation_type)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_reco_priority ON recommendation_log(priority)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_reco_action ON recommendation_log(action_taken, created_at)")

        tables_created += 1
        logger.success("  recommendation_log table created")

        # ====================================================================
        # TABLE 6: Score History (for trend tracking)
        # ====================================================================

        logger.info("Creating score_history table...")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS score_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                -- Target Entity
                entity_type TEXT NOT NULL,             -- 'product', 'seller', 'platform'
                entity_id TEXT NOT NULL,               -- Can be INT or TEXT

                -- Score Data
                score_type TEXT NOT NULL,              -- 'performance', 'risk', 'negotiation', etc.
                score_value REAL NOT NULL,
                score_grade TEXT,                      -- 'A', 'B', 'C', 'D', 'F'

                -- Context
                score_components TEXT,                 -- JSON with component breakdown
                trigger_event TEXT,                    -- What caused the score update

                -- Timestamp
                recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # Indexes for score_history
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_history_entity ON score_history(entity_type, entity_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_history_time ON score_history(recorded_at DESC)")

        tables_created += 1
        logger.success("  score_history table created")

        # Commit all changes
        conn.commit()

        # Get summary
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name LIKE '%performance%' OR name LIKE '%negotiation%' OR name LIKE '%recommendation%' OR name LIKE '%score_history%' OR name = 'platform_analytics'
            ORDER BY name
        """)

        tables = cursor.fetchall()

        logger.log_table(
            title="LiveScore Tables Created",
            headers=["#", "Table Name"],
            rows=[[i+1, name] for i, (name,) in enumerate(tables)]
        )

        logger.success(f"Migration completed! Created {tables_created} tables.")

        conn.close()

        logger.end_run(success=True, message=f"{tables_created} LiveScore tables ready")
        return True

    except Exception as e:
        logger.error(f"Migration failed: {str(e)}", error=str(e))
        logger.end_run(success=False, message=str(e))
        return False


def rollback_migration(db_path: str = None):
    """
    Rollback: Drop all LiveScore tables

    WARNING: This will delete ALL scoring and analytics data!

    Args:
        db_path: Path to tatanga.db
    """
    if db_path is None:
        db_path = Path(__file__).parent.parent / "tatanga.db"

    logger.warning("ROLLBACK: Dropping LiveScore tables...")
    logger.warning("This will DELETE ALL SCORING DATA!")

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        tables = [
            'score_history',
            'recommendation_log',
            'negotiation_sessions',
            'platform_analytics',
            'seller_performance',
            'product_performance'
        ]

        for table in tables:
            cursor.execute(f"DROP TABLE IF EXISTS {table}")
            logger.info(f"Dropped table: {table}")

        conn.commit()
        conn.close()

        logger.success("All LiveScore tables dropped successfully")
        return True

    except Exception as e:
        logger.error(f"Rollback failed: {str(e)}")
        return False


def verify_migration(db_path: str = None):
    """
    Verify all LiveScore tables exist

    Args:
        db_path: Path to tatanga.db

    Returns:
        True if all tables exist
    """
    if db_path is None:
        db_path = Path(__file__).parent.parent / "tatanga.db"

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        required_tables = [
            'product_performance',
            'seller_performance',
            'platform_analytics',
            'negotiation_sessions',
            'recommendation_log',
            'score_history'
        ]

        missing_tables = []

        for table in required_tables:
            cursor.execute(f"""
                SELECT name FROM sqlite_master
                WHERE type='table' AND name='{table}'
            """)

            if not cursor.fetchone():
                missing_tables.append(table)

        if missing_tables:
            logger.error(f"Missing tables: {missing_tables}")
            return False

        logger.success("All LiveScore tables verified")
        conn.close()
        return True

    except Exception as e:
        logger.error(f"Verification failed: {str(e)}")
        return False


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

if __name__ == '__main__':
    print("=" * 70)
    print("TATANGA - Migration 002: Create LiveScore Tables")
    print("=" * 70)

    import argparse

    parser = argparse.ArgumentParser(description='LiveScore tables migration')
    parser.add_argument('action', choices=['migrate', 'rollback', 'verify'],
                        help='Action to perform')
    parser.add_argument('--db', type=str, default=None,
                        help='Path to database file')

    args = parser.parse_args()

    if args.action == 'migrate':
        success = run_migration(args.db)
        sys.exit(0 if success else 1)

    elif args.action == 'rollback':
        confirm = input("Are you SURE you want to drop all LiveScore tables? (yes/no): ")
        if confirm.lower() == 'yes':
            success = rollback_migration(args.db)
            sys.exit(0 if success else 1)
        else:
            print("Rollback cancelled")
            sys.exit(0)

    elif args.action == 'verify':
        success = verify_migration(args.db)
        sys.exit(0 if success else 1)
