"""
TATANGA V3 - Kleinanzeigen Human Scraper
İnsan-benzeri davranışlarla Kleinanzeigen'den ürün kazıma

Özellikler:
- Cookie banner kapatma
- Login popup kapatma
- İnsansı arama (typo + düzeltme)
- Sayfa numaralarına tıklama ile navigasyon
- Rastgele ürün ziyareti
"""
from human_scraper_base import HumanScraper, LOG_DIR
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
from typing import List, Dict, Optional
import time
import random
import re
import urllib.parse


class KleinanzeigenScraper(HumanScraper):
    """Kleinanzeigen için insan-benzeri scraper"""

    BASE_URL = "https://www.kleinanzeigen.de"

    # Sıralama seçenekleri
    SORT_OPTIONS = {
        "newest": "SORTING_DATE",
        "price_asc": "PRICE_ASC",
        "price_desc": "PRICE_DESC",
    }

    # Almanca durum isimleri (Kleinanzeigen URL'de durum filtresi desteklemiyor)
    # Ama API tutarlılığı için parametre kabul edilir
    CONDITION_MAPPING = {
        "neu": "neu",
        "sehr_gut": "sehr_gut",
        "sehr gut": "sehr_gut",
        "gut": "gut",
        "akzeptabel": "akzeptabel",
    }

    def translate_condition(self, condition: str) -> str:
        """Durum değerini standart forma çevir"""
        if not condition:
            return None
        condition_lower = condition.lower().replace(" ", "_")
        return self.CONDITION_MAPPING.get(condition_lower, condition_lower)

    def __init__(self, headless: bool = True):
        super().__init__("kleinanzeigen", headless)
        self.products_found = []
        self.visited_urls = set()
        self.current_page = 1

    def build_search_url(self, query: str, page: int = 1,
                         min_price: float = None, max_price: float = None,
                         sort: str = None) -> str:
        """
        Kleinanzeigen arama URL'si oluştur
        """
        # Kleinanzeigen URL yapısı: /s-seite:2/nike/k0
        base_path = f"/s-preis:{int(min_price) if min_price else ''}:{int(max_price) if max_price else ''}" if min_price or max_price else "/s"

        if page > 1:
            base_path += f"-seite:{page}"

        base_path += f"/{urllib.parse.quote(query)}/k0"

        url = f"{self.BASE_URL}{base_path}"

        if sort and sort in self.SORT_OPTIONS:
            url += f"?sortingField={self.SORT_OPTIONS[sort]}"

        return url

    def go_to_homepage(self):
        """Kleinanzeigen ana sayfasına git"""
        self.log("Kleinanzeigen ana sayfasına gidiliyor...")
        self.visit_url(self.BASE_URL)
        self.screenshot("homepage")
        self.random_delay(1, 2)

        # Cookie banner'ı kapat
        self.close_cookie_banner()
        self.random_delay(0.5, 1)

        # Login popup'ı kapat
        self.close_login_popup()

    def close_cookie_banner(self, selectors: list = None):
        """Kleinanzeigen cookie banner'ı kapat"""
        ka_selectors = [
            "#gdpr-banner-accept",
            "[data-testid='gdpr-banner-accept']",
            "button[id*='accept']",
            "#consentBanner button",
            "#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll",
            ".gdpr-banner-accept",
            "[data-testid='cookie-consent-banner-accept']",
        ]
        super().close_cookie_banner(ka_selectors + (selectors or []))

    def close_login_popup(self):
        """
        Login popup'ını kapat
        Kleinanzeigen sağ üstte "Einloggen" popup'ı gösteriyor
        """
        self.log("Login popup kontrol ediliyor...")

        popup_close_selectors = [
            # Modal kapatma butonları
            "[data-testid='modal-close']",
            "[data-testid='close-button']",
            "[aria-label='Schließen']",
            "[aria-label='Dialog schließen']",
            "button[aria-label='close']",

            # Login overlay
            ".login-layer-close",
            ".mfp-close",
            ".modal-close",

            # Generic close butonları
            "[class*='CloseButton']",
            "[class*='close-button']",
            "button[class*='close']",

            # SVG close ikonları
            "button svg[class*='close']",
            "[class*='modal'] button[class*='close']",

            # Backdrop tıklama (popup dışına tıkla)
            ".mfp-bg",
            ".modal-backdrop",
        ]

        for selector in popup_close_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for element in elements:
                    if element.is_displayed():
                        self.log(f"Login popup kapatılıyor: {selector}")
                        try:
                            self.human_click(element)
                            self.random_delay(0.5, 1)
                            self.screenshot("login_popup_closed")
                            return True
                        except:
                            pass
            except:
                pass

        # ESC tuşu ile kapat
        try:
            from selenium.webdriver.common.action_chains import ActionChains
            ActionChains(self.driver).send_keys(Keys.ESCAPE).perform()
            self.random_delay(0.3, 0.5)
        except:
            pass

        self.log("Login popup bulunamadı veya zaten kapalı")
        return False

    def find_search_bar(self):
        """Arama kutusunu bul"""
        search_selectors = [
            "input#site-search-query",
            "input[name='keywords']",
            "input[id='site-search-query']",
            "input[placeholder*='suche']",
            "input[placeholder*='Suche']",
            "input[placeholder*='Was suchst']",
            ".site-search input",
            "#site-search input",
            "input[type='search']",
            "input[class*='search']",
        ]

        for selector in search_selectors:
            try:
                element = self.driver.find_element(By.CSS_SELECTOR, selector)
                if element.is_displayed():
                    self.log(f"Arama kutusu bulundu: {selector}")
                    return element
            except:
                pass

        self.log("Arama kutusu bulunamadı!", "error")
        self.screenshot("search_bar_not_found")
        return None

    def search(self, query: str) -> bool:
        """
        İnsansı arama yap - typo yapıp düzeltme ile
        """
        self.log(f"Arama yapılıyor: '{query}'")

        search_bar = self.find_search_bar()
        if not search_bar:
            return False

        # Arama kutusuna scroll yap (görünür olsun)
        self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", search_bar)
        self.random_delay(0.3, 0.5)

        # Arama kutusuna tıkla
        self.human_click(search_bar)
        self.random_delay(0.3, 0.7)

        # Temizle (varsa eski arama)
        search_bar.clear()
        self.random_delay(0.2, 0.4)

        # İnsan gibi yaz (typo ile)
        self.human_type(search_bar, query, make_mistakes=True)
        self.screenshot("search_typed")

        # Enter'a basmadan önce biraz bekle (düşünüyor gibi)
        self.random_delay(0.5, 1.0)
        search_bar.send_keys(Keys.ENTER)

        self.log("Arama gönderildi, sonuçlar bekleniyor...")
        self.random_delay(3, 5)

        # Popup kontrolü (arama sonrası da çıkabilir)
        self.close_login_popup()

        self.screenshot("search_results")
        self.current_page = 1

        return True

    def go_to_next_page(self) -> bool:
        """
        Sonraki sayfaya git - sayfa numaralarına tıklayarak
        """
        self.log(f"Sonraki sayfaya geçiliyor (mevcut: {self.current_page})...")

        next_page = self.current_page + 1

        # Önce pagination alanına scroll
        try:
            pagination = self.driver.find_element(By.CSS_SELECTOR, ".pagination-pages, nav[aria-label='pagination']")
            self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", pagination)
            self.random_delay(0.5, 1)
        except:
            # Sayfanın altına scroll
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            self.random_delay(0.5, 1)

        # Sonraki sayfa seçicileri
        next_page_selectors = [
            # Doğrudan sayfa numarası
            f"a[href*='seite:{next_page}']",
            f".pagination-pages a[href*='seite:{next_page}']",

            # Next butonu
            "a.pagination-next",
            "[data-testid='pagination-next']",
            "a[rel='next']",
            ".pagination-item--next a",
            "a[aria-label='Nächste Seite']",
            "[class*='pagination'] a[class*='next']",

            # SVG ok ile
            ".pagination a svg[class*='right']",
        ]

        for selector in next_page_selectors:
            try:
                element = self.driver.find_element(By.CSS_SELECTOR, selector)
                if element.is_displayed():
                    self.log(f"Sonraki sayfa butonu bulundu: {selector}")

                    # Zigzag mouse hareketi (insansı)
                    self.mouse_zigzag(element)

                    # Tıkla
                    self.human_click(element)
                    self.random_delay(2, 4)

                    # Popup kontrolü
                    self.close_login_popup()

                    self.current_page = next_page
                    self.screenshot(f"page_{next_page}")
                    self.log(f"Sayfa {next_page}'e geçildi")

                    return True
            except:
                pass

        self.log("Sonraki sayfa bulunamadı - muhtemelen son sayfa")
        return False

    def get_product_elements(self) -> list:
        """Sayfadaki ürün elementlerini al"""
        selectors = [
            "article.aditem",
            "[data-testid='aditem']",
            ".ad-listitem article",
            "li.ad-listitem",
        ]

        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    self.log(f"{len(elements)} ürün elementi bulundu ({selector})")
                    return elements
            except:
                pass

        return []

    def extract_product_data(self, element) -> Optional[Dict]:
        """Ürün elementinden veri çıkar"""
        try:
            # URL
            link = element.find_element(By.CSS_SELECTOR, "a[href*='/s-anzeige/']")
            url = link.get_attribute("href")

            if not url:
                return None

            # Zaten gördük mü?
            if url in self.visited_urls:
                return None
            self.visited_urls.add(url)

            # Başlık
            title = None
            title_selectors = [
                "h2 a",
                ".aditem-main--middle--title",
                "[data-testid='ad-title']",
                ".text-module-begin a",
            ]
            for sel in title_selectors:
                try:
                    title_elem = element.find_element(By.CSS_SELECTOR, sel)
                    title = title_elem.text.strip()
                    if title:
                        break
                except:
                    pass

            if not title:
                return None

            # Fiyat
            price = None
            price_selectors = [
                ".aditem-main--middle--price-shipping--price",
                "[data-testid='price']",
                ".aditem-details strong",
            ]
            for sel in price_selectors:
                try:
                    price_elem = element.find_element(By.CSS_SELECTOR, sel)
                    price_text = price_elem.text
                    # "15 € VB" veya "15,00 €"
                    price_match = re.search(r"([\d.,]+)\s*€", price_text)
                    if price_match:
                        price = float(price_match.group(1).replace(".", "").replace(",", "."))
                        break
                except:
                    pass

            # Resim
            image_url = None
            try:
                img = element.find_element(By.CSS_SELECTOR, "img")
                image_url = img.get_attribute("src") or img.get_attribute("data-src")
            except:
                pass

            # Konum
            location = None
            try:
                loc_elem = element.find_element(By.CSS_SELECTOR, ".aditem-main--top--left")
                location = loc_elem.text.strip()
            except:
                pass

            # Tarih
            posted_date = None
            try:
                date_elem = element.find_element(By.CSS_SELECTOR, ".aditem-main--top--right")
                posted_date = date_elem.text.strip()
            except:
                pass

            return {
                "url": url,
                "title": title,
                "price": price,
                "location": location,
                "posted_date": posted_date,
                "image": image_url,
                "platform": "kleinanzeigen",
                "scraped_at": datetime.now().isoformat()
            }

        except Exception as e:
            self.log(f"Ürün verisi çıkarma hatası: {e}", "debug")
            return None

    def extract_all_products(self) -> List[Dict]:
        """Sayfadaki tüm ürünleri çıkar"""
        elements = self.get_product_elements()
        products = []

        for element in elements:
            product = self.extract_product_data(element)
            if product and product["url"] not in [p["url"] for p in self.products_found]:
                products.append(product)
                self.products_found.append(product)

        self.log(f"{len(products)} yeni ürün çıkarıldı (Toplam: {len(self.products_found)})")
        return products

    def visit_random_product(self, visit_seller: bool = True) -> Optional[Dict]:
        """
        Rastgele bir ürüne git ve satıcı profilini ziyaret et
        İnsansı davranış: Ürün → Scroll → Satıcı Profili → Scroll → Geri → Geri
        """
        elements = self.get_product_elements()
        if not elements:
            self.log("Ürün elementi bulunamadı")
            return None

        # Rastgele bir ürün seç (ilk 10'dan)
        random_elements = random.sample(elements[:min(10, len(elements))], 1)
        element = random_elements[0]

        product_data = self.extract_product_data(element)
        if not product_data:
            return None

        self.log(f"=== RASTGELE ÜRÜN ZİYARETİ ===")
        self.log(f"Ürün: {product_data['title'][:50]}...")

        # Elemana mouse zigzag hareketi
        self.mouse_zigzag(element)
        self.random_delay(0.3, 0.6)

        # Ürün sayfasına git
        self.visit_url(product_data["url"])
        self.random_delay(2, 4)
        self.screenshot("product_page")

        # Sayfayı incele gibi scroll yap
        self.human_scroll("down", random.randint(200, 400))
        self.random_delay(1, 2)

        # Biraz daha scroll
        self.human_scroll("down", random.randint(100, 300))
        self.random_delay(0.5, 1.5)

        # Satıcı profiline git
        if visit_seller:
            self._visit_seller_profile()

        # Ürün sayfasına geri dön (satıcı profilinden)
        self.random_delay(1, 2)

        # Arama sonuçlarına geri dön
        self.go_back()
        self.random_delay(1, 2)

        # Popup kontrolü
        self.close_login_popup()

        self.log(f"=== RASTGELE ZİYARET TAMAMLANDI ===")
        return product_data

    def _visit_seller_profile(self) -> bool:
        """
        Satıcı profilini ziyaret et
        """
        seller_selectors = [
            # Kleinanzeigen satıcı linkleri
            "a[href*='/s-bestandsliste.html']",
            "a[href*='/pro/']",
            ".userprofile-vip a",
            "[data-testid='seller-link']",
            "[data-testid='user-info'] a",
            ".user-profile-link",
            "a[class*='seller']",
            "a[class*='user']",
            # Generic
            "[class*='sellerInfo'] a",
            "[class*='SellerInfo'] a",
        ]

        for selector in seller_selectors:
            try:
                links = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for link in links:
                    if link.is_displayed():
                        href = link.get_attribute("href") or ""
                        # Geçerli bir satıcı linki mi?
                        if any(x in href for x in ['/s-bestandsliste', '/pro/', 'anbieter', 'nutzer']):
                            self.log(f"Satıcı profiline gidiliyor: {href[:50]}...")

                            # Zigzag mouse
                            self.mouse_zigzag(link)

                            # Tıkla
                            self.human_click(link)
                            self.random_delay(2, 4)
                            self.screenshot("seller_profile")

                            # Profilde scroll yap (diğer ürünlere bak gibi)
                            self.human_scroll("down", random.randint(300, 500))
                            self.random_delay(1, 3)

                            # Biraz daha scroll
                            if random.random() < 0.5:
                                self.human_scroll("down", random.randint(200, 400))
                                self.random_delay(0.5, 1.5)

                            # Geri dön (ürün sayfasına)
                            self.go_back()
                            self.random_delay(1, 2)

                            self.log("Satıcı profili ziyareti tamamlandı")
                            return True
            except Exception as e:
                self.log(f"Satıcı linki denemesi başarısız: {e}", "debug")
                continue

        self.log("Satıcı profili bulunamadı", "debug")
        return False

    def scrape(self, query: str, max_products: int = None, max_pages: int = None,
               visit_products: bool = True, min_price: float = None,
               max_price: float = None, sort: str = "newest",
               use_search_bar: bool = True, condition: str = None,
               conditions: list = None) -> List[Dict]:
        """
        Ana kazıma fonksiyonu - İnsansı davranışlarla

        Args:
            query: Arama kelimesi
            max_products: Maksimum ürün sayısı
            max_pages: Maksimum sayfa sayısı
            visit_products: Rastgele ürünlere git
            min_price: Minimum fiyat filtresi
            max_price: Maximum fiyat filtresi
            sort: Sıralama (newest, price_asc, price_desc)
            use_search_bar: True = arama kutusunu kullan, False = direkt URL
            condition: Durum filtresi (sehr gut, gut, etc.) - Kleinanzeigen URL desteklemez ama log edilir
            conditions: Çoklu durum listesi
        """
        self.log(f"=== KAZIMA BAŞLIYOR ===")
        self.log(f"Arama: {query}")
        self.log(f"Max ürün: {max_products or 'Sınırsız'}")
        self.log(f"Max sayfa: {max_pages or 'Sınırsız'}")
        self.log(f"Arama kutusu: {'Evet' if use_search_bar else 'Hayır'}")
        if condition:
            self.log(f"Durum filtresi: {condition} (Not: Kleinanzeigen URL'de desteklenmiyor)")
        if conditions:
            self.log(f"Durum filtreleri: {conditions} (Not: Kleinanzeigen URL'de desteklenmiyor)")

        try:
            if use_search_bar:
                # === İNSANSI YOL: Ana sayfa → Arama kutusu → Sonuçlar ===
                self.go_to_homepage()

                # Arama yap
                if not self.search(query):
                    self.log("Arama başarısız, URL yöntemine geçiliyor...")
                    use_search_bar = False

            if not use_search_bar:
                # === DOĞRUDAN URL YÖNTEMİ ===
                url = self.build_search_url(
                    query=query,
                    page=1,
                    min_price=min_price,
                    max_price=max_price,
                    sort=sort
                )
                self.log(f"Doğrudan URL: {url}")
                self.visit_url(url)
                self.close_cookie_banner()
                self.close_login_popup()
                self.current_page = 1

            # === İLK SAYFA: HER ZAMAN BİR ÜRÜN VE SATICI PROFİLİ ZİYARET ET ===
            self.log("=== İLK SAYFA RASTGELE GEZİNME ===")

            # İlk sayfada ürünleri çıkarmadan önce scroll
            self.human_scroll("down", random.randint(300, 500))
            self.random_delay(1, 2)

            # İlk sayfada HER ZAMAN bir ürüne git ve satıcı profiline tıkla
            self.log("İlk sayfa: Rastgele ürün ve satıcı profili ziyareti...")
            self.visit_random_product(visit_seller=True)

            # Sayfa döngüsü
            while True:
                self.log(f"--- Sayfa {self.current_page} ---")

                # Sayfayı yukarıdan aşağıya scroll (insansı)
                self.human_scroll("down", random.randint(300, 500))
                self.random_delay(1, 2)

                # Zigzag mouse hareketi (bot olmadığımızı göster)
                if random.random() < 0.3:
                    try:
                        elements = self.get_product_elements()
                        if elements:
                            random_elem = random.choice(elements[:5])
                            self.mouse_zigzag(random_elem)
                    except:
                        pass

                # Ürünleri çıkar
                before_count = len(self.products_found)
                self.extract_all_products()
                after_count = len(self.products_found)
                new_products = after_count - before_count

                self.log(f"+{new_products} yeni ürün (Toplam: {after_count})")

                # Limit kontrolü
                if max_products and len(self.products_found) >= max_products:
                    self.log(f"Maksimum ürün sayısına ulaşıldı: {max_products}")
                    break

                if max_pages and self.current_page >= max_pages:
                    self.log(f"Maksimum sayfa sayısına ulaşıldı: {max_pages}")
                    break

                # Boş sayfa kontrolü
                if new_products == 0:
                    self.log("Boş sayfa, kazıma durduruluyor...")
                    break

                # Sonraki sayfalarda rastgele ürün ziyareti (%30 ihtimalle)
                # (İlk sayfa zaten ziyaret edildi)
                if visit_products and self.current_page > 1 and random.random() < 0.3:
                    self.visit_random_product(visit_seller=True)

                # İnsansı bekleme
                self.random_delay(2, 4)

                # Sonraki sayfaya git (tıklayarak)
                if not self.go_to_next_page():
                    self.log("Sonraki sayfaya geçilemedi, kazıma durduruluyor...")
                    break

            self.log(f"=== KAZIMA TAMAMLANDI ===")
            self.log(f"Toplam ürün: {len(self.products_found)}")
            self.log(f"Toplam sayfa: {self.current_page}")
            self.screenshot("scraping_complete")

            return self.products_found

        except Exception as e:
            self.log(f"Kazıma hatası: {e}", "error")
            self.screenshot("error")
            raise


def run_kleinanzeigen_scrape(query: str, max_products: int = None, headless: bool = True) -> List[Dict]:
    """Kleinanzeigen kazıma işlemini çalıştır"""
    with KleinanzeigenScraper(headless=headless) as scraper:
        return scraper.scrape(query, max_products=max_products)


if __name__ == "__main__":
    import sys

    query = sys.argv[1] if len(sys.argv) > 1 else "nike"
    max_items = int(sys.argv[2]) if len(sys.argv) > 2 else 50

    print(f"Kleinanzeigen kazıma başlıyor: {query}")
    products = run_kleinanzeigen_scrape(query, max_products=max_items, headless=True)

    print(f"\n{len(products)} ürün bulundu:")
    for p in products[:5]:
        print(f"  - {p['title'][:40]} | {p['price']} EUR | {p['url']}")
