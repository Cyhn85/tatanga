"""
TATANGA V3 - Sellpy Human Scraper
Insan-benzeri davranislarla Sellpy'den urun kazima
Acik artirma yok - sadece sabit fiyat
FIXED: Fiyat ve condition cikarma iyilestirildi
"""
from .human_scraper_base import HumanScraper, LOG_DIR
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
from typing import List, Dict, Optional
import time
import random
import re


class SellpyScraper(HumanScraper):
    """Sellpy icin insan-benzeri scraper"""

    BASE_URL = "https://www.sellpy.de"

    # Metadata alanlari
    METADATA_FIELDS = {
        "brand": "Marke",
        "type": "Art",
        "size": "Groesse",
        "color": "Farbe",
        "material": "Material",
        "pattern": "Muster",
        "fabric": "Stoff",
        "condition": "Zustand",
    }

    # Condition mapping
    CONDITION_MAPPING = {
        "sehr gut": "Sehr gut",
        "gut": "Gut",
        "guter zustand": "Gut",
        "sehr guter zustand": "Sehr gut",
        "neuwertig": "Wie neu",
        "neu mit etikett": "Neu mit Etikett",
        "akzeptabel": "Akzeptabel",
    }

    def __init__(self, headless: bool = True):
        super().__init__("sellpy", headless)
        self.products_found = []
        self.visited_urls = set()

    def close_cookie_banner(self, selectors: list = None):
        """Sellpy cookie banner'i kapat"""
        sellpy_selectors = [
            "//button[contains(text(), 'Alle Cookies akzeptieren')]",
            "//button[contains(text(), 'Alle akzeptieren')]",
            "button[data-testid='accept-cookies']",
            "#onetrust-accept-btn-handler",
            "button[id*='accept']",
            ".cookie-banner button[class*='accept']",
            "[class*='CookieConsent'] button",
        ]
        return super().close_cookie_banner(sellpy_selectors + (selectors or []))

    def close_size_popup(self):
        """Size filter popup kapat"""
        popup_selectors = [
            "//button[contains(@class, 'close')]",
            "[data-testid='dismiss-size-filter']",
            "button[aria-label='Close']",
            ".modal-close",
            ".popup-close",
            "//button[@aria-label='Schliessen']",
        ]

        for selector in popup_selectors:
            try:
                if selector.startswith('//'):
                    btn = self.driver.find_element(By.XPATH, selector)
                else:
                    btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.log(f"Size popup kapatiliyor: {selector}")
                    self.human_click(btn)
                    self.random_delay(0.5, 1)
                    return True
            except:
                pass
        return False

    def go_to_homepage(self):
        """Sellpy ana sayfasina git"""
        self.log("Sellpy ana sayfasina gidiliyor...")
        self.visit_url(self.BASE_URL)
        self.screenshot("homepage")

        self.random_delay(1, 2)
        self.close_cookie_banner()

    def search(self, query: str):
        """Arama yap"""
        self.log(f"Arama yapiliyor: '{query}'")

        # Search URL ile direkt git
        search_url = f"{self.BASE_URL}/search?q={query.replace(' ', '%20')}"
        self.visit_url(search_url)

        self.random_delay(2, 3)
        self.close_cookie_banner()
        self.close_size_popup()

        self.screenshot("search_results")
        return True

    def build_search_url(self, query: str, page: int = 1,
                         min_price: float = None, max_price: float = None,
                         category: str = None, condition: str = None) -> str:
        """Sellpy arama URL'si olustur"""
        import urllib.parse

        params = {"q": query}

        if page > 1:
            params["page"] = page
        if min_price is not None:
            params["minPrice"] = int(min_price)
        if max_price is not None:
            params["maxPrice"] = int(max_price)
        if category:
            params["category"] = category
        if condition:
            params["condition"] = condition

        query_string = urllib.parse.urlencode(params)
        return f"{self.BASE_URL}/search?{query_string}"

    def get_product_elements(self) -> list:
        """Sayfadaki urun elementlerini al"""
        selectors = [
            "[data-testid='product-card']",
            ".product-card",
            "article[class*='Product']",
            ".item-card",
            "a[href*='/item/']",
        ]

        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    self.log(f"{len(elements)} urun elementi bulundu ({selector})")
                    return elements
            except:
                pass

        return []

    def extract_price_from_text(self, text: str) -> Optional[float]:
        """Metin icinden fiyat cikar - iyilestirilmis regex"""
        if not text:
            return None

        # Temizle
        text = text.strip()

        # Pattern listesi - en ozelden genele
        patterns = [
            r'(\d+[,.]\d{2})\s*EUR',  # 12,99 EUR
            r'EUR\s*(\d+[,.]\d{2})',  # EUR 12,99
            r'(\d+[,.]\d{2})\s*\u20ac',    # 12,99 euro sign
            r'\u20ac\s*(\d+[,.]\d{2})',    # euro sign 12,99
            r'(\d+)\s*EUR',            # 12 EUR
            r'EUR\s*(\d+)',            # EUR 12
            r'(\d+)\s*\u20ac',              # 12 euro sign
            r'\u20ac\s*(\d+)',              # euro sign 12
            r'(\d+[,.]\d{2})',         # 12,99 (no currency)
            r'(\d+)',                   # 12 (just number)
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                price_str = match.group(1)
                try:
                    # Normalize: 12.345,99 -> 12345.99
                    if ',' in price_str and '.' in price_str:
                        # 12.345,99 formatinda
                        price_str = price_str.replace('.', '').replace(',', '.')
                    elif ',' in price_str:
                        # 12,99 formatinda
                        price_str = price_str.replace(',', '.')

                    price = float(price_str)
                    if 0.01 <= price <= 10000:  # Makul fiyat araligi
                        return price
                except ValueError:
                    continue

        return None

    def extract_product_data(self, element) -> Optional[Dict]:
        """Urun elementinden veri cikar - IYILESTIRILMIS"""
        try:
            # URL
            url = None
            try:
                link = element.find_element(By.CSS_SELECTOR, "a[href*='/item/']")
                url = link.get_attribute("href")
            except:
                try:
                    url = element.get_attribute("href")
                except:
                    pass

            if not url:
                self.log("URL bulunamadi", "debug")
                return None

            # Product ID
            product_id = None
            match = re.search(r'/item/([a-zA-Z0-9-]+)', url)
            if match:
                product_id = match.group(1)

            if not product_id:
                self.log("Product ID bulunamadi", "debug")
                return None

            # Title - daha fazla selector
            title = ""
            title_selectors = [
                "h3", "h2", "h4",
                ".item-title",
                "[class*='title']",
                "[class*='Title']",
                "[class*='name']",
                "[class*='Name']",
                "img[alt]"
            ]
            for sel in title_selectors:
                try:
                    title_el = element.find_element(By.CSS_SELECTOR, sel)
                    if sel == "img[alt]":
                        title = title_el.get_attribute("alt") or ""
                    else:
                        title = title_el.text.strip()
                    if title and len(title) > 3:
                        break
                except:
                    pass

            # PRICE - IYILESTIRILMIS CIKARMA
            price = None
            price_selectors = [
                "[data-testid='product-price']",
                "[data-testid='price']",
                "[class*='price']",
                "[class*='Price']",
                ".price",
                "span[class*='price']",
                "div[class*='price']",
                "p[class*='price']",
            ]

            for sel in price_selectors:
                try:
                    price_elements = element.find_elements(By.CSS_SELECTOR, sel)
                    for price_el in price_elements:
                        price_text = price_el.text.strip()
                        if price_text:
                            extracted = self.extract_price_from_text(price_text)
                            if extracted is not None:
                                price = extracted
                                self.log(f"Fiyat bulundu: {price} EUR ('{price_text}' icinden)", "debug")
                                break
                    if price is not None:
                        break
                except Exception as e:
                    self.log(f"Fiyat cikarma hatasi ({sel}): {e}", "debug")

            # Son caba: tum element textinden fiyat ara
            if price is None:
                try:
                    full_text = element.text
                    price = self.extract_price_from_text(full_text)
                    if price:
                        self.log(f"Fiyat full text'ten bulundu: {price} EUR", "debug")
                except:
                    pass

            if price is None:
                self.log(f"UYARI: Fiyat cikarilmadi - {url}", "warning")

            # Image
            image_url = None
            try:
                img = element.find_element(By.CSS_SELECTOR, "img")
                image_url = img.get_attribute("src") or img.get_attribute("data-src")
            except:
                pass

            # Brand (from title or metadata)
            brand = None
            if title:
                known_brands = ["Nike", "Adidas", "Puma", "Tommy Hilfiger", "H&M", "Zara",
                               "Calvin Klein", "Ralph Lauren", "Levis", "Guess", "Hugo Boss",
                               "Tommy", "Hilfiger", "Lacoste", "Gant", "Esprit"]
                for b in known_brands:
                    if b.lower() in title.lower():
                        brand = b
                        break

            # Condition from element
            condition = None
            condition_selectors = [
                "[class*='condition']",
                "[class*='Condition']",
                "[data-testid='condition']",
            ]
            for sel in condition_selectors:
                try:
                    cond_el = element.find_element(By.CSS_SELECTOR, sel)
                    cond_text = cond_el.text.strip().lower()
                    for key, value in self.CONDITION_MAPPING.items():
                        if key in cond_text:
                            condition = value
                            break
                    if condition:
                        break
                except:
                    pass

            return {
                "product_id": product_id,
                "url": url,
                "title": title,
                "price": price,
                "brand": brand,
                "condition": condition,
                "image": image_url,
                "platform": "sellpy",
                "is_auction": False,
                "scraped_at": datetime.now().isoformat()
            }

        except Exception as e:
            self.log(f"Urun verisi cikarma hatasi: {e}", "error")
            return None

    def extract_product_details(self, url: str) -> Optional[Dict]:
        """Urun detay sayfasindan ek bilgi cikar"""
        try:
            self.visit_url(url)
            self.random_delay(2, 3)

            details = {}

            # Fiyat detay sayfasindan
            price = None
            try:
                # Detay sayfasinda fiyat genelde daha net
                price_el = self.driver.find_element(By.CSS_SELECTOR, "[class*='price'], [data-testid*='price']")
                price = self.extract_price_from_text(price_el.text)
                if price:
                    details["price"] = price
                    self.log(f"Detay fiyat: {price} EUR")
            except:
                pass

            # Metadata alanlarini ara
            for field, german_label in self.METADATA_FIELDS.items():
                try:
                    xpath = f"//dt[contains(text(), '{german_label}')]/following-sibling::dd[1]"
                    el = self.driver.find_element(By.XPATH, xpath)
                    details[field] = el.text.strip()
                except:
                    try:
                        xpath = f"//*[contains(text(), '{german_label}:')]"
                        el = self.driver.find_element(By.XPATH, xpath)
                        text = el.text
                        match = re.search(f"{german_label}:\\s*(.+)", text)
                        if match:
                            details[field] = match.group(1).strip()
                    except:
                        pass

            # All images
            images = []
            try:
                img_elements = self.driver.find_elements(By.CSS_SELECTOR, "img[src*='sellpy']")
                for img in img_elements[:5]:
                    src = img.get_attribute("src")
                    if src and 'thumbnail' not in src.lower():
                        images.append(src)
            except:
                pass

            if images:
                details["images"] = images

            return details

        except Exception as e:
            self.log(f"Detay cikarma hatasi: {e}", "debug")
            return None

    def load_more_products(self) -> bool:
        """Daha fazla urun yukle"""
        initial_count = len(self.get_product_elements())
        self.log(f"Mevcut urun sayisi: {initial_count}")

        for attempt in range(3):
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            self.random_delay(1.5, 2.5)
            self.close_size_popup()

            new_count = len(self.get_product_elements())
            if new_count > initial_count:
                self.log(f"Scroll ile yuklendi: {initial_count} -> {new_count}")
                return True

        load_more_selectors = [
            "button[data-testid='load-more']",
            "//button[contains(text(), 'Mehr laden')]",
            "//button[contains(text(), 'Load more')]",
            ".load-more button",
        ]

        for selector in load_more_selectors:
            try:
                if selector.startswith('//'):
                    btn = self.driver.find_element(By.XPATH, selector)
                else:
                    btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.log(f"Load more bulundu: {selector}")
                    self.human_click(btn)
                    self.random_delay(2, 4)

                    new_count = len(self.get_product_elements())
                    if new_count > initial_count:
                        return True
            except:
                pass

        self.log("Daha fazla urun yuklenemedi")
        return False

    def extract_all_products(self) -> List[Dict]:
        """Sayfadaki tum urunleri cikar"""
        elements = self.get_product_elements()
        products = []

        for element in elements:
            product = self.extract_product_data(element)
            if product and product["url"] not in [p["url"] for p in self.products_found]:
                products.append(product)
                self.products_found.append(product)

        self.log(f"{len(products)} yeni urun cikarildi (Toplam: {len(self.products_found)})")
        return products

    def scrape_page(self, url: str) -> List[Dict]:
        """Tek bir sayfayi kazi"""
        self.log(f"Sayfa aciliyor: {url}")
        self.visit_url(url)

        self.close_cookie_banner()
        self.close_size_popup()

        return self.extract_all_products()

    def scrape(self, query: str, max_products: int = None, max_pages: int = 10,
               min_price: float = None, max_price: float = None,
               category: str = None, condition: str = None,
               fetch_details: bool = False, **kwargs) -> List[Dict]:
        """
        Ana kazima fonksiyonu

        Args:
            query: Arama kelimesi
            max_products: Maksimum urun sayisi
            max_pages: Maksimum sayfa sayisi
            min_price: Minimum fiyat
            max_price: Maksimum fiyat
            category: Kategori filtresi
            condition: Durum filtresi
            fetch_details: Detay sayfalarini da kazi
        """
        self.log("=== SELLPY KAZIMA BASLIYOR ===")
        self.log(f"Arama: {query}")
        self.log(f"Max urun: {max_products or 'Sinirsiz'}")
        self.log(f"Fiyat: {min_price} - {max_price} EUR")

        try:
            for page in range(1, max_pages + 1):
                url = self.build_search_url(
                    query=query,
                    page=page,
                    min_price=min_price,
                    max_price=max_price,
                    category=category,
                    condition=condition
                )

                self.log(f"Sayfa {page}/{max_pages}")

                before_count = len(self.products_found)
                self.scrape_page(url)
                after_count = len(self.products_found)

                new_products = after_count - before_count
                self.log(f"+{new_products} yeni urun (Toplam: {after_count})")

                # Limit kontrolu
                if max_products and len(self.products_found) >= max_products:
                    self.log(f"Maksimum urun sayisina ulasildi: {max_products}")
                    break

                if new_products == 0:
                    self.log("Bos sayfa, kazima durduruluyor...")
                    break

                self.random_delay(2, 4)

            # Detay sayfalarini kazi (opsiyonel) - fiyat olmayan urunler icin
            if self.products_found:
                products_without_price = [p for p in self.products_found if p.get("price") is None]
                if products_without_price:
                    self.log(f"{len(products_without_price)} urunun fiyati yok, detay sayfalarindan alinacak...")
                    for product in products_without_price[:10]:  # Max 10 detay
                        details = self.extract_product_details(product["url"])
                        if details:
                            product.update(details)
                        self.random_delay(1, 2)

            self.log("=== SELLPY KAZIMA TAMAMLANDI ===")

            # Fiyat istatistikleri
            with_price = len([p for p in self.products_found if p.get("price") is not None])
            self.log(f"Toplam: {len(self.products_found)} urun, {with_price} fiyatli")

            return self.products_found

        except Exception as e:
            self.log(f"Kazima hatasi: {e}", "error")
            self.screenshot("error")
            raise


def run_sellpy_scrape(query: str, max_products: int = None, headless: bool = True) -> List[Dict]:
    """Sellpy kazima islemini calistir"""
    with SellpyScraper(headless=headless) as scraper:
        return scraper.scrape(query, max_products=max_products)


if __name__ == "__main__":
    import sys

    query = sys.argv[1] if len(sys.argv) > 1 else "pullover"
    max_items = int(sys.argv[2]) if len(sys.argv) > 2 else 20

    print(f"Sellpy kazima basliyor: {query}")
    products = run_sellpy_scrape(query, max_products=max_items, headless=True)

    print(f"\n{len(products)} urun bulundu:")
    for p in products[:5]:
        price_str = f"{p['price']} EUR" if p.get('price') else "FIYAT YOK"
        print(f"  - {p['title'][:40]} | {price_str} | {p['url']}")
