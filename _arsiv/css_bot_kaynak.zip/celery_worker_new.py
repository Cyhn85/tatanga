"""
TATANGA V3 - Celery Worker with Human Scrapers
7 platform destekli insan-benzeri kazima sistemi
"""
import os
import sys
import logging
import hashlib
from celery import Celery
from datetime import datetime

# Add backend to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import settings

celery_app = Celery(
    "tatanga_worker",
    broker=settings.redis_url,
    backend=settings.redis_url.replace("/0", "/1"),
)

celery_app.conf.update(
    enable_utc=True,
    task_track_started=True,
    task_time_limit=900,  # 15 dakika - insan-benzeri scraping icin
    worker_prefetch_multiplier=1,
    worker_concurrency=2,
)

logger = logging.getLogger("TATANGA.celery")


# Human Scraper imports
SCRAPER_CLASSES = {}

def get_scraper_class(platform: str):
    """Lazy load scraper classes to avoid import errors at startup"""
    global SCRAPER_CLASSES

    if not SCRAPER_CLASSES:
        try:
            from services.human_scraper.human_scraper_vinted import VintedScraper
            from services.human_scraper.human_scraper_ebay import EbayScraper
            from services.human_scraper.human_scraper_kleinanzeigen import KleinanzeigenScraper
            from services.human_scraper.human_scraper_willhaben import WillhabenScraper
            from services.human_scraper.human_scraper_sellpy import SellpyScraper
            from services.human_scraper.human_scraper_percentil import PercentilScraper
            from services.human_scraper.human_scraper_tradera import TraderaScraper

            SCRAPER_CLASSES = {
                "vinted": VintedScraper,
                "ebay": EbayScraper,
                "kleinanzeigen": KleinanzeigenScraper,
                "willhaben": WillhabenScraper,
                "sellpy": SellpyScraper,
                "percentil": PercentilScraper,
                "tradera": TraderaScraper,
            }
            logger.info(f"Loaded {len(SCRAPER_CLASSES)} human scrapers")
        except Exception as e:
            logger.error(f"Failed to load human scrapers: {e}")
            SCRAPER_CLASSES = {}

    return SCRAPER_CLASSES.get(platform.lower())


def generate_scr_id(url: str) -> str:
    """Generate unique scr_id from URL"""
    hash_part = hashlib.md5(url.encode()).hexdigest()[:8]
    return f"SCR-{hash_part.upper()}"


def save_products_to_db(products: list, platform: str, query: str):
    """Save scraped products to database"""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from config import settings
    from models import Product

    sync_db_url = settings.database_url.replace("+asyncpg", "")
    engine = create_engine(sync_db_url)
    Session = sessionmaker(bind=engine)
    session = Session()

    saved_count = 0
    try:
        for p in products:
            url = p.get("url", "")
            if not url:
                continue

            # Check if product already exists by source_url
            existing = session.query(Product).filter_by(source_url=url).first()
            if existing:
                continue

            # Generate unique scr_id
            scr_id = generate_scr_id(url)

            # Check if scr_id already exists (collision)
            if session.query(Product).filter_by(scr_id=scr_id).first():
                continue

            # Prepare images as list
            image = p.get("image")
            images = [image] if image else []

            product = Product(
                scr_id=scr_id,
                source_url=url,
                source_platform=platform,
                title=p.get("title", ""),
                price=p.get("price"),
                images=images,
                condition=p.get("condition"),
                status="inbox"
            )
            session.add(product)
            saved_count += 1

        session.commit()
        logger.info(f"Saved {saved_count} new products to database")
    except Exception as e:
        session.rollback()
        logger.error(f"Failed to save products: {e}")
    finally:
        session.close()

    return saved_count


def update_job_status(job_id: str, status: str, result_count: int = 0, error_message: str = None):
    """Update job status in database"""
    from sqlalchemy import create_engine, text
    from config import settings

    sync_db_url = settings.database_url.replace("+asyncpg", "")
    engine = create_engine(sync_db_url)

    try:
        with engine.connect() as conn:
            if status == "completed":
                conn.execute(text("""
                    UPDATE scrape_jobs
                    SET status = :status, result_count = :count, completed_at = NOW()
                    WHERE job_id = :job_id
                """), {"status": status, "count": result_count, "job_id": job_id})
            else:
                conn.execute(text("""
                    UPDATE scrape_jobs
                    SET status = :status, error_message = :error, completed_at = NOW()
                    WHERE job_id = :job_id
                """), {"status": status, "error": error_message, "job_id": job_id})
            conn.commit()
            logger.info(f"Updated job {job_id} status to {status}")
    except Exception as e:
        logger.error(f"Failed to update job status: {e}")


@celery_app.task(bind=True, name="tatanga.scrape")
def scrape_task(self, platform: str, query: str, max_pages: int = 3, max_items: int = 50,
                min_price: float = None, max_price: float = None, condition: str = None,
                conditions: list = None, sort: str = None, job_id: str = None):
    """
    Ana kazima gorevi - Human Scrapers ile

    Args:
        platform: Platform adi (vinted, ebay, kleinanzeigen, willhaben, sellpy, percentil, tradera)
        query: Arama sorgusu
        max_pages: Maksimum sayfa sayisi
        max_items: Maksimum urun sayisi
        min_price: Minimum fiyat
        max_price: Maksimum fiyat
        condition: Tek durum filtresi (sehr gut, gut, etc.)
        conditions: Coklu durum listesi
        sort: Siralama
        job_id: Veritabani is ID'si
    """
    logger.info(f"Starting human scrape: {platform} - {query}")
    self.update_state(state="PROGRESS", meta={"status": "scraping", "platform": platform})

    try:
        # Get scraper class
        ScraperClass = get_scraper_class(platform)
        if not ScraperClass:
            raise ValueError(f"Unknown platform: {platform}. Supported: vinted, ebay, kleinanzeigen, willhaben, sellpy, percentil, tradera")

        # Run scraper with human-like behavior
        with ScraperClass(headless=True) as scraper:
            products = scraper.scrape(
                query=query,
                max_products=max_items,
                max_pages=max_pages,
                min_price=min_price,
                max_price=max_price,
                condition=condition,
                conditions=conditions
            )

        items_found = len(products)
        result = {
            "status": "success",
            "platform": platform,
            "query": query,
            "products": products,
            "stats": {
                "items_found": items_found,
                "pages_scraped": max_pages
            }
        }

        # Save products to database
        if products:
            saved_count = save_products_to_db(products, platform, query)
            result["stats"]["items_saved"] = saved_count

        # Update job status
        if job_id:
            update_job_status(job_id, "completed", items_found)

        logger.info(f"Completed: {items_found} items found")
        return result

    except Exception as e:
        logger.error(f"Failed: {e}")
        if job_id:
            update_job_status(job_id, "failed", error_message=str(e))
        return {"status": "error", "error": str(e), "platform": platform, "query": query}


@celery_app.task(name="tatanga.url_monitor")
def url_monitor_task():
    """Check all active tracked URLs"""
    logger.info("URL monitor running")
    return {"checked": 0, "updated": 0}
