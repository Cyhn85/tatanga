#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Minimal GUI Test
Test if Tkinter works at all
"""

import sys
import traceback

print("="*60)
print("TATANGA MINIMAL TEST")
print("="*60)
print()

# Test 1: Python version
print("[TEST 1] Python Version:")
print(f"  {sys.version}")
print()

# Test 2: Tkinter import
print("[TEST 2] Tkinter Import:")
try:
    import tkinter as tk
    print("  ✅ tkinter imported successfully")
except Exception as e:
    print(f"  ❌ tkinter import failed: {e}")
    traceback.print_exc()
    input("\nPress Enter to exit...")
    sys.exit(1)
print()

# Test 3: Create simple window
print("[TEST 3] Creating Simple Window:")
try:
    root = tk.Tk()
    root.title("TATANGA Test")
    root.geometry("400x300")

    label = tk.Label(
        root,
        text="✅ GUI Çalışıyor!\n\nTATANGA GUI sistemi normal.",
        font=("Arial", 14),
        fg="green"
    )
    label.pack(pady=50)

    info = tk.Label(
        root,
        text=f"Python: {sys.version.split()[0]}\nTkinter: {tk.TkVersion}",
        font=("Arial", 10),
        fg="gray"
    )
    info.pack(pady=10)

    close_btn = tk.Button(
        root,
        text="Kapat",
        command=root.destroy,
        bg="#4CAF50",
        fg="white",
        font=("Arial", 11, "bold"),
        width=15
    )
    close_btn.pack(pady=20)

    print("  ✅ Window created successfully")
    print()
    print("  GUI penceresi açıldı. Kapatmak için butona tıklayın.")
    print()

    root.mainloop()

    print("  ✅ Window closed successfully")

except Exception as e:
    print(f"  ❌ GUI creation failed: {e}")
    traceback.print_exc()
    input("\nPress Enter to exit...")
    sys.exit(1)

print()
print("="*60)
print("✅ ALL TESTS PASSED!")
print("="*60)
print()
print("TATANGA GUI sistemi çalışıyor.")
print("Şimdi ana launcher'ı deneyebilirsiniz:")
print("  START_TATANGA_VERBOSE.bat")
print()

input("Press Enter to exit...")
