import os
from dotenv import load_dotenv
from google import genai
import requests
from bs4 import BeautifulSoup

# 1. Ortam değişkenlerini yükle ve API anahtarını al
load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY")

if not API_KEY:
    print("HATA: GEMINI_API_KEY bulunamadı. Lütfen .env dosyanızı kontrol edin.")
    exit()

# 2. Gemini İstemcisini Başlat
client = genai.Client(api_key=API_KEY)

# 3. Web Kazıma Fonksiyonu (Örnek)
def web_kazima(url):
    """Belirtilen URL'den HTML içeriğini alır."""
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status() # Hata kodlarını kontrol et
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Basit bir örnek: Sayfadaki tüm paragraf metinlerini al
        paragraphs = [p.get_text() for p in soup.find_all('p') if p.get_text()]
        
        return "\n".join(paragraphs[:5]) # İlk 5 paragrafı döndür
        
    except Exception as e:
        return f"Kazıma Hatası: {e}"

# 4. Ana Program
def run_analysis():
    # Bu URL'yi, kazımak istediğiniz 2. el pazar yeri listeleme sayfasına çevirebilirsiniz
    target_url = "https://www.example.com/" 
    
    # 4a. Kazıma işlemini yap
    kazinan_veri = web_kazima(target_url)

    if "Kazıma Hatası" in kazinan_veri:
        print(kazinan_veri)
        return

    print("✅ Web'den veri kazındı. Şimdi Gemini ile analiz ediliyor...")

    # 4b. Gemini için komut (prompt) oluştur
    prompt = f"""
    Aşağıdaki veri, bir web sitesinden kazınmıştır. Bu veriyi analiz et ve özetle. 
    Veri bir ürün listesi ise (fiyat/açıklama) şeklinde bir tabloya dönüştür.
    --- KAZINAN VERİ BAŞLANGIÇ ---
    {kazinan_veri}
    --- KAZINAN VERİ SONU ---
    """
    
    try:
        # 4c. Gemini'den yanıt al
        response = client.models.generate_content(
            model='gemini-2.5-flash', # Hızlı ve uygun maliyetli model
            contents=prompt,
        )

        # 4d. Yanıtı yazdır
        print("\n--- GEMINI ANALİZİ ---\n")
        print(response.text)
        
    except Exception as e:
        print(f"API İsteği Başarısız Oldu: {e}")
        print("API anahtarınızın doğru olduğundan veya kredi limitinizin bulunduğundan emin olun.")

if __name__ == "__main__":
    run_analysis()
    