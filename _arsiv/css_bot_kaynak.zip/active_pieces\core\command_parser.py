#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Natural Language Command Parser
==========================================
Doğal dil komutlarını yapılandırılmış aksiyonlara çevirir.
Gemini API kullanır.
Platform Registry ile entegre çalışır.
"""

import os
import json
import re
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

# Gemini API Key
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', 'AIzaSyBwA4VQVEUROtcK9XZ228bAoCvRuHQ2LoE')

# Platform Registry'den al
try:
    from core.platform_registry import (
        PLATFORM_ALIASES,
        PLATFORM_REGISTRY,
        get_platform_language,
        resolve_platform,
        LANGUAGE_NAMES
    )
except ImportError:
    # Fallback
    PLATFORM_ALIASES = {
        'ebay': 'ebay.de',
        'ebay.de': 'ebay.de',
        'vinted': 'vinted.de',
        'vinted.de': 'vinted.de',
        'kleinanzeigen': 'kleinanzeigen.de',
        'ka': 'kleinanzeigen.de',
        'willhaben': 'willhaben.at',
        'marktplaats': 'marktplaats.nl',
    }
    PLATFORM_REGISTRY = {}
    get_platform_language = lambda p: 'de'
    resolve_platform = lambda p: p
    LANGUAGE_NAMES = {}

# Condition mappings
CONDITION_ALIASES = {
    'neu': 'new',
    'new': 'new',
    'wie neu': 'like_new',
    'sehr gut': 'very_good',
    'gut': 'good',
    'akzeptabel': 'fair',
    'fair': 'fair',
}

# Action keywords
ACTION_KEYWORDS = {
    'ara': 'search',
    'search': 'search',
    'suche': 'search',
    'bul': 'search',
    'find': 'search',
    'yayinla': 'publish',
    'publish': 'publish',
    'veroffentlichen': 'publish',
    'sil': 'delete',
    'delete': 'delete',
    'loschen': 'delete',
    'temizle': 'cleanup',
    'cleanup': 'cleanup',
    'favori': 'favorite',
    'favorite': 'favorite',
    'kontrol': 'check',
    'check': 'check',
    'prufen': 'check',
}


@dataclass
class ParsedCommand:
    """Parsed command structure"""
    action: str  # search, publish, delete, cleanup, check
    platforms: List[str]
    query: Optional[str]
    filters: Dict[str, Any]
    target_id: Optional[int]
    raw_command: str
    confidence: float
    parsed_at: str
    translated_queries: Dict[str, str] = field(default_factory=dict)  # platform -> translated query


def parse_command(text: str) -> ParsedCommand:
    """
    Doğal dil komutunu parse et

    Örnekler:
        "ebay+vinted'de nike ayakkabı ara"
        "sadece zustand:gut olanları getir"
        "fiyat 10-50€ arası"
        "favori 123'ü yayınla"
        "tüm satılmışları temizle"
    """
    text = text.strip().lower()
    original = text

    # Initialize result
    action = 'search'  # default
    platforms = []
    query = None
    filters = {}
    target_id = None
    confidence = 0.5

    # 1. Extract platforms
    # Find all platform-like patterns: domain names or aliases
    # Pattern: word.tld or just word (for aliases)
    domain_pattern = r'\b(\w+(?:\.\w+)?(?:\.(?:de|fr|uk|co\.uk|es|it|nl|be|pl|cz|at|se|dk|no|fi|com))?)\b'
    found_domains = re.findall(domain_pattern, text)

    for domain in found_domains:
        domain_lower = domain.lower()
        # Try to resolve using registry
        resolved = resolve_platform(domain_lower)
        if resolved and resolved in PLATFORM_REGISTRY:
            if resolved not in platforms:
                platforms.append(resolved)
                confidence += 0.05

    # Also check aliases directly
    for alias, platform in PLATFORM_ALIASES.items():
        if alias in text and platform not in platforms:
            platforms.append(platform)
            confidence += 0.05

    # Default platforms if none specified
    if not platforms:
        platforms = ['ebay.de', 'vinted.de']

    # 2. Detect action
    for keyword, act in ACTION_KEYWORDS.items():
        if keyword in text:
            action = act
            confidence += 0.1
            break

    # 3. Extract filters

    # Condition filter: "zustand:gut" or "nur gut" or "sadece iyi"
    condition_pattern = r'zustand[:\s]*(\w+)'
    cond_match = re.search(condition_pattern, text)
    if cond_match:
        cond = cond_match.group(1)
        if cond in CONDITION_ALIASES:
            filters['condition'] = CONDITION_ALIASES[cond]
            confidence += 0.1

    # Price filter: "fiyat 10-50" or "preis 10-50" or "10-50€"
    price_pattern = r'(\d+)\s*[-–]\s*(\d+)\s*[€$]?'
    price_match = re.search(price_pattern, text)
    if price_match:
        filters['price_min'] = int(price_match.group(1))
        filters['price_max'] = int(price_match.group(2))
        confidence += 0.1

    # Time filter: "son 24 saat" or "letzte 24 stunden"
    time_pattern = r'(?:son|letzte|last)\s*(\d+)\s*(?:saat|stunden|hours)'
    time_match = re.search(time_pattern, text)
    if time_match:
        filters['hours_ago'] = int(time_match.group(1))
        confidence += 0.1

    # 4. Extract target ID for publish/delete actions
    id_pattern = r'(?:favori|#|id)\s*(\d+)'
    id_match = re.search(id_pattern, text)
    if id_match:
        target_id = int(id_match.group(1))
        confidence += 0.1

    # 5. Extract search query
    # Remove known patterns to get the query
    query_text = text

    # Remove platform mentions (domain names and aliases)
    for platform in platforms:
        query_text = re.sub(rf'\b{re.escape(platform)}\b', '', query_text, flags=re.IGNORECASE)
    for alias in PLATFORM_ALIASES.keys():
        query_text = re.sub(rf'\b{re.escape(alias)}\b', '', query_text, flags=re.IGNORECASE)
    # Remove domain-like patterns
    query_text = re.sub(r'\b\w+\.(?:de|fr|uk|co\.uk|es|it|nl|be|pl|cz|at|se|dk|no|fi|com)\b', '', query_text, flags=re.IGNORECASE)

    # Remove action words
    for keyword in ACTION_KEYWORDS.keys():
        query_text = re.sub(rf'\b{keyword}\b', '', query_text)

    # Remove filter patterns
    query_text = re.sub(r'zustand[:\s]*\w+', '', query_text)
    query_text = re.sub(r'\d+\s*[-–]\s*\d+\s*[€$]?', '', query_text)
    query_text = re.sub(r'(?:son|letzte|last)\s*\d+\s*(?:saat|stunden|hours)', '', query_text)
    query_text = re.sub(r'(?:favori|#|id)\s*\d+', '', query_text)

    # Remove common words
    stop_words = ['de', 'da', 'den', 'sitelerinde', 'sitesinde', 'auf', 'in', 'und', 've', 'ile', 'sadece', 'nur', 'only', 'olanları', 'getir', "'de", "'da"]
    for word in stop_words:
        query_text = re.sub(rf'\b{word}\b', '', query_text)

    # Clean up
    query_text = re.sub(r'[\+,\'\"\(\)]', ' ', query_text)
    query_text = ' '.join(query_text.split())

    if query_text and len(query_text) > 2:
        query = query_text
        confidence += 0.2

    # Resolve platform names using registry
    resolved_platforms = []
    for p in set(platforms):
        resolved = resolve_platform(p)
        if resolved:
            resolved_platforms.append(resolved)

    if not resolved_platforms:
        resolved_platforms = ['ebay.de', 'vinted.de']

    # Translate query for each platform
    translated_queries = {}
    if query:
        translated_queries = translate_query_for_platforms(query, resolved_platforms)

    return ParsedCommand(
        action=action,
        platforms=resolved_platforms,
        query=query,
        filters=filters,
        target_id=target_id,
        raw_command=original,
        confidence=min(confidence, 1.0),
        parsed_at=datetime.now().isoformat(),
        translated_queries=translated_queries
    )


def parse_with_ai(text: str) -> ParsedCommand:
    """
    Gemini ile gelişmiş komut parse

    AI'ı kullanarak daha karmaşık komutları anlar
    """
    try:
        import google.generativeai as genai

        genai.configure(api_key=GEMINI_API_KEY)
        model = genai.GenerativeModel('gemini-1.5-flash')

        prompt = f"""
Du bist ein Kommando-Parser für ein E-Commerce-System. Analysiere den folgenden natürlichsprachlichen Befehl und extrahiere strukturierte Informationen.

Befehl: "{text}"

Antworte NUR mit einem JSON-Objekt in diesem Format:
{{
    "action": "search|publish|delete|cleanup|check",
    "platforms": ["ebay.de", "vinted.de"],
    "query": "Suchbegriff",
    "filters": {{
        "condition": "new|like_new|very_good|good|fair",
        "price_min": 0,
        "price_max": 100,
        "hours_ago": 24
    }},
    "target_id": null,
    "confidence": 0.9
}}

Regeln:
- action: was soll gemacht werden
- platforms: welche Plattformen (ebay.de, vinted.de, kleinanzeigen.de, etc.)
- query: Suchbegriff (nur für search action)
- filters: optionale Filter
- target_id: Produkt-ID für publish/delete actions
- confidence: wie sicher bist du (0.0-1.0)

Gib NUR das JSON zurück, NICHTS anderes.
"""

        response = model.generate_content(prompt)
        response_text = response.text.strip()

        # Clean markdown if present
        if response_text.startswith('```'):
            response_text = re.sub(r'^```\w*\n?', '', response_text)
            response_text = re.sub(r'\n?```$', '', response_text)

        data = json.loads(response_text)

        return ParsedCommand(
            action=data.get('action', 'search'),
            platforms=data.get('platforms', ['ebay.de', 'vinted.de']),
            query=data.get('query'),
            filters=data.get('filters', {}),
            target_id=data.get('target_id'),
            raw_command=text,
            confidence=data.get('confidence', 0.8),
            parsed_at=datetime.now().isoformat()
        )

    except Exception as e:
        print(f"AI parsing failed: {e}")
        # Fallback to rule-based parsing
        return parse_command(text)


def translate_query_for_platforms(query: str, platforms: List[str]) -> Dict[str, str]:
    """
    Sorguyu her platformun diline çevir

    Args:
        query: Orijinal sorgu (Türkçe olabilir)
        platforms: Platform domain listesi

    Returns:
        {platform: translated_query} dict
    """
    translated = {}

    # Dil gruplarına ayır
    languages_needed = {}
    for platform in platforms:
        lang = get_platform_language(platform)
        if lang not in languages_needed:
            languages_needed[lang] = []
        languages_needed[lang].append(platform)

    # Her dil için çeviri yap
    for lang, platform_list in languages_needed.items():
        translated_query = translate_to_language(query, lang)
        for platform in platform_list:
            translated[platform] = translated_query

    return translated


def translate_to_language(query: str, target_lang: str) -> str:
    """
    Sorguyu hedef dile çevir

    Önce cache kontrol eder, yoksa AI ile çevirir
    """
    # Zaten hedef dildeyse aynen döndür
    if target_lang == 'tr':
        return query

    # Basit çeviri cache (sık kullanılan terimler)
    TRANSLATION_CACHE = {
        # Türkçe -> Almanca
        ('deri ceket', 'de'): 'Lederjacke',
        ('nike ayakkabi', 'de'): 'Nike Schuhe',
        ('spor ayakkabi', 'de'): 'Sportschuhe',
        ('kazak', 'de'): 'Pullover',
        ('mont', 'de'): 'Jacke',
        ('canta', 'de'): 'Tasche',
        ('elbise', 'de'): 'Kleid',
        ('pantolon', 'de'): 'Hose',
        ('gomlek', 'de'): 'Hemd',
        ('etek', 'de'): 'Rock',
        ('bot', 'de'): 'Stiefel',
        ('cizme', 'de'): 'Stiefel',

        # Türkçe -> İngilizce
        ('deri ceket', 'en'): 'leather jacket',
        ('nike ayakkabi', 'en'): 'Nike shoes',
        ('spor ayakkabi', 'en'): 'sneakers',
        ('kazak', 'en'): 'sweater',
        ('mont', 'en'): 'jacket',
        ('canta', 'en'): 'bag',
        ('elbise', 'en'): 'dress',
        ('pantolon', 'en'): 'pants',
        ('gomlek', 'en'): 'shirt',
        ('etek', 'en'): 'skirt',
        ('bot', 'en'): 'boots',

        # Türkçe -> Fransızca
        ('deri ceket', 'fr'): 'veste en cuir',
        ('nike ayakkabi', 'fr'): 'chaussures Nike',
        ('spor ayakkabi', 'fr'): 'baskets',
        ('kazak', 'fr'): 'pull',
        ('mont', 'fr'): 'veste',
        ('canta', 'fr'): 'sac',
        ('elbise', 'fr'): 'robe',

        # Türkçe -> Fince (tori.fi için)
        ('deri ceket', 'fi'): 'nahkatakki',
        ('nike ayakkabi', 'fi'): 'Nike kengät',
        ('spor ayakkabi', 'fi'): 'lenkkitossut',
        ('kazak', 'fi'): 'villapaita',
        ('mont', 'fi'): 'takki',

        # Türkçe -> İsveççe
        ('deri ceket', 'sv'): 'skinnjacka',
        ('nike ayakkabi', 'sv'): 'Nike skor',
        ('spor ayakkabi', 'sv'): 'sneakers',
        ('kazak', 'sv'): 'tröja',
        ('mont', 'sv'): 'jacka',

        # Türkçe -> Norveççe
        ('deri ceket', 'no'): 'skinnjakke',
        ('nike ayakkabi', 'no'): 'Nike sko',
        ('kazak', 'no'): 'genser',

        # Türkçe -> Danca
        ('deri ceket', 'da'): 'læderjakke',
        ('nike ayakkabi', 'da'): 'Nike sko',
        ('kazak', 'da'): 'sweater',
    }

    # Normalize query
    query_lower = query.lower().strip()

    # Check cache
    cache_key = (query_lower, target_lang)
    if cache_key in TRANSLATION_CACHE:
        return TRANSLATION_CACHE[cache_key]

    # Marka isimleri çevrilmez (Nike, Adidas, Tommy Hilfiger, etc.)
    BRAND_NAMES = [
        'nike', 'adidas', 'puma', 'reebok', 'new balance', 'converse', 'vans',
        'tommy hilfiger', 'ralph lauren', 'calvin klein', 'hugo boss', 'lacoste',
        'gucci', 'prada', 'louis vuitton', 'chanel', 'hermes', 'burberry',
        'zara', 'h&m', 'mango', 'uniqlo', 'gap', 'levis', 'diesel',
        'north face', 'patagonia', 'columbia', 'timberland', 'ugg',
        'michael kors', 'coach', 'kate spade', 'furla', 'longchamp',
        'dyson', 'apple', 'samsung', 'sony', 'bose'
    ]

    # Eğer sadece marka ismi ise aynen döndür
    for brand in BRAND_NAMES:
        if brand in query_lower:
            # Markayı koru, geri kalanı çevirmeye çalış
            return query  # Şimdilik aynen döndür

    # AI çevirisi dene
    try:
        translated = ai_translate(query, target_lang)
        if translated:
            return translated
    except Exception:
        pass

    # Fallback: orijinal sorgu
    return query


def ai_translate(query: str, target_lang: str) -> Optional[str]:
    """Gemini ile çeviri yap"""
    try:
        import google.generativeai as genai

        genai.configure(api_key=GEMINI_API_KEY)
        model = genai.GenerativeModel('gemini-2.0-flash')

        lang_names = {
            'de': 'German', 'en': 'English', 'fr': 'French',
            'es': 'Spanish', 'it': 'Italian', 'nl': 'Dutch',
            'pl': 'Polish', 'cs': 'Czech', 'sv': 'Swedish',
            'da': 'Danish', 'no': 'Norwegian', 'fi': 'Finnish'
        }

        target_name = lang_names.get(target_lang, 'German')

        prompt = f"""Translate this product search term to {target_name}.
Keep brand names unchanged. Return ONLY the translation, nothing else.

Search term: "{query}"
Translation:"""

        response = model.generate_content(prompt)
        translated = response.text.strip()

        # Clean up
        translated = translated.replace('"', '').replace("'", "")
        if len(translated) > 100:  # Sanity check
            return query

        return translated

    except Exception as e:
        print(f"AI translation failed: {e}")
        return None


def to_dict(cmd: ParsedCommand) -> Dict:
    """ParsedCommand'ı dict'e çevir"""
    return {
        'action': cmd.action,
        'platforms': cmd.platforms,
        'query': cmd.query,
        'filters': cmd.filters,
        'target_id': cmd.target_id,
        'raw_command': cmd.raw_command,
        'confidence': cmd.confidence,
        'parsed_at': cmd.parsed_at,
        'translated_queries': cmd.translated_queries
    }


# Example usage
if __name__ == '__main__':
    examples = [
        "ebay+vinted'de nike ayakkabı ara",
        "sadece zustand:gut olanları getir",
        "fiyat 10-50€ arası ara",
        "favori 123'ü yayınla",
        "tüm satılmışları temizle",
        "kleinanzeigen'de tommy hilfiger ara",
        "son 24 saat içinde eklenenler"
    ]

    print("=" * 60)
    print("TATANGA Command Parser Test")
    print("=" * 60)

    for example in examples:
        print(f"\nInput: {example}")
        result = parse_command(example)
        print(f"Action: {result.action}")
        print(f"Platforms: {result.platforms}")
        print(f"Query: {result.query}")
        print(f"Filters: {result.filters}")
        print(f"Target ID: {result.target_id}")
        print(f"Confidence: {result.confidence:.1%}")
        print("-" * 40)
