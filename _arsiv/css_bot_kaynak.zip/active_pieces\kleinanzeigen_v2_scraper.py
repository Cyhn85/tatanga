# -*- coding: utf-8 -*-
"""
KLEINANZEIGEN V2 SCRAPER - Pagination + Robotic + Extended Delays
=================================================================
- Full pagination support
- Extended delays: +5 seconds between actions
- Robotic scroll patterns
- RANDOM PRODUCT VISITS - like a real user
- USER PROFILE VISITS - browse seller profiles
- Cookie consent handling
- Target: 1200+ products
"""

import sys
import io

# Safe stdout wrapper for Windows - skip if already wrapped or in special environment
if sys.platform == 'win32':
    try:
        if hasattr(sys.stdout, 'buffer') and not isinstance(sys.stdout, io.TextIOWrapper):
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    except (AttributeError, ValueError, OSError):
        pass

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import time
import random
import json
from typing import List, Dict, Optional
from datetime import datetime
import re
from urllib.parse import quote_plus

# Import metadata extractor for size/brand/color parsing
try:
    from integrations.metadata_extractor import extract_metadata
    METADATA_EXTRACTOR_AVAILABLE = True
except ImportError:
    METADATA_EXTRACTOR_AVAILABLE = False
    def extract_metadata(title, description=""):
        return {'size': None, 'brand': None, 'color': None, 'condition': 'Gebraucht'}

class KleinanzeigenV2Scraper:
    """
    Kleinanzeigen V2 - Enhanced scraper with pagination and robotic behavior
    Includes: random product visits, seller profile browsing
    """

    BASE_URL = "https://www.kleinanzeigen.de"

    def __init__(self, headless: bool = False, fast_mode: bool = False):
        self.headless = headless
        self.fast_mode = fast_mode  # Skip random visits, faster delays
        self.driver = None
        self.all_products = []
        self.base_delay = 2 if fast_mode else 5  # Reduced delays
        self.visited_products = set()
        self.visited_profiles = set()

    def _random_delay(self, min_extra: float = 0, max_extra: float = 3) -> None:
        """Extended random delay with Gaussian distribution"""
        base = self.base_delay
        extra = random.gauss((min_extra + max_extra) / 2, (max_extra - min_extra) / 4)
        extra = max(min_extra, min(max_extra, extra))
        delay = base + extra
        print(f"    [WAIT] Waiting {delay:.1f}s...")
        time.sleep(delay)

    def _human_scroll(self) -> None:
        """Human-like scroll pattern - smooth and variable"""
        print(f"    [SCROLL] Human scroll pattern...")

        total_height = self.driver.execute_script("return document.body.scrollHeight")
        current_position = 0

        while current_position < total_height:
            # Variable scroll amount (human-like)
            scroll_amount = random.randint(200, 500)

            # Scroll down
            self.driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
            current_position += scroll_amount

            # Random pause (reading time)
            time.sleep(random.uniform(0.5, 1.2))

            # Occasionally scroll up a bit (reconsidering)
            if random.random() < 0.2:
                back_scroll = random.randint(50, 150)
                self.driver.execute_script(f"window.scrollBy(0, -{back_scroll});")
                current_position -= back_scroll
                time.sleep(random.uniform(0.3, 0.7))

            # Occasionally pause longer (reading an item)
            if random.random() < 0.15:
                time.sleep(random.uniform(1.5, 3))

            # Update total height
            total_height = self.driver.execute_script("return document.body.scrollHeight")

        # Scroll back to top partially
        self.driver.execute_script(f"window.scrollTo(0, {random.randint(100, 500)});")
        time.sleep(0.5)

    def _robotic_scroll(self, scroll_count: int = 5) -> None:
        """Robotic scroll pattern to load lazy content"""
        print(f"    [ROBOT] Robotic scroll ({scroll_count}x)...")

        for i in range(scroll_count):
            scroll_amount = random.randint(300, 700)
            self.driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
            time.sleep(random.uniform(0.8, 1.5))

            if random.random() < 0.3:
                self.driver.execute_script(f"window.scrollBy(0, -{random.randint(50, 150)});")
                time.sleep(random.uniform(0.3, 0.6))

        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(1.5)

    def _visit_random_product(self) -> Optional[Dict]:
        """
        Visit a random product like a real user would
        Browse the product, maybe check seller profile
        """
        print("    [BROWSE] Browsing a random product...")

        try:
            # Find product cards on Kleinanzeigen
            items = self.driver.find_elements(By.CSS_SELECTOR,
                "article.aditem a.ellipsis, .aditem a[href*='/s-anzeige/'], li[data-adid] a"
            )

            if not items:
                return None

            # Pick random item
            random_item = random.choice(items)
            product_url = random_item.get_attribute('href')

            if not product_url or product_url in self.visited_products:
                return None

            self.visited_products.add(product_url)

            # Click and visit product
            original_url = self.driver.current_url
            random_item.click()

            time.sleep(random.uniform(3, 5))

            # Scroll around on product page (reading)
            for _ in range(random.randint(2, 4)):
                self.driver.execute_script(f"window.scrollBy(0, {random.randint(150, 350)});")
                time.sleep(random.uniform(0.8, 1.5))

            # Extract product details while we're here
            product_details = self._extract_product_details()

            # Maybe visit seller profile (30% chance)
            if random.random() < 0.3:
                self._visit_seller_profile()

            # Go back to search results
            self.driver.get(original_url)
            time.sleep(random.uniform(2, 4))

            return product_details

        except Exception as e:
            print(f"    [WARN] Product visit failed: {e}")
            try:
                self.driver.back()
                time.sleep(2)
            except:
                pass
            return None

    def _extract_product_details(self) -> Dict:
        """Extract details from product page"""
        details = {}

        try:
            # Title
            title_el = self.driver.find_elements(By.CSS_SELECTOR,
                "#viewad-title, h1[itemprop='name'], .boxedarticle--title"
            )
            if title_el:
                details['title'] = title_el[0].text.strip()

            # Price
            price_el = self.driver.find_elements(By.CSS_SELECTOR,
                "#viewad-price, .boxedarticle--price, [itemprop='price']"
            )
            if price_el:
                details['price'] = price_el[0].text.strip()

            # Description
            desc_el = self.driver.find_elements(By.CSS_SELECTOR,
                "#viewad-description-text, [itemprop='description'], .addetailslist--detail"
            )
            if desc_el:
                details['description'] = desc_el[0].text.strip()[:500]

            # Location
            loc_el = self.driver.find_elements(By.CSS_SELECTOR,
                "#viewad-locality, .addetailslist--detail--location"
            )
            if loc_el:
                details['location'] = loc_el[0].text.strip()

            details['url'] = self.driver.current_url

        except Exception as e:
            print(f"    [WARN] Details extraction error: {e}")

        return details

    def _visit_seller_profile(self) -> None:
        """
        Visit seller profile from product page
        Browse around like checking seller reputation
        """
        print("    [USER] Checking seller profile...")

        try:
            # Find seller link
            seller_links = self.driver.find_elements(By.CSS_SELECTOR,
                "#viewad-contact a, .userprofile-vip a, a[href*='/s-bestandsliste.html'], .iconlist-text a"
            )

            if not seller_links:
                return

            seller_link = seller_links[0]
            seller_url = seller_link.get_attribute('href')

            if seller_url in self.visited_profiles:
                return

            self.visited_profiles.add(seller_url)

            # Click seller profile
            product_url = self.driver.current_url
            seller_link.click()

            time.sleep(random.uniform(3, 5))

            # Scroll around profile
            for _ in range(random.randint(2, 3)):
                self.driver.execute_script(f"window.scrollBy(0, {random.randint(200, 400)});")
                time.sleep(random.uniform(0.8, 1.2))

            # Pause like reading
            time.sleep(random.uniform(2, 4))

            # Go back to product
            self.driver.get(product_url)
            time.sleep(random.uniform(2, 3))

        except Exception as e:
            print(f"    [WARN] Profile visit failed: {e}")

    def _handle_cookies(self) -> None:
        """Handle cookie consent popup"""
        print("    [COOKIE] Checking for cookie consent...")

        cookie_selectors = [
            "#gdpr-banner-accept",
            "button[data-testid='gdpr-banner-accept']",
            "#consentDialog button.gdpr-banner-accept",
            "button[id*='accept']",
            ".gdpr-banner-accept",
            "#onetrust-accept-btn-handler",
        ]

        cookie_texts = ['Akzeptieren', 'Alle akzeptieren', 'Accept', 'OK', 'Einverstanden']

        for selector in cookie_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for elem in elements:
                    if elem.is_displayed():
                        elem.click()
                        print(f"    [OK] Cookie accepted via: {selector[:30]}...")
                        time.sleep(2)
                        return
            except:
                continue

        for text in cookie_texts:
            try:
                elements = self.driver.find_elements(By.XPATH, f"//button[contains(text(), '{text}')]")
                for elem in elements:
                    if elem.is_displayed():
                        elem.click()
                        print(f"    [OK] Cookie accepted via text: {text}")
                        time.sleep(2)
                        return
            except:
                continue

    def _init_driver(self) -> None:
        """Initialize undetected Chrome driver"""
        print("[START] Initializing Chrome driver...")

        options = uc.ChromeOptions()

        if self.headless:
            options.add_argument('--headless=new')

        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_argument('--window-size=1920,1080')
        options.add_argument('--lang=de-DE')

        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        ]
        options.add_argument(f'--user-agent={random.choice(user_agents)}')

        # Use webdriver-manager to get correct chromedriver version
        driver_path = ChromeDriverManager().install()
        self.driver = uc.Chrome(options=options, driver_executable_path=driver_path)
        self.driver.implicitly_wait(10)
        print("[OK] Driver initialized")

    def _get_all_images_from_detail_page(self, product_url: str, max_images: int = 10) -> List[str]:
        """
        Visit product detail page and extract ALL images from gallery.
        Returns list of image URLs (minimum 1, target 5+)
        """
        images = []
        original_url = self.driver.current_url

        try:
            # Navigate to product detail page
            self.driver.get(product_url)
            time.sleep(random.uniform(2, 4))

            # Kleinanzeigen image gallery selectors
            image_selectors = [
                # Main gallery images
                "img.galleryimage-element",
                "img[data-imgsrc]",
                ".galleryimage img",
                "#viewad-image img",
                ".gallery-container img",
                # Thumbnail images (often have full-size URL in data attributes)
                ".galleryimage-thumbnail img",
                ".gallery-thumbnail img",
                # Fallback
                "img[src*='img.kleinanzeigen.de']",
            ]

            seen_urls = set()

            for selector in image_selectors:
                try:
                    img_elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    for img in img_elements:
                        # Try multiple attributes for full-size image URL
                        for attr in ['data-imgsrc', 'data-src', 'src']:
                            url = img.get_attribute(attr)
                            if url and 'kleinanzeigen.de' in url:
                                # Convert thumbnail to full-size if needed
                                # Kleinanzeigen uses /rule/... for thumbnails
                                if '/rule/' in url:
                                    # Remove rule parameters to get original
                                    url = re.sub(r'/rule/[^/]+/', '/', url)

                                if url not in seen_urls and not url.endswith('.svg'):
                                    seen_urls.add(url)
                                    images.append(url)
                                    if len(images) >= max_images:
                                        break
                        if len(images) >= max_images:
                            break
                    if len(images) >= max_images:
                        break
                except:
                    continue

            # If still no images, try JSON-LD data
            if len(images) < 2:
                try:
                    scripts = self.driver.find_elements(By.CSS_SELECTOR, 'script[type="application/ld+json"]')
                    for script in scripts:
                        data = json.loads(script.get_attribute('innerHTML'))
                        if isinstance(data, dict):
                            # Check for image array
                            img_data = data.get('image', [])
                            if isinstance(img_data, list):
                                for img_url in img_data:
                                    if isinstance(img_url, str) and img_url not in seen_urls:
                                        seen_urls.add(img_url)
                                        images.append(img_url)
                            elif isinstance(img_data, str) and img_data not in seen_urls:
                                seen_urls.add(img_data)
                                images.append(img_data)
                except:
                    pass

            print(f"      [IMG] Found {len(images)} images from detail page")

        except Exception as e:
            print(f"      [IMG ERROR] {str(e)[:50]}")

        finally:
            # Go back to original page
            try:
                self.driver.get(original_url)
                time.sleep(random.uniform(1, 2))
            except:
                pass

        return images if images else []

    def _extract_products_from_page(self) -> List[Dict]:
        """Extract products from current page - UPDATED V2 extraction with stale element fix"""
        products = []

        # Kleinanzeigen product card selectors (updated based on HTML analysis)
        selectors = [
            "article.aditem",
            "article[data-adid]",
            "li[data-adid]",
            ".aditem",
        ]

        # Find items with first matching selector
        items = []
        used_selector = None
        for selector in selectors:
            items = self.driver.find_elements(By.CSS_SELECTOR, selector)
            if items:
                used_selector = selector
                print(f"    [FOUND] Found {len(items)} items with selector: {selector[:40]}...")
                break

        if not items:
            return products

        # Process each item - re-find elements to avoid stale references
        total_items = len(items)
        for idx in range(total_items):
            try:
                # Re-find items to avoid stale element reference
                items_fresh = self.driver.find_elements(By.CSS_SELECTOR, used_selector)
                if idx >= len(items_fresh):
                    break
                item = items_fresh[idx]

                product = {}

                # URL - Get from data-href attribute (most reliable)
                data_href = item.get_attribute('data-href')
                if data_href:
                    product['url'] = self.BASE_URL + data_href if not data_href.startswith('http') else data_href
                else:
                    # Fallback: find link element
                    link_elem = item.find_elements(By.CSS_SELECTOR, "a[href*='/s-anzeige/']")
                    if link_elem:
                        href = link_elem[0].get_attribute('href')
                        if href:
                            product['url'] = href if href.startswith('http') else self.BASE_URL + href

                # Title - from a.ellipsis (most reliable)
                title_elem = item.find_elements(By.CSS_SELECTOR, "a.ellipsis")
                if title_elem and title_elem[0].text.strip():
                    product['title'] = title_elem[0].text.strip()

                # Fallback: try h2 for title
                if not product.get('title'):
                    h2_elem = item.find_elements(By.CSS_SELECTOR, "h2")
                    if h2_elem and h2_elem[0].text.strip():
                        product['title'] = h2_elem[0].text.strip()

                # Fallback: try JSON-LD script for title
                if not product.get('title'):
                    scripts = item.find_elements(By.CSS_SELECTOR, 'script[type="application/ld+json"]')
                    for s in scripts:
                        try:
                            data = json.loads(s.get_attribute('innerHTML'))
                            if data.get('title'):
                                product['title'] = data['title'].strip()
                                break
                        except:
                            pass

                # Price - try multiple selectors
                price_selectors = [
                    ".aditem-main--middle--price-shipping--price",
                    ".aditem-main--middle--price",
                    ".aditem-main--middle p strong",
                    ".aditem-main--middle",
                    "[data-testid='price']",
                    ".price-tag",
                ]

                for price_sel in price_selectors:
                    price_elem = item.find_elements(By.CSS_SELECTOR, price_sel)
                    if price_elem:
                        price_text = price_elem[0].text.strip()
                        if price_text:
                            # Try multiple price patterns
                            # Pattern 1: "115 €" or "115€" or "115 EUR"
                            price_match = re.search(r'(\d+(?:[.,]\d+)?)\s*(?:€|EUR|\u20AC)', price_text)
                            if not price_match:
                                # Pattern 2: Just numbers at start (for price-only elements)
                                price_match = re.search(r'^(\d+(?:[.,]\d+)?)', price_text)
                            if price_match:
                                product['price'] = price_text
                                price_str = price_match.group(1)
                                # German format: 1.234 -> 1234, 80,50 -> 80.50
                                if '.' in price_str and ',' in price_str:
                                    price_str = price_str.replace('.', '').replace(',', '.')
                                elif ',' in price_str:
                                    price_str = price_str.replace(',', '.')
                                elif '.' in price_str and len(price_str.split('.')[-1]) == 3:
                                    # 1.234 format (thousand separator)
                                    price_str = price_str.replace('.', '')
                                try:
                                    val = float(price_str)
                                    if val > 0:  # Only accept positive prices
                                        product['price_value'] = val
                                        break
                                except:
                                    pass

                # Fallback: search all text for price pattern
                if not product.get('price_value'):
                    all_text = item.text
                    # Look for price patterns in all text
                    price_patterns = [
                        r'(\d+(?:[.,]\d+)?)\s*(?:€|EUR|\u20AC)',  # With currency
                        r'(\d+)\s*€',  # Simple "115 €"
                        r'(\d+(?:,\d{2})?)\s*(?:€|EUR)',  # With cents "115,00 €"
                    ]
                    for pattern in price_patterns:
                        price_match = re.search(pattern, all_text)
                        if price_match:
                            product['price'] = price_match.group(0)
                            price_str = price_match.group(1)
                            if '.' in price_str and ',' in price_str:
                                price_str = price_str.replace('.', '').replace(',', '.')
                            elif ',' in price_str:
                                price_str = price_str.replace(',', '.')
                            try:
                                val = float(price_str)
                                if val > 0:
                                    product['price_value'] = val
                                    break
                            except:
                                pass

                # Location - from .aditem-main--top--left
                loc_elem = item.find_elements(By.CSS_SELECTOR, ".aditem-main--top--left")
                if loc_elem:
                    loc_text = loc_elem[0].text.strip()
                    if loc_text:
                        product['location'] = loc_text

                # Image - from img src
                img = item.find_elements(By.CSS_SELECTOR, "img")
                if img:
                    img_src = img[0].get_attribute('src') or img[0].get_attribute('data-src')
                    if img_src:
                        product['image'] = img_src

                # Description - from JSON-LD
                scripts = item.find_elements(By.CSS_SELECTOR, 'script[type="application/ld+json"]')
                for s in scripts:
                    try:
                        data = json.loads(s.get_attribute('innerHTML'))
                        if data.get('description'):
                            product['description'] = data['description'][:200]
                            break
                    except:
                        pass

                # Metadata
                product['platform'] = 'kleinanzeigen'
                product['country'] = 'DE'
                product['scraped_at'] = datetime.now().isoformat()

                # Extract size/brand/color/condition from title/description
                meta = extract_metadata(
                    product.get('title', ''),
                    product.get('description', '')
                )
                product['size'] = meta['size']
                product['brand'] = meta['brand']
                product['color'] = meta['color']
                product['condition'] = meta['condition']

                # Validate: must have URL and title
                if product.get('url') and product.get('title'):
                    products.append(product)

            except Exception as e:
                continue

        print(f"    [EXTRACT] Extracted {len(products)} valid products from {total_items} items")
        return products

    def _go_to_next_page(self, current_page: int) -> bool:
        """Navigate to next page - ENHANCED V3"""
        try:
            # Scroll to bottom first to load pagination
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(2)

            # Method 1: Click pagination button (multiple selectors)
            next_selectors = [
                "a.pagination-next",
                "a[rel='next']",
                ".pagination-pages a:last-child",
                "a[title*='nächste']",
                "a[title*='Nächste']",
                ".pagination a[href*='seite']",
                "nav.pagination a:last-of-type",
                "[data-testid='pagination-next']",
                "a.icon-arrow-right-open",
            ]

            for selector in next_selectors:
                try:
                    buttons = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    for btn in buttons:
                        if btn.is_displayed() and btn.is_enabled():
                            href = btn.get_attribute('href')
                            if href and 'seite' in href.lower():
                                self._robotic_scroll(2)
                                btn.click()
                                print(f"    [->] Clicked next page button: {selector}")
                                time.sleep(3)
                                return True
                except:
                    continue

            # Method 2: URL pagination - Kleinanzeigen format
            current_url = self.driver.current_url
            next_page = current_page + 1

            # Kleinanzeigen URL format: /s-seite:2/tommy+hilfiger/k0
            if '/seite:' in current_url:
                new_url = re.sub(r'/seite:\d+', f'/seite:{next_page}', current_url)
            elif '/s-' in current_url:
                # Insert seite after /s-
                new_url = re.sub(r'(/s-)', f'\\1seite:{next_page}/', current_url)
            else:
                new_url = f"{current_url}/seite:{next_page}"

            print(f"    [->] Navigating to: {new_url[:80]}...")
            self.driver.get(new_url)
            time.sleep(3)

            # Verify page changed
            if self.driver.current_url != current_url:
                print(f"    [OK] Page {next_page} loaded")
                return True
            else:
                print(f"    [WARN] URL didn't change")
                return False

        except Exception as e:
            print(f"    [ERROR] Pagination failed: {e}")
            return False

    def scrape_kleinanzeigen(self, query: str,
                             max_pages: int = 20,
                             visit_random_products: bool = True,
                             fetch_all_images: bool = True) -> List[Dict]:
        """
        Scrape Kleinanzeigen with pagination

        Args:
            query: Search term
            max_pages: Maximum number of pages to scrape
            visit_random_products: Whether to visit random products (more human-like)
            fetch_all_images: Whether to visit each product page to get all images (5+)
        """
        if not self.driver:
            self._init_driver()

        all_results = []
        seen_urls = set()

        print(f"\n{'='*60}")
        print(f"[SHOP] KLEINANZEIGEN - Searching: '{query}'")
        print(f"   Max pages: {max_pages}")
        print(f"   Random product visits: {visit_random_products}")
        print(f"{'='*60}")

        # Build search URL
        search_url = f"{self.BASE_URL}/s-{quote_plus(query)}/k0"

        print(f"   URL: {search_url}")

        # Navigate to search
        self.driver.get(search_url)
        self._random_delay(2, 4)

        # Handle cookies
        self._handle_cookies()
        self._random_delay(1, 2)

        # Paginate through results
        for page in range(1, max_pages + 1):
            print(f"\n   [PAGE] Page {page}/{max_pages}")

            # Wait for page to load
            self._random_delay(1, 3)

            # Human-like scroll
            self._human_scroll()

            # Robotic scroll for remaining content
            self._robotic_scroll(3)

            # Extract products
            products = self._extract_products_from_page()

            # Filter duplicates
            new_products = []
            for p in products:
                url = p.get('url', '')
                if url and url not in seen_urls:
                    seen_urls.add(url)
                    new_products.append(p)

            # Fetch all images from detail pages (if enabled)
            if fetch_all_images and new_products:
                print(f"   [IMAGES] Fetching all images for {len(new_products)} products...")
                current_page_url = self.driver.current_url

                for idx, product in enumerate(new_products):
                    product_url = product.get('url', '')
                    if product_url:
                        print(f"      [{idx+1}/{len(new_products)}] {product.get('title', '')[:30]}...")
                        images = self._get_all_images_from_detail_page(product_url, max_images=10)

                        if images:
                            product['images'] = images
                            product['image'] = images[0]  # First image as main
                            product['image_count'] = len(images)
                        else:
                            # Keep original thumbnail
                            product['images'] = [product.get('image', '')] if product.get('image') else []
                            product['image_count'] = 1

                        # Small delay between product visits
                        time.sleep(random.uniform(0.5, 1.5))

                # Return to search results page
                try:
                    self.driver.get(current_page_url)
                    time.sleep(random.uniform(2, 3))
                except:
                    pass

            all_results.extend(new_products)
            print(f"   [OK] Got {len(new_products)} new products (Total: {len(all_results)})")

            # Visit random products (human behavior) - skip in fast mode
            if visit_random_products and not self.fast_mode and len(new_products) > 0:
                num_visits = random.randint(1, 2)
                print(f"   [BROWSE] Visiting {num_visits} random products...")
                for _ in range(num_visits):
                    self._visit_random_product()
                    self._random_delay(1, 2)

            # Check if we should continue
            if len(new_products) == 0:
                print(f"   [WARN] No new products, stopping pagination")
                break

            # Go to next page
            if page < max_pages:
                if not self._go_to_next_page(page):
                    print(f"   [WARN] No more pages available")
                    break
                self._random_delay(2, 4)

        print(f"\n{'='*60}")
        print(f"[RESULT] KLEINANZEIGEN TOTAL: {len(all_results)} products")
        print(f"   Products visited: {len(self.visited_products)}")
        print(f"   Profiles visited: {len(self.visited_profiles)}")
        print(f"{'='*60}")

        return all_results

    def close(self):
        """Close the driver"""
        if self.driver:
            self.driver.quit()
            self.driver = None
            print("[CLOSE] Driver closed")


# Quick test function
def test_kleinanzeigen():
    """Test Kleinanzeigen scraper with human-like behavior"""
    scraper = KleinanzeigenV2Scraper(headless=False)

    try:
        results = scraper.scrape_kleinanzeigen(
            query="dyson airwrap",
            max_pages=10,
            visit_random_products=True
        )

        print(f"\n[STATS] Test Results:")
        print(f"   Total products: {len(results)}")

        # Save results
        filename = f"kleinanzeigen_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"   Saved to: {filename}")

        if results:
            print(f"\n   Sample product:")
            sample = results[0]
            for k, v in sample.items():
                print(f"      {k}: {v}")

        return results

    finally:
        scraper.close()


if __name__ == "__main__":
    test_kleinanzeigen()
