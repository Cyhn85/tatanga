#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Vinted Enhanced Scraper
Infinite scroll support + better data extraction for higher yield

Problem solved:
- Original connector gets only 10-20 products (no pagination)
- Manual search shows 100+ products
- This enhanced scraper scrolls multiple times to load more products

Features:
- 5x infinite scroll to load 50-100+ products
- Direct data extraction from search grid (not just URLs)
- Condition filtering at extraction time
- Better wait conditions
- Detailed logging for debugging

Author: TATANGA Team
Version: 1.0.0
"""

import sys
import io
import time
import re
import random
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

# Fix Windows console encoding
if sys.platform == 'win32':
    if not isinstance(sys.stdout, io.TextIOWrapper) or sys.stdout.encoding != 'utf-8':
        try:
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        except AttributeError:
            pass

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.logger import get_logger

# Import country-specific configuration
try:
    from integrations.vinted_country_config import get_country_config, get_link_selector, get_url_pattern, get_item_selectors
    COUNTRY_CONFIG_AVAILABLE = True
except ImportError:
    COUNTRY_CONFIG_AVAILABLE = False

logger = get_logger("vinted_enhanced")

# Selenium imports
try:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.common.exceptions import (
        TimeoutException, NoSuchElementException,
        StaleElementReferenceException, WebDriverException
    )
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False
    logger.warning("Selenium not installed")


# ============================================================================
# CONFIGURATION
# ============================================================================

@dataclass
class ScrollConfig:
    """Configuration for infinite scroll behavior"""
    scroll_count: int = 5          # Number of times to scroll
    scroll_delay: float = 1.5      # Seconds between scrolls
    scroll_pause: float = 0.5      # Pause after each scroll
    max_results: int = 100         # Maximum products to return
    wait_for_load: float = 3.0     # Wait for initial page load


# Country domains
VINTED_DOMAINS = {
    'de': 'vinted.de',
    'fr': 'vinted.fr',
    'uk': 'vinted.co.uk',
    'es': 'vinted.es',
    'it': 'vinted.it',
    'nl': 'vinted.nl',
    'be': 'vinted.be',
    'pl': 'vinted.pl',
    'cz': 'vinted.cz',
    'at': 'vinted.at',
    'se': 'vinted.se',
    'dk': 'vinted.dk',
    'no': 'vinted.no',
}

# Currency by country
COUNTRY_CURRENCY = {
    'de': 'EUR', 'fr': 'EUR', 'es': 'EUR', 'it': 'EUR',
    'nl': 'EUR', 'be': 'EUR', 'at': 'EUR',
    'uk': 'GBP',
    'pl': 'PLN',
    'cz': 'CZK',
    'se': 'SEK', 'dk': 'DKK', 'no': 'NOK',
}


# ============================================================================
# VINTED ENHANCED SCRAPER
# ============================================================================

class VintedEnhancedScraper:
    """
    Enhanced Vinted scraper with infinite scroll support

    Key improvements over basic connector:
    1. Multiple scroll cycles to load more products
    2. Direct data extraction from grid (title, price, condition)
    3. Deduplication by product ID
    4. Better logging for debugging
    """

    def __init__(
        self,
        country: str = 'de',
        config: ScrollConfig = None,
        headless: bool = True
    ):
        """
        Initialize enhanced scraper

        Args:
            country: Country code (de, fr, uk, etc.)
            config: Scroll configuration
            headless: Run browser in headless mode
        """
        if country not in VINTED_DOMAINS:
            raise ValueError(f"Unsupported country: {country}")

        self.country = country
        self.domain = VINTED_DOMAINS[country]
        self.base_url = f"https://www.{self.domain}"
        self.currency = COUNTRY_CURRENCY.get(country, 'EUR')
        self.config = config or ScrollConfig()
        self.headless = headless

        # Load country-specific configuration
        if COUNTRY_CONFIG_AVAILABLE:
            self.country_config = get_country_config(country)
            self.link_selector = self.country_config['link_selector']
            self.url_pattern = self.country_config['url_pattern']
            self.item_selectors = self.country_config['item_selectors']
            self.title_selectors = self.country_config['title_selectors']
            self.price_selectors = self.country_config['price_selectors']
            logger.info(f"Loaded country-specific config for {country}",
                       link_selector=self.link_selector,
                       url_pattern=self.url_pattern)
        else:
            # Fallback to default selectors
            self.country_config = None
            self.link_selector = 'a[href*="/items/"]'
            self.url_pattern = r'/items?/(\d+)'
            self.item_selectors = [
                '[data-testid="grid-item"]',
                '.feed-grid__item',
                '[class*="ItemBox"]',
                '[class*="ProductCard"]',
                '.web_ui__ItemBox__item',
                'div[class*="item"]'
            ]
            self.title_selectors = [
                '[data-testid*="title"]',
                '.web_ui__Text__caption',
                'h3', 'h4',
                '[class*="ItemBox__title"]',
                '[class*="title"]'
            ]
            self.price_selectors = [
                '[data-testid*="price"]',
                '.web_ui__Text__title',
                '[class*="price"]',
                '[class*="Price"]'
            ]

        self._driver = None

        # Statistics
        self.stats = {
            'total_scrolls': 0,
            'products_found': 0,
            'products_unique': 0,
            'products_filtered': 0,
            'errors': 0,
        }

        logger.info(f"VintedEnhancedScraper initialized",
                   country=country, domain=self.domain)

    @property
    def driver(self):
        """Lazy initialization of WebDriver"""
        if self._driver is None:
            self._driver = self._create_driver()
        return self._driver

    def _create_driver(self) -> webdriver.Chrome:
        """Create Chrome WebDriver with anti-detection settings"""
        if not SELENIUM_AVAILABLE:
            raise RuntimeError("Selenium not installed")

        options = Options()

        if self.headless:
            options.add_argument('--headless=new')

        # Anti-detection
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_argument('--disable-infobars')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-gpu')
        options.add_argument('--window-size=1920,1080')

        # Random user agent
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        ]
        options.add_argument(f'user-agent={random.choice(user_agents)}')

        options.add_experimental_option('excludeSwitches', ['enable-automation'])
        options.add_experimental_option('useAutomationExtension', False)

        driver = webdriver.Chrome(options=options)

        # Remove webdriver flag
        driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
            'source': '''
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                })
            '''
        })

        logger.info("Enhanced WebDriver created")
        return driver

    def _scroll_page(self) -> int:
        """
        Scroll to bottom of page and wait for new content

        Returns:
            Current scroll position
        """
        # Get current height
        last_height = self.driver.execute_script("return document.body.scrollHeight")

        # Scroll to bottom
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

        # Wait for page to load
        time.sleep(self.config.scroll_delay)

        # Try to wait for new content
        try:
            WebDriverWait(self.driver, 5).until(
                lambda d: d.execute_script("return document.body.scrollHeight") > last_height
            )
        except TimeoutException:
            # No new content loaded, might be at end
            pass

        new_height = self.driver.execute_script("return document.body.scrollHeight")
        self.stats['total_scrolls'] += 1

        return new_height

    def _extract_product_data(self, item_element) -> Optional[Dict]:
        """
        Extract product data directly from search grid item

        Args:
            item_element: Selenium WebElement for product card

        Returns:
            Product dictionary or None if extraction failed
        """
        try:
            # Find link and extract URL + ID using COUNTRY-SPECIFIC selector
            link = None
            url = None

            # Try country-specific link selector first
            try:
                link = item_element.find_element(By.CSS_SELECTOR, self.link_selector)
                url = link.get_attribute('href')
            except NoSuchElementException:
                # Fallback: try multiple patterns
                fallback_selectors = [
                    'a[href*="/item"]',      # Covers both /item/ and /items/
                    'a[href*="/items/"]',
                    'a[href*="/product/"]',
                    'a[href*="/catalog/"]'
                ]
                for sel in fallback_selectors:
                    try:
                        link = item_element.find_element(By.CSS_SELECTOR, sel)
                        url = link.get_attribute('href')
                        if url:
                            break
                    except NoSuchElementException:
                        continue

            if not url:
                return None

            # Extract product ID from URL using COUNTRY-SPECIFIC pattern
            id_match = re.search(self.url_pattern, url)
            product_id = id_match.group(1) if id_match else None

            # Fallback pattern if country-specific didn't match
            if not product_id:
                fallback_patterns = [
                    r'/item(?:s)?/(\d+)',    # /item/123 or /items/123
                    r'/product/(\d+)',
                    r'/(\d{8,})',            # Any long number
                ]
                for pattern in fallback_patterns:
                    id_match = re.search(pattern, url)
                    if id_match:
                        product_id = id_match.group(1)
                        break

            if not product_id:
                return None

            # Try to extract title using COUNTRY-SPECIFIC selectors
            title = None
            for sel in self.title_selectors:
                try:
                    title_el = item_element.find_element(By.CSS_SELECTOR, sel)
                    title = title_el.text.strip()
                    if title:
                        break
                except NoSuchElementException:
                    continue

            # Try to extract price using COUNTRY-SPECIFIC selectors
            price = None
            price_text = None
            for sel in self.price_selectors:
                try:
                    price_el = item_element.find_element(By.CSS_SELECTOR, sel)
                    price_text = price_el.text.strip()
                    if price_text:
                        price = self._parse_price(price_text)
                        break
                except NoSuchElementException:
                    continue

            # Try to extract condition (if visible in grid)
            condition = None
            try:
                # Some grids show condition badge
                cond_el = item_element.find_element(By.CSS_SELECTOR, '[class*="condition"], [class*="badge"]')
                condition = cond_el.text.strip()
            except NoSuchElementException:
                pass

            # Try to extract image
            image_url = None
            try:
                img_el = item_element.find_element(By.CSS_SELECTOR, 'img')
                image_url = img_el.get_attribute('src') or img_el.get_attribute('data-src')
            except NoSuchElementException:
                pass

            return {
                'id': product_id,
                'url': url,
                'title': title or f"Product {product_id}",
                'price': price,
                'price_text': price_text,
                'condition': condition,
                'image': image_url,
                'platform': f'vinted_{self.country}',
                'currency': self.currency,
            }

        except Exception as e:
            logger.debug(f"Failed to extract product data: {e}")
            return None

    def _parse_price(self, price_text: str) -> Optional[float]:
        """Parse price from text"""
        if not price_text:
            return None

        # Remove currency symbols and clean
        cleaned = re.sub(r'[^\d.,]', '', price_text)
        cleaned = cleaned.strip()

        if not cleaned:
            return None

        # Handle European format (comma decimal)
        if ',' in cleaned and '.' in cleaned:
            # Both separators: check which is decimal
            if cleaned.rfind(',') > cleaned.rfind('.'):
                cleaned = cleaned.replace('.', '').replace(',', '.')
            else:
                cleaned = cleaned.replace(',', '')
        elif ',' in cleaned:
            parts = cleaned.split(',')
            if len(parts) == 2 and len(parts[1]) <= 2:
                cleaned = cleaned.replace(',', '.')
            else:
                cleaned = cleaned.replace(',', '')

        try:
            return float(cleaned)
        except ValueError:
            return None

    def search_with_scroll(
        self,
        query: str,
        filters: Dict = None,
        max_results: int = None
    ) -> List[Dict]:
        """
        Search with infinite scroll to get more products

        Args:
            query: Search query
            filters: Optional filters (e.g., condition)
            max_results: Maximum products (default from config)

        Returns:
            List of product dictionaries
        """
        max_results = max_results or self.config.max_results

        logger.info(f"Enhanced search starting",
                   query=query, max_results=max_results,
                   scroll_count=self.config.scroll_count)

        # Build search URL with filters
        search_url = f"{self.base_url}/catalog?search_text={query}"

        # Add condition filter if specified
        if filters and filters.get('condition'):
            condition = filters['condition']
            # Vinted uses status_ids for condition
            # 6 = Neuf avec étiquette, 1 = Neuf sans étiquette, 2 = Très bon état
            condition_map = {
                'new': '6,1',
                'like_new': '1',
                'very_good': '2',
                'good': '3',
                'fair': '4',
            }
            if condition in condition_map:
                search_url += f"&status_ids={condition_map[condition]}"

        try:
            # Load search page
            self.driver.get(search_url)

            # Wait for initial load
            WebDriverWait(self.driver, 15).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )

            time.sleep(self.config.wait_for_load)

            # Accept cookies if present
            try:
                cookie_btn = self.driver.find_element(
                    By.CSS_SELECTOR,
                    '[data-testid="cookie-consent-accept"], [id*="cookie"] button, [class*="cookie"] button'
                )
                cookie_btn.click()
                time.sleep(0.5)
                logger.debug("Cookie popup accepted")
            except NoSuchElementException:
                pass

            all_products = {}  # Use dict for deduplication by ID
            last_count = 0
            no_new_count = 0

            # Scroll multiple times
            for scroll_num in range(self.config.scroll_count):
                logger.debug(f"Scroll {scroll_num + 1}/{self.config.scroll_count}")

                # Extract products from current view using COUNTRY-SPECIFIC selectors
                items_found = []
                for selector in self.item_selectors:
                    try:
                        items_found = self.driver.find_elements(By.CSS_SELECTOR, selector)
                        if items_found:
                            logger.debug(f"Found {len(items_found)} items with selector: {selector}")
                            break
                    except:
                        continue

                # Extract data from each item
                for item in items_found:
                    product = self._extract_product_data(item)
                    if product and product['id'] not in all_products:
                        all_products[product['id']] = product
                        self.stats['products_found'] += 1

                        if len(all_products) >= max_results:
                            break

                if len(all_products) >= max_results:
                    logger.info(f"Reached max_results ({max_results})")
                    break

                # Check if we got new products
                if len(all_products) == last_count:
                    no_new_count += 1
                    if no_new_count >= 2:
                        logger.info("No new products after 2 scrolls, stopping")
                        break
                else:
                    no_new_count = 0
                    last_count = len(all_products)

                # Scroll down
                self._scroll_page()

            self.stats['products_unique'] = len(all_products)

            products = list(all_products.values())

            logger.success(f"Enhanced search completed",
                          query=query,
                          total_found=self.stats['products_found'],
                          unique=len(products),
                          scrolls=self.stats['total_scrolls'])

            return products[:max_results]

        except Exception as e:
            self.stats['errors'] += 1
            logger.error(f"Enhanced search error: {e}")
            return []

    def search_products(self, query: str, max_results: int = 50) -> List[Dict]:
        """
        Compatibility wrapper for universal_scraper

        Args:
            query: Search query
            max_results: Maximum products

        Returns:
            List of product dictionaries
        """
        return self.search_with_scroll(query, max_results=max_results)

    def get_stats(self) -> Dict:
        """Get scraper statistics"""
        return {
            **self.stats,
            'country': self.country,
            'domain': self.domain,
        }

    def close(self):
        """Close WebDriver"""
        if self._driver:
            try:
                self._driver.quit()
            except:
                pass
            self._driver = None

    def __del__(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# ============================================================================
# FACTORY FUNCTION
# ============================================================================

def create_enhanced_scraper(country: str, **kwargs) -> VintedEnhancedScraper:
    """
    Create enhanced Vinted scraper for a country

    Args:
        country: Country code
        **kwargs: Additional arguments

    Returns:
        VintedEnhancedScraper instance
    """
    return VintedEnhancedScraper(country=country, **kwargs)


# ============================================================================
# TEST
# ============================================================================

if __name__ == '__main__':
    print("=" * 70)
    print("TATANGA - Vinted Enhanced Scraper Test")
    print("=" * 70)

    try:
        # Test with German Vinted
        scraper = VintedEnhancedScraper(
            country='de',
            config=ScrollConfig(scroll_count=3, max_results=30),
            headless=True
        )

        print(f"\nSearching for 'timberland stiefel' with 3 scrolls...")
        results = scraper.search_with_scroll("timberland stiefel")

        print(f"\nResults: {len(results)} products found")

        # Show first 5 results
        for i, product in enumerate(results[:5], 1):
            print(f"\n[{i}] {product.get('title', 'N/A')[:50]}")
            print(f"    Price: {product.get('price')} {product.get('currency')}")
            print(f"    URL: {product.get('url', 'N/A')[:60]}...")

        # Show stats
        print("\n" + "=" * 70)
        print("Statistics:")
        stats = scraper.get_stats()
        for key, value in stats.items():
            print(f"  {key}: {value}")

        scraper.close()
        print("\n✓ Test completed!")

    except Exception as e:
        print(f"\n✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
