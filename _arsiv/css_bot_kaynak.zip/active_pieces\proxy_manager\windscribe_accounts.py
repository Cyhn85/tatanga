# Windscribe Hesapları - 5 HESAP = 50GB/AY
# Her hesap için email ve şifre girin
# Boş bırakılan hesaplar kullanılmaz

ACCOUNTS = [
    {
        'id': 'windscribe1',
        'username': 'Cssberlin',  # Windscribe kullanıcı adı
        'email': 'cyhnsrgc@gmail.com',
        'password': 'F@ceb00k2002?',
        'monthly_quota_gb': 10,
        'priority': 1,
    },
    {
        'id': 'windscribe2',
        'username': '',  # Doldurun - Windscribe'a kayıt olunca belirlenir
        'email': 'ceyhuns.sorguc@gmail.com',
        'password': 'F@ceb00k2002?',
        'monthly_quota_gb': 10,
        'priority': 2,
    },
    {
        'id': 'windscribe3',
        'username': '',
        'email': 'ceyhunsabahattinsorguc@gmail.com',
        'password': 'F@cebook2002?',
        'monthly_quota_gb': 10,
        'priority': 3,
    },
    {
        'id': 'windscribe4',
        'username': '',
        'email': 'cssberlin@hotmail.com',
        'password': 'F@ceb00k2002?',
        'monthly_quota_gb': 10,
        'priority': 4,
    },
    {
        'id': 'windscribe5',
        'username': '',
        'email': 'cssberlin36@gmail.com',
        'password': 'F@ceb00k2002?',
        'monthly_quota_gb': 10,
        'priority': 5,
    },
]

# ============================================================================
# AYARLAR
# ============================================================================

# Hesap değiştirme eşiği (MB)
# Kalan kota bu değerin altına düşünce sonraki hesaba geçilir
SWITCH_THRESHOLD_MB = 500

# Günlük kullanım limiti (GB) - tüm hesaplar toplam
DAILY_LIMIT_GB = 5  # 5 hesapla günlük 5GB'a kadar

# Tercih edilen lokasyon (Almanya için)
PREFERRED_LOCATION = 'Germany'  # veya 'Frankfurt'

# ============================================================================
# TOPLAM KOTA HESABI
# ============================================================================
# 5 hesap x 10GB = 50GB/ay
# 1 ürün upload = ~7MB
# 50GB = ~7000 ürün/ay teorik
# Gerçekçi: 15 ürün/gün x 30 gün = 450 ürün/ay = ~3.2GB/ay
# SONUÇ: 50GB ile rahatça 15+ ürün/gün yapılabilir
# ============================================================================
