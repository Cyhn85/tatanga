#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Database Migrations
Sequential database schema updates for TATANGA system
"""

__version__ = "0.0.2"

__all__ = []
