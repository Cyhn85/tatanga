# Initialize Database with Default Store
# Run this once to set up the database with cyhn85 as source store

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.database import db

def init_database():
    """Initialize database with default source store"""
    print("Initializing Vinted Relister Database...")

    # Check if cyhn85 store already exists
    stores = db.get_stores()
    cyhn85_exists = any(s.get('store_name') == 'cyhn85' for s in stores)

    if not cyhn85_exists:
        # Add cyhn85 as default source store
        db.add_store({
            'store_name': 'cyhn85',
            'profile_url': 'https://www.vinted.de/member/293217988',
            'chrome_profile': 'Default',
            'is_source': True,
            'is_active': True,
            'daily_limit': 15,
            'upload_start_hour': 16,
            'upload_end_hour': 17
        })
        print("[OK] Source store 'cyhn85' added")

        # Also add as target (same account relisting)
        db.add_store({
            'store_name': 'cyhn85_target',
            'profile_url': 'https://www.vinted.de/member/293217988',
            'chrome_profile': 'Default',
            'is_source': False,
            'is_active': True,
            'daily_limit': 15,
            'upload_start_hour': 16,
            'upload_end_hour': 17
        })
        print("[OK] Target store 'cyhn85_target' added")
    else:
        print("[OK] Store 'cyhn85' already exists")

    # Show current statistics
    stats = db.get_statistics()
    stores = db.get_stores()

    print("\n" + "="*50)
    print("DATABASE INITIALIZED")
    print("="*50)
    print(f"Total Products: {stats.get('total_products', 0)}")
    print(f"Total Stores: {len(stores)}")
    for store in stores:
        store_type = "SOURCE" if store.get('is_source') else "TARGET"
        print(f"  - {store.get('store_name')} ({store_type})")
    print("="*50)

if __name__ == '__main__':
    init_database()
