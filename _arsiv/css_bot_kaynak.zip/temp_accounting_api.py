"""
TATANGA V3 - Accounting API
Financial tracking and reporting for Kleinunternehmer
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, func, extract
from database import get_db
from models import AccountingEntry, Invoice, Publication
from pydantic import BaseModel
from typing import Optional, List
from datetime import date, datetime
import random
import io
import csv

router = APIRouter()


def generate_acc_id():
    date_str = datetime.now().strftime("%Y%m%d")
    seq = str(random.randint(1, 9999)).zfill(4)
    return f"ACC-{date_str}-{seq}"


def generate_inv_id():
    date_str = datetime.now().strftime("%Y%m%d")
    seq = str(random.randint(1, 9999)).zfill(4)
    return f"INV-{date_str}-{seq}"


class CreateEntryRequest(BaseModel):
    type: str  # income or expense
    category: str
    description: str
    amount: float
    entry_date: date
    platform: Optional[str] = None
    product_id: Optional[int] = None
    tax_relevant: bool = True


class CreateInvoiceRequest(BaseModel):
    customer_name: str
    customer_address: Optional[str] = None
    items: List[dict]  # [{"description": "", "quantity": 1, "unit_price": 10.00}]
    notes: Optional[str] = None


@router.get("/summary")
async def get_accounting_summary(year: Optional[int] = None, db: AsyncSession = Depends(get_db)):
    """Get annual financial summary with Kleinunternehmer tracking"""
    target_year = year or date.today().year

    income_sum = await db.execute(
        select(func.coalesce(func.sum(AccountingEntry.amount), 0))
        .where(AccountingEntry.type == "income")
        .where(extract("year", AccountingEntry.date) == target_year)
    )
    expense_sum = await db.execute(
        select(func.coalesce(func.sum(AccountingEntry.amount), 0))
        .where(AccountingEntry.type == "expense")
        .where(extract("year", AccountingEntry.date) == target_year)
    )

    total_income = float(income_sum.scalar() or 0)
    total_expense = float(expense_sum.scalar() or 0)

    # Get sales from publications
    sales_sum = await db.execute(
        select(func.coalesce(func.sum(Publication.sale_price), 0))
        .where(Publication.status == "sold")
        .where(extract("year", Publication.sold_at) == target_year)
    )
    sales_revenue = float(sales_sum.scalar() or 0)

    return {
        "year": target_year,
        "total_income": total_income,
        "total_expense": total_expense,
        "net_profit": total_income - total_expense,
        "sales_revenue": sales_revenue,
        "kleinunternehmer_limit": 22000,
        "limit_percentage": round((total_income / 22000) * 100, 1) if total_income > 0 else 0,
        "remaining_limit": 22000 - total_income
    }


@router.get("/monthly")
async def get_monthly_breakdown(year: Optional[int] = None, db: AsyncSession = Depends(get_db)):
    """Get monthly breakdown of income and expenses"""
    target_year = year or date.today().year

    months = []
    for month in range(1, 13):
        income_result = await db.execute(
            select(func.coalesce(func.sum(AccountingEntry.amount), 0))
            .where(AccountingEntry.type == "income")
            .where(extract("year", AccountingEntry.date) == target_year)
            .where(extract("month", AccountingEntry.date) == month)
        )
        expense_result = await db.execute(
            select(func.coalesce(func.sum(AccountingEntry.amount), 0))
            .where(AccountingEntry.type == "expense")
            .where(extract("year", AccountingEntry.date) == target_year)
            .where(extract("month", AccountingEntry.date) == month)
        )

        income = float(income_result.scalar() or 0)
        expense = float(expense_result.scalar() or 0)

        months.append({
            "month": month,
            "month_name": datetime(target_year, month, 1).strftime("%B"),
            "income": income,
            "expense": expense,
            "profit": income - expense
        })

    return {"year": target_year, "months": months}


@router.get("/by-platform")
async def get_platform_breakdown(year: Optional[int] = None, db: AsyncSession = Depends(get_db)):
    """Get revenue breakdown by platform"""
    target_year = year or date.today().year

    platforms = ["vinted", "ebay", "kleinanzeigen", "willhaben"]
    result = []

    for platform in platforms:
        # Get sales from publications
        sales_result = await db.execute(
            select(func.count(), func.coalesce(func.sum(Publication.sale_price), 0))
            .where(Publication.platform == platform)
            .where(Publication.status == "sold")
            .where(extract("year", Publication.sold_at) == target_year)
        )
        count, revenue = sales_result.first()

        result.append({
            "platform": platform,
            "sales_count": count or 0,
            "revenue": float(revenue or 0)
        })

    return {"year": target_year, "platforms": result}


@router.get("/entries")
async def get_entries(
    entry_type: Optional[str] = None,
    category: Optional[str] = None,
    year: Optional[int] = None,
    month: Optional[int] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """Get accounting entries with filters"""
    query = select(AccountingEntry).order_by(desc(AccountingEntry.date))
    if entry_type:
        query = query.where(AccountingEntry.type == entry_type)
    if category:
        query = query.where(AccountingEntry.category == category)
    if year:
        query = query.where(extract("year", AccountingEntry.date) == year)
    if month:
        query = query.where(extract("month", AccountingEntry.date) == month)
    query = query.offset(skip).limit(limit)

    result = await db.execute(query)
    return result.scalars().all()


@router.post("/entries")
async def create_entry(request: CreateEntryRequest, db: AsyncSession = Depends(get_db)):
    """Create a new accounting entry"""
    entry = AccountingEntry(
        acc_id=generate_acc_id(),
        type=request.type,
        category=request.category,
        description=request.description,
        amount=request.amount,
        date=request.entry_date,
        platform=request.platform,
        product_id=request.product_id,
        tax_relevant=request.tax_relevant
    )
    db.add(entry)
    await db.commit()
    await db.refresh(entry)
    return {"message": "Entry created", "acc_id": entry.acc_id}


@router.delete("/entries/{entry_id}")
async def delete_entry(entry_id: int, db: AsyncSession = Depends(get_db)):
    """Delete an accounting entry"""
    result = await db.execute(select(AccountingEntry).where(AccountingEntry.id == entry_id))
    entry = result.scalar_one_or_none()
    if not entry:
        raise HTTPException(status_code=404, detail="Entry not found")
    await db.delete(entry)
    await db.commit()
    return {"message": "Entry deleted"}


@router.get("/categories")
async def get_categories():
    """Get available categories for income and expenses"""
    return {
        "income": ["Verkauf", "Sonstiges"],
        "expense": ["Einkauf", "Versand", "Verpackung", "Transport", "Software", "Buero", "Sonstiges"]
    }


# Invoice Management
@router.get("/invoices")
async def get_invoices(
    year: Optional[int] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """Get all invoices"""
    query = select(Invoice).order_by(desc(Invoice.created_at))
    if year:
        query = query.where(extract("year", Invoice.created_at) == year)
    query = query.offset(skip).limit(limit)

    result = await db.execute(query)
    return result.scalars().all()


@router.post("/invoices")
async def create_invoice(request: CreateInvoiceRequest, db: AsyncSession = Depends(get_db)):
    """Create a new invoice"""
    # Calculate totals
    subtotal = sum(item.get("quantity", 1) * item.get("unit_price", 0) for item in request.items)

    invoice = Invoice(
        inv_id=generate_inv_id(),
        customer_name=request.customer_name,
        customer_address=request.customer_address,
        items=request.items,
        subtotal=subtotal,
        total=subtotal,  # Kleinunternehmer - no VAT
        notes=request.notes,
        status="draft"
    )
    db.add(invoice)
    await db.commit()
    await db.refresh(invoice)

    return {"message": "Invoice created", "inv_id": invoice.inv_id, "total": subtotal}


@router.get("/invoices/{invoice_id}")
async def get_invoice(invoice_id: int, db: AsyncSession = Depends(get_db)):
    """Get invoice details"""
    result = await db.execute(select(Invoice).where(Invoice.id == invoice_id))
    invoice = result.scalar_one_or_none()
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return invoice


@router.patch("/invoices/{invoice_id}/status")
async def update_invoice_status(
    invoice_id: int,
    status: str,
    db: AsyncSession = Depends(get_db)
):
    """Update invoice status (draft, sent, paid)"""
    result = await db.execute(select(Invoice).where(Invoice.id == invoice_id))
    invoice = result.scalar_one_or_none()
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")

    invoice.status = status
    if status == "paid":
        invoice.paid_at = datetime.utcnow()

    await db.commit()
    return {"message": "Invoice status updated"}


@router.get("/export/csv")
async def export_entries_csv(
    year: Optional[int] = None,
    db: AsyncSession = Depends(get_db)
):
    """Export accounting entries as CSV"""
    target_year = year or date.today().year

    query = select(AccountingEntry).where(
        extract("year", AccountingEntry.date) == target_year
    ).order_by(AccountingEntry.date)

    result = await db.execute(query)
    entries = result.scalars().all()

    # Create CSV
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Datum", "Typ", "Kategorie", "Beschreibung", "Betrag", "Plattform", "Steuerrelevant"])

    for entry in entries:
        writer.writerow([
            entry.date.isoformat() if entry.date else "",
            entry.type,
            entry.category,
            entry.description,
            f"{entry.amount:.2f}",
            entry.platform or "",
            "Ja" if entry.tax_relevant else "Nein"
        ])

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=buchhaltung_{target_year}.csv"}
    )


@router.get("/tax-report")
async def get_tax_report(year: Optional[int] = None, db: AsyncSession = Depends(get_db)):
    """Get tax report summary for EÜR (Einnahmen-Überschuss-Rechnung)"""
    target_year = year or date.today().year

    # Tax-relevant income
    income_result = await db.execute(
        select(func.coalesce(func.sum(AccountingEntry.amount), 0))
        .where(AccountingEntry.type == "income")
        .where(AccountingEntry.tax_relevant == True)
        .where(extract("year", AccountingEntry.date) == target_year)
    )

    # Tax-relevant expenses by category
    expense_by_category = {}
    categories = ["Einkauf", "Versand", "Verpackung", "Transport", "Software", "Buero", "Sonstiges"]

    for category in categories:
        cat_result = await db.execute(
            select(func.coalesce(func.sum(AccountingEntry.amount), 0))
            .where(AccountingEntry.type == "expense")
            .where(AccountingEntry.category == category)
            .where(AccountingEntry.tax_relevant == True)
            .where(extract("year", AccountingEntry.date) == target_year)
        )
        expense_by_category[category] = float(cat_result.scalar() or 0)

    total_income = float(income_result.scalar() or 0)
    total_expenses = sum(expense_by_category.values())

    return {
        "year": target_year,
        "report_type": "EÜR",
        "total_income": total_income,
        "expenses_by_category": expense_by_category,
        "total_expenses": total_expenses,
        "profit": total_income - total_expenses,
        "kleinunternehmer_status": total_income <= 22000,
        "note": "Gemäß § 19 UStG - Kleinunternehmerregelung" if total_income <= 22000 else "Umsatzsteuerpflicht!"
    }
