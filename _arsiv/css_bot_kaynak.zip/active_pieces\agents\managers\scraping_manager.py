#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Scraping Manager
Manages 36 parallel scraping operations across all platforms

Features:
- 36 platform scraping coordination
- Hybrid scraping: API → Selenium → Screenshot+Vision fallback
- Parallel execution with rate limiting
- Country-specific language and grammar support
- Adaptive selector learning
- Session management

Author: TATANGA Team
Version: 1.0
"""

import sys
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")


class ScrapingManager:
    """
    Scraping Manager - Coordinates all 36 platform scraping operations

    Responsibilities:
    1. Manage scraper instances for each platform
    2. Execute parallel scraping with rate limiting
    3. Handle fallback strategies (API → Selenium → Screenshot)
    4. Track success/failure rates per platform
    5. Adaptive selector learning
    """

    def __init__(self, ceo_agent):
        """
        Initialize Scraping Manager

        Args:
            ceo_agent: Reference to CEO Agent
        """
        self.ceo = ceo_agent
        self.logger = ModuleLogger("scraping_manager")

        # Scraper instances
        self.scrapers: Dict[str, Any] = {}
        self.scraper_status: Dict[str, Dict] = {}

        # Execution control
        self.executor = ThreadPoolExecutor(max_workers=6)  # 6 parallel scrapers
        self.active_tasks: Dict[str, asyncio.Task] = {}
        self.running = False
        self.lock = threading.Lock()

        # Rate limiting per platform
        self.rate_limits = {
            'vinted': 2.0,      # 2 seconds between requests
            'ebay': 1.5,        # 1.5 seconds
            'shpock': 3.0,      # 3 seconds (more restrictive)
            'kleinanzeigen': 2.0,
            'willhaben': 2.0,
            'leboncoin': 2.0,
            'default': 2.0
        }

        # Statistics
        self.stats = {
            'total_scrapes': 0,
            'successful': 0,
            'failed': 0,
            'by_platform': {}
        }

        # Vision Agent for screenshot fallback
        self.vision_agent = None

        self.logger.info("Scraping Manager initialized")

    async def initialize_scrapers(self):
        """Initialize all platform scrapers"""
        platforms = self.ceo.PLATFORMS

        for platform_id, config in platforms.items():
            try:
                scraper = await self._create_scraper(platform_id, config)
                self.scrapers[platform_id] = scraper
                self.scraper_status[platform_id] = {
                    'status': 'idle',
                    'last_run': None,
                    'success_count': 0,
                    'error_count': 0,
                    'last_error': None
                }
            except Exception as e:
                self.logger.error(f"Failed to create scraper for {platform_id}", exception=str(e))

        self.logger.info(f"Initialized {len(self.scrapers)} scrapers")

    async def _create_scraper(self, platform_id: str, config: Dict) -> Any:
        """
        Create a scraper instance for a platform

        Args:
            platform_id: Platform identifier (e.g., 'vinted_de')
            config: Platform configuration

        Returns:
            Scraper instance
        """
        platform_type = config['platform']

        try:
            if platform_type == 'vinted':
                from integrations.vinted_enhanced import VintedEnhancedScraper
                return VintedEnhancedScraper(country=config['country'])

            elif platform_type == 'ebay':
                from integrations.ebay_multicountry_connector import EbayMultiCountryConnector
                return EbayMultiCountryConnector(marketplace=platform_id)

            elif platform_type == 'shpock':
                from integrations.shpock_connector import ShpockConnector
                return ShpockConnector(country=config['country'])

            elif platform_type == 'kleinanzeigen':
                from integrations.kleinanzeigen_connector import KleinanzeigenConnector
                return KleinanzeigenConnector()

            elif platform_type == 'willhaben':
                from integrations.willhaben_connector import WillhabenConnector
                return WillhabenConnector()

            elif platform_type == 'leboncoin':
                from integrations.leboncoin_connector import LeboncoinConnector
                return LeboncoinConnector()

            else:
                # Generic scraper for other platforms
                from integrations.universal_scraper import UniversalScraper
                return UniversalScraper(platform=platform_id)

        except ImportError as e:
            self.logger.warning(f"Scraper not available for {platform_id}: {e}")
            return None

    async def execute_scrape(self,
                            platform: str,
                            query: str,
                            limit: int = 50,
                            filters: Dict = None) -> Dict:
        """
        Execute scraping operation for a platform

        Args:
            platform: Platform ID
            query: Search query
            limit: Max results
            filters: Additional filters

        Returns:
            Scraping result
        """
        if platform not in self.scrapers:
            return {
                'success': False,
                'error': f'Scraper not available for {platform}',
                'platform': platform
            }

        scraper = self.scrapers[platform]
        if scraper is None:
            return {
                'success': False,
                'error': f'Scraper not initialized for {platform}',
                'platform': platform
            }

        self.scraper_status[platform]['status'] = 'running'
        start_time = datetime.now()

        try:
            # Try primary scraping method
            results = await self._execute_with_fallback(
                scraper=scraper,
                platform=platform,
                query=query,
                limit=limit,
                filters=filters
            )

            # Update statistics
            self.stats['total_scrapes'] += 1
            self.stats['successful'] += 1

            if platform not in self.stats['by_platform']:
                self.stats['by_platform'][platform] = {'success': 0, 'failed': 0}
            self.stats['by_platform'][platform]['success'] += 1

            self.scraper_status[platform].update({
                'status': 'idle',
                'last_run': datetime.now().isoformat(),
                'success_count': self.scraper_status[platform]['success_count'] + 1
            })

            duration = (datetime.now() - start_time).total_seconds()

            return {
                'success': True,
                'platform': platform,
                'query': query,
                'count': len(results),
                'results': results,
                'duration_seconds': duration
            }

        except Exception as e:
            self.stats['total_scrapes'] += 1
            self.stats['failed'] += 1

            if platform not in self.stats['by_platform']:
                self.stats['by_platform'][platform] = {'success': 0, 'failed': 0}
            self.stats['by_platform'][platform]['failed'] += 1

            self.scraper_status[platform].update({
                'status': 'error',
                'error_count': self.scraper_status[platform]['error_count'] + 1,
                'last_error': str(e)
            })

            self.logger.error(f"Scrape failed for {platform}", exception=str(e))

            return {
                'success': False,
                'platform': platform,
                'error': str(e)
            }

    async def _execute_with_fallback(self,
                                     scraper: Any,
                                     platform: str,
                                     query: str,
                                     limit: int,
                                     filters: Dict) -> List[Dict]:
        """
        Execute scraping with fallback strategies

        Strategy:
        1. API (if available)
        2. Selenium
        3. Screenshot + Vision AI (fallback)
        """
        # Method 1: Try API first
        if hasattr(scraper, 'search_api'):
            try:
                results = await self._run_in_executor(
                    scraper.search_api, query, limit, filters
                )
                if results:
                    self.logger.info(f"API scrape successful for {platform}")
                    return results
            except Exception as e:
                self.logger.warning(f"API method failed for {platform}: {e}")

        # Method 2: Try Selenium/Browser
        if hasattr(scraper, 'search') or hasattr(scraper, 'search_products'):
            try:
                search_method = getattr(scraper, 'search_products', None) or scraper.search
                results = await self._run_in_executor(
                    search_method, query, limit
                )
                if results:
                    self.logger.info(f"Selenium scrape successful for {platform}")
                    return results
            except Exception as e:
                self.logger.warning(f"Selenium method failed for {platform}: {e}")

        # Method 3: Screenshot + Vision AI fallback
        self.logger.info(f"Attempting screenshot fallback for {platform}")
        return await self._screenshot_fallback(scraper, platform, query, limit)

    async def _screenshot_fallback(self,
                                   scraper: Any,
                                   platform: str,
                                   query: str,
                                   limit: int) -> List[Dict]:
        """
        Fallback: Take screenshot and use Vision AI to extract data

        Args:
            scraper: Scraper instance
            platform: Platform ID
            query: Search query
            limit: Max results

        Returns:
            Extracted products
        """
        if not self.vision_agent:
            try:
                from agents.vision_agent import VisionAgent
                self.vision_agent = VisionAgent()
            except ImportError:
                self.logger.warning("Vision Agent not available for fallback")
                return []

        try:
            # Get platform config
            config = self.ceo.PLATFORMS.get(platform, {})
            language = config.get('language', 'en')

            # Take screenshot of search results
            screenshot = await self._take_search_screenshot(scraper, query)
            if not screenshot:
                return []

            # Use Vision AI to detect product URLs
            product_urls = await self.vision_agent.detect_product_urls(
                screenshot=screenshot,
                platform=platform
            )

            # Extract data from each product page
            products = []
            for url in product_urls[:limit]:
                product_screenshot = await self._take_product_screenshot(scraper, url)
                if product_screenshot:
                    product_data = await self.vision_agent.extract_product_data(
                        screenshot=product_screenshot,
                        language=language
                    )
                    if product_data:
                        product_data['url'] = url
                        product_data['platform'] = platform
                        products.append(product_data)

            self.logger.info(f"Screenshot fallback found {len(products)} products for {platform}")
            return products

        except Exception as e:
            self.logger.error(f"Screenshot fallback failed for {platform}", exception=str(e))
            return []

    async def _take_search_screenshot(self, scraper: Any, query: str) -> Optional[bytes]:
        """Take screenshot of search results page"""
        if hasattr(scraper, 'take_screenshot'):
            return await self._run_in_executor(scraper.take_screenshot, 'search', query)
        return None

    async def _take_product_screenshot(self, scraper: Any, url: str) -> Optional[bytes]:
        """Take screenshot of product page"""
        if hasattr(scraper, 'take_screenshot'):
            return await self._run_in_executor(scraper.take_screenshot, 'product', url)
        return None

    async def _run_in_executor(self, func, *args):
        """Run synchronous function in executor"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(self.executor, func, *args)

    # ==================== PARALLEL OPERATIONS ====================

    async def scrape_all_platforms(self, query: str, limit: int = 50) -> Dict:
        """
        Scrape all platforms in parallel

        Args:
            query: Search query
            limit: Max results per platform

        Returns:
            Combined results
        """
        self.logger.info(f"Starting parallel scrape on {len(self.scrapers)} platforms")

        tasks = []
        for platform_id in self.scrapers.keys():
            task = asyncio.create_task(
                self.execute_scrape(platform_id, query, limit)
            )
            tasks.append((platform_id, task))

        results = {}
        total_products = 0

        for platform_id, task in tasks:
            try:
                result = await task
                results[platform_id] = result
                if result.get('success'):
                    total_products += result.get('count', 0)
            except Exception as e:
                results[platform_id] = {'success': False, 'error': str(e)}

        return {
            'success': True,
            'platforms_scraped': len(results),
            'total_products': total_products,
            'results': results
        }

    async def scrape_by_platform_type(self, platform_type: str, query: str, limit: int = 50) -> Dict:
        """
        Scrape all countries for a specific platform type

        Args:
            platform_type: Platform type (vinted, ebay, etc.)
            query: Search query
            limit: Max results

        Returns:
            Combined results
        """
        platforms = [
            p for p, c in self.ceo.PLATFORMS.items()
            if c['platform'] == platform_type
        ]

        tasks = []
        for platform_id in platforms:
            if platform_id in self.scrapers:
                task = asyncio.create_task(
                    self.execute_scrape(platform_id, query, limit)
                )
                tasks.append((platform_id, task))

        results = {}
        for platform_id, task in tasks:
            try:
                result = await task
                results[platform_id] = result
            except Exception as e:
                results[platform_id] = {'success': False, 'error': str(e)}

        return {
            'platform_type': platform_type,
            'platforms_scraped': len(results),
            'results': results
        }

    # ==================== CONTROL ====================

    async def stop_all(self):
        """Stop all scraping operations"""
        self.running = False

        for task in self.active_tasks.values():
            task.cancel()

        self.active_tasks.clear()
        self.logger.info("All scraping operations stopped")

    def get_status(self) -> Dict:
        """Get manager status"""
        active_count = sum(
            1 for s in self.scraper_status.values()
            if s['status'] == 'running'
        )

        return {
            'status': 'running' if self.running else 'idle',
            'scrapers_total': len(self.scrapers),
            'scrapers_active': active_count,
            'stats': self.stats,
            'platform_status': {
                k: v['status'] for k, v in self.scraper_status.items()
            }
        }

    def get_platform_stats(self, platform: str) -> Optional[Dict]:
        """Get statistics for a specific platform"""
        if platform in self.scraper_status:
            return {
                **self.scraper_status[platform],
                'stats': self.stats['by_platform'].get(platform, {})
            }
        return None


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("SCRAPING MANAGER TEST")
    print("=" * 60)

    class MockCEO:
        PLATFORMS = {
            'vinted_de': {'platform': 'vinted', 'country': 'de', 'language': 'de-DE'},
            'vinted_fr': {'platform': 'vinted', 'country': 'fr', 'language': 'fr-FR'},
        }

    async def test():
        ceo = MockCEO()
        manager = ScrapingManager(ceo)

        print(f"\nStatus: {manager.get_status()}")
        print(f"Rate limits: {manager.rate_limits}")

        print("\n✅ Scraping Manager test complete!")

    asyncio.run(test())
    print("=" * 60)
