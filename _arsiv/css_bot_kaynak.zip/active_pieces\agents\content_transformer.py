#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Content Transformer Agent
Ürün içeriğini CSS Berlin için optimize eder

- Almanca SEO uyumlu başlık
- Zengin ürün açıklaması
- Fiyat stratejisi (kar marjı)
- Meta tags ve SEO
"""

import re
import json
from pathlib import Path
from datetime import datetime
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

# Streamlit-safe logger - don't use core.logger in Streamlit context
class SimpleLogger:
    """Simple print-based logger that works in Streamlit"""
    def __init__(self, name):
        self.name = name
    def info(self, msg, **kwargs):
        pass  # Suppress in Streamlit
    def success(self, msg, **kwargs):
        pass  # Suppress in Streamlit
    def error(self, msg, **kwargs):
        pass  # Suppress in Streamlit
    def warning(self, msg, **kwargs):
        pass  # Suppress in Streamlit

logger = SimpleLogger("content_transformer")


# ==================== BRAND DATABASE ====================

BRAND_INFO = {
    "timberland": {
        "full_name": "Timberland",
        "category": "Schuhe",
        "subcategory": "Stiefel",
        "keywords": ["boots", "stiefel", "waterproof", "leder", "outdoor"],
        "target_audience": "Herren",
        "premium": True
    },
    "nike": {
        "full_name": "Nike",
        "category": "Schuhe",
        "subcategory": "Sneaker",
        "keywords": ["sneaker", "sportschuhe", "running", "lifestyle"],
        "target_audience": "Unisex",
        "premium": True
    },
    "adidas": {
        "full_name": "Adidas",
        "category": "Schuhe",
        "subcategory": "Sneaker",
        "keywords": ["sneaker", "sportschuhe", "originals", "lifestyle"],
        "target_audience": "Unisex",
        "premium": True
    },
    "zara": {
        "full_name": "Zara",
        "category": "Kleidung",
        "subcategory": "Fashion",
        "keywords": ["mode", "fashion", "casual", "elegant"],
        "target_audience": "Damen",
        "premium": False
    },
    "h&m": {
        "full_name": "H&M",
        "category": "Kleidung",
        "subcategory": "Fashion",
        "keywords": ["mode", "casual", "basic", "trend"],
        "target_audience": "Unisex",
        "premium": False
    },
    "levis": {
        "full_name": "Levi's",
        "category": "Kleidung",
        "subcategory": "Jeans",
        "keywords": ["jeans", "denim", "klassisch", "vintage"],
        "target_audience": "Unisex",
        "premium": True
    },
    "gucci": {
        "full_name": "Gucci",
        "category": "Luxus",
        "subcategory": "Designer",
        "keywords": ["luxus", "designer", "premium", "italien"],
        "target_audience": "Unisex",
        "premium": True
    },
    "prada": {
        "full_name": "Prada",
        "category": "Luxus",
        "subcategory": "Designer",
        "keywords": ["luxus", "designer", "premium", "italien"],
        "target_audience": "Unisex",
        "premium": True
    }
}

# ==================== CONDITION MAPPING ====================

CONDITION_DE = {
    "new": "Neu mit Etikett",
    "new with tags": "Neu mit Etikett",
    "like new": "Neuwertig",
    "very good": "Sehr gut",
    "good": "Gut",
    "fair": "Akzeptabel",
    "pre-owned": "Gebraucht",
    "pre-owned - good": "Gebraucht - Gut",
    "pre-owned - very good": "Gebraucht - Sehr gut",
    "used": "Gebraucht",
    None: "Guter Zustand"
}

# ==================== PRICE STRATEGY ====================

def calculate_selling_price(purchase_price: float, condition: str = None, brand: str = None) -> dict:
    """
    Satış fiyatı hesapla

    Args:
        purchase_price: Alış fiyatı
        condition: Ürün durumu
        brand: Marka

    Returns:
        dict: {selling_price, margin_percent, profit}
    """
    # Base margin
    base_margin = 0.40  # 40%

    # Marka premium ise margin artır
    brand_lower = (brand or "").lower()
    if brand_lower in BRAND_INFO and BRAND_INFO[brand_lower].get("premium"):
        base_margin += 0.15  # +15% premium markalar için

    # Durum bazlı ayarlama
    condition_lower = (condition or "").lower()
    if "new" in condition_lower or "neu" in condition_lower:
        base_margin += 0.10  # Yeni ürünler +10%
    elif "very good" in condition_lower or "sehr gut" in condition_lower:
        base_margin += 0.05

    # Fiyat aralığına göre ayarlama
    if purchase_price < 20:
        base_margin += 0.20  # Düşük fiyatlı ürünlerde daha yüksek margin
    elif purchase_price > 100:
        base_margin -= 0.10  # Pahalı ürünlerde daha düşük margin

    # Min/max margin
    base_margin = max(0.30, min(0.70, base_margin))

    # Hesapla
    selling_price = round(purchase_price * (1 + base_margin), 2)

    # 9.99 formatına yuvarla
    selling_price = round(selling_price) - 0.01
    if selling_price < purchase_price:
        selling_price = purchase_price + 9.99

    profit = selling_price - purchase_price

    return {
        "selling_price": selling_price,
        "margin_percent": round(base_margin * 100, 1),
        "profit": round(profit, 2),
        "purchase_price": purchase_price
    }


# ==================== CONTENT TRANSFORMER ====================

class ContentTransformer:
    """
    Ürün içeriğini CSS Berlin için optimize eder
    """

    def __init__(self):
        self.brand_db = BRAND_INFO
        self.condition_map = CONDITION_DE

    def detect_brand(self, title: str, brand_field: str = None) -> str:
        """Markayı tespit et"""
        # Önce brand field'dan
        if brand_field:
            return brand_field.strip()

        # Title'dan tespit
        title_lower = title.lower()
        for brand_key, brand_info in self.brand_db.items():
            if brand_key in title_lower:
                return brand_info["full_name"]

        return None

    def detect_category(self, title: str, brand: str = None) -> dict:
        """Kategori tespit et"""
        title_lower = title.lower()

        # Marka bilgisinden
        if brand:
            brand_lower = brand.lower()
            if brand_lower in self.brand_db:
                info = self.brand_db[brand_lower]
                return {
                    "category": info["category"],
                    "subcategory": info["subcategory"],
                    "target_audience": info["target_audience"]
                }

        # Önce hedef kitleyi belirle (Damen/Herren/Kinder kelimeleri)
        target_audience = "Unisex"
        if any(w in title_lower for w in ["damen", "frauen", "women", "lady", "ladies", "femme"]):
            target_audience = "Damen"
        elif any(w in title_lower for w in ["herren", "männer", "men", "homme", "herr"]):
            target_audience = "Herren"
        elif any(w in title_lower for w in ["kinder", "kids", "jungen", "mädchen", "baby", "enfant"]):
            target_audience = "Kinder"

        # Keyword bazlı kategori tespit
        if any(w in title_lower for w in ["boot", "stiefel", "schuh", "shoe", "sneaker"]):
            return {"category": "Schuhe", "subcategory": "Sneaker", "target_audience": target_audience}
        elif any(w in title_lower for w in ["jacke", "jacket", "coat", "mantel"]):
            return {"category": "Kleidung", "subcategory": "Jacken", "target_audience": target_audience}
        elif any(w in title_lower for w in ["hose", "jeans", "pants", "trousers"]):
            return {"category": "Kleidung", "subcategory": "Hosen", "target_audience": target_audience}
        elif any(w in title_lower for w in ["hemd", "shirt", "bluse", "top"]):
            return {"category": "Kleidung", "subcategory": "Oberteile", "target_audience": target_audience}
        elif any(w in title_lower for w in ["tasche", "bag", "rucksack", "backpack"]):
            return {"category": "Accessoires", "subcategory": "Taschen", "target_audience": target_audience}

        return {"category": "Sonstiges", "subcategory": "Allgemein", "target_audience": target_audience}

    def translate_condition(self, condition: str) -> str:
        """Durumu Almancaya çevir"""
        if not condition:
            return self.condition_map[None]

        condition_lower = condition.lower().strip()
        for key, value in self.condition_map.items():
            if key and key in condition_lower:
                return value

        return self.condition_map[None]

    def generate_seo_title(self, original_title: str, brand: str = None, category_info: dict = None) -> str:
        """
        SEO uyumlu Almanca başlık oluştur

        Format: {Brand} {Product Type} {Key Features} | {Category}
        """
        parts = []

        # Marka
        if brand:
            parts.append(brand)

        # Orijinal başlıktan önemli kelimeleri çıkar
        # Gereksiz kelimeleri temizle
        clean_title = original_title
        remove_words = ["original", "authentic", "100%", "neu", "new", "vintage", "retro"]
        for word in remove_words:
            clean_title = re.sub(rf'\b{word}\b', '', clean_title, flags=re.IGNORECASE)

        # Başlığı ekle (50 karaktere kısalt)
        clean_title = clean_title.strip()
        if len(clean_title) > 50:
            clean_title = clean_title[:50].rsplit(' ', 1)[0]

        if clean_title and clean_title.lower() != (brand or "").lower():
            parts.append(clean_title)

        # Kategori ekle
        if category_info:
            parts.append(f"| {category_info.get('category', '')}")

        title = " ".join(parts).strip()

        # Maksimum 70 karakter (SEO)
        if len(title) > 70:
            title = title[:70].rsplit(' ', 1)[0]

        return title

    def generate_description(self, product_data: dict, brand: str = None, category_info: dict = None) -> str:
        """
        Zengin ürün açıklaması oluştur
        """
        lines = []

        # Başlık
        lines.append(f"<h3>{product_data.get('title', 'Produkt')}</h3>")
        lines.append("")

        # Açıklama paragrafı
        if brand:
            brand_info = self.brand_db.get(brand.lower(), {})
            if brand_info:
                lines.append(f"<p>Original {brand} Produkt in ausgezeichnetem Zustand. ")
                if brand_info.get("premium"):
                    lines.append("Premium-Qualität garantiert.</p>")
                else:
                    lines.append("Qualität zum fairen Preis.</p>")
        else:
            lines.append("<p>Hochwertiges Second-Hand Produkt in gutem Zustand.</p>")

        lines.append("")

        # Ürün detayları
        lines.append("<h4>Produktdetails:</h4>")
        lines.append("<ul>")

        if brand:
            lines.append(f"<li><strong>Marke:</strong> {brand}</li>")

        condition = self.translate_condition(product_data.get('condition'))
        lines.append(f"<li><strong>Zustand:</strong> {condition}</li>")

        if category_info:
            lines.append(f"<li><strong>Kategorie:</strong> {category_info.get('category', 'Sonstiges')}</li>")

        if product_data.get('location'):
            lines.append(f"<li><strong>Herkunft:</strong> {product_data.get('location')}</li>")

        lines.append("</ul>")
        lines.append("")

        # Kargo bilgisi
        lines.append("<h4>Versand:</h4>")
        lines.append("<p>Schneller und sicherer Versand aus Berlin. ")
        lines.append("Lieferung innerhalb von 2-4 Werktagen.</p>")
        lines.append("")

        # CSS Berlin bilgisi
        lines.append("<hr>")
        lines.append("<p><em>Dieses Produkt wurde sorgfältig von CSS Berlin ausgewählt und geprüft. ")
        lines.append("Nachhaltigkeit trifft auf Stil.</em></p>")

        return "\n".join(lines)

    def generate_meta_tags(self, product_data: dict, brand: str = None, category_info: dict = None) -> dict:
        """
        SEO meta tags oluştur
        """
        title = product_data.get('title', 'Produkt')

        # Meta description (max 160 karakter)
        desc_parts = []
        if brand:
            desc_parts.append(f"{brand}")
        desc_parts.append(title[:50])
        desc_parts.append("günstig kaufen bei CSS Berlin")
        desc_parts.append("Second-Hand Mode aus Berlin")

        meta_description = " - ".join(desc_parts)
        if len(meta_description) > 160:
            meta_description = meta_description[:157] + "..."

        # Keywords
        keywords = ["second hand", "gebraucht", "berlin", "nachhaltig"]
        if brand:
            keywords.insert(0, brand.lower())
        if category_info:
            keywords.append(category_info.get("category", "").lower())
            keywords.append(category_info.get("subcategory", "").lower())

        return {
            "meta_title": f"{title} | CSS Berlin",
            "meta_description": meta_description,
            "keywords": ", ".join(keywords),
            "og_title": title,
            "og_description": meta_description
        }

    def transform(self, product_data: dict) -> dict:
        """
        Tam ürün transformasyonu

        Args:
            product_data: Ham ürün verisi

        Returns:
            dict: Optimize edilmiş ürün verisi
        """
        logger.info(f"Transforming: {product_data.get('title', 'Unknown')[:50]}...")

        # Marka tespit
        brand = self.detect_brand(
            product_data.get('title', ''),
            product_data.get('brand')
        )

        # Kategori tespit
        category_info = self.detect_category(
            product_data.get('title', ''),
            brand
        )

        # Durum çevirisi
        condition_de = self.translate_condition(product_data.get('condition'))

        # SEO başlık
        seo_title = self.generate_seo_title(
            product_data.get('title', ''),
            brand,
            category_info
        )

        # Zengin açıklama
        description = self.generate_description(product_data, brand, category_info)

        # Meta tags
        meta = self.generate_meta_tags(product_data, brand, category_info)

        # Fiyat stratejisi
        price_info = calculate_selling_price(
            product_data.get('price', 0),
            product_data.get('condition'),
            brand
        )

        # Sonuç
        transformed = {
            # Orijinal veriler (referans)
            "original_title": product_data.get('title'),
            "original_price": product_data.get('price'),
            "source_url": product_data.get('link') or product_data.get('url'),
            "source_platform": product_data.get('platform'),

            # Transform edilmiş veriler
            "title": seo_title,
            "description": description,
            "price": price_info["selling_price"],
            "currency": product_data.get('currency', 'EUR'),

            # Meta
            "brand": brand,
            "condition": condition_de,
            "category": category_info.get("category"),
            "subcategory": category_info.get("subcategory"),
            "target_audience": category_info.get("target_audience"),

            # SEO
            "meta_title": meta["meta_title"],
            "meta_description": meta["meta_description"],
            "keywords": meta["keywords"],

            # Görseller
            "image": product_data.get('image'),
            "images": product_data.get('images', []),
            "image_count": len(product_data.get('images', [])) or 1,

            # Fiyat bilgisi
            "price_info": price_info,

            # Metadata
            "location": product_data.get('location'),
            "shipping_cost": product_data.get('shipping_cost', 0),
            "transformed_at": datetime.now().isoformat(),
            "source": "tatanga_transform"
        }

        logger.success(f"Transformed: {seo_title[:50]}... | Price: {price_info['purchase_price']}€ -> {price_info['selling_price']}€")

        return transformed


# ==================== CONVENIENCE FUNCTION ====================

def transform_product(product_data: dict) -> dict:
    """
    Ürünü transform et (kısa yol)
    """
    transformer = ContentTransformer()
    return transformer.transform(product_data)


# ==================== TEST ====================

if __name__ == '__main__':
    print("=" * 60)
    print("TATANGA - Content Transformer Test")
    print("=" * 60)

    transformer = ContentTransformer()

    # Test ürün
    test_product = {
        "title": "Timberland",
        "price": 50.0,
        "currency": "EUR",
        "platform": "vinted_de",
        "link": "https://vinted.de/item/123",
        "image": "https://example.com/image.jpg",
        "condition": "good",
        "brand": None,
        "location": "Berlin"
    }

    print("\n[INPUT]")
    print(json.dumps(test_product, indent=2, ensure_ascii=False))

    result = transformer.transform(test_product)

    print("\n[OUTPUT]")
    print(f"Title: {result['title']}")
    print(f"Price: {result['original_price']}€ -> {result['price']}€ (+{result['price_info']['margin_percent']}%)")
    print(f"Brand: {result['brand']}")
    print(f"Category: {result['category']} > {result['subcategory']}")
    print(f"Condition: {result['condition']}")
    print(f"\nMeta Title: {result['meta_title']}")
    print(f"Meta Desc: {result['meta_description'][:100]}...")

    print("\n" + "=" * 60)
    print("Test with Nike product:")

    test_product2 = {
        "title": "Nike Air Max 90 White Sneakers Size 42",
        "price": 35.0,
        "currency": "EUR",
        "platform": "ebay_de",
        "condition": "pre-owned - very good",
        "brand": "Nike"
    }

    result2 = transformer.transform(test_product2)
    print(f"Title: {result2['title']}")
    print(f"Price: {result2['original_price']}€ -> {result2['price']}€")
    print(f"Condition: {result2['condition']}")
