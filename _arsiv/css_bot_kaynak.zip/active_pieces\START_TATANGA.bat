@echo off
chcp 65001 >nul
title TATANGA Enterprise - Launcher

echo ============================================================
echo    TATANGA Enterprise v2.0 - Launcher
echo    Self-Healing Autonomous Scraping System
echo ============================================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python bulunamadi! Lutfen Python yukleyin.
    pause
    exit /b 1
)

REM Change to active_pieces directory
cd /d "%~dp0"

echo [1/3] API Sunucusu baslatiliyor (port 8080)...
start "TATANGA API" cmd /k "cd /d %~dp0 && python api\triaj_api.py"

REM Wait for API to start
timeout /t 3 /nobreak >nul

echo [2/3] Dashboard baslatiliyor (port 8501)...
start "TATANGA Dashboard" cmd /k "cd /d %~dp0 && streamlit run ui\triaj_dashboard.py --server.port 8501"

echo [3/3] Sistem hazirlaniyor...
timeout /t 5 /nobreak >nul

echo.
echo ============================================================
echo    TATANGA Enterprise AKTIF
echo ============================================================
echo.
echo    Dashboard:     http://localhost:8501
echo    API:           http://localhost:8080
echo    Health Check:  http://localhost:8080/health
echo    API Docs:      http://localhost:8080/docs
echo.
echo    Orchestrator otomatik olarak basladi ve
echo    Event Bus'tan gelen kazima taleplerini dinliyor.
echo.
echo    Kapatmak icin acik pencereleri kapatin.
echo ============================================================

REM Open browser
timeout /t 2 /nobreak >nul
start http://localhost:8501

pause
