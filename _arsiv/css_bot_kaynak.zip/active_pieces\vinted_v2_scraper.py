# -*- coding: utf-8 -*-
"""
VINTED V2 SCRAPER - Pagination + Robotic + Extended Delays
==========================================================
- Multi-country support: DE, FR, IT, NL, BE
- Pagination: Max 10 pages per filter combination
- Extended delays: +5 seconds between actions
- Robotic scroll patterns
- RANDOM PRODUCT VISITS - like a real user
- USER PROFILE VISITS - browse seller profiles
- Condition filters: sehr gut, gut
- Cookie consent handling
- Target: 1200+ products
"""

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import time
import random
import json
from typing import List, Dict, Optional
from datetime import datetime
import re
import sys
import io

# Safe stdout wrapper for Windows - skip if already wrapped or in special environment
if sys.platform == 'win32':
    try:
        if hasattr(sys.stdout, 'buffer') and not isinstance(sys.stdout, io.TextIOWrapper):
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    except (AttributeError, ValueError, OSError):
        pass

class VintedV2Scraper:
    """
    Vinted V2 - Enhanced scraper with pagination and robotic behavior
    Includes: random product visits, seller profile browsing
    """

    # Vinted domains per country
    VINTED_DOMAINS = {
        'de': 'https://www.vinted.de',
        'fr': 'https://www.vinted.fr',
        'it': 'https://www.vinted.it',
        'nl': 'https://www.vinted.nl',
        'be': 'https://www.vinted.be',
    }

    # Condition filter IDs (zustand/etat/condizione)
    CONDITION_FILTERS = {
        'sehr_gut': '&status_ids[]=2',       # Very good / Tres bon etat
        'gut': '&status_ids[]=3',            # Good / Bon etat
        'neu_mit_etikett': '&status_ids[]=6', # New with tags
        'neu_ohne_etikett': '&status_ids[]=1', # New without tags
    }

    def __init__(self, headless: bool = False, fast_mode: bool = False):
        self.headless = headless
        self.fast_mode = fast_mode  # Skip random visits, faster delays
        self.driver = None
        self.all_products = []
        self.base_delay = 3 if fast_mode else 7  # Fast: 3s, Normal: 7s
        self.visited_products = set()
        self.visited_profiles = set()

    def _random_delay(self, min_extra: float = 0, max_extra: float = 3) -> None:
        """Extended random delay with Gaussian distribution"""
        base = self.base_delay
        extra = random.gauss((min_extra + max_extra) / 2, (max_extra - min_extra) / 4)
        extra = max(min_extra, min(max_extra, extra))
        delay = base + extra
        print(f"    [WAIT] {delay:.1f}s...")
        time.sleep(delay)

    def _human_scroll(self) -> None:
        """Human-like scroll pattern - smooth and variable"""
        print(f"    [SCROLL] Human scroll pattern...")

        total_height = self.driver.execute_script("return document.body.scrollHeight")
        current_position = 0
        viewport_height = self.driver.execute_script("return window.innerHeight")

        while current_position < total_height:
            # Variable scroll amount (human-like)
            scroll_amount = random.randint(200, 500)

            # Scroll down
            self.driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
            current_position += scroll_amount

            # Random pause (reading time)
            time.sleep(random.uniform(0.5, 1.2))

            # Occasionally scroll up a bit (reconsidering)
            if random.random() < 0.2:
                back_scroll = random.randint(50, 150)
                self.driver.execute_script(f"window.scrollBy(0, -{back_scroll});")
                current_position -= back_scroll
                time.sleep(random.uniform(0.3, 0.7))

            # Occasionally pause longer (reading an item)
            if random.random() < 0.15:
                time.sleep(random.uniform(1.5, 3))

            # Update total height (infinite scroll might load more)
            total_height = self.driver.execute_script("return document.body.scrollHeight")

        # Scroll back to top partially
        self.driver.execute_script(f"window.scrollTo(0, {random.randint(100, 500)});")
        time.sleep(0.5)

    def _robotic_scroll(self, scroll_count: int = 5) -> None:
        """Robotic scroll pattern to load lazy content"""
        print(f"    [ROBOT] Robotic scroll ({scroll_count}x)...")

        for i in range(scroll_count):
            scroll_amount = random.randint(300, 700)
            self.driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
            time.sleep(random.uniform(0.8, 1.5))

            if random.random() < 0.3:
                self.driver.execute_script(f"window.scrollBy(0, -{random.randint(50, 150)});")
                time.sleep(random.uniform(0.3, 0.6))

        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(1.5)

    def _visit_random_product(self) -> Optional[Dict]:
        """
        Visit a random product like a real user would
        Browse the product, maybe check seller profile
        """
        print("    [BROWSE] Browsing a random product...")

        try:
            # Find product cards
            items = self.driver.find_elements(By.CSS_SELECTOR,
                ".feed-grid__item a[href*='/item'], .feed-grid__item a[href*='/artikel'], [data-testid='grid-item'] a"
            )

            if not items:
                return None

            # Pick random item
            random_item = random.choice(items)
            product_url = random_item.get_attribute('href')

            if not product_url or product_url in self.visited_products:
                return None

            self.visited_products.add(product_url)

            # Click and visit product
            original_url = self.driver.current_url
            random_item.click()

            time.sleep(random.uniform(3, 5))

            # Scroll around on product page (reading)
            for _ in range(random.randint(2, 4)):
                self.driver.execute_script(f"window.scrollBy(0, {random.randint(150, 350)});")
                time.sleep(random.uniform(0.8, 1.5))

            # Extract product details while we're here
            product_details = self._extract_product_details()

            # Maybe visit seller profile (30% chance)
            if random.random() < 0.3:
                self._visit_seller_profile()

            # Go back to search results
            self.driver.get(original_url)
            time.sleep(random.uniform(2, 4))

            return product_details

        except Exception as e:
            print(f"    [WARN] Product visit failed: {e}")
            try:
                self.driver.back()
                time.sleep(2)
            except:
                pass
            return None

    def _extract_product_details(self) -> Dict:
        """Extract details from product page"""
        details = {}

        try:
            # Title
            title_el = self.driver.find_elements(By.CSS_SELECTOR,
                "[data-testid='item-title'], h1[class*='title'], .ItemDetails h1"
            )
            if title_el:
                details['title'] = title_el[0].text.strip()

            # Price
            price_el = self.driver.find_elements(By.CSS_SELECTOR,
                "[data-testid='item-price'], [class*='ItemPrice'], .item-price"
            )
            if price_el:
                details['price'] = price_el[0].text.strip()

            # Description
            desc_el = self.driver.find_elements(By.CSS_SELECTOR,
                "[data-testid='item-description'], [class*='description'], .item-description"
            )
            if desc_el:
                details['description'] = desc_el[0].text.strip()[:500]

            # Condition
            cond_el = self.driver.find_elements(By.CSS_SELECTOR,
                "[data-testid='item-condition'], [class*='condition'], .item-attributes"
            )
            if cond_el:
                details['condition'] = cond_el[0].text.strip()

            details['url'] = self.driver.current_url

        except Exception as e:
            print(f"    [WARN] Details extraction error: {e}")

        return details

    def _visit_seller_profile(self) -> None:
        """
        Visit seller profile from product page
        Browse around like checking seller reputation
        """
        print("    [USER] Checking seller profile...")

        try:
            # Find seller link
            seller_links = self.driver.find_elements(By.CSS_SELECTOR,
                "a[href*='/member/'], a[href*='/membre/'], a[href*='/profil/'], [data-testid='seller-link']"
            )

            if not seller_links:
                return

            seller_link = seller_links[0]
            seller_url = seller_link.get_attribute('href')

            if seller_url in self.visited_profiles:
                return

            self.visited_profiles.add(seller_url)

            # Click seller profile
            product_url = self.driver.current_url
            seller_link.click()

            time.sleep(random.uniform(3, 5))

            # Scroll around profile (checking seller items/reviews)
            for _ in range(random.randint(2, 3)):
                self.driver.execute_script(f"window.scrollBy(0, {random.randint(200, 400)});")
                time.sleep(random.uniform(0.8, 1.2))

            # Pause like reading reviews
            time.sleep(random.uniform(2, 4))

            # Go back to product
            self.driver.get(product_url)
            time.sleep(random.uniform(2, 3))

        except Exception as e:
            print(f"    [WARN] Profile visit failed: {e}")

    def _handle_cookies(self) -> None:
        """Handle cookie consent popup"""
        print("    [COOKIE] Checking for cookie consent...")

        cookie_selectors = [
            "button[id*='accept']",
            "button[class*='accept']",
            "[data-testid='cookie-accept']",
            "#onetrust-accept-btn-handler",
            ".cookie-consent-accept",
            "button[id*='cookie']",
        ]

        # Also try by button text
        cookie_texts = ['Akzeptieren', 'Accepter', 'Accetta', 'Accepteren', 'Accept', 'OK']

        for selector in cookie_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for elem in elements:
                    if elem.is_displayed():
                        elem.click()
                        print(f"    [OK] Cookie accepted via: {selector[:30]}...")
                        time.sleep(2)
                        return
            except:
                continue

        # Try by text
        for text in cookie_texts:
            try:
                elements = self.driver.find_elements(By.XPATH, f"//button[contains(text(), '{text}')]")
                for elem in elements:
                    if elem.is_displayed():
                        elem.click()
                        print(f"    [OK] Cookie accepted via text: {text}")
                        time.sleep(2)
                        return
            except:
                continue

    def _init_driver(self) -> None:
        """Initialize undetected Chrome driver"""
        print("[START] Initializing Chrome driver...")

        options = uc.ChromeOptions()

        if self.headless:
            options.add_argument('--headless=new')

        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_argument('--window-size=1920,1080')
        options.add_argument('--lang=de-DE')

        # Random user agent
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        ]
        options.add_argument(f'--user-agent={random.choice(user_agents)}')

        # Use webdriver-manager to get correct chromedriver version
        driver_path = ChromeDriverManager().install()
        self.driver = uc.Chrome(options=options, driver_executable_path=driver_path)
        self.driver.implicitly_wait(10)
        print("[OK] Driver initialized")

    def _extract_products_from_page(self, country: str) -> List[Dict]:
        """Extract products from current page"""
        products = []
        domain = self.VINTED_DOMAINS[country]

        # Vinted product card selectors
        selectors = [
            ".feed-grid__item",
            "[data-testid='grid-item']",
            ".ItemBox_container__",
            ".feed-grid .feed-grid__item",
            "div[class*='ItemBox']",
        ]

        items = []
        for selector in selectors:
            items = self.driver.find_elements(By.CSS_SELECTOR, selector)
            if items:
                print(f"    [FOUND] {len(items)} items with selector: {selector[:40]}...")
                break

        for item in items:
            try:
                product = {}

                # URL - Get this first, it's the most reliable
                # Vinted uses: <a href="/items/123-title" class="new-item-box__overlay">
                link = item.find_elements(By.CSS_SELECTOR, "a.new-item-box__overlay, a[href*='/items/'], a[href*='/artikel/'], a")
                if link:
                    for lnk in link:
                        href = lnk.get_attribute('href') or ''
                        if '/items/' in href or '/artikel/' in href:
                            product['url'] = href if href.startswith('http') else domain + href
                            break
                    # Fallback: any vinted link
                    if not product.get('url'):
                        href = link[0].get_attribute('href') or ''
                        if href and 'vinted' in href:
                            product['url'] = href if href.startswith('http') else domain + href

                # Title - Get from img alt attribute (contains full product info)
                # Format: "Title, marke: Brand, zustand: Condition, Price"
                img = item.find_elements(By.CSS_SELECTOR, "img")
                if img:
                    alt_text = img[0].get_attribute('alt') or ''
                    if alt_text:
                        # Extract just the title part (before first comma or "marke:")
                        if ', marke:' in alt_text.lower():
                            product['title'] = alt_text.split(', marke:')[0].strip()
                        elif ',' in alt_text:
                            product['title'] = alt_text.split(',')[0].strip()
                        else:
                            product['title'] = alt_text[:100].strip()

                        # Extract price from alt text (format: "380,00 EUR" or "380,00 eur")
                        price_match = re.search(r'([\d.,]+)\s*(?:EUR|eur|\u20ac)', alt_text)
                        if price_match:
                            price_str = price_match.group(1).replace('.', '').replace(',', '.')
                            try:
                                product['price_value'] = float(price_str)
                                product['price'] = f"{product['price_value']:.2f} EUR"
                            except:
                                pass

                    # Image URL
                    product['image'] = img[0].get_attribute('src') or img[0].get_attribute('data-src')

                # Fallback: Try to get title from link title attribute
                if not product.get('title') and link:
                    title_attr = link[0].get_attribute('title') or ''
                    if title_attr:
                        if ', marke:' in title_attr.lower():
                            product['title'] = title_attr.split(', marke:')[0].strip()
                        else:
                            product['title'] = title_attr[:100].strip()

                # Fallback price from visible text
                if not product.get('price'):
                    all_text = item.text
                    # Look for price pattern like "380,00 EUR" or "380,00 eur"
                    price_match = re.search(r'([\d.,]+)\s*(?:EUR|\u20ac)', all_text)
                    if price_match:
                        price_str = price_match.group(1).replace('.', '').replace(',', '.')
                        try:
                            product['price_value'] = float(price_str)
                            product['price'] = f"{product['price_value']:.2f} EUR"
                        except:
                            pass

                # Brand extraction from alt text
                if img:
                    alt_text = img[0].get_attribute('alt') or ''
                    brand_match = re.search(r'marke:\s*([^,]+)', alt_text, re.IGNORECASE)
                    if brand_match:
                        product['brand'] = brand_match.group(1).strip()

                    # Condition extraction
                    condition_match = re.search(r'zustand:\s*([^,]+)', alt_text, re.IGNORECASE)
                    if condition_match:
                        product['condition'] = condition_match.group(1).strip()

                # Metadata
                product['platform'] = f'vinted_{country}'
                product['country'] = country.upper()
                product['scraped_at'] = datetime.now().isoformat()

                # Only add if we have URL (title optional now since we can get it from URL)
                if product.get('url'):
                    # If no title, extract from URL slug
                    if not product.get('title'):
                        url_parts = product['url'].split('/')
                        for part in url_parts:
                            if '-' in part and part[0].isdigit():
                                # Format: 7659397520-dyson-coanda-airwrap
                                slug = part.split('-', 1)[1] if '-' in part else part
                                product['title'] = slug.replace('-', ' ').title()
                                break

                    if product.get('title'):
                        products.append(product)

            except Exception as e:
                continue

        return products

    def _go_to_next_page(self, current_page: int) -> bool:
        """Navigate to next page"""
        try:
            # Method 1: Click pagination button
            next_buttons = self.driver.find_elements(By.CSS_SELECTOR,
                "[data-testid='pagination-next'], a[rel='next'], .pagination__next, button[aria-label*='Next'], button[aria-label*='Weiter'], a[aria-label*='Next']"
            )

            for btn in next_buttons:
                if btn.is_displayed() and btn.is_enabled():
                    self._robotic_scroll(2)
                    btn.click()
                    print(f"    [->] Clicked next page button")
                    return True

            # Method 2: URL pagination
            current_url = self.driver.current_url
            if 'page=' in current_url:
                new_url = re.sub(r'page=\d+', f'page={current_page + 1}', current_url)
            else:
                separator = '&' if '?' in current_url else '?'
                new_url = f"{current_url}{separator}page={current_page + 1}"

            self.driver.get(new_url)
            print(f"    [->] Navigated to page {current_page + 1} via URL")
            return True

        except Exception as e:
            print(f"    [ERROR] Pagination failed: {e}")
            return False

    def scrape_vinted(self, query: str, country: str = 'de',
                      max_pages: int = 10,
                      conditions: List[str] = ['sehr_gut', 'gut'],
                      visit_random_products: bool = True) -> List[Dict]:
        """
        Scrape Vinted with pagination and filters

        Args:
            query: Search term
            country: Country code (de, fr, it, nl, be)
            max_pages: Max pages per filter (Vinted limit is 10)
            conditions: List of condition filters to use
            visit_random_products: Whether to visit random products (more human-like)
        """
        if not self.driver:
            self._init_driver()

        domain = self.VINTED_DOMAINS.get(country)
        if not domain:
            print(f"[ERROR] Unknown country: {country}")
            return []

        all_results = []
        seen_urls = set()

        print(f"\n{'='*60}")
        print(f"[VINTED] {country.upper()} - Searching: '{query}'")
        print(f"   Conditions: {conditions}")
        print(f"   Max pages per filter: {max_pages}")
        print(f"   Random product visits: {visit_random_products}")
        print(f"{'='*60}")

        # Iterate through each condition filter
        for condition in conditions:
            condition_filter = self.CONDITION_FILTERS.get(condition, '')

            print(f"\n[FILTER] {condition}")

            # Build search URL
            search_url = f"{domain}/catalog?search_text={query}&order=newest_first{condition_filter}"

            print(f"   URL: {search_url[:80]}...")

            # Navigate to search
            self.driver.get(search_url)
            self._random_delay(2, 4)

            # Handle cookies on first load
            if len(all_results) == 0:
                self._handle_cookies()
                self._random_delay(1, 2)

            # Paginate through results
            for page in range(1, max_pages + 1):
                print(f"\n   [PAGE] {page}/{max_pages}")

                # Wait for page to load
                self._random_delay(1, 3)

                # Human-like scroll to load all items
                self._human_scroll()

                # Robotic scroll for remaining content
                self._robotic_scroll(3)

                # Extract products
                products = self._extract_products_from_page(country)

                # Filter duplicates
                new_products = []
                for p in products:
                    url = p.get('url', '')
                    if url and url not in seen_urls:
                        seen_urls.add(url)
                        p['condition_filter'] = condition
                        new_products.append(p)

                all_results.extend(new_products)
                print(f"   [OK] Got {len(new_products)} new products (Total: {len(all_results)})")

                # Visit random products (human behavior) - skip in fast_mode
                if visit_random_products and not self.fast_mode and len(new_products) > 0:
                    num_visits = random.randint(1, 3)
                    print(f"   [BROWSE] Visiting {num_visits} random products...")
                    for _ in range(num_visits):
                        self._visit_random_product()
                        self._random_delay(1, 2)

                # Check if we should continue
                if len(new_products) == 0:
                    print(f"   [WARN] No new products, moving to next filter")
                    break

                # Go to next page
                if page < max_pages:
                    if not self._go_to_next_page(page):
                        print(f"   [WARN] No more pages available")
                        break
                    self._random_delay(2, 4)

        print(f"\n{'='*60}")
        print(f"[RESULT] VINTED {country.upper()} TOTAL: {len(all_results)} products")
        print(f"   Products visited: {len(self.visited_products)}")
        print(f"   Profiles visited: {len(self.visited_profiles)}")
        print(f"{'='*60}")

        return all_results

    def scrape_all_countries(self, query: str,
                             countries: List[str] = ['de', 'fr', 'it', 'nl', 'be'],
                             max_pages: int = 10,
                             conditions: List[str] = ['sehr_gut', 'gut']) -> Dict:
        """
        Scrape all Vinted countries

        Returns dict with results per country and combined
        """
        if not self.driver:
            self._init_driver()

        results = {
            'query': query,
            'timestamp': datetime.now().isoformat(),
            'countries': {},
            'all_products': [],
            'total_count': 0
        }

        print(f"\n{'#'*60}")
        print(f"# VINTED MULTI-COUNTRY SCRAPER V2")
        print(f"# Query: {query}")
        print(f"# Countries: {', '.join(countries)}")
        print(f"# Target: 1200+ products")
        print(f"{'#'*60}")

        for country in countries:
            try:
                country_products = self.scrape_vinted(
                    query=query,
                    country=country,
                    max_pages=max_pages,
                    conditions=conditions,
                    visit_random_products=True
                )

                results['countries'][country] = {
                    'count': len(country_products),
                    'products': country_products
                }
                results['all_products'].extend(country_products)

                # Delay between countries
                if country != countries[-1]:
                    print(f"\n[WAIT] Waiting before next country...")
                    time.sleep(random.uniform(10, 15))

            except Exception as e:
                print(f"[ERROR] Error scraping {country}: {e}")
                results['countries'][country] = {
                    'count': 0,
                    'products': [],
                    'error': str(e)
                }

        results['total_count'] = len(results['all_products'])

        print(f"\n{'#'*60}")
        print(f"# FINAL RESULTS")
        print(f"#")
        for country, data in results['countries'].items():
            print(f"#   {country.upper()}: {data['count']} products")
        print(f"#")
        print(f"# TOTAL: {results['total_count']} products")
        print(f"{'#'*60}")

        return results

    def close(self):
        """Close the driver"""
        if self.driver:
            self.driver.quit()
            self.driver = None
            print("[CLOSE] Driver closed")


# Quick test function
def test_vinted_de():
    """Test Vinted DE scraper with human-like behavior"""
    scraper = VintedV2Scraper(headless=False)

    try:
        results = scraper.scrape_vinted(
            query="dyson airwrap",
            country='de',
            max_pages=5,
            conditions=['sehr_gut', 'gut'],
            visit_random_products=True
        )

        print(f"\n[STATS] Test Results:")
        print(f"   Total products: {len(results)}")

        # Save results
        with open('vinted_de_test.json', 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"   Saved to: vinted_de_test.json")

        if results:
            print(f"\n   Sample product:")
            sample = results[0]
            for k, v in sample.items():
                print(f"      {k}: {v}")

    finally:
        scraper.close()

    return results


def test_all_countries():
    """Test all Vinted countries"""
    scraper = VintedV2Scraper(headless=False)

    try:
        results = scraper.scrape_all_countries(
            query="dyson airwrap",
            countries=['de', 'fr', 'it', 'nl', 'be'],
            max_pages=10,
            conditions=['sehr_gut', 'gut']
        )

        # Save results
        filename = f"vinted_all_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"\n[SAVE] Saved to: {filename}")

        return results

    finally:
        scraper.close()


if __name__ == "__main__":
    # Run single country test first
    test_vinted_de()
