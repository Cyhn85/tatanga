<template>
  <div>
    <h1 class="text-3xl font-bold mb-6">Kazima</h1>

    <!-- System Health Panel -->
    <div class="bg-white rounded-lg shadow p-4 mb-6">
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-4">
          <span class="text-sm font-medium text-gray-700">Sistem Durumu:</span>
          <div class="flex items-center gap-2">
            <span class="w-3 h-3 rounded-full" :class="health.status === 'healthy' ? 'bg-green-500' : 'bg-yellow-500'"></span>
            <span class="text-sm" :class="health.status === 'healthy' ? 'text-green-600' : 'text-yellow-600'">
              {{ health.status === 'healthy' ? 'Tum sistemler aktif' : 'Kontrol ediliyor...' }}
            </span>
          </div>
        </div>
        <div class="flex items-center gap-4 text-sm text-gray-500">
          <span>Aktif isler: {{ stats.activeJobs }}</span>
          <span>|</span>
          <span>Toplam urun: {{ stats.products }}</span>
          <span>|</span>
          <span>Favoriler: {{ stats.favorites }}</span>
          <button @click="loadHealth" class="text-blue-600 hover:text-blue-800 ml-2">Yenile</button>
        </div>
      </div>
    </div>

    <!-- Live Progress Panel -->
    <div v-if="activeJobs.length > 0" class="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg shadow-lg p-6 mb-6 border-2 border-blue-200">
      <div class="flex items-center gap-3 mb-4">
        <div class="animate-spin w-6 h-6 border-4 border-blue-500 border-t-transparent rounded-full"></div>
        <h2 class="text-xl font-bold text-blue-800">Canli Kazima Islemi</h2>
        <span class="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-bold">{{ activeJobs.length }} aktif is</span>
      </div>

      <div class="space-y-4">
        <div v-for="job in activeJobs" :key="job.job_id" class="bg-white rounded-lg p-4 shadow">
          <div class="flex items-center justify-between mb-2">
            <div class="flex items-center gap-3">
              <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-lg text-sm font-bold uppercase">{{ job.platform }}</span>
              <span class="font-medium text-gray-800">{{ job.search_term }}</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="text-sm text-gray-500">{{ job.job_id }}</span>
              <button @click="cancelJob(job.job_id)" class="text-red-500 hover:text-red-700 text-sm font-medium">Durdur</button>
            </div>
          </div>

          <!-- Progress Bar -->
          <div class="relative h-4 bg-gray-200 rounded-full overflow-hidden">
            <div class="absolute inset-0 bg-gradient-to-r from-blue-400 via-blue-500 to-blue-600 animate-pulse"
                 :style="{ width: getJobProgress(job) + '%' }"></div>
            <div class="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"></div>
          </div>

          <div class="flex justify-between mt-2 text-sm">
            <span class="text-gray-500">
              <template v-if="job.result_count > 0">
                <span class="text-green-600 font-bold">{{ job.result_count }}</span> urun bulundu
              </template>
              <template v-else>
                Arama yapiliyor...
              </template>
            </span>
            <span class="text-gray-400">{{ formatTime(job.started_at) }} baslatildi</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Search Form -->
    <div class="bg-white rounded-lg shadow p-6 mb-6">
      <h2 class="text-xl font-bold mb-4">Yeni Arama</h2>

      <!-- Platform Selection -->
      <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 mb-2">Platformlar</label>
        <div class="flex flex-wrap gap-4">
          <label v-for="platform in availablePlatforms" :key="platform.id"
                 class="flex items-center gap-2 bg-gray-50 px-4 py-2 rounded-lg cursor-pointer hover:bg-gray-100"
                 :class="{ 'bg-blue-100 border-blue-500': selectedPlatforms.includes(platform.id) }">
            <input type="checkbox" :value="platform.id" v-model="selectedPlatforms" class="w-4 h-4" />
            <span class="font-medium">{{ platform.name }}</span>
            <span class="text-xs text-gray-500">{{ platform.country }}</span>
          </label>
        </div>
      </div>

      <!-- Arama Kelimesi -->
      <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 mb-1">Arama Kelimesi *</label>
        <input v-model="form.query" type="text" placeholder="ornek: Nike Air Max, tommy hilfiger pullover"
               class="w-full border rounded px-4 py-2 focus:ring-2 focus:ring-blue-500 text-lg" />
      </div>

      <!-- Advanced Filters -->
      <div class="border-t pt-4 mt-4">
        <h3 class="text-sm font-medium text-gray-700 mb-3">Gelismis Filtreler</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm text-gray-600 mb-1">Min Fiyat (EUR)</label>
            <input v-model="form.min_price" type="number" min="0" step="0.01" class="w-full border rounded px-4 py-2" />
          </div>
          <div>
            <label class="block text-sm text-gray-600 mb-1">Max Fiyat (EUR)</label>
            <input v-model="form.max_price" type="number" min="0" step="0.01" class="w-full border rounded px-4 py-2" />
          </div>
        </div>

        <!-- Condition Checkboxes (Multi-select) -->
        <div class="mt-4">
          <label class="block text-sm font-medium text-gray-700 mb-2">Urun Durumu (coklu secim)</label>
          <div class="flex flex-wrap gap-3">
            <label v-for="cond in availableConditions" :key="cond.value"
                   class="flex items-center gap-2 px-4 py-2 rounded-lg cursor-pointer border-2 transition-all"
                   :class="selectedConditions.includes(cond.value)
                     ? 'bg-green-100 border-green-500 text-green-800'
                     : 'bg-gray-50 border-gray-200 hover:border-gray-300'">
              <input type="checkbox" :value="cond.value" v-model="selectedConditions" class="w-4 h-4 text-green-600" />
              <span class="font-medium">{{ cond.label }}</span>
              <span class="text-xs text-gray-500">({{ cond.german }})</span>
            </label>
          </div>
          <p class="text-xs text-gray-400 mt-1">Tradera icin Isvecce ceviri otomatik uygulanir</p>
        </div>

        <!-- Sort -->
        <div class="mt-4">
          <label class="block text-sm text-gray-600 mb-1">Siralama</label>
          <select v-model="form.sort" class="w-full md:w-1/4 border rounded px-4 py-2">
            <option value="relevance">Alaka</option>
            <option value="price_asc">Fiyat (Artan)</option>
            <option value="price_desc">Fiyat (Azalan)</option>
            <option value="newest">En Yeni</option>
          </select>
        </div>
      </div>

      <button @click="startScrape" :disabled="!form.query || selectedPlatforms.length === 0 || loading"
              class="mt-4 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-bold">
        {{ loading ? "Araniyor..." : "Aramayi Baslat (" + selectedPlatforms.length + " platform)" }}
      </button>
    </div>

    <!-- Recent Jobs -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
      <div class="p-4 border-b flex justify-between items-center">
        <h2 class="text-xl font-bold">Son Aramalar</h2>
        <div class="flex gap-2">
          <button @click="loadJobs" class="text-blue-600 hover:text-blue-800 px-3 py-1 border rounded">Yenile</button>
          <button v-if="jobs.length > 0" @click="deleteAllJobs"
                  class="text-red-600 hover:text-red-800 px-3 py-1 border border-red-300 rounded hover:bg-red-50">
            Tumunu Sil
          </button>
        </div>
      </div>
      <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
          <tr>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Is ID</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Platform</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Arama</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Filtreler</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Durum</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sonuc</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Islem</th>
          </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
          <tr v-for="job in jobs" :key="job.id" class="hover:bg-gray-50">
            <td class="px-4 py-3 text-sm font-mono">{{ job.job_id }}</td>
            <td class="px-4 py-3 text-sm">
              <span class="px-2 py-1 bg-gray-100 rounded text-xs">{{ job.platform }}</span>
            </td>
            <td class="px-4 py-3 text-sm font-medium">{{ job.search_term }}</td>
            <td class="px-4 py-3 text-xs text-gray-500">
              <span v-if="job.min_price || job.max_price">{{ job.min_price || 0 }}-{{ job.max_price || 'inf' }} EUR</span>
            </td>
            <td class="px-4 py-3">
              <span class="px-2 py-1 text-xs rounded-full" :class="getStatusClass(job.status)">
                {{ getStatusText(job.status) }}
              </span>
            </td>
            <td class="px-4 py-3 text-sm font-bold">{{ job.result_count || 0 }} urun</td>
            <td class="px-4 py-3">
              <div class="flex gap-1">
                <button v-if="job.status === 'running'" @click="cancelJob(job.job_id)"
                        class="text-yellow-600 hover:text-yellow-800 text-xs px-2 py-1 border rounded">Durdur</button>
                <button @click="deleteJob(job.job_id)" class="text-red-600 hover:text-red-800 text-xs px-2 py-1 border rounded">Sil</button>
              </div>
            </td>
          </tr>
          <tr v-if="jobs.length === 0">
            <td colspan="7" class="px-4 py-8 text-center text-gray-500">Henuz arama yapilmadi</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from "vue"
import api from "../api/client"

const loading = ref(false)
const jobs = ref([])
const selectedPlatforms = ref(["vinted"])
const selectedConditions = ref([])
const health = ref({ status: "checking" })
const stats = ref({ activeJobs: 0, products: 0, favorites: 0 })
let pollInterval = null

const availablePlatforms = [
  { id: "vinted", name: "Vinted", country: "DE" },
  { id: "ebay", name: "eBay", country: "DE" },
  { id: "kleinanzeigen", name: "Kleinanzeigen", country: "DE" },
  { id: "tradera", name: "Tradera", country: "SE" },
  { id: "willhaben", name: "Willhaben", country: "AT" },
  { id: "sellpy", name: "Sellpy", country: "DE" },
  { id: "percentil", name: "Percentil", country: "DE" }
]

const availableConditions = [
  { value: "neu", label: "Neu", german: "Yeni" },
  { value: "sehr gut", label: "Sehr Gut", german: "Cok Iyi" },
  { value: "gut", label: "Gut", german: "Iyi" },
  { value: "akzeptabel", label: "Akzeptabel", german: "Kabul Edilebilir" }
]

// Computed: Active running jobs for live progress
const activeJobs = computed(() => jobs.value.filter(j => j.status === "running"))

const form = ref({
  query: "",
  min_price: null,
  max_price: null,
  sort: "relevance"
})

const getStatusClass = (status) => {
  const classes = {
    pending: "bg-yellow-100 text-yellow-800",
    running: "bg-blue-100 text-blue-800",
    completed: "bg-green-100 text-green-800",
    failed: "bg-red-100 text-red-800",
    cancelled: "bg-gray-100 text-gray-800"
  }
  return classes[status] || "bg-gray-100 text-gray-800"
}

const getStatusText = (status) => {
  const texts = { pending: "Bekliyor", running: "Calisiyor", completed: "Tamamlandi", failed: "Basarisiz", cancelled: "Iptal" }
  return texts[status] || status
}

const getJobProgress = (job) => {
  // Simulate progress based on time elapsed (max 90%)
  if (!job.started_at) return 30
  const elapsed = (Date.now() - new Date(job.started_at).getTime()) / 1000
  const progress = Math.min(90, 20 + (elapsed / 60) * 30)
  return progress
}

const formatTime = (dateStr) => {
  if (!dateStr) return ""
  const date = new Date(dateStr)
  return date.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })
}

const loadHealth = async () => {
  try {
    const res = await api.get("/health")
    health.value = res.data
    const statsRes = await api.get("/dashboard/stats")
    stats.value = {
      activeJobs: jobs.value.filter(j => j.status === "running").length,
      products: statsRes.data.total_products || 0,
      favorites: statsRes.data.total_favorites || 0
    }
  } catch (e) {
    health.value = { status: "error" }
  }
}

const startScrape = async () => {
  if (!form.value.query || selectedPlatforms.value.length === 0) return
  loading.value = true
  try {
    for (const platform of selectedPlatforms.value) {
      const payload = {
        platform,
        query: form.value.query
      }
      if (form.value.min_price) payload.min_price = parseFloat(form.value.min_price)
      if (form.value.max_price) payload.max_price = parseFloat(form.value.max_price)

      // Multi-condition support
      if (selectedConditions.value.length === 1) {
        payload.condition = selectedConditions.value[0]
      } else if (selectedConditions.value.length > 1) {
        payload.conditions = selectedConditions.value
      }

      if (form.value.sort) payload.sort = form.value.sort
      await api.post("/scraping/start", payload)
    }
    alert(selectedPlatforms.value.length + " platformda arama baslatildi!")
    loadJobs()
  } catch (error) {
    alert("Hata: " + (error.response?.data?.detail || error.message))
  } finally {
    loading.value = false
  }
}

const loadJobs = async () => {
  try {
    const res = await api.get("/scraping/jobs")
    jobs.value = res.data
    stats.value.activeJobs = jobs.value.filter(j => j.status === "running").length
  } catch (e) { console.error("Failed:", e) }
}

const deleteJob = async (jobId) => {
  if (!confirm("Bu aramayi silmek istediginizden emin misiniz?")) return
  try { await api.delete("/scraping/jobs/" + jobId); loadJobs() } catch (e) { alert("Silinemedi: " + e.message) }
}

const deleteAllJobs = async () => {
  if (!confirm("TUM aramalari silmek istediginizden emin misiniz?")) return
  try { await api.delete("/scraping/jobs"); loadJobs() } catch (e) { alert("Silinemedi: " + e.message) }
}

const cancelJob = async (jobId) => {
  try { await api.post("/scraping/jobs/" + jobId + "/cancel"); loadJobs() } catch (e) { alert("Durdurulamadi: " + e.message) }
}

onMounted(() => {
  loadJobs()
  loadHealth()
  // Poll more frequently when jobs are running (every 3 seconds)
  pollInterval = setInterval(() => {
    loadJobs()
    if (activeJobs.value.length > 0) {
      // Force reactivity update for progress bars
    }
  }, 3000)
})

onUnmounted(() => { if (pollInterval) clearInterval(pollInterval) })
</script>

<style scoped>
@keyframes shimmer {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}
.animate-shimmer {
  animation: shimmer 2s infinite;
}
</style>
