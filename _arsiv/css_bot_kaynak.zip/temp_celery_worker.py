"""
TATANGA V3 - Celery Worker
Background task processing for scraping
"""
from celery import Celery
from datetime import datetime
import logging

# Configure Celery
celery_app = Celery(
    'tatanga_worker',
    broker='redis://localhost:6379/0',
    backend='redis://localhost:6379/1'
)

celery_app.conf.update(
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='Europe/Berlin',
    enable_utc=True,
    task_track_started=True,
    task_time_limit=600,  # 10 minutes max
    worker_prefetch_multiplier=1,
    worker_concurrency=2,
)

logger = logging.getLogger('TATANGA.celery')


@celery_app.task(bind=True, name='tatanga.scrape')
def scrape_task(self, platform: str, query: str, max_pages: int = 3, max_items: int = 50):
    """
    Celery task for scraping
    """
    from services.scraper_service import run_scrape_task

    logger.info(f"Starting scrape task: {platform} - {query}")
    self.update_state(state='PROGRESS', meta={'status': 'scraping', 'platform': platform})

    try:
        result = run_scrape_task(platform, query, max_pages, max_items)
        logger.info(f"Scrape completed: {result['stats']['items_found']} items")
        return result
    except Exception as e:
        logger.error(f"Scrape failed: {e}")
        return {
            'status': 'error',
            'error': str(e),
            'platform': platform,
            'query': query
        }


@celery_app.task(name='tatanga.url_monitor')
def url_monitor_task():
    """
    Periodic task to check source URLs
    """
    # TODO: Implement URL monitoring
    logger.info("URL monitor task running")
    return {'status': 'ok', 'checked_at': datetime.now().isoformat()}


# Periodic tasks schedule
celery_app.conf.beat_schedule = {
    'url-monitor-every-5-minutes': {
        'task': 'tatanga.url_monitor',
        'schedule': 300.0,  # 5 minutes
    },
}


if __name__ == '__main__':
    celery_app.start()
