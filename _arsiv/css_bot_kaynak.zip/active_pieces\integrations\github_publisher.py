#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - GitHub Publisher for CSS Berlin
Ürünleri scraped-products.json dosyasına ekler ve git push yapar

Pilot: cssberlin.de (GitHub + Cloudflare Pages)
"""

import json
import subprocess
import os
import asyncio
import re
from pathlib import Path
from datetime import datetime
import sqlite3
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

# Import for source validation
try:
    from agents.screenshot_agent import ScreenshotAgent, AnalysisType, PageStatus
    from agents.ai_vision_manager import AIVisionManager, get_vision_manager
    VALIDATION_AVAILABLE = True
except ImportError:
    VALIDATION_AVAILABLE = False

# Import for AI content generation (FAZ 2)
try:
    from integrations.groq_seo_generator import GroqSEOGenerator
    GROQ_SEO_AVAILABLE = True
except ImportError:
    GROQ_SEO_AVAILABLE = False

# Import for image manipulation (FAZ 3)
try:
    from integrations.image_manipulator import ImageManipulator
    import requests
    import tempfile
    IMAGE_MANIPULATOR_AVAILABLE = True
except ImportError:
    IMAGE_MANIPULATOR_AVAILABLE = False

# Hetzner SFTP config
HETZNER_HOST = "195.201.146.224"
HETZNER_USER = "root"
HETZNER_IMAGE_PATH = "/root/videocu_v1/cssberlin_data/images"
HETZNER_IMAGE_URL = "https://api.cssberlin.de/images"

# Streamlit-safe logger - don't use core.logger in Streamlit context
class SimpleLogger:
    """Simple print-based logger that works in Streamlit"""
    def __init__(self, name):
        self.name = name
    def info(self, msg, **kwargs):
        pass  # Suppress in Streamlit
    def success(self, msg, **kwargs):
        pass  # Suppress in Streamlit
    def error(self, msg, **kwargs):
        pass  # Suppress in Streamlit
    def warning(self, msg, **kwargs):
        pass  # Suppress in Streamlit

# Use simple logger to avoid stdout wrapper issues
logger = SimpleLogger("github_publisher")

from agents.content_transformer import ContentTransformer, transform_product

# Paths
DB_PATH = Path(__file__).parent.parent / 'storage' / 'tatanga.db'
CSS_BERLIN_REPO = Path(r"c:\Users\cyhnsrgc\Desktop\CSS-Berlin-Website")
PRODUCTS_FILE = CSS_BERLIN_REPO / "scraped-products.json"


# ============================================
# CATEGORY DETECTION SYSTEM
# ============================================
CATEGORY_RULES = {
    # SCHUHE (Ayakkabı)
    'schuhe': {
        'keywords': ['schuh', 'shoe', 'ayakkabi', 'ayakkabı'],
        'subcategories': {
            'stiefel': ['stiefel', 'boot', 'boots', 'bot', 'ugg', 'timberland', 'dr martens', 'chelsea'],
            'sneaker': ['sneaker', 'turnschuh', 'sportschuh', 'nike', 'adidas', 'puma', 'jordan', 'air max', 'yeezy'],
            'sandalen': ['sandale', 'sandal', 'flip flop', 'slipper', 'birkenstock'],
            'high_heels': ['high heel', 'pump', 'stiletto', 'absatz', 'topuklu'],
            'loafer': ['loafer', 'mokassin', 'slipon', 'slip-on'],
        },
        'default_subcategory': 'sonstiges'
    },
    # BEKLEIDUNG (Giyim)
    'bekleidung': {
        'keywords': ['kleid', 'jacke', 'mantel', 'hose', 'shirt', 'bluse', 'pullover', 'sweater'],
        'subcategories': {
            'jacken': ['jacke', 'jacket', 'blazer', 'blouson', 'ceket', 'mont', 'parka', 'bomber'],
            'maentel': ['mantel', 'coat', 'trench', 'parka', 'wintermantel', 'palto', 'kaban'],
            'hosen': ['hose', 'jeans', 'pants', 'trousers', 'pantolon', 'legging', 'jogger'],
            'kleider': ['kleid', 'dress', 'elbise', 'abendkleid', 'cocktailkleid'],
            'oberteile': ['shirt', 'bluse', 'top', 'pullover', 'sweater', 'hoodie', 'sweatshirt', 'tshirt', 't-shirt'],
            'roecke': ['rock', 'skirt', 'etek', 'minirock'],
        },
        'default_subcategory': 'sonstiges'
    },
    # TASCHEN (Çanta)
    'taschen': {
        'keywords': ['tasche', 'bag', 'çanta', 'canta', 'rucksack', 'backpack'],
        'subcategories': {
            'handtaschen': ['handtasche', 'handbag', 'el çantası', 'clutch', 'tote'],
            'rucksaecke': ['rucksack', 'backpack', 'sırt çantası'],
            'umhaengetaschen': ['umhängetasche', 'crossbody', 'messenger', 'shoulder bag'],
            'geldbeutel': ['geldbeutel', 'wallet', 'portemonnaie', 'cüzdan'],
        },
        'default_subcategory': 'sonstiges'
    },
    # ACCESSOIRES (Aksesuar)
    'accessoires': {
        'keywords': ['uhr', 'watch', 'schmuck', 'jewelry', 'brille', 'gürtel', 'belt', 'schal', 'mütze'],
        'subcategories': {
            'uhren': ['uhr', 'watch', 'saat'],
            'schmuck': ['schmuck', 'jewelry', 'kette', 'ring', 'armband', 'ohrringe', 'halskette'],
            'brillen': ['brille', 'glasses', 'sonnenbrille', 'sunglasses', 'gözlük'],
            'guertel': ['gürtel', 'belt', 'kemer'],
            'schals': ['schal', 'scarf', 'tuch', 'mütze', 'hat', 'cap', 'beanie'],
        },
        'default_subcategory': 'sonstiges'
    }
}

# Target audience detection keywords
AUDIENCE_KEYWORDS = {
    'damen': ['damen', 'frauen', 'women', 'kadın', 'kadin', 'lady', 'ladies', 'feminine', 'weiblich'],
    'herren': ['herren', 'männer', 'men', 'erkek', 'mann', 'male', 'masculine', 'männlich'],
    'kinder': ['kinder', 'kids', 'children', 'çocuk', 'cocuk', 'baby', 'junior', 'mädchen', 'jungen'],
    'unisex': ['unisex', 'universal', 'all gender']
}

# Brand detection for better categorization
SHOE_BRANDS = ['ugg', 'nike', 'adidas', 'puma', 'timberland', 'dr martens', 'converse', 'vans',
               'new balance', 'jordan', 'reebok', 'asics', 'birkenstock', 'crocs', 'skechers',
               'clarks', 'ecco', 'geox', 'salamander', 'buffalo', 'tamaris', 'gabor', 'ara']


def detect_category(title: str, description: str = '') -> dict:
    """
    Başlık ve açıklamadan kategori, alt kategori ve hedef kitle algıla

    Returns:
        {
            'category': 'Schuhe',
            'subcategory': 'Stiefel',
            'target_audience': 'Damen',
            'brand': 'UGG'
        }
    """
    text = f"{title} {description}".lower()
    result = {
        'category': 'Sonstiges',
        'subcategory': 'Allgemein',
        'target_audience': 'Unisex',
        'brand': ''
    }

    # 1. Brand Detection (for shoes especially)
    for brand in SHOE_BRANDS:
        if brand in text:
            result['brand'] = brand.upper() if brand != 'dr martens' else 'Dr. Martens'
            # If shoe brand found, category is definitely Schuhe
            result['category'] = 'Schuhe'
            break

    # 2. Category Detection
    for cat_key, cat_data in CATEGORY_RULES.items():
        # Check main category keywords
        for keyword in cat_data['keywords']:
            if keyword in text:
                result['category'] = cat_key.capitalize()
                result['subcategory'] = cat_data['default_subcategory'].capitalize()
                break

        # Check subcategory keywords (more specific)
        for subcat_key, subcat_keywords in cat_data['subcategories'].items():
            for keyword in subcat_keywords:
                if keyword in text:
                    result['category'] = cat_key.capitalize()
                    result['subcategory'] = subcat_key.capitalize().replace('_', ' ')
                    break

    # 3. Special cases - UGG is always Stiefel
    if 'ugg' in text:
        result['category'] = 'Schuhe'
        result['subcategory'] = 'Stiefel'
        result['brand'] = 'UGG'

    # 4. Target Audience Detection (with word boundary)
    for audience, keywords in AUDIENCE_KEYWORDS.items():
        for keyword in keywords:
            # Kelime sınırı kontrolü - "men" kelimesi "damen" içinde bulunmasın
            pattern = r'\b' + re.escape(keyword) + r'\b'
            if re.search(pattern, text):
                result['target_audience'] = audience.capitalize()
                break

    # 5. Size-based audience detection (shoe sizes) - SADECE keyword yoksa
    # Eğer zaten keyword ile audience bulunduysa, size detection yapma
    if result['target_audience'] == 'Unisex':
        size_match = re.search(r'gr[öo]?\.?\s*(\d+)', text)
        if size_match:
            size = int(size_match.group(1))
            if 35 <= size <= 41:
                result['target_audience'] = 'Damen'
            elif 42 <= size <= 48:
                result['target_audience'] = 'Herren'
            elif size < 35:
                result['target_audience'] = 'Kinder'

    return result


class GitHubPublisher:
    """
    CSS Berlin sitesine ürün yayınlama

    Akış:
    1. scraped-products.json dosyasını oku
    2. Yeni ürünü ekle
    3. Git add, commit, push
    4. Cloudflare Pages otomatik build eder
    """

    # Platform-specific AI Vision prompts for sold detection
    SOLD_DETECTION_PROMPTS = {
        'vinted': """Analyze this screenshot of a Vinted product page.
Sites change their UI frequently, so check ALL indicators carefully:

SOLD indicators (check these first):
1. Green banner with "Verkauft" or "Sold" text anywhere on page
2. "Reserviert" (Reserved) status badge
3. "Artikel nicht mehr verfügbar" message

BUTTON indicators (MORE RELIABLE - sites change banners but buttons are consistent):
4. "Kaufen" button is GRAYED OUT, DISABLED, or has muted/faded color
5. "Kaufen" button is COMPLETELY MISSING from the page
6. "Nachricht senden" is the ONLY action button available (no buy option)
7. Price area shows "Verkauft" text instead of actual price
8. No "In den Warenkorb" option visible

AVAILABLE indicators (product can be purchased):
9. Active blue/purple/teal "Kaufen" button clearly visible and clickable
10. "In den Warenkorb" button present
11. Price clearly displayed with EUR symbol (e.g., "25,00 €")
12. Multiple action buttons visible (Kaufen + Nachricht)

IMPORTANT: If buy button is missing or disabled, mark as SOLD even without green banner!

Return JSON:
{
    "status": "available" | "sold" | "reserved" | "unavailable",
    "confidence": 0.0-1.0,
    "indicators": ["list of visual indicators found"],
    "price": extracted price or null,
    "currency": "EUR"
}

Only return JSON, no other text.""",

        'kleinanzeigen': """Analyze this screenshot of a Kleinanzeigen (eBay Kleinanzeigen) product page.
Look for these indicators:
1. Faded/grayed out product image
2. "Anzeige deaktiviert" text
3. "Diese Anzeige ist nicht mehr verfügbar" message
4. "Verkauft" or "Reserviert" badge
5. Missing contact/message buttons

Return JSON:
{
    "status": "available" | "sold" | "unavailable" | "deactivated",
    "confidence": 0.0-1.0,
    "indicators": ["list of visual indicators found"],
    "price": extracted price or null,
    "currency": "EUR"
}

Only return JSON, no other text.""",

        'ebay': """Analyze this screenshot of an eBay product page.
Look for these indicators:
1. "Ended" or "Beendet" label
2. "Sold" or "Verkauft" badge
3. Crossed-out price or "Item sold" message
4. "This listing has ended" text
5. Bidding ended message

Return JSON:
{
    "status": "available" | "sold" | "ended" | "unavailable",
    "confidence": 0.0-1.0,
    "indicators": ["list of visual indicators found"],
    "price": extracted price or null,
    "currency": "EUR"
}

Only return JSON, no other text.""",

        'default': """Analyze this screenshot of an e-commerce product page.
Determine if the product is still available for purchase.

Look for:
1. "Sold", "Verkauft", "Vendu" text
2. Grayed out images or buttons
3. "Out of stock", "Nicht verfügbar" messages
4. Error pages (404, not found)
5. Active "Buy" or "Add to cart" buttons (indicates available)

Return JSON:
{
    "status": "available" | "sold" | "unavailable" | "error",
    "confidence": 0.0-1.0,
    "indicators": ["list of visual indicators found"],
    "price": extracted price or null,
    "currency": "EUR"
}

Only return JSON, no other text."""
    }

    def __init__(self, repo_path: Path = CSS_BERLIN_REPO):
        self.repo_path = repo_path
        self.products_file = repo_path / "scraped-products.json"

        # Screenshot agent for validation
        self._screenshot_agent = None
        self._vision_manager = None

        # FAZ 2: AI content generation
        self._groq_seo = None

        # FAZ 3: Image manipulation
        self._image_manipulator = None
        self._temp_dir = Path(tempfile.gettempdir()) / "tatanga_images" if IMAGE_MANIPULATOR_AVAILABLE else None
        if self._temp_dir:
            self._temp_dir.mkdir(parents=True, exist_ok=True)

    def _get_screenshot_agent(self):
        """Lazy load screenshot agent"""
        if self._screenshot_agent is None and VALIDATION_AVAILABLE:
            self._screenshot_agent = ScreenshotAgent()
        return self._screenshot_agent

    def _get_vision_manager(self):
        """Lazy load vision manager"""
        if self._vision_manager is None and VALIDATION_AVAILABLE:
            self._vision_manager = get_vision_manager()
        return self._vision_manager

    def _get_groq_seo(self):
        """Lazy load Groq SEO generator"""
        if self._groq_seo is None and GROQ_SEO_AVAILABLE:
            self._groq_seo = GroqSEOGenerator()
        return self._groq_seo

    def _get_image_manipulator(self):
        """Lazy load image manipulator"""
        if self._image_manipulator is None and IMAGE_MANIPULATOR_AVAILABLE:
            self._image_manipulator = ImageManipulator()
        return self._image_manipulator

    def _detect_platform(self, url: str) -> str:
        """Detect platform from URL"""
        url_lower = url.lower()
        if 'vinted' in url_lower:
            return 'vinted'
        elif 'kleinanzeigen' in url_lower or 'ebay-kleinanzeigen' in url_lower:
            return 'kleinanzeigen'
        elif 'ebay' in url_lower:
            return 'ebay'
        else:
            return 'default'

    async def validate_source_availability_async(self, url: str) -> dict:
        """
        Kaynak URL'nin hala mevcut olup olmadığını AI Vision ile kontrol et

        Yöntem:
        1. Screenshot al (Playwright ile)
        2. AI Vision ile analiz et (platform-specific prompt)
        3. Sonucu döndür

        Args:
            url: Kontrol edilecek kaynak URL

        Returns:
            {
                'status': 'available' | 'sold' | 'unavailable' | 'error',
                'reason': str,
                'confidence': float,
                'indicators': list,
                'platform': str
            }
        """
        if not VALIDATION_AVAILABLE:
            logger.warning("Validation modules not available, skipping validation")
            return {
                'status': 'available',
                'reason': 'Validation skipped (modules not available)',
                'confidence': 0.0,
                'indicators': [],
                'platform': 'unknown'
            }

        if not url:
            return {
                'status': 'error',
                'reason': 'URL boş',
                'confidence': 1.0,
                'indicators': ['empty_url'],
                'platform': 'unknown'
            }

        try:
            # Detect platform
            platform = self._detect_platform(url)
            prompt = self.SOLD_DETECTION_PROMPTS.get(platform, self.SOLD_DETECTION_PROMPTS['default'])

            # Get screenshot agent
            screenshot_agent = self._get_screenshot_agent()
            if not screenshot_agent:
                return {
                    'status': 'available',
                    'reason': 'Screenshot agent not available',
                    'confidence': 0.0,
                    'indicators': [],
                    'platform': platform
                }

            # Take screenshot
            logger.info(f"Taking screenshot of {url[:50]}...")
            screenshot_result = await screenshot_agent.capture_screenshot(
                url=url,
                device_type='desktop',
                timeout=30000
            )

            if not screenshot_result.success:
                # HTTP error handling
                if screenshot_result.status_code == 404:
                    return {
                        'status': 'unavailable',
                        'reason': 'Sayfa bulunamadı (404)',
                        'confidence': 1.0,
                        'indicators': ['http_404'],
                        'platform': platform
                    }
                elif screenshot_result.status_code >= 400:
                    return {
                        'status': 'error',
                        'reason': f'HTTP hatası: {screenshot_result.status_code}',
                        'confidence': 0.9,
                        'indicators': [f'http_{screenshot_result.status_code}'],
                        'platform': platform
                    }
                else:
                    return {
                        'status': 'error',
                        'reason': f'Screenshot hatası: {screenshot_result.error}',
                        'confidence': 0.5,
                        'indicators': ['screenshot_failed'],
                        'platform': platform
                    }

            # Get vision manager
            vision_manager = self._get_vision_manager()
            if not vision_manager:
                return {
                    'status': 'available',
                    'reason': 'Vision manager not available',
                    'confidence': 0.0,
                    'indicators': [],
                    'platform': platform
                }

            # Read screenshot file for AI analysis
            with open(screenshot_result.screenshot_path, 'rb') as f:
                image_data = f.read()

            # AI Vision analysis
            logger.info(f"Analyzing screenshot with AI Vision ({platform})...")
            analysis = await vision_manager.analyze_image(
                image_data=image_data,
                custom_prompt=prompt
            )

            if not analysis.get('success'):
                return {
                    'status': 'available',  # Fail-safe: don't block on AI error
                    'reason': f"AI analiz hatası: {analysis.get('error', 'Unknown')}",
                    'confidence': 0.0,
                    'indicators': ['ai_error'],
                    'platform': platform
                }

            # Parse AI result
            result_data = analysis.get('result', {})
            status = result_data.get('status', 'unknown').lower()
            confidence = result_data.get('confidence', 0.5)
            indicators = result_data.get('indicators', [])

            # Map status
            status_map = {
                'available': 'available',
                'sold': 'sold',
                'reserved': 'sold',  # Reserved = not available
                'unavailable': 'unavailable',
                'deactivated': 'unavailable',
                'ended': 'sold',
                'error': 'error',
                'unknown': 'available'  # Fail-safe
            }
            final_status = status_map.get(status, 'available')

            return {
                'status': final_status,
                'reason': f"AI tespit: {status} ({', '.join(indicators[:3]) if indicators else 'no indicators'})",
                'confidence': confidence,
                'indicators': indicators,
                'platform': platform,
                'ai_provider': analysis.get('provider_name', 'unknown'),
                'screenshot_path': screenshot_result.screenshot_path
            }

        except Exception as e:
            logger.error(f"Source validation error: {e}")
            return {
                'status': 'available',  # Fail-safe: don't block on error
                'reason': f'Validation hatası: {str(e)}',
                'confidence': 0.0,
                'indicators': ['exception'],
                'platform': 'unknown'
            }

    def validate_source_availability(self, url: str) -> dict:
        """
        Sync wrapper for validate_source_availability_async
        """
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If already in async context, create new loop
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(
                        asyncio.run,
                        self.validate_source_availability_async(url)
                    )
                    return future.result(timeout=60)
            else:
                return loop.run_until_complete(
                    self.validate_source_availability_async(url)
                )
        except Exception as e:
            logger.error(f"Sync validation error: {e}")
            return {
                'status': 'available',
                'reason': f'Sync wrapper hatası: {str(e)}',
                'confidence': 0.0,
                'indicators': [],
                'platform': 'unknown'
            }

    # ========================================================================
    # FAZ 2: AI KÜNYE PIPELINE
    # ========================================================================

    def generate_ai_seo_content(self, product_data: dict) -> dict:
        """
        FAZ 2: GroqSEO ile AI tabanlı SEO başlık ve açıklama üret

        Args:
            product_data: ContentTransformer'dan gelen ürün verisi

        Returns:
            dict: SEO optimize edilmiş başlık, açıklama ve keywords
        """
        groq_seo = self._get_groq_seo()
        if not groq_seo:
            logger.warning("GroqSEO mevcut değil, orijinal içerik kullanılıyor")
            return {
                'seo_title': product_data.get('title', ''),
                'seo_description': product_data.get('description', ''),
                'seo_keywords': []
            }

        try:
            # Detect source platform for style selection
            source_platform = product_data.get('source_platform', 'unknown')
            platform_style_map = {
                'vinted': 'balanced',
                'kleinanzeigen': 'conservative',
                'ebay': 'balanced'
            }
            style = platform_style_map.get(source_platform, 'balanced')

            # Generate SEO variation
            result = groq_seo.generate_variation(
                original_title=product_data.get('title', ''),
                original_description=product_data.get('description', ''),
                platform='cssberlin',
                language='de',
                variation_style=style
            )

            logger.info(f"SEO içerik oluşturuldu: {result.get('title', '')[:40]}...")

            return {
                'seo_title': result.get('title', product_data.get('title', '')),
                'seo_description': result.get('description', product_data.get('description', '')),
                'seo_keywords': result.get('keywords', [])
            }

        except Exception as e:
            logger.error(f"GroqSEO hatası: {e}")
            return {
                'seo_title': product_data.get('title', ''),
                'seo_description': product_data.get('description', ''),
                'seo_keywords': []
            }

    # ========================================================================
    # FAZ 3: GÖRSEL İŞLEME VE HETZNER UPLOAD
    # ========================================================================

    def download_image(self, image_url: str, product_id: int) -> Path:
        """
        Görseli indir ve geçici klasöre kaydet

        Args:
            image_url: Kaynak görsel URL'si
            product_id: Ürün ID

        Returns:
            Path: İndirilen görselin yolu
        """
        if not IMAGE_MANIPULATOR_AVAILABLE:
            return None

        try:
            # Create product temp directory
            product_dir = self._temp_dir / str(product_id)
            product_dir.mkdir(parents=True, exist_ok=True)

            # Download image
            response = requests.get(image_url, timeout=30)
            response.raise_for_status()

            # Determine extension from content type
            content_type = response.headers.get('content-type', 'image/jpeg')
            ext = '.jpg' if 'jpeg' in content_type else '.png' if 'png' in content_type else '.jpg'

            # Save to temp file
            original_path = product_dir / f"original{ext}"
            with open(original_path, 'wb') as f:
                f.write(response.content)

            logger.info(f"Görsel indirildi: {original_path}")
            return original_path

        except Exception as e:
            logger.error(f"Görsel indirme hatası: {e}")
            return None

    def process_image(self, image_path: Path, product_id: int, platform: str = 'cssberlin') -> Path:
        """
        FAZ 3: Görseli ImageManipulator ile işle (hash değiştirme)

        Args:
            image_path: İndirilmiş görselin yolu
            product_id: Ürün ID
            platform: Hedef platform (preset seçimi için)

        Returns:
            Path: İşlenmiş görselin yolu
        """
        manipulator = self._get_image_manipulator()
        if not manipulator or not image_path:
            return image_path  # Return original if manipulator not available

        try:
            # Get platform preset
            preset = manipulator.get_platform_preset(platform)
            logger.info(f"Görsel işleniyor: preset={preset}")

            # Process image
            processed_pil = manipulator.process_single(
                image_path=str(image_path),
                manipulation_level=preset,
                strip_metadata=True
            )

            if processed_pil:
                # Save processed image
                product_dir = self._temp_dir / str(product_id)
                processed_path = product_dir / "processed.jpg"
                processed_pil.save(processed_path, quality=95)

                logger.info(f"Görsel işlendi: {processed_path}")
                return processed_path

            return image_path

        except Exception as e:
            logger.error(f"Görsel işleme hatası: {e}")
            return image_path

    def upload_to_hetzner(self, image_path: Path, product_id: int) -> str:
        """
        FAZ 3: İşlenmiş görseli Hetzner'a SCP ile yükle

        Args:
            image_path: Yüklenecek görsel yolu
            product_id: Ürün ID

        Returns:
            str: Hetzner'daki görsel URL'si
        """
        if not image_path or not image_path.exists():
            return None

        try:
            # Remote path
            remote_dir = f"{HETZNER_IMAGE_PATH}/{product_id}"
            remote_file = f"{remote_dir}/image.jpg"

            # Create remote directory via SSH
            ssh_mkdir = subprocess.run(
                ['ssh', f'{HETZNER_USER}@{HETZNER_HOST}', f'mkdir -p {remote_dir}'],
                capture_output=True,
                text=True,
                timeout=30
            )

            # Upload via SCP
            scp_result = subprocess.run(
                ['scp', str(image_path), f'{HETZNER_USER}@{HETZNER_HOST}:{remote_file}'],
                capture_output=True,
                text=True,
                timeout=60
            )

            if scp_result.returncode == 0:
                image_url = f"{HETZNER_IMAGE_URL}/{product_id}/image.jpg"
                logger.info(f"Görsel Hetzner'a yüklendi: {image_url}")
                return image_url
            else:
                logger.error(f"SCP hatası: {scp_result.stderr}")
                return None

        except subprocess.TimeoutExpired:
            logger.error("Hetzner upload timeout")
            return None
        except Exception as e:
            logger.error(f"Hetzner upload hatası: {e}")
            return None

    def process_and_upload_image(self, image_url: str, product_id: int, platform: str = 'cssberlin') -> str:
        """
        FAZ 3: Tam görsel işleme pipeline

        1. Görseli indir
        2. ImageManipulator ile hash değiştir
        3. Hetzner'a yükle
        4. URL döndür

        Args:
            image_url: Kaynak görsel URL'si
            product_id: Ürün ID
            platform: Hedef platform

        Returns:
            str: İşlenmiş görselin URL'si (Hetzner veya orijinal)
        """
        if not IMAGE_MANIPULATOR_AVAILABLE:
            logger.warning("ImageManipulator mevcut değil, orijinal URL kullanılıyor")
            return image_url

        try:
            # 1. Download
            original_path = self.download_image(image_url, product_id)
            if not original_path:
                return image_url

            # 2. Process
            processed_path = self.process_image(original_path, product_id, platform)

            # 3. Upload to Hetzner
            hetzner_url = self.upload_to_hetzner(processed_path, product_id)

            # 4. Cleanup temp files
            try:
                product_dir = self._temp_dir / str(product_id)
                if product_dir.exists():
                    import shutil
                    shutil.rmtree(product_dir)
            except:
                pass

            return hetzner_url or image_url

        except Exception as e:
            logger.error(f"Görsel pipeline hatası: {e}")
            return image_url

    def process_and_upload_all_images(self, image_urls: list, product_id: int, platform: str = 'cssberlin') -> list:
        """
        Process and upload ALL images for a product to Hetzner.

        Args:
            image_urls: List of source image URLs
            product_id: Product ID
            platform: Target platform

        Returns:
            list: List of processed image URLs from Hetzner
        """
        if not image_urls:
            return []

        if not IMAGE_MANIPULATOR_AVAILABLE:
            logger.warning("ImageManipulator mevcut değil, orijinal URL'ler kullanılıyor")
            return image_urls

        processed_urls = []
        manipulator = self._get_image_manipulator()

        for idx, image_url in enumerate(image_urls[:10]):  # Max 10 images
            try:
                # Create product temp directory
                product_dir = self._temp_dir / str(product_id)
                product_dir.mkdir(parents=True, exist_ok=True)

                # Download
                response = requests.get(image_url, timeout=30)
                response.raise_for_status()

                content_type = response.headers.get('content-type', 'image/jpeg')
                ext = '.jpg' if 'jpeg' in content_type else '.png' if 'png' in content_type else '.jpg'

                original_path = product_dir / f"original_{idx}{ext}"
                with open(original_path, 'wb') as f:
                    f.write(response.content)

                # Process with manipulator
                if manipulator:
                    preset = manipulator.get_platform_preset(platform)
                    processed_pil = manipulator.process_single(
                        image_path=str(original_path),
                        manipulation_level=preset,
                        strip_metadata=True
                    )

                    if processed_pil:
                        processed_path = product_dir / f"processed_{idx}.jpg"
                        processed_pil.save(processed_path, quality=95)
                    else:
                        processed_path = original_path
                else:
                    processed_path = original_path

                # Upload to Hetzner with index
                remote_dir = f"{HETZNER_IMAGE_PATH}/{product_id}"
                remote_file = f"{remote_dir}/image_{idx}.jpg"

                # Create remote directory
                subprocess.run(
                    ['ssh', f'{HETZNER_USER}@{HETZNER_HOST}', f'mkdir -p {remote_dir}'],
                    capture_output=True, text=True, timeout=30
                )

                # Upload via SCP
                scp_result = subprocess.run(
                    ['scp', str(processed_path), f'{HETZNER_USER}@{HETZNER_HOST}:{remote_file}'],
                    capture_output=True, text=True, timeout=60
                )

                if scp_result.returncode == 0:
                    hetzner_url = f"{HETZNER_IMAGE_URL}/{product_id}/image_{idx}.jpg"
                    processed_urls.append(hetzner_url)
                    logger.info(f"Uploaded image {idx+1}/{len(image_urls)}: {hetzner_url}")
                else:
                    processed_urls.append(image_url)  # Fallback to original

            except Exception as e:
                logger.error(f"Image {idx} upload error: {e}")
                processed_urls.append(image_url)  # Fallback to original

        # Cleanup temp files
        try:
            product_dir = self._temp_dir / str(product_id)
            if product_dir.exists():
                import shutil
                shutil.rmtree(product_dir)
        except:
            pass

        logger.info(f"Uploaded {len(processed_urls)} images for product {product_id}")
        return processed_urls

    # ========================================================================
    # CRUD OPERATIONS
    # ========================================================================

    def load_products(self) -> dict:
        """Mevcut ürünleri yükle"""
        try:
            if self.products_file.exists():
                with open(self.products_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return {"stats": {}, "products": []}
        except Exception as e:
            logger.error(f"Ürünler yüklenemedi: {e}")
            return {"stats": {}, "products": []}

    def save_products(self, data: dict) -> bool:
        """Ürünleri kaydet"""
        try:
            with open(self.products_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            logger.error(f"Ürünler kaydedilemedi: {e}")
            return False

    def get_next_id(self, data: dict) -> int:
        """Sonraki ürün ID'sini al"""
        if not data.get('products'):
            return 1
        max_id = max(p.get('id', 0) for p in data['products'])
        return max_id + 1

    # ========================================================================
    # FAZ 7: ÜRÜN SİLME (Favori kaldırma → Yayın silme)
    # ========================================================================

    def remove_product(self, json_product_id: int, reason: str = "favorite_removed") -> dict:
        """
        Ürünü scraped-products.json'dan sil ve git push yap

        Args:
            json_product_id: JSON'daki ürün ID'si
            reason: Silme sebebi

        Returns:
            dict: {success: bool, message: str}
        """
        try:
            # 1. JSON yükle
            data = self.load_products()
            products = data.get('products', [])
            original_count = len(products)

            # 2. Silinen ürünün bilgilerini bul (log için)
            removed_product = None
            for p in products:
                if p.get('id') == json_product_id:
                    removed_product = p
                    break

            # 3. Ürünü sil
            products = [p for p in products if p.get('id') != json_product_id]

            if len(products) == original_count:
                logger.warning(f"Product {json_product_id} not found in JSON")
                return {'success': False, 'message': f'Product {json_product_id} not found'}

            # 4. Stats güncelle
            data['products'] = products
            data['stats']['total_products'] = len(products)
            data['stats']['last_updated'] = datetime.now().isoformat()

            # 5. Kaydet
            if not self.save_products(data):
                return {'success': False, 'message': 'Failed to save products'}

            # 6. Git push
            product_title = removed_product.get('title', 'Unknown')[:30] if removed_product else 'Unknown'
            self.git_push(f"[TATANGA] Ürün silindi (ID: {json_product_id}) - {reason} - {product_title}")

            # 7. Hetzner görsellerini sil
            self._cleanup_hetzner_images(json_product_id)

            logger.info(f"Product {json_product_id} removed successfully: {reason}")
            return {'success': True, 'message': f'Product {json_product_id} removed', 'product_title': product_title}

        except Exception as e:
            logger.error(f"Failed to remove product {json_product_id}: {e}")
            return {'success': False, 'message': str(e)}

    def _cleanup_hetzner_images(self, product_id: int):
        """Hetzner'daki ürün görsellerini sil"""
        try:
            remote_dir = f"{HETZNER_IMAGE_PATH}/{product_id}"
            result = subprocess.run(
                ['ssh', f'{HETZNER_USER}@{HETZNER_HOST}', f'rm -rf {remote_dir}'],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                logger.info(f"Hetzner images cleaned: {remote_dir}")
            else:
                logger.warning(f"Hetzner cleanup warning: {result.stderr}")
        except subprocess.TimeoutExpired:
            logger.warning(f"Hetzner cleanup timeout for product {product_id}")
        except Exception as e:
            logger.warning(f"Hetzner cleanup failed for product {product_id}: {e}")
            # Görsel silme başarısız olsa da devam et - kritik değil

    def add_product(self, product_data: dict, apply_transform: bool = True,
                    use_groq_seo: bool = True, process_images: bool = True) -> dict:
        """
        Ürün ekle (Content Transform + GroqSEO + Image Processing)

        Args:
            product_data: Ham ürün verisi
            apply_transform: True ise ContentTransformer uygula
            use_groq_seo: True ise GroqSEO ile AI başlık/açıklama üret (FAZ 2)
            process_images: True ise görselleri işle ve Hetzner'a yükle (FAZ 3)

        Returns:
            dict: {success: bool, product_id: int, message: str}
        """
        try:
            # Mevcut verileri yükle
            data = self.load_products()

            # Yeni ID al
            new_id = self.get_next_id(data)

            # Content Transform uygula (SEO + fiyat)
            if apply_transform:
                logger.info("Content Transform uygulanıyor...")
                transformed = transform_product(product_data)

                # FAZ 2: GroqSEO ile AI SEO içerik üret
                seo_content = {}
                if use_groq_seo and GROQ_SEO_AVAILABLE:
                    logger.info("GroqSEO ile AI içerik oluşturuluyor...")
                    seo_content = self.generate_ai_seo_content(transformed)

                # FAZ 3: Görsel işleme ve Hetzner upload (ÇOKLU RESİM DESTEĞİ)
                # Önce tüm görselleri al (images dizisi varsa kullan, yoksa tek image)
                all_images = product_data.get('images', [])
                if not all_images and product_data.get('image'):
                    all_images = [product_data.get('image')]
                if not all_images and transformed.get('image'):
                    all_images = [transformed.get('image')]

                final_images = []  # Tüm işlenmiş görseller
                final_image_url = ''  # Ana görsel (ilk görsel)

                if process_images and IMAGE_MANIPULATOR_AVAILABLE and all_images:
                    logger.info(f"Tüm görseller işleniyor ve Hetzner'a yükleniyor... ({len(all_images)} adet)")
                    processed_urls = self.process_and_upload_all_images(
                        image_urls=all_images,
                        product_id=new_id,
                        platform=transformed.get('source_platform', 'cssberlin')
                    )
                    if processed_urls:
                        final_images = processed_urls
                        final_image_url = processed_urls[0]  # İlk görsel ana görsel
                    else:
                        final_images = all_images
                        final_image_url = all_images[0] if all_images else ''
                else:
                    final_images = all_images
                    final_image_url = all_images[0] if all_images else transformed.get('image', '')

                # AKILLI KATEGORİ ALGILAMA
                title_for_cat = seo_content.get('seo_title') or transformed.get('title', product_data.get('title', ''))
                desc_for_cat = seo_content.get('seo_description') or transformed.get('description', '')
                detected_cat = detect_category(title_for_cat, desc_for_cat)

                new_product = {
                    "id": new_id,
                    # Transform edilmiş başlık ve açıklama (GroqSEO varsa onu kullan)
                    "title": title_for_cat or 'Ürün',
                    "description": desc_for_cat,
                    # Transform edilmiş fiyat (kar marjı eklenmiş) - KÜSÜRAT YOK
                    "price": int(round(transformed.get('price', product_data.get('price', 0)))),
                    "original_price": int(round(transformed.get('original_price', product_data.get('price', 0)))),
                    "currency": transformed.get('currency', 'EUR'),
                    # Platform ve kaynak
                    "platform": "cssberlin",  # Artık CSS Berlin ürünü
                    "source_platform": transformed.get('source_platform', product_data.get('platform', 'unknown')),
                    "link": "",  # CSS Berlin'de kendi linki olacak
                    "source_url": transformed.get('source_url', product_data.get('link', '')),
                    # Görseller (FAZ 3: işlenmiş görsel - ÇOKLU RESİM)
                    "image": final_image_url,
                    "images": final_images,  # Tüm görseller dizisi
                    "image_count": len(final_images) if final_images else 1,
                    # Meta bilgiler - KAYNAK METADATA ÖNCELİKLİ
                    "brand": transformed.get('brand', '') or product_data.get('brand', '') or detected_cat['brand'],  # Orijinal öncelikli
                    "condition": transformed.get('condition', '') or product_data.get('condition', ''),  # Orijinal kullan (map YOK!)
                    "size": transformed.get('size', '') or product_data.get('size', ''),  # Orijinal beden
                    "color": transformed.get('color', '') or product_data.get('color', ''),  # Orijinal renk
                    "category": detected_cat['category'],
                    "subcategory": detected_cat['subcategory'],
                    "target_audience": detected_cat['target_audience'],
                    # SEO (FAZ 2: GroqSEO keywords)
                    "meta_title": transformed.get('meta_title', ''),
                    "meta_description": transformed.get('meta_description', ''),
                    "keywords": ', '.join(seo_content.get('seo_keywords', [])) or transformed.get('keywords', ''),
                    # Shipping
                    "location": "Berlin",
                    "shipping_cost": 4.99,  # Sabit kargo
                    "shipping_type": "STANDARD",
                    # Fiyat bilgisi
                    "margin_percent": transformed.get('price_info', {}).get('margin_percent', 0),
                    "profit": transformed.get('price_info', {}).get('profit', 0),
                    # Metadata
                    "scraped_at": datetime.now().isoformat(),
                    "transformed_at": transformed.get('transformed_at', ''),
                    "source": "tatanga_transform",
                    # FAZ 2+3 flags
                    "ai_seo_applied": bool(seo_content.get('seo_title')),
                    "image_processed": final_image_url != transformed.get('image', '')
                }

                logger.success(f"Transform tamamlandı: {transformed.get('original_price', 0)}€ -> {transformed.get('price', 0)}€")
            else:
                # Transform olmadan ham veri - KAYNAK METADATA KORU
                new_product = {
                    "id": new_id,
                    "title": product_data.get('title', 'Ürün'),
                    "price": int(round(float(product_data.get('price', 0)))),
                    "currency": product_data.get('currency', 'EUR'),
                    "platform": product_data.get('platform', 'tatanga'),
                    "link": product_data.get('link', ''),
                    "image": product_data.get('image', ''),
                    "image_count": len(product_data.get('images', [])) or 1,
                    "location": product_data.get('location', 'DE'),
                    "condition": product_data.get('condition', ''),
                    "shipping_cost": float(product_data.get('shipping_cost', 0)),
                    "shipping_type": "STANDARD",
                    "brand": product_data.get('brand', ''),
                    "size": product_data.get('size', ''),  # Orijinal beden
                    "color": product_data.get('color', ''),  # Orijinal renk
                    "description": product_data.get('description', ''),
                    "scraped_at": datetime.now().isoformat(),
                    "source": "tatanga_import"
                }

            # DUPLICATE CHECK - Aynı source_url varsa ekleme
            source_url = new_product.get('source_url', '')
            if source_url:
                existing_urls = [p.get('source_url', '') for p in data['products']]
                if source_url in existing_urls:
                    logger.warning(f"DUPLICATE: {source_url} zaten mevcut, atlanıyor")
                    return {
                        'success': False,
                        'product_id': None,
                        'message': f'Duplicate ürün: {source_url} zaten yayınlanmış'
                    }

            # Ürünü başa ekle (en yeni en üstte)
            data['products'].insert(0, new_product)

            # Stats güncelle
            data['stats']['total_products'] = len(data['products'])
            data['stats']['last_updated'] = datetime.now().strftime('%Y-%m-%d')

            # Platform stats güncelle
            platform = new_product['platform']
            if 'platforms' not in data['stats']:
                data['stats']['platforms'] = {}
            data['stats']['platforms'][platform] = data['stats']['platforms'].get(platform, 0) + 1

            # Kaydet
            if self.save_products(data):
                logger.success(f"Ürün eklendi: ID={new_id}, {new_product['title'][:50]}")
                return {
                    'success': True,
                    'product_id': new_id,
                    'message': f'Ürün JSON\'a eklendi (ID: {new_id})'
                }
            else:
                return {
                    'success': False,
                    'message': 'JSON dosyası kaydedilemedi'
                }

        except Exception as e:
            logger.error(f"Ürün ekleme hatası: {e}")
            return {
                'success': False,
                'message': f'Hata: {str(e)}'
            }

    def git_push(self, commit_message: str = None) -> dict:
        """
        Git add, commit, push

        Returns:
            dict: {success: bool, message: str}
        """
        # Save original working directory to restore later (critical for Streamlit)
        original_cwd = os.getcwd()

        try:
            # Git status kontrol (use cwd parameter, don't change directory)
            status = subprocess.run(
                ['git', 'status', '--porcelain'],
                capture_output=True, text=True, cwd=self.repo_path
            )

            if not status.stdout.strip():
                return {
                    'success': True,
                    'message': 'Değişiklik yok, push gerekmedi'
                }

            # Git add
            subprocess.run(
                ['git', 'add', 'scraped-products.json'],
                check=True, cwd=self.repo_path
            )

            # Commit message
            if not commit_message:
                commit_message = f"[TATANGA] Ürün eklendi - {datetime.now().strftime('%Y-%m-%d %H:%M')}"

            # Git commit
            subprocess.run(
                ['git', 'commit', '-m', commit_message],
                check=True, cwd=self.repo_path
            )

            # Git push
            result = subprocess.run(
                ['git', 'push', 'origin', 'main'],
                capture_output=True, text=True, cwd=self.repo_path
            )

            if result.returncode == 0:
                logger.success("Git push başarılı")
                return {
                    'success': True,
                    'message': 'GitHub\'a push edildi, Cloudflare build başlayacak'
                }
            else:
                logger.error(f"Git push hatası: {result.stderr}")
                return {
                    'success': False,
                    'message': f'Push hatası: {result.stderr}'
                }

        except subprocess.CalledProcessError as e:
            logger.error(f"Git komutu hatası: {e}")
            return {
                'success': False,
                'message': f'Git hatası: {str(e)}'
            }
        except Exception as e:
            logger.error(f"Git push hatası: {e}")
            return {
                'success': False,
                'message': f'Hata: {str(e)}'
            }
        finally:
            # Always restore original working directory (prevents Streamlit crash)
            os.chdir(original_cwd)

    def publish_product(self, product_data: dict, auto_push: bool = True, apply_transform: bool = True, validate_source: bool = True) -> dict:
        """
        Ürünü ekle ve (opsiyonel) push et

        Args:
            product_data: Ürün bilgileri
            auto_push: True ise otomatik git push yapar
            apply_transform: True ise ContentTransformer uygula (SEO + fiyat)
            validate_source: True ise kaynak URL'yi kontrol et (satıldı mı?)

        Returns:
            dict: {success, product_id, message, pushed, validation}
        """
        # 1. KAYNAK DOĞRULAMA (YENİ)
        source_url = product_data.get('source_url') or product_data.get('link') or product_data.get('url')

        if validate_source and source_url:
            logger.info(f"Kaynak doğrulanıyor: {source_url[:50]}...")
            validation = self.validate_source_availability(source_url)

            if validation['status'] != 'available':
                return {
                    'success': False,
                    'error': f"Kaynak mevcut değil: {validation['reason']}",
                    'validation': validation,
                    'message': f"Ürün yayınlanamaz: {validation['status']} ({validation.get('confidence', 0):.0%} güven)"
                }

            logger.info(f"Kaynak doğrulandı: {validation['status']} ({validation.get('confidence', 0):.0%})")

        # 2. Ürünü ekle (Content Transform ile)
        result = self.add_product(product_data, apply_transform=apply_transform)

        if not result['success']:
            return result

        result['pushed'] = False

        # Auto push
        if auto_push:
            push_result = self.git_push(
                f"[TATANGA] Ürün eklendi: {product_data.get('title', 'Ürün')[:50]}"
            )
            result['pushed'] = push_result['success']
            result['push_message'] = push_result['message']

        return result


def publish_variant_to_cssberlin(variant_data: dict, auto_push: bool = True) -> dict:
    """
    Varyant verisini CSS Berlin'e yayınla (VariantGenerator'dan gelen)

    Bu fonksiyon, VariantGenerator tarafından üretilen platform-specific
    varyant verilerini doğrudan yayınlar. Resimler zaten işlenmiş,
    başlık ve açıklama zaten SEO optimize edilmiş olarak gelir.

    Args:
        variant_data: VariantGenerator'dan gelen varyant verisi
            - title: SEO optimize edilmiş başlık
            - description: SEO optimize edilmiş açıklama
            - keywords: Keyword listesi
            - images: İşlenmiş resim yolları listesi
            - image: Ana resim yolu
            - price: Platform-specific fiyat (margin eklenmiş)
            - original_price: Orijinal fiyat
            - source_url: Kaynak URL
            - product_id: DB'deki ürün ID'si
        auto_push: True ise otomatik git push yapar

    Returns:
        dict: {success, product_id, message, pushed}
    """
    try:
        publisher = GitHubPublisher()
        data = publisher.load_products()
        new_id = publisher.get_next_id(data)

        # Varyant verilerinden image URL'lerini hazırla
        # Local path ise Hetzner'a yükle
        main_image = variant_data.get('image', '')
        images = variant_data.get('images', [])

        # Eğer local path ise Hetzner'a yükle
        if main_image and Path(main_image).exists():
            hetzner_url = publisher.upload_to_hetzner(Path(main_image), new_id)
            if hetzner_url:
                main_image = hetzner_url

        # AKILLI KATEGORİ ALGILAMA
        title = variant_data.get('title', '')
        description = variant_data.get('description', '')
        detected = detect_category(title, description)

        # Yeni ürün oluştur (varyant verileriyle - transform/SEO zaten uygulanmış)
        new_product = {
            "id": new_id,
            # Varyant'tan gelen SEO optimize başlık ve açıklama
            "title": title or 'Ürün',
            "description": description,
            # Varyant'tan gelen fiyat (margin eklenmiş) - KÜSÜRAT YOK
            "price": int(round(variant_data.get('price', 0))),
            "original_price": int(round(variant_data.get('original_price', 0))),
            "currency": "EUR",
            # Platform bilgisi
            "platform": "cssberlin",
            "source_platform": variant_data.get('source_platform', 'unknown'),
            "link": "",  # CSS Berlin'de kendi linki olacak
            "source_url": variant_data.get('source_url', ''),
            # Görsel (işlenmiş)
            "image": main_image,
            "image_count": len(images) if images else 1,
            # Meta - KAYNAK METADATA ÖNCELİKLİ (DEĞİŞTİRME!)
            "brand": variant_data.get('brand', '') or detected['brand'],  # Orijinal brand öncelikli
            "condition": variant_data.get('condition', ''),  # Orijinal condition kullan (map değil!)
            "size": variant_data.get('size', ''),  # Orijinal beden
            "color": variant_data.get('color', ''),  # Orijinal renk
            "category": detected['category'],
            "subcategory": detected['subcategory'],
            "target_audience": detected['target_audience'],
            # SEO (varyant'tan)
            "keywords": ', '.join(variant_data.get('keywords', [])),
            # Shipping
            "location": "Berlin",
            "shipping_cost": 4.99,
            "shipping_type": "STANDARD",
            # Fiyat bilgisi
            "margin_percent": variant_data.get('margin_percent', 0),
            "profit": variant_data.get('price', 0) - variant_data.get('original_price', 0),
            # Metadata
            "scraped_at": datetime.now().isoformat(),
            "source": "tatanga_variant",
            # Flags
            "ai_seo_applied": True,  # Varyant zaten SEO uygulanmış
            "image_processed": True,  # Varyant zaten işlenmiş
            "variant_generated": True
        }

        # Ürünü başa ekle
        data['products'].insert(0, new_product)

        # Stats güncelle
        data['stats']['total_products'] = len(data['products'])
        data['stats']['last_updated'] = datetime.now().strftime('%Y-%m-%d')

        # Kaydet
        if not publisher.save_products(data):
            return {'success': False, 'message': 'JSON dosyası kaydedilemedi'}

        result = {
            'success': True,
            'product_id': new_id,
            'message': f'Varyant CSS Berlin\'e eklendi (ID: {new_id})',
            'pushed': False
        }

        # Auto push
        if auto_push:
            push_result = publisher.git_push(
                f"[TATANGA] Varyant eklendi: {variant_data.get('title', 'Ürün')[:50]}"
            )
            result['pushed'] = push_result['success']
            result['push_message'] = push_result['message']

        return result

    except Exception as e:
        return {'success': False, 'message': f'Varyant yayınlama hatası: {str(e)}'}


def publish_favorite_to_cssberlin(product_id: int, auto_push: bool = True) -> dict:
    """
    Favori ürünü CSS Berlin'e yayınla (eski yöntem - ham veri)

    NOT: Varyant sistemi aktifse publish_variant_to_cssberlin() kullanın!

    Args:
        product_id: TATANGA veritabanındaki ürün ID
        auto_push: True ise otomatik git push yapar

    Returns:
        dict: {success, product_id, message, pushed}
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    try:
        # Ürün bilgilerini çek
        cursor.execute("""
            SELECT
                p.*,
                ps.normalized_score
            FROM products p
            LEFT JOIN product_scores ps ON p.id = ps.product_id
            WHERE p.id = ?
        """, (product_id,))

        product = cursor.fetchone()
        if not product:
            return {'success': False, 'message': 'Ürün bulunamadı'}

        product = dict(product)

        # Görselleri parse et
        images = []
        main_image = ''
        if product.get('images'):
            try:
                images = json.loads(product['images']) if isinstance(product['images'], str) else product['images']
                main_image = images[0] if images else ''
            except:
                pass

        # Orijinal durum bilgisini kullan (map YAPMA - kaynak metadata'yı koru!)
        condition_text = product.get('condition', '')

        # Publisher oluştur
        publisher = GitHubPublisher()

        # AKILLI KATEGORİ ALGILAMA
        title = product.get('title', '')
        description = product.get('description', '')
        detected = detect_category(title, description)

        # ============== AI ORİJİNAL BAŞLIK/AÇIKLAMA ==============
        try:
            from core.ai_helpers import generate_seo_title, generate_seo_description
            ai_title = generate_seo_title(product)
            ai_description = generate_seo_description(product)
            # AI ürettiyse kullan, yoksa orijinal
            final_title = ai_title if ai_title and len(ai_title) > 10 else title
            final_description = ai_description if ai_description and len(ai_description) > 30 else description
            logger.info(f"AI generated title: {final_title[:50]}...")
        except Exception as e:
            logger.warning(f"AI generation failed, using original: {e}")
            final_title = title
            final_description = description

        # ============== MİNİMUM 5 RESİM KONTROLÜ ==============
        if len(images) < 5:
            logger.warning(f"Only {len(images)} images, need 5. Duplicating existing images.")
            # Mevcut resimleri çoğalt (manipüle edilecek)
            while len(images) < 5 and images:
                images.append(images[len(images) % len(images[:1])])

        # Ürün verisini hazırla - AI BAŞLIK/AÇIKLAMA KULLAN
        product_data = {
            'title': final_title or 'Ürün',
            'price': product.get('price', 0),
            'currency': product.get('currency', 'EUR'),
            'platform': product.get('platform', 'unknown'),
            'link': product.get('url', ''),
            'source_url': product.get('url', ''),  # Kaynak URL sakla
            'image': main_image,
            'images': images[:5],  # Max 5 resim
            'condition': condition_text,  # Orijinal condition (map yapılmadı!)
            'brand': product.get('brand', '') or detected['brand'],  # Orijinal brand öncelikli
            'description': final_description,
            'location': product.get('location', 'DE'),
            'shipping_cost': product.get('shipping_cost', 0) or 0,
            # KAYNAK METADATA - DEĞİŞTİRME!
            'size': product.get('size', ''),
            'color': product.get('color', ''),
            # AKILLI KATEGORİ BİLGİLERİ
            'category': detected['category'],
            'subcategory': detected['subcategory'],
            'target_audience': detected['target_audience']
        }

        # Yayınla
        result = publisher.publish_product(product_data, auto_push=auto_push)

        # Sonucu kaydet
        if result['success']:
            cursor.execute("""
                UPDATE publish_history
                SET status = 'success', published_url = ?
                WHERE id = (
                    SELECT id FROM publish_history
                    WHERE product_id = ? AND status = 'pending'
                    ORDER BY created_at DESC LIMIT 1
                )
            """, (f"cssberlin.de (ID: {result.get('product_id')})", product_id))

            # Store last_used güncelle
            cursor.execute("""
                UPDATE stores SET last_used = ? WHERE store_key = 'css_berlin'
            """, (datetime.now().isoformat(),))

            conn.commit()
        else:
            cursor.execute("""
                UPDATE publish_history
                SET status = 'failed', error_message = ?
                WHERE id = (
                    SELECT id FROM publish_history
                    WHERE product_id = ? AND status = 'pending'
                    ORDER BY created_at DESC LIMIT 1
                )
            """, (result.get('message', 'Bilinmeyen hata'), product_id))
            conn.commit()

        return result

    except Exception as e:
        logger.error(f"CSS Berlin yayınlama hatası: {e}")
        return {'success': False, 'message': str(e)}
    finally:
        conn.close()


# ============================================================================
# TEST
# ============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("TATANGA - GitHub Publisher Test")
    print("=" * 60)

    publisher = GitHubPublisher()

    # Mevcut ürün sayısı
    data = publisher.load_products()
    print(f"\nMevcut ürün sayısı: {data['stats'].get('total_products', len(data['products']))}")

    # Test ürün ekleme (push olmadan)
    test_product = {
        'title': 'Test Ürün - TATANGA Import',
        'price': 25.00,
        'currency': 'EUR',
        'platform': 'tatanga_test',
        'link': 'https://example.com/test',
        'image': 'https://via.placeholder.com/300',
        'condition': 'Good',
        'brand': 'Test Brand',
        'location': 'DE'
    }

    print("\n[TEST] Ürün ekleniyor (push YAPILMAYACAK)...")
    result = publisher.publish_product(test_product, auto_push=False)
    print(f"Sonuç: {result}")

    print("\n✅ GitHub Publisher hazır!")
    print("\nKullanım:")
    print("1. Dashboard > Favoriler > 🚀 Yayınla")
    print("2. CSS Berlin seç > ✅ Yayınla")
    print("3. Ürün scraped-products.json'a eklenir")
    print("4. Git push yapılır")
    print("5. Cloudflare Pages otomatik build eder")
