#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STORE AGENT - Own Store Notifications Handler
24/7 monitoring of our own stores across platforms

Features:
- Monitors sales notifications
- Customer message alerts
- Low stock warnings
- Review notifications
- Order status tracking
- Telegram notifications with actions

Author: TATANGA Team
Version: 1.0
"""

import sys
import json
import sqlite3
import asyncio
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents.base_agent import BaseAgent, AgentConfig


class NotificationType(Enum):
    """Types of store notifications"""
    SALE = "sale"
    CUSTOMER_MESSAGE = "customer_message"
    LOW_STOCK = "low_stock"
    OUT_OF_STOCK = "out_of_stock"
    REVIEW = "review"
    ORDER_SHIPPED = "order_shipped"
    ORDER_DELIVERED = "order_delivered"
    RETURN_REQUEST = "return_request"
    PRICE_DROP_REQUEST = "price_drop_request"


@dataclass
class StoreNotification:
    """Represents a store notification"""
    id: int
    store_name: str
    platform: str
    notification_type: NotificationType
    product_id: Optional[int] = None
    product_title: Optional[str] = None
    customer_name: Optional[str] = None
    amount: Optional[float] = None
    message: Optional[str] = None
    details: Optional[Dict] = None
    is_read: bool = False
    created_at: Optional[datetime] = None


@dataclass
class StoreConfig:
    """Configuration for a store"""
    store_name: str
    platform: str
    is_active: bool = True
    low_stock_threshold: int = 3
    check_sales: bool = True
    check_messages: bool = True
    check_reviews: bool = True
    check_stock: bool = True


class StoreAgent(BaseAgent):
    """
    24/7 Store Notification Handler

    Monitors our own stores for:
    - New sales
    - Customer messages
    - Low/out of stock
    - Reviews
    - Order updates

    Usage:
        agent = StoreAgent(interval_seconds=300)  # 5 minutes
        agent.start()

        # Add store to monitor
        agent.add_store('cssberlin_vinted', 'vinted_de')

        # Stop agent
        agent.stop()
    """

    def __init__(self, interval_seconds: int = 300):
        """
        Initialize Store Agent

        Args:
            interval_seconds: How often to check stores (default 5 min)
        """
        config = AgentConfig(
            name="store",
            interval_seconds=interval_seconds,
            max_retries=3,
            retry_delay_seconds=10
        )
        super().__init__(config)

        # Notifications database
        self.notifications_db = Path(__file__).parent.parent / 'storage' / 'store_notifications.db'
        self._init_notifications_db()

        # Registered stores
        self.stores: Dict[str, StoreConfig] = {}
        self._load_stores()

        # Stats
        self.notifications_count = 0
        self.sales_total = 0.0

    def _init_notifications_db(self):
        """Initialize store notifications database"""
        self.notifications_db.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.notifications_db)
        cursor = conn.cursor()

        # Store notifications table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS store_notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                store_name TEXT NOT NULL,
                platform TEXT NOT NULL,
                notification_type TEXT NOT NULL,
                product_id INTEGER,
                product_title TEXT,
                customer_name TEXT,
                amount REAL,
                message TEXT,
                details TEXT,
                is_read INTEGER DEFAULT 0,
                notified_telegram INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Registered stores table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS registered_stores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                store_name TEXT UNIQUE NOT NULL,
                platform TEXT NOT NULL,
                is_active INTEGER DEFAULT 1,
                low_stock_threshold INTEGER DEFAULT 3,
                check_sales INTEGER DEFAULT 1,
                check_messages INTEGER DEFAULT 1,
                check_reviews INTEGER DEFAULT 1,
                check_stock INTEGER DEFAULT 1,
                last_checked DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Sales summary table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS store_sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                store_name TEXT NOT NULL,
                platform TEXT NOT NULL,
                product_id INTEGER,
                product_title TEXT,
                buyer_name TEXT,
                sale_price REAL,
                currency TEXT DEFAULT 'EUR',
                order_id TEXT,
                status TEXT DEFAULT 'pending',
                sold_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Index for queries
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_notifications_store_type
            ON store_notifications(store_name, notification_type, created_at)
        """)

        conn.commit()
        conn.close()

    def _load_stores(self):
        """Load registered stores from database"""
        conn = sqlite3.connect(self.notifications_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT store_name, platform, is_active, low_stock_threshold,
                   check_sales, check_messages, check_reviews, check_stock
            FROM registered_stores
            WHERE is_active = 1
        """)

        for row in cursor.fetchall():
            self.stores[row[0]] = StoreConfig(
                store_name=row[0],
                platform=row[1],
                is_active=row[2] == 1,
                low_stock_threshold=row[3],
                check_sales=row[4] == 1,
                check_messages=row[5] == 1,
                check_reviews=row[6] == 1,
                check_stock=row[7] == 1
            )

        conn.close()
        self.logger.info(f"Loaded {len(self.stores)} active stores")

    async def setup(self):
        """Setup hook - called before first process"""
        self.logger.info("Store Agent starting up")
        self.logger.info(f"Monitoring {len(self.stores)} stores")

    async def process(self) -> Dict[str, Any]:
        """
        Main processing loop - check all stores for notifications

        Returns:
            Processing result summary
        """
        results = {
            'stores_checked': 0,
            'new_sales': 0,
            'new_messages': 0,
            'low_stock_alerts': 0,
            'notifications_sent': 0
        }

        if not self.stores:
            return {'status': 'idle', 'message': 'No stores configured'}

        self.logger.info(f"Checking {len(self.stores)} stores")

        for store_name, store_config in self.stores.items():
            try:
                # Check store
                store_results = await self._check_store(store_config)

                results['stores_checked'] += 1
                results['new_sales'] += store_results.get('sales', 0)
                results['new_messages'] += store_results.get('messages', 0)
                results['low_stock_alerts'] += store_results.get('low_stock', 0)
                results['notifications_sent'] += store_results.get('notifications', 0)

                # Update last checked
                self._update_last_checked(store_name)

            except Exception as e:
                self.logger.error(f"Store check error ({store_name}): {e}")

        results['total_notifications'] = self.notifications_count

        return results

    async def _check_store(self, store: StoreConfig) -> Dict[str, int]:
        """
        Check a single store for notifications

        Args:
            store: Store configuration

        Returns:
            Dict with counts of each notification type
        """
        results = {'sales': 0, 'messages': 0, 'low_stock': 0, 'notifications': 0}

        self.logger.info(f"Checking store: {store.store_name} ({store.platform})")

        # Check sales
        if store.check_sales:
            sales = await self._check_sales(store)
            results['sales'] = len(sales)
            for sale in sales:
                await self._notify_sale(store, sale)
                results['notifications'] += 1

        # Check customer messages
        if store.check_messages:
            messages = await self._check_messages(store)
            results['messages'] = len(messages)
            for msg in messages:
                await self._notify_message(store, msg)
                results['notifications'] += 1

        # Check stock levels
        if store.check_stock:
            low_stock = await self._check_stock(store)
            results['low_stock'] = len(low_stock)
            for item in low_stock:
                await self._notify_low_stock(store, item)
                results['notifications'] += 1

        return results

    async def _check_sales(self, store: StoreConfig) -> List[Dict]:
        """Check for new sales (placeholder - implement platform API)"""
        # TODO: Implement actual platform API calls
        # For now, check database for unprocessed sales
        conn = sqlite3.connect(self.notifications_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, product_id, product_title, buyer_name, sale_price, order_id
            FROM store_sales
            WHERE store_name = ?
            AND status = 'pending'
            ORDER BY sold_at DESC
            LIMIT 10
        """, (store.store_name,))

        sales = [
            {
                'id': row[0],
                'product_id': row[1],
                'product_title': row[2],
                'buyer_name': row[3],
                'sale_price': row[4],
                'order_id': row[5]
            }
            for row in cursor.fetchall()
        ]

        conn.close()
        return sales

    async def _check_messages(self, store: StoreConfig) -> List[Dict]:
        """Check for new customer messages (placeholder)"""
        # TODO: Implement actual platform API calls
        return []

    async def _check_stock(self, store: StoreConfig) -> List[Dict]:
        """Check for low stock items (placeholder)"""
        # TODO: Implement actual stock checking
        return []

    async def _notify_sale(self, store: StoreConfig, sale: Dict):
        """Create sale notification and send to Telegram"""
        # Save notification
        notification_id = self._save_notification(
            store_name=store.store_name,
            platform=store.platform,
            notification_type=NotificationType.SALE,
            product_id=sale.get('product_id'),
            product_title=sale.get('product_title'),
            customer_name=sale.get('buyer_name'),
            amount=sale.get('sale_price'),
            details=sale
        )

        # Update sale status
        if sale.get('id'):
            conn = sqlite3.connect(self.notifications_db)
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE store_sales SET status = 'notified' WHERE id = ?",
                (sale['id'],)
            )
            conn.commit()
            conn.close()

        # Track sales
        self.sales_total += sale.get('sale_price', 0)

        # Send Telegram notification
        await self._send_telegram_notification(
            notification_type=NotificationType.SALE,
            store=store,
            data={
                'product': sale.get('product_title', 'Unknown'),
                'buyer': sale.get('buyer_name', 'Unknown'),
                'price': sale.get('sale_price', 0),
                'order_id': sale.get('order_id')
            }
        )

        self.notifications_count += 1

    async def _notify_message(self, store: StoreConfig, message: Dict):
        """Create customer message notification"""
        notification_id = self._save_notification(
            store_name=store.store_name,
            platform=store.platform,
            notification_type=NotificationType.CUSTOMER_MESSAGE,
            product_id=message.get('product_id'),
            customer_name=message.get('customer_name'),
            message=message.get('message'),
            details=message
        )

        await self._send_telegram_notification(
            notification_type=NotificationType.CUSTOMER_MESSAGE,
            store=store,
            data=message
        )

        self.notifications_count += 1

    async def _notify_low_stock(self, store: StoreConfig, item: Dict):
        """Create low stock notification"""
        notification_type = NotificationType.OUT_OF_STOCK if item.get('quantity', 0) == 0 else NotificationType.LOW_STOCK

        notification_id = self._save_notification(
            store_name=store.store_name,
            platform=store.platform,
            notification_type=notification_type,
            product_id=item.get('product_id'),
            product_title=item.get('title'),
            details=item
        )

        await self._send_telegram_notification(
            notification_type=notification_type,
            store=store,
            data=item
        )

        self.notifications_count += 1

    def _save_notification(
        self,
        store_name: str,
        platform: str,
        notification_type: NotificationType,
        product_id: int = None,
        product_title: str = None,
        customer_name: str = None,
        amount: float = None,
        message: str = None,
        details: Dict = None
    ) -> int:
        """Save notification to database"""
        conn = sqlite3.connect(self.notifications_db)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO store_notifications
            (store_name, platform, notification_type, product_id, product_title,
             customer_name, amount, message, details)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            store_name, platform, notification_type.value,
            product_id, product_title, customer_name, amount, message,
            json.dumps(details) if details else None
        ))

        notification_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return notification_id

    async def _send_telegram_notification(
        self,
        notification_type: NotificationType,
        store: StoreConfig,
        data: Dict
    ):
        """Send notification to Telegram"""
        try:
            from integrations.telegram_bot import TatangaTelegramBot

            bot = TatangaTelegramBot()

            # Build message based on type
            if notification_type == NotificationType.SALE:
                message = (
                    f"🎉 *SATIŞ!*\n\n"
                    f"🏪 Mağaza: `{store.store_name}`\n"
                    f"📱 Platform: {store.platform}\n\n"
                    f"📦 Ürün: {data.get('product', 'N/A')}\n"
                    f"👤 Alıcı: {data.get('buyer', 'N/A')}\n"
                    f"💰 Fiyat: €{data.get('price', 0):.2f}\n"
                    f"🔖 Sipariş: #{data.get('order_id', 'N/A')}"
                )

            elif notification_type == NotificationType.CUSTOMER_MESSAGE:
                message = (
                    f"💬 *MÜŞTERİ MESAJI*\n\n"
                    f"🏪 Mağaza: `{store.store_name}`\n"
                    f"👤 Müşteri: {data.get('customer_name', 'N/A')}\n\n"
                    f"📝 *Mesaj:*\n_{data.get('message', 'N/A')[:300]}_"
                )

            elif notification_type == NotificationType.LOW_STOCK:
                message = (
                    f"⚠️ *DÜŞÜK STOK*\n\n"
                    f"🏪 Mağaza: `{store.store_name}`\n"
                    f"📦 Ürün: {data.get('title', 'N/A')}\n"
                    f"📊 Kalan: {data.get('quantity', 0)} adet"
                )

            elif notification_type == NotificationType.OUT_OF_STOCK:
                message = (
                    f"❌ *STOK BİTTİ*\n\n"
                    f"🏪 Mağaza: `{store.store_name}`\n"
                    f"📦 Ürün: {data.get('title', 'N/A')}\n"
                    f"⚠️ Acil stok yenilemesi gerekiyor!"
                )

            else:
                message = (
                    f"🔔 *MAĞAZA BİLDİRİMİ*\n\n"
                    f"🏪 Mağaza: `{store.store_name}`\n"
                    f"📱 Tür: {notification_type.value}\n"
                    f"📝 Detay: {json.dumps(data, ensure_ascii=False)[:200]}"
                )

            await bot.send_notification(message)

            # Mark as notified
            conn = sqlite3.connect(self.notifications_db)
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE store_notifications
                SET notified_telegram = 1
                WHERE store_name = ? AND notified_telegram = 0
                ORDER BY created_at DESC LIMIT 1
            """, (store.store_name,))
            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error(f"Telegram notification failed: {e}")

    def _update_last_checked(self, store_name: str):
        """Update last checked timestamp for store"""
        conn = sqlite3.connect(self.notifications_db)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE registered_stores
            SET last_checked = datetime('now')
            WHERE store_name = ?
        """, (store_name,))

        conn.commit()
        conn.close()

    # ========================================================================
    # PUBLIC API - Store Management
    # ========================================================================

    def add_store(
        self,
        store_name: str,
        platform: str,
        low_stock_threshold: int = 3
    ) -> bool:
        """
        Register a store for monitoring

        Args:
            store_name: Unique store identifier
            platform: Platform name (vinted_de, ebay_de, etc.)
            low_stock_threshold: Stock level to trigger alerts

        Returns:
            True if added successfully
        """
        conn = sqlite3.connect(self.notifications_db)
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT OR REPLACE INTO registered_stores
                (store_name, platform, low_stock_threshold, is_active)
                VALUES (?, ?, ?, 1)
            """, (store_name, platform, low_stock_threshold))

            conn.commit()

            # Add to in-memory dict
            self.stores[store_name] = StoreConfig(
                store_name=store_name,
                platform=platform,
                low_stock_threshold=low_stock_threshold
            )

            self.logger.info(f"Added store: {store_name} ({platform})")
            return True

        except Exception as e:
            self.logger.error(f"Failed to add store: {e}")
            return False

        finally:
            conn.close()

    def remove_store(self, store_name: str) -> bool:
        """Remove a store from monitoring"""
        conn = sqlite3.connect(self.notifications_db)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE registered_stores
            SET is_active = 0
            WHERE store_name = ?
        """, (store_name,))

        affected = cursor.rowcount
        conn.commit()
        conn.close()

        if store_name in self.stores:
            del self.stores[store_name]

        return affected > 0

    def record_sale(
        self,
        store_name: str,
        platform: str,
        product_id: int,
        product_title: str,
        buyer_name: str,
        sale_price: float,
        order_id: str = None,
        currency: str = 'EUR'
    ) -> int:
        """
        Record a sale for notification

        Args:
            store_name: Store identifier
            platform: Platform name
            product_id: Product ID
            product_title: Product title
            buyer_name: Buyer name/username
            sale_price: Sale amount
            order_id: Platform order ID
            currency: Currency code

        Returns:
            Sale record ID
        """
        conn = sqlite3.connect(self.notifications_db)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO store_sales
            (store_name, platform, product_id, product_title, buyer_name,
             sale_price, currency, order_id, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        """, (
            store_name, platform, product_id, product_title,
            buyer_name, sale_price, currency, order_id
        ))

        sale_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Recorded sale: {store_name} - €{sale_price:.2f}")
        return sale_id

    def get_store_stats(self) -> Dict:
        """Get statistics for all monitored stores"""
        conn = sqlite3.connect(self.notifications_db)
        cursor = conn.cursor()

        # Get notification counts by type
        cursor.execute("""
            SELECT notification_type, COUNT(*) as count
            FROM store_notifications
            WHERE created_at > datetime('now', '-24 hours')
            GROUP BY notification_type
        """)
        notification_counts = {row[0]: row[1] for row in cursor.fetchall()}

        # Get sales stats
        cursor.execute("""
            SELECT COUNT(*), SUM(sale_price)
            FROM store_sales
            WHERE sold_at > datetime('now', '-24 hours')
        """)
        sales_row = cursor.fetchone()
        sales_count = sales_row[0] or 0
        sales_total = sales_row[1] or 0

        conn.close()

        return {
            'stores_monitored': len(self.stores),
            'notifications_24h': notification_counts,
            'sales_24h': sales_count,
            'revenue_24h': sales_total,
            'total_notifications': self.notifications_count,
            'total_revenue_session': self.sales_total
        }

    def get_recent_notifications(self, limit: int = 20) -> List[Dict]:
        """Get recent notifications"""
        conn = sqlite3.connect(self.notifications_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, store_name, platform, notification_type, product_title,
                   customer_name, amount, message, is_read, created_at
            FROM store_notifications
            ORDER BY created_at DESC
            LIMIT ?
        """, (limit,))

        notifications = [
            {
                'id': row[0],
                'store_name': row[1],
                'platform': row[2],
                'type': row[3],
                'product_title': row[4],
                'customer_name': row[5],
                'amount': row[6],
                'message': row[7],
                'is_read': row[8] == 1,
                'created_at': row[9]
            }
            for row in cursor.fetchall()
        ]

        conn.close()
        return notifications


# Test
if __name__ == "__main__":
    print("=" * 60)
    print("STORE AGENT - TEST")
    print("=" * 60)
    print()

    # Create agent
    agent = StoreAgent(interval_seconds=300)

    # Add test stores
    print("Adding test stores...")
    agent.add_store('cssberlin_vinted_de', 'vinted_de')
    agent.add_store('cssberlin_ebay', 'ebay_de')
    agent.add_store('cssberlin_kleinanzeigen', 'kleinanzeigen')

    print()
    print(f"Stores monitored: {len(agent.stores)}")
    for name, config in agent.stores.items():
        print(f"  - {name} ({config.platform})")

    print()
    print("Recording test sale...")
    sale_id = agent.record_sale(
        store_name='cssberlin_vinted_de',
        platform='vinted_de',
        product_id=123,
        product_title='Vintage Leather Jacket',
        buyer_name='TestBuyer',
        sale_price=89.99,
        order_id='ORD-12345'
    )
    print(f"Sale recorded with ID: {sale_id}")

    print()
    print("Store stats:")
    stats = agent.get_store_stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")

    print()
    print("Recent notifications:")
    for notif in agent.get_recent_notifications(5):
        print(f"  [{notif['type']}] {notif['store_name']}: {notif.get('product_title', notif.get('message', 'N/A'))[:40]}")

    print()
    print("=" * 60)
    print("To run as background service: agent.start()")
    print("=" * 60)