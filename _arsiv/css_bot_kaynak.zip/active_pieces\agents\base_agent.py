#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BASE AGENT - Foundation for 24/7 AI Workers
Abstract base class for all TATANGA agents

Features:
- Async processing loop
- Configurable intervals
- Status tracking
- Error handling
- Graceful shutdown
- Webhook/cron/event triggers
- Logging integration

Author: TATANGA Team
Version: 1.0
"""

import sys
import asyncio
import signal
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, Optional, Any, Callable, List
import threading
import json
import sqlite3

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.logger import ModuleLogger


class AgentStatus(Enum):
    """Agent status states"""
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    ERROR = "error"
    STOPPING = "stopping"
    STOPPED = "stopped"


@dataclass
class AgentConfig:
    """Configuration for an agent"""
    name: str
    interval_seconds: int = 60
    max_retries: int = 3
    retry_delay_seconds: int = 5
    enabled: bool = True
    auto_start: bool = False
    log_level: str = "INFO"
    metadata: Dict[str, Any] = field(default_factory=dict)


class BaseAgent(ABC):
    """
    Abstract base class for all TATANGA agents

    Provides:
    - Async event loop management
    - Status tracking and reporting
    - Error handling with retries
    - Graceful shutdown
    - Logging
    - Database for state persistence

    Usage:
        class MyAgent(BaseAgent):
            async def process(self):
                # Do work
                pass

        agent = MyAgent(config)
        agent.start()  # Start background processing
        agent.stop()   # Stop gracefully
    """

    def __init__(self, config: AgentConfig):
        """
        Initialize agent

        Args:
            config: Agent configuration
        """
        self.config = config
        self.name = config.name
        self.interval = config.interval_seconds
        self.max_retries = config.max_retries
        self.retry_delay = config.retry_delay_seconds

        # Status
        self.status = AgentStatus.IDLE
        self.last_run: Optional[datetime] = None
        self.next_run: Optional[datetime] = None
        self.run_count = 0
        self.error_count = 0
        self.last_error: Optional[str] = None

        # Control
        self._stop_event = threading.Event()
        self._pause_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        # Logging
        self.logger = ModuleLogger(f"agent.{self.name}")

        # Database for state persistence
        self.db_path = Path(__file__).parent.parent / 'storage' / 'agents.db'
        self._init_database()

        # Callbacks
        self._on_start_callbacks: List[Callable] = []
        self._on_stop_callbacks: List[Callable] = []
        self._on_error_callbacks: List[Callable] = []
        self._on_complete_callbacks: List[Callable] = []

        self.logger.info(f"Agent initialized", name=self.name, interval=self.interval)

    def _init_database(self):
        """Initialize agent state database"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_state (
                agent_name TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                last_run DATETIME,
                run_count INTEGER DEFAULT 0,
                error_count INTEGER DEFAULT 0,
                last_error TEXT,
                metadata TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_name TEXT NOT NULL,
                level TEXT NOT NULL,
                message TEXT NOT NULL,
                details TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Index for fast lookups
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_agent_logs_name
            ON agent_logs(agent_name, created_at DESC)
        """)

        conn.commit()
        conn.close()

    def _save_state(self):
        """Save agent state to database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT OR REPLACE INTO agent_state
                (agent_name, status, last_run, run_count, error_count, last_error, metadata, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
            """, (
                self.name,
                self.status.value,
                self.last_run.isoformat() if self.last_run else None,
                self.run_count,
                self.error_count,
                self.last_error,
                json.dumps(self.config.metadata)
            ))

            conn.commit()
            conn.close()
        except Exception as e:
            self.logger.error("Failed to save state", exception=e)

    def _load_state(self):
        """Load agent state from database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                SELECT status, last_run, run_count, error_count, last_error
                FROM agent_state
                WHERE agent_name = ?
            """, (self.name,))

            row = cursor.fetchone()
            conn.close()

            if row:
                # Restore counts (but not status - always start fresh)
                self.run_count = row[2] or 0
                self.error_count = row[3] or 0
                self.last_error = row[4]
                if row[1]:
                    self.last_run = datetime.fromisoformat(row[1])

        except Exception as e:
            self.logger.error("Failed to load state", exception=e)

    def _log_to_db(self, level: str, message: str, details: Dict = None):
        """Log message to database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO agent_logs (agent_name, level, message, details)
                VALUES (?, ?, ?, ?)
            """, (
                self.name,
                level,
                message,
                json.dumps(details) if details else None
            ))

            conn.commit()
            conn.close()
        except Exception as e:
            print(f"DB log error: {e}")

    @abstractmethod
    async def process(self) -> Any:
        """
        Main processing method - MUST be implemented by subclasses

        This method is called on each interval tick.
        Should contain the agent's main logic.

        Returns:
            Any result from processing
        """
        pass

    async def setup(self):
        """
        Setup method called before first process()
        Override in subclass if needed
        """
        pass

    async def cleanup(self):
        """
        Cleanup method called after stop()
        Override in subclass if needed
        """
        pass

    def on_start(self, callback: Callable):
        """Register callback for agent start"""
        self._on_start_callbacks.append(callback)

    def on_stop(self, callback: Callable):
        """Register callback for agent stop"""
        self._on_stop_callbacks.append(callback)

    def on_error(self, callback: Callable):
        """Register callback for errors"""
        self._on_error_callbacks.append(callback)

    def on_complete(self, callback: Callable):
        """Register callback for successful processing"""
        self._on_complete_callbacks.append(callback)

    def _trigger_callbacks(self, callbacks: List[Callable], *args, **kwargs):
        """Trigger all callbacks in a list"""
        for callback in callbacks:
            try:
                callback(*args, **kwargs)
            except Exception as e:
                self.logger.error("Callback error", exception=e)

    async def _run_loop(self):
        """Main async run loop"""
        self.logger.info("Agent run loop started")
        self._log_to_db("INFO", "Agent started")

        # Setup
        try:
            await self.setup()
        except Exception as e:
            self.logger.error("Setup failed", exception=e)
            self.status = AgentStatus.ERROR
            self.last_error = str(e)
            self._save_state()
            return

        self._trigger_callbacks(self._on_start_callbacks)

        while not self._stop_event.is_set():
            # Check for pause
            if self._pause_event.is_set():
                self.status = AgentStatus.PAUSED
                await asyncio.sleep(1)
                continue

            self.status = AgentStatus.RUNNING
            self.next_run = datetime.now()

            # Process with retry logic
            success = False
            for attempt in range(self.max_retries):
                try:
                    result = await self.process()
                    self.run_count += 1
                    self.last_run = datetime.now()
                    self.last_error = None
                    success = True

                    self._trigger_callbacks(self._on_complete_callbacks, result)
                    self._log_to_db("INFO", "Process completed", {"result": str(result)[:200]})
                    break

                except Exception as e:
                    self.error_count += 1
                    self.last_error = str(e)
                    self.logger.error(
                        f"Process error (attempt {attempt + 1}/{self.max_retries})",
                        exception=e
                    )
                    self._trigger_callbacks(self._on_error_callbacks, e)
                    self._log_to_db("ERROR", f"Process error: {e}", {"attempt": attempt + 1})

                    if attempt < self.max_retries - 1:
                        await asyncio.sleep(self.retry_delay)

            if not success:
                self.status = AgentStatus.ERROR

            self._save_state()

            # Wait for next interval
            self.status = AgentStatus.IDLE
            for _ in range(self.interval):
                if self._stop_event.is_set():
                    break
                await asyncio.sleep(1)

        # Cleanup
        self.status = AgentStatus.STOPPING
        try:
            await self.cleanup()
        except Exception as e:
            self.logger.error("Cleanup error", exception=e)

        self.status = AgentStatus.STOPPED
        self._trigger_callbacks(self._on_stop_callbacks)
        self._save_state()
        self._log_to_db("INFO", "Agent stopped")
        self.logger.info("Agent run loop stopped")

    def _thread_target(self):
        """Thread target that runs the async loop"""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)

        try:
            self._loop.run_until_complete(self._run_loop())
        finally:
            self._loop.close()

    def start(self):
        """Start the agent in a background thread"""
        if self._thread and self._thread.is_alive():
            self.logger.warning("Agent already running")
            return

        self.logger.info("Starting agent")
        self._stop_event.clear()
        self._pause_event.clear()
        self._load_state()

        self._thread = threading.Thread(target=self._thread_target, daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 10.0):
        """
        Stop the agent gracefully

        Args:
            timeout: Maximum time to wait for shutdown
        """
        if not self._thread or not self._thread.is_alive():
            self.logger.warning("Agent not running")
            return

        self.logger.info("Stopping agent")
        self._stop_event.set()
        self._thread.join(timeout=timeout)

        if self._thread.is_alive():
            self.logger.warning("Agent did not stop gracefully")

    def pause(self):
        """Pause the agent"""
        self.logger.info("Pausing agent")
        self._pause_event.set()

    def resume(self):
        """Resume the agent"""
        self.logger.info("Resuming agent")
        self._pause_event.clear()

    def trigger(self):
        """Manually trigger a processing run"""
        if self.status not in [AgentStatus.RUNNING, AgentStatus.PAUSED]:
            self.logger.info("Manual trigger requested")
            # Force immediate processing by temporarily setting interval to 0
            # This is a simple approach - could be improved with an event queue
            asyncio.run_coroutine_threadsafe(self.process(), self._loop)

    def get_status(self) -> Dict:
        """Get current agent status"""
        return {
            'name': self.name,
            'status': self.status.value,
            'last_run': self.last_run.isoformat() if self.last_run else None,
            'next_run': self.next_run.isoformat() if self.next_run else None,
            'run_count': self.run_count,
            'error_count': self.error_count,
            'last_error': self.last_error,
            'interval_seconds': self.interval,
            'is_running': self._thread.is_alive() if self._thread else False
        }

    def get_logs(self, limit: int = 50) -> List[Dict]:
        """Get recent agent logs from database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                SELECT level, message, details, created_at
                FROM agent_logs
                WHERE agent_name = ?
                ORDER BY created_at DESC
                LIMIT ?
            """, (self.name, limit))

            rows = cursor.fetchall()
            conn.close()

            return [
                {
                    'level': row[0],
                    'message': row[1],
                    'details': json.loads(row[2]) if row[2] else None,
                    'timestamp': row[3]
                }
                for row in rows
            ]
        except Exception as e:
            self.logger.error("Failed to get logs", exception=e)
            return []


class SimpleAgent(BaseAgent):
    """
    Simple agent that runs a function periodically

    Usage:
        def my_task():
            print("Doing something")
            return "Done"

        agent = SimpleAgent(
            AgentConfig(name="my_agent", interval_seconds=60),
            task_func=my_task
        )
        agent.start()
    """

    def __init__(self, config: AgentConfig, task_func: Callable):
        super().__init__(config)
        self.task_func = task_func

    async def process(self):
        if asyncio.iscoroutinefunction(self.task_func):
            return await self.task_func()
        else:
            return self.task_func()


# Example usage
if __name__ == "__main__":
    import time

    print("=" * 60)
    print("BASE AGENT - TEST")
    print("=" * 60)
    print()

    # Create a simple test agent
    class TestAgent(BaseAgent):
        async def process(self):
            self.logger.info("Processing...")
            await asyncio.sleep(1)
            return {"status": "ok", "timestamp": datetime.now().isoformat()}

    # Configure agent
    config = AgentConfig(
        name="test_agent",
        interval_seconds=5,
        max_retries=3
    )

    # Create and start agent
    agent = TestAgent(config)

    # Add callbacks
    agent.on_start(lambda: print("[CALLBACK] Agent started!"))
    agent.on_complete(lambda r: print(f"[CALLBACK] Complete: {r}"))
    agent.on_stop(lambda: print("[CALLBACK] Agent stopped!"))

    print("Starting agent...")
    agent.start()

    # Let it run for a bit
    print("Agent running. Press Ctrl+C to stop...")
    try:
        for i in range(15):
            time.sleep(1)
            status = agent.get_status()
            print(f"  Status: {status['status']}, Runs: {status['run_count']}")
    except KeyboardInterrupt:
        pass

    print("\nStopping agent...")
    agent.stop()

    print("\nFinal status:")
    status = agent.get_status()
    for key, value in status.items():
        print(f"  {key}: {value}")

    print("\nRecent logs:")
    for log in agent.get_logs(5):
        print(f"  [{log['level']}] {log['message']}")

    print()
    print("=" * 60)
    print("✓ Test completed!")
    print("=" * 60)
