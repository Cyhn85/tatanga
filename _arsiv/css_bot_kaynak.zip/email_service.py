"""
CSS Berlin - Email Service
Professional email sending with templates
"""

import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import secrets
import logging

logger = logging.getLogger(__name__)

# Email Configuration - Update these with your SMTP settings
SMTP_HOST = os.getenv('SMTP_HOST', 'smtp.ionos.de')
SMTP_PORT = int(os.getenv('SMTP_PORT', '587'))
SMTP_USER = os.getenv('SMTP_USER', 'noreply@cssberlin.de')
SMTP_PASSWORD = os.getenv('SMTP_PASSWORD', '')
FROM_EMAIL = os.getenv('FROM_EMAIL', 'noreply@cssberlin.de')
FROM_NAME = 'CSS Berlin'

# Base URL for links
BASE_URL = os.getenv('BASE_URL', 'https://cssberlin.de')


def get_email_header():
    return '''
    <div style="background-color: #1a1a2e; padding: 20px; text-align: center;">
        <img src="https://cssberlin.de/img/logo.png" alt="CSS Berlin" style="height: 50px;">
    </div>
    '''


def get_email_footer():
    year = datetime.now().year
    return f'''
    <div style="background-color: #f5f5f5; padding: 20px; text-align: center; font-size: 12px; color: #666;">
        <p>CSS Berlin - Second-hand Fashion Marketplace</p>
        <p>&copy; {year} CSS Berlin. Alle Rechte vorbehalten.</p>
        <p>
            <a href="{BASE_URL}/datenschutz.html" style="color: #666;">Datenschutz</a> |
            <a href="{BASE_URL}/agb.html" style="color: #666;">AGB</a> |
            <a href="{BASE_URL}/impressum.html" style="color: #666;">Impressum</a>
        </p>
    </div>
    '''


def create_verification_email(first_name: str, verification_code: str) -> tuple:
    """Create verification email content"""

    subject = "Willkommen bei CSS Berlin - Bitte bestätigen Sie Ihre E-Mail"

    header = get_email_header()
    footer = get_email_footer()

    html_content = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }}
            .container {{ max-width: 600px; margin: 0 auto; background: #ffffff; }}
            .content {{ padding: 30px; }}
            .button {{
                display: inline-block;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white !important;
                padding: 15px 30px;
                text-decoration: none;
                border-radius: 25px;
                font-weight: bold;
                margin: 20px 0;
            }}
            .code {{
                font-size: 32px;
                font-weight: bold;
                letter-spacing: 5px;
                color: #667eea;
                background: #f0f0f0;
                padding: 15px 25px;
                border-radius: 10px;
                display: inline-block;
                margin: 20px 0;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            {header}
            <div class="content">
                <h2>Hallo {first_name}!</h2>
                <p>Vielen Dank für Ihre Registrierung bei <strong>CSS Berlin</strong>!</p>
                <p>Um Ihre E-Mail-Adresse zu bestätigen, verwenden Sie bitte den folgenden Code:</p>

                <div style="text-align: center;">
                    <div class="code">{verification_code}</div>
                </div>

                <p>Oder klicken Sie auf den Button:</p>
                <div style="text-align: center;">
                    <a href="{BASE_URL}/verify-email.html?code={verification_code}" class="button">
                        E-Mail bestätigen
                    </a>
                </div>

                <p style="font-size: 14px; color: #666; margin-top: 30px;">
                    Dieser Code ist <strong>24 Stunden</strong> gültig.<br>
                    Falls Sie sich nicht bei CSS Berlin registriert haben, ignorieren Sie diese E-Mail bitte.
                </p>
            </div>
            {footer}
        </div>
    </body>
    </html>
    '''

    return subject, html_content


def create_password_reset_email(first_name: str, reset_code: str) -> tuple:
    """Create password reset email content"""

    subject = "CSS Berlin - Passwort zurücksetzen"

    header = get_email_header()
    footer = get_email_footer()

    html_content = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }}
            .container {{ max-width: 600px; margin: 0 auto; background: #ffffff; }}
            .content {{ padding: 30px; }}
            .button {{
                display: inline-block;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white !important;
                padding: 15px 30px;
                text-decoration: none;
                border-radius: 25px;
                font-weight: bold;
                margin: 20px 0;
            }}
            .code {{
                font-size: 32px;
                font-weight: bold;
                letter-spacing: 5px;
                color: #667eea;
                background: #f0f0f0;
                padding: 15px 25px;
                border-radius: 10px;
                display: inline-block;
                margin: 20px 0;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            {header}
            <div class="content">
                <h2>Hallo {first_name}!</h2>
                <p>Sie haben eine Anfrage zum Zurücksetzen Ihres Passworts gestellt.</p>
                <p>Verwenden Sie den folgenden Code:</p>

                <div style="text-align: center;">
                    <div class="code">{reset_code}</div>
                </div>

                <p>Oder klicken Sie auf den Button:</p>
                <div style="text-align: center;">
                    <a href="{BASE_URL}/reset-password.html?code={reset_code}" class="button">
                        Passwort zurücksetzen
                    </a>
                </div>

                <p style="font-size: 14px; color: #666; margin-top: 30px;">
                    Dieser Code ist <strong>1 Stunde</strong> gültig.<br>
                    Falls Sie kein neues Passwort angefordert haben, ignorieren Sie diese E-Mail.
                </p>
            </div>
            {footer}
        </div>
    </body>
    </html>
    '''

    return subject, html_content


def create_welcome_email(first_name: str) -> tuple:
    """Create welcome email after verification"""

    subject = "Willkommen bei CSS Berlin!"

    header = get_email_header()
    footer = get_email_footer()

    html_content = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }}
            .container {{ max-width: 600px; margin: 0 auto; background: #ffffff; }}
            .content {{ padding: 30px; }}
            .button {{
                display: inline-block;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white !important;
                padding: 15px 30px;
                text-decoration: none;
                border-radius: 25px;
                font-weight: bold;
                margin: 10px 5px;
            }}
            .feature {{ padding: 15px; margin: 10px 0; background: #f9f9f9; border-radius: 10px; }}
        </style>
    </head>
    <body>
        <div class="container">
            {header}
            <div class="content">
                <h2>Herzlich Willkommen, {first_name}!</h2>
                <p>Ihre E-Mail wurde erfolgreich bestätigt. Sie sind jetzt Teil der CSS Berlin Community!</p>

                <h3>Was Sie jetzt tun können:</h3>

                <div class="feature">
                    <strong>Einkaufen</strong><br>
                    Entdecken Sie tausende Second-hand Fashion Artikel
                </div>

                <div class="feature">
                    <strong>Verkaufen</strong><br>
                    Verdienen Sie Geld mit Kleidung, die Sie nicht mehr tragen
                </div>

                <div class="feature">
                    <strong>Verhandeln</strong><br>
                    Machen Sie Angebote und finden Sie den besten Preis
                </div>

                <div style="text-align: center; margin-top: 30px;">
                    <a href="{BASE_URL}" class="button">Jetzt stöbern</a>
                    <a href="{BASE_URL}/inserieren.html" class="button">Artikel verkaufen</a>
                </div>
            </div>
            {footer}
        </div>
    </body>
    </html>
    '''

    return subject, html_content


def generate_verification_code() -> str:
    """Generate a 6-digit verification code"""
    return ''.join([str(secrets.randbelow(10)) for _ in range(6)])


async def send_email(to_email: str, subject: str, html_content: str) -> bool:
    """Send email via SMTP"""

    if not SMTP_PASSWORD:
        logger.error("SMTP_PASSWORD not configured!")
        return False

    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = f"{FROM_NAME} <{FROM_EMAIL}>"
        msg['To'] = to_email

        # Add HTML content
        html_part = MIMEText(html_content, 'html', 'utf-8')
        msg.attach(html_part)

        # Connect and send
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.send_message(msg)

        logger.info(f"Email sent successfully to {to_email}")
        return True

    except Exception as e:
        logger.error(f"Failed to send email to {to_email}: {str(e)}")
        return False


async def send_verification_email(to_email: str, first_name: str, verification_code: str) -> bool:
    """Send verification email to user"""
    subject, html_content = create_verification_email(first_name, verification_code)
    return await send_email(to_email, subject, html_content)


async def send_password_reset_email(to_email: str, first_name: str, reset_code: str) -> bool:
    """Send password reset email"""
    subject, html_content = create_password_reset_email(first_name, reset_code)
    return await send_email(to_email, subject, html_content)


async def send_welcome_email(to_email: str, first_name: str) -> bool:
    """Send welcome email after verification"""
    subject, html_content = create_welcome_email(first_name)
    return await send_email(to_email, subject, html_content)