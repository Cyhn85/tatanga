"""
TATANGA V3 - Human-like Scraper Service
Supports: Vinted, eBay, Kleinanzeigen, Tradera, Willhaben, Sellpy, Percentil
"""
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from urllib.parse import urlencode, quote
from datetime import datetime
from typing import Dict, List, Optional
import time
import random
import logging
import math

logger = logging.getLogger("TATANGA.scraper")

# Platform condition mappings
VINTED_CONDITIONS = {
    "new": 6,
    "like_new": 1,
    "very_good": 2,
    "good": 3,
    "acceptable": 4
}

EBAY_CONDITIONS = {
    "new": 1000,
    "like_new": 2500,
    "very_good": 3000,
    "good": 4000,
    "acceptable": 5000
}


class HumanBehavior:
    """Simulate human-like browser behavior"""

    @staticmethod
    def random_delay(min_sec: float = 0.5, max_sec: float = 2.0):
        """Random delay like human reading/thinking"""
        time.sleep(random.uniform(min_sec, max_sec))

    @staticmethod
    def human_scroll(driver, scroll_amount: int = None, direction: str = "down"):
        """Scroll like a human - variable speed, sometimes pause"""
        if scroll_amount is None:
            scroll_amount = random.randint(200, 600)

        if direction == "up":
            scroll_amount = -scroll_amount

        # Smooth scroll with variable chunks
        chunks = random.randint(3, 8)
        chunk_size = scroll_amount // chunks

        for i in range(chunks):
            driver.execute_script(f"window.scrollBy(0, {chunk_size})")
            time.sleep(random.uniform(0.05, 0.15))

            # Sometimes pause mid-scroll like reading
            if random.random() < 0.2:
                time.sleep(random.uniform(0.3, 0.8))

    @staticmethod
    def random_mouse_movement(driver, element=None):
        """Move mouse randomly, optionally to element"""
        try:
            actions = ActionChains(driver)

            if element:
                # Move to element with offset
                offset_x = random.randint(-5, 5)
                offset_y = random.randint(-5, 5)
                actions.move_to_element_with_offset(element, offset_x, offset_y)
            else:
                # Random movement
                x = random.randint(100, 800)
                y = random.randint(100, 600)
                actions.move_by_offset(x, y)

            actions.perform()
            time.sleep(random.uniform(0.1, 0.3))
        except:
            pass

    @staticmethod
    def simulate_reading(min_sec: float = 1.0, max_sec: float = 4.0):
        """Simulate human reading time"""
        time.sleep(random.uniform(min_sec, max_sec))

    @staticmethod
    def random_action(driver):
        """Perform random human-like action"""
        action_type = random.choice(["scroll", "pause", "move", "nothing"])

        if action_type == "scroll":
            direction = random.choice(["up", "down"])
            HumanBehavior.human_scroll(driver, direction=direction)
        elif action_type == "pause":
            time.sleep(random.uniform(0.5, 1.5))
        elif action_type == "move":
            HumanBehavior.random_mouse_movement(driver)


class ScraperService:
    """Multi-platform scraper with human-like behavior"""

    PLATFORMS = {
        "vinted": {"base_url": "https://www.vinted.de", "country": "DE"},
        "ebay": {"base_url": "https://www.ebay.de", "country": "DE"},
        "kleinanzeigen": {"base_url": "https://www.kleinanzeigen.de", "country": "DE"},
        "tradera": {"base_url": "https://www.tradera.com", "country": "SE"},
        "willhaben": {"base_url": "https://www.willhaben.at", "country": "AT"},
        "sellpy": {"base_url": "https://www.sellpy.de", "country": "DE"},
        "percentil": {"base_url": "https://www.percentil.de", "country": "DE"}
    }

    def __init__(self, headless: bool = True):
        self.headless = headless
        self.driver = None
        self.human = HumanBehavior()

    def _init_driver(self):
        if self.driver:
            return

        options = uc.ChromeOptions()

        if self.headless:
            options.add_argument("--headless=new")

        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--lang=de-DE")

        # Randomize user agent
        user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/119.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
        ]
        options.add_argument(f"--user-agent={random.choice(user_agents)}")

        self.driver = uc.Chrome(options=options)
        self.driver.implicitly_wait(10)
        logger.info("Chrome driver initialized")

    def _close_cookies(self):
        """Accept cookie banners"""
        selectors = [
            "#onetrust-accept-btn-handler",
            "[data-testid='cookie-accept']",
            ".cookie-consent-accept",
            "#didomi-notice-agree-button",
            "[id*='accept']",
            "[class*='accept-cookies']",
            "button[class*='consent']"
        ]

        for selector in selectors:
            try:
                btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.human.random_mouse_movement(self.driver, btn)
                    btn.click()
                    self.human.random_delay(0.5, 1.0)
                    logger.info("Closed cookie banner")
                    return
            except:
                pass

    def _human_scroll_page(self, scroll_times: int = 3):
        """Scroll page like human with pauses"""
        for i in range(scroll_times):
            self.human.human_scroll(self.driver)
            self.human.random_delay(0.3, 1.0)

            # Random action between scrolls
            if random.random() < 0.3:
                self.human.random_action(self.driver)

    def _visit_random_product(self, products: List, platform: str) -> Optional[Dict]:
        """Click on a random product, view it, maybe visit seller, then go back"""
        if not products or random.random() > 0.4:  # 40% chance to visit
            return None

        try:
            product = random.choice(products[:min(10, len(products))])
            product_url = product.get("url")

            if not product_url:
                return None

            logger.info(f"Visiting product: {product_url[:50]}...")
            self.driver.get(product_url)
            self.human.random_delay(2, 4)

            # Simulate reading product
            self.human.simulate_reading(2, 5)
            self._human_scroll_page(random.randint(1, 3))

            # Maybe visit seller profile (30% chance)
            if random.random() < 0.3:
                self._visit_seller_profile(platform)

            # Go back
            self.driver.back()
            self.human.random_delay(1, 2)

            return product
        except Exception as e:
            logger.warning(f"Failed to visit product: {e}")
            return None

    def _visit_seller_profile(self, platform: str):
        """Visit seller/user profile"""
        try:
            seller_selectors = {
                "vinted": "[data-testid='user-link'], .ItemBox__overlay a",
                "ebay": ".ux-seller-section__item--seller a, .s-item__seller-info a",
                "kleinanzeigen": ".userprofile-vip, .text-link-secondary",
                "willhaben": ".UserInfo-link",
                "tradera": ".seller-link",
            }

            selector = seller_selectors.get(platform)
            if not selector:
                return

            seller_link = self.driver.find_element(By.CSS_SELECTOR, selector)
            if seller_link:
                self.human.random_mouse_movement(self.driver, seller_link)
                seller_link.click()
                logger.info("Visited seller profile")
                self.human.simulate_reading(2, 4)
                self.driver.back()
                self.human.random_delay(1, 2)
        except:
            pass

    def _navigate_to_next_page(self, platform: str, current_page: int) -> bool:
        """Navigate to next page with human behavior"""
        try:
            next_selectors = {
                "vinted": "[data-testid='pagination-next'], .Pagination__next",
                "ebay": ".pagination__next, a[aria-label='Next']",
                "kleinanzeigen": ".pagination-next, [data-testid='pagination-next']",
                "willhaben": "[data-testid='pagination-top-next-button']",
                "tradera": ".pagination-next",
                "sellpy": "[aria-label='Next page']",
                "percentil": ".pagination__next"
            }

            selector = next_selectors.get(platform)
            if not selector:
                return False

            # First scroll to bottom to see pagination
            self.human.human_scroll(self.driver, 500)
            self.human.random_delay(0.5, 1.0)

            next_btn = self.driver.find_element(By.CSS_SELECTOR, selector)
            if next_btn and next_btn.is_enabled():
                self.human.random_mouse_movement(self.driver, next_btn)
                next_btn.click()
                self.human.random_delay(2, 4)
                return True
        except Exception as e:
            logger.debug(f"No next page: {e}")

        return False

    # URL Builders for each platform
    def _build_vinted_url(self, query, min_price=None, max_price=None, condition=None, sort=None):
        base = "https://www.vinted.de/catalog"
        params = {"search_text": query}
        if min_price: params["price_from"] = int(min_price)
        if max_price: params["price_to"] = int(max_price)
        if condition and condition in VINTED_CONDITIONS:
            params["status_ids[]"] = VINTED_CONDITIONS[condition]
        if sort == "price_asc": params["order"] = "price_low_to_high"
        elif sort == "price_desc": params["order"] = "price_high_to_low"
        else: params["order"] = "newest_first"
        return f"{base}?{urlencode(params)}"

    def _build_ebay_url(self, query, min_price=None, max_price=None, condition=None, sort=None):
        base = "https://www.ebay.de/sch/i.html"
        params = {"_nkw": query}
        if min_price: params["_udlo"] = int(min_price)
        if max_price: params["_udhi"] = int(max_price)
        if condition and condition in EBAY_CONDITIONS:
            params["LH_ItemCondition"] = EBAY_CONDITIONS[condition]
        if sort == "price_asc": params["_sop"] = 15
        elif sort == "price_desc": params["_sop"] = 16
        else: params["_sop"] = 10
        return f"{base}?{urlencode(params)}"

    def _build_kleinanzeigen_url(self, query, min_price=None, max_price=None, condition=None, sort=None):
        base = "https://www.kleinanzeigen.de/s-"
        price_part = ""
        if min_price or max_price:
            p_min = int(min_price) if min_price else ""
            p_max = int(max_price) if max_price else ""
            price_part = f"preis:{p_min}:{p_max}/"
        return f"{base}{price_part}{query.replace(' ', '-')}/k0"

    def _build_tradera_url(self, query, min_price=None, max_price=None, condition=None, sort=None):
        base = "https://www.tradera.com/search"
        params = {"q": query}
        if min_price: params["priceMin"] = int(min_price)
        if max_price: params["priceMax"] = int(max_price)
        if sort == "price_asc": params["sortBy"] = "Price"
        elif sort == "price_desc": params["sortBy"] = "PriceDesc"
        return f"{base}?{urlencode(params)}"

    def _build_willhaben_url(self, query, min_price=None, max_price=None, condition=None, sort=None):
        base = "https://www.willhaben.at/iad/kaufen-und-verkaufen/marktplatz"
        params = {"keyword": query}
        if min_price: params["PRICE_FROM"] = int(min_price)
        if max_price: params["PRICE_TO"] = int(max_price)
        if sort == "price_asc": params["sort"] = "1"
        elif sort == "price_desc": params["sort"] = "2"
        return f"{base}?{urlencode(params)}"

    def _build_sellpy_url(self, query, min_price=None, max_price=None, condition=None, sort=None):
        base = "https://www.sellpy.de/search"
        params = {"q": query}
        if min_price: params["minPrice"] = int(min_price)
        if max_price: params["maxPrice"] = int(max_price)
        return f"{base}?{urlencode(params)}"

    def _build_percentil_url(self, query, min_price=None, max_price=None, condition=None, sort=None):
        base = "https://www.percentil.de/search"
        params = {"q": query}
        if min_price: params["price_min"] = int(min_price)
        if max_price: params["price_max"] = int(max_price)
        return f"{base}?{urlencode(params)}"

    # Extractors for each platform
    def _extract_vinted(self) -> List[Dict]:
        products = []
        try:
            items = self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='grid-item'], .feed-grid__item")
            for item in items[:50]:
                try:
                    url = item.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
                    title = item.find_element(By.CSS_SELECTOR, "[data-testid='description-title'], .ItemBox__title").text
                    try:
                        price_text = item.find_element(By.CSS_SELECTOR, "[data-testid='price-text'], .ItemBox__price").text
                        price = float(price_text.replace("EUR", "").replace(",", ".").strip())
                    except:
                        price = None
                    try:
                        image = item.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                    except:
                        image = None

                    products.append({
                        "url": url, "title": title, "price": price, "image": image,
                        "platform": "vinted", "scraped_at": datetime.now().isoformat()
                    })
                except:
                    pass
        except Exception as e:
            logger.warning(f"Vinted extraction error: {e}")
        return products

    def _extract_ebay(self) -> List[Dict]:
        products = []
        try:
            items = self.driver.find_elements(By.CSS_SELECTOR, ".s-item, .srp-results .s-item__wrapper")
            for item in items[:50]:
                try:
                    url = item.find_element(By.CSS_SELECTOR, ".s-item__link").get_attribute("href")
                    title = item.find_element(By.CSS_SELECTOR, ".s-item__title").text
                    try:
                        price_text = item.find_element(By.CSS_SELECTOR, ".s-item__price").text
                        price = float(price_text.split()[0].replace("EUR", "").replace(",", ".").strip())
                    except:
                        price = None
                    try:
                        image = item.find_element(By.CSS_SELECTOR, ".s-item__image img").get_attribute("src")
                    except:
                        image = None

                    if "Shop on eBay" not in title:
                        products.append({
                            "url": url, "title": title, "price": price, "image": image,
                            "platform": "ebay", "scraped_at": datetime.now().isoformat()
                        })
                except:
                    pass
        except Exception as e:
            logger.warning(f"eBay extraction error: {e}")
        return products

    def _extract_kleinanzeigen(self) -> List[Dict]:
        products = []
        try:
            items = self.driver.find_elements(By.CSS_SELECTOR, ".aditem, [data-testid='aditem']")
            for item in items[:50]:
                try:
                    url = item.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
                    if not url.startswith("http"):
                        url = "https://www.kleinanzeigen.de" + url
                    title = item.find_element(By.CSS_SELECTOR, ".ellipsis, .text-module-begin").text
                    try:
                        price_text = item.find_element(By.CSS_SELECTOR, ".aditem-main--middle--price-shipping--price, .aditem-main--middle--price").text
                        price = float(price_text.replace("EUR", "").replace("VB", "").replace(",", ".").strip())
                    except:
                        price = None
                    try:
                        image = item.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                    except:
                        image = None

                    products.append({
                        "url": url, "title": title, "price": price, "image": image,
                        "platform": "kleinanzeigen", "scraped_at": datetime.now().isoformat()
                    })
                except:
                    pass
        except Exception as e:
            logger.warning(f"Kleinanzeigen extraction error: {e}")
        return products

    def _extract_tradera(self) -> List[Dict]:
        products = []
        try:
            items = self.driver.find_elements(By.CSS_SELECTOR, ".item-card, [data-testid='search-item']")
            for item in items[:50]:
                try:
                    url = item.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
                    if not url.startswith("http"):
                        url = "https://www.tradera.com" + url
                    title = item.find_element(By.CSS_SELECTOR, ".item-card__title, h3").text
                    try:
                        price_text = item.find_element(By.CSS_SELECTOR, ".item-card__price, .price").text
                        price = float(price_text.replace("kr", "").replace(" ", "").replace(",", ".").strip())
                    except:
                        price = None
                    try:
                        image = item.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                    except:
                        image = None

                    products.append({
                        "url": url, "title": title, "price": price, "image": image,
                        "platform": "tradera", "scraped_at": datetime.now().isoformat()
                    })
                except:
                    pass
        except Exception as e:
            logger.warning(f"Tradera extraction error: {e}")
        return products

    def _extract_willhaben(self) -> List[Dict]:
        products = []
        try:
            items = self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='ad-list-item'], .search-result-entry")
            for item in items[:50]:
                try:
                    url = item.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
                    if not url.startswith("http"):
                        url = "https://www.willhaben.at" + url
                    title = item.find_element(By.CSS_SELECTOR, "[data-testid='ad-description'], h3").text
                    try:
                        price_text = item.find_element(By.CSS_SELECTOR, "[data-testid='ad-price'], .info-1st-row").text
                        price = float(price_text.replace("EUR", "").replace(" ", "").replace(",", ".").strip())
                    except:
                        price = None
                    try:
                        image = item.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                    except:
                        image = None

                    products.append({
                        "url": url, "title": title, "price": price, "image": image,
                        "platform": "willhaben", "scraped_at": datetime.now().isoformat()
                    })
                except:
                    pass
        except Exception as e:
            logger.warning(f"Willhaben extraction error: {e}")
        return products

    def _extract_sellpy(self) -> List[Dict]:
        products = []
        try:
            items = self.driver.find_elements(By.CSS_SELECTOR, "[data-testid='product-card'], .product-card")
            for item in items[:50]:
                try:
                    url = item.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
                    if not url.startswith("http"):
                        url = "https://www.sellpy.de" + url
                    title = item.find_element(By.CSS_SELECTOR, "[data-testid='product-title'], .product-title").text
                    try:
                        price_text = item.find_element(By.CSS_SELECTOR, "[data-testid='product-price'], .product-price").text
                        price = float(price_text.replace("EUR", "").replace(",", ".").strip())
                    except:
                        price = None
                    try:
                        image = item.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                    except:
                        image = None

                    products.append({
                        "url": url, "title": title, "price": price, "image": image,
                        "platform": "sellpy", "scraped_at": datetime.now().isoformat()
                    })
                except:
                    pass
        except Exception as e:
            logger.warning(f"Sellpy extraction error: {e}")
        return products

    def _extract_percentil(self) -> List[Dict]:
        products = []
        try:
            items = self.driver.find_elements(By.CSS_SELECTOR, ".product-card, .product-item")
            for item in items[:50]:
                try:
                    url = item.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
                    if not url.startswith("http"):
                        url = "https://www.percentil.de" + url
                    title = item.find_element(By.CSS_SELECTOR, ".product-name, h3").text
                    try:
                        price_text = item.find_element(By.CSS_SELECTOR, ".product-price, .price").text
                        price = float(price_text.replace("EUR", "").replace(",", ".").strip())
                    except:
                        price = None
                    try:
                        image = item.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                    except:
                        image = None

                    products.append({
                        "url": url, "title": title, "price": price, "image": image,
                        "platform": "percentil", "scraped_at": datetime.now().isoformat()
                    })
                except:
                    pass
        except Exception as e:
            logger.warning(f"Percentil extraction error: {e}")
        return products

    def scrape(self, platform: str, query: str, max_pages: int = 3, max_items: int = 50,
               min_price: float = None, max_price: float = None, condition: str = None, sort: str = None) -> Dict:
        """Main scraping method with human-like behavior"""
        result = {
            "status": "pending",
            "platform": platform,
            "query": query,
            "products": [],
            "stats": {
                "pages_scraped": 0,
                "items_found": 0,
                "started_at": datetime.now().isoformat(),
                "completed_at": None
            }
        }

        try:
            self._init_driver()

            # Build URL based on platform
            url_builders = {
                "vinted": self._build_vinted_url,
                "ebay": self._build_ebay_url,
                "kleinanzeigen": self._build_kleinanzeigen_url,
                "tradera": self._build_tradera_url,
                "willhaben": self._build_willhaben_url,
                "sellpy": self._build_sellpy_url,
                "percentil": self._build_percentil_url
            }

            builder = url_builders.get(platform)
            if not builder:
                result["status"] = "error"
                result["error"] = f"Unknown platform: {platform}"
                return result

            search_url = builder(query, min_price, max_price, condition, sort)
            logger.info(f"Scraping {platform}: {query} - URL: {search_url}")

            # Navigate to search page
            self.driver.get(search_url)
            self.human.random_delay(3, 5)

            self._close_cookies()
            self.human.random_delay(1, 2)

            all_products = []
            extractors = {
                "vinted": self._extract_vinted,
                "ebay": self._extract_ebay,
                "kleinanzeigen": self._extract_kleinanzeigen,
                "tradera": self._extract_tradera,
                "willhaben": self._extract_willhaben,
                "sellpy": self._extract_sellpy,
                "percentil": self._extract_percentil
            }

            for page in range(max_pages):
                logger.info(f"Page {page + 1}/{max_pages}")

                # Human-like scrolling
                self._human_scroll_page(random.randint(2, 4))
                self.human.random_delay(1, 2)

                # Extract products
                extractor = extractors.get(platform)
                if extractor:
                    products = extractor()
                else:
                    products = []

                # Add unique products
                existing_urls = {p["url"] for p in all_products}
                new_products = [p for p in products if p.get("url") and p["url"] not in existing_urls]
                all_products.extend(new_products)

                result["stats"]["pages_scraped"] += 1
                logger.info(f"Found {len(new_products)} new products on page {page + 1}")

                # Maybe visit a random product (human behavior)
                if random.random() < 0.25:
                    self._visit_random_product(new_products, platform)

                # Check if we have enough
                if len(all_products) >= max_items:
                    break

                # Navigate to next page
                if page < max_pages - 1:
                    if not self._navigate_to_next_page(platform, page + 1):
                        logger.info("No more pages available")
                        break
                    self.human.random_delay(2, 4)

            # Trim to max_items
            all_products = all_products[:max_items]
            result["products"] = all_products
            result["stats"]["items_found"] = len(all_products)
            result["stats"]["completed_at"] = datetime.now().isoformat()
            result["status"] = "completed"

        except Exception as e:
            logger.error(f"Scraping error: {e}")
            result["status"] = "error"
            result["error"] = str(e)

        return result

    def close(self):
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            self.driver = None


def run_scrape_task(platform: str, query: str, max_pages: int = 3, max_items: int = 50,
                   min_price: float = None, max_price: float = None, condition: str = None, sort: str = None) -> Dict:
    """Run scraping task"""
    scraper = ScraperService(headless=True)
    try:
        return scraper.scrape(platform, query, max_pages, max_items, min_price, max_price, condition, sort)
    finally:
        scraper.close()
