@echo off
echo ============================================
echo TATANGA Triaj Merkezi API
echo ============================================
echo.

cd /d "%~dp0"

echo Checking dependencies...
pip install fastapi uvicorn -q

echo.
echo Starting FastAPI Server...
echo URL: http://localhost:8080
echo Docs: http://localhost:8080/docs
echo.

python api/triaj_api.py

pause
