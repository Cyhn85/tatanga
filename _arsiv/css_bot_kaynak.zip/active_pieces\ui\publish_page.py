#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Publishing Center UI
Multi-platform product publishing with image processing
"""

import streamlit as st
import sqlite3
import json
from pathlib import Path
from datetime import datetime
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

# Database path
DB_PATH = Path(__file__).parent.parent / "tatanga.db"

# Import connectors
try:
    from integrations.kleinanzeigen_connector import KleinanzeigenConnector
    KLEINANZEIGEN_AVAILABLE = True
except ImportError:
    KLEINANZEIGEN_AVAILABLE = False

try:
    from integrations.vinted_connector import VintedConnector
    VINTED_AVAILABLE = True
except ImportError:
    VINTED_AVAILABLE = False

try:
    from integrations.github_publisher import GitHubPublisher
    GITHUB_AVAILABLE = True
except ImportError:
    GITHUB_AVAILABLE = False

# Import image processor
try:
    from integrations.image_processor import ImageProcessor
    IMAGE_PROCESSOR_AVAILABLE = True
except ImportError:
    IMAGE_PROCESSOR_AVAILABLE = False

# Import category mapper
try:
    from category_mapper import (
        map_category_to_vinted,
        map_condition_to_vinted,
        get_vinted_condition_label,
        detect_category_from_title,
        KLEINANZEIGEN_TO_VINTED,
        VINTED_CONDITIONS
    )
    MAPPER_AVAILABLE = True
except ImportError:
    MAPPER_AVAILABLE = False


def get_favorites():
    """Get all favorite products from database."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("""
        SELECT * FROM products
        WHERE is_favorite = 1
        ORDER BY updated_at DESC
        LIMIT 100
    """)

    products = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return products


def get_publish_history(product_id: int):
    """Get publish history for a product."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("""
        SELECT * FROM publish_history
        WHERE product_id = ?
        ORDER BY created_at DESC
    """, (product_id,))

    history = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return history


def save_publish_history(
    product_id: int,
    platform: str,
    status: str,
    external_id: str = None,
    external_url: str = None,
    price: float = None,
    category: str = None,
    condition: str = None,
    images_count: int = 0,
    error: str = None
):
    """Save publish attempt to history."""
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO publish_history
        (product_id, platform, publish_status, external_listing_id,
         external_listing_url, publish_price, category_used, condition_used,
         images_count, error_message, published_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        product_id, platform, status, external_id, external_url,
        price, category, condition, images_count, error,
        datetime.now().isoformat() if status == 'success' else None
    ))

    conn.commit()
    conn.close()


def render_publish_page():
    """Render the publishing center page."""
    st.markdown("""
        <h1 style='text-align: center; margin-bottom: 0;'>
            📤 YAYINLAMA MERKEZİ
        </h1>
        <p style='text-align: center; color: #888; margin-top: 5px;'>
            Multi-Platform Ürün Yayınlama
        </p>
    """, unsafe_allow_html=True)

    st.markdown("---")

    # Platform durumları
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        if GITHUB_AVAILABLE:
            st.success("✅ CSS Berlin")
        else:
            st.error("❌ CSS Berlin")
    with col2:
        if KLEINANZEIGEN_AVAILABLE:
            st.success("✅ Kleinanzeigen")
        else:
            st.warning("⚠️ Kleinanzeigen")
    with col3:
        if VINTED_AVAILABLE:
            st.success("✅ Vinted")
        else:
            st.warning("⚠️ Vinted")
    with col4:
        if IMAGE_PROCESSOR_AVAILABLE:
            st.success("✅ Görsel İşleme")
        else:
            st.warning("⚠️ Görsel İşleme")

    st.markdown("---")

    # Favorilerden ürün seç
    favorites = get_favorites()

    if not favorites:
        st.warning("⚠️ Henüz favori ürün yok. Önce gelen kutusundan ürünleri favorilere ekleyin.")
        return

    # Ürün seçici
    product_options = {
        f"{p['title'][:50]}... ({p.get('platform', 'N/A')}) - {p.get('price', 0)}{p.get('currency', '€')}": p['id']
        for p in favorites
    }

    selected_label = st.selectbox(
        "📦 Yayınlanacak Ürün",
        options=list(product_options.keys()),
        help="Favorilerden bir ürün seçin"
    )

    if not selected_label:
        return

    selected_id = product_options[selected_label]
    selected_product = next((p for p in favorites if p['id'] == selected_id), None)

    if not selected_product:
        return

    # Ürün önizleme
    st.markdown("### 📋 Ürün Önizleme")

    col1, col2 = st.columns([1, 2])

    with col1:
        # Görseller
        images = []
        try:
            images = json.loads(selected_product.get('images', '[]'))
        except:
            pass

        if images:
            # İlk görsel büyük
            st.image(images[0], use_container_width=True)

            # Diğer görseller küçük
            if len(images) > 1:
                cols = st.columns(min(4, len(images) - 1))
                for i, img in enumerate(images[1:5]):
                    with cols[i]:
                        st.image(img, use_container_width=True)

            st.caption(f"📸 {len(images)} görsel mevcut")
        else:
            st.warning("⚠️ Görsel bulunamadı")

    with col2:
        # Ürün bilgileri
        st.markdown(f"**Başlık:** {selected_product.get('title', 'N/A')}")
        st.markdown(f"**Kaynak:** {selected_product.get('platform', 'N/A')}")
        st.markdown(f"**Fiyat:** {selected_product.get('price', 0)} {selected_product.get('currency', '€')}")

        # Durum (varsa)
        condition = selected_product.get('source_condition') or selected_product.get('condition', '')
        if condition:
            st.markdown(f"**Durum:** {condition}")

        # Kategori algılama
        detected_cat = None
        if MAPPER_AVAILABLE:
            detected_cat = detect_category_from_title(selected_product.get('title', ''))
            if detected_cat:
                st.markdown(f"**Algılanan Kategori:** {detected_cat}")

    st.markdown("---")

    # Yayın ayarları
    st.markdown("### ⚙️ Yayın Ayarları")

    col1, col2 = st.columns(2)

    with col1:
        # Hedef platformlar
        st.markdown("**🎯 Hedef Platformlar:**")
        publish_css = st.checkbox("CSS Berlin (GitHub)", value=GITHUB_AVAILABLE, disabled=not GITHUB_AVAILABLE)
        publish_kleinanzeigen = st.checkbox("Kleinanzeigen", value=False, disabled=not KLEINANZEIGEN_AVAILABLE)
        publish_vinted = st.checkbox("Vinted DE", value=False, disabled=not VINTED_AVAILABLE)

    with col2:
        # Satış fiyatı
        default_price = float(selected_product.get('price', 0) or 0) * 1.8  # %80 kar marjı
        publish_price = st.number_input(
            "💰 Satış Fiyatı (€)",
            min_value=0.0,
            value=round(default_price, 2),
            step=1.0,
            help="Önerilen: Alış fiyatının 1.8-2x katı"
        )

        # Durum seçimi
        condition_options = list(VINTED_CONDITIONS.values()) if MAPPER_AVAILABLE else [
            "Neu mit Etikett", "Neu ohne Etikett", "Sehr gut", "Gut", "Zufriedenstellend"
        ]
        publish_condition = st.selectbox(
            "📝 Ürün Durumu",
            options=condition_options,
            index=2  # Default: Sehr gut
        )

    # Görsel işleme ayarları
    st.markdown("---")
    st.markdown("### 🖼️ Görsel İşleme")

    col1, col2 = st.columns(2)

    with col1:
        process_images = st.checkbox(
            "Görsel İşleme Aktif",
            value=IMAGE_PROCESSOR_AVAILABLE,
            disabled=not IMAGE_PROCESSOR_AVAILABLE,
            help="Görselleri duplicate detection bypass için işler"
        )

    with col2:
        manipulation_level = st.select_slider(
            "Manipülasyon Seviyesi",
            options=["light", "medium", "aggressive", "ultra"],
            value="medium",
            disabled=not process_images,
            help="Light: %98 bypass, %97 kalite | Ultra: %100 bypass, %88 kalite"
        )

    # Minimum resim garantisi
    ensure_min_images = st.checkbox(
        "Minimum 5 resim garantile (eksik resimler augment edilir)",
        value=True,
        disabled=not IMAGE_PROCESSOR_AVAILABLE
    )

    st.markdown("---")

    # Yayın geçmişi
    with st.expander("📜 Yayın Geçmişi", expanded=False):
        history = get_publish_history(selected_id)
        if history:
            for h in history:
                status_icon = "✅" if h['publish_status'] == 'success' else "❌"
                st.markdown(f"""
                    {status_icon} **{h['platform']}** - {h['created_at'][:16]}
                    {"- " + h['external_listing_url'] if h.get('external_listing_url') else ""}
                    {" | Error: " + h['error_message'] if h.get('error_message') else ""}
                """)
        else:
            st.info("Henüz yayın geçmişi yok")

    st.markdown("---")

    # Yayınla butonu
    if st.button("🚀 YAYINLA", type="primary", use_container_width=True):
        if not any([publish_css, publish_kleinanzeigen, publish_vinted]):
            st.error("❌ En az bir platform seçmelisiniz!")
            return

        with st.spinner("Yayınlanıyor..."):
            progress = st.progress(0)
            status_text = st.empty()

            results = {}
            platforms_to_publish = []

            if publish_css:
                platforms_to_publish.append("css_berlin")
            if publish_kleinanzeigen:
                platforms_to_publish.append("kleinanzeigen")
            if publish_vinted:
                platforms_to_publish.append("vinted")

            # 1. Görsel işleme
            processed_images = images
            if process_images and IMAGE_PROCESSOR_AVAILABLE and images:
                status_text.text("🖼️ Görseller işleniyor...")
                progress.progress(10)

                try:
                    processor = ImageProcessor()
                    result = processor.process_from_urls(
                        urls=images,
                        minimum=5 if ensure_min_images else 1,
                        platform=platforms_to_publish[0] if platforms_to_publish else 'vinted',
                        manipulation_level=manipulation_level
                    )

                    if result['success']:
                        processed_images = [str(p) for p in result['images']]
                        st.info(f"✅ {result['processed_count']} görsel işlendi" +
                               (f", {result['augmented_count']} augment edildi" if result['augmented_count'] > 0 else ""))
                except Exception as e:
                    st.warning(f"⚠️ Görsel işleme hatası: {e}")

            progress.progress(30)

            # 2. CSS Berlin yayını
            if publish_css and GITHUB_AVAILABLE:
                status_text.text("📤 CSS Berlin'e yayınlanıyor...")
                try:
                    publisher = GitHubPublisher()
                    css_result = publisher.publish_product({
                        'title': selected_product.get('title'),
                        'price': publish_price,
                        'description': selected_product.get('description', ''),
                        'images': processed_images[:5],
                        'condition': publish_condition,
                        'source_url': selected_product.get('url')
                    })

                    if css_result.get('success'):
                        results['css_berlin'] = {'status': 'success', 'url': css_result.get('url')}
                        save_publish_history(
                            selected_id, 'css_berlin', 'success',
                            external_url=css_result.get('url'),
                            price=publish_price,
                            images_count=len(processed_images)
                        )
                        st.success(f"✅ CSS Berlin: {css_result.get('url')}")
                    else:
                        results['css_berlin'] = {'status': 'error', 'error': css_result.get('error')}
                        save_publish_history(
                            selected_id, 'css_berlin', 'error',
                            error=css_result.get('error')
                        )
                        st.error(f"❌ CSS Berlin: {css_result.get('error')}")
                except Exception as e:
                    results['css_berlin'] = {'status': 'error', 'error': str(e)}
                    save_publish_history(selected_id, 'css_berlin', 'error', error=str(e))
                    st.error(f"❌ CSS Berlin hatası: {e}")

            progress.progress(50)

            # 3. Kleinanzeigen yayını
            if publish_kleinanzeigen and KLEINANZEIGEN_AVAILABLE:
                status_text.text("📤 Kleinanzeigen'e yayınlanıyor...")
                st.info("ℹ️ Kleinanzeigen yayını manuel onay gerektirir (Selenium)")
                # Not: Gerçek implementasyon için Kleinanzeigen login ve listing oluşturma gerekli
                save_publish_history(
                    selected_id, 'kleinanzeigen', 'pending',
                    price=publish_price,
                    condition=publish_condition,
                    images_count=len(processed_images)
                )
                results['kleinanzeigen'] = {'status': 'pending', 'message': 'Manuel işlem gerekli'}

            progress.progress(70)

            # 4. Vinted yayını
            if publish_vinted and VINTED_AVAILABLE:
                status_text.text("📤 Vinted'e yayınlanıyor...")
                st.info("ℹ️ Vinted yayını manuel onay gerektirir (Selenium)")
                # Not: Gerçek implementasyon için Vinted login ve listing oluşturma gerekli
                save_publish_history(
                    selected_id, 'vinted', 'pending',
                    price=publish_price,
                    condition=publish_condition,
                    images_count=len(processed_images)
                )
                results['vinted'] = {'status': 'pending', 'message': 'Manuel işlem gerekli'}

            progress.progress(100)
            status_text.text("✅ Yayın işlemi tamamlandı!")

            # Özet
            st.markdown("### 📊 Sonuç Özeti")
            for platform, result in results.items():
                if result['status'] == 'success':
                    st.success(f"✅ {platform}: Başarılı")
                elif result['status'] == 'pending':
                    st.warning(f"⏳ {platform}: Beklemede")
                else:
                    st.error(f"❌ {platform}: Hata - {result.get('error', 'Bilinmeyen hata')}")


if __name__ == "__main__":
    st.set_page_config(page_title="TATANGA - Yayınlama", layout="wide")
    render_publish_page()
