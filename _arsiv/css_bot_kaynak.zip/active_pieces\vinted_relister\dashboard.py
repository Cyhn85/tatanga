# Vinted Relister Dashboard - TAM GUI TABANLI
# Streamlit UI - Tum islemler butonlarla yapilir

import os
import sys
import subprocess
import threading
import time
import queue
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import streamlit as st

# Import local modules
from config import (
    VINTED_PROFILE_URL, DAILY_UPLOAD_LIMIT,
    UPLOAD_START_HOUR, UPLOAD_END_HOUR,
    STATUS_RAW, STATUS_IMAGE_DONE, STATUS_SEO_DONE,
    STATUS_VALIDATED, STATUS_UPLOADED, DASHBOARD_PORT
)
from utils.database import db

# Page config
st.set_page_config(
    page_title="Vinted Relister",
    page_icon="",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'logs' not in st.session_state:
    st.session_state.logs = []
if 'running_flows' not in st.session_state:
    st.session_state.running_flows = {
        'scraper': False,
        'image': False,
        'seo': False,
        'validator': False,
        'uploader': False
    }
if 'log_queue' not in st.session_state:
    st.session_state.log_queue = queue.Queue()


def add_log(message: str):
    """Add log message with timestamp - both to session and file"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    log_entry = f"[{timestamp}] {message}"

    # Add to session state if available
    try:
        st.session_state.logs.append(log_entry)
        # Keep only last 100 logs
        if len(st.session_state.logs) > 100:
            st.session_state.logs = st.session_state.logs[-100:]
    except:
        pass

    # Always write to file for thread safety
    log_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dashboard_logs.txt')
    try:
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(log_entry + '\n')
    except:
        pass

    # Also print to console
    print(log_entry)


def read_logs_from_file(limit: int = 50) -> list:
    """Read recent logs from file"""
    log_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dashboard_logs.txt')
    try:
        if os.path.exists(log_file):
            with open(log_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                return lines[-limit:] if len(lines) > limit else lines
    except:
        pass
    return []


def clear_log_file():
    """Clear the log file"""
    log_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dashboard_logs.txt')
    try:
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write('')
    except:
        pass


def run_flow_in_background(flow_name: str, module_name: str, args: list = None):
    """Run a flow module in background using subprocess"""

    def worker():
        st.session_state.running_flows[flow_name] = True
        add_log(f"[BASLATILDI] {flow_name.upper()} calisiyor...")

        try:
            cmd = [sys.executable, '-m', module_name]
            if args:
                cmd.extend(args)

            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=os.path.dirname(os.path.abspath(__file__)),
                text=True,
                bufsize=1
            )

            # Read output line by line
            for line in iter(process.stdout.readline, ''):
                if line:
                    add_log(line.strip())

            process.wait()

            if process.returncode == 0:
                add_log(f"[TAMAMLANDI] {flow_name.upper()} basariyla bitti!")
            else:
                add_log(f"[HATA] {flow_name.upper()} hata ile sonlandi (kod: {process.returncode})")

        except Exception as e:
            add_log(f"[HATA] {flow_name.upper()}: {str(e)}")
        finally:
            st.session_state.running_flows[flow_name] = False

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()


def get_status_label(status: int) -> str:
    """Get human-readable status label"""
    labels = {
        0: "Ham",
        1: "Resim OK",
        2: "SEO OK",
        3: "Dogrulanmis",
        4: "Onay Bekliyor",
        5: "Yuklendi"
    }
    return labels.get(status, f"Bilinmiyor ({status})")


def main():
    """Main dashboard"""

    # Sidebar navigation
    st.sidebar.title("Vinted Relister")
    st.sidebar.markdown("---")

    page = st.sidebar.radio(
        "Sayfa",
        ["Ana Panel", "Otomasyon", "Magazalar", "Urunler", "Loglar"]
    )

    st.sidebar.markdown("---")

    # Quick stats in sidebar
    stats = db.get_statistics()
    st.sidebar.metric("Toplam Urun", stats.get('total_products', 0))
    st.sidebar.metric("Yuklenen", stats.get('uploaded', 0))
    st.sidebar.metric("Bekleyen", stats.get('total_products', 0) - stats.get('uploaded', 0))

    # Page routing
    if page == "Ana Panel":
        show_dashboard(stats)
    elif page == "Otomasyon":
        show_automation()
    elif page == "Magazalar":
        show_stores()
    elif page == "Urunler":
        show_products()
    elif page == "Loglar":
        show_logs()


def show_dashboard(stats: dict):
    """Main dashboard page"""
    st.title("Vinted Relister Dashboard")

    # Status overview
    col1, col2, col3, col4, col5 = st.columns(5)

    with col1:
        st.metric("Ham", stats.get('raw', 0))
    with col2:
        st.metric("Resim OK", stats.get('image_done', 0))
    with col3:
        st.metric("SEO OK", stats.get('seo_done', 0))
    with col4:
        st.metric("Dogrulanmis", stats.get('validated', 0))
    with col5:
        st.metric("Yuklendi", stats.get('uploaded', 0))

    st.markdown("---")

    # Progress bar
    total = stats.get('total_products', 0)
    uploaded = stats.get('uploaded', 0)
    if total > 0:
        progress = uploaded / total
        st.progress(progress, text=f"Ilerleme: {uploaded}/{total} ({progress*100:.1f}%)")

    # Estimated completion
    if uploaded < total:
        remaining = total - uploaded
        days_remaining = (remaining // DAILY_UPLOAD_LIMIT) + 1
        st.info(f"Tahmini bitis: {days_remaining} gun ({DAILY_UPLOAD_LIMIT} urun/gun)")

    st.markdown("---")

    # Quick Actions
    st.subheader("Hizli Islemler")

    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("Tum Akisi Baslat", type="primary", use_container_width=True):
            if not any(st.session_state.running_flows.values()):
                add_log("=== TUM AKIS BASLATILDI ===")
                # Run flows sequentially would need a special handler
                st.warning("Tum akis icin Otomasyon sayfasina gidin")
            else:
                st.error("Zaten bir islem calisiyor!")

    with col2:
        if st.button("Istatistikleri Yenile", use_container_width=True):
            st.rerun()

    with col3:
        if st.button("Loglari Temizle", use_container_width=True):
            st.session_state.logs = []
            add_log("Loglar temizlendi")
            st.rerun()

    # Running status
    st.markdown("---")
    st.subheader("Calisma Durumu")

    running = [name for name, status in st.session_state.running_flows.items() if status]
    if running:
        st.warning(f"Calisan islemler: {', '.join(running)}")
    else:
        st.success("Tum islemler bosta")

    # Recent logs
    st.markdown("---")
    st.subheader("Son Loglar")

    log_container = st.container()
    with log_container:
        if st.session_state.logs:
            for log in st.session_state.logs[-10:]:
                st.text(log)
        else:
            st.info("Henuz log yok")


def show_automation():
    """Automation control page - MAIN CONTROL CENTER"""
    st.title("Otomasyon Kontrol Merkezi")

    st.markdown("""
    Bu sayfadan tum islemleri butonlarla baslatabilirsiniz.
    Her buton ilgili islemi arka planda calistirir.
    """)

    st.markdown("---")

    # Flow Control Cards
    col1, col2, col3 = st.columns(3)

    # SCRAPER
    with col1:
        st.subheader("1. Scraper")
        st.caption("Vinted'den urunleri ceker")

        stats = db.get_statistics()
        st.metric("Cekilecek", "83 urun")

        if st.session_state.running_flows['scraper']:
            st.warning("Calisiyor...")
            if st.button("Durdur", key="stop_scraper"):
                st.session_state.running_flows['scraper'] = False
                add_log("[DURDURULDU] Scraper durduruldu")
        else:
            if st.button("Scraper Baslat", key="start_scraper", type="primary", use_container_width=True):
                run_flow_in_background('scraper', 'flows.flow1_scraper')
                st.rerun()

    # IMAGE PROCESSOR
    with col2:
        st.subheader("2. Resim Isleme")
        st.caption("Arka plan siler, beyaz fon ekler")

        stats = db.get_statistics()
        st.metric("Islenecek", stats.get('raw', 0))

        if st.session_state.running_flows['image']:
            st.warning("Calisiyor...")
            if st.button("Durdur", key="stop_image"):
                st.session_state.running_flows['image'] = False
        else:
            if st.button("Resim Islemeyi Baslat", key="start_image", type="primary", use_container_width=True):
                run_flow_in_background('image', 'flows.flow2_image')
                st.rerun()

    # SEO REWRITER
    with col3:
        st.subheader("3. SEO Uretici")
        st.caption("Groq ile Almanca icerik uretir")

        stats = db.get_statistics()
        st.metric("Islenecek", stats.get('image_done', 0))

        seo_style = st.selectbox("Stil", ["balanced", "conservative", "aggressive"], key="seo_style")

        if st.session_state.running_flows['seo']:
            st.warning("Calisiyor...")
            if st.button("Durdur", key="stop_seo"):
                st.session_state.running_flows['seo'] = False
        else:
            if st.button("SEO Uretimini Baslat", key="start_seo", type="primary", use_container_width=True):
                run_flow_in_background('seo', 'flows.flow3_seo', ['--style', seo_style])
                st.rerun()

    st.markdown("---")

    col4, col5, col6 = st.columns(3)

    # VALIDATOR
    with col4:
        st.subheader("4. Dogrulayici")
        st.caption("Gemini ile icerik kontrol eder")

        stats = db.get_statistics()
        st.metric("Islenecek", stats.get('seo_done', 0))

        if st.session_state.running_flows['validator']:
            st.warning("Calisiyor...")
            if st.button("Durdur", key="stop_validator"):
                st.session_state.running_flows['validator'] = False
        else:
            if st.button("Dogrulamayi Baslat", key="start_validator", type="primary", use_container_width=True):
                run_flow_in_background('validator', 'flows.flow4_validator')
                st.rerun()

    # UPLOADER
    with col5:
        st.subheader("5. Yukleyici")
        st.caption("Vinted'e urun yukler")

        stats = db.get_statistics()
        validated = stats.get('validated', 0)
        st.metric("Yuklenecek", validated)

        # Check upload window
        now = datetime.now()
        if UPLOAD_START_HOUR <= now.hour < UPLOAD_END_HOUR:
            st.success(f"Yukleme penceresi ACIK")
        else:
            st.warning(f"Yukleme penceresi: {UPLOAD_START_HOUR}:00-{UPLOAD_END_HOUR}:00")

        if st.session_state.running_flows['uploader']:
            st.warning("Calisiyor...")
            if st.button("Durdur", key="stop_uploader"):
                st.session_state.running_flows['uploader'] = False
        else:
            if st.button("Yuklemeyi Baslat", key="start_uploader", type="primary", use_container_width=True):
                run_flow_in_background('uploader', 'flows.flow5_uploader')
                st.rerun()

    # FULL PIPELINE
    with col6:
        st.subheader("Tam Akis")
        st.caption("Tum adimlari sirayla calistirir")

        if any(st.session_state.running_flows.values()):
            running = [k for k, v in st.session_state.running_flows.items() if v]
            st.warning(f"Calisan: {', '.join(running)}")
        else:
            if st.button("TUM AKISI BASLAT", key="start_all", type="primary", use_container_width=True):
                add_log("=== TAM AKIS BASLATILDI ===")
                add_log("Adim 1: Scraper baslatiliyor...")
                run_flow_in_background('scraper', 'flows.flow1_scraper')
                st.rerun()

    # Live Logs Section
    st.markdown("---")
    st.subheader("Canli Log")

    # Auto-refresh toggle
    auto_refresh = st.checkbox("Otomatik yenile (her 5 saniye)", value=False)

    log_area = st.empty()
    with log_area.container():
        if st.session_state.logs:
            log_text = "\n".join(st.session_state.logs[-30:])
            st.code(log_text, language=None)
        else:
            st.info("Henuz log yok. Bir islem baslatin.")

    if auto_refresh:
        time.sleep(5)
        st.rerun()


def run_login_test(store_id: int, store_name: str, chrome_profile: str, login_type: str,
                   email: str, password: str, proxy_host: str = '', proxy_port: int = 0):
    """Run login test using subprocess (avoids Playwright threading issues)"""
    import json

    def worker():
        proxy_info = f" (Proxy: {proxy_host}:{proxy_port})" if proxy_host and proxy_port else ""
        add_log(f"[LOGIN TEST] {store_name} icin baslatildi{proxy_info}...")
        add_log(f"[INFO] Chrome profil: {chrome_profile}")

        try:
            # Build command for subprocess
            script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'utils', 'login_test_runner.py')

            cmd = [
                sys.executable, script_path,
                '--chrome-profile', chrome_profile,
                '--login-type', login_type
            ]

            if email:
                cmd.extend(['--email', email])
            if password:
                cmd.extend(['--password', password])
            if proxy_host:
                cmd.extend(['--proxy-host', proxy_host])
            if proxy_port:
                cmd.extend(['--proxy-port', str(proxy_port)])

            add_log(f"[INFO] Login test subprocess baslatiliyor...")

            # Run subprocess
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=os.path.dirname(os.path.abspath(__file__)),
                text=True
            )

            # Read output
            output_lines = []
            result_json = None

            for line in iter(process.stdout.readline, ''):
                if line:
                    line = line.strip()
                    output_lines.append(line)

                    if line == "---RESULT_JSON---":
                        # Next line is the JSON result
                        json_line = process.stdout.readline().strip()
                        if json_line:
                            try:
                                result_json = json.loads(json_line)
                            except:
                                add_log(f"[WARN] JSON parse hatasi: {json_line[:50]}")
                    elif line.startswith('['):
                        add_log(line[:100])

            process.wait()

            if result_json:
                if result_json.get('success'):
                    proxy_msg = f" [Proxy: {result_json.get('proxy', 'yok')}]" if result_json.get('proxy_used') else ""
                    add_log(f"[LOGIN OK] {store_name}: {result_json.get('message', 'Basarili')}{proxy_msg}")
                    db.update_store_login_status(store_id, 'active')
                else:
                    add_log(f"[LOGIN FAIL] {store_name}: {result_json.get('message', 'Bilinmeyen hata')}")
                    db.update_store_login_status(store_id, 'failed')
            else:
                add_log(f"[ERROR] Test sonucu alinamadi")
                # Show last few output lines
                for line in output_lines[-5:]:
                    add_log(f"  {line[:100]}")
                db.update_store_login_status(store_id, 'error')

        except Exception as e:
            add_log(f"[ERROR] {store_name}: {str(e)}")
            db.update_store_login_status(store_id, 'error')

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()


def get_login_status_icon(status: str) -> str:
    """Get status icon for login status"""
    icons = {
        'active': '[AKTIF]',
        'failed': '[BASARISIZ]',
        'error': '[HATA]',
        'unknown': '[BILINMIYOR]'
    }
    return icons.get(status, '[?]')


def show_stores():
    """Store management page with LOGIN CREDENTIALS"""
    st.title("Magaza ve Login Yonetimi")

    stores = db.get_stores()
    source_stores = [s for s in stores if s.get('is_source')]
    target_stores = [s for s in stores if not s.get('is_source')]

    # Overview
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Toplam Magaza", len(stores))
    with col2:
        st.metric("Kaynak Magaza", len(source_stores))
    with col3:
        st.metric("Hedef Magaza", len(target_stores))

    st.markdown("---")

    # ========== SOURCE STORES SECTION ==========
    st.subheader("KAYNAK MAGAZALAR (Urun Cekilecek)")

    if source_stores:
        for store in source_stores:
            store_id = store.get('id')
            store_name = store.get('store_name')
            login_status = store.get('login_status', 'unknown')
            login_type = store.get('login_type', 'email')

            with st.expander(f"{get_login_status_icon(login_status)} {store_name}", expanded=False):
                col1, col2 = st.columns([2, 1])

                proxy_enabled = store.get('proxy_enabled', 0)
                proxy_host = store.get('proxy_host', '')
                proxy_port = store.get('proxy_port', 0)

                with col1:
                    st.markdown(f"""
                    **Profil URL:** `{store.get('profile_url')}`
                    **Chrome Profil:** `{store.get('chrome_profile')}`
                    **Login Tipi:** `{login_type}`
                    **Login Durumu:** `{login_status}`
                    """)

                    # Show credentials if exists
                    if store.get('login_email'):
                        st.markdown(f"**E-Mail:** `{store.get('login_email')}`")

                    # Show proxy info if enabled
                    if proxy_enabled and proxy_host:
                        st.markdown(f"**Proxy:** `{proxy_host}:{proxy_port}`")

                with col2:
                    # Login Test Button
                    if st.button("Login Test", key=f"test_src_{store_id}", type="primary"):
                        run_login_test(
                            store_id=store_id,
                            store_name=store_name,
                            chrome_profile=store.get('chrome_profile', 'Default'),
                            login_type=login_type,
                            email=store.get('login_email', ''),
                            password=store.get('login_password', ''),
                            proxy_host=proxy_host if proxy_enabled else '',
                            proxy_port=proxy_port if proxy_enabled else 0
                        )
                        st.info("Login testi baslatildi - Loglari kontrol edin")
                        st.rerun()

                    if st.button("Scrape Baslat", key=f"scrape_{store_id}"):
                        run_flow_in_background('scraper', 'flows.flow1_scraper')
                        st.rerun()

                    if st.button("Sil", key=f"del_src_{store_id}"):
                        db.delete_store(store_id)
                        st.rerun()

                # Edit credentials form
                st.markdown("---")
                st.markdown("**Giris Bilgilerini Guncelle:**")

                edit_col1, edit_col2 = st.columns(2)
                with edit_col1:
                    new_email = st.text_input("E-Mail", value=store.get('login_email', ''), key=f"email_src_{store_id}")
                    new_password = st.text_input("Sifre", value=store.get('login_password', ''), type="password", key=f"pass_src_{store_id}")
                with edit_col2:
                    new_login_type = st.selectbox("Login Tipi", ["email", "google"], index=0 if login_type == 'email' else 1, key=f"type_src_{store_id}")
                    new_chrome = st.text_input("Chrome Profil", value=store.get('chrome_profile', 'Default'), key=f"chrome_src_{store_id}")

                # Proxy settings
                st.markdown("**Proxy Ayarlari (IP Izolasyonu):**")
                proxy_col1, proxy_col2, proxy_col3 = st.columns([1, 2, 1])
                with proxy_col1:
                    new_proxy_enabled = st.checkbox("Proxy Aktif", value=bool(proxy_enabled), key=f"proxy_en_src_{store_id}")
                with proxy_col2:
                    new_proxy_host = st.text_input("Proxy Host", value=proxy_host or "192.168.43.1", key=f"proxy_host_src_{store_id}")
                with proxy_col3:
                    new_proxy_port = st.number_input("Port", value=proxy_port or 8080, min_value=0, max_value=65535, key=f"proxy_port_src_{store_id}")

                if st.button("Kaydet", key=f"save_src_{store_id}"):
                    db.update_store(store_id, {
                        'login_email': new_email,
                        'login_password': new_password,
                        'login_type': new_login_type,
                        'chrome_profile': new_chrome,
                        'proxy_enabled': 1 if new_proxy_enabled else 0,
                        'proxy_host': new_proxy_host,
                        'proxy_port': int(new_proxy_port)
                    })
                    st.success("Guncellendi!")
                    st.rerun()
    else:
        st.info("Henuz kaynak magaza yok. Asagidan ekleyin.")

    st.markdown("---")

    # ========== TARGET STORES SECTION ==========
    st.subheader("HEDEF MAGAZALAR (Urun Yuklenecek)")

    if target_stores:
        for store in target_stores:
            store_id = store.get('id')
            store_name = store.get('store_name')
            login_status = store.get('login_status', 'unknown')
            login_type = store.get('login_type', 'email')

            proxy_enabled = store.get('proxy_enabled', 0)
            proxy_host = store.get('proxy_host', '')
            proxy_port = store.get('proxy_port', 0)

            with st.expander(f"{get_login_status_icon(login_status)} {store_name}", expanded=False):
                col1, col2 = st.columns([2, 1])

                with col1:
                    st.markdown(f"""
                    **Profil URL:** `{store.get('profile_url')}`
                    **Chrome Profil:** `{store.get('chrome_profile')}`
                    **Login Tipi:** `{login_type}`
                    **Login Durumu:** `{login_status}`
                    **Gunluk Limit:** `{store.get('daily_limit')}`
                    **Yukleme Saatleri:** `{store.get('upload_start_hour')}:00 - {store.get('upload_end_hour')}:00`
                    """)

                    if store.get('login_email'):
                        st.markdown(f"**E-Mail:** `{store.get('login_email')}`")

                    # Show proxy info if enabled
                    if proxy_enabled and proxy_host:
                        st.markdown(f"**Proxy:** `{proxy_host}:{proxy_port}`")

                with col2:
                    if st.button("Login Test", key=f"test_tgt_{store_id}", type="primary"):
                        run_login_test(
                            store_id=store_id,
                            store_name=store_name,
                            chrome_profile=store.get('chrome_profile', 'Default'),
                            login_type=login_type,
                            email=store.get('login_email', ''),
                            password=store.get('login_password', ''),
                            proxy_host=proxy_host if proxy_enabled else '',
                            proxy_port=proxy_port if proxy_enabled else 0
                        )
                        st.info("Login testi baslatildi")
                        st.rerun()

                    if st.button("Upload Baslat", key=f"upload_{store_id}"):
                        run_flow_in_background('uploader', 'flows.flow5_uploader')
                        st.rerun()

                    if st.button("Sil", key=f"del_tgt_{store_id}"):
                        db.delete_store(store_id)
                        st.rerun()

                # Edit credentials
                st.markdown("---")
                st.markdown("**Giris Bilgilerini Guncelle:**")

                edit_col1, edit_col2 = st.columns(2)
                with edit_col1:
                    new_email = st.text_input("E-Mail", value=store.get('login_email', ''), key=f"email_tgt_{store_id}")
                    new_password = st.text_input("Sifre", value=store.get('login_password', ''), type="password", key=f"pass_tgt_{store_id}")
                with edit_col2:
                    new_login_type = st.selectbox("Login Tipi", ["email", "google"], index=0 if login_type == 'email' else 1, key=f"type_tgt_{store_id}")
                    new_chrome = st.text_input("Chrome Profil", value=store.get('chrome_profile', 'Default'), key=f"chrome_tgt_{store_id}")

                # Proxy settings
                st.markdown("**Proxy Ayarlari (IP Izolasyonu):**")
                proxy_col1, proxy_col2, proxy_col3 = st.columns([1, 2, 1])
                with proxy_col1:
                    new_proxy_enabled = st.checkbox("Proxy Aktif", value=bool(proxy_enabled), key=f"proxy_en_tgt_{store_id}")
                with proxy_col2:
                    new_proxy_host = st.text_input("Proxy Host", value=proxy_host or "192.168.43.1", key=f"proxy_host_tgt_{store_id}")
                with proxy_col3:
                    new_proxy_port = st.number_input("Port", value=proxy_port or 8080, min_value=0, max_value=65535, key=f"proxy_port_tgt_{store_id}")

                if st.button("Kaydet", key=f"save_tgt_{store_id}"):
                    db.update_store(store_id, {
                        'login_email': new_email,
                        'login_password': new_password,
                        'login_type': new_login_type,
                        'chrome_profile': new_chrome,
                        'proxy_enabled': 1 if new_proxy_enabled else 0,
                        'proxy_host': new_proxy_host,
                        'proxy_port': int(new_proxy_port)
                    })
                    st.success("Guncellendi!")
                    st.rerun()
    else:
        st.info("Henuz hedef magaza yok. Asagidan ekleyin.")

    # ========== PRODUCT FLOW MAPPING ==========
    st.markdown("---")
    st.subheader("URUN AKIS ESLESTIRMESI")

    if source_stores and (target_stores or source_stores):
        col1, col2, col3 = st.columns([2, 1, 2])

        with col1:
            source_options = [s.get('store_name') for s in source_stores]
            selected_source = st.selectbox("Kaynak Magaza", source_options, key="flow_source")

        with col2:
            st.markdown("<br><center>--></center>", unsafe_allow_html=True)

        with col3:
            all_targets = source_stores + target_stores
            target_options = [s.get('store_name') for s in all_targets]
            selected_target = st.selectbox("Hedef Magaza", target_options, key="flow_target")

        if selected_source and selected_target:
            if selected_source == selected_target:
                st.info(f"{selected_source} -> {selected_target} (Ayni hesaba yeniden yukleme)")
            else:
                st.success(f"{selected_source} -> {selected_target} (Farkli hesaba kopyalama)")

            if st.button("Bu Akisi Baslat", type="primary"):
                add_log(f"Akis baslatildi: {selected_source} -> {selected_target}")
                run_flow_in_background('scraper', 'flows.flow1_scraper')
                st.rerun()
    else:
        st.warning("Akis olusturmak icin en az bir kaynak magaza ekleyin.")

    st.markdown("---")

    # ========== ADD NEW STORE WITH CREDENTIALS ==========
    st.subheader("Yeni Magaza Ekle (Login Bilgileri ile)")

    tab1, tab2 = st.tabs(["Kaynak Magaza", "Hedef Magaza"])

    with tab1:
        with st.form("add_source_store"):
            st.markdown("**Kaynak magaza:** Urunlerin cekilecegi Vinted hesabi")

            col1, col2 = st.columns(2)
            with col1:
                src_store_name = st.text_input("Magaza Adi *", placeholder="cyhn85", key="src_name")
                src_profile_url = st.text_input("Profil URL", value="https://www.vinted.de/member/", key="src_url")
            with col2:
                src_chrome_profile = st.text_input("Chrome Profil", value="Default", key="src_chrome")
                src_login_type = st.selectbox("Login Tipi", ["email", "google"], key="src_login_type")

            st.markdown("**Giris Bilgileri:**")
            col3, col4 = st.columns(2)
            with col3:
                src_email = st.text_input("E-Mail", placeholder="cssberlin@hotmail.com", key="src_email")
            with col4:
                src_password = st.text_input("Sifre", type="password", placeholder="******", key="src_password")

            if st.form_submit_button("Kaynak Magaza Ekle", type="primary"):
                if src_store_name:
                    db.add_store({
                        'store_name': src_store_name,
                        'profile_url': src_profile_url,
                        'chrome_profile': src_chrome_profile,
                        'is_source': True,
                        'is_active': True,
                        'daily_limit': 0,
                        'upload_start_hour': 0,
                        'upload_end_hour': 0,
                        'login_email': src_email,
                        'login_password': src_password,
                        'login_type': src_login_type,
                        'login_status': 'unknown'
                    })
                    st.success(f"Kaynak magaza '{src_store_name}' eklendi!")
                    st.rerun()
                else:
                    st.error("Magaza adi gerekli!")

    with tab2:
        with st.form("add_target_store"):
            st.markdown("**Hedef magaza:** Urunlerin yuklenecegi Vinted hesabi")

            col1, col2 = st.columns(2)
            with col1:
                tgt_store_name = st.text_input("Magaza Adi *", placeholder="store2", key="tgt_name")
                tgt_profile_url = st.text_input("Profil URL", value="https://www.vinted.de/member/", key="tgt_url")
            with col2:
                tgt_chrome_profile = st.text_input("Chrome Profil", value="Profile 2", key="tgt_chrome")
                tgt_login_type = st.selectbox("Login Tipi", ["email", "google"], key="tgt_login_type")

            st.markdown("**Giris Bilgileri:**")
            col3, col4 = st.columns(2)
            with col3:
                tgt_email = st.text_input("E-Mail", placeholder="store2@email.com", key="tgt_email")
            with col4:
                tgt_password = st.text_input("Sifre", type="password", placeholder="******", key="tgt_password")

            st.markdown("**Yukleme Ayarlari:**")
            col5, col6 = st.columns(2)
            with col5:
                tgt_daily_limit = st.number_input("Gunluk Limit", value=15, key="tgt_limit")
            with col6:
                tgt_upload_hours = st.slider("Yukleme Saatleri", 0, 23, (16, 17), key="tgt_hours")

            if st.form_submit_button("Hedef Magaza Ekle", type="primary"):
                if tgt_store_name:
                    db.add_store({
                        'store_name': tgt_store_name,
                        'profile_url': tgt_profile_url,
                        'chrome_profile': tgt_chrome_profile,
                        'is_source': False,
                        'is_active': True,
                        'daily_limit': tgt_daily_limit,
                        'upload_start_hour': tgt_upload_hours[0],
                        'upload_end_hour': tgt_upload_hours[1],
                        'login_email': tgt_email,
                        'login_password': tgt_password,
                        'login_type': tgt_login_type,
                        'login_status': 'unknown'
                    })
                    st.success(f"Hedef magaza '{tgt_store_name}' eklendi!")
                    st.rerun()
                else:
                    st.error("Magaza adi gerekli!")

    # ========== CHROME PROFILE INFO ==========
    st.markdown("---")
    st.subheader("Chrome Profil Bilgisi")

    with st.expander("Chrome Profil Nasil Olusturulur?"):
        st.markdown("""
        **Chrome Profil Konumu:**
        ```
        C:\\Users\\cyhnsrgc\\AppData\\Local\\Google\\Chrome\\User Data\\
        - Default/           -> Ana hesap
        - Profile 2/         -> Ikinci hesap
        - Profile 3/         -> Ucuncu hesap
        ```

        **Yeni Profil Olusturma:**
        1. Chrome'u acin
        2. Sag ustteki profil ikonuna tiklayin
        3. "Ekle" -> Yeni profil olusturun
        4. Vinted'a manuel giris yapin (ilk seferlik)
        5. Dashboard'da profil adini girin (orn: "Profile 2")

        **Login Tipleri:**
        - **email**: E-Mail + Sifre ile giris (cssberlin@hotmail.com)
        - **google**: Google hesabi ile giris (Chrome'da Google oturumu acik olmali)
        """)


def show_products():
    """Products management page"""
    st.title("Urun Yonetimi")

    # Filters
    col1, col2 = st.columns(2)
    with col1:
        status_filter = st.selectbox(
            "Durum Filtresi",
            ["Tumu", "Ham", "Resim OK", "SEO OK", "Dogrulanmis", "Yuklendi"],
            key="product_filter"
        )
    with col2:
        limit = st.number_input("Gosterilecek Urun", min_value=10, max_value=100, value=20)

    # Map filter to status code
    status_map = {
        "Tumu": None,
        "Ham": 0,
        "Resim OK": 1,
        "SEO OK": 2,
        "Dogrulanmis": 3,
        "Yuklendi": 5
    }

    status_code = status_map.get(status_filter)

    if status_code is not None:
        products = db.get_products_by_status(status_code)
    else:
        products = db.get_all_products()

    st.markdown(f"**{len(products)} urun bulundu**")

    if products:
        for product in products[:limit]:
            with st.expander(f"{product.get('raw_title', 'N/A')[:50]} - {get_status_label(product.get('status', 0))}"):
                col1, col2 = st.columns([2, 1])

                with col1:
                    st.write(f"**ID:** {product.get('id')}")
                    st.write(f"**Marka:** {product.get('brand', 'N/A')}")
                    st.write(f"**Fiyat:** {product.get('price', 0):.2f} EUR")

                    if product.get('processed_title'):
                        st.write(f"**SEO Baslik:** {product.get('processed_title')}")

                with col2:
                    st.write(f"**Durum:** {get_status_label(product.get('status', 0))}")
                    approved = "Evet" if product.get('telegram_approved') else "Hayir"
                    st.write(f"**Onay:** {approved}")

                    # Action buttons
                    if product.get('status') == STATUS_VALIDATED and not product.get('telegram_approved'):
                        col_a, col_b = st.columns(2)
                        with col_a:
                            if st.button("Onayla", key=f"approve_{product['id']}"):
                                db.update_product(product['id'], {'telegram_approved': 1})
                                add_log(f"Urun onaylandi: {product['id']}")
                                st.rerun()
                        with col_b:
                            if st.button("Atla", key=f"skip_{product['id']}"):
                                db.update_product(product['id'], {'telegram_approved': 0, 'status': -1})
                                add_log(f"Urun atlandi: {product['id']}")
                                st.rerun()

                    # Show first image if available
                    final_path = product.get('final_images_path', '')
                    if final_path and os.path.exists(final_path):
                        images = [f for f in os.listdir(final_path) if f.endswith(('.jpg', '.png'))]
                        if images:
                            st.image(os.path.join(final_path, images[0]), width=150)
    else:
        st.info("Bu kriterlere uyan urun bulunamadi.")


def show_logs():
    """Logs page"""
    st.title("Islem Loglari")

    # Auto-refresh option
    auto_refresh = st.checkbox("Otomatik Yenile (her 3 saniye)", value=False)

    col1, col2 = st.columns(2)
    with col1:
        if st.button("Loglari Yenile"):
            st.rerun()
    with col2:
        if st.button("Loglari Temizle"):
            st.session_state.logs = []
            clear_log_file()
            st.rerun()

    st.markdown("---")

    # File-based logs (thread-safe)
    st.subheader("Islem Loglari (Dosyadan)")

    file_logs = read_logs_from_file(limit=50)
    if file_logs:
        log_text = "".join(reversed(file_logs))
        st.code(log_text, language=None)
    else:
        st.info("Henuz log yok - Login Test veya Scrape baslatın")

    st.markdown("---")

    # Database logs
    st.subheader("Veritabani Loglari")

    logs = db.get_logs(limit=50)

    if logs:
        for log in logs:
            status_icon = "[OK]" if log.get('status') == 'success' else "[X]"
            timestamp = log.get('created_at', '')[:19]
            st.text(f"{timestamp} | {status_icon} {log.get('action', 'N/A')} | {log.get('message', '')[:50]}")
    else:
        st.info("Henuz veritabani logu yok")

    # Auto-refresh
    if auto_refresh:
        time.sleep(3)
        st.rerun()


if __name__ == "__main__":
    main()
