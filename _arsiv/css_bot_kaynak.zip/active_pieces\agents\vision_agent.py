#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Vision Agent
AI-powered image analysis for screenshot-based scraping

Features:
- Product URL detection from screenshots
- Product data extraction from images
- Product availability checking
- Multi-language support
- GPT-4V / Claude Vision integration

Author: TATANGA Team
Version: 1.0
"""

import sys
import asyncio
import base64
import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path
import re

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")


class VisionAgent:
    """
    Vision Agent - AI-powered image analysis

    Uses GPT-4V or Claude Vision to extract data from screenshots
    when traditional scraping methods fail.

    Capabilities:
    1. Detect product URLs from search result pages
    2. Extract product details from product pages
    3. Check product availability status
    4. Detect "sold" indicators in multiple languages
    """

    # Language-specific sold indicators
    SOLD_INDICATORS = {
        'de': ['verkauft', 'ausverkauft', 'nicht mehr verfügbar', 'bereits verkauft', 'reserviert'],
        'en': ['sold', 'sold out', 'no longer available', 'item sold', 'reserved'],
        'fr': ['vendu', 'épuisé', 'plus disponible', 'article vendu', 'réservé'],
        'es': ['vendido', 'agotado', 'no disponible', 'artículo vendido', 'reservado'],
        'it': ['venduto', 'esaurito', 'non disponibile', 'articolo venduto', 'riservato'],
        'nl': ['verkocht', 'uitverkocht', 'niet meer beschikbaar', 'gereserveerd'],
        'pl': ['sprzedane', 'wyprzedane', 'niedostępne', 'zarezerwowane'],
        'sv': ['såld', 'slutsåld', 'ej tillgänglig', 'reserverad'],
        'da': ['solgt', 'udsolgt', 'ikke tilgængelig', 'reserveret'],
        'no': ['solgt', 'utsolgt', 'ikke tilgjengelig', 'reservert'],
        'cs': ['prodáno', 'vyprodáno', 'nedostupné', 'rezervováno'],
        'fi': ['myyty', 'loppuunmyyty', 'ei saatavilla', 'varattu'],
    }

    # Platform-specific URL patterns
    URL_PATTERNS = {
        'vinted': r'vinted\.[a-z.]+/items?/(\d+)',
        'ebay': r'ebay\.[a-z.]+/itm/(\d+)',
        'kleinanzeigen': r'kleinanzeigen\.de/s-anzeige/[^/]+/(\d+)',
        'willhaben': r'willhaben\.at/iad/[^/]+/d/[^/]+-(\d+)',
        'leboncoin': r'leboncoin\.fr/ad/[^/]+/(\d+)',
        'shpock': r'shpock\.com/[^/]+/([a-zA-Z0-9-]+)',
    }

    def __init__(self, api_key: str = None, model: str = 'gpt-4-vision-preview'):
        """
        Initialize Vision Agent

        Args:
            api_key: OpenAI or Anthropic API key
            model: Vision model to use
        """
        self.api_key = api_key or os.getenv('OPENAI_API_KEY') or os.getenv('ANTHROPIC_API_KEY')
        self.model = model
        self.logger = ModuleLogger("vision_agent")

        # Determine which API to use
        if 'claude' in model.lower():
            self.api_type = 'anthropic'
        else:
            self.api_type = 'openai'

        # Statistics
        self.stats = {
            'images_processed': 0,
            'urls_detected': 0,
            'products_extracted': 0
        }

        self.logger.info(f"Vision Agent initialized with {self.api_type} API")

    async def detect_product_urls(self, screenshot: bytes, platform: str = None) -> List[str]:
        """
        Detect product URLs from a search results screenshot

        Args:
            screenshot: Screenshot image bytes
            platform: Platform hint for URL pattern

        Returns:
            List of detected product URLs
        """
        self.logger.info(f"Detecting product URLs from screenshot")

        prompt = f"""
Analyze this screenshot of a product search results page.

Task: Identify and extract ALL visible product URLs/links.

Instructions:
1. Look for product cards/tiles in the search results
2. For each visible product, identify its URL
3. URLs may be visible in the browser bar, or you can construct them from product IDs

Platform: {platform if platform else 'Unknown'}

Return a JSON array of URLs:
{{
    "urls": [
        "https://...",
        "https://..."
    ],
    "count": <number of products found>,
    "confidence": <0.0-1.0>
}}

If you cannot see any product URLs, return an empty array.
Only return valid JSON, no other text.
"""

        try:
            response = await self._call_vision_api(screenshot, prompt)
            data = self._parse_json_response(response)

            urls = data.get('urls', [])

            # Validate URLs against platform patterns
            if platform:
                pattern = self.URL_PATTERNS.get(platform.split('_')[0])
                if pattern:
                    urls = [url for url in urls if re.search(pattern, url)]

            self.stats['images_processed'] += 1
            self.stats['urls_detected'] += len(urls)

            self.logger.info(f"Detected {len(urls)} product URLs")

            return urls

        except Exception as e:
            self.logger.error("Failed to detect URLs", exception=str(e))
            return []

    async def extract_product_data(self, screenshot: bytes, language: str = 'en') -> Optional[Dict]:
        """
        Extract product details from a product page screenshot

        Args:
            screenshot: Screenshot image bytes
            language: Expected language of the page

        Returns:
            Extracted product data
        """
        self.logger.info(f"Extracting product data (language: {language})")

        lang_code = language.split('-')[0] if '-' in language else language
        sold_keywords = self.SOLD_INDICATORS.get(lang_code, self.SOLD_INDICATORS['en'])

        prompt = f"""
Analyze this screenshot of a product detail page.

Page language: {language}

Extract the following information:

1. **title**: Product title/name
2. **price**: Price (numbers only, no currency symbol)
3. **currency**: Currency (EUR, GBP, USD, etc.)
4. **description**: Product description (first 500 chars)
5. **condition**: Product condition (New, Used, Good, etc.) - in original language
6. **seller_name**: Seller's name/username
7. **location**: Location/city
8. **category**: Product category
9. **brand**: Brand name (if visible)
10. **size**: Size (if clothing/shoes)
11. **color**: Color (if visible)
12. **is_sold**: Is the product marked as SOLD? Look for: {', '.join(sold_keywords)}
13. **buy_button_exists**: Is there a visible "Buy" or "Add to cart" button?
14. **images_count**: Number of product images visible

Return as JSON:
{{
    "title": "...",
    "price": 29.99,
    "currency": "EUR",
    "description": "...",
    "condition": "...",
    "seller_name": "...",
    "location": "...",
    "category": "...",
    "brand": "...",
    "size": "...",
    "color": "...",
    "is_sold": false,
    "buy_button_exists": true,
    "images_count": 5,
    "confidence": 0.95
}}

Only return valid JSON, no other text.
"""

        try:
            response = await self._call_vision_api(screenshot, prompt)
            data = self._parse_json_response(response)

            self.stats['images_processed'] += 1
            self.stats['products_extracted'] += 1

            self.logger.info(f"Extracted product: {data.get('title', 'Unknown')[:50]}")

            return data

        except Exception as e:
            self.logger.error("Failed to extract product data", exception=str(e))
            return None

    async def check_product_availability(self, screenshot: bytes, language: str = 'en') -> Dict:
        """
        Check if a product is still available for purchase

        Args:
            screenshot: Screenshot image bytes
            language: Page language

        Returns:
            Availability status
        """
        self.logger.info(f"Checking product availability")

        lang_code = language.split('-')[0] if '-' in language else language
        sold_keywords = self.SOLD_INDICATORS.get(lang_code, self.SOLD_INDICATORS['en'])

        prompt = f"""
Analyze this product page screenshot and determine if the product is still available.

Page language: {language}

Check for these sold/unavailable indicators: {', '.join(sold_keywords)}

Determine:
1. Is the product available for purchase?
2. Is it marked as "SOLD"?
3. Has the seller withdrawn/removed the listing?
4. Has the listing expired?
5. Is there any warning/error message?

Return JSON:
{{
    "is_available": true/false,
    "is_sold": true/false,
    "seller_withdrawn": true/false,
    "listing_expired": true/false,
    "warning_message": "..." or null,
    "buy_button_visible": true/false,
    "buy_button_enabled": true/false,
    "confidence": 0.0-1.0,
    "reason": "explanation of the decision"
}}

Only return valid JSON.
"""

        try:
            response = await self._call_vision_api(screenshot, prompt)
            data = self._parse_json_response(response)

            self.stats['images_processed'] += 1

            return data

        except Exception as e:
            self.logger.error("Failed to check availability", exception=str(e))
            return {
                'is_available': True,  # Assume available on error
                'is_sold': False,
                'confidence': 0.0,
                'error': str(e)
            }

    async def find_selector(self, screenshot: bytes, element_type: str, description: str) -> Optional[str]:
        """
        Find a CSS selector for an element in the screenshot

        Used by self-healing system when selectors break.

        Args:
            screenshot: Screenshot image bytes
            element_type: Type of element (button, input, link, etc.)
            description: Description of the element

        Returns:
            Suggested CSS selector
        """
        prompt = f"""
Analyze this webpage screenshot and help me find a CSS selector.

I'm looking for: {element_type}
Description: {description}

Based on typical web structures and the visible UI, suggest the most likely CSS selectors.

Return JSON:
{{
    "selectors": [
        "selector1",
        "selector2",
        "selector3"
    ],
    "element_found": true/false,
    "element_position": {{
        "approximate_x": "left/center/right",
        "approximate_y": "top/middle/bottom"
    }},
    "confidence": 0.0-1.0
}}

Suggest multiple selectors from most specific to most general.
Consider: data-testid, class names, IDs, element types, attributes.
"""

        try:
            response = await self._call_vision_api(screenshot, prompt)
            data = self._parse_json_response(response)

            selectors = data.get('selectors', [])
            if selectors:
                return selectors[0]

            return None

        except Exception as e:
            self.logger.error("Failed to find selector", exception=str(e))
            return None

    async def _call_vision_api(self, image: bytes, prompt: str) -> str:
        """
        Call the Vision API (OpenAI or Anthropic)

        Args:
            image: Image bytes
            prompt: Text prompt

        Returns:
            API response text
        """
        if not self.api_key:
            raise ValueError("API key not configured")

        # Encode image to base64
        image_b64 = base64.b64encode(image).decode('utf-8')

        if self.api_type == 'openai':
            return await self._call_openai_vision(image_b64, prompt)
        else:
            return await self._call_anthropic_vision(image_b64, prompt)

    async def _call_openai_vision(self, image_b64: str, prompt: str) -> str:
        """Call OpenAI GPT-4V API"""
        import aiohttp

        url = "https://api.openai.com/v1/chat/completions"

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{image_b64}",
                                "detail": "high"
                            }
                        }
                    ]
                }
            ],
            "max_tokens": 2000
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=payload) as resp:
                if resp.status != 200:
                    error = await resp.text()
                    raise Exception(f"OpenAI API error: {error}")

                data = await resp.json()
                return data['choices'][0]['message']['content']

    async def _call_anthropic_vision(self, image_b64: str, prompt: str) -> str:
        """Call Anthropic Claude Vision API"""
        import aiohttp

        url = "https://api.anthropic.com/v1/messages"

        headers = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01"
        }

        payload = {
            "model": self.model,
            "max_tokens": 2000,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": image_b64
                            }
                        },
                        {
                            "type": "text",
                            "text": prompt
                        }
                    ]
                }
            ]
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=payload) as resp:
                if resp.status != 200:
                    error = await resp.text()
                    raise Exception(f"Anthropic API error: {error}")

                data = await resp.json()
                return data['content'][0]['text']

    def _parse_json_response(self, response: str) -> Dict:
        """Parse JSON from API response"""
        # Try to extract JSON from the response
        try:
            # First, try direct JSON parse
            return json.loads(response)
        except:
            pass

        # Try to find JSON in the response
        json_match = re.search(r'\{[\s\S]*\}', response)
        if json_match:
            try:
                return json.loads(json_match.group())
            except:
                pass

        # Return empty dict if parsing fails
        self.logger.warning("Failed to parse JSON from response")
        return {}

    def get_stats(self) -> Dict:
        """Get Vision Agent statistics"""
        return self.stats


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("VISION AGENT TEST")
    print("=" * 60)

    async def test():
        agent = VisionAgent()

        print(f"\nAPI Type: {agent.api_type}")
        print(f"Model: {agent.model}")
        print(f"API Key configured: {bool(agent.api_key)}")

        print(f"\nSold indicators (German): {agent.SOLD_INDICATORS['de']}")
        print(f"Sold indicators (French): {agent.SOLD_INDICATORS['fr']}")

        print(f"\nURL patterns:")
        for platform, pattern in agent.URL_PATTERNS.items():
            print(f"  {platform}: {pattern}")

        print(f"\nStats: {agent.get_stats()}")
        print("\n✅ Vision Agent test complete!")

    asyncio.run(test())
    print("=" * 60)
