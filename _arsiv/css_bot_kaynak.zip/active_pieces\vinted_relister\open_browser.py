# Simple browser opener for manual login - no input needed
import os
import sys
import time
sys.stdout.reconfigure(encoding='utf-8')
from playwright.sync_api import sync_playwright

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def open_browser():
    """Open browser and keep it open for 5 minutes"""
    print("=" * 60)
    print("VINTED BROWSER - Manual Login")
    print("=" * 60)
    print("\nOpening browser...")
    print("Browser will stay open for 5 minutes.\n")

    profile_dir = os.path.join(BASE_DIR, 'playwright_profiles', 'cssberlin')
    os.makedirs(profile_dir, exist_ok=True)

    with sync_playwright() as pw:
        # Simple browser without proxy
        browser = pw.chromium.launch_persistent_context(
            user_data_dir=profile_dir,
            headless=False,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--no-sandbox',
                '--start-maximized'
            ],
            viewport=None,
            locale='de-DE',
            timezone_id='Europe/Berlin',
            slow_mo=50
        )

        page = browser.pages[0] if browser.pages else browser.new_page()

        print("[1] Opening Vinted.de...")
        page.goto('https://www.vinted.de/', wait_until='domcontentloaded', timeout=60000)

        print("\n" + "=" * 60)
        print("BROWSER READY!")
        print("=" * 60)
        print("""
TODO:
1. Click 'Einloggen' button (top right)
2. Select 'Mit E-Mail-Adresse weitermachen'
3. Login with cssberlin account
4. After login, go to /items/new to upload

Browser stays open for 5 minutes...
        """)

        # Keep browser open for 5 minutes
        for i in range(60):  # 60 * 5 = 300 seconds = 5 minutes
            time.sleep(5)

            # Check if on upload page
            if '/items/new' in page.url:
                print(f"\n[{i*5}s] On upload page! Recording form...")

                # Record form elements
                elements = []
                inputs = page.query_selector_all('input, textarea, button[data-testid], select')
                for el in inputs:
                    try:
                        tag = el.evaluate('e => e.tagName')
                        testid = el.get_attribute('data-testid') or ''
                        name = el.get_attribute('name') or ''
                        placeholder = el.get_attribute('placeholder') or ''
                        el_type = el.get_attribute('type') or ''

                        if testid or name:
                            elements.append({
                                'tag': tag, 'type': el_type,
                                'name': name, 'data-testid': testid,
                                'placeholder': placeholder[:50] if placeholder else ''
                            })
                    except:
                        pass

                print(f"Found {len(elements)} form elements")
                for j, el in enumerate(elements[:20]):
                    print(f"  {j+1}. {el['tag']} | testid={el['data-testid']} | name={el['name']}")

                # Save
                import json
                with open(os.path.join(BASE_DIR, 'form_elements.json'), 'w', encoding='utf-8') as f:
                    json.dump(elements, f, indent=2, ensure_ascii=False)
                print("Saved to form_elements.json")

                # Take screenshot
                try:
                    ss_path = os.path.join(BASE_DIR, 'data', 'upload_form.png')
                    os.makedirs(os.path.dirname(ss_path), exist_ok=True)
                    page.screenshot(path=ss_path)
                    print(f"Screenshot: {ss_path}")
                except Exception as e:
                    print(f"Screenshot failed: {e}")
            else:
                print(f"[{i*5}s] Waiting... URL: {page.url[:50]}")

        print("\n[DONE] 5 minutes passed. Closing browser.")
        browser.close()

if __name__ == '__main__':
    open_browser()
