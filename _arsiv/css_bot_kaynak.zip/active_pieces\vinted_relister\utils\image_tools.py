# Image processing utilities for Vinted Relister
import os
import sys
import random
import subprocess
from typing import List, Tuple, Optional
from pathlib import Path
import io

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (
    NCONVERT_PATH, IMAGE_ROTATION_RANGE, IMAGE_ROTATION_RANGE_MULTI,
    IMAGE_CONTRAST_RANGE, IMAGE_CONTRAST_RANGE_MULTI, IMAGE_QUALITY,
    PROCESSED_DIR, FINAL_DIR
)

try:
    from PIL import Image, ImageFilter, ImageEnhance
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("Warning: Pillow not installed. Run: pip install pillow")

try:
    from rembg import remove
    REMBG_AVAILABLE = True
except ImportError:
    REMBG_AVAILABLE = False
    print("Warning: rembg not installed. Run: pip install rembg")


class ImageProcessor:
    """Process images for Vinted duplicate prevention"""

    def __init__(self, multi_store: bool = False):
        """
        Initialize image processor

        Args:
            multi_store: If True, apply stronger variations for different store uploads
        """
        self.multi_store = multi_store
        self.rotation_range = IMAGE_ROTATION_RANGE_MULTI if multi_store else IMAGE_ROTATION_RANGE
        self.contrast_range = IMAGE_CONTRAST_RANGE_MULTI if multi_store else IMAGE_CONTRAST_RANGE

    def remove_background(self, input_path: str, output_path: str) -> bool:
        """
        Remove background from image using rembg (AI-based)

        Args:
            input_path: Path to input image
            output_path: Path to save processed image (PNG with transparency)

        Returns:
            True if successful
        """
        if not REMBG_AVAILABLE:
            raise ImportError("rembg is not installed")

        try:
            with open(input_path, 'rb') as f:
                input_data = f.read()

            # Remove background with alpha matting for better edge quality
            output_data = remove(
                input_data,
                alpha_matting=True,
                alpha_matting_foreground_threshold=240,
                alpha_matting_background_threshold=10,
                alpha_matting_erode_size=10
            )

            # Ensure output directory exists
            os.makedirs(os.path.dirname(output_path), exist_ok=True)

            with open(output_path, 'wb') as f:
                f.write(output_data)

            return True

        except Exception as e:
            print(f"Error removing background: {e}")
            return False

    def add_white_background(self, input_path: str, output_path: str, add_shadow: bool = True) -> bool:
        """
        Add white background to transparent PNG and optionally add drop shadow

        Args:
            input_path: Path to transparent PNG
            output_path: Path to save final image
            add_shadow: Whether to add subtle drop shadow

        Returns:
            True if successful
        """
        if not PIL_AVAILABLE:
            raise ImportError("Pillow is not installed")

        try:
            # Open transparent image
            img = Image.open(input_path).convert('RGBA')

            # Create white background
            background = Image.new('RGBA', img.size, (255, 255, 255, 255))

            if add_shadow:
                # Create shadow layer
                shadow = Image.new('RGBA', img.size, (0, 0, 0, 0))

                # Get alpha channel and blur it for shadow
                alpha = img.split()[3]
                shadow_alpha = alpha.filter(ImageFilter.GaussianBlur(radius=8))

                # Create shadow with offset
                shadow_layer = Image.new('RGBA', img.size, (0, 0, 0, 30))
                shadow_layer.putalpha(shadow_alpha)

                # Offset shadow slightly
                offset = (5, 5)
                shadow_offset = Image.new('RGBA', img.size, (255, 255, 255, 255))
                shadow_offset.paste(shadow_layer, offset, shadow_layer)

                # Composite: background + shadow + image
                background = Image.alpha_composite(background, shadow_offset)

            # Composite final image
            result = Image.alpha_composite(background, img)

            # Convert to RGB and save as JPEG
            result = result.convert('RGB')

            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            result.save(output_path, 'JPEG', quality=IMAGE_QUALITY)

            return True

        except Exception as e:
            print(f"Error adding white background: {e}")
            return False

    def apply_duplicate_prevention(self, input_path: str, output_path: str) -> bool:
        """
        Apply transformations to prevent duplicate detection

        Transformations:
        - Random rotation (1-2 degrees or 3-5 for multi-store)
        - Contrast adjustment (2-5% or 5-10% for multi-store)
        - EXIF metadata removal
        - Slight quality re-encoding

        Args:
            input_path: Path to input image
            output_path: Path to save processed image

        Returns:
            True if successful
        """
        if not PIL_AVAILABLE:
            raise ImportError("Pillow is not installed")

        try:
            img = Image.open(input_path)

            # Random rotation
            rotation = random.uniform(*self.rotation_range)
            if random.choice([True, False]):
                rotation = -rotation
            img = img.rotate(rotation, expand=True, fillcolor=(255, 255, 255))

            # Contrast adjustment
            contrast_factor = 1 + random.uniform(*self.contrast_range) / 100
            enhancer = ImageEnhance.Contrast(img)
            img = enhancer.enhance(contrast_factor)

            # Slight brightness adjustment
            brightness_factor = 1 + random.uniform(-2, 2) / 100
            enhancer = ImageEnhance.Brightness(img)
            img = enhancer.enhance(brightness_factor)

            # Convert to RGB if necessary
            if img.mode in ('RGBA', 'P'):
                background = Image.new('RGB', img.size, (255, 255, 255))
                if img.mode == 'RGBA':
                    background.paste(img, mask=img.split()[3])
                else:
                    background.paste(img)
                img = background

            # Save with quality re-encoding (removes EXIF automatically)
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            img.save(output_path, 'JPEG', quality=IMAGE_QUALITY, optimize=True)

            return True

        except Exception as e:
            print(f"Error applying duplicate prevention: {e}")
            return False

    def process_with_nconvert(self, input_path: str, output_path: str) -> bool:
        """
        Use NConvert CLI for image processing (alternative to Pillow)

        Args:
            input_path: Path to input image
            output_path: Path to save processed image

        Returns:
            True if successful
        """
        if not os.path.exists(NCONVERT_PATH):
            print(f"NConvert not found at: {NCONVERT_PATH}")
            return False

        try:
            rotation = random.uniform(*self.rotation_range)
            contrast = random.randint(*self.contrast_range)

            cmd = [
                NCONVERT_PATH,
                '-clearmeta',  # Remove EXIF
                '-rotate', str(rotation),
                '-contrast', str(contrast),
                '-q', str(IMAGE_QUALITY),
                '-out', 'jpeg',
                '-o', output_path,
                input_path
            ]

            result = subprocess.run(cmd, capture_output=True, text=True)

            if result.returncode != 0:
                print(f"NConvert error: {result.stderr}")
                return False

            return True

        except Exception as e:
            print(f"Error running NConvert: {e}")
            return False

    def center_and_resize(self, input_path: str, output_path: str,
                          target_size: Tuple[int, int] = (1200, 1200)) -> bool:
        """
        Center image on canvas and resize

        Args:
            input_path: Path to input image
            output_path: Path to save processed image
            target_size: Target dimensions (width, height)

        Returns:
            True if successful
        """
        if not PIL_AVAILABLE:
            raise ImportError("Pillow is not installed")

        try:
            img = Image.open(input_path)

            # Calculate aspect ratio
            img_ratio = img.width / img.height
            target_ratio = target_size[0] / target_size[1]

            if img_ratio > target_ratio:
                # Image is wider - fit to width
                new_width = int(target_size[0] * 0.9)  # 90% of target width
                new_height = int(new_width / img_ratio)
            else:
                # Image is taller - fit to height
                new_height = int(target_size[1] * 0.9)  # 90% of target height
                new_width = int(new_height * img_ratio)

            # Resize image
            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)

            # Create white canvas
            canvas = Image.new('RGB', target_size, (255, 255, 255))

            # Center image on canvas
            x = (target_size[0] - new_width) // 2
            y = (target_size[1] - new_height) // 2

            # Handle transparency
            if img.mode == 'RGBA':
                canvas.paste(img, (x, y), img.split()[3])
            else:
                canvas.paste(img, (x, y))

            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            canvas.save(output_path, 'JPEG', quality=IMAGE_QUALITY)

            return True

        except Exception as e:
            print(f"Error centering image: {e}")
            return False

    def process_product_images(self, product_id: str, raw_images: List[str],
                               output_dir: str, remove_bg: bool = True) -> List[str]:
        """
        Process all images for a product

        Args:
            product_id: Product identifier for folder naming
            raw_images: List of raw image paths
            output_dir: Base output directory
            remove_bg: Whether to remove background

        Returns:
            List of processed image paths
        """
        processed_paths = []
        product_dir = os.path.join(output_dir, str(product_id))
        os.makedirs(product_dir, exist_ok=True)

        for i, raw_path in enumerate(raw_images):
            try:
                filename = f"{product_id}_{i+1:02d}.jpg"
                final_path = os.path.join(product_dir, filename)

                if remove_bg:
                    # Step 1: Remove background
                    temp_png = os.path.join(product_dir, f"temp_{i}.png")
                    if self.remove_background(raw_path, temp_png):
                        # Step 2: Add white background with shadow
                        temp_white = os.path.join(product_dir, f"temp_white_{i}.jpg")
                        if self.add_white_background(temp_png, temp_white):
                            # Step 3: Apply duplicate prevention
                            if self.apply_duplicate_prevention(temp_white, final_path):
                                processed_paths.append(final_path)

                            # Cleanup temp files
                            if os.path.exists(temp_white):
                                os.remove(temp_white)

                        # Cleanup temp PNG
                        if os.path.exists(temp_png):
                            os.remove(temp_png)
                else:
                    # Just apply duplicate prevention without bg removal
                    if self.apply_duplicate_prevention(raw_path, final_path):
                        processed_paths.append(final_path)

            except Exception as e:
                print(f"Error processing image {raw_path}: {e}")
                continue

        return processed_paths

    def generate_seo_filename(self, brand: str, model: str, color: str,
                              product_id: str, index: int) -> str:
        """
        Generate SEO-friendly filename

        Args:
            brand: Product brand
            model: Product model
            color: Product color
            product_id: Product ID
            index: Image index

        Returns:
            SEO-friendly filename
        """
        def clean(text: str) -> str:
            if not text:
                return ''
            # Remove special characters, convert to lowercase
            import re
            text = re.sub(r'[^a-zA-Z0-9\s-]', '', text)
            text = text.lower().strip()
            text = re.sub(r'\s+', '-', text)
            return text

        parts = [clean(brand), clean(model), clean(color), str(product_id)]
        parts = [p for p in parts if p]

        filename = '-'.join(parts)
        return f"{filename}_{index:02d}.jpg"


# Global processor instance
image_processor = ImageProcessor()
