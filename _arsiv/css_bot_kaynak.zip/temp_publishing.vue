<template>
  <div>
    <h1 class="text-3xl font-bold mb-6">Yayinlar</h1>

    <!-- Stats -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <div class="bg-white rounded-lg shadow p-4">
        <div class="text-gray-500 text-sm">Toplam</div>
        <div class="text-2xl font-bold">{{ stats.total_publications }}</div>
      </div>
      <div class="bg-white rounded-lg shadow p-4">
        <div class="text-gray-500 text-sm">Aktif</div>
        <div class="text-2xl font-bold text-green-600">{{ stats.active }}</div>
      </div>
      <div class="bg-white rounded-lg shadow p-4">
        <div class="text-gray-500 text-sm">Satildi</div>
        <div class="text-2xl font-bold text-purple-600">{{ stats.sold }}</div>
      </div>
      <div class="bg-white rounded-lg shadow p-4">
        <div class="text-gray-500 text-sm">Ciro</div>
        <div class="text-2xl font-bold text-blue-600">{{ formatPrice(stats.total_revenue) }}</div>
      </div>
    </div>

    <!-- Filter & Pagination Info -->
    <div class="flex gap-2 mb-4 flex-wrap items-center">
      <button @click="filter = ''" :class="filter === '' ? 'bg-blue-600 text-white' : 'bg-white'" class="px-4 py-2 rounded-lg shadow">Tumu</button>
      <button @click="filter = 'active'" :class="filter === 'active' ? 'bg-green-600 text-white' : 'bg-white'" class="px-4 py-2 rounded-lg shadow">Aktif</button>
      <button @click="filter = 'sold'" :class="filter === 'sold' ? 'bg-purple-600 text-white' : 'bg-white'" class="px-4 py-2 rounded-lg shadow">Satildi</button>
      <span class="ml-auto text-gray-500">Sayfa {{ currentPage }}/{{ totalPages }} ({{ totalCount }} yayin)</span>
    </div>

    <!-- Publications Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      <div v-for="pub in paginatedPublications" :key="pub.id" class="bg-white rounded-lg shadow overflow-hidden hover:shadow-lg transition-shadow">
        <div class="h-40 bg-gray-200 relative">
          <img v-if="pub.product_image" :src="pub.product_image" class="w-full h-full object-cover" />
          <div v-else class="w-full h-full flex items-center justify-center text-gray-400 text-4xl">P</div>
          <span class="absolute top-2 right-2 px-2 py-1 text-xs rounded-full font-bold" :class="getStatusClass(pub.status)">
            {{ getStatusText(pub.status) }}
          </span>
          <span class="absolute top-2 left-2 px-2 py-1 bg-gray-900 text-white text-xs rounded">{{ pub.platform }}</span>
        </div>
        <div class="p-4">
          <h3 class="font-bold text-sm mb-2 truncate" :title="pub.product_title">{{ pub.product_title || "Urun" }}</h3>
          <div class="text-xl font-bold text-green-600 mb-2">{{ formatPrice(pub.sale_price) }}</div>
          <div class="text-xs text-gray-500 mb-3">
            <div>ID: {{ pub.pub_id }}</div>
            <div>{{ formatDate(pub.published_at) }}</div>
          </div>
          <div class="flex gap-2 border-t pt-3">
            <a v-if="pub.listing_url" :href="pub.listing_url" target="_blank" class="flex-1 bg-blue-100 text-blue-700 text-center py-2 rounded text-sm hover:bg-blue-200">
              Listede Gor
            </a>
            <button v-if="pub.status === 'active'" @click="markAsSold(pub.id)" class="flex-1 bg-green-100 text-green-700 py-2 rounded text-sm hover:bg-green-200">
              Satildi
            </button>
            <button @click="showDetails(pub)" class="px-3 bg-gray-100 text-gray-700 py-2 rounded hover:bg-gray-200">i</button>
          </div>
        </div>
      </div>
      <div v-if="filteredPublications.length === 0" class="col-span-full text-center py-12 text-gray-500">Henuz yayin yok</div>
    </div>

    <!-- Pagination -->
    <div v-if="totalPages > 1" class="mt-6 flex justify-center items-center gap-2">
      <button @click="goToPage(1)" :disabled="currentPage === 1" class="px-3 py-2 rounded border hover:bg-gray-100 disabled:opacity-50">&lt;&lt;</button>
      <button @click="goToPage(currentPage - 1)" :disabled="currentPage === 1" class="px-3 py-2 rounded border hover:bg-gray-100 disabled:opacity-50">&lt;</button>
      <template v-for="page in visiblePages" :key="page">
        <button v-if="page !== '...'" @click="goToPage(page)" :class="page === currentPage ? 'bg-blue-600 text-white' : 'bg-white hover:bg-gray-100'" class="px-4 py-2 rounded border font-medium">{{ page }}</button>
        <span v-else class="px-2 text-gray-400">...</span>
      </template>
      <button @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages" class="px-3 py-2 rounded border hover:bg-gray-100 disabled:opacity-50">&gt;</button>
      <button @click="goToPage(totalPages)" :disabled="currentPage === totalPages" class="px-3 py-2 rounded border hover:bg-gray-100 disabled:opacity-50">&gt;&gt;</button>
      <select v-model="itemsPerPage" @change="goToPage(1)" class="ml-4 border rounded px-2 py-2">
        <option :value="25">25</option>
        <option :value="50">50</option>
        <option :value="100">100</option>
      </select>
    </div>

    <!-- Detail Modal -->
    <div v-if="selectedPub" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" @click.self="selectedPub = null">
      <div class="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-screen overflow-y-auto m-4">
        <div class="p-6">
          <div class="flex justify-between items-start mb-4">
            <h2 class="text-xl font-bold">Yayin Detaylari</h2>
            <button @click="selectedPub = null" class="text-gray-500 hover:text-gray-700 text-2xl">x</button>
          </div>
          <div class="grid grid-cols-2 gap-4 mb-4">
            <div><label class="text-sm text-gray-500">Pub ID</label><div class="font-mono">{{ selectedPub.pub_id }}</div></div>
            <div><label class="text-sm text-gray-500">Platform</label><div class="font-bold">{{ selectedPub.platform }}</div></div>
            <div><label class="text-sm text-gray-500">Durum</label><div><span class="px-2 py-1 text-xs rounded-full" :class="getStatusClass(selectedPub.status)">{{ getStatusText(selectedPub.status) }}</span></div></div>
            <div><label class="text-sm text-gray-500">Fiyat</label><div class="font-bold text-green-600">{{ formatPrice(selectedPub.sale_price) }}</div></div>
          </div>
          <div class="mb-4"><label class="text-sm text-gray-500">Urun</label><div class="font-medium">{{ selectedPub.product_title }}</div></div>
          <div v-if="selectedPub.listing_url" class="mb-4">
            <label class="text-sm text-gray-500">Liste URL</label>
            <a :href="selectedPub.listing_url" target="_blank" class="text-blue-600 hover:underline block truncate">{{ selectedPub.listing_url }}</a>
          </div>
          <div class="grid grid-cols-2 gap-4 text-sm">
            <div><label class="text-gray-500">Yayinlanma</label><div>{{ formatDate(selectedPub.published_at) }}</div></div>
            <div v-if="selectedPub.sold_at"><label class="text-gray-500">Satis</label><div>{{ formatDate(selectedPub.sold_at) }}</div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from "vue"
import api from "../api/client"

const publications = ref([])
const stats = ref({ total_publications: 0, active: 0, sold: 0, total_revenue: 0 })
const filter = ref("")
const selectedPub = ref(null)
const currentPage = ref(1)
const itemsPerPage = ref(50)

const filteredPublications = computed(() => {
  if (!filter.value) return publications.value
  return publications.value.filter(p => p.status === filter.value)
})

const totalCount = computed(() => filteredPublications.value.length)
const totalPages = computed(() => Math.ceil(totalCount.value / itemsPerPage.value) || 1)

const paginatedPublications = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage.value
  return filteredPublications.value.slice(start, start + itemsPerPage.value)
})

const visiblePages = computed(() => {
  const pages = []
  const total = totalPages.value
  const current = currentPage.value
  if (total <= 7) {
    for (let i = 1; i <= total; i++) pages.push(i)
  } else {
    pages.push(1)
    if (current > 3) pages.push("...")
    for (let i = Math.max(2, current - 1); i <= Math.min(total - 1, current + 1); i++) pages.push(i)
    if (current < total - 2) pages.push("...")
    pages.push(total)
  }
  return pages
})

watch(filter, () => { currentPage.value = 1 })

const goToPage = (page) => { if (page >= 1 && page <= totalPages.value) currentPage.value = page }

const formatPrice = (price) => {
  if (!price) return "-"
  return new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(price)
}

const formatDate = (date) => {
  if (!date) return "-"
  return new Date(date).toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" })
}

const getStatusClass = (status) => status === "active" ? "bg-green-100 text-green-800" : "bg-purple-100 text-purple-800"
const getStatusText = (status) => status === "active" ? "Aktif" : "Satildi"
const showDetails = (pub) => { selectedPub.value = pub }

const markAsSold = async (pubId) => {
  const price = prompt("Satis fiyati (EUR):")
  if (!price) return
  try {
    await api.post("/publishing/" + pubId + "/sold", null, { params: { sale_price: parseFloat(price) } })
    loadData()
  } catch (error) { alert("Hata: " + (error.response?.data?.detail || error.message)) }
}

const loadData = async () => {
  try {
    const [pubRes, statsRes] = await Promise.all([api.get("/publishing"), api.get("/publishing/stats")])
    publications.value = pubRes.data
    stats.value = statsRes.data
  } catch (error) { console.error(error) }
}

onMounted(loadData)
</script>
