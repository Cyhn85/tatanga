@echo off
cd /d "C:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python migrations\source_validator_daemon.py