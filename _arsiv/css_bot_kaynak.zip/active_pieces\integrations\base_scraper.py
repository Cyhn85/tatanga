#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA v3 - Base Scraper Class
================================
Tüm platform scraper'ları için temel sınıf.

Özellikler:
- Cookie/Popup handling
- Human-like scroll ve mouse hareketleri
- Pagination (scroll & button click)
- Anti-bot bypass teknikleri
- Rate limiting
- Session management

Author: TATANGA Team
Version: 3.0
"""

import sys
import time
import random
import hashlib
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Callable
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
import logging

# Windows encoding fix
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except:
        pass

# Selenium imports
try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.common.action_chains import ActionChains
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.options import Options as ChromeOptions
    from selenium.common.exceptions import (
        TimeoutException,
        NoSuchElementException,
        StaleElementReferenceException,
        ElementClickInterceptedException
    )
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False

# Undetected chromedriver
try:
    import undetected_chromedriver as uc
    UC_AVAILABLE = True
except ImportError:
    UC_AVAILABLE = False


# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class ScrapedProduct:
    """Scraped ürün verisi"""
    id: str
    url: str
    title: str
    price: float = 0.0
    currency: str = 'EUR'
    image: str = ''
    images: List[str] = field(default_factory=list)
    location: str = ''
    description: str = ''
    brand: str = ''
    category: str = ''
    condition: str = ''
    platform: str = ''
    country: str = ''
    seller_name: str = ''
    scraped_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'url': self.url,
            'title': self.title,
            'price': self.price,
            'currency': self.currency,
            'image': self.image,
            'images': self.images,
            'location': self.location,
            'description': self.description,
            'brand': self.brand,
            'category': self.category,
            'condition': self.condition,
            'platform': self.platform,
            'country': self.country,
            'seller_name': self.seller_name,
            'scraped_at': self.scraped_at
        }


@dataclass
class PaginationConfig:
    """Pagination yapılandırması"""
    type: str = 'scroll'  # 'scroll', 'button', 'url'
    max_pages: int = 5
    items_per_page: int = 50
    scroll_pause: float = 2.0
    next_button_selector: str = ''
    page_url_template: str = ''  # URL'de {page} placeholder
    load_more_selector: str = ''


@dataclass
class ScraperStats:
    """Scraper istatistikleri"""
    pages_scraped: int = 0
    items_found: int = 0
    items_extracted: int = 0
    captchas_detected: int = 0
    popups_closed: int = 0
    errors: int = 0
    retries: int = 0
    start_time: str = field(default_factory=lambda: datetime.now().isoformat())
    end_time: str = ''
    duration_seconds: float = 0.0


# ============================================================================
# USER AGENTS
# ============================================================================

USER_AGENTS = [
    # Windows Chrome
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    # Mac Chrome
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
    # Windows Firefox
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    # Mac Safari
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
    # Windows Edge
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
]


# ============================================================================
# BASE SCRAPER CLASS
# ============================================================================

class BaseScraper(ABC):
    """
    Tüm platform scraper'ları için temel sınıf

    Alt sınıflar şu metodları implement etmeli:
    - _get_platform_config() -> Dict
    - _extract_product_from_element(element) -> ScrapedProduct
    - _build_search_url(query, filters) -> str
    """

    def __init__(
        self,
        platform_key: str,
        platform_name: str,
        country: str = 'de',
        headless: bool = False,
        use_undetected: bool = True,
        proxy: Optional[str] = None,
        rate_limit_delay: float = 2.0,
        max_retries: int = 3
    ):
        """
        Args:
            platform_key: Platform tanımlayıcı (ör: 'willhaben', 'ebay')
            platform_name: Platform görünen adı (ör: 'Willhaben', 'eBay')
            country: Ülke kodu (ör: 'de', 'at')
            headless: Headless mod (görünmez tarayıcı)
            use_undetected: undetected-chromedriver kullan
            proxy: Proxy adresi (ör: 'host:port')
            rate_limit_delay: İstekler arası bekleme (saniye)
            max_retries: Maksimum deneme sayısı
        """
        self.platform_key = platform_key
        self.platform_name = platform_name
        self.country = country
        self.headless = headless
        self.use_undetected = use_undetected and UC_AVAILABLE
        self.proxy = proxy
        self.rate_limit_delay = rate_limit_delay
        self.max_retries = max_retries

        self.driver: Optional[webdriver.Chrome] = None
        self.stats = ScraperStats()

        # Logger
        self.logger = logging.getLogger(f'TATANGA.{platform_key}')
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter(
                f'[{platform_key.upper()}] %(message)s'
            ))
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)

        self.logger.info(f"Initialized - Headless: {headless}, Undetected: {self.use_undetected}")

    # ========================================================================
    # ABSTRACT METHODS - Alt sınıflar implement etmeli
    # ========================================================================

    @abstractmethod
    def _get_platform_config(self) -> Dict:
        """
        Platform-specific yapılandırma döndür

        Returns:
            {
                'base_url': str,
                'search_url_template': str,
                'language': str,
                'currency': str,
                'cookie_selectors': List[str],
                'captcha_indicators': List[str],
                'item_selectors': List[str],
                'title_selectors': List[str],
                'price_selectors': List[str],
                'image_selectors': List[str],
                'location_selectors': List[str],
                'pagination': PaginationConfig
            }
        """
        pass

    @abstractmethod
    def _extract_product_from_element(self, element) -> Optional[ScrapedProduct]:
        """
        Tek bir element'ten ürün verisi çıkar

        Args:
            element: Selenium WebElement

        Returns:
            ScrapedProduct veya None
        """
        pass

    @abstractmethod
    def _build_search_url(self, query: str, filters: Optional[Dict] = None) -> str:
        """
        Arama URL'i oluştur

        Args:
            query: Arama sorgusu
            filters: Filtreler (price_min, price_max, category, etc.)

        Returns:
            Tam arama URL'i
        """
        pass

    # ========================================================================
    # DRIVER MANAGEMENT
    # ========================================================================

    def _init_driver(self):
        """Tarayıcıyı başlat"""
        if self.driver is not None:
            return

        config = self._get_platform_config()
        user_agent = random.choice(USER_AGENTS)
        language = config.get('language', 'de-DE')

        if self.use_undetected:
            options = uc.ChromeOptions()

            if self.headless:
                options.add_argument('--headless=new')

            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument(f'--lang={language}')
            options.add_argument(f'--user-agent={user_agent}')
            options.add_argument('--window-size=1920,1080')
            options.add_argument('--disable-blink-features=AutomationControlled')

            if self.proxy:
                options.add_argument(f'--proxy-server={self.proxy}')

            self.driver = uc.Chrome(options=options)

        else:
            options = ChromeOptions()

            if self.headless:
                options.add_argument('--headless=new')

            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument(f'--lang={language}')
            options.add_argument(f'--user-agent={user_agent}')
            options.add_argument('--window-size=1920,1080')
            options.add_argument('--disable-blink-features=AutomationControlled')
            options.add_experimental_option('excludeSwitches', ['enable-automation'])
            options.add_experimental_option('useAutomationExtension', False)

            if self.proxy:
                options.add_argument(f'--proxy-server={self.proxy}')

            self.driver = webdriver.Chrome(options=options)

        self.driver.implicitly_wait(10)
        self.driver.set_page_load_timeout(30)

        # Stealth scripts
        self._inject_stealth_scripts()

        self.logger.info(f"Driver started - UA: {user_agent[:50]}...")

    def _inject_stealth_scripts(self):
        """Anti-detection scriptleri inject et"""
        try:
            self.driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
                'source': '''
                    Object.defineProperty(navigator, 'webdriver', {
                        get: () => undefined
                    });

                    window.chrome = { runtime: {} };

                    Object.defineProperty(navigator, 'plugins', {
                        get: () => [1, 2, 3, 4, 5]
                    });

                    Object.defineProperty(navigator, 'languages', {
                        get: () => ['de-DE', 'de', 'en-US', 'en']
                    });

                    const originalQuery = window.navigator.permissions.query;
                    window.navigator.permissions.query = (parameters) => (
                        parameters.name === 'notifications' ?
                            Promise.resolve({ state: Notification.permission }) :
                            originalQuery(parameters)
                    );
                '''
            })
        except Exception as e:
            self.logger.warning(f"Stealth script inject failed: {e}")

    def close(self):
        """Tarayıcıyı kapat"""
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            self.driver = None

        # Stats finalize
        self.stats.end_time = datetime.now().isoformat()
        if self.stats.start_time:
            try:
                start = datetime.fromisoformat(self.stats.start_time)
                end = datetime.fromisoformat(self.stats.end_time)
                self.stats.duration_seconds = (end - start).total_seconds()
            except:
                pass

        self.logger.info(f"Closed - Stats: {self.stats.items_extracted} items, {self.stats.pages_scraped} pages")

    def __del__(self):
        self.close()

    # ========================================================================
    # HUMAN-LIKE BEHAVIOR
    # ========================================================================

    def _random_delay(self, min_sec: float = None, max_sec: float = None):
        """Gaussian dağılımlı rastgele bekleme"""
        if min_sec is None:
            min_sec = self.rate_limit_delay * 0.5
        if max_sec is None:
            max_sec = self.rate_limit_delay * 1.5

        mean = (min_sec + max_sec) / 2
        std = (max_sec - min_sec) / 4
        delay = max(min_sec, min(max_sec, random.gauss(mean, std)))
        time.sleep(delay)
        return delay

    def _human_scroll(self, scroll_amount: int = None, pause: float = None):
        """İnsan benzeri scroll"""
        if not self.driver:
            return

        if scroll_amount is None:
            scroll_amount = random.randint(300, 700)

        if pause is None:
            pause = random.uniform(0.5, 1.5)

        # Smooth scroll
        self.driver.execute_script(f'''
            window.scrollBy({{
                top: {scroll_amount},
                behavior: 'smooth'
            }});
        ''')
        time.sleep(pause)

        # Bazen geri scroll
        if random.random() < 0.15:
            back_amount = random.randint(50, 150)
            self.driver.execute_script(f'window.scrollBy(0, -{back_amount})')
            time.sleep(random.uniform(0.2, 0.5))

    def _scroll_to_bottom(self, max_scrolls: int = 10, pause: float = 2.0):
        """
        Sayfanın sonuna kadar scroll (infinite scroll için)

        Args:
            max_scrolls: Maksimum scroll sayısı
            pause: Her scroll sonrası bekleme

        Returns:
            Yapılan scroll sayısı
        """
        if not self.driver:
            return 0

        last_height = self.driver.execute_script("return document.body.scrollHeight")
        scroll_count = 0

        for i in range(max_scrolls):
            # Scroll down
            self._human_scroll(scroll_amount=800)
            self._random_delay(pause * 0.8, pause * 1.2)

            # Yeni yüksekliği kontrol et
            new_height = self.driver.execute_script("return document.body.scrollHeight")
            scroll_count += 1

            if new_height == last_height:
                # Sayfa sonu - bir kez daha dene
                self._human_scroll(scroll_amount=500)
                self._random_delay(1, 2)

                new_height = self.driver.execute_script("return document.body.scrollHeight")
                if new_height == last_height:
                    self.logger.info(f"Reached page bottom after {scroll_count} scrolls")
                    break

            last_height = new_height

        return scroll_count

    def _human_mouse_move(self, element=None):
        """İnsan benzeri mouse hareketi"""
        if not self.driver:
            return

        try:
            actions = ActionChains(self.driver)

            if element:
                # Element'e hareket
                offset_x = random.randint(-5, 5)
                offset_y = random.randint(-5, 5)
                actions.move_to_element_with_offset(element, offset_x, offset_y)
            else:
                # Rastgele hareket
                for _ in range(random.randint(2, 4)):
                    x_offset = random.randint(-50, 50)
                    y_offset = random.randint(-50, 50)
                    actions.move_by_offset(x_offset, y_offset)
                    actions.pause(random.uniform(0.1, 0.3))

            actions.perform()
        except:
            pass

    def _human_type(self, element, text: str):
        """İnsan benzeri yazma"""
        element.clear()
        for char in text:
            element.send_keys(char)
            time.sleep(random.uniform(0.05, 0.15))

            # Bazen typo düzelt
            if random.random() < 0.02:
                element.send_keys(Keys.BACKSPACE)
                time.sleep(random.uniform(0.1, 0.3))
                element.send_keys(char)

    # ========================================================================
    # POPUP & COOKIE HANDLING
    # ========================================================================

    def _handle_popups(self) -> int:
        """
        Cookie consent ve diğer popup'ları kapat

        Returns:
            Kapatılan popup sayısı
        """
        if not self.driver:
            return 0

        config = self._get_platform_config()
        cookie_selectors = config.get('cookie_selectors', [])

        # Varsayılan selectors
        default_selectors = [
            'button#onetrust-accept-btn-handler',
            'button#didomi-notice-agree-button',
            'button[data-testid="cookie-accept"]',
            'button[data-testid="accept-cookies"]',
            '[data-role="accept"]',
            'button.accept-cookies',
            'button.cookie-consent-accept',
            '#gdpr-consent-banner-accept',
            '.cookie-banner button.accept',
            '[aria-label*="Accept"]',
            '[aria-label*="accept"]',
            'button:contains("Accept")',
            'button:contains("Akzeptieren")',
            'button:contains("Alle akzeptieren")',
        ]

        all_selectors = cookie_selectors + default_selectors
        closed_count = 0

        for selector in all_selectors:
            try:
                # contains() için XPath kullan
                if ':contains(' in selector:
                    text = selector.split(':contains("')[1].split('")')[0]
                    xpath = f'//button[contains(text(), "{text}")]'
                    btn = WebDriverWait(self.driver, 2).until(
                        EC.element_to_be_clickable((By.XPATH, xpath))
                    )
                else:
                    btn = WebDriverWait(self.driver, 2).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )

                self._human_mouse_move(btn)
                self._random_delay(0.3, 0.8)
                btn.click()

                closed_count += 1
                self.stats.popups_closed += 1
                self.logger.info(f"Popup closed: {selector[:50]}")
                self._random_delay(0.5, 1.0)

            except (TimeoutException, NoSuchElementException):
                continue
            except Exception as e:
                continue

        # Login/Register popup'larını da kapat
        dismiss_selectors = [
            'button[aria-label="Close"]',
            'button[aria-label="Schließen"]',
            '.modal-close',
            '.popup-close',
            '[data-testid="close-button"]',
            'button.close',
            '.overlay-close',
        ]

        for selector in dismiss_selectors:
            try:
                btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    btn.click()
                    closed_count += 1
                    self.stats.popups_closed += 1
                    self._random_delay(0.3, 0.8)
            except:
                continue

        return closed_count

    # ========================================================================
    # CAPTCHA DETECTION
    # ========================================================================

    def _check_captcha(self) -> bool:
        """CAPTCHA varlığını kontrol et"""
        if not self.driver:
            return False

        config = self._get_platform_config()
        indicators = config.get('captcha_indicators', [])

        # Varsayılan indicators
        default_indicators = [
            'captcha', 'recaptcha', 'hcaptcha',
            'robot', 'verify you are human',
            'are you a robot', 'datadome',
            'cf-challenge', 'challenge-running',
            'sicherheitskontroll', 'überprüfung'
        ]

        all_indicators = indicators + default_indicators

        try:
            page_source = self.driver.page_source.lower()

            for indicator in all_indicators:
                if indicator.lower() in page_source:
                    self.logger.warning(f"CAPTCHA detected: {indicator}")
                    self.stats.captchas_detected += 1
                    return True

            return False
        except:
            return False

    def _wait_for_captcha_solve(self, timeout: int = 60) -> bool:
        """Kullanıcının CAPTCHA çözmesini bekle"""
        if self.headless:
            self.logger.error("Cannot solve CAPTCHA in headless mode!")
            return False

        self.logger.info(f"Please solve CAPTCHA manually (waiting {timeout}s)...")

        start = time.time()
        while time.time() - start < timeout:
            time.sleep(2)
            if not self._check_captcha():
                self.logger.info("CAPTCHA solved!")
                return True

        self.logger.error("CAPTCHA timeout!")
        return False

    # ========================================================================
    # PAGINATION
    # ========================================================================

    def _paginate_scroll(self, max_items: int = 100) -> List:
        """
        Infinite scroll pagination

        Args:
            max_items: Maksimum ürün sayısı

        Returns:
            Bulunan element listesi
        """
        config = self._get_platform_config()
        item_selectors = config.get('item_selectors', [])
        pagination = config.get('pagination', PaginationConfig())

        all_items = []
        seen_urls = set()
        no_new_items_count = 0

        for page in range(pagination.max_pages):
            self.logger.info(f"Scroll page {page + 1}/{pagination.max_pages}")

            # Scroll
            self._scroll_to_bottom(max_scrolls=5, pause=pagination.scroll_pause)

            # Items'ları bul
            current_items = []
            for selector in item_selectors:
                try:
                    items = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    if items:
                        current_items = items
                        break
                except:
                    continue

            # Yeni items'ları ekle
            new_count = 0
            for item in current_items:
                try:
                    url = item.get_attribute('href') or ''
                    if url and url not in seen_urls:
                        seen_urls.add(url)
                        all_items.append(item)
                        new_count += 1
                except:
                    continue

            self.logger.info(f"Found {new_count} new items, total: {len(all_items)}")

            if new_count == 0:
                no_new_items_count += 1
                if no_new_items_count >= 2:
                    self.logger.info("No more new items, stopping pagination")
                    break
            else:
                no_new_items_count = 0

            if len(all_items) >= max_items:
                self.logger.info(f"Reached max items limit: {max_items}")
                break

            self.stats.pages_scraped += 1
            self._random_delay(1, 3)

        return all_items[:max_items]

    def _paginate_button(self, max_items: int = 100) -> List:
        """
        Button click pagination (Load More veya Next Page)

        Args:
            max_items: Maksimum ürün sayısı

        Returns:
            Bulunan element listesi
        """
        config = self._get_platform_config()
        item_selectors = config.get('item_selectors', [])
        pagination = config.get('pagination', PaginationConfig())

        all_items = []
        seen_urls = set()

        for page in range(pagination.max_pages):
            self.logger.info(f"Button page {page + 1}/{pagination.max_pages}")

            # Önce sayfadaki items'ları topla
            self._human_scroll(scroll_amount=500)
            self._random_delay(1, 2)

            current_items = []
            for selector in item_selectors:
                try:
                    items = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    if items:
                        current_items = items
                        break
                except:
                    continue

            # Yeni items'ları ekle
            for item in current_items:
                try:
                    url = item.get_attribute('href') or ''
                    if url and url not in seen_urls:
                        seen_urls.add(url)
                        all_items.append(item)
                except:
                    continue

            self.logger.info(f"Total items: {len(all_items)}")

            if len(all_items) >= max_items:
                break

            # Load More veya Next butonunu bul ve tıkla
            button_found = False

            # Load More button
            if pagination.load_more_selector:
                try:
                    load_more = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, pagination.load_more_selector))
                    )
                    self._human_mouse_move(load_more)
                    self._random_delay(0.3, 0.8)
                    load_more.click()
                    button_found = True
                    self.logger.info("Clicked Load More button")
                except:
                    pass

            # Next Page button
            if not button_found and pagination.next_button_selector:
                try:
                    next_btn = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, pagination.next_button_selector))
                    )
                    self._human_mouse_move(next_btn)
                    self._random_delay(0.3, 0.8)
                    next_btn.click()
                    button_found = True
                    self.logger.info("Clicked Next Page button")
                except:
                    pass

            if not button_found:
                self.logger.info("No more pages available")
                break

            self.stats.pages_scraped += 1
            self._random_delay(pagination.scroll_pause, pagination.scroll_pause * 1.5)

        return all_items[:max_items]

    def _paginate_url(self, base_url: str, max_items: int = 100) -> List:
        """
        URL-based pagination

        Args:
            base_url: İlk sayfa URL'i
            max_items: Maksimum ürün sayısı

        Returns:
            Bulunan element listesi
        """
        config = self._get_platform_config()
        item_selectors = config.get('item_selectors', [])
        pagination = config.get('pagination', PaginationConfig())

        all_items = []
        seen_urls = set()

        for page in range(1, pagination.max_pages + 1):
            # URL oluştur
            if pagination.page_url_template:
                page_url = pagination.page_url_template.format(page=page)
                if not page_url.startswith('http'):
                    page_url = base_url + page_url
            else:
                # Varsayılan: ?page=X
                separator = '&' if '?' in base_url else '?'
                page_url = f"{base_url}{separator}page={page}"

            self.logger.info(f"URL page {page}/{pagination.max_pages}")

            # Sayfaya git
            self.driver.get(page_url)
            self._random_delay(2, 4)

            # Popup'ları kapat
            self._handle_popups()

            # CAPTCHA kontrolü
            if self._check_captcha():
                if not self._wait_for_captcha_solve():
                    break

            # Scroll
            self._human_scroll(scroll_amount=500)
            self._random_delay(1, 2)

            # Items'ları bul
            current_items = []
            for selector in item_selectors:
                try:
                    items = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    if items:
                        current_items = items
                        break
                except:
                    continue

            if not current_items:
                self.logger.info("No items found on page, stopping")
                break

            # Yeni items'ları ekle
            new_count = 0
            for item in current_items:
                try:
                    url = item.get_attribute('href') or ''
                    if url and url not in seen_urls:
                        seen_urls.add(url)
                        all_items.append(item)
                        new_count += 1
                except:
                    continue

            if new_count == 0:
                self.logger.info("No new items on page, stopping")
                break

            self.logger.info(f"Found {new_count} new items, total: {len(all_items)}")

            if len(all_items) >= max_items:
                break

            self.stats.pages_scraped += 1

        return all_items[:max_items]

    # ========================================================================
    # MAIN SEARCH METHOD
    # ========================================================================

    def search(
        self,
        query: str,
        filters: Optional[Dict] = None,
        max_items: int = 50
    ) -> List[Dict]:
        """
        Ana arama metodu

        Args:
            query: Arama sorgusu
            filters: Filtreler {
                'price_min': float,
                'price_max': float,
                'category': str,
                'brand': str,
                'condition': str
            }
            max_items: Maksimum ürün sayısı

        Returns:
            Ürün listesi (dict formatında)
        """
        self.logger.info(f"Starting search: '{query}' (max: {max_items})")
        self.stats = ScraperStats()  # Reset stats

        results = []

        for attempt in range(self.max_retries):
            try:
                # Driver başlat
                self._init_driver()

                # URL oluştur ve git
                search_url = self._build_search_url(query, filters)
                self.logger.info(f"URL: {search_url}")

                self.driver.get(search_url)
                self._random_delay(2, 4)

                # Popup'ları kapat
                self._handle_popups()

                # CAPTCHA kontrolü
                if self._check_captcha():
                    if not self._wait_for_captcha_solve():
                        self.stats.retries += 1
                        self.close()
                        self._random_delay(5, 10)
                        continue

                # İnsan benzeri davranış
                self._human_mouse_move()
                self._random_delay(1, 2)

                # Pagination tipine göre items topla
                config = self._get_platform_config()
                pagination = config.get('pagination', PaginationConfig())

                if pagination.type == 'scroll':
                    elements = self._paginate_scroll(max_items)
                elif pagination.type == 'button':
                    elements = self._paginate_button(max_items)
                elif pagination.type == 'url':
                    elements = self._paginate_url(search_url, max_items)
                else:
                    # Tek sayfa
                    elements = []
                    for selector in config.get('item_selectors', []):
                        try:
                            elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                            if elements:
                                break
                        except:
                            continue

                self.stats.items_found = len(elements)
                self.logger.info(f"Found {len(elements)} elements")

                # Ürünleri extract et
                for element in elements[:max_items]:
                    try:
                        product = self._extract_product_from_element(element)
                        if product and product.title:
                            results.append(product.to_dict())
                            self.stats.items_extracted += 1
                    except Exception as e:
                        self.stats.errors += 1
                        continue

                self.logger.info(f"Extracted {len(results)} products")
                break  # Başarılı, döngüden çık

            except Exception as e:
                self.logger.error(f"Search error (attempt {attempt + 1}): {e}")
                self.stats.errors += 1
                self.stats.retries += 1
                self.close()
                self._random_delay(3, 7)
                continue

        return results

    # ========================================================================
    # HELPER METHODS
    # ========================================================================

    def _parse_price(self, price_text: str) -> float:
        """Fiyat text'inden float değer çıkar"""
        if not price_text:
            return 0.0

        # Temizle
        price_clean = re.sub(r'[^\d,.]', '', price_text)

        # Almanca format: 1.234,56 -> 1234.56
        if ',' in price_clean and '.' in price_clean:
            if price_clean.index('.') < price_clean.index(','):
                price_clean = price_clean.replace('.', '').replace(',', '.')
            else:
                price_clean = price_clean.replace(',', '')
        elif ',' in price_clean:
            price_clean = price_clean.replace(',', '.')

        try:
            return float(price_clean)
        except:
            return 0.0

    def _generate_id(self, url: str) -> str:
        """URL'den benzersiz ID oluştur"""
        if not url:
            return f"{self.platform_key}_{hashlib.md5(str(time.time()).encode()).hexdigest()[:12]}"

        return f"{self.platform_key}_{hashlib.md5(url.encode()).hexdigest()[:12]}"

    def _safe_get_text(self, element, selector: str, default: str = '') -> str:
        """Güvenli text çıkarma"""
        try:
            el = element.find_element(By.CSS_SELECTOR, selector)
            return el.text.strip()
        except:
            return default

    def _safe_get_attribute(self, element, attr: str, default: str = '') -> str:
        """Güvenli attribute çıkarma"""
        try:
            return element.get_attribute(attr) or default
        except:
            return default

    def get_stats(self) -> Dict:
        """İstatistikleri döndür"""
        return {
            'pages_scraped': self.stats.pages_scraped,
            'items_found': self.stats.items_found,
            'items_extracted': self.stats.items_extracted,
            'captchas_detected': self.stats.captchas_detected,
            'popups_closed': self.stats.popups_closed,
            'errors': self.stats.errors,
            'retries': self.stats.retries,
            'duration_seconds': self.stats.duration_seconds
        }


# ============================================================================
# TEST
# ============================================================================

if __name__ == '__main__':
    print("="*60)
    print("TATANGA v3 - Base Scraper")
    print("="*60)
    print("\nThis is an abstract base class.")
    print("Use platform-specific scrapers like WillhabenScraper.")
    print("\nAvailable features:")
    print("  - Cookie/Popup handling")
    print("  - Human-like scroll & mouse movements")
    print("  - Pagination (scroll, button, URL)")
    print("  - Anti-bot bypass techniques")
    print("  - Rate limiting")
    print("  - Session management")
