"""
TATANGA V3 - Human-like Scraper Service (Updated Selectors)
Supports: Vinted, eBay, Kleinanzeigen, Sellpy
"""
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from urllib.parse import urlencode, quote
from datetime import datetime
from typing import Dict, List
import time
import random
import logging
import re
import json

logger = logging.getLogger("TATANGA.scraper")


class HumanBehavior:
    """Simulate human-like browser behavior"""

    @staticmethod
    def random_delay(min_sec: float = 0.5, max_sec: float = 2.0):
        time.sleep(random.uniform(min_sec, max_sec))

    @staticmethod
    def human_scroll(driver, scroll_amount: int = None, direction: str = "down"):
        if scroll_amount is None:
            scroll_amount = random.randint(300, 700)
        if direction == "up":
            scroll_amount = -scroll_amount
        chunks = random.randint(3, 6)
        chunk_size = scroll_amount // chunks
        for i in range(chunks):
            driver.execute_script(f"window.scrollBy(0, {chunk_size})")
            time.sleep(random.uniform(0.05, 0.12))
            if random.random() < 0.15:
                time.sleep(random.uniform(0.2, 0.5))

    @staticmethod
    def random_mouse_movement(driver, element=None):
        try:
            actions = ActionChains(driver)
            if element:
                offset_x = random.randint(-3, 3)
                offset_y = random.randint(-3, 3)
                actions.move_to_element_with_offset(element, offset_x, offset_y)
            actions.perform()
            time.sleep(random.uniform(0.05, 0.2))
        except:
            pass


class ScraperService:
    """Multi-platform scraper with human-like behavior"""

    PLATFORMS = {
        "vinted": {"base_url": "https://www.vinted.de"},
        "ebay": {"base_url": "https://www.ebay.de"},
        "kleinanzeigen": {"base_url": "https://www.kleinanzeigen.de"},
        "sellpy": {"base_url": "https://www.sellpy.de"},
    }

    def __init__(self, headless: bool = True):
        self.headless = headless
        self.driver = None
        self.human = HumanBehavior()

    def _init_driver(self):
        if self.driver:
            return

        options = uc.ChromeOptions()
        if self.headless:
            options.add_argument("--headless=new")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--lang=de-DE")

        user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/130.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36",
        ]
        options.add_argument(f"--user-agent={random.choice(user_agents)}")

        self.driver = uc.Chrome(options=options)
        self.driver.implicitly_wait(3)  # Reduced for faster extraction
        logger.info("Chrome driver initialized")

    def _close_cookies(self):
        cookie_selectors = [
            "#onetrust-accept-btn-handler",
            "#gdpr-banner-accept",
            "[data-testid='cookie-accept']",
            "#didomi-notice-agree-button",
            "button[id*='accept']",
            "[class*='cookie'] button[class*='accept']",
        ]

        for selector in cookie_selectors:
            try:
                btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.human.random_mouse_movement(self.driver, btn)
                    btn.click()
                    self.human.random_delay(0.5, 1.0)
                    logger.info("Cookie banner closed")
                    return
            except:
                pass

    def _human_scroll_page(self, times: int = 3):
        for i in range(times):
            self.human.human_scroll(self.driver)
            self.human.random_delay(0.3, 0.8)

    # URL Builders
    def _build_vinted_url(self, query, min_price=None, max_price=None, **kwargs):
        params = {"search_text": query, "order": "newest_first"}
        if min_price:
            params["price_from"] = int(min_price)
        if max_price:
            params["price_to"] = int(max_price)
        return f"https://www.vinted.de/catalog?{urlencode(params)}"

    def _build_ebay_url(self, query, min_price=None, max_price=None, **kwargs):
        params = {"_nkw": query, "_sop": 10}
        if min_price:
            params["_udlo"] = int(min_price)
        if max_price:
            params["_udhi"] = int(max_price)
        return f"https://www.ebay.de/sch/i.html?{urlencode(params)}"

    def _build_kleinanzeigen_url(self, query, min_price=None, max_price=None, **kwargs):
        price_part = ""
        if min_price or max_price:
            p_min = int(min_price) if min_price else ""
            p_max = int(max_price) if max_price else ""
            price_part = f"preis:{p_min}:{p_max}/"
        return f"https://www.kleinanzeigen.de/s-{price_part}{query.replace(' ', '-')}/k0"

    def _build_sellpy_url(self, query, min_price=None, max_price=None, **kwargs):
        params = {"q": query}
        if min_price:
            params["minPrice"] = int(min_price)
        if max_price:
            params["maxPrice"] = int(max_price)
        return f"https://www.sellpy.de/search?{urlencode(params)}"

    # Extractors
    def _extract_vinted(self) -> List[Dict]:
        """Extract products from Vinted - using data-testid selector"""
        products = []
        try:
            # Use data-testid selector which contains product ID - most reliable
            imgs = self.driver.find_elements(By.CSS_SELECTOR, "img[data-testid*='product-item']")
            logger.info(f"Vinted: Found {len(imgs)} product images")

            seen_urls = set()
            for img in imgs[:60]:
                try:
                    alt_text = img.get_attribute("alt") or ""
                    if not alt_text or len(alt_text) < 5:
                        continue

                    image_url = img.get_attribute("src")

                    # Get URL from data-testid which contains product ID
                    testid = img.get_attribute("data-testid") or ""
                    # Format: product-item-id-7825237839--image--img
                    product_id_match = re.search(r"product-item-id-(\d+)", testid)
                    if not product_id_match:
                        continue

                    product_id = product_id_match.group(1)
                    url = f"https://www.vinted.de/items/{product_id}"

                    if url in seen_urls:
                        continue
                    seen_urls.add(url)

                    # Parse alt text: "Tommy Hilfiger Handtasche, marke: Tommy Hilfiger, zustand: Sehr gut, 20,00 EUR"
                    title = alt_text.split(",")[0].strip()

                    # Extract price from alt
                    price = None
                    price_match = re.search(r"([\d.,]+)\s*(?:€|EUR)", alt_text)
                    if price_match:
                        try:
                            price = float(price_match.group(1).replace(".", "").replace(",", "."))
                        except:
                            pass

                    if title and len(title) > 2:
                        products.append({
                            "url": url,
                            "title": title[:200],
                            "price": price,
                            "image": image_url,
                            "platform": "vinted",
                            "scraped_at": datetime.now().isoformat()
                        })
                except:
                    continue

        except Exception as e:
            logger.warning(f"Vinted extraction error: {e}")

        logger.info(f"Vinted: Extracted {len(products)} products")
        return products

    def _extract_ebay(self) -> List[Dict]:
        """Extract products from eBay - new 2024/2025 structure"""
        products = []
        try:
            items = self.driver.find_elements(By.CSS_SELECTOR, "li[data-viewport]")
            logger.info(f"eBay: Found {len(items)} item containers")

            for item in items[:60]:
                try:
                    # Get link
                    try:
                        link = item.find_element(By.CSS_SELECTOR, "a")
                        url = link.get_attribute("href")
                    except:
                        continue

                    if not url or "ebay.de/itm/" not in url:
                        continue

                    # Title - first line of text
                    title = ""
                    try:
                        item_text = item.text.split("\n")[0]
                        title = item_text.strip()
                    except:
                        pass

                    # Price
                    price = None
                    try:
                        price_el = item.find_element(By.CSS_SELECTOR, ".s-card__price")
                        price_text = price_el.text
                        price = float(price_text.replace("EUR", "").replace(".", "").replace(",", ".").strip())
                    except:
                        pass

                    # Image
                    image = None
                    try:
                        img_el = item.find_element(By.CSS_SELECTOR, "img")
                        image = img_el.get_attribute("src")
                    except:
                        pass

                    if title and len(title) > 2:
                        products.append({
                            "url": url,
                            "title": title[:200],
                            "price": price,
                            "image": image,
                            "platform": "ebay",
                            "scraped_at": datetime.now().isoformat()
                        })
                except:
                    continue

        except Exception as e:
            logger.warning(f"eBay extraction error: {e}")

        logger.info(f"eBay: Extracted {len(products)} products")
        return products

    def _extract_kleinanzeigen(self) -> List[Dict]:
        """Extract products from Kleinanzeigen"""
        products = []
        try:
            items = self.driver.find_elements(By.CSS_SELECTOR, "article.aditem, [data-adid]")
            logger.info(f"Kleinanzeigen: Found {len(items)} item containers")

            for item in items[:60]:
                try:
                    # URL from data-href or anchor
                    url = None
                    data_href = item.get_attribute("data-href")
                    if data_href:
                        url = "https://www.kleinanzeigen.de" + data_href if not data_href.startswith("http") else data_href
                    else:
                        try:
                            link = item.find_element(By.CSS_SELECTOR, "a[href*='/s-anzeige/']")
                            url = link.get_attribute("href")
                            if not url.startswith("http"):
                                url = "https://www.kleinanzeigen.de" + url
                        except:
                            pass

                    if not url:
                        continue

                    # Title from JSON-LD or img alt
                    title = ""
                    try:
                        script = item.find_element(By.CSS_SELECTOR, "script[type='application/ld+json']")
                        json_data = json.loads(script.get_attribute("innerHTML"))
                        title = json_data.get("title", "")
                    except:
                        try:
                            img = item.find_element(By.CSS_SELECTOR, "img[alt]")
                            alt = img.get_attribute("alt") or ""
                            title = alt.split(" Vorschau")[0].strip() if " Vorschau" in alt else alt
                        except:
                            pass

                    # Price
                    price = None
                    try:
                        price_el = item.find_element(By.CSS_SELECTOR, ".aditem-main--middle--price-shipping--price, .aditem-main--middle--price, [class*='price']")
                        price_text = price_el.text
                        price_match = re.search(r"([\d.,]+)", price_text)
                        if price_match:
                            price = float(price_match.group(1).replace(".", "").replace(",", "."))
                    except:
                        pass

                    # Image
                    image = None
                    try:
                        img = item.find_element(By.CSS_SELECTOR, "img[src]")
                        image = img.get_attribute("src")
                    except:
                        pass

                    if title and len(title) > 2:
                        products.append({
                            "url": url,
                            "title": title[:200],
                            "price": price,
                            "image": image,
                            "platform": "kleinanzeigen",
                            "scraped_at": datetime.now().isoformat()
                        })
                except:
                    continue

        except Exception as e:
            logger.warning(f"Kleinanzeigen extraction error: {e}")

        logger.info(f"Kleinanzeigen: Extracted {len(products)} products")
        return products

    def _extract_sellpy(self) -> List[Dict]:
        """Extract products from Sellpy - uses Schema.org markup"""
        products = []
        try:
            items = self.driver.find_elements(By.CSS_SELECTOR, "article[itemtype*='Product'], article.item-tile-container")
            logger.info(f"Sellpy: Found {len(items)} item containers")

            for item in items[:60]:
                try:
                    # URL
                    url = None
                    try:
                        link = item.find_element(By.CSS_SELECTOR, "a[itemprop='url'], a[href*='/item/']")
                        url = link.get_attribute("href")
                        if url and not url.startswith("http"):
                            url = "https://www.sellpy.de" + url
                    except:
                        pass

                    if not url:
                        continue

                    # Title - brand + description
                    title = ""
                    try:
                        brand = item.find_element(By.CSS_SELECTOR, "h3[itemprop='name'], h3").text
                        try:
                            desc = item.find_element(By.CSS_SELECTOR, "p[class*='RrhFW'], p[class*='body3']").text
                        except:
                            desc = ""
                        title = f"{brand} - {desc}".strip() if brand and desc else (brand or desc)
                    except:
                        pass

                    # Price
                    price = None
                    try:
                        price_el = item.find_element(By.CSS_SELECTOR, "p[itemprop='price']")
                        content = price_el.get_attribute("content")
                        if content:
                            price = float(content)
                        else:
                            price_text = price_el.text
                            price = float(price_text.replace("EUR", "").replace(",", ".").strip())
                    except:
                        pass

                    # Image
                    image = None
                    try:
                        img = item.find_element(By.CSS_SELECTOR, "img[itemprop='image'], img[src]")
                        image = img.get_attribute("src")
                    except:
                        pass

                    if title and len(title) > 2:
                        products.append({
                            "url": url,
                            "title": title[:200],
                            "price": price,
                            "image": image,
                            "platform": "sellpy",
                            "scraped_at": datetime.now().isoformat()
                        })
                except:
                    continue

        except Exception as e:
            logger.warning(f"Sellpy extraction error: {e}")

        logger.info(f"Sellpy: Extracted {len(products)} products")
        return products

    def scrape(self, platform: str, query: str, max_pages: int = 3, max_items: int = 50,
               min_price: float = None, max_price: float = None, condition: str = None, sort: str = None) -> Dict:
        """Main scraping method"""
        result = {
            "status": "pending",
            "platform": platform,
            "query": query,
            "products": [],
            "stats": {
                "pages_scraped": 0,
                "items_found": 0,
                "started_at": datetime.now().isoformat(),
                "completed_at": None
            }
        }

        # Check if platform is supported
        if platform not in self.PLATFORMS:
            result["status"] = "error"
            result["error"] = f"Platform '{platform}' is not supported. Supported: {list(self.PLATFORMS.keys())}"
            return result

        try:
            self._init_driver()

            # Build URL
            url_builders = {
                "vinted": self._build_vinted_url,
                "ebay": self._build_ebay_url,
                "kleinanzeigen": self._build_kleinanzeigen_url,
                "sellpy": self._build_sellpy_url,
            }

            builder = url_builders.get(platform)
            search_url = builder(query, min_price, max_price)
            logger.info(f"Scraping {platform}: {query} - URL: {search_url}")

            # Navigate
            self.driver.get(search_url)
            self.human.random_delay(3, 5)

            self._close_cookies()
            self.human.random_delay(1, 2)

            all_products = []
            extractors = {
                "vinted": self._extract_vinted,
                "ebay": self._extract_ebay,
                "kleinanzeigen": self._extract_kleinanzeigen,
                "sellpy": self._extract_sellpy,
            }

            for page in range(max_pages):
                logger.info(f"Page {page + 1}/{max_pages}")

                self._human_scroll_page(random.randint(2, 4))
                self.human.random_delay(1, 2)

                extractor = extractors.get(platform)
                if extractor:
                    products = extractor()
                else:
                    products = []

                existing_urls = {p["url"] for p in all_products}
                new_products = [p for p in products if p.get("url") and p["url"] not in existing_urls]
                all_products.extend(new_products)

                result["stats"]["pages_scraped"] += 1
                logger.info(f"Found {len(new_products)} new products on page {page + 1}")

                if len(all_products) >= max_items:
                    break

                # Don't navigate to next page for now - single page scraping
                if page < max_pages - 1:
                    self.human.random_delay(1, 2)

            all_products = all_products[:max_items]
            result["products"] = all_products
            result["stats"]["items_found"] = len(all_products)
            result["stats"]["completed_at"] = datetime.now().isoformat()
            result["status"] = "completed"

        except Exception as e:
            logger.error(f"Scraping error: {e}")
            result["status"] = "error"
            result["error"] = str(e)

        return result

    def close(self):
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            self.driver = None


def run_scrape_task(platform: str, query: str, max_pages: int = 3, max_items: int = 50,
                   min_price: float = None, max_price: float = None, condition: str = None, sort: str = None) -> Dict:
    """Run scraping task"""
    scraper = ScraperService(headless=True)
    try:
        return scraper.scrape(platform, query, max_pages, max_items, min_price, max_price, condition, sort)
    finally:
        scraper.close()