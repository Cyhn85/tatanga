#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STOCK MONITOR
Monitor source product availability for DIS LOGISTIK operations
Checks if scraped products are still available on source platforms
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import sqlite3
import requests
from pathlib import Path
from datetime import datetime, timedelta
from threading import Thread
import time
import re


class StockMonitor:
    """Monitor source product availability and auto-deactivate if unavailable"""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Stock Monitor - DIS LOGISTIK")
        self.root.geometry("1000x700")
        self.root.configure(bg='#0f0f1e')

        # Database path
        self.db_path = Path(__file__).parent.parent / "active_pieces" / "tatanga.db"
        if not self.db_path.exists():
            self.db_path = Path(__file__).parent / "tatanga.db"

        # Monitoring state
        self.monitoring = False
        self.monitor_thread = None

        # Setup UI
        self.setup_ui()

    def setup_ui(self):
        """Create the main UI"""

        # Header
        header = tk.Frame(self.root, bg='#16213e', height=80)
        header.pack(fill=tk.X, padx=10, pady=10)

        title = tk.Label(
            header,
            text="📡 STOCK MONITOR",
            font=("Arial", 24, "bold"),
            fg='#f39c12',
            bg='#16213e'
        )
        title.pack(side=tk.LEFT, padx=20, pady=20)

        subtitle = tk.Label(
            header,
            text="Monitor source product availability\nAuto-deactivate if out of stock",
            font=("Arial", 10),
            fg='#ffffff',
            bg='#16213e',
            justify=tk.LEFT
        )
        subtitle.pack(side=tk.LEFT, padx=20)

        # Status indicator
        self.status_label = tk.Label(
            header,
            text="● STOPPED",
            font=("Arial", 12, "bold"),
            fg='#e74c3c',
            bg='#16213e'
        )
        self.status_label.pack(side=tk.RIGHT, padx=20)

        # Control panel
        control_frame = tk.LabelFrame(
            self.root,
            text="MONITOR CONTROLS",
            bg='#16213e',
            fg='#f39c12',
            font=("Arial", 12, "bold"),
            padx=15,
            pady=15
        )
        control_frame.pack(fill=tk.X, padx=10, pady=10)

        # Settings
        settings_frame = tk.Frame(control_frame, bg='#16213e')
        settings_frame.pack(fill=tk.X, pady=5)

        tk.Label(
            settings_frame,
            text="Check Interval:",
            bg='#16213e',
            fg='#ffffff',
            font=("Arial", 10)
        ).pack(side=tk.LEFT, padx=5)

        self.interval_var = tk.StringVar(value="4")
        interval_combo = ttk.Combobox(
            settings_frame,
            textvariable=self.interval_var,
            values=["1", "2", "4", "6", "12", "24"],
            state="readonly",
            width=8
        )
        interval_combo.pack(side=tk.LEFT, padx=5)

        tk.Label(
            settings_frame,
            text="hours",
            bg='#16213e',
            fg='#ffffff',
            font=("Arial", 10)
        ).pack(side=tk.LEFT, padx=5)

        # Auto-deactivate option
        self.auto_deactivate = tk.BooleanVar(value=True)
        tk.Checkbutton(
            settings_frame,
            text="Auto-deactivate if out of stock",
            variable=self.auto_deactivate,
            bg='#16213e',
            fg='#ffffff',
            font=("Arial", 10),
            selectcolor='#0f0f1e'
        ).pack(side=tk.LEFT, padx=20)

        # Buttons
        button_frame = tk.Frame(control_frame, bg='#16213e')
        button_frame.pack(fill=tk.X, pady=10)

        self.start_button = tk.Button(
            button_frame,
            text="▶ Start Monitoring",
            command=self.start_monitoring,
            bg='#50c878',
            fg='#ffffff',
            font=("Arial", 11, "bold"),
            cursor="hand2",
            width=18
        )
        self.start_button.pack(side=tk.LEFT, padx=5)

        self.stop_button = tk.Button(
            button_frame,
            text="⏹ Stop Monitoring",
            command=self.stop_monitoring,
            bg='#e74c3c',
            fg='#ffffff',
            font=("Arial", 11, "bold"),
            cursor="hand2",
            width=18,
            state='disabled'
        )
        self.stop_button.pack(side=tk.LEFT, padx=5)

        tk.Button(
            button_frame,
            text="🔍 Check Now",
            command=self.check_now,
            bg='#4a90e2',
            fg='#ffffff',
            font=("Arial", 11, "bold"),
            cursor="hand2",
            width=18
        ).pack(side=tk.LEFT, padx=5)

        # Stats panel
        stats_frame = tk.LabelFrame(
            self.root,
            text="MONITORING STATS",
            bg='#16213e',
            fg='#f39c12',
            font=("Arial", 12, "bold"),
            padx=15,
            pady=15
        )
        stats_frame.pack(fill=tk.X, padx=10, pady=10)

        self.stats_label = tk.Label(
            stats_frame,
            text="Total Products: 0 | Active: 0 | Out of Stock: 0 | Last Check: Never",
            bg='#16213e',
            fg='#ffffff',
            font=("Arial", 10),
            anchor=tk.W
        )
        self.stats_label.pack(fill=tk.X, pady=5)

        # Products table
        table_frame = tk.LabelFrame(
            self.root,
            text="MONITORED PRODUCTS",
            bg='#16213e',
            fg='#f39c12',
            font=("Arial", 12, "bold"),
            padx=10,
            pady=10
        )
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Treeview
        vsb = ttk.Scrollbar(table_frame, orient="vertical")

        self.products_tree = ttk.Treeview(
            table_frame,
            columns=("ID", "Platform", "Title", "Status", "Last Check"),
            show='headings',
            yscrollcommand=vsb.set
        )

        vsb.config(command=self.products_tree.yview)

        self.products_tree.heading("ID", text="Product ID")
        self.products_tree.heading("Platform", text="Platform")
        self.products_tree.heading("Title", text="Title")
        self.products_tree.heading("Status", text="Stock Status")
        self.products_tree.heading("Last Check", text="Last Checked")

        self.products_tree.column("ID", width=80)
        self.products_tree.column("Platform", width=120)
        self.products_tree.column("Title", width=350)
        self.products_tree.column("Status", width=120)
        self.products_tree.column("Last Check", width=150)

        self.products_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        # Log
        log_frame = tk.LabelFrame(
            self.root,
            text="MONITOR LOG",
            bg='#16213e',
            fg='#f39c12',
            font=("Arial", 12, "bold"),
            padx=10,
            pady=10
        )
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            bg='#0f0f1e',
            fg='#00ff41',
            font=("Consolas", 9),
            height=10
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)

        # Initial load
        self.log("Stock Monitor initialized")
        self.refresh_products()
        self.update_stats()

    def refresh_products(self):
        """Refresh products table"""

        try:
            # Clear existing
            for item in self.products_tree.get_children():
                self.products_tree.delete(item)

            if not self.db_path.exists():
                self.log("Database not found", "WARN")
                return

            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            # Get products with source URLs (DIS LOGISTIK products)
            cursor.execute("""
                SELECT id, platform, title, stock_status, last_stock_check
                FROM products
                WHERE source_url IS NOT NULL
                ORDER BY id DESC
                LIMIT 500
            """)

            rows = cursor.fetchall()
            conn.close()

            for row in rows:
                product_id, platform, title, status, last_check = row
                title_short = title[:50] + "..." if len(title) > 50 else title
                status_display = status if status else "Unknown"
                last_check_display = last_check if last_check else "Never"

                self.products_tree.insert(
                    "",
                    tk.END,
                    values=(product_id, platform, title_short, status_display, last_check_display)
                )

            self.log(f"Loaded {len(rows)} products for monitoring")

        except Exception as e:
            self.log(f"Error refreshing products: {e}", "ERROR")

    def update_stats(self):
        """Update statistics"""

        try:
            if not self.db_path.exists():
                return

            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            # Total products with source URLs
            cursor.execute("SELECT COUNT(*) FROM products WHERE source_url IS NOT NULL")
            total = cursor.fetchone()[0]

            # Active (in stock)
            cursor.execute("SELECT COUNT(*) FROM products WHERE source_url IS NOT NULL AND stock_status = 'in_stock'")
            active = cursor.fetchone()[0]

            # Out of stock
            cursor.execute("SELECT COUNT(*) FROM products WHERE source_url IS NOT NULL AND stock_status = 'out_of_stock'")
            out_of_stock = cursor.fetchone()[0]

            # Last check
            cursor.execute("SELECT MAX(last_stock_check) FROM products WHERE source_url IS NOT NULL")
            last_check = cursor.fetchone()[0]
            last_check_display = last_check if last_check else "Never"

            conn.close()

            self.stats_label.config(
                text=f"Total Products: {total} | Active: {active} | Out of Stock: {out_of_stock} | Last Check: {last_check_display}"
            )

        except Exception as e:
            self.log(f"Error updating stats: {e}", "ERROR")

    def start_monitoring(self):
        """Start automatic monitoring"""

        self.monitoring = True
        self.status_label.config(text="● RUNNING", fg='#50c878')
        self.start_button.config(state='disabled')
        self.stop_button.config(state='normal')

        self.log("="*60)
        self.log("MONITORING STARTED")
        self.log(f"Check interval: {self.interval_var.get()} hours")
        self.log("="*60)

        # Start monitor thread
        self.monitor_thread = Thread(target=self.monitor_loop, daemon=True)
        self.monitor_thread.start()

    def stop_monitoring(self):
        """Stop automatic monitoring"""

        self.monitoring = False
        self.status_label.config(text="● STOPPED", fg='#e74c3c')
        self.start_button.config(state='normal')
        self.stop_button.config(state='disabled')

        self.log("MONITORING STOPPED")

    def monitor_loop(self):
        """Background monitoring loop"""

        interval_hours = int(self.interval_var.get())
        interval_seconds = interval_hours * 3600

        while self.monitoring:
            try:
                self.log(f"Running stock check...")
                self.perform_stock_check()
                self.log(f"Stock check complete. Next check in {interval_hours} hours.")

                # Sleep in small intervals to allow quick stop
                for _ in range(interval_seconds):
                    if not self.monitoring:
                        break
                    time.sleep(1)

            except Exception as e:
                self.log(f"Monitor loop error: {e}", "ERROR")
                time.sleep(60)  # Wait 1 minute on error

    def check_now(self):
        """Perform immediate stock check"""

        self.log("="*60)
        self.log("MANUAL STOCK CHECK STARTED")
        self.log("="*60)

        Thread(target=self.perform_stock_check, daemon=True).start()

    def perform_stock_check(self):
        """Perform stock availability check"""

        try:
            if not self.db_path.exists():
                self.log("Database not found", "ERROR")
                return

            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            # Get products with source URLs
            cursor.execute("""
                SELECT id, platform, title, source_url, stock_status
                FROM products
                WHERE source_url IS NOT NULL
            """)

            products = cursor.fetchall()

            in_stock_count = 0
            out_of_stock_count = 0
            error_count = 0

            for product in products:
                product_id, platform, title, source_url, current_status = product

                try:
                    # Check URL availability
                    availability = self.check_url_availability(source_url, platform)

                    if availability == 'in_stock':
                        in_stock_count += 1
                        new_status = 'in_stock'
                    elif availability == 'out_of_stock':
                        out_of_stock_count += 1
                        new_status = 'out_of_stock'

                        # Auto-deactivate if enabled
                        if self.auto_deactivate.get() and current_status != 'out_of_stock':
                            self.log(f"❌ OUT OF STOCK: {title[:40]}... - Deactivating", "WARN")
                            # TODO: Deactivate on target platforms
                    else:
                        error_count += 1
                        new_status = 'unknown'

                    # Update database
                    cursor.execute("""
                        UPDATE products
                        SET stock_status = ?, last_stock_check = ?
                        WHERE id = ?
                    """, (new_status, datetime.now().isoformat(), product_id))

                except Exception as e:
                    self.log(f"Error checking {product_id}: {e}", "ERROR")
                    error_count += 1

                # Small delay to avoid rate limiting
                time.sleep(1)

            conn.commit()
            conn.close()

            # Summary
            self.log("="*60)
            self.log(f"CHECK COMPLETE")
            self.log(f"✅ In Stock: {in_stock_count}")
            self.log(f"❌ Out of Stock: {out_of_stock_count}")
            self.log(f"⚠️ Errors: {error_count}")
            self.log("="*60)

            # Refresh UI
            self.root.after(0, self.refresh_products)
            self.root.after(0, self.update_stats)

        except Exception as e:
            self.log(f"Stock check error: {e}", "ERROR")

    def check_url_availability(self, url, platform):
        """Check if URL is still available"""

        try:
            # Set user agent to avoid blocking
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }

            response = requests.get(url, headers=headers, timeout=10, allow_redirects=True)

            if response.status_code == 404:
                return 'out_of_stock'

            # Check for out-of-stock keywords in HTML
            html_lower = response.text.lower()

            out_of_stock_keywords = [
                'sold out',
                'out of stock',
                'nicht verfügbar',
                'verkauft',
                'ausverkauft',
                'nicht mehr verfügbar',
                'product not found',
                'item removed',
            ]

            for keyword in out_of_stock_keywords:
                if keyword in html_lower:
                    return 'out_of_stock'

            # If page loads and no out-of-stock keywords, assume in stock
            return 'in_stock'

        except requests.exceptions.RequestException as e:
            self.log(f"Request error for {url}: {e}", "ERROR")
            return 'unknown'

    def log(self, message, level="INFO"):
        """Log a message"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_line = f"[{timestamp}] {level}: {message}\n"
        self.root.after(0, lambda: self.log_text.insert(tk.END, log_line))
        self.root.after(0, lambda: self.log_text.see(tk.END))

    def run(self):
        """Start the GUI"""
        self.root.mainloop()


if __name__ == "__main__":
    print("="*60)
    print("STOCK MONITOR - DIS LOGISTIK")
    print("="*60)
    print("Starting GUI...")
    print()

    app = StockMonitor()
    app.run()
