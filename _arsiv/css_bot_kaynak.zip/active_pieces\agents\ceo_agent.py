#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA ENTERPRISE - CEO AGENT
Central orchestrator that manages all 36 scraping operations and sub-agents

Architecture:
                    CEO AGENT (TATANGA)
                          │
    ┌─────────┬───────────┼───────────┬─────────┐
    │         │           │           │         │
    ▼         ▼           ▼           ▼         ▼
 SCRAPING  SALES   COMMUNICATION  LOGISTICS  ACCOUNTING
 MANAGER   MANAGER   MANAGER      MANAGER    MANAGER
    │         │           │           │         │
    ▼         ▼           ▼           ▼         ▼
36 Scrapers Upload   Messaging   Shipping   Invoice
            Login    Reviews     Tracking   Reports

Features:
- 36 parallel scraping operations coordination
- 5 specialized manager agents
- Telegram command interface
- Self-healing system
- 7/24 autonomous operation
- Performance metrics and reporting

Author: TATANGA Team
Version: 2.0
"""

import sys
import os
import asyncio
import json
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
from dataclasses import dataclass, field
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
            logging.basicConfig(level=logging.INFO)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")
        def debug(self, msg, **kwargs):
            self.logger.debug(f"{msg} {kwargs}")

from agents.base_agent import BaseAgent, AgentConfig, AgentStatus


class ManagerType(Enum):
    """Manager types"""
    SCRAPING = "scraping"
    SALES = "sales"
    COMMUNICATION = "communication"
    LOGISTICS = "logistics"
    ACCOUNTING = "accounting"


class OperationPriority(Enum):
    """Operation priority levels"""
    CRITICAL = 1
    HIGH = 2
    NORMAL = 3
    LOW = 4


@dataclass
class SystemMetrics:
    """System-wide performance metrics"""
    total_scrapes: int = 0
    successful_scrapes: int = 0
    failed_scrapes: int = 0
    products_found: int = 0
    products_favorited: int = 0
    products_sold: int = 0
    messages_sent: int = 0
    messages_received: int = 0
    shipments_created: int = 0
    invoices_archived: int = 0
    uptime_hours: float = 0.0
    last_reset: datetime = field(default_factory=datetime.now)


@dataclass
class ManagerStatus:
    """Status of a manager"""
    name: str
    status: str = "idle"
    active_operations: int = 0
    last_activity: Optional[datetime] = None
    error_count: int = 0
    success_rate: float = 100.0


class CEOAgent(BaseAgent):
    """
    CEO Agent - Master Orchestrator for TATANGA Enterprise

    Responsibilities:
    1. Coordinate all 36 scraping operations
    2. Manage 5 specialized managers
    3. Handle Telegram commands
    4. Monitor system health
    5. Self-healing on failures
    6. Generate reports
    7. 7/24 autonomous operation
    """

    # Platform definitions
    PLATFORMS = {
        # VINTED - 13 countries
        'vinted_de': {'platform': 'vinted', 'country': 'de', 'language': 'de-DE', 'currency': 'EUR'},
        'vinted_fr': {'platform': 'vinted', 'country': 'fr', 'language': 'fr-FR', 'currency': 'EUR'},
        'vinted_uk': {'platform': 'vinted', 'country': 'uk', 'language': 'en-GB', 'currency': 'GBP'},
        'vinted_es': {'platform': 'vinted', 'country': 'es', 'language': 'es-ES', 'currency': 'EUR'},
        'vinted_it': {'platform': 'vinted', 'country': 'it', 'language': 'it-IT', 'currency': 'EUR'},
        'vinted_nl': {'platform': 'vinted', 'country': 'nl', 'language': 'nl-NL', 'currency': 'EUR'},
        'vinted_be': {'platform': 'vinted', 'country': 'be', 'language': 'nl-BE', 'currency': 'EUR'},
        'vinted_pl': {'platform': 'vinted', 'country': 'pl', 'language': 'pl-PL', 'currency': 'PLN'},
        'vinted_cz': {'platform': 'vinted', 'country': 'cz', 'language': 'cs-CZ', 'currency': 'CZK'},
        'vinted_at': {'platform': 'vinted', 'country': 'at', 'language': 'de-AT', 'currency': 'EUR'},
        'vinted_se': {'platform': 'vinted', 'country': 'se', 'language': 'sv-SE', 'currency': 'SEK'},
        'vinted_dk': {'platform': 'vinted', 'country': 'dk', 'language': 'da-DK', 'currency': 'DKK'},
        'vinted_no': {'platform': 'vinted', 'country': 'no', 'language': 'nb-NO', 'currency': 'NOK'},

        # EBAY - 10 marketplaces
        'ebay_de': {'platform': 'ebay', 'country': 'de', 'language': 'de-DE', 'currency': 'EUR', 'marketplace_id': 'EBAY_DE'},
        'ebay_uk': {'platform': 'ebay', 'country': 'uk', 'language': 'en-GB', 'currency': 'GBP', 'marketplace_id': 'EBAY_GB'},
        'ebay_fr': {'platform': 'ebay', 'country': 'fr', 'language': 'fr-FR', 'currency': 'EUR', 'marketplace_id': 'EBAY_FR'},
        'ebay_us': {'platform': 'ebay', 'country': 'us', 'language': 'en-US', 'currency': 'USD', 'marketplace_id': 'EBAY_US'},
        'ebay_it': {'platform': 'ebay', 'country': 'it', 'language': 'it-IT', 'currency': 'EUR', 'marketplace_id': 'EBAY_IT'},
        'ebay_es': {'platform': 'ebay', 'country': 'es', 'language': 'es-ES', 'currency': 'EUR', 'marketplace_id': 'EBAY_ES'},
        'ebay_nl': {'platform': 'ebay', 'country': 'nl', 'language': 'nl-NL', 'currency': 'EUR', 'marketplace_id': 'EBAY_NL'},
        'ebay_be': {'platform': 'ebay', 'country': 'be', 'language': 'nl-BE', 'currency': 'EUR', 'marketplace_id': 'EBAY_BE'},
        'ebay_at': {'platform': 'ebay', 'country': 'at', 'language': 'de-AT', 'currency': 'EUR', 'marketplace_id': 'EBAY_AT'},
        'ebay_ch': {'platform': 'ebay', 'country': 'ch', 'language': 'de-CH', 'currency': 'CHF', 'marketplace_id': 'EBAY_CH'},

        # SHPOCK - 3 regions
        'shpock_de': {'platform': 'shpock', 'country': 'de', 'language': 'de-DE', 'currency': 'EUR'},
        'shpock_at': {'platform': 'shpock', 'country': 'at', 'language': 'de-AT', 'currency': 'EUR'},
        'shpock_uk': {'platform': 'shpock', 'country': 'uk', 'language': 'en-GB', 'currency': 'GBP'},

        # Single country platforms
        'kleinanzeigen': {'platform': 'kleinanzeigen', 'country': 'de', 'language': 'de-DE', 'currency': 'EUR'},
        'willhaben': {'platform': 'willhaben', 'country': 'at', 'language': 'de-AT', 'currency': 'EUR'},
        'leboncoin': {'platform': 'leboncoin', 'country': 'fr', 'language': 'fr-FR', 'currency': 'EUR'},
        'tradera': {'platform': 'tradera', 'country': 'se', 'language': 'sv-SE', 'currency': 'SEK'},
        'sellpy_de': {'platform': 'sellpy', 'country': 'de', 'language': 'de-DE', 'currency': 'EUR'},
        'percentil_de': {'platform': 'percentil', 'country': 'de', 'language': 'de-DE', 'currency': 'EUR'},

        # Nordic platforms
        'finn_no': {'platform': 'finn', 'country': 'no', 'language': 'nb-NO', 'currency': 'NOK'},
        'blocket_se': {'platform': 'blocket', 'country': 'se', 'language': 'sv-SE', 'currency': 'SEK'},
        'tori_fi': {'platform': 'tori', 'country': 'fi', 'language': 'fi-FI', 'currency': 'EUR'},
        'dba_dk': {'platform': 'dba', 'country': 'dk', 'language': 'da-DK', 'currency': 'DKK'},
    }

    def __init__(self, config: Optional[AgentConfig] = None):
        """
        Initialize CEO Agent

        Args:
            config: Agent configuration (optional)
        """
        if config is None:
            config = AgentConfig(
                name="ceo_agent",
                interval_seconds=60,  # Main loop every 60 seconds
                max_retries=3,
                enabled=True,
                auto_start=False
            )

        super().__init__(config)

        # Managers
        self.managers: Dict[ManagerType, Any] = {}
        self.manager_status: Dict[ManagerType, ManagerStatus] = {}

        # Telegram bot
        self.telegram_bot = None
        self.telegram_token = os.getenv('TELEGRAM_BOT_TOKEN', '')
        self.admin_chat_id = os.getenv('TELEGRAM_ADMIN_CHAT_ID', '')

        # Metrics
        self.metrics = SystemMetrics()
        self.start_time = datetime.now()

        # Operation queue
        self.operation_queue: List[Dict] = []
        self.operation_lock = threading.Lock()

        # Self-healing
        self.healing_enabled = True
        self.max_consecutive_failures = 5
        self.consecutive_failures: Dict[str, int] = {}

        # Thread pool for parallel operations
        self.executor = ThreadPoolExecutor(max_workers=10)

        # Scheduler for periodic tasks
        self.scheduled_tasks: Dict[str, Dict] = {}

        self.logger.info("CEO Agent initialized", platforms=len(self.PLATFORMS))

    async def setup(self):
        """Setup CEO Agent - called before first process"""
        self.logger.info("Setting up CEO Agent...")

        # Initialize managers
        await self._initialize_managers()

        # Initialize Telegram bot
        await self._initialize_telegram()

        # Load saved state
        await self._load_system_state()

        # Schedule periodic tasks
        self._schedule_periodic_tasks()

        self.logger.info("CEO Agent setup complete")

    async def process(self) -> Dict:
        """
        Main processing loop - called every interval

        Returns:
            Processing result
        """
        try:
            # Update uptime
            self.metrics.uptime_hours = (datetime.now() - self.start_time).total_seconds() / 3600

            # 1. Health check all systems
            health = await self._health_check()

            # 2. Process operation queue
            processed = await self._process_operation_queue()

            # 3. Check for self-healing needs
            if self.healing_enabled:
                await self._self_healing_check()

            # 4. Check favorite products availability
            await self._check_favorites_availability()

            # 5. Check for incoming messages
            await self._check_incoming_messages()

            # 6. Database cleanup (non-favorites older than 7 days)
            await self._database_cleanup()

            # 7. Save state
            await self._save_system_state()

            return {
                'status': 'ok',
                'health': health,
                'operations_processed': processed,
                'metrics': self._get_metrics_summary(),
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            self.logger.error("CEO process error", exception=str(e))
            await self._notify_error("CEO Process Error", str(e))
            raise

    async def cleanup(self):
        """Cleanup CEO Agent - called after stop"""
        self.logger.info("Cleaning up CEO Agent...")

        # Stop all managers
        for manager_type, manager in self.managers.items():
            try:
                if hasattr(manager, 'stop'):
                    manager.stop()
            except Exception as e:
                self.logger.error(f"Error stopping {manager_type}", exception=str(e))

        # Shutdown executor
        self.executor.shutdown(wait=True)

        # Save final state
        await self._save_system_state()

        self.logger.info("CEO Agent cleanup complete")

    # ==================== MANAGER OPERATIONS ====================

    async def _initialize_managers(self):
        """Initialize all manager agents"""
        from agents.managers.scraping_manager import ScrapingManager
        from agents.managers.sales_manager import SalesManager
        from agents.managers.communication_manager import CommunicationManager
        from agents.managers.logistics_manager import LogisticsManager
        from agents.managers.accounting_manager import AccountingManager

        self.managers = {
            ManagerType.SCRAPING: ScrapingManager(self),
            ManagerType.SALES: SalesManager(self),
            ManagerType.COMMUNICATION: CommunicationManager(self),
            ManagerType.LOGISTICS: LogisticsManager(self),
            ManagerType.ACCOUNTING: AccountingManager(self),
        }

        for manager_type in ManagerType:
            self.manager_status[manager_type] = ManagerStatus(name=manager_type.value)

        self.logger.info("All managers initialized", count=len(self.managers))

    def get_manager(self, manager_type: ManagerType) -> Any:
        """Get a specific manager"""
        return self.managers.get(manager_type)

    # ==================== SCRAPING OPERATIONS ====================

    async def start_scraping(self,
                            platform: str = 'all',
                            query: str = None,
                            limit: int = 50,
                            filters: Dict = None) -> Dict:
        """
        Start scraping operation

        Args:
            platform: Platform ID or 'all' for all platforms
            query: Search query
            limit: Max results per platform
            filters: Additional filters (price, condition, etc.)

        Returns:
            Operation result
        """
        self.logger.info(f"Starting scraping", platform=platform, query=query)

        if platform == 'all':
            platforms = list(self.PLATFORMS.keys())
        else:
            platforms = [platform] if platform in self.PLATFORMS else []

        if not platforms:
            return {'success': False, 'error': f'Unknown platform: {platform}'}

        # Queue operations
        operation_id = f"scrape_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        for p in platforms:
            operation = {
                'id': f"{operation_id}_{p}",
                'type': 'scrape',
                'platform': p,
                'query': query,
                'limit': limit,
                'filters': filters or {},
                'priority': OperationPriority.NORMAL.value,
                'created_at': datetime.now().isoformat()
            }

            with self.operation_lock:
                self.operation_queue.append(operation)

        self.logger.info(f"Queued {len(platforms)} scraping operations")

        return {
            'success': True,
            'operation_id': operation_id,
            'platforms': platforms,
            'queued': len(platforms)
        }

    async def stop_scraping(self, platform: str = 'all') -> Dict:
        """Stop scraping operations"""
        scraping_manager = self.get_manager(ManagerType.SCRAPING)
        if scraping_manager:
            await scraping_manager.stop_all()

        return {'success': True, 'message': f'Scraping stopped for {platform}'}

    # ==================== TELEGRAM OPERATIONS ====================

    async def _initialize_telegram(self):
        """Initialize Telegram bot"""
        if not self.telegram_token:
            self.logger.warning("Telegram bot token not configured")
            return

        try:
            from agents.telegram_bot import TelegramBot
            self.telegram_bot = TelegramBot(
                token=self.telegram_token,
                admin_chat_id=self.admin_chat_id,
                ceo_agent=self
            )
            await self.telegram_bot.start()
            self.logger.info("Telegram bot initialized")
        except ImportError:
            self.logger.warning("Telegram bot module not available")
        except Exception as e:
            self.logger.error("Telegram init failed", exception=str(e))

    async def send_telegram_notification(self,
                                         message: str,
                                         priority: str = 'normal',
                                         chat_id: str = None) -> bool:
        """
        Send Telegram notification

        Args:
            message: Message text
            priority: 'critical', 'high', 'normal', 'low'
            chat_id: Optional specific chat ID
        """
        if not self.telegram_bot:
            return False

        emoji = {
            'critical': '🚨',
            'high': '⚠️',
            'normal': 'ℹ️',
            'low': '📝'
        }

        formatted = f"{emoji.get(priority, 'ℹ️')} {message}"

        try:
            await self.telegram_bot.send_message(
                chat_id or self.admin_chat_id,
                formatted
            )
            return True
        except Exception as e:
            self.logger.error("Telegram notification failed", exception=str(e))
            return False

    # ==================== HEALTH & MONITORING ====================

    async def _health_check(self) -> Dict:
        """Check health of all systems"""
        health = {
            'ceo': 'healthy',
            'managers': {},
            'platforms': {},
            'database': 'unknown',
            'telegram': 'disconnected',
            'timestamp': datetime.now().isoformat()
        }

        # Check managers
        for manager_type, manager in self.managers.items():
            try:
                status = manager.get_status() if hasattr(manager, 'get_status') else {'status': 'unknown'}
                health['managers'][manager_type.value] = status.get('status', 'unknown')
            except:
                health['managers'][manager_type.value] = 'error'

        # Check Telegram
        if self.telegram_bot:
            health['telegram'] = 'connected'

        return health

    async def _self_healing_check(self):
        """Check for failures and attempt auto-repair"""
        for platform, failures in self.consecutive_failures.items():
            if failures >= self.max_consecutive_failures:
                self.logger.warning(f"Auto-healing triggered for {platform}")

                # Attempt recovery
                await self._attempt_recovery(platform)

                # Notify admin
                await self.send_telegram_notification(
                    f"Self-healing triggered for {platform} after {failures} failures",
                    priority='high'
                )

    async def _attempt_recovery(self, platform: str):
        """Attempt to recover a failing platform"""
        try:
            # 1. Clear cached data
            # 2. Rotate proxy/user agent
            # 3. Refresh session
            # 4. Reset consecutive failures
            self.consecutive_failures[platform] = 0

            self.logger.info(f"Recovery attempted for {platform}")
        except Exception as e:
            self.logger.error(f"Recovery failed for {platform}", exception=str(e))

    # ==================== FAVORITES & CLEANUP ====================

    async def _check_favorites_availability(self):
        """Check if favorited products are still available"""
        # This would call the SalesManager to check favorites
        pass

    async def _database_cleanup(self):
        """Clean up database - remove non-favorites older than 7 days"""
        # This would call the AccountingManager for cleanup
        pass

    # ==================== MESSAGING ====================

    async def _check_incoming_messages(self):
        """Check for incoming messages across all platforms"""
        communication_manager = self.get_manager(ManagerType.COMMUNICATION)
        if communication_manager:
            await communication_manager.check_all_messages()

    # ==================== OPERATIONS QUEUE ====================

    async def _process_operation_queue(self) -> int:
        """Process queued operations"""
        processed = 0

        with self.operation_lock:
            # Sort by priority
            self.operation_queue.sort(key=lambda x: x.get('priority', 3))

            # Process up to 10 operations per cycle
            operations_to_process = self.operation_queue[:10]
            self.operation_queue = self.operation_queue[10:]

        for operation in operations_to_process:
            try:
                await self._execute_operation(operation)
                processed += 1
            except Exception as e:
                self.logger.error(f"Operation failed: {operation.get('id')}", exception=str(e))

        return processed

    async def _execute_operation(self, operation: Dict):
        """Execute a single operation"""
        op_type = operation.get('type')

        if op_type == 'scrape':
            scraping_manager = self.get_manager(ManagerType.SCRAPING)
            if scraping_manager:
                result = await scraping_manager.execute_scrape(
                    platform=operation.get('platform'),
                    query=operation.get('query'),
                    limit=operation.get('limit', 50),
                    filters=operation.get('filters', {})
                )

                # Update metrics
                if result.get('success'):
                    self.metrics.successful_scrapes += 1
                    self.metrics.products_found += result.get('count', 0)
                else:
                    self.metrics.failed_scrapes += 1
                    platform = operation.get('platform')
                    self.consecutive_failures[platform] = self.consecutive_failures.get(platform, 0) + 1

                self.metrics.total_scrapes += 1

    # ==================== STATE MANAGEMENT ====================

    async def _load_system_state(self):
        """Load system state from database"""
        # Load metrics, scheduled tasks, etc.
        pass

    async def _save_system_state(self):
        """Save system state to database"""
        # Save metrics, scheduled tasks, etc.
        self._save_state()

    # ==================== SCHEDULING ====================

    def _schedule_periodic_tasks(self):
        """Schedule periodic tasks"""
        self.scheduled_tasks = {
            'daily_report': {
                'interval': 86400,  # 24 hours
                'last_run': None,
                'callback': self._generate_daily_report
            },
            'favorites_check': {
                'interval': 3600,  # 1 hour
                'last_run': None,
                'callback': self._check_favorites_availability
            },
            'database_cleanup': {
                'interval': 86400,  # 24 hours
                'last_run': None,
                'callback': self._database_cleanup
            }
        }

    # ==================== REPORTING ====================

    async def _generate_daily_report(self) -> Dict:
        """Generate daily performance report"""
        report = {
            'date': datetime.now().strftime('%Y-%m-%d'),
            'uptime_hours': self.metrics.uptime_hours,
            'scraping': {
                'total': self.metrics.total_scrapes,
                'successful': self.metrics.successful_scrapes,
                'failed': self.metrics.failed_scrapes,
                'success_rate': (self.metrics.successful_scrapes / max(1, self.metrics.total_scrapes)) * 100
            },
            'products': {
                'found': self.metrics.products_found,
                'favorited': self.metrics.products_favorited,
                'sold': self.metrics.products_sold
            },
            'communication': {
                'messages_sent': self.metrics.messages_sent,
                'messages_received': self.metrics.messages_received
            },
            'logistics': {
                'shipments': self.metrics.shipments_created
            },
            'accounting': {
                'invoices': self.metrics.invoices_archived
            }
        }

        # Send via Telegram
        await self.send_telegram_notification(
            f"📊 *Daily Report - {report['date']}*\n"
            f"Uptime: {report['uptime_hours']:.1f}h\n"
            f"Scrapes: {report['scraping']['total']} ({report['scraping']['success_rate']:.1f}% success)\n"
            f"Products Found: {report['products']['found']}\n"
            f"Products Sold: {report['products']['sold']}",
            priority='normal'
        )

        return report

    def _get_metrics_summary(self) -> Dict:
        """Get current metrics summary"""
        return {
            'uptime_hours': round(self.metrics.uptime_hours, 2),
            'total_scrapes': self.metrics.total_scrapes,
            'products_found': self.metrics.products_found,
            'success_rate': round((self.metrics.successful_scrapes / max(1, self.metrics.total_scrapes)) * 100, 1)
        }

    async def _notify_error(self, title: str, error: str):
        """Notify admin of critical error"""
        await self.send_telegram_notification(
            f"*{title}*\n{error}",
            priority='critical'
        )

    # ==================== PUBLIC API ====================

    def get_system_status(self) -> Dict:
        """Get complete system status"""
        return {
            'status': self.status.value,
            'uptime_hours': round(self.metrics.uptime_hours, 2),
            'metrics': self._get_metrics_summary(),
            'managers': {k.value: v.status for k, v in self.manager_status.items()},
            'platforms_count': len(self.PLATFORMS),
            'operation_queue_size': len(self.operation_queue),
            'telegram_connected': self.telegram_bot is not None,
            'healing_enabled': self.healing_enabled,
            'last_run': self.last_run.isoformat() if self.last_run else None
        }

    def get_platform_list(self) -> List[Dict]:
        """Get list of all supported platforms"""
        return [
            {'id': k, **v}
            for k, v in self.PLATFORMS.items()
        ]


# ==================== TELEGRAM COMMAND HANDLERS ====================

class CEOCommandHandler:
    """Handler for Telegram commands"""

    def __init__(self, ceo_agent: CEOAgent):
        self.ceo = ceo_agent

    async def handle_status(self) -> str:
        """Handle /status command"""
        status = self.ceo.get_system_status()
        return (
            f"🤖 *TATANGA Status*\n\n"
            f"Status: {status['status']}\n"
            f"Uptime: {status['uptime_hours']}h\n"
            f"Platforms: {status['platforms_count']}\n"
            f"Queue Size: {status['operation_queue_size']}\n"
            f"Telegram: {'✅' if status['telegram_connected'] else '❌'}\n\n"
            f"*Metrics:*\n"
            f"Total Scrapes: {status['metrics']['total_scrapes']}\n"
            f"Products Found: {status['metrics']['products_found']}\n"
            f"Success Rate: {status['metrics']['success_rate']}%"
        )

    async def handle_scrape(self, platform: str = 'all', query: str = None) -> str:
        """Handle /scrape command"""
        result = await self.ceo.start_scraping(platform, query)
        if result['success']:
            return f"✅ Scraping started for {len(result['platforms'])} platform(s)"
        return f"❌ {result.get('error', 'Unknown error')}"

    async def handle_stop(self) -> str:
        """Handle /stop command"""
        await self.ceo.stop_scraping('all')
        return "⏹️ All scraping operations stopped"

    async def handle_report(self, period: str = 'daily') -> str:
        """Handle /report command"""
        report = await self.ceo._generate_daily_report()
        return f"📊 Report generated for {report['date']}"

    async def handle_platforms(self) -> str:
        """Handle /platforms command"""
        platforms = self.ceo.get_platform_list()

        by_platform = {}
        for p in platforms:
            name = p['platform']
            if name not in by_platform:
                by_platform[name] = []
            by_platform[name].append(p['country'])

        lines = ["📦 *Supported Platforms:*\n"]
        for platform, countries in by_platform.items():
            lines.append(f"• {platform.upper()}: {', '.join(countries)}")

        return '\n'.join(lines)

    async def handle_health(self) -> str:
        """Handle /health command"""
        health = await self.ceo._health_check()

        lines = ["🏥 *System Health:*\n"]
        lines.append(f"CEO: {health['ceo']}")
        lines.append(f"Telegram: {health['telegram']}")

        lines.append("\n*Managers:*")
        for name, status in health['managers'].items():
            emoji = '✅' if status == 'healthy' else '❌'
            lines.append(f"  {emoji} {name}: {status}")

        return '\n'.join(lines)


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 70)
    print("🎩 CEO AGENT - TATANGA ENTERPRISE")
    print("=" * 70)

    async def test():
        # Create CEO Agent
        ceo = CEOAgent()

        print(f"\nPlatforms supported: {len(ceo.PLATFORMS)}")
        print(f"\nSystem status:")
        status = ceo.get_system_status()
        for key, value in status.items():
            print(f"  {key}: {value}")

        print(f"\nPlatform breakdown:")
        platforms = ceo.get_platform_list()
        by_type = {}
        for p in platforms:
            ptype = p['platform']
            if ptype not in by_type:
                by_type[ptype] = 0
            by_type[ptype] += 1

        for ptype, count in by_type.items():
            print(f"  {ptype}: {count} countries")

        print("\n✅ CEO Agent test complete!")

    asyncio.run(test())
    print("=" * 70)
