#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OUTBOX AGENT - Outgoing Messages Queue Handler
24/7 Message sending with rate limiting and approval system

Features:
- Manages outgoing message queue
- Platform-specific rate limiting
- Spam protection
- Telegram approval workflow
- Auto-translation before sending
- Retry mechanism for failed sends

Author: TATANGA Team
Version: 1.0
"""

import sys
import json
import sqlite3
import asyncio
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents.base_agent import BaseAgent, AgentConfig
from integrations.smart_translator import SmartTranslator


@dataclass
class OutgoingMessage:
    """Represents an outgoing platform message"""
    id: int
    platform: str
    recipient_id: str
    recipient_name: str
    message: str
    conversation_id: Optional[str] = None
    product_id: Optional[int] = None
    priority: str = 'normal'
    status: str = 'pending'
    requires_approval: bool = True
    approved: bool = False
    sent_at: Optional[datetime] = None
    error_message: Optional[str] = None


@dataclass
class RateLimitConfig:
    """Rate limit configuration for a platform"""
    platform: str
    max_per_hour: int = 10
    max_per_day: int = 50
    min_interval_seconds: int = 60


class OutboxAgent(BaseAgent):
    """
    24/7 Outgoing Message Queue Handler

    Manages outgoing messages with:
    - Rate limiting per platform
    - Telegram approval workflow
    - Auto-translation
    - Retry mechanism

    Usage:
        agent = OutboxAgent(interval_seconds=30)
        agent.start()

        # Queue a message
        agent.queue_message(
            platform='vinted_de',
            recipient_id='user123',
            message='Noch zu haben?'
        )

        # Stop agent
        agent.stop()
    """

    # Platform rate limits
    RATE_LIMITS: Dict[str, RateLimitConfig] = {
        'vinted_de': RateLimitConfig('vinted_de', max_per_hour=10, max_per_day=50, min_interval_seconds=60),
        'vinted_fr': RateLimitConfig('vinted_fr', max_per_hour=10, max_per_day=50, min_interval_seconds=60),
        'vinted_uk': RateLimitConfig('vinted_uk', max_per_hour=10, max_per_day=50, min_interval_seconds=60),
        'ebay_de': RateLimitConfig('ebay_de', max_per_hour=15, max_per_day=100, min_interval_seconds=30),
        'ebay_uk': RateLimitConfig('ebay_uk', max_per_hour=15, max_per_day=100, min_interval_seconds=30),
        'kleinanzeigen': RateLimitConfig('kleinanzeigen', max_per_hour=8, max_per_day=30, min_interval_seconds=120),
        'tradera': RateLimitConfig('tradera', max_per_hour=10, max_per_day=40, min_interval_seconds=90),
        'leboncoin': RateLimitConfig('leboncoin', max_per_hour=5, max_per_day=20, min_interval_seconds=180),
        'willhaben': RateLimitConfig('willhaben', max_per_hour=8, max_per_day=30, min_interval_seconds=120),
    }

    # Default messages by language
    DEFAULT_MESSAGES = {
        'de': "Hallo! Ist dieser Artikel noch verfügbar?",
        'en': "Hi! Is this item still available?",
        'fr': "Bonjour ! Cet article est-il toujours disponible ?",
        'sv': "Hej! Är denna artikel fortfarande tillgänglig?",
        'no': "Hei! Er denne varen fortsatt tilgjengelig?",
        'da': "Hej! Er denne vare stadig tilgængelig?",
        'fi': "Hei! Onko tämä tuote vielä saatavilla?",
    }

    def __init__(self, interval_seconds: int = 30):
        """
        Initialize Outbox Agent

        Args:
            interval_seconds: How often to process queue
        """
        config = AgentConfig(
            name="outbox",
            interval_seconds=interval_seconds,
            max_retries=3,
            retry_delay_seconds=5
        )
        super().__init__(config)

        # Initialize translator
        try:
            self.translator = SmartTranslator()
        except Exception as e:
            self.logger.warning(f"Translator init failed: {e}")
            self.translator = None

        # Message queue database (shared with inbox)
        self.queue_db = Path(__file__).parent.parent / 'storage' / 'message_queue.db'
        self._init_queue_db()

        # Send history for rate limiting
        self.send_history: Dict[str, List[datetime]] = {}

        # Stats
        self.messages_sent = 0
        self.messages_failed = 0
        self.messages_awaiting_approval = 0

    def _init_queue_db(self):
        """Initialize message queue database"""
        self.queue_db.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        # Message queue table (if not exists from inbox_agent)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS message_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                direction TEXT NOT NULL,
                platform TEXT NOT NULL,
                conversation_id TEXT,
                product_id INTEGER,
                sender TEXT,
                recipient TEXT,
                message_original TEXT,
                message_translated TEXT,
                language TEXT,
                status TEXT DEFAULT 'pending',
                priority TEXT DEFAULT 'normal',
                risk_score INTEGER DEFAULT 50,
                sentiment TEXT DEFAULT 'neutral',
                suggested_reply TEXT,
                requires_approval INTEGER DEFAULT 0,
                approved_at DATETIME,
                sent_at DATETIME,
                notified_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                error_message TEXT,
                retry_count INTEGER DEFAULT 0
            )
        """)

        # Send history for rate limiting
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS send_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                recipient TEXT,
                message_id INTEGER,
                sent_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Index for rate limit queries
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_send_history_platform_time
            ON send_history(platform, sent_at)
        """)

        conn.commit()
        conn.close()

    async def setup(self):
        """Setup hook - called before first process"""
        self.logger.info("Outbox Agent starting up")

        # Load recent send history for rate limiting
        self._load_send_history()

        self.logger.info(f"Rate limits configured for {len(self.RATE_LIMITS)} platforms")

    def _load_send_history(self):
        """Load recent send history from database"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        # Get sends from last 24 hours
        cursor.execute("""
            SELECT platform, sent_at
            FROM send_history
            WHERE sent_at > datetime('now', '-24 hours')
            ORDER BY sent_at
        """)

        for row in cursor.fetchall():
            platform = row[0]
            sent_at = datetime.fromisoformat(row[1]) if row[1] else datetime.now()

            if platform not in self.send_history:
                self.send_history[platform] = []
            self.send_history[platform].append(sent_at)

        conn.close()
        self.logger.info(f"Loaded send history: {sum(len(v) for v in self.send_history.values())} recent sends")

    async def process(self) -> Dict[str, Any]:
        """
        Main processing loop - send approved messages respecting rate limits

        Returns:
            Processing result summary
        """
        results = {
            'sent': 0,
            'skipped_rate_limit': 0,
            'skipped_pending_approval': 0,
            'failed': 0
        }

        # Get approved messages ready to send
        messages = self._get_ready_messages()

        if not messages:
            return {'status': 'idle', 'message': 'No messages ready to send'}

        self.logger.info(f"Processing {len(messages)} outgoing messages")

        for msg in messages:
            platform = msg['platform']

            # Check rate limit
            if not self._can_send(platform):
                self.logger.warning(f"Rate limit reached for {platform}")
                results['skipped_rate_limit'] += 1
                continue

            # Check approval (if required)
            if msg['requires_approval'] and not msg.get('approved'):
                results['skipped_pending_approval'] += 1
                continue

            try:
                # Send message
                success = await self._send_message(msg)

                if success:
                    self._mark_sent(msg['id'])
                    self._record_send(platform, msg.get('recipient'))
                    results['sent'] += 1
                    self.messages_sent += 1
                else:
                    results['failed'] += 1
                    self.messages_failed += 1

            except Exception as e:
                self.logger.error(f"Send error: {e}")
                self._mark_failed(msg['id'], str(e))
                results['failed'] += 1
                self.messages_failed += 1

        results['total_sent'] = self.messages_sent
        results['total_failed'] = self.messages_failed

        return results

    def _can_send(self, platform: str) -> bool:
        """
        Check if we can send to platform (rate limit check)

        Args:
            platform: Target platform

        Returns:
            True if within rate limits
        """
        config = self.RATE_LIMITS.get(platform)
        if not config:
            return True  # No limit configured

        now = datetime.now()
        history = self.send_history.get(platform, [])

        # Clean old entries
        history = [t for t in history if t > now - timedelta(hours=24)]
        self.send_history[platform] = history

        # Check hourly limit
        last_hour = [t for t in history if t > now - timedelta(hours=1)]
        if len(last_hour) >= config.max_per_hour:
            return False

        # Check daily limit
        if len(history) >= config.max_per_day:
            return False

        # Check minimum interval
        if history:
            last_send = max(history)
            if (now - last_send).total_seconds() < config.min_interval_seconds:
                return False

        return True

    def _get_rate_limit_status(self, platform: str) -> Dict:
        """Get rate limit status for a platform"""
        config = self.RATE_LIMITS.get(platform)
        if not config:
            return {'limited': False, 'message': 'No limits configured'}

        now = datetime.now()
        history = self.send_history.get(platform, [])

        # Clean and count
        history = [t for t in history if t > now - timedelta(hours=24)]
        last_hour = [t for t in history if t > now - timedelta(hours=1)]

        return {
            'platform': platform,
            'hourly_used': len(last_hour),
            'hourly_limit': config.max_per_hour,
            'daily_used': len(history),
            'daily_limit': config.max_per_day,
            'min_interval_seconds': config.min_interval_seconds,
            'can_send': self._can_send(platform)
        }

    async def _send_message(self, msg: Dict) -> bool:
        """
        Send a message to platform

        Args:
            msg: Message data

        Returns:
            True if sent successfully
        """
        platform = msg['platform']
        recipient = msg['recipient']
        message = msg.get('message_translated') or msg['message_original']

        self.logger.info(f"Sending message to {platform}/{recipient}")

        # TODO: Implement actual platform sending
        # For now, simulate success
        await asyncio.sleep(1)

        self.logger.success(f"Message sent: {platform}/{recipient}")
        return True

    def _get_ready_messages(self) -> List[Dict]:
        """Get messages ready to send (approved or not requiring approval)"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, direction, platform, conversation_id, product_id,
                   recipient, message_original, message_translated, language,
                   requires_approval, approved_at, retry_count
            FROM message_queue
            WHERE direction = 'outbox'
            AND status IN ('pending', 'approved')
            AND (requires_approval = 0 OR approved_at IS NOT NULL)
            ORDER BY
                CASE priority
                    WHEN 'urgent' THEN 1
                    WHEN 'high' THEN 2
                    WHEN 'normal' THEN 3
                    WHEN 'low' THEN 4
                END,
                created_at
            LIMIT 10
        """)

        rows = cursor.fetchall()
        conn.close()

        return [
            {
                'id': row[0],
                'direction': row[1],
                'platform': row[2],
                'conversation_id': row[3],
                'product_id': row[4],
                'recipient': row[5],
                'message_original': row[6],
                'message_translated': row[7],
                'language': row[8],
                'requires_approval': row[9],
                'approved': row[10] is not None,
                'retry_count': row[11] or 0
            }
            for row in rows
        ]

    def _mark_sent(self, msg_id: int):
        """Mark message as sent"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE message_queue
            SET status = 'sent', sent_at = datetime('now')
            WHERE id = ?
        """, (msg_id,))

        conn.commit()
        conn.close()

    def _mark_failed(self, msg_id: int, error: str):
        """Mark message as failed"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE message_queue
            SET status = 'failed',
                error_message = ?,
                retry_count = retry_count + 1
            WHERE id = ?
        """, (error, msg_id))

        conn.commit()
        conn.close()

    def _record_send(self, platform: str, recipient: str = None):
        """Record a send for rate limiting"""
        now = datetime.now()

        # Update in-memory history
        if platform not in self.send_history:
            self.send_history[platform] = []
        self.send_history[platform].append(now)

        # Record in database
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO send_history (platform, recipient, sent_at)
            VALUES (?, ?, ?)
        """, (platform, recipient, now.isoformat()))

        conn.commit()
        conn.close()

    # ========================================================================
    # PUBLIC API - Queue Messages
    # ========================================================================

    def queue_message(
        self,
        platform: str,
        recipient_id: str,
        message: str,
        conversation_id: str = None,
        product_id: int = None,
        priority: str = 'normal',
        requires_approval: bool = True,
        translate_to: str = None
    ) -> int:
        """
        Queue an outgoing message

        Args:
            platform: Target platform
            recipient_id: Recipient ID/username
            message: Message text
            conversation_id: Optional conversation ID
            product_id: Optional related product ID
            priority: Message priority (low, normal, high, urgent)
            requires_approval: Whether Telegram approval is needed
            translate_to: Target language for translation

        Returns:
            Queue item ID
        """
        # Translate if needed
        message_translated = message
        if translate_to and self.translator:
            try:
                message_translated = self.translator.translate(message, translate_to)
            except Exception as e:
                self.logger.warning(f"Translation failed: {e}")

        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO message_queue
            (direction, platform, recipient, message_original, message_translated,
             language, conversation_id, product_id, priority, requires_approval)
            VALUES ('outbox', ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            platform, recipient_id, message, message_translated,
            translate_to, conversation_id, product_id, priority,
            1 if requires_approval else 0
        ))

        item_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Queued outgoing message: {platform}/{recipient_id} (ID: {item_id})")

        # Request Telegram approval if needed
        if requires_approval:
            self._request_approval(item_id, platform, recipient_id, message_translated or message)

        return item_id

    def _request_approval(self, msg_id: int, platform: str, recipient: str, message: str):
        """Request Telegram approval for a message"""
        try:
            # Import telegram bot
            from integrations.telegram_bot import TatangaTelegramBot

            bot = TatangaTelegramBot()

            notification = (
                f"📤 *GİDEN MESAJ ONAYI*\n\n"
                f"📱 Platform: `{platform}`\n"
                f"👤 Alıcı: {recipient}\n\n"
                f"💬 *Mesaj:*\n_{message[:300]}_\n\n"
                f"Bu mesajı göndermek için onay gerekiyor."
            )

            # Note: In real implementation, this would use inline keyboard buttons
            asyncio.create_task(bot.send_notification(notification))

            self.logger.info(f"Approval requested for message {msg_id}")

        except Exception as e:
            self.logger.error(f"Approval request failed: {e}")

    def approve_message(self, msg_id: int) -> bool:
        """
        Approve a message for sending

        Args:
            msg_id: Message ID to approve

        Returns:
            True if approved successfully
        """
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE message_queue
            SET status = 'approved', approved_at = datetime('now')
            WHERE id = ? AND direction = 'outbox'
        """, (msg_id,))

        affected = cursor.rowcount
        conn.commit()
        conn.close()

        if affected > 0:
            self.logger.info(f"Message {msg_id} approved")
            return True

        return False

    def reject_message(self, msg_id: int, reason: str = None) -> bool:
        """
        Reject a message (don't send)

        Args:
            msg_id: Message ID to reject
            reason: Optional rejection reason

        Returns:
            True if rejected successfully
        """
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE message_queue
            SET status = 'rejected', error_message = ?
            WHERE id = ? AND direction = 'outbox'
        """, (reason or 'Rejected by user', msg_id))

        affected = cursor.rowcount
        conn.commit()
        conn.close()

        if affected > 0:
            self.logger.info(f"Message {msg_id} rejected")
            return True

        return False

    def get_pending_approvals(self) -> List[Dict]:
        """Get messages waiting for approval"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, platform, recipient, message_original, message_translated,
                   priority, created_at
            FROM message_queue
            WHERE direction = 'outbox'
            AND status = 'pending'
            AND requires_approval = 1
            AND approved_at IS NULL
            ORDER BY created_at
        """)

        rows = cursor.fetchall()
        conn.close()

        return [
            {
                'id': row[0],
                'platform': row[1],
                'recipient': row[2],
                'message_original': row[3],
                'message_translated': row[4],
                'priority': row[5],
                'created_at': row[6]
            }
            for row in rows
        ]

    def get_queue_stats(self) -> Dict:
        """Get queue statistics"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT status, COUNT(*) as count
            FROM message_queue
            WHERE direction = 'outbox'
            GROUP BY status
        """)

        stats = {row[0]: row[1] for row in cursor.fetchall()}
        conn.close()

        return {
            'pending': stats.get('pending', 0),
            'approved': stats.get('approved', 0),
            'sent': stats.get('sent', 0),
            'failed': stats.get('failed', 0),
            'rejected': stats.get('rejected', 0),
            'total_sent_session': self.messages_sent,
            'total_failed_session': self.messages_failed
        }


# Test
if __name__ == "__main__":
    print("=" * 60)
    print("OUTBOX AGENT - TEST")
    print("=" * 60)
    print()

    # Create agent
    agent = OutboxAgent(interval_seconds=30)

    # Queue some test messages
    print("Queueing test messages...")

    agent.queue_message(
        platform='vinted_de',
        recipient_id='TestUser1',
        message='Hallo! Ist dieser Artikel noch verfügbar?',
        requires_approval=False  # Auto-send
    )

    agent.queue_message(
        platform='ebay_de',
        recipient_id='TestUser2',
        message='Hi! Is this still available?',
        translate_to='de',
        requires_approval=True  # Needs approval
    )

    print()
    print("Queue stats:")
    stats = agent.get_queue_stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")

    print()
    print("Rate limit status:")
    for platform in ['vinted_de', 'ebay_de', 'kleinanzeigen']:
        status = agent._get_rate_limit_status(platform)
        print(f"  {platform}: {status['hourly_used']}/{status['hourly_limit']} hourly, can_send={status['can_send']}")

    print()
    print("Pending approvals:")
    for approval in agent.get_pending_approvals():
        print(f"  [{approval['id']}] {approval['platform']} -> {approval['recipient']}")

    print()
    print("=" * 60)
    print("To run as background service: agent.start()")
    print("=" * 60)