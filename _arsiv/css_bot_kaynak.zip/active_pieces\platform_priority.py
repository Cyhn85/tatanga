#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Platform Priority Algorithm
Smart scoring system to determine platform implementation order
"""

import json
import sys
import io
from pathlib import Path
from typing import Dict, List, Tuple

# Fix Windows console encoding for emojis
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')


class PlatformPriorityEngine:
    """
    Smart priority scoring engine for platform implementation

    Scoring criteria (weighted):
    - Popularity Score (25%): Market share and user base
    - API Quality (20%): Official API = best, None = worst
    - Speed (15%): Fast API > Medium Selenium > Slow Selenium
    - Reliability (20%): Platform stability and success rate
    - Duplicate Risk (10%): Inverted - Lower risk = higher score
    - Upload Capability (20%): IC LOGISTIK support
    """

    WEIGHTS = {
        'popularity': 0.25,
        'api_quality': 0.20,
        'speed': 0.15,
        'reliability': 0.20,
        'duplicate_risk': 0.10,
        'upload_capability': 0.20
    }

    def __init__(self, capabilities_file: str = None):
        if capabilities_file is None:
            capabilities_file = Path(__file__).parent / 'config' / 'platform_capabilities.json'

        with open(capabilities_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            self.platforms = data['platforms']
            self.metadata = data['metadata']

    def _score_api_quality(self, platform_data: Dict) -> float:
        """
        Score API quality
        - Official API with OAuth: 100
        - Official API without OAuth: 90
        - Unofficial API: 50
        - No API (Selenium required): 20
        """
        if not platform_data.get('api_available', False):
            return 20.0

        api_type = platform_data.get('api_type', 'none')
        if api_type == 'official':
            if platform_data.get('oauth_required', False):
                return 100.0
            return 90.0
        elif api_type == 'unofficial':
            return 50.0
        else:
            return 20.0

    def _score_speed(self, platform_data: Dict) -> float:
        """
        Score platform speed
        - fast: 100 (API-based)
        - medium: 60 (Selenium medium complexity)
        - slow: 30 (Selenium high complexity + CAPTCHA)
        """
        speed = platform_data.get('speed', 'medium')
        speed_map = {
            'fast': 100.0,
            'medium': 60.0,
            'slow': 30.0
        }
        return speed_map.get(speed, 60.0)

    def _score_duplicate_risk(self, platform_data: Dict) -> float:
        """
        Score duplicate risk (INVERTED - lower risk = higher score)
        - low: 100
        - medium: 60
        - high: 30
        """
        risk = platform_data.get('duplicate_risk', 'medium')
        risk_map = {
            'low': 100.0,
            'medium': 60.0,
            'high': 30.0
        }
        return risk_map.get(risk, 60.0)

    def _score_upload_capability(self, platform_data: Dict) -> float:
        """
        Score upload capability (IC LOGISTIK)
        - IC LOGISTIK available: 100
        - IC LOGISTIK not available: 0
        """
        return 100.0 if platform_data.get('ic_logistik', False) else 0.0

    def calculate_priority_score(self, platform_key: str) -> Tuple[float, Dict[str, float]]:
        """
        Calculate weighted priority score for a platform

        Returns:
            (total_score, score_breakdown)
        """
        platform_data = self.platforms[platform_key]

        # Individual scores (0-100)
        scores = {
            'popularity': float(platform_data.get('popularity_score', 50)),
            'api_quality': self._score_api_quality(platform_data),
            'speed': self._score_speed(platform_data),
            'reliability': float(platform_data.get('reliability_score', 50)),
            'duplicate_risk': self._score_duplicate_risk(platform_data),
            'upload_capability': self._score_upload_capability(platform_data)
        }

        # Calculate weighted total
        total_score = sum(scores[key] * self.WEIGHTS[key] for key in scores)

        return total_score, scores

    def generate_priority_list(self, include_implemented: bool = False) -> List[Dict]:
        """
        Generate sorted priority list for all platforms

        Args:
            include_implemented: Include already implemented platforms

        Returns:
            List of platforms sorted by priority (highest first)
        """
        priority_list = []

        for platform_key, platform_data in self.platforms.items():
            # Check if already implemented
            is_implemented = '✅ ALREADY IMPLEMENTED' in platform_data.get('notes', '')

            if not include_implemented and is_implemented:
                continue

            score, breakdown = self.calculate_priority_score(platform_key)

            priority_list.append({
                'platform_key': platform_key,
                'name': platform_data['name'],
                'country': platform_data['country'],
                'priority_score': round(score, 2),
                'score_breakdown': {k: round(v, 1) for k, v in breakdown.items()},
                'api_available': platform_data.get('api_available', False),
                'selenium_complexity': platform_data.get('selenium_complexity', 'N/A'),
                'duplicate_risk': platform_data.get('duplicate_risk', 'unknown'),
                'is_implemented': is_implemented,
                'dis_logistik': platform_data.get('dis_logistik', False),
                'ic_logistik': platform_data.get('ic_logistik', False),
                'notes': platform_data.get('notes', '')
            })

        # Sort by priority score (descending)
        priority_list.sort(key=lambda x: x['priority_score'], reverse=True)

        # Add rank
        for i, item in enumerate(priority_list, 1):
            item['rank'] = i

        return priority_list

    def print_priority_report(self, include_implemented: bool = False):
        """
        Print human-readable priority report
        """
        priority_list = self.generate_priority_list(include_implemented)

        print("\n" + "="*100)
        print("TATANGA - PLATFORM IMPLEMENTATION PRIORITY REPORT")
        print("="*100)
        print(f"\nTotal Platforms Analyzed: {len(self.platforms)}")
        print(f"Platforms in Report: {len(priority_list)}")
        print(f"\nScoring Weights:")
        for key, weight in self.WEIGHTS.items():
            print(f"  - {key.replace('_', ' ').title()}: {weight*100}%")
        print("\n" + "="*100)

        for item in priority_list:
            print(f"\nRANK #{item['rank']}: {item['name']} ({item['platform_key']})")
            print(f"  Priority Score: {item['priority_score']}/100")
            print(f"  Country: {item['country']}")

            # Status
            status = "✅ IMPLEMENTED" if item['is_implemented'] else "⏳ PENDING"
            print(f"  Status: {status}")

            # Capabilities
            dis = "✓" if item['dis_logistik'] else "✗"
            ic = "✓" if item['ic_logistik'] else "✗"
            print(f"  DIS LOGISTIK: {dis} | IC LOGISTIK: {ic}")

            # API Info
            if item['api_available']:
                print(f"  API: ✓ Available | Selenium: Optional")
            else:
                complexity = item['selenium_complexity']
                print(f"  API: ✗ Not Available | Selenium: Required ({complexity} complexity)")

            # Score breakdown
            print(f"  Score Breakdown:")
            for key, value in item['score_breakdown'].items():
                bar_length = int(value / 5)  # 100 = 20 chars
                bar = "█" * bar_length + "░" * (20 - bar_length)
                print(f"    {key.replace('_', ' ').title():20s} [{bar}] {value}/100")

            # Duplicate risk
            risk_emoji = {"low": "🟢", "medium": "🟡", "high": "🔴"}.get(item['duplicate_risk'], "⚪")
            print(f"  Duplicate Risk: {risk_emoji} {item['duplicate_risk'].upper()}")

        print("\n" + "="*100)
        print("IMPLEMENTATION RECOMMENDATIONS")
        print("="*100)

        # Group by implementation strategy
        api_platforms = [p for p in priority_list if p['api_available'] and not p['is_implemented']]
        selenium_easy = [p for p in priority_list if not p['api_available'] and p['selenium_complexity'] in ['low', 'medium'] and not p['is_implemented']]
        selenium_hard = [p for p in priority_list if not p['api_available'] and p['selenium_complexity'] == 'high' and not p['is_implemented']]

        print(f"\n🚀 PHASE 1: API-Based Platforms (Fast Implementation)")
        print(f"   Count: {len(api_platforms)}")
        if api_platforms:
            for p in api_platforms[:5]:  # Top 5
                print(f"   #{p['rank']} {p['name']} (Score: {p['priority_score']})")

        print(f"\n🔧 PHASE 2: Selenium Medium Complexity")
        print(f"   Count: {len(selenium_easy)}")
        if selenium_easy:
            for p in selenium_easy[:5]:
                print(f"   #{p['rank']} {p['name']} (Score: {p['priority_score']})")

        print(f"\n⚠️  PHASE 3: Selenium High Complexity (Advanced)")
        print(f"   Count: {len(selenium_hard)}")
        if selenium_hard:
            for p in selenium_hard[:5]:
                print(f"   #{p['rank']} {p['name']} (Score: {p['priority_score']})")

        print("\n" + "="*100)

    def export_priority_json(self, output_file: str = None):
        """
        Export priority list to JSON file
        """
        if output_file is None:
            output_file = Path(__file__).parent / 'config' / 'platform_priority.json'

        priority_list = self.generate_priority_list(include_implemented=True)

        output_data = {
            'metadata': {
                'total_platforms': len(self.platforms),
                'scoring_weights': self.WEIGHTS,
                'generated_at': '2025-11-26'
            },
            'priority_list': priority_list
        }

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, indent=2, ensure_ascii=False)

        print(f"\n✓ Priority list exported to: {output_file}")
        return output_file


def main():
    """
    Generate and display platform priority report
    """
    engine = PlatformPriorityEngine()

    # Print priority report (exclude already implemented)
    engine.print_priority_report(include_implemented=False)

    # Export to JSON
    engine.export_priority_json()

    print("\n✓ Platform priority analysis complete!")


if __name__ == '__main__':
    main()
