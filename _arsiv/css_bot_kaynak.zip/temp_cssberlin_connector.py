"""
TATANGA V3 - CSS Berlin Connector
Publishes products to cssberlin.de via automation API
"""
import httpx
import asyncio
from typing import Optional, Dict, List, Any
from datetime import datetime

# CSS Berlin API Configuration
# Use localhost since both services run on the same server
import os
CSSBERLIN_API_URL = os.getenv("CSSBERLIN_API_URL", "http://localhost:8000")
CSSBERLIN_AUTOMATION_ENDPOINT = f"{CSSBERLIN_API_URL}/api/automation/process"

# Condition translations
CONDITION_MAPPING = {
    "new_with_tags": "Neu mit Etikett",
    "new_without_tags": "Neu ohne Etikett",
    "very_good": "Sehr gut",
    "good": "Gut",
    "satisfactory": "Befriedigend",
    "like_new": "Wie neu",
    "Neu mit Etikett": "Neu mit Etikett",
    "Neu ohne Etikett": "Neu ohne Etikett",
    "Sehr gut": "Sehr gut",
    "Gut": "Gut",
    "Befriedigend": "Befriedigend"
}

# Category mapping
CATEGORY_MAPPING = {
    "women": "Damen",
    "men": "Herren",
    "kids": "Kinder",
    "shoes": "Schuhe",
    "bags": "Taschen",
    "accessories": "Accessoires"
}


async def download_image(url: str, timeout: int = 30) -> Optional[bytes]:
    """Download image from URL and return bytes"""
    try:
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
            response = await client.get(url)
            if response.status_code == 200:
                return response.content
    except Exception as e:
        print(f"[CSSBERLIN] Error downloading image {url}: {e}")
    return None


async def download_images_from_urls(image_urls: List[str], max_images: int = 5) -> List[tuple]:
    """Download multiple images from URLs - returns list of (filename, bytes) tuples"""
    images = []

    for i, url in enumerate(image_urls[:max_images]):
        image_data = await download_image(url)
        if image_data:
            ext = "jpg"
            if ".png" in url.lower():
                ext = "png"
            elif ".webp" in url.lower():
                ext = "webp"

            filename = f"image_{i+1}.{ext}"
            images.append((filename, image_data))

    return images


def generate_seo_content(product_data: Dict) -> Dict:
    """Generate SEO optimized title and description"""
    brand = product_data.get("brand", "")
    name = product_data.get("title", product_data.get("name", "Produkt"))
    size = product_data.get("size", "")
    condition = product_data.get("condition", "")
    price = product_data.get("price", 0)
    category = product_data.get("category", "")

    # Generate SEO title
    parts = []
    if brand:
        parts.append(brand)
    parts.append(name)
    if size:
        parts.append(f"Groesse {size}")
    parts.append("Berlin")

    title = " ".join(parts)
    if len(title) > 70:
        title = title[:67] + "..."

    # Generate meta description
    meta_parts = []
    if brand:
        meta_parts.append(brand)
    meta_parts.append(name)
    if size:
        meta_parts.append(f"Groesse {size}")
    if condition:
        meta_parts.append(condition)
    meta_parts.append("in Berlin zu verkaufen.")
    if price:
        meta_parts.append(f"Preis: {price} EUR.")
    meta_parts.append("Jetzt bestellen!")

    meta_description = " ".join(meta_parts)

    # Generate full description
    full_lines = [
        f"Produkt: {name}" + (f" - {brand}" if brand else ""),
        "",
        "Produktdetails:",
    ]
    if brand:
        full_lines.append(f"- Marke: {brand}")
    full_lines.append(f"- Zustand: {condition or 'Gut'}")
    if size:
        full_lines.append(f"- Groesse: {size}")
    if price:
        full_lines.append(f"- Preis: {price} EUR")
    if category:
        full_lines.append(f"- Kategorie: {category}")

    full_lines.extend([
        "",
        "Lieferung:",
        "- Schnelle Lieferung in Berlin",
        "- Deutschlandweiter Versand",
        "- Sichere Verpackung",
        "",
        "Von CSS Berlin geprueft"
    ])

    full_description = "\n".join(full_lines)

    # Generate tags
    tags = ["Berlin", "CSS", "Second Hand", "Nachhaltig"]
    if brand:
        tags.append(brand)
    if category:
        tags.append(category)
    if size:
        tags.append(f"Groesse {size}")

    return {
        "title": title,
        "description_meta": meta_description,
        "description_full": full_description,
        "tags": list(set(tags))
    }


async def publish_to_cssberlin(
    product_data: Dict,
    images: Optional[List[str]] = None,
    download_images_flag: bool = True
) -> Dict[str, Any]:
    """
    Publish a product to CSS Berlin

    Args:
        product_data: Product information dict with keys:
            - title/name: Product name
            - brand: Brand name
            - category: Category (Damen, Herren, etc.)
            - condition: Product condition
            - size: Size
            - price: Price in EUR
            - description: Optional description
        images: List of image URLs or file paths
        download_images_flag: Whether to download images from URLs

    Returns:
        Dict with success status and product_id or error
    """
    try:
        # Prepare form data
        form_data = {}

        # Required fields
        form_data["name"] = product_data.get("title", product_data.get("name", "Produkt"))
        form_data["brand"] = product_data.get("brand", "Unbekannt")

        # Map category
        category = product_data.get("category", "")
        form_data["category"] = CATEGORY_MAPPING.get(category.lower(), category) if category else "Damen"

        # Map condition
        condition = product_data.get("condition", "good")
        form_data["condition"] = CONDITION_MAPPING.get(condition, condition) if condition else "Gut"

        form_data["size"] = str(product_data.get("size", "M"))
        form_data["price"] = str(float(product_data.get("price", 0)))

        # Generate SEO content
        seo = generate_seo_content(product_data)
        form_data["title"] = seo["title"]
        form_data["description"] = product_data.get("description", "")
        form_data["description_full"] = seo["description_full"]
        form_data["tags"] = str(seo["tags"])
        form_data["status"] = "pending"

        # Add subcategory if available
        if product_data.get("subcategory"):
            form_data["subcategory"] = product_data["subcategory"]

        # Handle images
        files = []
        if images and download_images_flag:
            downloaded = await download_images_from_urls(images)
            for filename, data in downloaded:
                files.append(("images", (filename, data, "image/jpeg")))

        print(f"[CSSBERLIN] Publishing: {form_data['name']} with {len(files)} images")

        # Send to CSS Berlin API
        async with httpx.AsyncClient(timeout=60) as client:
            if files:
                response = await client.post(
                    CSSBERLIN_AUTOMATION_ENDPOINT,
                    data=form_data,
                    files=files
                )
            else:
                response = await client.post(
                    CSSBERLIN_AUTOMATION_ENDPOINT,
                    data=form_data
                )

            result = response.json()

            if response.status_code == 200 and result.get("success"):
                product_id = result.get("product_id")
                listing_url = f"https://cssberlin.de/produkt/{product_id}"

                print(f"[CSSBERLIN] Success! Product ID: {product_id}")

                return {
                    "success": True,
                    "platform": "cssberlin",
                    "product_id": product_id,
                    "listing_url": listing_url,
                    "message": result.get("message", "Product published successfully")
                }
            else:
                error = result.get("error", "Unknown error")
                print(f"[CSSBERLIN] Failed: {error}")
                return {
                    "success": False,
                    "platform": "cssberlin",
                    "error": error
                }

    except Exception as e:
        print(f"[CSSBERLIN] Exception: {e}")
        return {
            "success": False,
            "platform": "cssberlin",
            "error": str(e)
        }


# Test function
async def test_connector():
    """Test the CSS Berlin connector"""
    test_product = {
        "title": "Nike Air Max 90 Sneaker",
        "brand": "Nike",
        "category": "shoes",
        "condition": "very_good",
        "size": "42",
        "price": 89.99,
        "description": "Sehr gepflegte Nike Air Max 90 in Weiss"
    }

    result = await publish_to_cssberlin(test_product, images=None)
    print(f"Test result: {result}")
    return result


if __name__ == "__main__":
    asyncio.run(test_connector())
