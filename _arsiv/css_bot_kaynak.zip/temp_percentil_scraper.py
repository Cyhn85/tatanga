"""
TATANGA V3 - Percentil Human Scraper
Insan-benzeri davranislarla Percentil'den urun kazima
Onemli: Retail/orijinal fiyat bilgisi arbitraj icin cok degerli!
"""
from .human_scraper_base import HumanScraper, LOG_DIR
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
from typing import List, Dict, Optional
import time
import random
import re


class PercentilScraper(HumanScraper):
    """Percentil icin insan-benzeri scraper"""

    BASE_URL = "https://www.percentil.de"

    # Metadata alanlari
    METADATA_FIELDS = {
        "size": "Groesse",
        "measurements": "Masse",
        "season": "Saison",
        "condition": "Zustand",
        "color": "Farbe",
    }

    # Fiyat alanlari - retail fiyat arbitraj icin onemli!
    PRICE_FIELDS = {
        "current_price": ".sale-price, .current-price",
        "original_price": ".original-price, .crossed-price",
        "discount_code": ".discount-code",
        "retail_value": ".retail-price",  # "Geschaetzter Neupreis 119,00EUR"
    }

    def __init__(self, headless: bool = True):
        super().__init__("percentil", headless)
        self.products_found = []
        self.visited_urls = set()

    def close_cookie_banner(self, selectors: list = None):
        """Percentil cookie banner'i kapat"""
        percentil_selectors = [
            "//button[contains(text(), 'COOKIES AKZEPTIEREN')]",
            "//button[contains(text(), 'Cookies akzeptieren')]",
            "//button[contains(text(), 'Alle akzeptieren')]",
            "#onetrust-accept-btn-handler",
            "button[id*='accept']",
            ".cookie-consent button",
            "[class*='CookieConsent'] button",
            "button[class*='accept-cookies']",
        ]
        return super().close_cookie_banner(percentil_selectors + (selectors or []))

    def close_newsletter_popup(self):
        """Newsletter popup kapat (scroll ile acilir)"""
        popup_selectors = [
            "//button[@aria-label='Close']",
            "//button[@aria-label='Schliessen']",
            ".modal-close",
            ".popup-close",
            "//button[contains(@class, 'close')]",
            "[data-testid='close-modal']",
            ".newsletter-popup button.close",
            "//div[contains(@class, 'modal')]//button[contains(@class, 'close')]",
        ]

        for selector in popup_selectors:
            try:
                if selector.startswith('//'):
                    btn = self.driver.find_element(By.XPATH, selector)
                else:
                    btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.log(f"Newsletter popup kapatiliyor: {selector}")
                    self.human_click(btn)
                    self.random_delay(0.5, 1)
                    return True
            except:
                pass
        return False

    def go_to_homepage(self):
        """Percentil ana sayfasina git"""
        self.log("Percentil ana sayfasina gidiliyor...")
        self.visit_url(self.BASE_URL)
        self.screenshot("homepage")

        self.random_delay(1, 2)
        self.close_cookie_banner()

    def search(self, query: str):
        """Arama yap"""
        self.log(f"Arama yapiliyor: '{query}'")

        # Search URL ile direkt git
        search_url = f"{self.BASE_URL}/search?q={query.replace(' ', '%20')}"
        self.visit_url(search_url)

        self.random_delay(2, 3)
        self.close_cookie_banner()

        # Scroll ve popup kontrolu
        self.human_scroll("down", 300)
        self.random_delay(1, 2)
        self.close_newsletter_popup()

        self.screenshot("search_results")
        return True

    def build_search_url(self, query: str, page: int = 1,
                         min_price: float = None, max_price: float = None,
                         category: str = None, condition: str = None,
                         size: str = None) -> str:
        """Percentil arama URL'si olustur"""
        import urllib.parse

        params = {"q": query}

        if page > 1:
            params["page"] = page
        if min_price is not None:
            params["minPrice"] = int(min_price)
        if max_price is not None:
            params["maxPrice"] = int(max_price)
        if category:
            params["category"] = category
        if condition:
            params["condition"] = condition
        if size:
            params["size"] = size

        query_string = urllib.parse.urlencode(params)
        return f"{self.BASE_URL}/search?{query_string}"

    def get_product_elements(self) -> list:
        """Sayfadaki urun elementlerini al"""
        selectors = [
            "[data-testid='product-card']",
            ".product-card",
            "article[class*='product']",
            ".item-card",
            "a[href*='/produkt/']",
            ".product-list-item",
        ]

        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    self.log(f"{len(elements)} urun elementi bulundu ({selector})")
                    return elements
            except:
                pass

        return []

    def extract_product_data(self, element) -> Optional[Dict]:
        """Urun elementinden veri cikar"""
        try:
            # URL
            url = None
            try:
                link = element.find_element(By.CSS_SELECTOR, "a[href*='/produkt/']")
                url = link.get_attribute("href")
            except:
                try:
                    link = element.find_element(By.CSS_SELECTOR, "a")
                    url = link.get_attribute("href")
                except:
                    try:
                        url = element.get_attribute("href")
                    except:
                        pass

            if not url or '/produkt/' not in url:
                return None

            # Product ID
            product_id = None
            match = re.search(r'/produkt/([a-zA-Z0-9-]+)', url)
            if match:
                product_id = match.group(1)

            if not product_id:
                return None

            # Title
            title = ""
            title_selectors = ["h3", "h2", ".product-title", "[class*='title']", "img[alt]"]
            for sel in title_selectors:
                try:
                    title_el = element.find_element(By.CSS_SELECTOR, sel)
                    if sel == "img[alt]":
                        title = title_el.get_attribute("alt") or ""
                    else:
                        title = title_el.text.strip()
                    if title:
                        break
                except:
                    pass

            # Current Price (sale price)
            price = None
            price_selectors = [".sale-price", ".current-price", ".price", "[class*='price']", "span"]
            for sel in price_selectors:
                try:
                    price_el = element.find_element(By.CSS_SELECTOR, sel)
                    price_text = price_el.text
                    price_match = re.search(r'([\d.,]+)\s*(?:EUR|€)', price_text)
                    if price_match:
                        price = float(price_match.group(1).replace('.', '').replace(',', '.'))
                        break
                except:
                    pass

            # Original/Crossed Price
            original_price = None
            original_selectors = [".original-price", ".crossed-price", "del", "s", "[class*='original']"]
            for sel in original_selectors:
                try:
                    orig_el = element.find_element(By.CSS_SELECTOR, sel)
                    orig_text = orig_el.text
                    orig_match = re.search(r'([\d.,]+)\s*(?:EUR|€)', orig_text)
                    if orig_match:
                        original_price = float(orig_match.group(1).replace('.', '').replace(',', '.'))
                        break
                except:
                    pass

            # Discount percentage
            discount_percent = None
            if price and original_price and original_price > price:
                discount_percent = round((1 - price/original_price) * 100, 1)

            # Image
            image_url = None
            try:
                img = element.find_element(By.CSS_SELECTOR, "img")
                image_url = img.get_attribute("src") or img.get_attribute("data-src")
            except:
                pass

            # Brand (from title)
            brand = None
            if title:
                known_brands = ["Nike", "Adidas", "Puma", "Tommy Hilfiger", "H&M", "Zara",
                               "Calvin Klein", "Ralph Lauren", "Levis", "Guess", "Hugo Boss",
                               "Mango", "Massimo Dutti", "Bershka", "Pull&Bear"]
                for b in known_brands:
                    if b.lower() in title.lower():
                        brand = b
                        break

            return {
                "product_id": product_id,
                "url": url,
                "title": title,
                "price": price,
                "original_price": original_price,
                "discount_percent": discount_percent,
                "brand": brand,
                "image": image_url,
                "platform": "percentil",
                "is_auction": False,  # Percentil has no auctions
                "scraped_at": datetime.now().isoformat()
            }

        except Exception as e:
            self.log(f"Urun verisi cikarma hatasi: {e}", "debug")
            return None

    def extract_product_details(self, url: str) -> Optional[Dict]:
        """Urun detay sayfasindan ek bilgi cikar - retail fiyat dahil"""
        try:
            self.visit_url(url)
            self.random_delay(2, 3)

            # Newsletter popup kontrol
            self.close_newsletter_popup()

            details = {}

            # Retail Value - COK ONEMLI ARBITRAJ ICIN!
            # "Geschaetzter Neupreis 119,00EUR"
            retail_patterns = [
                r'Gesch[aä]tzter\s+Neupreis[:\s]*([\d.,]+)\s*(?:EUR|€)',
                r'Neupreis[:\s]*([\d.,]+)\s*(?:EUR|€)',
                r'UVP[:\s]*([\d.,]+)\s*(?:EUR|€)',
                r'Original[:\s]*([\d.,]+)\s*(?:EUR|€)',
            ]

            try:
                page_text = self.driver.find_element(By.TAG_NAME, "body").text
                for pattern in retail_patterns:
                    match = re.search(pattern, page_text, re.IGNORECASE)
                    if match:
                        details["retail_value"] = float(match.group(1).replace('.', '').replace(',', '.'))
                        self.log(f"Retail value bulundu: {details['retail_value']} EUR")
                        break
            except:
                pass

            # Discount Code (e.g., PCSA30)
            try:
                discount_selectors = [".discount-code", "[class*='promo-code']", "[class*='coupon']"]
                for sel in discount_selectors:
                    try:
                        el = self.driver.find_element(By.CSS_SELECTOR, sel)
                        details["discount_code"] = el.text.strip()
                        break
                    except:
                        pass
            except:
                pass

            # Metadata alanlari
            for field, german_label in self.METADATA_FIELDS.items():
                try:
                    xpath = f"//dt[contains(text(), '{german_label}')]/following-sibling::dd[1]"
                    el = self.driver.find_element(By.XPATH, xpath)
                    details[field] = el.text.strip()
                except:
                    try:
                        xpath = f"//*[contains(text(), '{german_label}:')]"
                        el = self.driver.find_element(By.XPATH, xpath)
                        text = el.text
                        match = re.search(f"{german_label}:\\s*(.+)", text)
                        if match:
                            details[field] = match.group(1).strip()
                    except:
                        pass

            # Measurements - "Laenge 62 cm / Brustbreite 63 cm"
            try:
                measurements_patterns = [
                    r'(L[aä]nge\s*[\d.,]+\s*cm)',
                    r'(Brustbreite\s*[\d.,]+\s*cm)',
                    r'([\d.,]+\s*cm\s*/\s*[\d.,]+\s*cm)',
                ]
                for pattern in measurements_patterns:
                    match = re.search(pattern, page_text, re.IGNORECASE)
                    if match:
                        if "measurements" not in details:
                            details["measurements"] = match.group(1)
                        else:
                            details["measurements"] += " / " + match.group(1)
            except:
                pass

            # All images
            images = []
            try:
                img_elements = self.driver.find_elements(By.CSS_SELECTOR, "img[src*='percentil']")
                for img in img_elements[:5]:  # Max 5 images
                    src = img.get_attribute("src")
                    if src and 'thumbnail' not in src.lower():
                        images.append(src)
            except:
                pass

            if images:
                details["images"] = images

            return details

        except Exception as e:
            self.log(f"Detay cikarma hatasi: {e}", "debug")
            return None

    def load_more_products(self) -> bool:
        """Daha fazla urun yukle"""
        initial_count = len(self.get_product_elements())
        self.log(f"Mevcut urun sayisi: {initial_count}")

        # Scroll to bottom
        for attempt in range(3):
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            self.random_delay(1.5, 2.5)

            # Check popup
            self.close_newsletter_popup()

            new_count = len(self.get_product_elements())
            if new_count > initial_count:
                self.log(f"Scroll ile yuklendi: {initial_count} -> {new_count}")
                return True

        # Load more button
        load_more_selectors = [
            "button[data-testid='load-more']",
            "//button[contains(text(), 'Mehr laden')]",
            "//button[contains(text(), 'Mehr anzeigen')]",
            "//button[contains(text(), 'Load more')]",
            ".load-more button",
            ".pagination-next",
        ]

        for selector in load_more_selectors:
            try:
                if selector.startswith('//'):
                    btn = self.driver.find_element(By.XPATH, selector)
                else:
                    btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.log(f"Load more bulundu: {selector}")
                    self.human_click(btn)
                    self.random_delay(2, 4)

                    new_count = len(self.get_product_elements())
                    if new_count > initial_count:
                        return True
            except:
                pass

        self.log("Daha fazla urun yuklenemedi")
        return False

    def extract_all_products(self) -> List[Dict]:
        """Sayfadaki tum urunleri cikar"""
        elements = self.get_product_elements()
        products = []

        for element in elements:
            product = self.extract_product_data(element)
            if product and product["url"] not in [p["url"] for p in self.products_found]:
                products.append(product)
                self.products_found.append(product)

        self.log(f"{len(products)} yeni urun cikarildi (Toplam: {len(self.products_found)})")
        return products

    def scrape_page(self, url: str) -> List[Dict]:
        """Tek bir sayfayi kazi"""
        self.log(f"Sayfa aciliyor: {url}")
        self.visit_url(url)

        self.close_cookie_banner()
        self.human_scroll("down", 300)
        self.close_newsletter_popup()

        return self.extract_all_products()

    def scrape(self, query: str, max_products: int = None, max_pages: int = 10,
               min_price: float = None, max_price: float = None,
               category: str = None, condition: str = None, size: str = None,
               fetch_details: bool = False, fetch_retail_values: bool = True,
               **kwargs) -> List[Dict]:
        """
        Ana kazima fonksiyonu

        Args:
            query: Arama kelimesi
            max_products: Maksimum urun sayisi
            max_pages: Maksimum sayfa sayisi
            min_price: Minimum fiyat
            max_price: Maksimum fiyat
            category: Kategori filtresi
            condition: Durum filtresi
            size: Beden filtresi
            fetch_details: Detay sayfalarini da kazi
            fetch_retail_values: Retail fiyatlari cek (arbitraj icin)
        """
        self.log("=== PERCENTIL KAZIMA BASLIYOR ===")
        self.log(f"Arama: {query}")
        self.log(f"Max urun: {max_products or 'Sinirsiz'}")
        self.log(f"Fiyat: {min_price} - {max_price} EUR")
        self.log(f"Retail degerler: {'Evet' if fetch_retail_values else 'Hayir'}")

        try:
            for page in range(1, max_pages + 1):
                url = self.build_search_url(
                    query=query,
                    page=page,
                    min_price=min_price,
                    max_price=max_price,
                    category=category,
                    condition=condition,
                    size=size
                )

                self.log(f"Sayfa {page}/{max_pages}")

                before_count = len(self.products_found)
                self.scrape_page(url)
                after_count = len(self.products_found)

                new_products = after_count - before_count
                self.log(f"+{new_products} yeni urun (Toplam: {after_count})")

                # Limit kontrolu
                if max_products and len(self.products_found) >= max_products:
                    self.log(f"Maksimum urun sayisina ulasildi: {max_products}")
                    break

                # Bos sayfa
                if new_products == 0:
                    self.log("Bos sayfa, kazima durduruluyor...")
                    break

                self.random_delay(2, 4)

            # Retail degerleri cek (opsiyonel ama onerilen)
            if fetch_retail_values and self.products_found:
                self.log("Retail degerleri icin detay sayfalari kaziniyor...")
                count = min(30, len(self.products_found)) if not fetch_details else len(self.products_found)

                for i, product in enumerate(self.products_found[:count]):
                    details = self.extract_product_details(product["url"])
                    if details:
                        product.update(details)

                        # Arbitraj potansiyeli hesapla
                        if details.get("retail_value") and product.get("price"):
                            savings = details["retail_value"] - product["price"]
                            savings_percent = (savings / details["retail_value"]) * 100
                            product["arbitrage_potential"] = {
                                "savings": savings,
                                "savings_percent": round(savings_percent, 1)
                            }

                    # Her 5 urunde bir mola
                    if i > 0 and i % 5 == 0:
                        self.random_delay(3, 6)

            self.log("=== PERCENTIL KAZIMA TAMAMLANDI ===")
            self.log(f"Toplam urun: {len(self.products_found)}")

            # Arbitraj potansiyeli olan urunleri logla
            high_potential = [p for p in self.products_found
                            if p.get("arbitrage_potential", {}).get("savings_percent", 0) > 50]
            if high_potential:
                self.log(f"Yuksek arbitraj potansiyeli: {len(high_potential)} urun (>50% tasarruf)")

            return self.products_found

        except Exception as e:
            self.log(f"Kazima hatasi: {e}", "error")
            self.screenshot("error")
            raise


def run_percentil_scrape(query: str, max_products: int = None, headless: bool = True) -> List[Dict]:
    """Percentil kazima islemini calistir"""
    with PercentilScraper(headless=headless) as scraper:
        return scraper.scrape(query, max_products=max_products)


if __name__ == "__main__":
    import sys

    query = sys.argv[1] if len(sys.argv) > 1 else "pullover"
    max_items = int(sys.argv[2]) if len(sys.argv) > 2 else 20

    print(f"Percentil kazima basliyor: {query}")
    products = run_percentil_scrape(query, max_products=max_items, headless=True)

    print(f"\n{len(products)} urun bulundu:")
    for p in products[:5]:
        arb = p.get("arbitrage_potential", {})
        print(f"  - {p['title'][:30]} | {p['price']} EUR | Retail: {p.get('retail_value', 'N/A')} | Tasarruf: {arb.get('savings_percent', 'N/A')}%")
