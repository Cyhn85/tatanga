"""
Product Card Agent
==================
Ürün künye/card sistemi için merkezi agent.
Tüm platformlardan gelen ürünleri normalize eder ve zenginleştirir.

Features:
- Platform komisyon hesaplaması
- Kargo maliyeti hesaplaması
- Net kâr potansiyeli analizi
- Kondisyon standardizasyonu (1-5 skala)
- Cross-platform fiyat karşılaştırması
- Beden/size standardizasyonu
- EUR dönüşümü (tüm para birimleri için)
"""

import asyncio
import logging
import re
import json
import hashlib
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("product_card_agent")


class Platform(Enum):
    """Desteklenen platformlar"""
    VINTED = "vinted"
    EBAY = "ebay"
    KLEINANZEIGEN = "kleinanzeigen"
    MARKTPLAATS = "marktplaats"
    TWEEDEHANDS = "2dehands"
    BLOCKET = "blocket"
    FINN = "finn"
    DBA = "dba"
    TORI = "tori"
    DEPOP = "depop"
    VESTIAIRE = "vestiaire"
    WALLAPOP = "wallapop"
    WILLHABEN = "willhaben"
    SHPOCK = "shpock"
    TRADERA = "tradera"
    SELLPY = "sellpy"
    VIDE_DRESSING = "vide-dressing"
    REBELLE = "rebelle"
    MOMOX = "momox"
    MEDIMOPS = "medimops"
    UNKNOWN = "unknown"


class Currency(Enum):
    """Para birimleri"""
    EUR = "EUR"
    SEK = "SEK"  # Swedish Krona
    NOK = "NOK"  # Norwegian Krone
    DKK = "DKK"  # Danish Krone
    GBP = "GBP"  # British Pound
    CHF = "CHF"  # Swiss Franc
    PLN = "PLN"  # Polish Zloty
    CZK = "CZK"  # Czech Koruna
    HUF = "HUF"  # Hungarian Forint


# EUR dönüşüm oranları (yaklaşık)
EUR_RATES = {
    Currency.EUR: 1.0,
    Currency.SEK: 0.087,   # ~11.5 SEK = 1 EUR
    Currency.NOK: 0.085,   # ~11.7 NOK = 1 EUR
    Currency.DKK: 0.134,   # ~7.46 DKK = 1 EUR
    Currency.GBP: 1.17,    # ~0.85 GBP = 1 EUR
    Currency.CHF: 1.05,    # ~0.95 CHF = 1 EUR
    Currency.PLN: 0.23,    # ~4.35 PLN = 1 EUR
    Currency.CZK: 0.041,   # ~24.5 CZK = 1 EUR
    Currency.HUF: 0.0026,  # ~385 HUF = 1 EUR
}


@dataclass
class PlatformFees:
    """Platform komisyon yapısı"""
    platform: Platform
    commission_percent: float  # Yüzde olarak (örn: 10.0 = %10)
    commission_fixed: float    # Sabit ücret (EUR)
    commission_min: float      # Minimum komisyon (EUR)
    currency: Currency = Currency.EUR

    def calculate(self, price: float) -> float:
        """Komisyon hesapla"""
        commission = (price * self.commission_percent / 100) + self.commission_fixed
        return max(commission, self.commission_min)


# Platform komisyon yapıları
PLATFORM_FEES = {
    Platform.VINTED: PlatformFees(Platform.VINTED, 5.0, 0.7, 0.0),
    Platform.EBAY: PlatformFees(Platform.EBAY, 13.0, 0.3, 0.0),
    Platform.KLEINANZEIGEN: PlatformFees(Platform.KLEINANZEIGEN, 0.0, 0.0, 0.0),  # Ücretsiz
    Platform.MARKTPLAATS: PlatformFees(Platform.MARKTPLAATS, 7.5, 0.5, 0.0),
    Platform.TWEEDEHANDS: PlatformFees(Platform.TWEEDEHANDS, 8.0, 0.35, 0.0),
    Platform.BLOCKET: PlatformFees(Platform.BLOCKET, 10.0, 0.87, 2.17, Currency.SEK),  # 10% + 10 SEK, min 25 SEK
    Platform.FINN: PlatformFees(Platform.FINN, 10.0, 2.14, 3.33, Currency.NOK),  # 10% + 25 NOK, min 39 NOK
    Platform.DBA: PlatformFees(Platform.DBA, 7.0, 1.34, 2.55, Currency.DKK),  # 7% + 10 DKK, min 19 DKK
    Platform.TORI: PlatformFees(Platform.TORI, 12.0, 2.0, 3.0),
    Platform.DEPOP: PlatformFees(Platform.DEPOP, 10.0, 0.0, 0.0),
    Platform.VESTIAIRE: PlatformFees(Platform.VESTIAIRE, 15.0, 0.0, 0.0),
    Platform.WALLAPOP: PlatformFees(Platform.WALLAPOP, 0.0, 0.0, 0.0),  # Ücretsiz (satıcı için)
    Platform.WILLHABEN: PlatformFees(Platform.WILLHABEN, 0.0, 0.0, 0.0),  # Ücretsiz
    Platform.SHPOCK: PlatformFees(Platform.SHPOCK, 0.0, 0.0, 0.0),  # Ücretsiz
    Platform.TRADERA: PlatformFees(Platform.TRADERA, 8.0, 0.0, 0.0),
    Platform.SELLPY: PlatformFees(Platform.SELLPY, 40.0, 0.0, 0.0),  # Sellpy takes 40%
    Platform.VIDE_DRESSING: PlatformFees(Platform.VIDE_DRESSING, 12.0, 1.0, 0.0),
    Platform.REBELLE: PlatformFees(Platform.REBELLE, 18.0, 0.0, 0.0),
    Platform.MOMOX: PlatformFees(Platform.MOMOX, 0.0, 0.0, 0.0),  # Fixed price buyer
    Platform.MEDIMOPS: PlatformFees(Platform.MEDIMOPS, 0.0, 0.0, 0.0),  # Fixed price buyer
}


# Ortalama kargo maliyetleri (EUR, ülke içi)
SHIPPING_COSTS = {
    Platform.VINTED: 4.50,
    Platform.EBAY: 5.00,
    Platform.KLEINANZEIGEN: 5.00,
    Platform.MARKTPLAATS: 4.50,
    Platform.TWEEDEHANDS: 4.50,
    Platform.BLOCKET: 6.00,  # PostNord
    Platform.FINN: 7.00,     # Posten
    Platform.DBA: 5.50,      # PostNord
    Platform.TORI: 6.00,     # Posti
    Platform.DEPOP: 5.00,
    Platform.VESTIAIRE: 0.0,  # Dahil
    Platform.WALLAPOP: 4.00,
    Platform.WILLHABEN: 5.00,
    Platform.SHPOCK: 4.50,
    Platform.TRADERA: 5.50,
    Platform.SELLPY: 0.0,    # Dahil
}


@dataclass
class ProductCard:
    """Zenginleştirilmiş ürün künye/card"""
    # Temel bilgiler
    id: str
    url: str
    platform: Platform
    title: str
    description: str

    # Fiyat bilgileri
    price: float
    currency: Currency
    price_eur: float = 0.0  # EUR cinsinden fiyat

    # Maliyet analizi
    platform_commission: float = 0.0
    shipping_cost: float = 0.0
    total_cost: float = 0.0
    seller_receives: float = 0.0  # Satıcının eline geçen

    # Kondisyon
    condition_raw: str = ""
    condition_score: int = 0  # 1-5 skala

    # Beden/Size
    size_raw: str = ""
    size_normalized: str = ""  # EU/US/UK normalize

    # Görseller
    images: List[str] = field(default_factory=list)
    thumbnail: str = ""

    # Satıcı bilgileri
    seller_name: str = ""
    seller_rating: float = 0.0
    seller_verified: bool = False

    # Konum
    location: str = ""
    country: str = ""

    # Kategori
    category: str = ""
    brand: str = ""

    # Metadata
    scraped_at: str = ""
    attributes: Dict[str, Any] = field(default_factory=dict)

    # Benchmark (cross-platform karşılaştırma)
    benchmark_products: List[Dict] = field(default_factory=list)
    avg_market_price: float = 0.0
    price_position: str = ""  # "below_market", "at_market", "above_market"
    profit_potential: float = 0.0

    def __post_init__(self):
        self.scraped_at = datetime.now().isoformat()
        self._calculate_prices()

    def _calculate_prices(self):
        """Fiyat ve maliyet hesaplamaları"""
        # EUR'a çevir
        rate = EUR_RATES.get(self.currency, 1.0)
        self.price_eur = self.price * rate

        # Platform komisyonu
        fees = PLATFORM_FEES.get(self.platform)
        if fees:
            self.platform_commission = fees.calculate(self.price_eur)

        # Kargo maliyeti
        if self.shipping_cost == 0:
            self.shipping_cost = SHIPPING_COSTS.get(self.platform, 5.0)

        # Toplam maliyet (alıcı için)
        self.total_cost = self.price_eur + self.shipping_cost

        # Satıcının eline geçen
        self.seller_receives = self.price_eur - self.platform_commission

    def to_dict(self) -> Dict:
        """Dict'e dönüştür"""
        data = asdict(self)
        data['platform'] = self.platform.value
        data['currency'] = self.currency.value
        return data

    def get_kunye(self) -> Dict:
        """Künye formatında özet bilgi"""
        return {
            'id': self.id,
            'title': self.title[:50] + '...' if len(self.title) > 50 else self.title,
            'platform': self.platform.value,
            'price': f"€{self.price_eur:.2f}",
            'condition': f"{self.condition_score}/5",
            'size': self.size_normalized or self.size_raw,
            'brand': self.brand,
            'commission': f"€{self.platform_commission:.2f}",
            'shipping': f"€{self.shipping_cost:.2f}",
            'total_cost': f"€{self.total_cost:.2f}",
            'seller_receives': f"€{self.seller_receives:.2f}",
            'profit_potential': f"€{self.profit_potential:.2f}" if self.profit_potential else "N/A",
            'price_position': self.price_position or "N/A",
        }


class ProductCardAgent:
    """
    Product Card Agent
    Ürünleri normalize eder, zenginleştirir ve analiz eder.
    """

    # Kondisyon eşleştirme (farklı diller → 1-5 skor)
    CONDITION_MAP = {
        # English
        'new': 5, 'brand new': 5, 'bnwt': 5, 'nwt': 5,
        'like new': 4, 'excellent': 4, 'mint': 4,
        'very good': 4, 'good': 3, 'fair': 2, 'poor': 1,

        # German
        'neu': 5, 'nagelneu': 5, 'ungetragen': 5,
        'wie neu': 4, 'sehr gut': 4, 'gut': 3,
        'akzeptabel': 2, 'stark gebraucht': 1,

        # Dutch
        'nieuw': 5, 'zo goed als nieuw': 4, 'gebruikt': 3,
        'redelijk': 2, 'beschadigd': 1,

        # Swedish
        'nytt': 5, 'ny': 5, 'oanvänd': 5, 'som ny': 4,
        'bra skick': 3, 'begagnad': 3, 'slitage': 2,

        # Norwegian
        'som nytt': 4, 'pent brukt': 4, 'god stand': 3,
        'brukt': 3, 'noe slitasje': 2,

        # Danish
        'nyt': 5, 'som nyt': 4, 'velholdt': 3,
        'slidt': 2, 'defekt': 1,

        # Finnish
        'uusi': 5, 'uudenveroinen': 4, 'hyvä': 3,
        'käytetty': 3, 'kulunut': 2, 'viallinen': 1,

        # French
        'neuf': 5, 'comme neuf': 4, 'très bon état': 4,
        'bon état': 3, 'état correct': 2,

        # Turkish (internal use)
        'sıfır': 5, 'çok iyi': 4, 'iyi': 3, 'orta': 2, 'kötü': 1,
    }

    # Beden standardizasyonu
    SIZE_MAP = {
        # EU sizes
        'xxs': 'XXS', 'xs': 'XS', 's': 'S', 'm': 'M',
        'l': 'L', 'xl': 'XL', 'xxl': 'XXL', '2xl': 'XXL',
        'xxxl': 'XXXL', '3xl': 'XXXL',

        # Numeric (EU)
        '32': 'XXS', '34': 'XS', '36': 'S', '38': 'M',
        '40': 'L', '42': 'XL', '44': 'XXL', '46': 'XXXL',

        # UK sizes (approx conversion to EU)
        'uk 4': 'XXS', 'uk 6': 'XS', 'uk 8': 'XS',
        'uk 10': 'S', 'uk 12': 'M', 'uk 14': 'L',
        'uk 16': 'XL', 'uk 18': 'XXL',

        # US sizes
        'us 0': 'XXS', 'us 2': 'XS', 'us 4': 'XS',
        'us 6': 'S', 'us 8': 'M', 'us 10': 'L',
        'us 12': 'XL', 'us 14': 'XXL',
    }

    def __init__(self):
        self.logger = logging.getLogger("product_card_agent")
        self.processed_count = 0
        self.error_count = 0

    def detect_platform(self, url: str) -> Platform:
        """URL'den platform tespit et"""
        url_lower = url.lower()

        platform_patterns = {
            Platform.VINTED: ['vinted.'],
            Platform.EBAY: ['ebay.'],
            Platform.KLEINANZEIGEN: ['kleinanzeigen.de', 'ebay-kleinanzeigen.de'],
            Platform.MARKTPLAATS: ['marktplaats.nl'],
            Platform.TWEEDEHANDS: ['2dehands.be', '2ememain.be'],
            Platform.BLOCKET: ['blocket.se'],
            Platform.FINN: ['finn.no'],
            Platform.DBA: ['dba.dk'],
            Platform.TORI: ['tori.fi'],
            Platform.DEPOP: ['depop.'],
            Platform.VESTIAIRE: ['vestiairecollective.'],
            Platform.WALLAPOP: ['wallapop.'],
            Platform.WILLHABEN: ['willhaben.'],
            Platform.SHPOCK: ['shpock.'],
            Platform.TRADERA: ['tradera.'],
            Platform.SELLPY: ['sellpy.'],
        }

        for platform, patterns in platform_patterns.items():
            for pattern in patterns:
                if pattern in url_lower:
                    return platform

        return Platform.UNKNOWN

    def detect_currency(self, platform: Platform, price_text: str = "") -> Currency:
        """Platform ve fiyat metninden para birimi tespit et"""
        # Platform bazlı varsayılan
        platform_currencies = {
            Platform.BLOCKET: Currency.SEK,
            Platform.TRADERA: Currency.SEK,
            Platform.FINN: Currency.NOK,
            Platform.DBA: Currency.DKK,
        }

        if platform in platform_currencies:
            return platform_currencies[platform]

        # Fiyat metninden tespit
        if price_text:
            price_lower = price_text.lower()
            if 'sek' in price_lower or 'kr' in price_lower and 'dkk' not in price_lower:
                return Currency.SEK
            elif 'nok' in price_lower:
                return Currency.NOK
            elif 'dkk' in price_lower:
                return Currency.DKK
            elif '£' in price_text or 'gbp' in price_lower:
                return Currency.GBP
            elif 'chf' in price_lower:
                return Currency.CHF

        # Varsayılan EUR
        return Currency.EUR

    def normalize_condition(self, condition_text: str) -> Tuple[str, int]:
        """Kondisyon metnini normalize et ve skor ver"""
        if not condition_text:
            return "", 0

        condition_lower = condition_text.lower().strip()

        for key, score in self.CONDITION_MAP.items():
            if key in condition_lower:
                return condition_text, score

        return condition_text, 0

    def normalize_size(self, size_text: str) -> str:
        """Beden metnini normalize et"""
        if not size_text:
            return ""

        size_lower = size_text.lower().strip()

        # Doğrudan eşleşme
        if size_lower in self.SIZE_MAP:
            return self.SIZE_MAP[size_lower]

        # Regex ile sayı çıkarma
        match = re.search(r'(\d+)', size_lower)
        if match:
            num = match.group(1)
            if num in self.SIZE_MAP:
                return self.SIZE_MAP[num]

        # UK/US prefix ile
        for prefix in ['uk ', 'us ']:
            if prefix in size_lower:
                key = size_lower
                if key in self.SIZE_MAP:
                    return self.SIZE_MAP[key]

        return size_text.upper()

    def extract_brand(self, title: str, description: str = "") -> str:
        """Başlık veya açıklamadan marka çıkar"""
        # Popüler markalar listesi
        brands = [
            'Nike', 'Adidas', 'Zara', 'H&M', 'Mango', 'Gucci', 'Prada',
            'Louis Vuitton', 'Chanel', 'Dior', 'Hermes', 'Burberry',
            'Ralph Lauren', 'Tommy Hilfiger', 'Calvin Klein', 'Levi\'s',
            'The North Face', 'Patagonia', 'Columbia', 'Jack Wolfskin',
            'Massimo Dutti', 'COS', 'Arket', '& Other Stories',
            'Acne Studios', 'Ganni', 'Sandro', 'Maje', 'Isabel Marant',
            'Rolex', 'Omega', 'Tag Heuer', 'Apple', 'Samsung', 'Sony',
        ]

        text = f"{title} {description}".lower()

        for brand in brands:
            if brand.lower() in text:
                return brand

        return ""

    def create_card(self, product_data: Dict) -> ProductCard:
        """Ham ürün verisinden ProductCard oluştur"""
        try:
            url = product_data.get('url', '')
            platform = self.detect_platform(url)

            price = float(product_data.get('price', 0))
            price_text = product_data.get('price_text', '')
            currency = self.detect_currency(platform, price_text)

            condition_raw = product_data.get('condition', product_data.get('condition_raw', ''))
            condition_text, condition_score = self.normalize_condition(condition_raw)

            size_raw = product_data.get('size', product_data.get('size_raw', ''))
            size_normalized = self.normalize_size(size_raw)

            title = product_data.get('title', '')
            description = product_data.get('description', '')
            brand = product_data.get('brand', '') or self.extract_brand(title, description)

            card = ProductCard(
                id=product_data.get('id', hashlib.md5(url.encode()).hexdigest()[:12]),
                url=url,
                platform=platform,
                title=title,
                description=description,
                price=price,
                currency=currency,
                condition_raw=condition_text,
                condition_score=condition_score,
                size_raw=size_raw,
                size_normalized=size_normalized,
                images=product_data.get('images', []),
                thumbnail=product_data.get('thumbnail', ''),
                seller_name=product_data.get('seller_name', ''),
                seller_rating=float(product_data.get('seller_rating', 0)),
                seller_verified=product_data.get('seller_verified', False),
                location=product_data.get('location', ''),
                country=product_data.get('country', ''),
                category=product_data.get('category', ''),
                brand=brand,
                attributes=product_data.get('attributes', {}),
                shipping_cost=float(product_data.get('shipping_cost', 0)),
            )

            self.processed_count += 1
            self.logger.info(f"Card created: {card.id} - {platform.value} - €{card.price_eur:.2f}")

            return card

        except Exception as e:
            self.error_count += 1
            self.logger.error(f"Card creation error: {e}")
            raise

    async def enrich_with_benchmark(self, card: ProductCard, search_query: str = None) -> ProductCard:
        """
        Ürünü cross-platform benchmark ile zenginleştir.
        Aynı/benzer ürünü diğer platformlarda ara ve karşılaştır.
        """
        # TODO: Implement cross-platform search
        # Bu metod, aynı ürünü diğer platformlarda arayacak
        # ve ortalama piyasa fiyatını hesaplayacak

        # Örnek benchmark (gerçek implementasyon için connector'lar kullanılacak)
        if card.price_eur > 0:
            # Basit piyasa pozisyonu tahmini
            estimated_market = card.price_eur * 1.1  # Varsayılan: piyasanın %10 altında

            if card.price_eur < estimated_market * 0.8:
                card.price_position = "below_market"
                card.profit_potential = estimated_market - card.price_eur
            elif card.price_eur < estimated_market * 1.1:
                card.price_position = "at_market"
                card.profit_potential = 0
            else:
                card.price_position = "above_market"
                card.profit_potential = 0

            card.avg_market_price = estimated_market

        return card

    def batch_process(self, products: List[Dict]) -> List[ProductCard]:
        """Birden fazla ürünü toplu işle"""
        cards = []

        for product in products:
            try:
                card = self.create_card(product)
                cards.append(card)
            except Exception as e:
                self.logger.error(f"Batch process error: {e}")
                continue

        self.logger.info(f"Batch processed: {len(cards)}/{len(products)} products")
        return cards

    def get_stats(self) -> Dict:
        """İstatistikleri getir"""
        return {
            'processed_count': self.processed_count,
            'error_count': self.error_count,
            'success_rate': (self.processed_count / (self.processed_count + self.error_count) * 100)
                           if (self.processed_count + self.error_count) > 0 else 0
        }


# Utility functions
def calculate_resale_profit(buy_price: float, sell_price: float,
                           buy_platform: Platform, sell_platform: Platform,
                           buy_shipping: float = 0, sell_shipping: float = 0) -> Dict:
    """
    Yeniden satış kâr hesaplaması

    Args:
        buy_price: Alış fiyatı (EUR)
        sell_price: Satış fiyatı (EUR)
        buy_platform: Satın alma platformu
        sell_platform: Satış platformu
        buy_shipping: Alışta ödenen kargo
        sell_shipping: Satışta alıcının ödeyeceği kargo

    Returns:
        Kâr analizi dict
    """
    # Alış maliyeti
    total_buy_cost = buy_price + buy_shipping

    # Satış komisyonu
    sell_fees = PLATFORM_FEES.get(sell_platform)
    if sell_fees:
        sell_commission = sell_fees.calculate(sell_price)
    else:
        sell_commission = 0

    # Satıcının eline geçen
    seller_receives = sell_price - sell_commission

    # Net kâr
    net_profit = seller_receives - total_buy_cost

    # ROI
    roi = (net_profit / total_buy_cost * 100) if total_buy_cost > 0 else 0

    return {
        'buy_price': buy_price,
        'buy_shipping': buy_shipping,
        'total_buy_cost': total_buy_cost,
        'sell_price': sell_price,
        'sell_commission': sell_commission,
        'seller_receives': seller_receives,
        'net_profit': net_profit,
        'roi_percent': roi,
        'profitable': net_profit > 0
    }


# CLI interface
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Product Card Agent")
    parser.add_argument("action", choices=["create", "analyze", "benchmark"], help="Action")
    parser.add_argument("--url", "-u", help="Product URL")
    parser.add_argument("--price", "-p", type=float, help="Product price")
    parser.add_argument("--platform", help="Platform name")
    parser.add_argument("--input", "-i", help="Input JSON file")
    parser.add_argument("--output", "-o", help="Output JSON file")

    args = parser.parse_args()

    agent = ProductCardAgent()

    try:
        if args.action == "create":
            if args.url and args.price:
                product = {
                    'url': args.url,
                    'price': args.price,
                    'title': 'Test Product',
                }
                card = agent.create_card(product)
                kunye = card.get_kunye()

                print("\n=== ÜRÜN KÜNYESİ ===")
                for key, value in kunye.items():
                    print(f"  {key}: {value}")

                if args.output:
                    with open(args.output, 'w', encoding='utf-8') as f:
                        json.dump(card.to_dict(), f, indent=2, ensure_ascii=False)
            else:
                print("Error: --url and --price required for create")

        elif args.action == "analyze":
            if args.input:
                with open(args.input, 'r', encoding='utf-8') as f:
                    products = json.load(f)

                if isinstance(products, dict):
                    products = [products]

                cards = agent.batch_process(products)

                print(f"\nProcessed {len(cards)} products:")
                for card in cards[:10]:
                    print(f"  - {card.title[:40]}... - €{card.price_eur:.2f} ({card.platform.value})")

                if args.output:
                    with open(args.output, 'w', encoding='utf-8') as f:
                        json.dump([c.to_dict() for c in cards], f, indent=2, ensure_ascii=False)
            else:
                print("Error: --input required for analyze")

        elif args.action == "benchmark":
            # Cross-platform kâr analizi örneği
            result = calculate_resale_profit(
                buy_price=20.0,
                sell_price=35.0,
                buy_platform=Platform.VINTED,
                sell_platform=Platform.EBAY,
                buy_shipping=4.50
            )

            print("\n=== RESALE PROFIT ANALYSIS ===")
            for key, value in result.items():
                if isinstance(value, float):
                    print(f"  {key}: €{value:.2f}")
                else:
                    print(f"  {key}: {value}")

        print(f"\nStats: {agent.get_stats()}")

    except Exception as e:
        print(f"Error: {e}")
