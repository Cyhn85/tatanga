"""
TATANGA Kaynak Dogrulama Daemon
================================
Her 30 dakikada bir calisir (Windows Task Scheduler veya Hetzner Cron)
Satilmis/mevcut olmayan urunleri tespit eder ve otomatik siler.

Kullanim:
- Windows: Task Scheduler ile her 30 dk
- Hetzner: Cron job ile her 30 dk (*/30 * * * *)
"""

import json
import requests
import subprocess
import logging
import os
from pathlib import Path
from datetime import datetime
import time

# ============================================
# CONFIGURATION
# ============================================
WEBSITE_PATH = Path(r"C:\Users\cyhnsrgc\Desktop\CSS-Berlin-Website")
JSON_PATH = WEBSITE_PATH / "scraped-products.json"
LOG_DIR = Path(r"C:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces\logs")

# Hetzner
HETZNER_HOST = "195.201.146.224"
HETZNER_USER = "root"
HETZNER_IMAGE_PATH = "/root/videocu_v1/cssberlin_data/images"

# Sold indicators
SOLD_INDICATORS = [
    'verkauft', 'sold', 'nicht mehr verfugbar', 'not available',
    'reserviert', 'reserved', 'ausverkauft', 'out of stock',
    'deaktiviert', 'deactivated', 'geloscht', 'deleted',
    'abgelaufen', 'expired', 'nicht gefunden', 'not found',
    'anzeige wurde deaktiviert', 'anzeige existiert nicht',
]

# ============================================
# SETUP LOGGING
# ============================================
LOG_DIR.mkdir(parents=True, exist_ok=True)
log_file = LOG_DIR / "source_validator.log"

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


# ============================================
# HELPER FUNCTIONS
# ============================================
def load_json():
    """Load full JSON structure"""
    with open(JSON_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_json(data):
    """Save JSON structure"""
    with open(JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def check_source_availability(url, timeout=15):
    """Check if source URL is still available"""
    if not url or url in ['unknown', 'Unknown', '']:
        return {'available': None, 'reason': 'No source URL'}

    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
        }
        response = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)

        # 404 = definitely sold/removed
        if response.status_code == 404:
            return {'available': False, 'reason': '404 Not Found'}

        if response.status_code != 200:
            return {'available': False, 'reason': f'HTTP {response.status_code}'}

        # Check content for sold indicators
        content_lower = response.text.lower()
        for indicator in SOLD_INDICATORS:
            if indicator in content_lower:
                return {'available': False, 'reason': f'Sold: {indicator}'}

        return {'available': True, 'reason': 'OK'}

    except requests.exceptions.Timeout:
        return {'available': False, 'reason': 'Timeout'}
    except requests.exceptions.RequestException as e:
        return {'available': False, 'reason': str(e)[:50]}


def delete_hetzner_images(product_id):
    """Delete product images from Hetzner"""
    try:
        remote_dir = f"{HETZNER_IMAGE_PATH}/{product_id}"
        cmd = f"rm -rf {remote_dir}"
        result = subprocess.run(
            ['ssh', f'{HETZNER_USER}@{HETZNER_HOST}', cmd],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            logger.info(f"  Hetzner gorselleri silindi: {product_id}")
            return True
    except Exception as e:
        logger.warning(f"  Hetzner silme hatasi: {e}")
    return False


def git_push_changes(deleted_count):
    """Commit and push changes to GitHub"""
    try:
        os.chdir(WEBSITE_PATH)

        # Git add
        subprocess.run(['git', 'add', 'scraped-products.json'], capture_output=True, text=True)

        # Git commit
        commit_msg = f"[TATANGA-AUTO] Remove {deleted_count} sold product(s)"
        subprocess.run(['git', 'commit', '-m', commit_msg], capture_output=True, text=True)

        # Git push
        result = subprocess.run(['git', 'push'], capture_output=True, text=True, timeout=60)

        if result.returncode == 0:
            logger.info(f"GIT PUSH: Basarili - {deleted_count} urun silindi")
            return True
        else:
            logger.error(f"GIT PUSH: Hata - {result.stderr}")
            return False

    except Exception as e:
        logger.error(f"GIT PUSH: Exception - {e}")
        return False


# ============================================
# MAIN VALIDATION FUNCTION
# ============================================
def run_validation():
    """Main validation function"""
    logger.info("=" * 50)
    logger.info("KAYNAK DOGRULAMA BASLADI")
    logger.info("=" * 50)

    # Load data
    data = load_json()
    products = data.get('products', [])
    initial_count = len(products)

    logger.info(f"Toplam urun: {initial_count}")

    # Find products with valid source_url
    products_with_source = [
        p for p in products
        if p.get('source_url') and p['source_url'] not in ['unknown', 'Unknown', '']
    ]

    logger.info(f"Kontrol edilecek: {len(products_with_source)} urun (source_url var)")

    if not products_with_source:
        logger.info("Kontrol edilecek urun yok - CIKIS")
        return

    # Check each product
    sold_products = []

    for i, product in enumerate(products_with_source):
        source_url = product.get('source_url', '')
        product_id = product.get('id')
        title = product.get('title', '')[:40]

        logger.info(f"Kontrol [{i+1}/{len(products_with_source)}]: ID {product_id}")

        result = check_source_availability(source_url)

        if result['available'] == False:
            sold_products.append({
                'id': product_id,
                'title': title,
                'reason': result['reason'],
                'source_url': source_url
            })
            logger.warning(f"  SATILMIS: {title} ({result['reason']})")
        else:
            logger.info(f"  MEVCUT: {title}")

        # Rate limiting
        time.sleep(0.5)

    # Process sold products
    if sold_products:
        logger.info(f"\n{len(sold_products)} SATILMIS URUN TESPIT EDILDI")

        # Remove from JSON
        sold_ids = [p['id'] for p in sold_products]
        products = [p for p in products if p.get('id') not in sold_ids]

        # Update stats
        data['products'] = products
        data['stats']['total_products'] = len(products)
        data['stats']['last_updated'] = datetime.now().strftime('%Y-%m-%d')

        # Save JSON
        save_json(data)
        logger.info(f"JSON guncellendi: {len(products)} urun kaldi")

        # Delete Hetzner images
        for sold in sold_products:
            delete_hetzner_images(sold['id'])

        # Git push
        git_push_changes(len(sold_products))

        # Log summary
        logger.info("\nSILINEN URUNLER:")
        for sold in sold_products:
            logger.info(f"  - ID {sold['id']}: {sold['title']} ({sold['reason']})")

    else:
        logger.info("\nHicbir satilmis urun tespit edilmedi")

    # Final summary
    final_count = len(products)
    logger.info(f"\nKONTROL TAMAMLANDI")
    logger.info(f"  Baslangic: {initial_count} urun")
    logger.info(f"  Silinen: {len(sold_products)} urun")
    logger.info(f"  Kalan: {final_count} urun")
    logger.info("=" * 50)


# ============================================
# ENTRY POINT
# ============================================
if __name__ == "__main__":
    try:
        run_validation()
    except Exception as e:
        logger.error(f"KRITIK HATA: {e}")
        raise