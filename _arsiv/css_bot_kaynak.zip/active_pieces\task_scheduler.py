#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA v3 - Task Scheduler Service
====================================
Zamanlanmış scraping görevlerini yöneten servis.

Özellikler:
- APScheduler ile interval/cron based scheduling
- Multi-platform scraping
- Category & Brand based search
- Database persistence
- REST API (FastAPI)
- Background execution

Author: TATANGA Team
Version: 3.0
"""

import sys
import os
import json
import sqlite3
import threading
import time
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
import logging

# Windows encoding fix - safe for Streamlit
if sys.platform == 'win32':
    try:
        # Check if stdout/stderr are valid and have reconfigure method
        if hasattr(sys.stdout, 'reconfigure') and hasattr(sys.stdout, 'buffer'):
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        if hasattr(sys.stderr, 'reconfigure') and hasattr(sys.stderr, 'buffer'):
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except (AttributeError, ValueError, OSError):
        pass  # Skip if in Streamlit or special environment

# Add paths
BASE_DIR = Path(__file__).parent
sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR / 'integrations'))

# APScheduler
try:
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.interval import IntervalTrigger
    from apscheduler.triggers.cron import CronTrigger
    from apscheduler.jobstores.memory import MemoryJobStore
    APSCHEDULER_AVAILABLE = True
except ImportError:
    APSCHEDULER_AVAILABLE = False
    # APScheduler not installed - silent fail for Streamlit compatibility
    # Define placeholder classes for type hints
    IntervalTrigger = None
    CronTrigger = None
    BackgroundScheduler = None

# FastAPI (optional)
try:
    from fastapi import FastAPI, HTTPException, BackgroundTasks
    from fastapi.middleware.cors import CORSMiddleware
    from pydantic import BaseModel
    import uvicorn
    FASTAPI_AVAILABLE = True
except ImportError:
    FASTAPI_AVAILABLE = False

# Category Mapper
try:
    from category_mapper import (
        build_search_queries,
        get_category_info,
        get_brand_info,
        BRAND_DATABASE
    )
    MAPPER_AVAILABLE = True
except ImportError:
    MAPPER_AVAILABLE = False
    # category_mapper not found - silent fail for Streamlit compatibility

# Platform Scrapers
AVAILABLE_SCRAPERS = {}

try:
    from integrations.willhaben_scraper import WillhabenScraper
    AVAILABLE_SCRAPERS['willhaben'] = WillhabenScraper
except ImportError:
    pass

try:
    from integrations.ebay_connector import EbayConnector
    AVAILABLE_SCRAPERS['ebay'] = EbayConnector
except ImportError:
    pass

try:
    from integrations.kleinanzeigen_connector import KleinanzeigenConnector
    AVAILABLE_SCRAPERS['kleinanzeigen'] = KleinanzeigenConnector
except ImportError:
    pass

try:
    from integrations.vinted_connector import VintedConnector
    AVAILABLE_SCRAPERS['vinted'] = VintedConnector
except ImportError:
    pass


# ============================================================================
# LOGGING
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger('TATANGA.Scheduler')


# ============================================================================
# DATABASE MANAGER
# ============================================================================

class SchedulerDB:
    """Task scheduler veritabanı yönetimi"""

    def __init__(self, db_path: str = None):
        if db_path is None:
            db_path = str(BASE_DIR / 'data' / 'tatanga.db')

        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_tables()

    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_tables(self):
        """Tabloları oluştur"""
        conn = self._get_conn()
        cursor = conn.cursor()

        # Scheduled Tasks
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS scheduled_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                brands TEXT NOT NULL,
                platforms TEXT NOT NULL,
                filters TEXT,
                schedule_type TEXT DEFAULT 'interval',
                schedule_value TEXT DEFAULT '4h',
                is_active BOOLEAN DEFAULT 1,
                last_run_at DATETIME,
                next_run_at DATETIME,
                total_runs INTEGER DEFAULT 0,
                total_products_found INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME
            )
        """)

        # Task Runs
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                completed_at DATETIME,
                status TEXT DEFAULT 'running',
                products_found INTEGER DEFAULT 0,
                platforms_scraped TEXT,
                error_message TEXT,
                duration_seconds INTEGER,
                FOREIGN KEY (task_id) REFERENCES scheduled_tasks(id) ON DELETE CASCADE
            )
        """)

        # Scraped Products (scheduler results)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS scheduler_products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER,
                run_id INTEGER,
                product_id TEXT UNIQUE,
                platform TEXT,
                title TEXT,
                price REAL,
                currency TEXT DEFAULT 'EUR',
                url TEXT,
                image TEXT,
                location TEXT,
                brand TEXT,
                category TEXT,
                scraped_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES scheduled_tasks(id),
                FOREIGN KEY (run_id) REFERENCES task_runs(id)
            )
        """)

        conn.commit()
        conn.close()
        logger.info(f"Database initialized: {self.db_path}")

    # ========================================================================
    # TASK CRUD
    # ========================================================================

    def create_task(
        self,
        name: str,
        category: str,
        brands: List[str],
        platforms: List[str],
        filters: Optional[Dict] = None,
        schedule_type: str = 'interval',
        schedule_value: str = '4h'
    ) -> int:
        """Yeni task oluştur"""
        conn = self._get_conn()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO scheduled_tasks
            (name, category, brands, platforms, filters, schedule_type, schedule_value, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            name,
            category,
            json.dumps(brands),
            json.dumps(platforms),
            json.dumps(filters) if filters else '{}',
            schedule_type,
            schedule_value,
            datetime.now().isoformat()
        ))

        task_id = cursor.lastrowid
        conn.commit()
        conn.close()

        logger.info(f"Created task {task_id}: {name}")
        return task_id

    def get_task(self, task_id: int) -> Optional[Dict]:
        """Tek task getir"""
        conn = self._get_conn()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM scheduled_tasks WHERE id = ?", (task_id,))
        row = cursor.fetchone()
        conn.close()

        if row:
            return self._row_to_task(row)
        return None

    def get_all_tasks(self, active_only: bool = False) -> List[Dict]:
        """Tüm taskları getir"""
        conn = self._get_conn()
        cursor = conn.cursor()

        if active_only:
            cursor.execute("SELECT * FROM scheduled_tasks WHERE is_active = 1 ORDER BY created_at DESC")
        else:
            cursor.execute("SELECT * FROM scheduled_tasks ORDER BY created_at DESC")

        rows = cursor.fetchall()
        conn.close()

        return [self._row_to_task(row) for row in rows]

    def update_task(self, task_id: int, updates: Dict) -> bool:
        """Task güncelle"""
        conn = self._get_conn()
        cursor = conn.cursor()

        # JSON fields
        if 'brands' in updates:
            updates['brands'] = json.dumps(updates['brands'])
        if 'platforms' in updates:
            updates['platforms'] = json.dumps(updates['platforms'])
        if 'filters' in updates:
            updates['filters'] = json.dumps(updates['filters'])

        updates['updated_at'] = datetime.now().isoformat()

        set_clause = ', '.join([f"{k} = ?" for k in updates.keys()])
        values = list(updates.values()) + [task_id]

        cursor.execute(f"UPDATE scheduled_tasks SET {set_clause} WHERE id = ?", values)
        conn.commit()
        conn.close()

        return True

    def delete_task(self, task_id: int) -> bool:
        """Task sil"""
        conn = self._get_conn()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM scheduled_tasks WHERE id = ?", (task_id,))
        cursor.execute("DELETE FROM task_runs WHERE task_id = ?", (task_id,))

        conn.commit()
        conn.close()

        logger.info(f"Deleted task {task_id}")
        return True

    def _row_to_task(self, row) -> Dict:
        """Row'u task dict'e çevir"""
        return {
            'id': row['id'],
            'name': row['name'],
            'category': row['category'],
            'brands': json.loads(row['brands']),
            'platforms': json.loads(row['platforms']),
            'filters': json.loads(row['filters']) if row['filters'] else {},
            'schedule_type': row['schedule_type'],
            'schedule_value': row['schedule_value'],
            'is_active': bool(row['is_active']),
            'last_run_at': row['last_run_at'],
            'next_run_at': row['next_run_at'],
            'total_runs': row['total_runs'],
            'total_products_found': row['total_products_found'],
            'created_at': row['created_at'],
            'updated_at': row['updated_at']
        }

    # ========================================================================
    # TASK RUN MANAGEMENT
    # ========================================================================

    def create_run(self, task_id: int) -> int:
        """Yeni run başlat"""
        conn = self._get_conn()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO task_runs (task_id, started_at, status)
            VALUES (?, ?, 'running')
        """, (task_id, datetime.now().isoformat()))

        run_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return run_id

    def complete_run(
        self,
        run_id: int,
        status: str,
        products_found: int,
        platforms_scraped: List[str],
        error_message: str = None
    ):
        """Run'ı tamamla"""
        conn = self._get_conn()
        cursor = conn.cursor()

        # Duration hesapla
        cursor.execute("SELECT started_at FROM task_runs WHERE id = ?", (run_id,))
        row = cursor.fetchone()
        duration = 0
        if row and row['started_at']:
            try:
                started = datetime.fromisoformat(row['started_at'])
                duration = int((datetime.now() - started).total_seconds())
            except:
                pass

        cursor.execute("""
            UPDATE task_runs
            SET completed_at = ?, status = ?, products_found = ?,
                platforms_scraped = ?, error_message = ?, duration_seconds = ?
            WHERE id = ?
        """, (
            datetime.now().isoformat(),
            status,
            products_found,
            json.dumps(platforms_scraped),
            error_message,
            duration,
            run_id
        ))

        # Task'ı güncelle
        cursor.execute("SELECT task_id FROM task_runs WHERE id = ?", (run_id,))
        row = cursor.fetchone()
        if row:
            task_id = row['task_id']
            cursor.execute("""
                UPDATE scheduled_tasks
                SET last_run_at = ?, total_runs = total_runs + 1,
                    total_products_found = total_products_found + ?
                WHERE id = ?
            """, (datetime.now().isoformat(), products_found, task_id))

        conn.commit()
        conn.close()

    def get_task_runs(self, task_id: int, limit: int = 10) -> List[Dict]:
        """Task'ın son run'larını getir"""
        conn = self._get_conn()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT * FROM task_runs
            WHERE task_id = ?
            ORDER BY started_at DESC
            LIMIT ?
        """, (task_id, limit))

        rows = cursor.fetchall()
        conn.close()

        return [dict(row) for row in rows]

    # ========================================================================
    # PRODUCT MANAGEMENT
    # ========================================================================

    def save_products(self, task_id: int, run_id: int, products: List[Dict]) -> int:
        """Ürünleri kaydet"""
        conn = self._get_conn()
        cursor = conn.cursor()

        saved_count = 0
        for product in products:
            try:
                cursor.execute("""
                    INSERT OR REPLACE INTO scheduler_products
                    (task_id, run_id, product_id, platform, title, price, currency,
                     url, image, location, brand, category, scraped_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    task_id,
                    run_id,
                    product.get('id', ''),
                    product.get('platform', ''),
                    product.get('title', ''),
                    product.get('price', 0),
                    product.get('currency', 'EUR'),
                    product.get('url', ''),
                    product.get('image', ''),
                    product.get('location', ''),
                    product.get('brand', ''),
                    product.get('category', ''),
                    datetime.now().isoformat()
                ))
                saved_count += 1
            except Exception as e:
                logger.warning(f"Failed to save product: {e}")
                continue

        conn.commit()
        conn.close()

        return saved_count

    def get_products(
        self,
        task_id: Optional[int] = None,
        platform: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict]:
        """Ürünleri getir"""
        conn = self._get_conn()
        cursor = conn.cursor()

        query = "SELECT * FROM scheduler_products WHERE 1=1"
        params = []

        if task_id:
            query += " AND task_id = ?"
            params.append(task_id)
        if platform:
            query += " AND platform = ?"
            params.append(platform)

        query += " ORDER BY scraped_at DESC LIMIT ?"
        params.append(limit)

        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()

        return [dict(row) for row in rows]


# ============================================================================
# TASK EXECUTOR
# ============================================================================

class TaskExecutor:
    """Task çalıştırıcı"""

    def __init__(self, db: SchedulerDB):
        self.db = db
        self.running_tasks = {}  # task_id -> thread
        self.logger = logging.getLogger('TATANGA.Executor')

    def execute_task(self, task_id: int) -> Dict:
        """
        Task'ı çalıştır

        Returns:
            {
                'success': bool,
                'run_id': int,
                'products_found': int,
                'platforms_scraped': List[str],
                'error': str
            }
        """
        task = self.db.get_task(task_id)
        if not task:
            return {'success': False, 'error': 'Task not found'}

        if task_id in self.running_tasks:
            return {'success': False, 'error': 'Task already running'}

        self.logger.info(f"Executing task {task_id}: {task['name']}")

        # Run başlat
        run_id = self.db.create_run(task_id)
        all_products = []
        platforms_scraped = []
        error_message = None

        try:
            # Her platform için scrape
            for platform in task['platforms']:
                if platform not in AVAILABLE_SCRAPERS:
                    self.logger.warning(f"Scraper not available: {platform}")
                    continue

                self.logger.info(f"Scraping {platform}...")

                try:
                    # Scraper oluştur
                    scraper_class = AVAILABLE_SCRAPERS[platform]
                    scraper = scraper_class(headless=True)

                    # Her marka için ara
                    for brand in task['brands']:
                        query = f"{brand} {task['category']}"

                        filters = task.get('filters', {})
                        filters['brand'] = brand

                        self.logger.info(f"  Searching: {query}")

                        try:
                            results = scraper.search(
                                query=query,
                                filters=filters,
                                max_items=50
                            )

                            # Marka ve kategori bilgisi ekle
                            for item in results:
                                item['brand'] = brand
                                item['category'] = task['category']

                            all_products.extend(results)
                            self.logger.info(f"  Found {len(results)} items for {brand}")

                        except Exception as e:
                            self.logger.error(f"  Search error: {e}")
                            continue

                        # Markalar arası bekleme
                        time.sleep(3)

                    scraper.close()
                    platforms_scraped.append(platform)

                except Exception as e:
                    self.logger.error(f"Platform error ({platform}): {e}")
                    continue

                # Platformlar arası bekleme
                time.sleep(5)

            # Ürünleri kaydet
            saved = self.db.save_products(task_id, run_id, all_products)
            self.logger.info(f"Saved {saved} products")

            # Run tamamla
            self.db.complete_run(
                run_id=run_id,
                status='completed',
                products_found=len(all_products),
                platforms_scraped=platforms_scraped
            )

            return {
                'success': True,
                'run_id': run_id,
                'products_found': len(all_products),
                'platforms_scraped': platforms_scraped
            }

        except Exception as e:
            error_message = str(e)
            self.logger.error(f"Task execution error: {e}")

            self.db.complete_run(
                run_id=run_id,
                status='failed',
                products_found=len(all_products),
                platforms_scraped=platforms_scraped,
                error_message=error_message
            )

            return {
                'success': False,
                'run_id': run_id,
                'products_found': len(all_products),
                'platforms_scraped': platforms_scraped,
                'error': error_message
            }

    def execute_task_async(self, task_id: int) -> bool:
        """Task'ı async olarak çalıştır"""
        if task_id in self.running_tasks:
            return False

        def run():
            try:
                self.execute_task(task_id)
            finally:
                self.running_tasks.pop(task_id, None)

        thread = threading.Thread(target=run, daemon=True)
        self.running_tasks[task_id] = thread
        thread.start()

        return True


# ============================================================================
# SCHEDULER SERVICE
# ============================================================================

class SchedulerService:
    """
    Ana scheduler servisi

    Kullanım:
        service = SchedulerService()
        service.start()

        # Task ekle
        task_id = service.add_task(
            name='Herren Mäntel',
            category='herren_mantel',
            brands=['Hugo Boss', 'Tommy Hilfiger'],
            platforms=['willhaben', 'ebay'],
            schedule='4h'
        )

        # Manuel çalıştır
        service.run_task_now(task_id)

        # Durdur
        service.stop()
    """

    def __init__(self, db_path: str = None):
        self.db = SchedulerDB(db_path)
        self.executor = TaskExecutor(self.db)
        self.scheduler = None
        self.is_running = False

        if APSCHEDULER_AVAILABLE:
            self.scheduler = BackgroundScheduler(
                jobstores={'default': MemoryJobStore()},
                job_defaults={
                    'coalesce': True,
                    'max_instances': 1
                }
            )

        self.logger = logging.getLogger('TATANGA.Service')

    def start(self):
        """Scheduler'ı başlat"""
        if not APSCHEDULER_AVAILABLE:
            self.logger.error("APScheduler not available!")
            return False

        if self.is_running:
            return True

        # Mevcut aktif taskları yükle
        tasks = self.db.get_all_tasks(active_only=True)
        for task in tasks:
            self._add_job(task)

        self.scheduler.start()
        self.is_running = True
        self.logger.info(f"Scheduler started with {len(tasks)} active tasks")

        return True

    def stop(self):
        """Scheduler'ı durdur"""
        if self.scheduler and self.is_running:
            self.scheduler.shutdown(wait=False)
            self.is_running = False
            self.logger.info("Scheduler stopped")

    def _add_job(self, task: Dict):
        """Task için job ekle"""
        if not self.scheduler:
            return

        job_id = f"task_{task['id']}"

        # Mevcut job'ı kaldır
        try:
            self.scheduler.remove_job(job_id)
        except:
            pass

        # Schedule parse
        schedule_type = task['schedule_type']
        schedule_value = task['schedule_value']

        if schedule_type == 'interval':
            # Parse interval (e.g., '4h', '30m', '1d')
            trigger = self._parse_interval(schedule_value)
        elif schedule_type == 'cron':
            # Cron expression
            trigger = CronTrigger.from_crontab(schedule_value)
        else:
            # Default: 4 saat
            trigger = IntervalTrigger(hours=4)

        self.scheduler.add_job(
            self.executor.execute_task,
            trigger=trigger,
            args=[task['id']],
            id=job_id,
            name=task['name'],
            replace_existing=True
        )

        self.logger.info(f"Added job for task {task['id']}: {schedule_value}")

    def _parse_interval(self, value: str) -> "IntervalTrigger":
        """Interval string'i parse et"""
        import re

        match = re.match(r'(\d+)([mhd])', value.lower())
        if not match:
            return IntervalTrigger(hours=4)

        amount = int(match.group(1))
        unit = match.group(2)

        if unit == 'm':
            return IntervalTrigger(minutes=amount)
        elif unit == 'h':
            return IntervalTrigger(hours=amount)
        elif unit == 'd':
            return IntervalTrigger(days=amount)

        return IntervalTrigger(hours=4)

    # ========================================================================
    # PUBLIC API
    # ========================================================================

    def add_task(
        self,
        name: str,
        category: str,
        brands: List[str],
        platforms: List[str],
        filters: Optional[Dict] = None,
        schedule: str = '4h'
    ) -> int:
        """
        Yeni task ekle

        Args:
            name: Task adı
            category: Kategori (ör: 'herren_mantel')
            brands: Marka listesi
            platforms: Platform listesi
            filters: Filtreler (price_max, etc.)
            schedule: Schedule string (ör: '4h', '30m', '1d')

        Returns:
            Task ID
        """
        task_id = self.db.create_task(
            name=name,
            category=category,
            brands=brands,
            platforms=platforms,
            filters=filters,
            schedule_type='interval',
            schedule_value=schedule
        )

        # Job ekle
        task = self.db.get_task(task_id)
        if task and self.is_running:
            self._add_job(task)

        return task_id

    def remove_task(self, task_id: int) -> bool:
        """Task sil"""
        # Job'ı kaldır
        if self.scheduler:
            try:
                self.scheduler.remove_job(f"task_{task_id}")
            except:
                pass

        return self.db.delete_task(task_id)

    def pause_task(self, task_id: int) -> bool:
        """Task'ı duraklat"""
        self.db.update_task(task_id, {'is_active': False})

        if self.scheduler:
            try:
                self.scheduler.pause_job(f"task_{task_id}")
            except:
                pass

        return True

    def resume_task(self, task_id: int) -> bool:
        """Task'ı devam ettir"""
        self.db.update_task(task_id, {'is_active': True})

        if self.scheduler:
            try:
                self.scheduler.resume_job(f"task_{task_id}")
            except:
                pass

        return True

    def run_task_now(self, task_id: int) -> Dict:
        """Task'ı hemen çalıştır"""
        return self.executor.execute_task(task_id)

    def run_task_async(self, task_id: int) -> bool:
        """Task'ı async çalıştır"""
        return self.executor.execute_task_async(task_id)

    def get_tasks(self, active_only: bool = False) -> List[Dict]:
        """Taskları getir"""
        return self.db.get_all_tasks(active_only)

    def get_task(self, task_id: int) -> Optional[Dict]:
        """Tek task getir"""
        return self.db.get_task(task_id)

    def get_task_runs(self, task_id: int, limit: int = 10) -> List[Dict]:
        """Task run geçmişi"""
        return self.db.get_task_runs(task_id, limit)

    def get_products(
        self,
        task_id: Optional[int] = None,
        platform: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict]:
        """Ürünleri getir"""
        return self.db.get_products(task_id, platform, limit)

    def get_status(self) -> Dict:
        """Servis durumu"""
        tasks = self.db.get_all_tasks()
        active_tasks = [t for t in tasks if t['is_active']]

        running_jobs = []
        if self.scheduler:
            running_jobs = [j.id for j in self.scheduler.get_jobs()]

        return {
            'is_running': self.is_running,
            'total_tasks': len(tasks),
            'active_tasks': len(active_tasks),
            'running_jobs': len(running_jobs),
            'available_scrapers': list(AVAILABLE_SCRAPERS.keys())
        }


# ============================================================================
# FASTAPI REST API (Optional)
# ============================================================================

def create_api(service: SchedulerService):
    """FastAPI uygulaması oluştur"""
    if not FASTAPI_AVAILABLE:
        return None

    app = FastAPI(title="TATANGA Scheduler API", version="3.0")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Pydantic models
    class TaskCreate(BaseModel):
        name: str
        category: str
        brands: List[str]
        platforms: List[str]
        filters: Optional[Dict] = None
        schedule: str = '4h'

    class TaskUpdate(BaseModel):
        name: Optional[str] = None
        brands: Optional[List[str]] = None
        platforms: Optional[List[str]] = None
        filters: Optional[Dict] = None
        schedule: Optional[str] = None
        is_active: Optional[bool] = None

    # Routes
    @app.get("/")
    def root():
        return {"service": "TATANGA Scheduler", "version": "3.0"}

    @app.get("/status")
    def get_status():
        return service.get_status()

    @app.get("/tasks")
    def list_tasks(active_only: bool = False):
        return service.get_tasks(active_only)

    @app.get("/tasks/{task_id}")
    def get_task(task_id: int):
        task = service.get_task(task_id)
        if not task:
            raise HTTPException(404, "Task not found")
        return task

    @app.post("/tasks")
    def create_task(task: TaskCreate):
        task_id = service.add_task(
            name=task.name,
            category=task.category,
            brands=task.brands,
            platforms=task.platforms,
            filters=task.filters,
            schedule=task.schedule
        )
        return {"task_id": task_id}

    @app.put("/tasks/{task_id}")
    def update_task(task_id: int, task: TaskUpdate):
        updates = {k: v for k, v in task.dict().items() if v is not None}
        if 'schedule' in updates:
            updates['schedule_value'] = updates.pop('schedule')

        service.db.update_task(task_id, updates)
        return {"success": True}

    @app.delete("/tasks/{task_id}")
    def delete_task(task_id: int):
        service.remove_task(task_id)
        return {"success": True}

    @app.post("/tasks/{task_id}/run")
    def run_task(task_id: int, background_tasks: BackgroundTasks, async_run: bool = True):
        if async_run:
            background_tasks.add_task(service.executor.execute_task, task_id)
            return {"status": "started", "task_id": task_id}
        else:
            result = service.run_task_now(task_id)
            return result

    @app.post("/tasks/{task_id}/pause")
    def pause_task(task_id: int):
        service.pause_task(task_id)
        return {"success": True}

    @app.post("/tasks/{task_id}/resume")
    def resume_task(task_id: int):
        service.resume_task(task_id)
        return {"success": True}

    @app.get("/tasks/{task_id}/runs")
    def get_task_runs(task_id: int, limit: int = 10):
        return service.get_task_runs(task_id, limit)

    @app.get("/products")
    def get_products(task_id: Optional[int] = None, platform: Optional[str] = None, limit: int = 100):
        return service.get_products(task_id, platform, limit)

    @app.get("/scrapers")
    def list_scrapers():
        return {"available": list(AVAILABLE_SCRAPERS.keys())}

    return app


# ============================================================================
# CLI
# ============================================================================

def main():
    import argparse

    parser = argparse.ArgumentParser(description='TATANGA Task Scheduler')
    parser.add_argument('--api', action='store_true', help='Start REST API server')
    parser.add_argument('--port', type=int, default=8502, help='API port')
    parser.add_argument('--create-task', action='store_true', help='Create a sample task')
    parser.add_argument('--list-tasks', action='store_true', help='List all tasks')
    parser.add_argument('--run-task', type=int, help='Run a task by ID')

    args = parser.parse_args()

    # Service oluştur
    service = SchedulerService()

    if args.create_task:
        # Örnek task oluştur
        task_id = service.add_task(
            name='Herren Mäntel Test',
            category='herren_mantel',
            brands=['Hugo Boss', 'Tommy Hilfiger'],
            platforms=['willhaben'],
            filters={'price_max': 200},
            schedule='4h'
        )
        print(f"Created task ID: {task_id}")
        return

    if args.list_tasks:
        tasks = service.get_tasks()
        print(f"\nTotal tasks: {len(tasks)}")
        print("-" * 60)
        for task in tasks:
            status = "Active" if task['is_active'] else "Paused"
            print(f"[{task['id']}] {task['name']} ({status})")
            print(f"    Category: {task['category']}")
            print(f"    Brands: {', '.join(task['brands'])}")
            print(f"    Platforms: {', '.join(task['platforms'])}")
            print(f"    Schedule: {task['schedule_value']}")
            print(f"    Total runs: {task['total_runs']}")
            print()
        return

    if args.run_task:
        print(f"Running task {args.run_task}...")
        result = service.run_task_now(args.run_task)
        print(f"Result: {result}")
        return

    if args.api:
        if not FASTAPI_AVAILABLE:
            print("FastAPI not installed: pip install fastapi uvicorn")
            return

        print(f"Starting API server on port {args.port}...")
        service.start()

        app = create_api(service)
        uvicorn.run(app, host="0.0.0.0", port=args.port)
        return

    # Default: Scheduler başlat
    print("="*60)
    print("TATANGA v3 - Task Scheduler Service")
    print("="*60)
    print(f"\nAvailable scrapers: {list(AVAILABLE_SCRAPERS.keys())}")
    print(f"APScheduler: {'Available' if APSCHEDULER_AVAILABLE else 'Not available'}")
    print(f"FastAPI: {'Available' if FASTAPI_AVAILABLE else 'Not available'}")

    service.start()

    print("\nScheduler running. Press Ctrl+C to stop.")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nShutting down...")
        service.stop()


if __name__ == '__main__':
    main()
