#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Database Migration 001
Create Products Table - The Foundation of TATANGA System

This is the CRITICAL missing piece identified in the gap analysis.
All other tables depend on this one.

Run this migration FIRST before any other database operations.
"""

import sys
import sqlite3
from pathlib import Path
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.logger import get_logger

logger = get_logger("migration_001")


def run_migration(db_path: str = None):
    """
    Create the products table with all necessary columns

    Args:
        db_path: Path to tatanga.db (defaults to active_pieces/tatanga.db)
    """
    if db_path is None:
        db_path = Path(__file__).parent.parent / "tatanga.db"

    logger.start_run("Migration 001: Create Products Table")

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Check if table already exists
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='products'
        """)

        if cursor.fetchone():
            logger.warning("Products table already exists, skipping creation")
            logger.end_run(success=True, message="Table already exists (safe)")
            return True

        # Create products table
        logger.info("Creating products table...")

        cursor.execute("""
            CREATE TABLE products (
                -- Primary Key
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                -- Platform Information
                platform TEXT NOT NULL,                -- 'vinted_de', 'ebay_de', 'kleinanzeigen', etc.
                platform_item_id TEXT,                 -- Platform's internal ID

                -- Basic Product Information
                title TEXT NOT NULL,
                description TEXT,
                price REAL,
                currency TEXT DEFAULT 'EUR',

                -- Product Details
                category TEXT,                         -- 'Clothing', 'Electronics', etc.
                subcategory TEXT,                      -- 'Shoes', 'Laptops', etc.
                brand TEXT,
                size TEXT,
                color TEXT,
                condition TEXT,                        -- 'New', 'Like New', 'Good', 'Fair', 'Poor'

                -- Location
                seller_location TEXT,                  -- City or region
                country_code TEXT,                     -- 'DE', 'FR', 'UK', etc.

                -- Seller Information
                seller_id TEXT,                        -- Platform's seller ID
                seller_name TEXT,
                seller_rating REAL,                    -- 0-5 stars or 0-100 percentage

                -- URLs and Images
                url TEXT UNIQUE NOT NULL,              -- Product listing URL (unique constraint!)
                image_urls TEXT,                       -- JSON array of image URLs
                image_count INTEGER DEFAULT 0,

                -- Status and Flags
                is_active BOOLEAN DEFAULT 1,           -- Still available for sale
                is_favorite BOOLEAN DEFAULT 0,         -- Marked as favorite/bookmarked
                is_monitored BOOLEAN DEFAULT 0,        -- Actively monitoring for changes

                -- Interactions
                conversation_count INTEGER DEFAULT 0,  -- Number of seller conversations
                transfer_count INTEGER DEFAULT 0,      -- Times transferred to other platforms
                view_count INTEGER DEFAULT 0,          -- Views (if platform provides this)

                -- Performance Tracking
                last_viewed_at DATETIME,               -- Last time someone viewed it
                last_message_at DATETIME,              -- Last seller message received
                last_transferred_at DATETIME,          -- Last time uploaded elsewhere
                last_price_check_at DATETIME,          -- Last price monitoring check
                price_history TEXT,                    -- JSON array of price changes

                -- SEO and Content Enhancement
                seo_keywords TEXT,                     -- Generated SEO keywords
                translated_title TEXT,                 -- Title in target language
                translated_description TEXT,           -- Description in target language
                target_language TEXT,                  -- 'en', 'de', 'fr', etc.

                -- Timestamps
                scraped_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """)

        logger.success("Products table created successfully")

        # Create indexes for common queries
        logger.info("Creating indexes...")

        indexes = [
            ("idx_products_platform", "CREATE INDEX idx_products_platform ON products(platform)"),
            ("idx_products_platform_item_id", "CREATE INDEX idx_products_platform_item_id ON products(platform, platform_item_id)"),
            ("idx_products_seller", "CREATE INDEX idx_products_seller ON products(seller_id, platform)"),
            ("idx_products_category", "CREATE INDEX idx_products_category ON products(category)"),
            ("idx_products_brand", "CREATE INDEX idx_products_brand ON products(brand)"),
            ("idx_products_price", "CREATE INDEX idx_products_price ON products(price)"),
            ("idx_products_is_active", "CREATE INDEX idx_products_is_active ON products(is_active)"),
            ("idx_products_is_favorite", "CREATE INDEX idx_products_is_favorite ON products(is_favorite)"),
            ("idx_products_created_at", "CREATE INDEX idx_products_created_at ON products(created_at DESC)"),
            ("idx_products_scraped_at", "CREATE INDEX idx_products_scraped_at ON products(scraped_at DESC)"),
        ]

        for idx_name, idx_sql in indexes:
            cursor.execute(idx_sql)
            logger.info(f"  Created index: {idx_name}")

        logger.success(f"Created {len(indexes)} indexes")

        # Create trigger to update updated_at timestamp
        logger.info("Creating update trigger...")

        cursor.execute("""
            CREATE TRIGGER update_products_timestamp
            AFTER UPDATE ON products
            FOR EACH ROW
            BEGIN
                UPDATE products
                SET updated_at = CURRENT_TIMESTAMP
                WHERE id = NEW.id;
            END;
        """)

        logger.success("Update trigger created")

        # Commit changes
        conn.commit()

        # Get table info
        cursor.execute("PRAGMA table_info(products)")
        columns = cursor.fetchall()

        logger.log_table(
            title="Products Table Schema",
            headers=["ID", "Name", "Type", "Not Null", "Default"],
            rows=[[c[0], c[1], c[2], "✓" if c[3] else "", c[4] or ""] for c in columns]
        )

        cursor.execute("SELECT COUNT(*) FROM products")
        count = cursor.fetchone()[0]

        logger.success(f"Migration completed successfully! Current product count: {count}")

        conn.close()

        logger.end_run(success=True, message="Products table ready for use")
        return True

    except Exception as e:
        logger.error(f"Migration failed: {str(e)}", error=str(e))
        logger.end_run(success=False, message=str(e))
        return False


def rollback_migration(db_path: str = None):
    """
    Rollback: Drop the products table

    WARNING: This will delete ALL product data!

    Args:
        db_path: Path to tatanga.db
    """
    if db_path is None:
        db_path = Path(__file__).parent.parent / "tatanga.db"

    logger.warning("ROLLBACK: Dropping products table...")
    logger.warning("This will DELETE ALL PRODUCT DATA!")

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Drop trigger first
        cursor.execute("DROP TRIGGER IF EXISTS update_products_timestamp")

        # Drop indexes
        cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_products_%'")
        indexes = cursor.fetchall()

        for (idx_name,) in indexes:
            cursor.execute(f"DROP INDEX IF EXISTS {idx_name}")
            logger.info(f"Dropped index: {idx_name}")

        # Drop table
        cursor.execute("DROP TABLE IF EXISTS products")

        conn.commit()
        conn.close()

        logger.success("Products table dropped successfully")
        return True

    except Exception as e:
        logger.error(f"Rollback failed: {str(e)}")
        return False


def verify_migration(db_path: str = None):
    """
    Verify the products table exists and is properly structured

    Args:
        db_path: Path to tatanga.db

    Returns:
        True if table exists and has correct structure
    """
    if db_path is None:
        db_path = Path(__file__).parent.parent / "tatanga.db"

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Check table exists
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='products'
        """)

        if not cursor.fetchone():
            logger.error("Products table does not exist!")
            return False

        # Check minimum required columns
        cursor.execute("PRAGMA table_info(products)")
        columns = {row[1] for row in cursor.fetchall()}

        required_columns = {
            'id', 'platform', 'title', 'url', 'price',
            'seller_id', 'created_at', 'is_active'
        }

        missing = required_columns - columns
        if missing:
            logger.error(f"Missing required columns: {missing}")
            return False

        # Check URL unique constraint
        cursor.execute("""
            SELECT sql FROM sqlite_master
            WHERE type='table' AND name='products'
        """)
        table_sql = cursor.fetchone()[0]

        if 'UNIQUE' not in table_sql or 'url' not in table_sql:
            logger.warning("URL unique constraint may be missing")

        logger.success("Products table verification passed")
        conn.close()
        return True

    except Exception as e:
        logger.error(f"Verification failed: {str(e)}")
        return False


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

if __name__ == '__main__':
    print("=" * 70)
    print("TATANGA - Migration 001: Create Products Table")
    print("=" * 70)

    import argparse

    parser = argparse.ArgumentParser(description='Products table migration')
    parser.add_argument('action', choices=['migrate', 'rollback', 'verify'],
                        help='Action to perform')
    parser.add_argument('--db', type=str, default=None,
                        help='Path to database file')

    args = parser.parse_args()

    if args.action == 'migrate':
        success = run_migration(args.db)
        sys.exit(0 if success else 1)

    elif args.action == 'rollback':
        confirm = input("Are you SURE you want to drop the products table? (yes/no): ")
        if confirm.lower() == 'yes':
            success = rollback_migration(args.db)
            sys.exit(0 if success else 1)
        else:
            print("Rollback cancelled")
            sys.exit(0)

    elif args.action == 'verify':
        success = verify_migration(args.db)
        sys.exit(0 if success else 1)
