# Login Test Runner - Subprocess olarak calisir
# Bu script Playwright'i ana process'te calistirir (thread sorunu yok)
# Her magaza icin ayri Playwright profil dizini kullanir

import sys
import os
import json
import argparse

# Fix encoding for Turkish characters
sys.stdout.reconfigure(encoding='utf-8')

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def run_login_test(chrome_profile: str, login_type: str, email: str, password: str,
                   proxy_host: str = '', proxy_port: int = 0) -> dict:
    """Run Vinted login test"""

    result = {
        'success': False,
        'message': '',
        'login_type': login_type,
        'proxy_used': bool(proxy_host and proxy_port)
    }

    if proxy_host and proxy_port:
        result['proxy'] = f'{proxy_host}:{proxy_port}'

    browser = None

    try:
        from playwright.sync_api import sync_playwright
        from config import BASE_DIR

        # Her magaza icin ayri playwright profil dizini
        # Chrome'un sifreli cookie'leri yerine, Playwright kendi session'ini saklar
        playwright_data_dir = os.path.join(BASE_DIR, 'playwright_profiles', chrome_profile)
        os.makedirs(playwright_data_dir, exist_ok=True)

        # Build args
        args = [
            '--disable-blink-features=AutomationControlled',
            '--no-sandbox',
        ]

        if proxy_host and proxy_port:
            args.append(f'--proxy-server=http://{proxy_host}:{proxy_port}')

        print(f"[INFO] Playwright profil: {chrome_profile}")
        print(f"[INFO] Profil dizini: {playwright_data_dir}")
        print(f"[INFO] Proxy: {proxy_host}:{proxy_port}" if proxy_host else "[INFO] Proxy: Yok")

        # Start playwright
        playwright = sync_playwright().start()

        # Playwright kendi user-data-dir'ini kullanir (Chrome'dan bagimsiz)
        # Ilk giriste kullanici manuel login yapar, sonra session kaydedilir
        browser = playwright.chromium.launch_persistent_context(
            user_data_dir=playwright_data_dir,
            headless=False,
            args=args,
            viewport={'width': 1920, 'height': 1080},
            locale='de-DE',
            timezone_id='Europe/Berlin'
        )

        page = browser.pages[0] if browser.pages else browser.new_page()

        # Navigate to Vinted
        print("[INFO] Vinted.de'ye gidiliyor...")
        # domcontentloaded daha hizli, networkidle cok bekleyebilir
        page.goto('https://www.vinted.de', wait_until='domcontentloaded', timeout=90000)
        # Sayfanin tam yuklenmesini bekle
        page.wait_for_timeout(5000)

        # Check if logged in
        print("[INFO] Sayfa yuklendi, login kontrolu yapiliyor...")
        page.wait_for_timeout(3000)

        # Handle cookie consent if present
        try:
            cookie_btn = page.query_selector('[data-testid="cookie-consent-accept-all"], button:has-text("Alle akzeptieren")')
            if cookie_btn:
                cookie_btn.click()
                print("[INFO] Cookie kabul edildi")
                page.wait_for_timeout(1000)
        except:
            pass

        # Look for user menu or login button
        try:
            # Check for user avatar or profile link
            user_menu = page.query_selector('[data-testid="user-menu-button"], [data-testid="header--user-menu--toggle"], .c-user-menu, [href*="/member/"]')
            if user_menu:
                result['success'] = True
                result['message'] = 'Login aktif - Oturum acik'
                print("[OK] Login aktif!")
            else:
                # Check for login button - means not logged in
                login_btn = page.query_selector('[data-testid="header-login-button"], button:has-text("Einloggen"), a:has-text("Einloggen")')
                if login_btn:
                    result['success'] = False
                    result['message'] = 'Oturum kapali - Tarayicida manuel giris yapin, sonra tekrar test edin'
                    print("[WARN] Login gerekli - Tarayicida Vinted'e giris yapin!")
                    print("[INFO] 60 saniye bekleniyor, bu surede giris yapabilirsiniz...")
                    # Kullaniciya giris icin 60 saniye ver
                    page.wait_for_timeout(60000)
                    # Tekrar kontrol et
                    user_menu = page.query_selector('[data-testid="user-menu-button"], [data-testid="header--user-menu--toggle"]')
                    if user_menu:
                        result['success'] = True
                        result['message'] = 'Login basarili - Oturum kaydedildi'
                        print("[OK] Login basarili! Session kaydedildi.")
                else:
                    result['success'] = True
                    result['message'] = 'Sayfa yuklendi - Login durumu belirsiz'
        except Exception as e:
            result['message'] = f'Login kontrol hatasi: {str(e)}'

        # Close browser
        print("[INFO] Tarayici kapatiliyor...")
        browser.close()
        playwright.stop()

    except Exception as e:
        import traceback
        error_msg = str(e) if str(e) else type(e).__name__
        result['message'] = f'Test hatasi: {error_msg}'
        result['traceback'] = traceback.format_exc()
        print(f"[ERROR] {error_msg}")
        print(traceback.format_exc())

        if browser:
            try:
                browser.close()
            except:
                pass

    return result


def main():
    parser = argparse.ArgumentParser(description='Vinted Login Test Runner')
    parser.add_argument('--chrome-profile', required=True, help='Chrome profile name')
    parser.add_argument('--login-type', default='check', help='Login type: check, email, google')
    parser.add_argument('--email', default='', help='Email for login')
    parser.add_argument('--password', default='', help='Password for login')
    parser.add_argument('--proxy-host', default='', help='Proxy host')
    parser.add_argument('--proxy-port', type=int, default=0, help='Proxy port')

    args = parser.parse_args()

    result = run_login_test(
        chrome_profile=args.chrome_profile,
        login_type=args.login_type,
        email=args.email,
        password=args.password,
        proxy_host=args.proxy_host,
        proxy_port=args.proxy_port
    )

    # Output result as JSON
    print("---RESULT_JSON---")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
