#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Module Logger
Simple logging utility for consistent log formatting across all modules
"""

import sys
import io
from datetime import datetime
from enum import Enum

# NOTE: Removed sys.stdout/stderr wrapper to avoid Streamlit conflicts
# If you need UTF-8 console output, set PYTHONIOENCODING=utf-8 environment variable


class LogLevel(Enum):
    """Log level enumeration"""
    INFO = "INFO"
    SUCCESS = "SUCCESS"
    WARNING = "WARNING"
    ERROR = "ERROR"
    DEBUG = "DEBUG"


class ModuleLogger:
    """
    Simple console logger for TATANGA modules

    Usage:
        logger = ModuleLogger("my_module")
        logger.info("Starting process", product_id=123)
        logger.success("Process completed", duration="5s")
        logger.error("Process failed", error="Connection timeout")
    """

    def __init__(self, module_name: str, verbose: bool = True):
        """
        Initialize logger for a specific module

        Args:
            module_name: Name of the module (e.g., "livescore_engine")
            verbose: If False, only log warnings and errors
        """
        self.module_name = module_name
        self.verbose = verbose
        self.run_name = None
        self.run_start_time = None

    def _format_message(self, level: LogLevel, message: str, **kwargs) -> str:
        """
        Format log message with timestamp and metadata

        Args:
            level: Log level
            message: Main message
            **kwargs: Additional key-value pairs to log

        Returns:
            Formatted log string
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Color codes for different log levels
        colors = {
            LogLevel.INFO: "\033[94m",      # Blue
            LogLevel.SUCCESS: "\033[92m",   # Green
            LogLevel.WARNING: "\033[93m",   # Yellow
            LogLevel.ERROR: "\033[91m",     # Red
            LogLevel.DEBUG: "\033[90m"      # Gray
        }
        reset_color = "\033[0m"

        # Build base message
        color = colors.get(level, "")
        base = f"{color}[{timestamp}] [{level.value}] [{self.module_name}]{reset_color} {message}"

        # Add kwargs if present
        if kwargs:
            kwargs_str = " | ".join([f"{k}={v}" for k, v in kwargs.items()])
            base += f" | {kwargs_str}"

        return base

    def info(self, message: str, **kwargs):
        """Log informational message"""
        if self.verbose:
            print(self._format_message(LogLevel.INFO, message, **kwargs))

    def success(self, message: str, **kwargs):
        """Log success message"""
        print(self._format_message(LogLevel.SUCCESS, message, **kwargs))

    def warning(self, message: str, **kwargs):
        """Log warning message"""
        print(self._format_message(LogLevel.WARNING, message, **kwargs))

    def error(self, message: str, **kwargs):
        """Log error message"""
        print(self._format_message(LogLevel.ERROR, message, **kwargs), file=sys.stderr)

    def debug(self, message: str, **kwargs):
        """Log debug message (only if verbose=True)"""
        if self.verbose:
            print(self._format_message(LogLevel.DEBUG, message, **kwargs))

    def start_run(self, name: str):
        """
        Start a named run (for tracking longer operations)

        Args:
            name: Name of the run (e.g., "Product Score Calculation")
        """
        self.run_name = name
        self.run_start_time = datetime.now()

        separator = "=" * 70
        print(f"\n{separator}")
        print(f"🚀 START RUN: {name}")
        print(f"   Module: {self.module_name}")
        print(f"   Started: {self.run_start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{separator}\n")

    def end_run(self, success: bool = True, message: str = None):
        """
        End a named run

        Args:
            success: Whether the run was successful
            message: Optional message to include
        """
        if not self.run_name:
            self.warning("end_run() called without start_run()")
            return

        duration = datetime.now() - self.run_start_time
        status = "✅ SUCCESS" if success else "❌ FAILED"

        separator = "=" * 70
        print(f"\n{separator}")
        print(f"{status}: {self.run_name}")
        print(f"   Duration: {duration.total_seconds():.2f}s")
        if message:
            print(f"   Message: {message}")
        print(f"{separator}\n")

        # Reset run tracking
        self.run_name = None
        self.run_start_time = None

    def log_table(self, title: str, rows: list, headers: list = None):
        """
        Log data in table format

        Args:
            title: Table title
            rows: List of lists (table data)
            headers: Optional list of column headers
        """
        print(f"\n📊 {title}")
        print("-" * 70)

        if headers:
            header_row = " | ".join([str(h).ljust(15) for h in headers])
            print(header_row)
            print("-" * 70)

        for row in rows:
            row_str = " | ".join([str(cell).ljust(15) for cell in row])
            print(row_str)

        print("-" * 70 + "\n")

    def log_dict(self, title: str, data: dict):
        """
        Log dictionary in pretty format

        Args:
            title: Dictionary title
            data: Dictionary to log
        """
        print(f"\n📋 {title}")
        print("-" * 70)

        for key, value in data.items():
            print(f"  {key}: {value}")

        print("-" * 70 + "\n")


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def get_logger(module_name: str, verbose: bool = True) -> ModuleLogger:
    """
    Get a logger instance for a module

    Args:
        module_name: Name of the module
        verbose: If False, only log warnings and errors

    Returns:
        ModuleLogger instance
    """
    return ModuleLogger(module_name, verbose)


# ============================================================================
# TESTING
# ============================================================================

if __name__ == '__main__':
    print("TATANGA - ModuleLogger Test\n")
    print("=" * 70)

    # Test basic logging
    logger = ModuleLogger("test_module")

    logger.info("Starting test", test_id=123)
    logger.success("Test passed", score=95)
    logger.warning("Potential issue detected", risk_level="medium")
    logger.error("Test failed", error_code=404)
    logger.debug("Debug information", memory_usage="50MB")

    print("\n" + "=" * 70)
    print("Test: Run Tracking\n")

    # Test run tracking
    logger.start_run("Complex Operation Test")

    import time
    logger.info("Step 1: Initialize")
    time.sleep(0.5)
    logger.info("Step 2: Process data")
    time.sleep(0.5)
    logger.success("Step 3: Save results")

    logger.end_run(success=True, message="All steps completed successfully")

    print("\n" + "=" * 70)
    print("Test: Table Logging\n")

    # Test table logging
    logger.log_table(
        title="Product Performance",
        headers=["Product ID", "Score", "Grade", "Status"],
        rows=[
            [1, 85, "A", "Active"],
            [2, 72, "C", "Active"],
            [3, 45, "F", "Attention"]
        ]
    )

    print("\n" + "=" * 70)
    print("Test: Dictionary Logging\n")

    # Test dict logging
    logger.log_dict(
        title="System Stats",
        data={
            "Total Products": 142,
            "Active Conversations": 23,
            "Avg Score": 67.5,
            "Top Platform": "Vinted DE"
        }
    )

    print("\n" + "=" * 70)
    print("✓ All tests complete!")
