# Proxy Manager Module
# Automatic proxy rotation with quota tracking

from .config import STORE_RULES, PROXY_SERVICES, ROTATION_CONFIG
from .quota_tracker import get_tracker, QuotaTracker
from .proxy_pool import get_pool, ProxyPool

__all__ = [
    'STORE_RULES',
    'PROXY_SERVICES',
    'ROTATION_CONFIG',
    'get_tracker',
    'QuotaTracker',
    'get_pool',
    'ProxyPool'
]
