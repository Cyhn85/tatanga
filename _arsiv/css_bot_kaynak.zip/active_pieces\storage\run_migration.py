#!/usr/bin/env python3
"""
Database Migration Runner
Yeni künye (product card) alanlarını ekler
"""

import sqlite3
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("migration")

DB_PATH = Path(__file__).parent / "tatanga.db"

def run_migration():
    """Run the künye fields migration"""

    if not DB_PATH.exists():
        logger.error(f"Database not found: {DB_PATH}")
        return False

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Get existing columns
    cursor.execute("PRAGMA table_info(products)")
    existing_columns = {row[1] for row in cursor.fetchall()}

    # New columns to add
    new_columns = [
        ("shipping_cost", "REAL DEFAULT 0"),
        ("platform_commission", "REAL DEFAULT 0"),
        ("total_cost", "REAL DEFAULT 0"),
        ("seller_receives", "REAL DEFAULT 0"),
        ("profit_potential", "REAL DEFAULT 0"),
        ("price_position", "TEXT"),
        ("avg_market_price", "REAL DEFAULT 0"),
        ("size_normalized", "TEXT"),
        ("detected_brand", "TEXT"),
        ("seller_rating", "REAL DEFAULT 0"),
        ("seller_verified", "INTEGER DEFAULT 0"),
        ("seller_type", "TEXT"),
        ("gallery_images", "TEXT"),
        ("screenshot_path", "TEXT"),
        ("ai_analysis", "TEXT"),
        ("platform_id", "TEXT"),
    ]

    added = 0
    for col_name, col_def in new_columns:
        if col_name not in existing_columns:
            try:
                cursor.execute(f"ALTER TABLE products ADD COLUMN {col_name} {col_def}")
                logger.info(f"Added column: {col_name}")
                added += 1
            except sqlite3.OperationalError as e:
                if "duplicate column" not in str(e).lower():
                    logger.error(f"Error adding {col_name}: {e}")

    # Create indexes
    indexes = [
        ("idx_products_platform_commission", "platform_commission"),
        ("idx_products_shipping_cost", "shipping_cost"),
        ("idx_products_profit_potential", "profit_potential"),
        ("idx_products_price_position", "price_position"),
        ("idx_products_detected_brand", "detected_brand"),
        ("idx_products_size_normalized", "size_normalized"),
    ]

    for idx_name, column in indexes:
        try:
            cursor.execute(f"CREATE INDEX IF NOT EXISTS {idx_name} ON products({column})")
            logger.info(f"Created index: {idx_name}")
        except sqlite3.OperationalError as e:
            logger.debug(f"Index {idx_name}: {e}")

    conn.commit()
    conn.close()

    logger.info(f"Migration completed: {added} columns added")
    return True


if __name__ == "__main__":
    print("=" * 50)
    print("TATANGA Database Migration")
    print("Adding künye (product card) fields")
    print("=" * 50)

    success = run_migration()

    if success:
        print("\n✅ Migration completed successfully!")
    else:
        print("\n❌ Migration failed!")
