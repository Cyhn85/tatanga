"""
Vinted Ülke Bazlı Konfigürasyon
Her ülke için özel selector, URL pattern ve dil ayarları
"""

# 13 Vinted ülkesi için tam konfigürasyon
VINTED_COUNTRY_CONFIG = {
    # ======================= ALMANYA =======================
    'de': {
        'domain': 'vinted.de',
        'url_pattern': r'/items/(\d+)',
        'link_selector': 'a[href*="/items/"]',
        'search_endpoint': '/catalog?search_text=',
        'language': 'de',
        'currency': 'EUR',
        'currency_symbol': '€',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '.feed-grid__item',
            '[class*="ItemBox"]',
            '[class*="ProductCard"]',
            '.web_ui__ItemBox__item',
            'div[class*="item"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            '.web_ui__Text__caption',
            'h3', 'h4',
            '[class*="ItemBox__title"]',
            '[class*="title"]'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '.web_ui__Text__title',
            '[class*="price"]',
            '[class*="Price"]'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[class*="Image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Neu mit Etikett',
            'like_new': 'Neu ohne Etikett',
            'very_good': 'Sehr gut',
            'good': 'Gut',
            'fair': 'Befriedigend'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= FRANSA =======================
    'fr': {
        'domain': 'vinted.fr',
        'url_pattern': r'/items/(\d+)',
        'link_selector': 'a[href*="/items/"]',
        'search_endpoint': '/catalog?search_text=',
        'language': 'fr',
        'currency': 'EUR',
        'currency_symbol': '€',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '.feed-grid__item',
            '[class*="ItemBox"]',
            '[class*="ProductCard"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            '.web_ui__Text__caption',
            'h3', 'h4',
            '[class*="title"]'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '.web_ui__Text__title',
            '[class*="price"]'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[class*="Image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Neuf avec étiquette',
            'like_new': 'Neuf sans étiquette',
            'very_good': 'Très bon état',
            'good': 'Bon état',
            'fair': 'Satisfaisant'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= İNGİLTERE =======================
    'uk': {
        'domain': 'vinted.co.uk',
        'url_pattern': r'/item(?:s)?/(\d+)',  # Hem /item/ hem /items/ destekle
        'link_selector': 'a[href*="/item"]',   # /item ve /items/ için çalışır
        'search_endpoint': '/catalog?search_text=',
        'language': 'en',
        'currency': 'GBP',
        'currency_symbol': '£',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '[class*="ProductCard"]',
            '[class*="ItemBox"]',
            'article[class*="item"]',
            '.feed-grid__item',
            'div[class*="item"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            'h3[class*="title"]',
            'h3', 'h4',
            '[class*="ItemBox__title"]',
            '[class*="title"]',
            '.web_ui__Text__caption'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '[class*="price"]',
            '[class*="Price"]',
            '.web_ui__Text__title'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[class*="Image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'New with tags',
            'like_new': 'New without tags',
            'very_good': 'Very good',
            'good': 'Good',
            'fair': 'Satisfactory'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= İSPANYA =======================
    'es': {
        'domain': 'vinted.es',
        'url_pattern': r'/items/(\d+)',
        'link_selector': 'a[href*="/items/"]',
        'search_endpoint': '/catalog?search_text=',
        'language': 'es',
        'currency': 'EUR',
        'currency_symbol': '€',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '.feed-grid__item',
            '[class*="ItemBox"]',
            '[class*="ProductCard"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            '.web_ui__Text__caption',
            'h3', 'h4',
            '[class*="title"]'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '.web_ui__Text__title',
            '[class*="price"]'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Nuevo con etiqueta',
            'like_new': 'Nuevo sin etiqueta',
            'very_good': 'Muy bueno',
            'good': 'Bueno',
            'fair': 'Satisfactorio'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= İTALYA =======================
    'it': {
        'domain': 'vinted.it',
        'url_pattern': r'/items/(\d+)',
        'link_selector': 'a[href*="/items/"]',
        'search_endpoint': '/catalog?search_text=',
        'language': 'it',
        'currency': 'EUR',
        'currency_symbol': '€',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '.feed-grid__item',
            '[class*="ItemBox"]',
            '[class*="ProductCard"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            '.web_ui__Text__caption',
            'h3', 'h4',
            '[class*="title"]'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '.web_ui__Text__title',
            '[class*="price"]'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Nuovo con cartellino',
            'like_new': 'Nuovo senza cartellino',
            'very_good': 'Ottime condizioni',
            'good': 'Buone condizioni',
            'fair': 'Soddisfacente'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= HOLLANDA =======================
    'nl': {
        'domain': 'vinted.nl',
        'url_pattern': r'/items/(\d+)',
        'link_selector': 'a[href*="/items/"]',
        'search_endpoint': '/catalog?search_text=',
        'language': 'nl',
        'currency': 'EUR',
        'currency_symbol': '€',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '.feed-grid__item',
            '[class*="ItemBox"]',
            '[class*="ProductCard"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            '.web_ui__Text__caption',
            'h3', 'h4',
            '[class*="title"]'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '.web_ui__Text__title',
            '[class*="price"]'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Nieuw met labels',
            'like_new': 'Nieuw zonder labels',
            'very_good': 'Zeer goed',
            'good': 'Goed',
            'fair': 'Redelijk'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= BELÇİKA =======================
    'be': {
        'domain': 'vinted.be',
        'url_pattern': r'/items/(\d+)',
        'link_selector': 'a[href*="/items/"]',
        'search_endpoint': '/catalog?search_text=',
        'language': 'nl',  # Hem Hollandaca hem Fransızca, varsayılan nl
        'currency': 'EUR',
        'currency_symbol': '€',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '.feed-grid__item',
            '[class*="ItemBox"]',
            '[class*="ProductCard"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            '.web_ui__Text__caption',
            'h3', 'h4',
            '[class*="title"]'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '.web_ui__Text__title',
            '[class*="price"]'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Nieuw met labels',
            'like_new': 'Nieuw zonder labels',
            'very_good': 'Zeer goed',
            'good': 'Goed',
            'fair': 'Redelijk'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= POLONYA =======================
    'pl': {
        'domain': 'vinted.pl',
        'url_pattern': r'/items/(\d+)',
        'link_selector': 'a[href*="/items/"]',
        'search_endpoint': '/catalog?search_text=',
        'language': 'pl',
        'currency': 'PLN',
        'currency_symbol': 'zł',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '.feed-grid__item',
            '[class*="ItemBox"]',
            '[class*="ProductCard"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            '.web_ui__Text__caption',
            'h3', 'h4',
            '[class*="title"]'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '.web_ui__Text__title',
            '[class*="price"]'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Nowy z metką',
            'like_new': 'Nowy bez metki',
            'very_good': 'Bardzo dobry',
            'good': 'Dobry',
            'fair': 'Zadowalający'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= ÇEKİYE =======================
    'cz': {
        'domain': 'vinted.cz',
        'url_pattern': r'/items/(\d+)',
        'link_selector': 'a[href*="/items/"]',
        'search_endpoint': '/catalog?search_text=',
        'language': 'cs',
        'currency': 'CZK',
        'currency_symbol': 'Kč',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '.feed-grid__item',
            '[class*="ItemBox"]',
            '[class*="ProductCard"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            '.web_ui__Text__caption',
            'h3', 'h4',
            '[class*="title"]'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '.web_ui__Text__title',
            '[class*="price"]'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Nové s visačkou',
            'like_new': 'Nové bez visačky',
            'very_good': 'Velmi dobrý',
            'good': 'Dobrý',
            'fair': 'Uspokojivý'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= AVUSTURYA =======================
    'at': {
        'domain': 'vinted.at',
        'url_pattern': r'/items/(\d+)',
        'link_selector': 'a[href*="/items/"]',
        'search_endpoint': '/catalog?search_text=',
        'language': 'de',
        'currency': 'EUR',
        'currency_symbol': '€',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '.feed-grid__item',
            '[class*="ItemBox"]',
            '[class*="ProductCard"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            '.web_ui__Text__caption',
            'h3', 'h4',
            '[class*="title"]'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '.web_ui__Text__title',
            '[class*="price"]'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Neu mit Etikett',
            'like_new': 'Neu ohne Etikett',
            'very_good': 'Sehr gut',
            'good': 'Gut',
            'fair': 'Befriedigend'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= İSVEÇ =======================
    'se': {
        'domain': 'vinted.se',
        'url_pattern': r'/items/(\d+)',
        'link_selector': 'a[href*="/items/"]',
        'search_endpoint': '/catalog?search_text=',
        'language': 'sv',
        'currency': 'SEK',
        'currency_symbol': 'kr',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '.feed-grid__item',
            '[class*="ItemBox"]',
            '[class*="ProductCard"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            '.web_ui__Text__caption',
            'h3', 'h4',
            '[class*="title"]'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '.web_ui__Text__title',
            '[class*="price"]'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Ny med lapp',
            'like_new': 'Ny utan lapp',
            'very_good': 'Mycket bra',
            'good': 'Bra',
            'fair': 'Tillfredsställande'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= DANİMARKA =======================
    'dk': {
        'domain': 'vinted.dk',
        'url_pattern': r'/items/(\d+)',
        'link_selector': 'a[href*="/items/"]',
        'search_endpoint': '/catalog?search_text=',
        'language': 'da',
        'currency': 'DKK',
        'currency_symbol': 'kr',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '.feed-grid__item',
            '[class*="ItemBox"]',
            '[class*="ProductCard"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            '.web_ui__Text__caption',
            'h3', 'h4',
            '[class*="title"]'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '.web_ui__Text__title',
            '[class*="price"]'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Ny med mærke',
            'like_new': 'Ny uden mærke',
            'very_good': 'Meget god',
            'good': 'God',
            'fair': 'Tilfredsstillende'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    },

    # ======================= NORVEÇ =======================
    'no': {
        'domain': 'vinted.no',
        'url_pattern': r'/item(?:s)?/(\d+)',  # Hem /item/ hem /items/ destekle
        'link_selector': 'a[href*="/item"]',   # /item ve /items/ için çalışır
        'search_endpoint': '/catalog?search_text=',
        'language': 'no',
        'currency': 'NOK',
        'currency_symbol': 'kr',
        'item_selectors': [
            '[data-testid="grid-item"]',
            '[class*="ProductCard"]',
            '[class*="ItemBox"]',
            '.feed-grid__item',
            'article[class*="item"]',
            'div[class*="item"]'
        ],
        'title_selectors': [
            '[data-testid*="title"]',
            'h3[class*="title"]',
            'h3', 'h4',
            '[class*="ItemBox__title"]',
            '[class*="title"]',
            '.web_ui__Text__caption'
        ],
        'price_selectors': [
            '[data-testid*="price"]',
            '[class*="price"]',
            '[class*="Price"]',
            '.web_ui__Text__title'
        ],
        'image_selectors': [
            'img[data-testid*="image"]',
            'img[class*="Image"]',
            'img[src*="vinted"]'
        ],
        'condition_labels': {
            'new': 'Ny med lapp',
            'like_new': 'Ny uten lapp',
            'very_good': 'Veldig bra',
            'good': 'Bra',
            'fair': 'Tilfredsstillende'
        },
        'condition_filter_ids': {
            'new': '6,1',
            'like_new': '1',
            'very_good': '2',
            'good': '3',
            'fair': '4'
        }
    }
}


def get_country_config(country_code: str) -> dict:
    """
    Ülke koduna göre konfigürasyon döndür
    Bilinmeyen ülke için Almanya varsayılan
    """
    return VINTED_COUNTRY_CONFIG.get(country_code.lower(), VINTED_COUNTRY_CONFIG['de'])


def get_all_countries() -> list:
    """Desteklenen tüm ülke kodlarını döndür"""
    return list(VINTED_COUNTRY_CONFIG.keys())


def get_link_selector(country_code: str) -> str:
    """Ülkeye özel link selector döndür"""
    config = get_country_config(country_code)
    return config['link_selector']


def get_url_pattern(country_code: str) -> str:
    """Ülkeye özel URL pattern döndür"""
    config = get_country_config(country_code)
    return config['url_pattern']


def get_item_selectors(country_code: str) -> list:
    """Ülkeye özel item selector listesi döndür"""
    config = get_country_config(country_code)
    return config['item_selectors']
