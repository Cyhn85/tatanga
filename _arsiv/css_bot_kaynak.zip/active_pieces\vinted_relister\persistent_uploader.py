# Vinted Persistent Uploader - Uses Playwright's own browser with saved session
# No CDP required - more reliable than connecting to external Chrome
# WITH PROXY MANAGER INTEGRATION

import os
import sys
import time
import random

sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Add proxy_manager to path
ACTIVE_PIECES_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ACTIVE_PIECES_DIR, 'proxy_manager'))

from playwright.sync_api import sync_playwright
from human_behavior import HumanBehavior
from utils.database import db
from config import STATUS_VALIDATED, STATUS_UPLOADED

# Proxy Manager - optional, graceful fallback if not available
try:
    from proxy_pool import get_pool
    from quota_tracker import get_tracker
    PROXY_MANAGER_AVAILABLE = True
    print('[OK] Proxy Manager loaded')
except ImportError:
    PROXY_MANAGER_AVAILABLE = False
    print('[INFO] Proxy Manager not available - using direct connection')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
SESSIONS_DIR = os.path.join(BASE_DIR, 'sessions')
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(SESSIONS_DIR, exist_ok=True)

# Account configurations
ACCOUNTS = {
    'cyhn54': {
        'network': 'Ev WiFi',
        'session_dir': os.path.join(SESSIONS_DIR, 'cyhn54'),
    },
    'cssberlin': {
        'email': 'cssberlin@hotmail.com',
        'password': 'Css200231',
        'network': 'Mobil Hotspot + Every Proxy',
        'session_dir': os.path.join(SESSIONS_DIR, 'cssberlin'),
    }
}


def print_banner():
    print("=" * 60)
    print("  VINTED PERSISTENT UPLOADER")
    print("  Playwright ile kendi tarayicisini baslatir")
    print("  Oturum bilgileri kaydedilir")
    print("=" * 60)


def launch_browser(account):
    """Launch browser with persistent context and optional proxy"""
    config = ACCOUNTS[account]
    session_dir = config['session_dir']
    os.makedirs(session_dir, exist_ok=True)

    print(f"\n[*] Tarayici baslatiliyor...")
    print(f"    Oturum dizini: {session_dir}")

    # Get proxy settings from Proxy Manager
    proxy_config = None
    if PROXY_MANAGER_AVAILABLE:
        try:
            pool = get_pool()
            proxy_config = pool.format_for_playwright(account)
            if proxy_config:
                print(f"    [PROXY] {proxy_config.get('server', 'N/A')}")
            else:
                print(f"    [DIRECT] No proxy needed for {account}")
        except Exception as e:
            print(f"    [WARN] Proxy Manager error: {e}")

    pw = sync_playwright().start()

    # Build launch options
    launch_opts = {
        'user_data_dir': session_dir,
        'headless': False,
        'viewport': {'width': 1280, 'height': 900},
        'locale': 'de-DE',
        'timezone_id': 'Europe/Berlin',
        'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'args': [
            '--disable-blink-features=AutomationControlled',
            '--disable-infobars',
            '--start-maximized',
        ],
        'ignore_default_args': ['--enable-automation'],
    }

    # Add proxy if available
    if proxy_config:
        launch_opts['proxy'] = proxy_config

    # Launch with persistent context (saves cookies, localStorage, etc.)
    context = pw.chromium.launch_persistent_context(**launch_opts)

    # Get the page (or create new one)
    if context.pages:
        page = context.pages[0]
    else:
        page = context.new_page()

    print("[OK] Tarayici basladi!")
    return pw, context, page


def handle_cookie_popup(page):
    """Handle cookie consent popup that blocks the page"""
    try:
        print("[*] Cookie popup kontrol ediliyor...")

        # Common cookie accept button selectors for Vinted
        cookie_selectors = [
            'button:has-text("Alle akzeptieren")',
            'button:has-text("Alle Cookies akzeptieren")',
            'button:has-text("Accept all")',
            'button:has-text("Akzeptieren")',
            'button[data-testid="cookie-accept-all"]',
            '#onetrust-accept-btn-handler',
            'button.cookie-accept',
            '[id*="cookie"] button:has-text("Akzeptieren")',
            '[class*="cookie"] button:has-text("Akzeptieren")',
            'div[role="dialog"] button:has-text("Akzeptieren")',
            'div[role="dialog"] button:has-text("Alle")',
        ]

        for sel in cookie_selectors:
            try:
                btn = page.query_selector(sel)
                if btn and btn.is_visible():
                    btn.click()
                    print(f"    [OK] Cookie popup kapatildi: {sel[:30]}")
                    time.sleep(1)
                    return True
            except:
                continue

        # Try with locator (more powerful)
        try:
            page.locator('button:has-text("Alle akzeptieren")').first.click(timeout=3000)
            print("    [OK] Cookie popup kapatildi (locator)")
            time.sleep(1)
            return True
        except:
            pass

        # Try clicking any visible "Accept" type button in a dialog
        try:
            dialogs = page.query_selector_all('div[role="dialog"], div[class*="modal"], div[class*="overlay"]')
            for dialog in dialogs:
                btns = dialog.query_selector_all('button')
                for btn in btns:
                    text = btn.inner_text().lower()
                    if any(x in text for x in ['akzeptieren', 'accept', 'alle', 'ok', 'verstanden']):
                        btn.click()
                        print(f"    [OK] Dialog button tiklandi: {text[:20]}")
                        time.sleep(1)
                        return True
        except:
            pass

        print("    [INFO] Cookie popup bulunamadi veya zaten kapatilmis")
        return False

    except Exception as e:
        print(f"    [DEBUG] Cookie popup error: {e}")
        return False


def check_login_status(page):
    """Check if user is logged in"""
    try:
        # First handle any cookie popup
        handle_cookie_popup(page)
        time.sleep(0.5)

        # Look for login/register button (means not logged in)
        login_btn = page.query_selector('a:has-text("Einloggen"), button:has-text("Einloggen"), a:has-text("Registrieren")')
        if login_btn:
            return False

        # Look for user menu/avatar (means logged in)
        avatar = page.query_selector('[data-testid*="avatar"], .header img, nav img[alt*="avatar"]')
        if avatar:
            return True

        # Look for "Verkaufen" button (only visible when logged in)
        sell_btn = page.query_selector('a:has-text("Verkaufen"), button:has-text("Verkaufen")')
        if sell_btn:
            return True

        return False
    except:
        return False


def wait_for_manual_login(page, timeout_minutes=10):
    """Wait for user to log in manually"""
    print(f"\n{'='*50}")
    print("  MANUEL GIRIS GEREKLI!")
    print("  ")
    print("  1. Vinted.de'ye giris yapin")
    print("  2. Email: cssberlin@hotmail.com")
    print("  3. Sifre: Css200231")
    print("  4. Captcha cikarsa cozun")
    print(f"{'='*50}")
    print(f"\n[*] Login bekleniyor (max {timeout_minutes} dakika)...")

    start = time.time()
    max_wait = timeout_minutes * 60

    while time.time() - start < max_wait:
        if check_login_status(page):
            print("\n[OK] Login basarili!")
            return True

        remaining = int(max_wait - (time.time() - start))
        mins = remaining // 60
        secs = remaining % 60
        print(f"\r  Bekleniyor... {mins}:{secs:02d}", end='', flush=True)
        time.sleep(2)

    print("\n[ERROR] Zaman asimi!")
    return False


def format_title_for_vinted(title):
    """Format title: only first letter of each word capitalized (Vinted rule)"""
    # Split into words
    words = title.split()
    formatted_words = []

    for word in words:
        if word:
            # Keep brand names and sizes as they are (e.g., XS, M, L, XL, 59FIFTY)
            if word.upper() in ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL', '59FIFTY', 'EU', 'UK', 'US']:
                formatted_words.append(word.upper())
            elif len(word) <= 2:
                # Short words like "Gr" stay as-is
                formatted_words.append(word)
            else:
                # Title case: first letter uppercase, rest lowercase
                formatted_words.append(word.capitalize())

    return ' '.join(formatted_words)


def detect_product_colors(title, description):
    """Detect colors from title and description"""
    colors = []
    text = (title + ' ' + description).lower()

    color_keywords = {
        'schwarz': 'schwarz', 'black': 'schwarz',
        'weiß': 'weiß', 'weiss': 'weiß', 'white': 'weiß',
        'blau': 'blau', 'blue': 'blau', 'navy': 'blau',
        'rot': 'rot', 'red': 'rot',
        'grün': 'grün', 'green': 'grün',
        'gelb': 'gelb', 'yellow': 'gelb',
        'grau': 'grau', 'grey': 'grau', 'gray': 'grau',
        'braun': 'braun', 'brown': 'braun',
        'türkis': 'türkis', 'turquoise': 'türkis',
        'pink': 'rosa', 'rosa': 'rosa',
        'orange': 'orange',
        'lila': 'lila', 'purple': 'lila', 'violet': 'lila',
        'beige': 'beige', 'cream': 'beige', 'khaki': 'beige',
    }

    for keyword, color in color_keywords.items():
        if keyword in text and color not in colors:
            colors.append(color)
            if len(colors) >= 2:
                break

    return colors if colors else ['schwarz']


def detect_category(title):
    """Detect Vinted category from product title"""
    title_lower = title.lower()

    # Shoes / Schuhe
    if any(x in title_lower for x in ['sneaker', 'shoe', 'schuhe', 'boots', 'sandal', 'crocs', 'slipper', 'loafer', 'trainer']):
        return {'type': 'shoes', 'de': 'Schuhe', 'subcategory': 'Sneaker'}

    # Hats / Caps / Mützen
    if any(x in title_lower for x in ['cap', 'mütze', 'hat', 'beanie', 'snapback', '59fifty', 'fitted', 'bucket']):
        return {'type': 'accessory', 'de': 'Mützen', 'subcategory': 'Caps'}

    # Jackets / Jacken
    if any(x in title_lower for x in ['jacke', 'jacket', 'coat', 'mantel', 'parka', 'hoodie', 'windbreaker']):
        return {'type': 'jacket', 'de': 'Jacken', 'subcategory': 'Übergangsjacken'}

    # T-Shirts
    if any(x in title_lower for x in ['t-shirt', 'tshirt', 'shirt', 'tee']):
        return {'type': 'tshirt', 'de': 'T-Shirts', 'subcategory': 'T-Shirts'}

    # Pullover / Sweater
    if any(x in title_lower for x in ['pullover', 'sweater', 'sweatshirt', 'pulli']):
        return {'type': 'sweater', 'de': 'Pullover', 'subcategory': 'Pullover'}

    # Pants / Hosen
    if any(x in title_lower for x in ['hose', 'jeans', 'pants', 'jogger', 'shorts', 'chino']):
        return {'type': 'pants', 'de': 'Hosen', 'subcategory': 'Jeans'}

    # Default: Accessory
    return {'type': 'accessory', 'de': 'Accessoires', 'subcategory': 'Sonstiges'}


def detect_size(title, category_type):
    """Detect size from title based on category"""
    title_lower = title.lower()
    import re

    # Shoe sizes (36-50)
    if category_type == 'shoes':
        match = re.search(r'(?:gr\.?\s*|size\s*|größe\s*)(\d{2}(?:[.,]\d)?)', title_lower)
        if match:
            return match.group(1).replace(',', '.')
        # Common size patterns
        for size in ['45', '44', '43', '42', '41', '40', '39', '38', '37', '36', '46', '47']:
            if size in title:
                return size
        return '42'  # Default

    # Hat sizes (XS, S, M, L, XL, or 7 1/4 etc.)
    if category_type == 'accessory':
        for size in ['XS', 'S', 'M', 'L', 'XL', 'XXL']:
            if size.lower() in title_lower or f' {size.lower()} ' in title_lower:
                return size
        # Fitted cap sizes
        match = re.search(r'(\d[/\s]?\d\/\d|\d{1,2})', title)
        if match:
            return match.group(1)
        return 'M'  # Default

    # Clothing sizes
    for size in ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL']:
        if size.lower() in title_lower:
            return size

    # Numeric sizes
    match = re.search(r'(?:gr\.?\s*|size\s*)(\d{1,3})', title_lower)
    if match:
        return match.group(1)

    return 'M'  # Default


def detect_brand(title):
    """Detect brand from title"""
    title_lower = title.lower()

    brands = {
        'nike': 'Nike',
        'adidas': 'Adidas',
        'puma': 'Puma',
        'new era': 'New Era',
        'newera': 'New Era',
        'crocs': 'Crocs',
        'vans': 'Vans',
        'converse': 'Converse',
        'reebok': 'Reebok',
        'jordan': 'Jordan',
        'under armour': 'Under Armour',
        'fila': 'Fila',
        'asics': 'Asics',
        'new balance': 'New Balance',
        'tommy hilfiger': 'Tommy Hilfiger',
        'tommy': 'Tommy Hilfiger',
        'ralph lauren': 'Ralph Lauren',
        'lacoste': 'Lacoste',
        'hugo boss': 'Hugo Boss',
        'calvin klein': 'Calvin Klein',
        'levis': "Levi's",
        "levi's": "Levi's",
        'diesel': 'Diesel',
        'zara': 'Zara',
        'h&m': 'H&M',
        'primark': 'Primark',
        'champion': 'Champion',
        'carhartt': 'Carhartt',
        'the north face': 'The North Face',
        'north face': 'The North Face',
        'timberland': 'Timberland',
        'dr. martens': 'Dr. Martens',
        'birkenstock': 'Birkenstock',
        'gucci': 'Gucci',
        'versace': 'Versace',
        'balenciaga': 'Balenciaga',
        'supreme': 'Supreme',
        'off-white': 'Off-White',
        'stone island': 'Stone Island',
    }

    for key, brand in brands.items():
        if key in title_lower:
            return brand

    return None  # No brand detected


def select_category_vinted(page, category_info, human):
    """Select category on Vinted - IMPROVED for new UI"""
    try:
        print("    [1] Kategori dropdown aciliyor...")

        # Step 1: Find and click the category field
        # Vinted's new UI uses a cell/row structure
        dropdown_clicked = False

        # Scroll to make sure category field is visible
        page.evaluate('window.scrollBy(0, 200)')
        time.sleep(0.5)

        # Method 1: Click on "Wähle eine Kategorie" text
        try:
            cat_btn = page.locator('text="Wähle eine Kategorie"').first
            if cat_btn.is_visible(timeout=2000):
                cat_btn.click()
                dropdown_clicked = True
                print("    [OK] Kategori alani tiklandi")
                time.sleep(1.5)
        except:
            pass

        # Method 2: Use data-testid
        if not dropdown_clicked:
            try:
                cat_field = page.locator('[data-testid*="catalog"], [data-testid*="category"]').first
                if cat_field.is_visible(timeout=1000):
                    cat_field.click()
                    dropdown_clicked = True
                    print("    [OK] Kategori (testid)")
                    time.sleep(1.5)
            except:
                pass

        # Method 3: JavaScript - find row with "Kategorie" label
        if not dropdown_clicked:
            try:
                clicked = page.evaluate('''() => {
                    // Find all divs that look like form rows
                    const allDivs = document.querySelectorAll('div');
                    for (const div of allDivs) {
                        const text = div.textContent || '';
                        // Find the category row
                        if (text.includes('Kategorie') && text.includes('Wähle eine Kategorie')) {
                            // Find clickable area within this row
                            const clickables = div.querySelectorAll('[role="button"], button, a');
                            for (const c of clickables) {
                                if (c.offsetHeight > 0) {
                                    c.click();
                                    return true;
                                }
                            }
                            // If no button found, click the div itself
                            if (div.offsetHeight > 0 && div.offsetHeight < 100) {
                                div.click();
                                return true;
                            }
                        }
                    }
                    // Alternative: find text directly
                    const textElements = document.querySelectorAll('div, span');
                    for (const el of textElements) {
                        if (el.textContent === 'Wähle eine Kategorie') {
                            el.click();
                            return true;
                        }
                    }
                    return false;
                }''')
                if clicked:
                    dropdown_clicked = True
                    print("    [OK] Kategori (JS)")
                    time.sleep(1.5)
            except Exception as e:
                print(f"    [DEBUG] JS error: {e}")

        if not dropdown_clicked:
            print("    [WARN] Kategori dropdown bulunamadi!")
            return False

        # Step 2: Navigate category hierarchy
        # Wait for modal/dropdown to appear
        time.sleep(1)

        # Vinted structure: Herren > Schuhe > Sneaker
        gender = 'Herren'
        main_category = category_info.get('de', 'Schuhe')

        print(f"    [2] Seciliyor: {gender} > {main_category}")

        # Click Herren
        try:
            page.get_by_role("option", name=gender).click()
            print(f"    [OK] {gender}")
            time.sleep(1)
        except:
            try:
                page.locator(f'text="{gender}"').first.click()
                time.sleep(1)
            except:
                # Try JavaScript
                page.evaluate(f'''() => {{
                    const items = document.querySelectorAll('div, li, span, button');
                    for (const item of items) {{
                        if (item.textContent.trim() === '{gender}') {{
                            item.click();
                            return true;
                        }}
                    }}
                    return false;
                }}''')
                time.sleep(1)

        # Click main category (Schuhe, Accessoires, etc.)
        try:
            page.get_by_role("option", name=main_category).click()
            print(f"    [OK] {main_category}")
            time.sleep(1)
        except:
            try:
                page.locator(f'text="{main_category}"').first.click()
                time.sleep(1)
            except:
                # Try JavaScript
                page.evaluate(f'''() => {{
                    const items = document.querySelectorAll('div, li, span, button');
                    for (const item of items) {{
                        if (item.textContent.includes('{main_category}')) {{
                            item.click();
                            return true;
                        }}
                    }}
                    return false;
                }}''')
                time.sleep(1)

        # Click subcategory if available
        subcategory = category_info.get('subcategory', '')
        if subcategory:
            try:
                page.get_by_role("option", name=subcategory).click()
                print(f"    [OK] {subcategory}")
                time.sleep(1)
            except:
                try:
                    page.locator(f'text="{subcategory}"').first.click()
                    time.sleep(1)
                except:
                    page.evaluate(f'''() => {{
                        const items = document.querySelectorAll('div, li, span, button');
                        for (const item of items) {{
                            if (item.textContent.includes('{subcategory}')) {{
                                item.click();
                                return true;
                            }}
                        }}
                        return false;
                    }}''')
                    time.sleep(0.5)

        # Verify selection
        time.sleep(1)
        try:
            still_empty = page.locator('text="Wähle eine Kategorie"').is_visible(timeout=500)
            if still_empty:
                print("    [WARN] Kategori secilmemis olabilir")
                return False
        except:
            pass

        return True

    except Exception as e:
        print(f"    [DEBUG] Category error: {e}")
        return False


def select_category_from_suggestion(page, human):
    """DEPRECATED - Use select_category_vinted instead"""
    return False


def select_category_manual(page, category_info, human):
    """DEPRECATED - Use select_category_vinted instead"""
    return select_category_vinted(page, category_info, human)


def select_size(page, size_value, category_type, human):
    """Select size based on category type - improved for Vinted's UI"""
    try:
        # Wait for dynamic fields to load after category selection
        time.sleep(2)
        print(f"    [1] Größe dropdown aciliyor...")

        # Step 1: Click on size dropdown - use page.evaluate to scroll and find
        dropdown_clicked = False

        # First, scroll down to make sure the size field is visible
        page.evaluate('window.scrollBy(0, 300)')
        time.sleep(0.5)

        # Try various methods to open size dropdown
        size_dropdown_selectors = [
            'div:has-text("Wähle eine Größe"):visible',
            'text="Wähle eine Größe"',
            '[data-testid*="size"]',
            'div[class*="cell"]:has-text("Größe")',
        ]

        for sel in size_dropdown_selectors:
            try:
                el = page.locator(sel).first
                if el.is_visible(timeout=2000):
                    el.click()
                    dropdown_clicked = True
                    print(f"    [OK] Size dropdown acildi")
                    time.sleep(1.5)
                    break
            except:
                continue

        if not dropdown_clicked:
            try:
                page.get_by_text("Wähle eine Größe").click()
                dropdown_clicked = True
                print("    [OK] Size dropdown acildi (text)")
                time.sleep(1.5)
            except:
                pass

        if not dropdown_clicked:
            # Use JavaScript to find and click - be more specific
            try:
                clicked = page.evaluate('''() => {
                    // Find elements containing "Größe" and "Wähle"
                    const allElements = document.querySelectorAll('div, span, button');
                    for (const el of allElements) {
                        if (el.textContent.includes('Wähle eine Größe') && el.offsetHeight > 0) {
                            el.click();
                            return true;
                        }
                    }
                    return false;
                }''')
                if clicked:
                    dropdown_clicked = True
                    time.sleep(1.5)
            except:
                pass

        if not dropdown_clicked:
            print("    [WARN] Size dropdown acilamadi - alan henuz yuklenmediyse normal")
            return False

        # Step 2: Select the size value
        print(f"    [2] Size seciliyor: {size_value}")
        time.sleep(1)

        # For shoe sizes, the value is just a number like "45"
        # For clothing, it's like "M", "L", "XL"
        size_str = str(size_value)

        # Try clicking in the size list/modal
        try:
            page.get_by_text(size_str, exact=True).click()
            print(f"    [OK] Size secildi: {size_value}")
            time.sleep(0.5)
            return True
        except:
            pass

        # Try with role=option (common in dropdowns)
        try:
            page.locator(f'[role="option"]:has-text("{size_str}")').first.click()
            print(f"    [OK] Size secildi (option): {size_value}")
            return True
        except:
            pass

        # Try with list items
        try:
            page.locator(f'li:has-text("{size_str}")').first.click()
            return True
        except:
            pass

        # Try JavaScript click
        try:
            page.evaluate(f'''() => {{
                const items = document.querySelectorAll('[role="option"], li, div');
                for (const item of items) {{
                    if (item.textContent.trim() === "{size_str}" || item.textContent.includes("{size_str}")) {{
                        item.click();
                        return true;
                    }}
                }}
                return false;
            }}''')
            return True
        except:
            pass

        return False

    except Exception as e:
        print(f"    [DEBUG] Size error: {e}")
        return False


def select_brand(page, brand_name, human):
    """Select or type brand name - improved for Vinted's UI"""
    if not brand_name:
        return False

    try:
        # Wait for dynamic fields to load
        time.sleep(1)
        print(f"    [1] Marke dropdown aciliyor...")

        # Step 1: Click on brand dropdown
        dropdown_clicked = False

        # Scroll to make sure brand field is visible
        page.evaluate('window.scrollBy(0, 200)')
        time.sleep(0.3)

        brand_dropdown_selectors = [
            'div:has-text("Wähle eine Marke"):visible',
            'text="Wähle eine Marke"',
            '[data-testid*="brand"]',
            'div[class*="cell"]:has-text("Marke")',
        ]

        for sel in brand_dropdown_selectors:
            try:
                el = page.locator(sel).first
                if el.is_visible(timeout=2000):
                    el.click()
                    dropdown_clicked = True
                    print(f"    [OK] Brand dropdown acildi")
                    time.sleep(1.5)
                    break
            except:
                continue

        if not dropdown_clicked:
            try:
                page.get_by_text("Wähle eine Marke").click()
                dropdown_clicked = True
                print("    [OK] Brand dropdown acildi (text)")
                time.sleep(1.5)
            except:
                pass

        if not dropdown_clicked:
            # Try JavaScript approach - be more specific
            try:
                clicked = page.evaluate('''() => {
                    const allElements = document.querySelectorAll('div, span, button');
                    for (const el of allElements) {
                        if (el.textContent.includes('Wähle eine Marke') && el.offsetHeight > 0) {
                            el.click();
                            return true;
                        }
                    }
                    return false;
                }''')
                if clicked:
                    dropdown_clicked = True
                    time.sleep(1.5)
            except:
                pass

        if not dropdown_clicked:
            print("    [WARN] Brand dropdown acilamadi - alan henuz yuklenmediyse normal")
            return False

        # Step 2: Type brand name in search input (if available)
        print(f"    [2] Marke yaziliyor: {brand_name}")
        time.sleep(0.5)

        # Try to find search input in dropdown modal
        try:
            search_input = page.locator('input[type="search"], input[type="text"], input[placeholder*="Such"], input[placeholder*="search"]').first
            if search_input.is_visible(timeout=2000):
                search_input.fill('')
                search_input.type(brand_name, delay=50)
                time.sleep(1.5)  # Wait for autocomplete
        except:
            pass

        # Step 3: Click on brand from list
        try:
            page.get_by_text(brand_name, exact=True).click()
            print(f"    [OK] Marke secildi: {brand_name}")
            time.sleep(0.5)
            return True
        except:
            pass

        # Try with role=option
        try:
            page.locator(f'[role="option"]:has-text("{brand_name}")').first.click()
            print(f"    [OK] Marke secildi (option): {brand_name}")
            return True
        except:
            pass

        # Try list items
        try:
            page.locator(f'li:has-text("{brand_name}")').first.click()
            return True
        except:
            pass

        # Try JavaScript click
        try:
            page.evaluate(f'''() => {{
                const items = document.querySelectorAll('[role="option"], li, div');
                for (const item of items) {{
                    if (item.textContent.includes("{brand_name}")) {{
                        item.click();
                        return true;
                    }}
                }}
                return false;
            }}''')
            return True
        except:
            pass

        return False

    except Exception as e:
        print(f"    [DEBUG] Brand error: {e}")
        return False


def detect_package_size(title):
    """Detect package size from product type

    User Rules:
    - Stiefel (boots): Groß
    - Sneaker, Sportschuhe: Mittel
    - Mantel, Jacke: Groß
    - Pullover, Cap, Hemd, T-Shirt: Klein
    """
    title_lower = title.lower()

    # GROSS (Large): Stiefel/Boots, Mäntel, Jacken
    if any(x in title_lower for x in ['stiefel', 'boots', 'boot', 'mantel', 'coat', 'jacke', 'jacket', 'parka', 'winterjacke', 'daunenjacke']):
        return 'large'

    # KLEIN (Small): Pullover, Caps/Mützen, Hemden, T-Shirts
    if any(x in title_lower for x in ['pullover', 'sweater', 'hoodie', 'sweatshirt', 'cap', 'mütze', 'hat', 'beanie', 'snapback', '59fifty',
                                      'hemd', 'shirt', 't-shirt', 'tshirt', 'bluse', 'top']):
        return 'small'

    # MITTEL (Medium): Sneaker, Sportschuhe, and default for shoes
    if any(x in title_lower for x in ['sneaker', 'sportschuh', 'laufschuh', 'turnschuh', 'crocs', 'sandal', 'slipper', 'loafer']):
        return 'medium'

    # Default: Medium for anything else (including generic shoes)
    return 'medium'


def select_condition(page, human):
    """Select condition - default to 'Gut' (Good) - improved for Vinted's UI"""
    try:
        print("    [1] Zustand dropdown aciliyor...")

        # Step 1: Click on Zustand dropdown
        dropdown_clicked = False

        zustand_selectors = [
            'div:has-text("Wähle den Zustand"):visible',
            'div:has(span:text("Zustand")) >> div:has-text("Wähle")',
            '[class*="cell"]:has-text("Zustand")',
            'button:has-text("Zustand")',
            '[data-testid*="status"]',
            '[data-testid*="condition"]',
        ]

        for sel in zustand_selectors:
            try:
                el = page.locator(sel).first
                if el.is_visible(timeout=1000):
                    el.click()
                    dropdown_clicked = True
                    print("    [OK] Zustand dropdown acildi")
                    time.sleep(1)
                    break
            except:
                continue

        if not dropdown_clicked:
            try:
                page.get_by_text("Wähle den Zustand").click()
                dropdown_clicked = True
                time.sleep(1)
            except:
                pass

        if not dropdown_clicked:
            try:
                page.evaluate('''() => {
                    const rows = document.querySelectorAll('div, tr, li');
                    for (const row of rows) {
                        if (row.textContent.includes('Zustand') && row.textContent.includes('Wähle')) {
                            row.click();
                            return true;
                        }
                    }
                    return false;
                }''')
                dropdown_clicked = True
                time.sleep(1)
            except:
                pass

        if not dropdown_clicked:
            return False

        # Step 2: Select "Gut" option
        print("    [2] Zustand seciliyor: Gut")
        time.sleep(0.5)

        try:
            page.get_by_text("Gut", exact=True).click()
            print("    [OK] Zustand secildi: Gut")
            return True
        except:
            pass

        try:
            page.locator('[role="option"]:has-text("Gut")').first.click()
            return True
        except:
            pass

        return False

    except Exception as e:
        print(f"    [DEBUG] Zustand error: {e}")
    return False


def select_colors(page, colors, human):
    """Select colors from the color picker - improved for Vinted's UI"""
    try:
        print("    [1] Farbe dropdown aciliyor...")

        # Step 1: Click on Farbe dropdown
        dropdown_clicked = False

        farbe_selectors = [
            'div:has-text("Wähle bis zu 2 Farben"):visible',
            'div:has(span:text("Farbe")) >> div:has-text("Wähle")',
            '[class*="cell"]:has-text("Farbe")',
            'button:has-text("Farbe")',
            '[data-testid*="color"]',
        ]

        for sel in farbe_selectors:
            try:
                el = page.locator(sel).first
                if el.is_visible(timeout=1000):
                    el.click()
                    dropdown_clicked = True
                    print("    [OK] Farbe dropdown acildi")
                    time.sleep(1)
                    break
            except:
                continue

        if not dropdown_clicked:
            try:
                page.get_by_text("Wähle bis zu 2 Farben").click()
                dropdown_clicked = True
                time.sleep(1)
            except:
                pass

        if not dropdown_clicked:
            try:
                page.evaluate('''() => {
                    const rows = document.querySelectorAll('div, tr, li');
                    for (const row of rows) {
                        if (row.textContent.includes('Farbe') && row.textContent.includes('Wähle')) {
                            row.click();
                            return true;
                        }
                    }
                    return false;
                }''')
                dropdown_clicked = True
                time.sleep(1)
            except:
                pass

        if not dropdown_clicked:
            return False

        # Color mapping (lowercase key -> German display name)
        color_map = {
            'schwarz': 'Schwarz',
            'weiß': 'Weiß',
            'weiss': 'Weiß',
            'blau': 'Blau',
            'rot': 'Rot',
            'grün': 'Grün',
            'gelb': 'Gelb',
            'grau': 'Grau',
            'braun': 'Braun',
            'rosa': 'Rosa',
            'pink': 'Rosa',
            'orange': 'Orange',
            'lila': 'Lila',
            'beige': 'Beige',
            'türkis': 'Türkis',
            'turquoise': 'Türkis',
        }

        # Step 2: Select colors (max 2)
        print(f"    [2] Renkler seciliyor: {colors}")
        selected = 0

        for color in colors[:2]:
            german_name = color_map.get(color.lower(), color.capitalize())

            try:
                page.get_by_text(german_name, exact=True).click()
                selected += 1
                print(f"    [OK] Renk secildi: {german_name}")
                time.sleep(0.5)
            except:
                try:
                    page.locator(f'[role="option"]:has-text("{german_name}")').first.click()
                    selected += 1
                    time.sleep(0.5)
                except:
                    pass

        return selected > 0

    except Exception as e:
        print(f"    [DEBUG] Color error: {e}")
    return False


def fill_price(page, price, human):
    """Fill the price field"""
    try:
        price_str = str(int(float(price)))

        price_selectors = [
            'input[name="price"]',
            '[data-testid="price-input"] input',
            'input[inputmode="decimal"]',
            'input[placeholder*="0,00"]',
            'input[placeholder*="Preis"]',
        ]

        for sel in price_selectors:
            try:
                el = page.query_selector(sel)
                if el:
                    el.click()
                    time.sleep(0.2)
                    el.fill('')
                    time.sleep(0.1)
                    el.type(price_str, delay=80)
                    return True
            except:
                continue

    except Exception as e:
        print(f"    [DEBUG] Price error: {e}")
    return False


def select_package_size(page, size, human):
    """Select package size - improved for Vinted's UI"""
    try:
        size_map = {
            'small': 'Klein',
            'medium': 'Mittel',
            'large': 'Groß'
        }
        german_size = size_map.get(size, 'Mittel')
        print(f"    Paketgröße seciliyor: {german_size}")

        # Vinted uses radio buttons for package size
        # First try to find the Paketgröße section
        try:
            # Try clicking the option directly
            page.get_by_text(german_size, exact=True).click()
            print(f"    [OK] Paketgröße secildi: {german_size}")
            return True
        except:
            pass

        # Try radio button selectors
        selectors = [
            f'label:has-text("{german_size}")',
            f'input[type="radio"] + label:has-text("{german_size}")',
            f'div[role="radio"]:has-text("{german_size}")',
            f'[class*="radio"]:has-text("{german_size}")',
        ]

        for sel in selectors:
            try:
                el = page.locator(sel).first
                if el.is_visible(timeout=500):
                    el.click()
                    print(f"    [OK] Paketgröße secildi: {german_size}")
                    return True
            except:
                continue

        # Try JavaScript approach
        try:
            page.evaluate(f'''() => {{
                const labels = document.querySelectorAll('label, div[role="radio"]');
                for (const label of labels) {{
                    if (label.textContent.includes('{german_size}')) {{
                        label.click();
                        return true;
                    }}
                }}
                return false;
            }}''')
            return True
        except:
            pass

    except Exception as e:
        print(f"    [DEBUG] Package size error: {e}")
    return False


def upload_product(page, human, product):
    """Upload a single product with COMPLETE form filling including category, size, brand"""
    raw_title = product.get('processed_title', product.get('raw_title', ''))
    title = format_title_for_vinted(raw_title)  # Apply Vinted title formatting
    desc = product.get('processed_description', product.get('raw_description', ''))
    price = product.get('price', 0)
    images_path = product.get('processed_images_path', product.get('raw_images_path', ''))

    # Detect ALL attributes
    colors = detect_product_colors(title, desc)
    package_size = detect_package_size(title)
    category = detect_category(title)
    size = detect_size(title, category['type'])
    brand = detect_brand(title)

    print(f"\n{'='*50}")
    print(f"  URUN: {title[:45]}...")
    print(f"  FIYAT: {price} EUR")
    print(f"  KATEGORI: {category['de']}")
    print(f"  BEDEN: {size}")
    print(f"  MARKA: {brand or 'Bilinmiyor'}")
    print(f"  RENKLER: {', '.join(colors)}")
    print(f"  PAKET: {package_size}")
    print(f"{'='*50}")

    # 1. Go to upload page
    print("\n[1] Upload sayfasi...")
    page.goto('https://www.vinted.de/items/new', wait_until='networkidle', timeout=60000)
    time.sleep(2)
    human.between_actions()

    # 2. Upload images
    print("[2] Resimler...")
    if images_path and os.path.exists(images_path):
        images = sorted([
            os.path.join(images_path, f)
            for f in os.listdir(images_path)
            if f.lower().endswith(('.jpg', '.jpeg', '.png'))
        ])[:10]

        if images:
            file_input = page.query_selector('input[type="file"]')
            if file_input:
                file_input.set_input_files(images)
                print(f"    {len(images)} resim yukleniyor...")
                time.sleep(3 + len(images))

    human.between_actions()

    # 3. Fill title
    print("[3] Baslik...")
    title_selectors = [
        '[data-testid="title-input"]',
        'input[name="title"]',
        'input[placeholder*="Titel"]',
    ]
    for sel in title_selectors:
        if human.fill_field(sel, title):
            print(f"    OK: {title[:35]}...")
            break

    human.between_actions()

    # 4. Select category (KRITIK - sonrasında ek alanlar açılır)
    print("[4] Kategori seciliyor...")
    time.sleep(2)  # Wait for page to stabilize

    # Use the new unified category selection function
    if select_category_vinted(page, category, human):
        print(f"    [OK] Kategori secildi: {category['de']}")
    else:
        print("    [WARN] Kategori secilemedi - manuel secin!")

    # Wait for additional fields to load after category selection
    print("[5] Ek alanlar yukleniyor...")
    time.sleep(2)
    human.random_scroll()
    time.sleep(1)

    # 5. Select SIZE (appears after category)
    print("[6] Größe (Beden)...")
    if select_size(page, size, category['type'], human):
        print(f"    OK: {size}")
    else:
        print(f"    [SKIP] Beden: {size}")
    human.between_actions()

    # 6. Select BRAND (appears after category)
    print("[7] Marke...")
    if brand:
        if select_brand(page, brand, human):
            print(f"    OK: {brand}")
        else:
            print(f"    [SKIP] Marka: {brand}")
    else:
        print("    [SKIP] Marka bilinmiyor")
    human.between_actions()

    # 7. Fill description
    print("[8] Aciklama...")
    desc_selectors = [
        '[data-testid="description-textarea"]',
        'textarea[name="description"]',
        'textarea[placeholder*="Beschreib"]',
    ]
    for sel in desc_selectors:
        if human.fill_field(sel, desc):
            print(f"    OK: {len(desc)} karakter")
            break

    human.between_actions()

    # 8. Select condition (Zustand)
    print("[9] Zustand...")
    if select_condition(page, human):
        print("    OK: Gut")
    else:
        print("    [SKIP]")
    human.between_actions()

    # 9. Select colors
    print("[10] Farbe...")
    if select_colors(page, colors, human):
        print(f"    OK: {', '.join(colors)}")
    else:
        print("    [SKIP]")
    human.between_actions()

    # 10. Fill price
    print("[11] Preis...")
    if fill_price(page, price, human):
        print(f"    OK: {price} EUR")
    else:
        print("    [SKIP] - Manuel girin!")
    human.between_actions()

    # 11. Select package size
    print("[12] Paketgröße...")
    if select_package_size(page, package_size, human):
        print(f"    OK: {package_size}")
    else:
        print("    [SKIP]")

    # Scroll to bottom
    page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
    time.sleep(1)

    # Take screenshot
    ss_path = os.path.join(DATA_DIR, f'upload_{product.get("id", 0)}_ready.png')
    page.screenshot(path=ss_path, full_page=True)
    print(f"\n    Screenshot: {ss_path}")

    # Summary
    print("\n" + "="*50)
    print("  FORM HAZIR!")
    print(f"  Kategori: {category['de']}")
    print(f"  Beden: {size}")
    print(f"  Marka: {brand or '-'}")
    print(f"  Fiyat: {price} EUR")
    print("="*50)

    # Wait 3 seconds then auto-publish
    print("\n[AUTO] 3 saniye sonra yayinlanacak...")
    time.sleep(3)

    # 11. Click publish
    print("[10] Hochladen...")
    publish_clicked = False

    publish_selectors = [
        'button:has-text("Hochladen")',
        'button:has-text("Artikel hochladen")',
        'button[type="submit"]:has-text("Hochladen")',
        'button[data-testid="submit-button"]',
    ]

    for sel in publish_selectors:
        try:
            btn = page.query_selector(sel)
            if btn and btn.is_visible():
                btn.scroll_into_view_if_needed()
                time.sleep(0.3)
                btn.click()
                publish_clicked = True
                print("    Buton tiklandi!")
                break
        except:
            continue

    if not publish_clicked:
        try:
            page.locator('button:has-text("Hochladen")').first.click()
            publish_clicked = True
        except:
            print("    [WARN] Buton bulunamadi!")

    # Wait for result
    time.sleep(5)

    # Check URL
    current_url = page.url
    if '/items/' in current_url and '/new' not in current_url:
        print("\n[OK] URUN YAYINLANDI!")
        return True
    else:
        print(f"\n[INFO] URL: {current_url}")
        return True  # Assume success


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--account', choices=['cyhn54', 'cssberlin'], default='cssberlin')
    parser.add_argument('--skip-check', action='store_true', help='Skip network check prompt')
    args = parser.parse_args()

    print_banner()

    account = args.account
    print(f"\n[INFO] Hesap: {account}")
    print(f"[INFO] Ag: {ACCOUNTS[account]['network']}")

    if account == 'cssberlin' and not args.skip_check:
        print("\n!!! KONTROL !!!")
        print("  - Mobil Hotspot ACIK mi?")
        print("  - Every Proxy AKTIF mi?")
        print("  - Ev WiFi KAPALI mi?")
        try:
            input("\nDevam etmek icin ENTER...")
        except EOFError:
            print("\n[AUTO] Devam ediliyor...")

    # Launch browser
    pw, context, page = launch_browser(account)

    try:
        # Go to Vinted
        print("\n[*] Vinted.de...")
        page.goto('https://www.vinted.de/', wait_until='networkidle', timeout=60000)
        time.sleep(2)

        # Handle cookie popup first
        handle_cookie_popup(page)
        time.sleep(1)

        # Check login
        if not check_login_status(page):
            if not wait_for_manual_login(page):
                print("[ERROR] Login basarisiz!")
                return
        else:
            print("[OK] Zaten giris yapilmis!")

        # Save session after login
        time.sleep(1)

        # Initialize human behavior
        human = HumanBehavior(page)

        # Get products
        products = db.get_products_by_status(STATUS_VALIDATED)
        print(f"\n[INFO] {len(products)} urun hazir")

        if not products:
            print("[INFO] Yuklenecek urun yok!")
            return

        # Upload products
        uploaded = 0
        for i, product in enumerate(products):
            print(f"\n{'#'*60}")
            print(f"  URUN {i+1}/{len(products)}")
            print(f"{'#'*60}")

            try:
                if upload_product(page, human, product):
                    db.update_product(product['id'], {
                        'status': STATUS_UPLOADED,
                        'target_store': account
                    })
                    db.add_log(product['id'], 'upload', 'success', f'Uploaded to {account}')
                    uploaded += 1

                # Delay between products
                if i < len(products) - 1:
                    delay = random.randint(45, 90)
                    print(f"\n[WAIT] Sonraki urun icin {delay}s...")
                    for remaining in range(delay, 0, -1):
                        print(f"\r  {remaining}s...", end='', flush=True)
                        time.sleep(1)
                    print()

            except Exception as e:
                print(f"\n[ERROR] {e}")
                db.add_log(product['id'], 'upload', 'failed', str(e))
                time.sleep(3)

        # Summary
        print(f"\n{'='*60}")
        print(f"  TAMAMLANDI: {uploaded}/{len(products)}")
        print(f"{'='*60}")

        # Keep browser open for review
        print("\n[INFO] Tarayici 60 saniye acik kalacak...")
        time.sleep(60)

    finally:
        context.close()
        pw.stop()


if __name__ == '__main__':
    main()
