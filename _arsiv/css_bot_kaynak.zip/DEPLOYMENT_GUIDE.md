# TATANGA - Deployment Guide

**Server:** Hetzner CX23 (Nurnberg, Germany)
**IP:** 195.201.146.224
**OS:** Ubuntu 22.04 LTS
**Target:** Production deployment

---

## Table of Contents

1. [Server Preparation](#1-server-preparation)
2. [Software Installation](#2-software-installation)
3. [TATANGA Deployment](#3-tatanga-deployment)
4. [Service Configuration](#4-service-configuration)
5. [Nginx Reverse Proxy](#5-nginx-reverse-proxy)
6. [SSL/TLS Setup](#6-ssltls-setup)
7. [Monitoring & Logging](#7-monitoring--logging)
8. [Backup Strategy](#8-backup-strategy)
9. [Troubleshooting](#9-troubleshooting)

---

## 1. Server Preparation

### 1.1 SSH Connection

**Connect to Hetzner server:**

```bash
# From Windows (PowerShell/Command Prompt)
ssh root@195.201.146.224

# Enter password: P3Cf3wbbTRwC
```

**First login - Create non-root user:**

```bash
# Create user
adduser tatanga
usermod -aG sudo tatanga

# Copy SSH key (optional but recommended)
su - tatanga
mkdir ~/.ssh
chmod 700 ~/.ssh
# Copy your public key to ~/.ssh/authorized_keys

# Test sudo
sudo apt update
```

### 1.2 System Update

```bash
# Update system
sudo apt update
sudo apt upgrade -y

# Install essential tools
sudo apt install -y \
    build-essential \
    git \
    curl \
    wget \
    htop \
    vim \
    tmux \
    ufw \
    fail2ban
```

### 1.3 Firewall Configuration

```bash
# Configure UFW firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Allow SSH (port 22)
sudo ufw allow 22/tcp

# Allow HTTP (port 80)
sudo ufw allow 80/tcp

# Allow HTTPS (port 443)
sudo ufw allow 443/tcp

# Enable firewall
sudo ufw enable

# Check status
sudo ufw status verbose
```

### 1.4 Fail2Ban (Security)

```bash
# Install fail2ban
sudo apt install -y fail2ban

# Create local config
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local

# Edit config
sudo vim /etc/fail2ban/jail.local

# Add/modify:
[sshd]
enabled = true
port = 22
maxretry = 3
bantime = 3600

# Start fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban

# Check status
sudo fail2ban-client status
```

---

## 2. Software Installation

### 2.1 Python 3.10+

```bash
# Add deadsnakes PPA (for latest Python)
sudo add-apt-repository ppa:deadsnakes/ppa
sudo apt update

# Install Python 3.10
sudo apt install -y python3.10 python3.10-venv python3.10-dev

# Install pip
curl -sS https://bootstrap.pypa.io/get-pip.py | sudo python3.10

# Verify
python3.10 --version  # Should be 3.10.x
pip3.10 --version
```

### 2.2 Chrome & ChromeDriver (for Selenium)

```bash
# Install Chrome
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo apt install -y ./google-chrome-stable_current_amd64.deb

# Verify Chrome
google-chrome --version

# Install ChromeDriver
# Get version matching Chrome version
CHROME_VERSION=$(google-chrome --version | grep -oP '\d+\.\d+\.\d+')
CHROMEDRIVER_VERSION=$(curl -s https://chromedriver.storage.googleapis.com/LATEST_RELEASE_${CHROME_VERSION%.*})

wget https://chromedriver.storage.googleapis.com/${CHROMEDRIVER_VERSION}/chromedriver_linux64.zip
unzip chromedriver_linux64.zip
sudo mv chromedriver /usr/local/bin/
sudo chmod +x /usr/local/bin/chromedriver

# Verify ChromeDriver
chromedriver --version

# Install Xvfb (headless display)
sudo apt install -y xvfb

# Create Xvfb service
sudo vim /etc/systemd/system/xvfb.service

# Add:
[Unit]
Description=X Virtual Frame Buffer Service
After=network.target

[Service]
ExecStart=/usr/bin/Xvfb :99 -screen 0 1920x1080x24

[Install]
WantedBy=multi-user.target

# Start Xvfb
sudo systemctl enable xvfb
sudo systemctl start xvfb

# Set DISPLAY environment variable
export DISPLAY=:99
```

### 2.3 Git Configuration

```bash
# Configure git
git config --global user.name "TATANGA Server"
git config --global user.email "server@tatanga.local"

# Generate SSH key for GitHub
ssh-keygen -t ed25519 -C "server@tatanga.local"

# Add to GitHub
cat ~/.ssh/id_ed25519.pub
# Copy output and add to GitHub: Settings → SSH Keys
```

---

## 3. TATANGA Deployment

### 3.1 Clone Repository

```bash
# Create application directory
sudo mkdir -p /opt/tatanga
sudo chown tatanga:tatanga /opt/tatanga

# Clone repository
cd /opt/tatanga
git clone <YOUR_REPO_URL> .

# If using local files, upload via scp:
# From Windows:
scp -r "C:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces" tatanga@195.201.146.224:/opt/tatanga/
```

### 3.2 Virtual Environment

```bash
# Create virtual environment
cd /opt/tatanga
python3.10 -m venv venv

# Activate
source venv/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements_tatanga.txt

# Verify installation
pip list | grep -E "(requests|selenium|groq|cryptography)"
```

### 3.3 Configuration

```bash
# Create config directory
mkdir -p /opt/tatanga/active_pieces/config
mkdir -p /opt/tatanga/active_pieces/storage
mkdir -p /opt/tatanga/logs

# Copy credentials (from local machine)
# From Windows:
scp "C:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces\config\credentials.py" \
    tatanga@195.201.146.224:/opt/tatanga/active_pieces/config/

# Set restrictive permissions
chmod 600 /opt/tatanga/active_pieces/config/credentials.py

# Initialize databases
cd /opt/tatanga
source venv/bin/activate
python3 -c "
from active_pieces.core.database import init_database
init_database()
print('Databases initialized!')
"
```

### 3.4 Environment Variables

```bash
# Create .env file
vim /opt/tatanga/.env

# Add:
TATANGA_ENV=production
TATANGA_LOG_LEVEL=INFO
DISPLAY=:99
GROQ_API_KEY=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
TELEGRAM_BOT_TOKEN=<YOUR_BOT_TOKEN>
TELEGRAM_CHAT_ID=<YOUR_CHAT_ID>

# Secure .env
chmod 600 /opt/tatanga/.env

# Load env vars automatically
echo "source /opt/tatanga/.env" >> ~/.bashrc
```

---

## 4. Service Configuration

### 4.1 Flask Webhook Server (Systemd Service)

```bash
# Create service file
sudo vim /etc/systemd/system/tatanga-webhook.service

# Add:
[Unit]
Description=TATANGA Webhook Server
After=network.target

[Service]
Type=simple
User=tatanga
WorkingDirectory=/opt/tatanga
Environment="PATH=/opt/tatanga/venv/bin"
Environment="DISPLAY=:99"
ExecStart=/opt/tatanga/venv/bin/python active_pieces/integrations/activepieces_webhook.py

Restart=always
RestartSec=10

StandardOutput=append:/opt/tatanga/logs/webhook.log
StandardError=append:/opt/tatanga/logs/webhook-error.log

[Install]
WantedBy=multi-user.target
```

**Enable and start:**

```bash
sudo systemctl daemon-reload
sudo systemctl enable tatanga-webhook
sudo systemctl start tatanga-webhook

# Check status
sudo systemctl status tatanga-webhook

# View logs
tail -f /opt/tatanga/logs/webhook.log
```

### 4.2 Telegram Bot Service

```bash
# Create service
sudo vim /etc/systemd/system/tatanga-telegram.service

# Add:
[Unit]
Description=TATANGA Telegram Bot
After=network.target

[Service]
Type=simple
User=tatanga
WorkingDirectory=/opt/tatanga
Environment="PATH=/opt/tatanga/venv/bin"
ExecStart=/opt/tatanga/venv/bin/python active_pieces/integrations/telegram_bot.py

Restart=always
RestartSec=10

StandardOutput=append:/opt/tatanga/logs/telegram.log
StandardError=append:/opt/tatanga/logs/telegram-error.log

[Install]
WantedBy=multi-user.target
```

**Enable and start:**

```bash
sudo systemctl daemon-reload
sudo systemctl enable tatanga-telegram
sudo systemctl start tatanga-telegram

# Check status
sudo systemctl status tatanga-telegram
```

### 4.3 Stock Monitor Service (Optional)

```bash
# Create service
sudo vim /etc/systemd/system/tatanga-stockmonitor.service

# Add:
[Unit]
Description=TATANGA Stock Monitor
After=network.target

[Service]
Type=simple
User=tatanga
WorkingDirectory=/opt/tatanga
Environment="PATH=/opt/tatanga/venv/bin"
Environment="DISPLAY=:99"
ExecStart=/opt/tatanga/venv/bin/python active_pieces/stock_monitor.py

Restart=always
RestartSec=300

StandardOutput=append:/opt/tatanga/logs/stockmonitor.log
StandardError=append:/opt/tatanga/logs/stockmonitor-error.log

[Install]
WantedBy=multi-user.target
```

**Enable and start:**

```bash
sudo systemctl daemon-reload
sudo systemctl enable tatanga-stockmonitor
sudo systemctl start tatanga-stockmonitor
```

### 4.4 Manage All Services

```bash
# Start all
sudo systemctl start tatanga-webhook tatanga-telegram tatanga-stockmonitor

# Stop all
sudo systemctl stop tatanga-webhook tatanga-telegram tatanga-stockmonitor

# Restart all
sudo systemctl restart tatanga-webhook tatanga-telegram tatanga-stockmonitor

# Check status all
sudo systemctl status tatanga-webhook tatanga-telegram tatanga-stockmonitor

# View logs
journalctl -u tatanga-webhook -f
journalctl -u tatanga-telegram -f
```

---

## 5. Nginx Reverse Proxy

### 5.1 Install Nginx

```bash
# Install
sudo apt install -y nginx

# Start and enable
sudo systemctl enable nginx
sudo systemctl start nginx

# Check status
sudo systemctl status nginx
```

### 5.2 Configure Reverse Proxy

```bash
# Create site config
sudo vim /etc/nginx/sites-available/tatanga

# Add:
server {
    listen 80;
    server_name 195.201.146.224 api.tatanga.local;

    # Webhook endpoint
    location /webhook/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # WebSocket support (if needed)
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    # API endpoints
    location /api/ {
        proxy_pass http://127.0.0.1:5000/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # Status page
    location /status {
        proxy_pass http://127.0.0.1:5000/status;
        proxy_set_header Host $host;
    }

    # Logs
    access_log /var/log/nginx/tatanga-access.log;
    error_log /var/log/nginx/tatanga-error.log;
}
```

**Enable site:**

```bash
# Create symlink
sudo ln -s /etc/nginx/sites-available/tatanga /etc/nginx/sites-enabled/

# Test config
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx
```

### 5.3 Test Reverse Proxy

```bash
# From server
curl http://localhost/status

# From external
curl http://195.201.146.224/status

# Should return TATANGA status JSON
```

---

## 6. SSL/TLS Setup

### 6.1 Let's Encrypt (Free SSL)

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Obtain certificate (if you have domain)
sudo certbot --nginx -d api.tatanga.yourdomain.com

# If using IP only, create self-signed certificate:
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /etc/ssl/private/tatanga-selfsigned.key \
    -out /etc/ssl/certs/tatanga-selfsigned.crt \
    -subj "/C=DE/ST=Bavaria/L=Nuremberg/O=TATANGA/CN=195.201.146.224"
```

### 6.2 Update Nginx for HTTPS

```bash
# Edit config
sudo vim /etc/nginx/sites-available/tatanga

# Add HTTPS server block:
server {
    listen 443 ssl http2;
    server_name 195.201.146.224;

    # SSL certificates
    ssl_certificate /etc/ssl/certs/tatanga-selfsigned.crt;
    ssl_certificate_key /etc/ssl/private/tatanga-selfsigned.key;

    # SSL configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512;
    ssl_session_cache shared:SSL:10m;

    # Locations (same as HTTP)
    location /webhook/ {
        proxy_pass http://127.0.0.1:5000;
        # ... (same proxy settings)
    }
}

# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name 195.201.146.224;
    return 301 https://$server_name$request_uri;
}
```

**Reload Nginx:**

```bash
sudo nginx -t
sudo systemctl reload nginx
```

---

## 7. Monitoring & Logging

### 7.1 Log Rotation

```bash
# Create logrotate config
sudo vim /etc/logrotate.d/tatanga

# Add:
/opt/tatanga/logs/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    create 0640 tatanga tatanga
    sharedscripts
    postrotate
        systemctl reload tatanga-webhook tatanga-telegram tatanga-stockmonitor > /dev/null 2>&1 || true
    endscript
}
```

### 7.2 System Monitoring

```bash
# Install monitoring tools
sudo apt install -y htop iotop nethogs

# Real-time monitoring
htop             # CPU, memory
iotop -o         # Disk I/O
nethogs          # Network bandwidth

# Service status dashboard
watch -n 5 'sudo systemctl status tatanga-* --no-pager'
```

### 7.3 Application Monitoring

```bash
# Create monitoring script
vim /opt/tatanga/scripts/monitor.sh

# Add:
#!/bin/bash

echo "=== TATANGA System Monitor ==="
echo

echo "--- Service Status ---"
systemctl is-active tatanga-webhook tatanga-telegram tatanga-stockmonitor

echo
echo "--- Database Size ---"
du -sh /opt/tatanga/active_pieces/storage/*.db

echo
echo "--- Disk Usage ---"
df -h /opt/tatanga

echo
echo "--- Memory Usage ---"
free -h

echo
echo "--- Recent Errors ---"
tail -20 /opt/tatanga/logs/*-error.log

# Make executable
chmod +x /opt/tatanga/scripts/monitor.sh

# Run
/opt/tatanga/scripts/monitor.sh
```

### 7.4 Cron Jobs

```bash
# Edit crontab
crontab -e

# Add:
# Monitor system every 5 minutes
*/5 * * * * /opt/tatanga/scripts/monitor.sh >> /opt/tatanga/logs/monitor.log 2>&1

# Backup database daily at 2 AM
0 2 * * * /opt/tatanga/scripts/backup.sh

# Clean old logs weekly
0 0 * * 0 find /opt/tatanga/logs -name "*.log" -mtime +30 -delete
```

---

## 8. Backup Strategy

### 8.1 Database Backup

```bash
# Create backup script
vim /opt/tatanga/scripts/backup.sh

# Add:
#!/bin/bash

BACKUP_DIR="/opt/tatanga/backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup databases
cp /opt/tatanga/active_pieces/storage/tatanga.db \
   $BACKUP_DIR/tatanga_$DATE.db

cp /opt/tatanga/active_pieces/storage/translation_cache.db \
   $BACKUP_DIR/translation_cache_$DATE.db

cp /opt/tatanga/active_pieces/storage/kleinanzeigen_selectors.db \
   $BACKUP_DIR/kleinanzeigen_selectors_$DATE.db

# Compress
tar -czf $BACKUP_DIR/backup_$DATE.tar.gz \
    $BACKUP_DIR/tatanga_$DATE.db \
    $BACKUP_DIR/translation_cache_$DATE.db \
    $BACKUP_DIR/kleinanzeigen_selectors_$DATE.db

# Remove individual files
rm $BACKUP_DIR/tatanga_$DATE.db
rm $BACKUP_DIR/translation_cache_$DATE.db
rm $BACKUP_DIR/kleinanzeigen_selectors_$DATE.db

# Delete backups older than 30 days
find $BACKUP_DIR -name "backup_*.tar.gz" -mtime +30 -delete

echo "Backup completed: backup_$DATE.tar.gz"

# Make executable
chmod +x /opt/tatanga/scripts/backup.sh

# Test
/opt/tatanga/scripts/backup.sh
```

### 8.2 Remote Backup (Optional)

```bash
# Install rclone (for cloud backup)
curl https://rclone.org/install.sh | sudo bash

# Configure rclone (Google Drive, Dropbox, etc.)
rclone config

# Add to backup script:
# Upload to cloud
rclone copy $BACKUP_DIR/backup_$DATE.tar.gz remote:tatanga-backups/
```

---

## 9. Troubleshooting

### 9.1 Service Won't Start

```bash
# Check service status
sudo systemctl status tatanga-webhook -l

# Check logs
journalctl -u tatanga-webhook -n 50

# Check Python path
/opt/tatanga/venv/bin/python --version

# Test manually
cd /opt/tatanga
source venv/bin/activate
python active_pieces/integrations/activepieces_webhook.py
# (Ctrl+C to stop)
```

### 9.2 ChromeDriver Issues

```bash
# Check Chrome version
google-chrome --version

# Check ChromeDriver version
chromedriver --version

# Versions must match!

# Test Selenium
cd /opt/tatanga
source venv/bin/activate
python -c "
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

options = Options()
options.add_argument('--headless')
options.add_argument('--no-sandbox')

driver = webdriver.Chrome(options=options)
driver.get('https://www.google.com')
print('Title:', driver.title)
driver.quit()
print('Selenium working!')
"
```

### 9.3 Database Locked

```bash
# Check for processes using database
lsof /opt/tatanga/active_pieces/storage/tatanga.db

# Kill stuck processes
kill -9 <PID>

# Restart services
sudo systemctl restart tatanga-webhook
```

### 9.4 Port Already in Use

```bash
# Check what's using port 5000
sudo lsof -i :5000

# Kill process
kill -9 <PID>

# Or change port in webhook config
vim /opt/tatanga/active_pieces/integrations/activepieces_webhook.py
# Change: app.run(host='0.0.0.0', port=5001)
```

### 9.5 Nginx 502 Bad Gateway

```bash
# Check if Flask is running
curl http://127.0.0.1:5000/status

# Check Nginx error log
sudo tail -f /var/log/nginx/tatanga-error.log

# Check SELinux (if enabled)
sudo setenforce 0  # Permissive mode

# Restart services
sudo systemctl restart tatanga-webhook
sudo systemctl restart nginx
```

---

## Quick Commands Reference

```bash
# Start all services
sudo systemctl start tatanga-webhook tatanga-telegram tatanga-stockmonitor

# Check status
sudo systemctl status tatanga-*

# View logs
tail -f /opt/tatanga/logs/*.log

# Backup now
/opt/tatanga/scripts/backup.sh

# Monitor system
/opt/tatanga/scripts/monitor.sh

# Restart everything
sudo systemctl restart tatanga-* nginx

# Update code
cd /opt/tatanga
git pull
source venv/bin/activate
pip install -r requirements_tatanga.txt --upgrade
sudo systemctl restart tatanga-*
```

---

## Post-Deployment Checklist

- [ ] SSH connection successful
- [ ] Non-root user created
- [ ] Firewall configured
- [ ] Fail2ban active
- [ ] Python 3.10+ installed
- [ ] Chrome + ChromeDriver installed
- [ ] Virtual environment created
- [ ] Dependencies installed
- [ ] Credentials configured
- [ ] Databases initialized
- [ ] Webhook service running
- [ ] Telegram bot running
- [ ] Nginx reverse proxy working
- [ ] SSL certificate installed
- [ ] Logs rotating properly
- [ ] Backup script scheduled
- [ ] Monitoring active

---

**Deployment Complete!** 🎉

TATANGA is now running on Hetzner server `195.201.146.224`.

Access webhook: `https://195.201.146.224/webhook/`
Check status: `https://195.201.146.224/status`
