#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
INBOX AGENT - Incoming Messages Handler
24/7 Platform message monitoring and processing

Features:
- Monitors all platforms for new seller messages
- Auto-translates incoming messages
- Risk analysis with AI
- Sentiment detection
- Telegram notifications with interactive buttons
- Auto-response suggestions

Author: TATANGA Team
Version: 1.0
"""

import sys
import json
import sqlite3
import asyncio
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents.base_agent import BaseAgent, AgentConfig
from integrations.smart_translator import SmartTranslator


@dataclass
class IncomingMessage:
    """Represents an incoming platform message"""
    id: str
    platform: str
    conversation_id: str
    product_id: Optional[int]
    sender_id: str
    sender_name: str
    message: str
    language: str
    timestamp: datetime
    is_read: bool = False
    translated: Optional[str] = None
    risk_score: int = 50
    sentiment: str = 'neutral'
    suggested_reply: Optional[str] = None


class InboxAgent(BaseAgent):
    """
    24/7 Incoming Message Handler

    Monitors platform messages and processes them:
    - Translation
    - Risk analysis
    - Sentiment detection
    - Telegram notification
    - Auto-response suggestion

    Usage:
        agent = InboxAgent(interval_seconds=60)
        agent.start()

        # Stop agent
        agent.stop()
    """

    # Risk keywords by category
    RISK_KEYWORDS = {
        'positive': {
            'de': ['ja', 'verfügbar', 'noch da', 'gerne', 'klar', 'natürlich', 'sofort'],
            'en': ['yes', 'available', 'sure', 'absolutely', 'of course', 'ready'],
            'fr': ['oui', 'disponible', 'bien sûr', 'absolument', 'prêt'],
            'tr': ['evet', 'mevcut', 'tabii', 'hazır', 'olur']
        },
        'negative': {
            'de': ['nein', 'verkauft', 'reserviert', 'nicht mehr', 'leider', 'schade'],
            'en': ['no', 'sold', 'reserved', 'not available', 'sorry', 'unfortunately'],
            'fr': ['non', 'vendu', 'réservé', 'plus disponible', 'désolé'],
            'tr': ['hayır', 'satıldı', 'rezerve', 'yok', 'maalesef']
        },
        'suspicious': {
            'de': ['banküberweisung', 'paypal friends', 'außerhalb', 'whatsapp', 'telegram', 'privat'],
            'en': ['bank transfer', 'paypal friends', 'outside', 'whatsapp', 'telegram', 'private'],
            'fr': ['virement', 'paypal amis', 'dehors', 'whatsapp', 'telegram', 'privé'],
            'tr': ['havale', 'paypal arkadaş', 'dışında', 'whatsapp', 'telegram', 'özel']
        }
    }

    # Suggested replies by sentiment
    REPLY_TEMPLATES = {
        'positive': {
            'de': "Vielen Dank für Ihre Antwort! Was wäre Ihr bester Preis?",
            'en': "Thank you for your reply! What would be your best price?",
            'fr': "Merci pour votre réponse ! Quel serait votre meilleur prix ?",
            'tr': "Cevabınız için teşekkürler! En iyi fiyatınız ne olurdu?"
        },
        'neutral': {
            'de': "Danke für Ihre Nachricht. Ist der Artikel noch verfügbar?",
            'en': "Thanks for your message. Is the item still available?",
            'fr': "Merci pour votre message. L'article est-il toujours disponible ?",
            'tr': "Mesajınız için teşekkürler. Ürün hala mevcut mu?"
        },
        'negative': None  # No auto-reply for negative sentiment
    }

    def __init__(self, interval_seconds: int = 60):
        """
        Initialize Inbox Agent

        Args:
            interval_seconds: How often to check for new messages
        """
        config = AgentConfig(
            name="inbox",
            interval_seconds=interval_seconds,
            max_retries=3,
            retry_delay_seconds=5
        )
        super().__init__(config)

        # Initialize translator
        try:
            self.translator = SmartTranslator()
        except Exception as e:
            self.logger.warning(f"Translator init failed: {e}")
            self.translator = None

        # Message queue database
        self.queue_db = Path(__file__).parent.parent / 'storage' / 'message_queue.db'
        self._init_queue_db()

        # Stats
        self.messages_processed = 0
        self.messages_notified = 0

        # Active platforms to monitor
        self.active_platforms = [
            'vinted_de', 'vinted_fr', 'vinted_uk',
            'ebay_de', 'ebay_uk',
            'kleinanzeigen',
            'tradera'
        ]

    def _init_queue_db(self):
        """Initialize message queue database"""
        self.queue_db.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        # Message queue table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS message_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                direction TEXT NOT NULL,
                platform TEXT NOT NULL,
                conversation_id TEXT,
                product_id INTEGER,
                sender TEXT,
                recipient TEXT,
                message_original TEXT,
                message_translated TEXT,
                language TEXT,
                status TEXT DEFAULT 'pending',
                priority TEXT DEFAULT 'normal',
                risk_score INTEGER DEFAULT 50,
                sentiment TEXT DEFAULT 'neutral',
                suggested_reply TEXT,
                requires_approval INTEGER DEFAULT 0,
                approved_at DATETIME,
                sent_at DATETIME,
                notified_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                error_message TEXT
            )
        """)

        # Index for pending messages
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_queue_direction_status
            ON message_queue(direction, status, created_at)
        """)

        conn.commit()
        conn.close()

    async def setup(self):
        """Setup hook - called before first process"""
        self.logger.info("Inbox Agent starting up")

        if not self.translator or not self.translator.groq:
            self.logger.warning("AI translation not available")
        else:
            self.logger.info("AI translation ready")

    async def process(self) -> Dict[str, Any]:
        """
        Main processing loop - check for new messages and process them

        Returns:
            Processing result summary
        """
        results = {
            'processed': 0,
            'notified': 0,
            'errors': 0
        }

        # Get pending incoming messages
        messages = self._get_pending_messages()

        if not messages:
            return {'status': 'idle', 'message': 'No pending messages'}

        self.logger.info(f"Processing {len(messages)} incoming messages")

        for msg in messages:
            try:
                # Process message
                processed_msg = await self._process_message(msg)

                # Update database
                self._update_message(processed_msg)

                # Send Telegram notification
                notified = await self._notify_telegram(processed_msg)

                if notified:
                    results['notified'] += 1
                    self.messages_notified += 1

                results['processed'] += 1
                self.messages_processed += 1

            except Exception as e:
                results['errors'] += 1
                self.logger.error(f"Message processing error: {e}")
                self._mark_error(msg['id'], str(e))

        results['total_processed'] = self.messages_processed
        results['total_notified'] = self.messages_notified

        return results

    async def _process_message(self, msg: Dict) -> Dict:
        """
        Process a single incoming message

        Args:
            msg: Raw message from database

        Returns:
            Processed message with translation, risk, sentiment
        """
        message_text = msg['message_original']

        # 1. Detect language and translate
        translated = message_text
        detected_lang = 'de'  # default

        if self.translator:
            try:
                detected_lang = self.translator.detect_language(message_text)
                if detected_lang != 'tr':  # Always translate to Turkish for operator
                    translated = self.translator.translate(message_text, 'tr', detected_lang)
            except Exception as e:
                self.logger.warning(f"Translation failed: {e}")

        # 2. Calculate risk score
        risk_score = self._calculate_risk(message_text, detected_lang)

        # 3. Detect sentiment
        sentiment = self._detect_sentiment(message_text, detected_lang)

        # 4. Generate suggested reply
        suggested_reply = self._generate_reply(sentiment, detected_lang)

        return {
            **msg,
            'message_translated': translated,
            'language': detected_lang,
            'risk_score': risk_score,
            'sentiment': sentiment,
            'suggested_reply': suggested_reply,
            'status': 'processed'
        }

    def _calculate_risk(self, message: str, language: str) -> int:
        """
        Calculate risk score based on message content

        Args:
            message: Original message text
            language: Detected language

        Returns:
            Risk score (0-100, lower is better)
        """
        message_lower = message.lower()
        score = 50  # Neutral default

        # Check positive keywords (reduce risk)
        positive_words = self.RISK_KEYWORDS['positive'].get(language, [])
        for word in positive_words:
            if word in message_lower:
                score -= 10

        # Check negative keywords (increase risk)
        negative_words = self.RISK_KEYWORDS['negative'].get(language, [])
        for word in negative_words:
            if word in message_lower:
                score += 15

        # Check suspicious keywords (high risk)
        suspicious_words = self.RISK_KEYWORDS['suspicious'].get(language, [])
        for word in suspicious_words:
            if word in message_lower:
                score += 25

        # Clamp between 0-100
        return max(0, min(100, score))

    def _detect_sentiment(self, message: str, language: str) -> str:
        """
        Detect message sentiment

        Args:
            message: Original message text
            language: Detected language

        Returns:
            Sentiment: 'positive', 'negative', or 'neutral'
        """
        message_lower = message.lower()

        # Count positive vs negative indicators
        positive_count = 0
        negative_count = 0

        positive_words = self.RISK_KEYWORDS['positive'].get(language, [])
        for word in positive_words:
            if word in message_lower:
                positive_count += 1

        negative_words = self.RISK_KEYWORDS['negative'].get(language, [])
        for word in negative_words:
            if word in message_lower:
                negative_count += 1

        if positive_count > negative_count:
            return 'positive'
        elif negative_count > positive_count:
            return 'negative'
        else:
            return 'neutral'

    def _generate_reply(self, sentiment: str, language: str) -> Optional[str]:
        """
        Generate suggested reply based on sentiment

        Args:
            sentiment: Message sentiment
            language: Target language for reply

        Returns:
            Suggested reply text or None
        """
        templates = self.REPLY_TEMPLATES.get(sentiment)
        if templates is None:
            return None

        # Get template in detected language, fallback to German
        return templates.get(language, templates.get('de'))

    def _get_pending_messages(self) -> List[Dict]:
        """Get pending incoming messages from queue"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, direction, platform, conversation_id, product_id,
                   sender, message_original, language, created_at
            FROM message_queue
            WHERE direction = 'inbox' AND status = 'pending'
            ORDER BY created_at
            LIMIT 20
        """)

        rows = cursor.fetchall()
        conn.close()

        return [
            {
                'id': row[0],
                'direction': row[1],
                'platform': row[2],
                'conversation_id': row[3],
                'product_id': row[4],
                'sender': row[5],
                'message_original': row[6],
                'language': row[7],
                'created_at': row[8]
            }
            for row in rows
        ]

    def _update_message(self, msg: Dict):
        """Update processed message in database"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE message_queue
            SET message_translated = ?,
                language = ?,
                risk_score = ?,
                sentiment = ?,
                suggested_reply = ?,
                status = ?
            WHERE id = ?
        """, (
            msg.get('message_translated'),
            msg.get('language'),
            msg.get('risk_score'),
            msg.get('sentiment'),
            msg.get('suggested_reply'),
            msg.get('status', 'processed'),
            msg['id']
        ))

        conn.commit()
        conn.close()

    def _mark_error(self, msg_id: int, error: str):
        """Mark message as failed"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE message_queue
            SET status = 'error', error_message = ?
            WHERE id = ?
        """, (error, msg_id))

        conn.commit()
        conn.close()

    def _mark_notified(self, msg_id: int):
        """Mark message as notified"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE message_queue
            SET status = 'notified', notified_at = datetime('now')
            WHERE id = ?
        """, (msg_id,))

        conn.commit()
        conn.close()

    async def _notify_telegram(self, msg: Dict) -> bool:
        """
        Send Telegram notification for processed message

        Args:
            msg: Processed message data

        Returns:
            True if notification sent successfully
        """
        try:
            # Import telegram bot
            from integrations.telegram_bot import TatangaTelegramBot

            bot = TatangaTelegramBot()

            # Build notification message
            risk_emoji = "🟢" if msg['risk_score'] < 30 else "🟡" if msg['risk_score'] < 60 else "🔴"
            sentiment_emoji = "😊" if msg['sentiment'] == 'positive' else "😐" if msg['sentiment'] == 'neutral' else "😟"

            notification = (
                f"📥 *GELEN MESAJ*\n\n"
                f"📱 Platform: `{msg['platform']}`\n"
                f"👤 Satıcı: {msg.get('sender', 'Unknown')}\n"
                f"🌐 Dil: {msg.get('language', 'de').upper()}\n\n"
                f"💬 *Orijinal:*\n_{msg['message_original'][:200]}_\n\n"
                f"🔄 *Çeviri:*\n_{msg.get('message_translated', msg['message_original'])[:200]}_\n\n"
                f"{risk_emoji} Risk Skoru: {msg['risk_score']}/100\n"
                f"{sentiment_emoji} Duygu: {msg['sentiment']}\n"
            )

            if msg.get('suggested_reply'):
                notification += f"\n✍️ *Önerilen Yanıt:*\n_{msg['suggested_reply']}_"

            # Send notification
            await bot.send_notification(notification)

            # Mark as notified
            self._mark_notified(msg['id'])

            self.logger.info(f"Telegram notification sent for message {msg['id']}")
            return True

        except Exception as e:
            self.logger.error(f"Telegram notification failed: {e}")
            return False

    # ========================================================================
    # PUBLIC API - Queue Messages
    # ========================================================================

    def queue_incoming_message(
        self,
        platform: str,
        sender: str,
        message: str,
        conversation_id: str = None,
        product_id: int = None,
        priority: str = 'normal'
    ) -> int:
        """
        Queue an incoming message for processing

        Args:
            platform: Source platform
            sender: Sender ID/name
            message: Message text
            conversation_id: Optional conversation ID
            product_id: Optional related product ID
            priority: Message priority (low, normal, high, urgent)

        Returns:
            Queue item ID
        """
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO message_queue
            (direction, platform, sender, message_original, conversation_id, product_id, priority)
            VALUES ('inbox', ?, ?, ?, ?, ?, ?)
        """, (platform, sender, message, conversation_id, product_id, priority))

        item_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Queued incoming message: {platform}/{sender} (ID: {item_id})")
        return item_id

    def get_queue_stats(self) -> Dict:
        """Get queue statistics"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT status, COUNT(*) as count
            FROM message_queue
            WHERE direction = 'inbox'
            GROUP BY status
        """)

        stats = {row[0]: row[1] for row in cursor.fetchall()}
        conn.close()

        return {
            'pending': stats.get('pending', 0),
            'processed': stats.get('processed', 0),
            'notified': stats.get('notified', 0),
            'error': stats.get('error', 0),
            'total_processed_session': self.messages_processed,
            'total_notified_session': self.messages_notified
        }


# Test
if __name__ == "__main__":
    print("=" * 60)
    print("INBOX AGENT - TEST")
    print("=" * 60)
    print()

    # Create agent
    agent = InboxAgent(interval_seconds=30)

    # Queue some test messages
    print("Queueing test messages...")

    agent.queue_incoming_message(
        platform='vinted_de',
        sender='TestSeller1',
        message='Ja, ist noch verfügbar. Kann es morgen versenden.',
        conversation_id='conv_001',
        product_id=123
    )

    agent.queue_incoming_message(
        platform='ebay_de',
        sender='TestSeller2',
        message='Leider schon verkauft.',
        conversation_id='conv_002',
        product_id=456
    )

    agent.queue_incoming_message(
        platform='kleinanzeigen',
        sender='TestSeller3',
        message='Können wir außerhalb der Plattform per PayPal Friends abwickeln?',
        conversation_id='conv_003',
        product_id=789
    )

    print()
    print("Queue stats:")
    stats = agent.get_queue_stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")

    print()
    print("Testing risk calculation...")
    print("-" * 40)

    test_messages = [
        ("Ja, ist noch da. Gerne!", "de"),
        ("Sorry, already sold.", "en"),
        ("Können wir per WhatsApp schreiben?", "de"),
        ("Oui, disponible. Envoi demain.", "fr")
    ]

    for msg, lang in test_messages:
        risk = agent._calculate_risk(msg, lang)
        sentiment = agent._detect_sentiment(msg, lang)
        print(f"  '{msg[:30]}...' -> Risk: {risk}, Sentiment: {sentiment}")

    print()
    print("=" * 60)
    print("To run as background service: agent.start()")
    print("=" * 60)
