# Vinted Auto Login + Product Upload
import os
import sys
import time
import random
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from playwright.sync_api import sync_playwright
from utils.database import db
from config import STATUS_VALIDATED, STATUS_UPLOADED

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# cssberlin credentials
VINTED_EMAIL = "cssberlin@hotmail.com"
VINTED_PASSWORD = "Cssberlin200231"

class VintedAutoUploader:
    def __init__(self):
        self.profile_dir = os.path.join(BASE_DIR, 'playwright_profiles', 'cssberlin')
        os.makedirs(self.profile_dir, exist_ok=True)

    def random_delay(self, min_s=1, max_s=3):
        time.sleep(random.uniform(min_s, max_s))

    def login(self, page):
        """Perform login to Vinted"""
        print("\n[LOGIN] Starting login process...")

        # Go to Vinted
        page.goto('https://www.vinted.de/', wait_until='networkidle', timeout=60000)
        self.random_delay(2, 4)

        # Accept cookies if shown (use correct selector)
        try:
            cookie_selectors = [
                'button#onetrust-accept-btn-handler',
                'button:has-text("Alle akzeptieren")',
                'button:has-text("Alle zulassen")'
            ]
            for sel in cookie_selectors:
                cookie_btn = page.query_selector(sel)
                if cookie_btn and cookie_btn.is_visible():
                    cookie_btn.click()
                    print(f"[OK] Cookies accepted: {sel}")
                    self.random_delay(1, 2)
                    break
        except:
            pass

        # Take screenshot of initial page
        page.screenshot(path=os.path.join(BASE_DIR, 'data', 'login_step0.png'))

        # Step 0: Click header "Registrieren | Einloggen" button to open popup
        print("[0] Clicking header 'Registrieren | Einloggen' button...")
        try:
            header_btn = page.query_selector('a:has-text("Registrieren | Einloggen"), button:has-text("Registrieren | Einloggen")')
            if header_btn and header_btn.is_visible():
                header_btn.click()
                print("[OK] Popup opened")
                self.random_delay(2, 3)
            else:
                # Try alternative selector
                header_btn = page.query_selector('[data-testid="header--login-button"]')
                if header_btn:
                    header_btn.click()
                    print("[OK] Popup opened via testid")
                    self.random_delay(2, 3)
        except Exception as e:
            print(f"[WARN] Header button: {e}")

        page.screenshot(path=os.path.join(BASE_DIR, 'data', 'login_step0b.png'))

        # Step 1: Now click "Einloggen" link at BOTTOM of popup
        # "Hast du schon einen Account? Einloggen"
        print("[1] Looking for 'Einloggen' in popup...")

        clicked = False

        # Method 1: Use Playwright's get_by_text (more robust)
        try:
            einloggen = page.get_by_text("Einloggen", exact=True).first
            if einloggen.is_visible():
                einloggen.click()
                print("[OK] Clicked 'Einloggen' via get_by_text")
                clicked = True
                self.random_delay(2, 3)
        except Exception as e:
            print(f"[DEBUG] Method 1: {e}")

        # Method 2: Try different selectors for any element with Einloggen
        if not clicked:
            selectors_to_try = [
                'button:has-text("Einloggen"):not(:has-text("Registrieren"))',
                'span:has-text("Einloggen"):not(:has-text("Registrieren"))',
                '[role="button"]:has-text("Einloggen")',
                'a:has-text("Einloggen"):not(:has-text("Registrieren"))',
            ]
            for sel in selectors_to_try:
                try:
                    el = page.query_selector(sel)
                    if el and el.is_visible():
                        el.click()
                        print(f"[OK] Clicked Einloggen via: {sel[:40]}")
                        clicked = True
                        self.random_delay(2, 3)
                        break
                except Exception as e:
                    continue

        # Method 3: Click by coordinates if visible in modal
        if not clicked:
            try:
                # The "Einloggen" text should be near bottom of modal
                modal = page.query_selector('[role="dialog"], [class*="Modal"], [class*="modal"]')
                if modal:
                    box = modal.bounding_box()
                    if box:
                        # Click near bottom center of modal where Einloggen link is
                        x = box['x'] + box['width'] / 2
                        y = box['y'] + box['height'] - 50  # Near bottom
                        page.mouse.click(x, y)
                        print(f"[OK] Clicked near modal bottom ({x:.0f}, {y:.0f})")
                        clicked = True
                        self.random_delay(2, 3)
            except Exception as e:
                print(f"[DEBUG] Method 3: {e}")

        page.screenshot(path=os.path.join(BASE_DIR, 'data', 'login_step1.png'))

        # Step 2: Click "Einloggen mit E-Mail" option
        print("[2] Looking for E-Mail login option...")
        self.random_delay(1, 2)

        clicked_email = False

        # Method 1: Use get_by_text for "E-Mail"
        try:
            email_opt = page.get_by_text("E-Mail", exact=False).first
            if email_opt and email_opt.is_visible():
                email_opt.click()
                print("[OK] Clicked E-Mail option via get_by_text")
                clicked_email = True
                self.random_delay(2, 3)
        except Exception as e:
            print(f"[DEBUG] E-Mail get_by_text: {e}")

        # Method 2: Try various selectors
        if not clicked_email:
            email_login_selectors = [
                'a:has-text("E-Mail")',
                'button:has-text("E-Mail")',
                'span:has-text("E-Mail")',
                '[data-testid*="email"]',
                'a:has-text("Mit E-Mail")',
            ]

            for sel in email_login_selectors:
                try:
                    el = page.query_selector(sel)
                    if el and el.is_visible():
                        el.click()
                        print(f"[OK] Clicked email login: {sel}")
                        clicked_email = True
                        self.random_delay(2, 3)
                        break
                except:
                    continue

        if not clicked_email:
            print("[INFO] E-Mail option not found, checking if form is visible...")

        page.screenshot(path=os.path.join(BASE_DIR, 'data', 'login_step2.png'))

        # Step 3: Fill email
        print("[3] Entering email...")
        email_selectors = [
            'input[type="email"]',
            'input[name="email"]',
            'input[placeholder*="E-Mail"]',
            'input[id*="email"]',
            'input[autocomplete="email"]'
        ]

        email_filled = False
        for sel in email_selectors:
            try:
                el = page.query_selector(sel)
                if el and el.is_visible():
                    el.click()
                    el.fill(VINTED_EMAIL)
                    print(f"[OK] Email entered in: {sel}")
                    email_filled = True
                    self.random_delay(0.5, 1)
                    break
            except:
                continue

        if not email_filled:
            print("[WARN] Email field not found!")

        # Step 4: Fill password
        print("[4] Entering password...")
        password_selectors = [
            'input[type="password"]',
            'input[name="password"]',
            'input[autocomplete="current-password"]'
        ]

        password_filled = False
        for sel in password_selectors:
            try:
                el = page.query_selector(sel)
                if el and el.is_visible():
                    el.click()
                    el.fill(VINTED_PASSWORD)
                    print(f"[OK] Password entered in: {sel}")
                    password_filled = True
                    self.random_delay(0.5, 1)
                    break
            except:
                continue

        if not password_filled:
            print("[WARN] Password field not found!")

        page.screenshot(path=os.path.join(BASE_DIR, 'data', 'login_step3.png'))

        # Step 5: Click login/submit button
        print("[5] Clicking login button...")
        submit_selectors = [
            'button[type="submit"]',
            'button:has-text("Weiter")',
            'button:has-text("Einloggen")',
            'button:has-text("Anmelden")',
            'input[type="submit"]'
        ]

        for sel in submit_selectors:
            try:
                el = page.query_selector(sel)
                if el and el.is_visible():
                    el.click()
                    print(f"[OK] Clicked submit: {sel}")
                    self.random_delay(4, 6)
                    break
            except:
                continue

        page.screenshot(path=os.path.join(BASE_DIR, 'data', 'login_step4.png'))

        # Wait for page to load
        page.wait_for_timeout(5000)

        # Verify login by checking URL or page content
        current_url = page.url
        print(f"[INFO] Current URL: {current_url}")

        # Check if we're on a page that indicates login
        if '/auth/' not in current_url:
            # Try to go to upload page
            page.goto('https://www.vinted.de/items/new', wait_until='domcontentloaded', timeout=60000)
            self.random_delay(3, 5)

            # Check if redirected back to login
            if '/auth/' in page.url:
                print("[ERROR] Not logged in - redirected to auth")
                page.screenshot(path=os.path.join(BASE_DIR, 'data', 'login_failed.png'))
                return False
            else:
                print("[OK] Login successful! On upload page.")
                page.screenshot(path=os.path.join(BASE_DIR, 'data', 'login_success.png'))
                return True
        else:
            print("[ERROR] Still on auth page")
            page.screenshot(path=os.path.join(BASE_DIR, 'data', 'login_failed.png'))
            return False

    def upload_product(self, page, product):
        """Upload a single product"""
        title = product.get('processed_title', product.get('raw_title', ''))
        desc = product.get('processed_description', product.get('raw_description', ''))
        price = product.get('price', 0)
        images_path = product.get('processed_images_path', product.get('raw_images_path', ''))

        print(f"\n[UPLOAD] {title[:50]}...")

        # Go to upload page
        page.goto('https://www.vinted.de/items/new', wait_until='networkidle', timeout=60000)
        self.random_delay(2, 4)

        # 1. Upload images
        print("[1] Uploading images...")
        if images_path and os.path.exists(images_path):
            images = [os.path.join(images_path, f) for f in os.listdir(images_path)
                     if f.lower().endswith(('.jpg', '.jpeg', '.png'))][:10]

            if images:
                file_input = page.query_selector('input[type="file"]')
                if file_input:
                    file_input.set_input_files(images)
                    print(f"[OK] {len(images)} images uploaded")
                    self.random_delay(3, 5)  # Wait for upload

        # 2. Fill title
        print("[2] Filling title...")
        title_input = page.query_selector('[data-testid="title-input"], input[name="title"], input[placeholder*="Titel"]')
        if title_input:
            title_input.fill(title)
            self.random_delay(1, 2)
            # Wait for category suggestion
            page.wait_for_timeout(2000)

        # 3. Fill description
        print("[3] Filling description...")
        desc_input = page.query_selector('[data-testid="description-textarea"], textarea[name="description"], textarea[placeholder*="Beschreib"]')
        if desc_input:
            desc_input.fill(desc)
            self.random_delay(1, 2)

        # 4. Fill price
        print("[4] Filling price...")
        price_input = page.query_selector('[data-testid="price-input"], input[name="price"], input[placeholder*="Preis"]')
        if price_input:
            price_input.fill(str(int(price)))
            self.random_delay(1, 2)

        # 5. Select category if needed
        print("[5] Checking category...")
        # Category is usually auto-suggested based on title
        # Click first suggestion if available
        try:
            cat_suggestion = page.query_selector('[data-testid="category-suggestion"], [role="option"]')
            if cat_suggestion:
                cat_suggestion.click()
                self.random_delay(1, 2)
        except:
            pass

        # Take screenshot before submit
        ss_path = os.path.join(BASE_DIR, 'data', f'upload_{product.get("id", "unknown")}.png')
        page.screenshot(path=ss_path)
        print(f"[SS] Screenshot saved: {ss_path}")

        # 6. Submit (publish)
        print("[6] Publishing...")
        publish_btn = page.query_selector('button:has-text("Hochladen"), button:has-text("Artikel hochladen"), button[type="submit"]')
        if publish_btn and publish_btn.is_visible():
            publish_btn.click()
            self.random_delay(5, 8)
            print("[OK] Product published!")
            return True
        else:
            print("[WARN] Publish button not found")
            return False

    def run(self, limit=1):
        """Main run function"""
        print("=" * 60)
        print("VINTED AUTO UPLOADER - CSSBERLIN")
        print("=" * 60)
        print()
        print("!!! HATIRLATMA !!!")
        print("  - Mobil Hotspot'a bagli mi?")
        print("  - Every Proxy acik mi?")
        print("=" * 60)

        # Get products to upload
        products = db.get_products_by_status(STATUS_VALIDATED)[:limit]
        print(f"\n{len(products)} products ready to upload\n")

        if not products:
            print("[INFO] No products to upload")
            return 0

        with sync_playwright() as pw:
            browser = pw.chromium.launch_persistent_context(
                user_data_dir=self.profile_dir,
                headless=False,
                args=[
                    '--disable-blink-features=AutomationControlled',
                    '--no-sandbox',
                    '--start-maximized'
                ],
                viewport={'width': 1400, 'height': 900},
                locale='de-DE',
                timezone_id='Europe/Berlin'
            )

            page = browser.pages[0] if browser.pages else browser.new_page()

            # Login first
            if not self.login(page):
                print("[ERROR] Login failed! Exiting.")
                browser.close()
                return 0

            # Upload products
            done = 0
            for i, product in enumerate(products):
                print(f"\n{'='*50}")
                print(f"Product {i+1}/{len(products)}")
                print(f"{'='*50}")

                try:
                    if self.upload_product(page, product):
                        # Update database
                        db.update_product(product['id'], {
                            'status': STATUS_UPLOADED,
                            'target_store': 'cssberlin'
                        })
                        db.add_log(product['id'], 'upload', 'success', 'Auto-uploaded to cssberlin')
                        done += 1

                    # Delay between products
                    if i < len(products) - 1:
                        delay = random.randint(30, 60)
                        print(f"\n[WAIT] {delay}s before next product...")
                        time.sleep(delay)

                except Exception as e:
                    print(f"[ERROR] {e}")
                    db.add_log(product['id'], 'upload', 'failed', str(e))

            print(f"\n{'='*60}")
            print(f"DONE: {done}/{len(products)} products uploaded")
            print(f"{'='*60}")

            # Keep browser open briefly
            print("\nBrowser closing in 10 seconds...")
            page.wait_for_timeout(10000)
            browser.close()

            return done


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--limit', type=int, default=1, help='Max products to upload')
    args = parser.parse_args()

    return VintedAutoUploader().run(args.limit)


if __name__ == '__main__':
    main()
