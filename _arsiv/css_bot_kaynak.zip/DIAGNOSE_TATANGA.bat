@echo off
chcp 65001 >nul
color 0A
title TATANGA Diagnostic Tool

echo.
echo ═══════════════════════════════════════════════════════════
echo   🔍 TATANGA DIAGNOSTIC TOOL
echo ═══════════════════════════════════════════════════════════
echo.

REM Test 1: Python Check
echo [TEST 1] Python Kontrolu...
python --version >nul 2>&1
if errorlevel 1 (
    color 0C
    echo ❌ HATA: Python bulunamadi!
    echo.
    echo COZUM:
    echo   1. Python yukleyin: https://www.python.org/downloads/
    echo   2. Kurulumda "Add Python to PATH" secenegini isaretleyin
    echo.
    pause
    exit /b 1
) else (
    python --version
    echo ✅ Python kurulu
)
echo.

REM Test 2: Current Directory
echo [TEST 2] Calisma Dizini Kontrolu...
echo Mevcut konum: %CD%
if not exist "TATANGA_LAUNCHER.py" (
    color 0C
    echo ❌ HATA: TATANGA_LAUNCHER.py bulunamadi!
    echo.
    echo COZUM:
    echo   Bu .bat dosyasini "CSS BOT" klasorunde calistirin
    echo.
    pause
    exit /b 1
) else (
    echo ✅ TATANGA_LAUNCHER.py bulundu
)
echo.

REM Test 3: Required Packages
echo [TEST 3] Gerekli Paketler Kontrolu...
echo.

echo Kontrol: tkinter...
python -c "import tkinter" >nul 2>&1
if errorlevel 1 (
    echo ❌ tkinter eksik
    set MISSING=1
) else (
    echo ✅ tkinter
)

echo Kontrol: PIL (pillow)...
python -c "import PIL" >nul 2>&1
if errorlevel 1 (
    echo ⚠️  pillow eksik
    set MISSING=1
) else (
    echo ✅ pillow
)

echo Kontrol: cv2 (opencv-python)...
python -c "import cv2" >nul 2>&1
if errorlevel 1 (
    echo ⚠️  opencv-python eksik
    set MISSING=1
) else (
    echo ✅ opencv-python
)

echo Kontrol: imagehash...
python -c "import imagehash" >nul 2>&1
if errorlevel 1 (
    echo ⚠️  imagehash eksik
    set MISSING=1
) else (
    echo ✅ imagehash
)

echo Kontrol: flask...
python -c "import flask" >nul 2>&1
if errorlevel 1 (
    echo ⚠️  flask eksik
    set MISSING=1
) else (
    echo ✅ flask
)

echo Kontrol: cryptography...
python -c "import cryptography" >nul 2>&1
if errorlevel 1 (
    echo ⚠️  cryptography eksik
    set MISSING=1
) else (
    echo ✅ cryptography
)

echo.

if defined MISSING (
    color 0E
    echo ⚠️  UYARI: Bazi paketler eksik!
    echo.
    echo COZUM:
    echo   pip install -r requirements_tatanga.txt
    echo.
    echo Simdi kurmak ister misiniz? (E/H)
    set /p INSTALL="Secim: "
    if /i "%INSTALL%"=="E" (
        echo.
        echo Paketler yukleniyor...
        pip install -r requirements_tatanga.txt
        echo.
        echo ✅ Kurulum tamamlandi!
    )
) else (
    echo ✅ Tum paketler kurulu
)

echo.

REM Test 4: Database Check
echo [TEST 4] Database Kontrolu...
if exist "css_arbitraj.db" (
    echo ✅ Database bulundu: css_arbitraj.db
) else (
    color 0E
    echo ⚠️  UYARI: Database bulunamadi!
    echo.
    echo COZUM:
    echo   python active_pieces\database_migration_v2.py
)
echo.

REM Test 5: Import Test
echo [TEST 5] TATANGA Import Testi...
echo.
python -c "import sys; sys.path.insert(0, 'active_pieces'); from core.logger import ModuleLogger; print('✅ Import basarili')" 2>nul
if errorlevel 1 (
    color 0C
    echo ❌ HATA: TATANGA modulleri yuklenemedi!
    echo.
    echo COZUM:
    echo   1. active_pieces klasorunu kontrol edin
    echo   2. Python dosyalarin encoding'ini kontrol edin
    echo.
) else (
    echo ✅ TATANGA modulleri yuklenebiliyor
)
echo.

REM Test 6: Tkinter GUI Test
echo [TEST 6] Tkinter GUI Testi...
echo.
python -c "import tkinter as tk; root = tk.Tk(); root.title('Test'); root.geometry('300x100'); tk.Label(root, text='GUI Calisiyor!').pack(pady=20); root.after(2000, root.destroy); root.mainloop(); print('✅ GUI test basarili')"
if errorlevel 1 (
    color 0C
    echo ❌ HATA: GUI olusturulamiyor!
    echo.
    echo COZUM:
    echo   Python kurulumunuzu yeniden yapin ve tkinter'i isaretleyin
    echo.
) else (
    echo ✅ Tkinter GUI calisiyor
)
echo.

REM Summary
echo ═══════════════════════════════════════════════════════════
echo   📊 DIAGNOSTIC OZET
echo ═══════════════════════════════════════════════════════════
echo.

if defined MISSING (
    color 0E
    echo ⚠️  DURUM: Eksik paketler var
    echo.
    echo Lutfen once pakatleri yukleyin:
    echo   pip install -r requirements_tatanga.txt
    echo.
) else (
    color 0A
    echo ✅ DURUM: Sistem hazir!
    echo.
    echo TATANGA'yi baslatmak icin:
    echo   START_TATANGA_VERBOSE.bat
    echo.
)

echo ═══════════════════════════════════════════════════════════
echo.
pause
