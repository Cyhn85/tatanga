<template>
  <div>
    <h1 class="text-3xl font-bold mb-6">Urunler</h1>

    <!-- Filters -->
    <div class="bg-white rounded-lg shadow p-4 mb-6">
      <div class="flex gap-4 items-center">
        <select v-model="filter.status" @change="loadProducts" class="border rounded px-4 py-2">
          <option value="">Tum Durumlar</option>
          <option value="inbox">Gelen Kutusu</option>
          <option value="favorite">Favori</option>
          <option value="published">Yayinda</option>
          <option value="sold">Satildi</option>
        </select>
        <select v-model="filter.platform" @change="loadProducts" class="border rounded px-4 py-2">
          <option value="">Tum Platformlar</option>
          <option value="ebay">eBay</option>
          <option value="vinted">Vinted</option>
          <option value="kleinanzeigen">Kleinanzeigen</option>
          <option value="tradera">Tradera</option>
          <option value="willhaben">Willhaben</option>
          <option value="sellpy">Sellpy</option>
          <option value="percentil">Percentil</option>
        </select>
        <span class="text-gray-500 ml-auto">{{ products.length }} urun</span>
      </div>
    </div>

    <!-- Bulk Actions Toolbar -->
    <div v-if="selectedProducts.length > 0"
         class="bg-blue-100 border border-blue-300 rounded-lg p-4 mb-4 flex items-center gap-4">
      <span class="font-medium text-blue-800">{{ selectedProducts.length }} urun secildi</span>
      <button @click="bulkAddToFavorites"
              class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded font-medium">
        Favorilere Ekle
      </button>
      <button @click="bulkDelete"
              class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded font-medium">
        Sil
      </button>
      <button @click="selectedProducts = []"
              class="text-gray-600 hover:text-gray-800 ml-auto">
        Secimi Temizle
      </button>
    </div>

    <!-- Products Table -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
      <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
          <tr>
            <th class="px-4 py-3 text-left">
              <input type="checkbox"
                     :checked="allSelected"
                     @change="toggleSelectAll"
                     class="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500" />
            </th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Gorsel</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Baslik</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Platform</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fiyat</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Durum</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Eylemler</th>
          </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
          <tr v-for="product in products" :key="product.id"
              :class="selectedProducts.includes(product.id) ? 'bg-blue-50' : 'hover:bg-gray-50'">
            <td class="px-4 py-3">
              <input type="checkbox"
                     :value="product.id"
                     v-model="selectedProducts"
                     class="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500" />
            </td>
            <td class="px-4 py-3 text-sm text-gray-500">{{ product.scr_id }}</td>
            <td class="px-4 py-3">
              <img v-if="getFirstImage(product)" :src="getFirstImage(product)" class="w-16 h-16 object-cover rounded" />
              <div v-else class="w-16 h-16 bg-gray-200 rounded flex items-center justify-center text-gray-400">?</div>
            </td>
            <td class="px-4 py-3">
              <a :href="product.source_url" target="_blank" class="text-blue-600 hover:underline">
                {{ truncate(product.title, 40) }}
              </a>
            </td>
            <td class="px-4 py-3 text-sm">{{ product.source_platform || "-" }}</td>
            <td class="px-4 py-3 text-sm font-bold">{{ formatPrice(product.price) }}</td>
            <td class="px-4 py-3">
              <span class="px-2 py-1 text-xs rounded-full" :class="getStatusClass(product.status)">
                {{ getStatusText(product.status) }}
              </span>
            </td>
            <td class="px-4 py-3">
              <div class="flex gap-2">
                <button @click="toggleFavorite(product)"
                        class="text-xl transition-colors"
                        :class="isFavorite(product.id) ? 'text-red-500 hover:text-red-600' : 'text-yellow-400 hover:text-yellow-500'"
                        :title="isFavorite(product.id) ? 'Favorilerden Cikar' : 'Favorilere Ekle'">
                  ★
                </button>
                <a :href="product.source_url" target="_blank" class="text-blue-500 hover:text-blue-600 text-xl" title="Kaynak">🔗</a>
                <button @click="deleteProduct(product.id)" class="text-red-500 hover:text-red-600 text-xl" title="Sil">🗑</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue"
import api from "../api/client"

const products = ref([])
const filter = ref({ status: "", platform: "" })
const favoriteProductIds = ref(new Set())
const productFavoriteMap = ref({}) // product_id -> favorite_id mapping
const selectedProducts = ref([]) // Secili urun ID'leri

// Tumu secili mi?
const allSelected = computed(() => {
  return products.value.length > 0 &&
         selectedProducts.value.length === products.value.length
})

const getFirstImage = (product) => {
  if (product.images && product.images.length > 0) {
    return product.images[0].url || product.images[0]
  }
  return null
}

const truncate = (text, len) => {
  if (!text) return "-"
  return text.length > len ? text.substring(0, len) + "..." : text
}

const formatPrice = (price) => {
  if (!price) return "-"
  return new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(price)
}

const getStatusClass = (status) => {
  const classes = {
    inbox: "bg-blue-100 text-blue-800",
    favorite: "bg-yellow-100 text-yellow-800",
    published: "bg-green-100 text-green-800",
    sold: "bg-purple-100 text-purple-800"
  }
  return classes[status] || "bg-gray-100 text-gray-800"
}

const getStatusText = (status) => {
  const texts = { inbox: "Gelen Kutusu", favorite: "Favori", published: "Yayinda", sold: "Satildi" }
  return texts[status] || status
}

const isFavorite = (productId) => {
  return favoriteProductIds.value.has(productId)
}

const loadFavorites = async () => {
  try {
    const res = await api.get("/favorites/")
    favoriteProductIds.value = new Set(res.data.map(f => f.product.id))
    productFavoriteMap.value = Object.fromEntries(
      res.data.map(f => [f.product.id, f.id])
    )
  } catch (error) {
    console.error("Favoriler yuklenemedi:", error)
  }
}

const toggleFavorite = async (product) => {
  try {
    if (isFavorite(product.id)) {
      // Favoriden cikar
      const favId = productFavoriteMap.value[product.id]
      await api.delete("/favorites/" + favId)
      favoriteProductIds.value.delete(product.id)
      delete productFavoriteMap.value[product.id]
    } else {
      // Favoriye ekle
      await api.post("/favorites/", { product_id: product.id })
    }
    // Her iki durumda da yenile
    await loadFavorites()
    await loadProducts()
  } catch (error) {
    alert("Hata: " + (error.response?.data?.detail || error.message))
  }
}

// Tumunu sec/birak
const toggleSelectAll = () => {
  if (allSelected.value) {
    selectedProducts.value = []
  } else {
    selectedProducts.value = products.value.map(p => p.id)
  }
}

// Toplu favoriye ekleme
const bulkAddToFavorites = async () => {
  const notFavorited = selectedProducts.value.filter(id => !favoriteProductIds.value.has(id))
  if (notFavorited.length === 0) {
    alert("Secili urunlerin tumu zaten favorilerde")
    return
  }

  for (const productId of notFavorited) {
    try {
      await api.post("/favorites/", { product_id: productId })
    } catch (e) {
      console.error("Favori ekleme hatasi:", e)
    }
  }

  await loadFavorites()
  selectedProducts.value = []
  alert(notFavorited.length + " urun favorilere eklendi")
}

// Toplu silme
const bulkDelete = async () => {
  if (!confirm(selectedProducts.value.length + " urun silinecek. Emin misiniz?")) return

  for (const productId of selectedProducts.value) {
    try {
      await api.delete("/products/" + productId)
    } catch (e) {
      console.error("Silme hatasi:", e)
    }
  }

  selectedProducts.value = []
  await loadProducts()
}

const deleteProduct = async (productId) => {
  if (!confirm("Bu urunu silmek istediginizden emin misiniz?")) return
  try {
    await api.delete("/products/" + productId)
    loadProducts()
  } catch (error) {
    alert("Hata: " + (error.response?.data?.detail || error.message))
  }
}

const loadProducts = async () => {
  try {
    const params = {}
    if (filter.value.status) params.status = filter.value.status
    if (filter.value.platform) params.platform = filter.value.platform
    const res = await api.get("/products", { params })
    products.value = res.data
    // Urunler yenilendiginde secimi temizle
    selectedProducts.value = []
  } catch (error) {
    console.error("Failed:", error)
  }
}

onMounted(() => {
  loadProducts()
  loadFavorites()
})
</script>