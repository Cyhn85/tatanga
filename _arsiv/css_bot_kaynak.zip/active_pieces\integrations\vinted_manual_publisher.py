#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Vinted Manuel Yayınlama Sistemi
Dosya sistemi tabanlı manuel yayınlama için hazırlık

Features:
- Ürün için özel klasör oluşturma
- Görselleri indirme ve işleme (duplicate bypass)
- listing_info.txt oluşturma (başlık, açıklama, fiyat, kategori)
- Tıklanabilir file:/// link döndürme

Author: TATANGA Team
Version: 1.0.0
"""

import sys
import os
import json
import shutil
import requests
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional

sys.path.insert(0, str(Path(__file__).parent.parent))

# Import logger
try:
    from core.logger import get_logger
    logger = get_logger("vinted_manual_publisher")
except ImportError:
    import logging
    logger = logging.getLogger("vinted_manual_publisher")

# Import image processor
try:
    from integrations.image_processor import ImageProcessor
    IMAGE_PROCESSOR_AVAILABLE = True
except ImportError:
    IMAGE_PROCESSOR_AVAILABLE = False

# Import variant generator for SEO content
try:
    from integrations.variant_generator import ProductVariantGenerator
    VARIANT_GENERATOR_AVAILABLE = True
except ImportError:
    VARIANT_GENERATOR_AVAILABLE = False

# Import image format fixer for WebP/AVIF → JPEG conversion
try:
    from integrations.image_format_fixer import (
        detect_format_from_bytes,
        convert_bytes_to_jpeg,
        ensure_jpeg,
        detect_image_format
    )
    FORMAT_FIXER_AVAILABLE = True
except ImportError:
    FORMAT_FIXER_AVAILABLE = False
    logger.warning("Image format fixer not available - WebP images may cause API errors")

# Import Groq SEO generator for organic content
try:
    from integrations.groq_seo_generator import GroqSEOGenerator
    GROQ_SEO_AVAILABLE = True
except ImportError:
    GROQ_SEO_AVAILABLE = False


# Base output directory for Vinted manual listings
VINTED_OUTPUT_DIR = Path(__file__).parent.parent / "output" / "vinted_listings"


class VintedManualPublisher:
    """
    Vinted Manuel Yayınlama Sistemi

    Ürünleri dosya sistemi üzerinden manuel yayınlama için hazırlar.
    """

    # Vinted kategori mappings (German)
    CATEGORY_MAPPING = {
        'kleidung': '5', # Damen > Kleidung
        'schuhe': '16',  # Damen > Schuhe
        'taschen': '13', # Damen > Taschen
        'accessoires': '19', # Damen > Accessoires
        'herren': '1050', # Herren
        'kinder': '2050', # Kinder
    }

    # Vinted condition mappings
    CONDITION_MAPPING = {
        'neu mit etikett': '1',
        'neu ohne etikett': '2',
        'sehr gut': '3',
        'gut': '4',
        'zufriedenstellend': '5'
    }

    def __init__(self, output_dir: str = None):
        """
        Initialize VintedManualPublisher.

        Args:
            output_dir: Output directory for listings (default: output/vinted_listings/)
        """
        if output_dir:
            self.output_dir = Path(output_dir)
        else:
            self.output_dir = VINTED_OUTPUT_DIR

        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Initialize processors
        self.image_processor = ImageProcessor() if IMAGE_PROCESSOR_AVAILABLE else None
        self.variant_generator = ProductVariantGenerator() if VARIANT_GENERATOR_AVAILABLE else None
        self.seo_generator = GroqSEOGenerator() if GROQ_SEO_AVAILABLE else None

        # Session for downloading images
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })

        logger.info(f"VintedManualPublisher initialized. Output: {self.output_dir}")

    def prepare_listing(
        self,
        product_data: Dict,
        custom_price: float = None,
        generate_organic_content: bool = True,
        manipulation_level: str = "medium"
    ) -> Dict:
        """
        Ürün için Vinted manuel yayınlama dosyalarını hazırla.

        Args:
            product_data: Ürün verisi (title, price, images, description, etc.)
            custom_price: Manuel satış fiyatı (None ise otomatik hesapla)
            generate_organic_content: AI ile organik içerik oluştur
            manipulation_level: Görsel işleme seviyesi (light/medium/aggressive/ultra)

        Returns:
            Dict with success status, folder_path, file_link, and images
        """
        try:
            product_id = product_data.get('id') or product_data.get('product_id')
            if not product_id:
                product_id = f"manual_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

            # Create unique folder for this listing
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            folder_name = f"vinted_{product_id}_{timestamp}"
            listing_dir = self.output_dir / folder_name
            listing_dir.mkdir(parents=True, exist_ok=True)

            images_dir = listing_dir / "images"
            images_dir.mkdir(exist_ok=True)

            logger.info(f"Preparing Vinted listing: {listing_dir}")

            # 1. Process images
            processed_images = self._process_images(
                product_data,
                images_dir,
                manipulation_level
            )

            # 2. Generate content (organic or original)
            content = self._generate_content(
                product_data,
                generate_organic=generate_organic_content
            )

            # 3. Calculate price
            source_price = float(product_data.get('price', 0) or 0)
            if custom_price:
                final_price = custom_price
            else:
                # Default: 30% margin
                final_price = round(source_price * 1.30, 2)

            # 4. Create listing_info.txt
            listing_info = self._create_listing_info(
                product_data,
                content,
                final_price,
                processed_images,
                listing_dir
            )

            # 5. Create metadata.json for tracking
            self._create_metadata(
                product_data,
                final_price,
                processed_images,
                listing_dir
            )

            # Generate clickable file:/// link
            file_link = self._get_file_link(listing_dir)

            result = {
                'success': True,
                'product_id': product_id,
                'folder_path': str(listing_dir),
                'file_link': file_link,
                'images_count': len(processed_images),
                'images': processed_images,
                'title': content['title'],
                'description': content['description'][:100] + "...",
                'price': final_price,
                'source_price': source_price,
                'created_at': datetime.now().isoformat()
            }

            logger.info(f"Vinted listing prepared: {file_link}")
            return result

        except Exception as e:
            logger.error(f"Error preparing Vinted listing: {e}")
            return {
                'success': False,
                'error': str(e),
                'product_id': product_data.get('id')
            }

    def _process_images(
        self,
        product_data: Dict,
        output_dir: Path,
        manipulation_level: str
    ) -> List[str]:
        """
        Process and save images for the listing.

        Returns list of saved image paths.
        """
        processed_images = []

        # Get image URLs
        images = product_data.get('images', '[]')
        if isinstance(images, str):
            try:
                images = json.loads(images)
            except:
                images = [images] if images else []

        if not images:
            # Try single image field
            image = product_data.get('image', '')
            if image:
                images = [image]

        if not images:
            logger.warning("No images found for product")
            return processed_images

        # Download and process each image
        for i, img_url in enumerate(images[:10]):  # Max 10 images
            try:
                # Download image
                response = self.session.get(img_url, timeout=30)
                if response.status_code != 200:
                    continue

                # KRITIK: Detect ACTUAL format from bytes (not URL or Content-Type!)
                image_data = response.content

                if FORMAT_FIXER_AVAILABLE:
                    actual_format = detect_format_from_bytes(image_data)
                    logger.info(f"Image {i+1} actual format: {actual_format}")

                    # Convert non-JPEG formats to JPEG to prevent API errors
                    if actual_format != 'jpeg':
                        logger.info(f"Converting {actual_format} → JPEG")
                        jpeg_data = convert_bytes_to_jpeg(image_data, quality=95)
                        if jpeg_data:
                            image_data = jpeg_data
                        else:
                            logger.warning(f"Failed to convert image {i+1}, using original")

                    ext = 'jpg'  # Always save as JPEG after conversion
                else:
                    # Fallback: Check Content-Type (less reliable)
                    content_type = response.headers.get('Content-Type', '').lower()
                    if 'png' in content_type:
                        ext = 'png'
                    elif 'webp' in content_type:
                        ext = 'webp'  # Will cause issues without format fixer!
                        logger.warning(f"WebP detected but format fixer unavailable - may cause API errors!")
                    else:
                        ext = 'jpg'

                original_path = output_dir / f"original_{i+1}.{ext}"
                with open(original_path, 'wb') as f:
                    f.write(image_data)

                # Process with manipulation if available
                if self.image_processor and self.image_processor.manipulator:
                    try:
                        manipulated_path = output_dir / f"vinted_{i+1}.jpg"

                        # Get manipulation preset based on level
                        preset = self._get_manipulation_preset(manipulation_level)

                        success = self.image_processor.manipulator.manipulate_image(
                            str(original_path),
                            str(manipulated_path),
                            **preset
                        )

                        if success:
                            processed_images.append(str(manipulated_path))
                            # Remove original to save space
                            original_path.unlink()
                        else:
                            processed_images.append(str(original_path))
                    except Exception as manip_err:
                        logger.warning(f"Manipulation failed: {manip_err}")
                        processed_images.append(str(original_path))
                else:
                    processed_images.append(str(original_path))

            except Exception as e:
                logger.warning(f"Failed to process image {i+1}: {e}")

        # Ensure minimum 5 images (augment if needed)
        if len(processed_images) < 5 and processed_images:
            processed_images = self._augment_images(processed_images, output_dir, min_count=5)

        return processed_images

    def _augment_images(self, images: List[str], output_dir: Path, min_count: int = 5) -> List[str]:
        """
        Augment images to reach minimum count.
        """
        if not self.image_processor or not self.image_processor.manipulator:
            return images

        augmented = images.copy()
        source_idx = 0
        aug_num = len(images) + 1

        while len(augmented) < min_count and source_idx < len(images):
            source_path = images[source_idx % len(images)]
            aug_path = output_dir / f"vinted_aug_{aug_num}.jpg"

            try:
                # Different manipulation for augmented images
                success = self.image_processor.manipulator.manipulate_image(
                    source_path,
                    str(aug_path),
                    rotation=3.0 + (aug_num * 0.5),
                    brightness=15 + (aug_num * 2),
                    noise=10,
                    quality=88
                )

                if success:
                    augmented.append(str(aug_path))
                    aug_num += 1
            except:
                pass

            source_idx += 1

            # Prevent infinite loop
            if aug_num > 15:
                break

        return augmented

    def _get_manipulation_preset(self, level: str) -> Dict:
        """Get manipulation preset based on level."""
        presets = {
            'light': {
                'rotation': 0.5,
                'noise': 3,
                'brightness': 5,
                'contrast': 1.02,
                'quality': 95
            },
            'medium': {
                'rotation': 1.5,
                'noise': 7,
                'brightness': 10,
                'contrast': 1.05,
                'quality': 90
            },
            'aggressive': {
                'rotation': 3.0,
                'noise': 12,
                'brightness': 15,
                'contrast': 1.08,
                'quality': 85
            },
            'ultra': {
                'rotation': 5.0,
                'noise': 18,
                'brightness': 20,
                'contrast': 1.12,
                'quality': 80
            }
        }
        return presets.get(level, presets['medium'])

    def _generate_content(self, product_data: Dict, generate_organic: bool = True) -> Dict:
        """
        Generate title and description.

        If generate_organic is True and Groq is available, creates AI-generated content.
        Otherwise, uses original content with minor modifications.
        """
        original_title = product_data.get('title', 'Produkt')
        original_desc = product_data.get('description', '')
        brand = product_data.get('brand', '')
        size = product_data.get('size', '')
        color = product_data.get('color', '')
        condition = product_data.get('condition', 'Sehr gut')

        if generate_organic and self.seo_generator:
            try:
                # Generate organic content with Groq
                seo_result = self.seo_generator.generate(
                    title=original_title,
                    description=original_desc,
                    platform='vinted',
                    style='casual',
                    metadata={
                        'brand': brand,
                        'size': size,
                        'color': color,
                        'condition': condition
                    }
                )

                if seo_result.get('success'):
                    return {
                        'title': seo_result.get('title', original_title),
                        'description': seo_result.get('description', original_desc),
                        'tags': seo_result.get('tags', []),
                        'is_organic': True
                    }
            except Exception as e:
                logger.warning(f"Groq SEO generation failed: {e}")

        # Fallback: Use original with minor modifications
        new_title = original_title

        # Add brand if not in title
        if brand and brand.lower() not in original_title.lower():
            new_title = f"{brand} {new_title}"

        # Build description
        desc_parts = []
        if original_desc:
            desc_parts.append(original_desc)

        # Add metadata
        meta_lines = []
        if brand:
            meta_lines.append(f"Marke: {brand}")
        if size:
            meta_lines.append(f"Grosse: {size}")
        if color:
            meta_lines.append(f"Farbe: {color}")
        if condition:
            meta_lines.append(f"Zustand: {condition}")

        if meta_lines:
            desc_parts.append("\n" + "\n".join(meta_lines))

        # Add shipping note
        desc_parts.append("\nVersand: Sofort verfugbar!")

        return {
            'title': new_title[:80],  # Vinted title limit
            'description': "\n".join(desc_parts)[:2000],  # Vinted description limit
            'tags': self._extract_tags(original_title, brand),
            'is_organic': False
        }

    def _extract_tags(self, title: str, brand: str = None) -> List[str]:
        """Extract hashtags from title and brand."""
        tags = []

        # Common fashion keywords
        keywords = ['vintage', 'designer', 'original', 'neu', 'luxus', 'premium']

        title_lower = title.lower()
        for kw in keywords:
            if kw in title_lower:
                tags.append(f"#{kw}")

        if brand:
            tags.append(f"#{brand.lower().replace(' ', '')}")

        return tags[:5]  # Max 5 tags

    def _create_listing_info(
        self,
        product_data: Dict,
        content: Dict,
        price: float,
        images: List[str],
        listing_dir: Path
    ) -> Path:
        """
        Create listing_info.txt with all listing details.
        """
        info_path = listing_dir / "listing_info.txt"

        # Detect category
        category = self._detect_category(product_data.get('title', ''))
        condition = product_data.get('condition', 'Sehr gut')
        condition_code = self.CONDITION_MAPPING.get(condition.lower(), '3')

        content_text = f"""
================================================================================
                    VINTED MANUEL LISTING - TATANGA
================================================================================

BASLIK (Title):
{content['title']}

--------------------------------------------------------------------------------

ACIKLAMA (Description):
{content['description']}

--------------------------------------------------------------------------------

FIYAT (Price): {price:.2f} EUR
KAYNAK FIYAT (Source): {product_data.get('price', 0)} {product_data.get('currency', 'EUR')}

--------------------------------------------------------------------------------

KATEGORI ONERILERI:
- Ana Kategori: Damen / Herren
- Alt Kategori: {category}
- Kondisyon: {condition} (Code: {condition_code})

--------------------------------------------------------------------------------

GORSELLER ({len(images)} adet):
"""

        for i, img_path in enumerate(images, 1):
            content_text += f"  {i}. {Path(img_path).name}\n"

        content_text += f"""
--------------------------------------------------------------------------------

ETIKETLER (Tags):
{', '.join(content.get('tags', []))}

--------------------------------------------------------------------------------

KAYNAK BILGILERI:
- Platform: {product_data.get('platform', 'unknown')}
- URL: {product_data.get('url', 'N/A')}
- Brand: {product_data.get('brand', 'N/A')}
- Size: {product_data.get('size', 'N/A')}
- Color: {product_data.get('color', 'N/A')}

--------------------------------------------------------------------------------

OLUSTURULMA TARIHI: {datetime.now().strftime('%d.%m.%Y %H:%M')}
AI ORGANIK ICERIK: {'EVET' if content.get('is_organic') else 'HAYIR'}

================================================================================
"""

        with open(info_path, 'w', encoding='utf-8') as f:
            f.write(content_text)

        return info_path

    def _create_metadata(
        self,
        product_data: Dict,
        price: float,
        images: List[str],
        listing_dir: Path
    ):
        """Create metadata.json for tracking and potential automation."""
        metadata = {
            'product_id': product_data.get('id'),
            'source_platform': product_data.get('platform'),
            'source_url': product_data.get('url'),
            'source_price': product_data.get('price'),
            'source_currency': product_data.get('currency', 'EUR'),
            'listing_price': price,
            'images': [Path(img).name for img in images],
            'brand': product_data.get('brand'),
            'size': product_data.get('size'),
            'color': product_data.get('color'),
            'condition': product_data.get('condition'),
            'created_at': datetime.now().isoformat(),
            'status': 'pending',
            'vinted_listing_id': None,
            'vinted_listing_url': None
        }

        metadata_path = listing_dir / "metadata.json"
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)

    def _detect_category(self, title: str) -> str:
        """Detect Vinted category from title."""
        title_lower = title.lower()

        # Category keywords
        keywords = {
            'kleid': 'Kleider',
            'hose': 'Hosen',
            'jeans': 'Jeans',
            'rock': 'Roecke',
            'bluse': 'Blusen',
            'hemd': 'Hemden',
            'jacke': 'Jacken',
            'mantel': 'Maentel',
            'pullover': 'Pullover',
            'schuh': 'Schuhe',
            'tasche': 'Taschen',
            'sneaker': 'Sneakers',
            'stiefel': 'Stiefel',
            'sandal': 'Sandalen',
        }

        for keyword, category in keywords.items():
            if keyword in title_lower:
                return category

        return 'Sonstiges'

    def _get_file_link(self, folder_path: Path) -> str:
        """Generate clickable file:/// link for the folder."""
        # Convert to absolute path and use forward slashes
        abs_path = folder_path.resolve()

        # Windows path to file URI
        if sys.platform == 'win32':
            # file:///C:/Users/... format
            path_str = str(abs_path).replace('\\', '/')
            return f"file:///{path_str}"
        else:
            # Unix: file:///home/... format
            return f"file://{abs_path}"

    def get_all_listings(self) -> List[Dict]:
        """Get all prepared listings."""
        listings = []

        for folder in self.output_dir.iterdir():
            if folder.is_dir() and folder.name.startswith('vinted_'):
                metadata_path = folder / "metadata.json"
                if metadata_path.exists():
                    try:
                        with open(metadata_path, 'r', encoding='utf-8') as f:
                            metadata = json.load(f)

                        metadata['folder_path'] = str(folder)
                        metadata['file_link'] = self._get_file_link(folder)
                        listings.append(metadata)
                    except:
                        pass

        # Sort by creation date
        listings.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        return listings

    def update_listing_status(
        self,
        folder_path: str,
        status: str,
        vinted_id: str = None,
        vinted_url: str = None
    ) -> bool:
        """Update listing status after manual publish."""
        try:
            metadata_path = Path(folder_path) / "metadata.json"

            if not metadata_path.exists():
                return False

            with open(metadata_path, 'r', encoding='utf-8') as f:
                metadata = json.load(f)

            metadata['status'] = status
            metadata['updated_at'] = datetime.now().isoformat()

            if vinted_id:
                metadata['vinted_listing_id'] = vinted_id
            if vinted_url:
                metadata['vinted_listing_url'] = vinted_url

            with open(metadata_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2, ensure_ascii=False)

            return True
        except Exception as e:
            logger.error(f"Failed to update listing status: {e}")
            return False

    def cleanup_published_listings(self, days_old: int = 7) -> int:
        """Remove listings that have been published and are older than X days."""
        cleaned = 0
        cutoff = datetime.now().timestamp() - (days_old * 86400)

        for folder in self.output_dir.iterdir():
            if folder.is_dir() and folder.name.startswith('vinted_'):
                metadata_path = folder / "metadata.json"
                if metadata_path.exists():
                    try:
                        with open(metadata_path, 'r', encoding='utf-8') as f:
                            metadata = json.load(f)

                        if metadata.get('status') == 'published':
                            created = datetime.fromisoformat(metadata.get('created_at', ''))
                            if created.timestamp() < cutoff:
                                shutil.rmtree(folder)
                                cleaned += 1
                    except:
                        pass

        return cleaned


# Convenience function for quick access
def prepare_vinted_manual_listing(product_data: Dict, **kwargs) -> Dict:
    """
    Quick function to prepare a Vinted manual listing.

    Args:
        product_data: Product data dict
        **kwargs: Additional options (custom_price, generate_organic_content, manipulation_level)

    Returns:
        Dict with success, folder_path, file_link, etc.
    """
    publisher = VintedManualPublisher()
    return publisher.prepare_listing(product_data, **kwargs)


if __name__ == "__main__":
    # Test the publisher
    test_product = {
        'id': 12345,
        'title': 'Nike Air Max 90 Sneaker Herren',
        'price': 45.00,
        'currency': 'EUR',
        'platform': 'ebay',
        'url': 'https://ebay.de/itm/12345',
        'brand': 'Nike',
        'size': '42',
        'color': 'Schwarz/Weiss',
        'condition': 'Sehr gut',
        'description': 'Originale Nike Air Max 90 in sehr gutem Zustand.',
        'images': [
            'https://picsum.photos/800/600',
            'https://picsum.photos/800/601',
            'https://picsum.photos/800/602'
        ]
    }

    result = prepare_vinted_manual_listing(
        test_product,
        custom_price=75.00,
        generate_organic_content=True,
        manipulation_level='medium'
    )

    print(f"\nResult: {json.dumps(result, indent=2, ensure_ascii=False)}")

    if result['success']:
        print(f"\nKlasor yolu: {result['folder_path']}")
        print(f"Tiklanabilir link: {result['file_link']}")
