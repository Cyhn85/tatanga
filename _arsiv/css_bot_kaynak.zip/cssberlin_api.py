"""
CSS Berlin - Product Listing API
Backend for cssberlin.de second-hand fashion marketplace
"""

import os
import json
import logging
import uuid
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Literal
import subprocess
import signal as sig
import os

from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Query, Request
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field
import uvicorn

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('cssberlin_api.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ========== Configuration ==========
PRODUCTS_DIR = Path('/root/videocu_v1/cssberlin_data/products')
IMAGES_DIR = Path('/root/videocu_v1/cssberlin_data/images')
PRODUCTS_DB_FILE = Path('/root/videocu_v1/cssberlin_data/products.json')

# Daemon configuration paths
DAEMON_CONFIG_FILE = Path('/opt/tatanga/stock_monitor/daemon_config.json')
DAEMON_STATUS_FILE = Path('/opt/tatanga/stock_monitor/daemon_status.json')
DAEMON_PID_FILE = Path('/opt/tatanga/stock_monitor/daemon.pid')

# IP whitelist for daemon endpoints (localhost only)
DAEMON_ALLOWED_IPS = ['127.0.0.1', '::1', 'localhost']

# Ensure directories exist
PRODUCTS_DIR.mkdir(parents=True, exist_ok=True)
IMAGES_DIR.mkdir(parents=True, exist_ok=True)

# ========== Pydantic Models ==========

# Daemon Configuration Models
class DaemonConfigRequest(BaseModel):
    """Daemon configuration update request"""
    check_interval_seconds: int = Field(ge=30, le=360, description="Check interval in seconds (30-360)")

class DaemonConfigResponse(BaseModel):
    """Current daemon configuration response"""
    check_interval_seconds: int
    products_per_minute: int
    use_ai_vision: bool
    is_running: bool
    last_updated: Optional[str] = None
    pid: Optional[int] = None

class DaemonStatusResponse(BaseModel):
    """Daemon runtime status response"""
    status: Literal["running", "stopped", "unknown"]
    uptime_seconds: Optional[int] = None
    products_checked: int = 0
    products_removed: int = 0
    errors: int = 0
    last_check: Optional[str] = None

# Product Models
class ProductBase(BaseModel):
    """Base product model"""
    name: str
    title: str
    brand: Optional[str] = None
    category: str
    subcategory: Optional[str] = None
    condition: str
    size: str
    colors: Optional[List[str]] = []
    materials: Optional[List[str]] = []
    price: float
    description: Optional[str] = None
    description_full: Optional[str] = None
    shipping_options: Optional[Dict] = None
    tags: Optional[List[str]] = []
    status: str = 'pending'

class ProductResponse(ProductBase):
    """Product response with ID and images"""
    id: str
    images: List[str]
    created_at: str
    updated_at: Optional[str] = None

class ProductListResponse(BaseModel):
    """Paginated product list"""
    total: int
    page: int
    per_page: int
    products: List[ProductResponse]

# ========== Database Functions ==========

def load_products_db() -> Dict:
    """Load products from JSON file"""
    if PRODUCTS_DB_FILE.exists():
        try:
            with open(PRODUCTS_DB_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {'products': {}}
    return {'products': {}}

def save_products_db(db: Dict):
    """Save products to JSON file"""
    PRODUCTS_DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(PRODUCTS_DB_FILE, 'w', encoding='utf-8') as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

# ========== FastAPI App ==========

app = FastAPI(
    title='CSS Berlin API',
    description='Second-hand fashion marketplace API for cssberlin.de',
    version='1.0.0',
    docs_url='/docs',
    redoc_url='/redoc'
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

# ========== Startup Event ==========

@app.on_event("startup")
async def startup_event():
    """Initialize on startup"""
    PRODUCTS_DIR.mkdir(parents=True, exist_ok=True)
    IMAGES_DIR.mkdir(parents=True, exist_ok=True)

    # Mount images directory after ensuring it exists
    app.mount('/images', StaticFiles(directory=str(IMAGES_DIR)), name='images')
    logger.info("CSS Berlin API started")

# ========== Endpoints ==========

@app.get('/')
async def root():
    """API root"""
    return {
        'name': 'CSS Berlin API',
        'version': '1.0.0',
        'status': 'online',
        'docs': '/docs'
    }

@app.get('/health')
async def health():
    """Health check"""
    db = load_products_db()
    return {
        'status': 'healthy',
        'products_count': len(db.get('products', {})),
        'timestamp': datetime.now().isoformat()
    }

@app.post('/api/products', response_model=ProductResponse)
async def create_product(
    name: str = Form(...),
    title: str = Form(...),
    brand: str = Form(None),
    category: str = Form(...),
    subcategory: str = Form(None),
    condition: str = Form(...),
    size: str = Form(...),
    colors: str = Form('[]'),
    materials: str = Form('[]'),
    price: float = Form(...),
    description: str = Form(None),
    description_full: str = Form(None),
    shipping_options: str = Form('{}'),
    tags: str = Form('[]'),
    status: str = Form('pending'),
    images: List[UploadFile] = File(...)
):
    """Create a new product listing"""
    try:
        # Generate unique ID
        product_id = str(uuid.uuid4())[:8]
        created_at = datetime.now().isoformat()

        # Parse JSON fields
        try:
            colors_list = json.loads(colors) if colors else []
            materials_list = json.loads(materials) if materials else []
            shipping_dict = json.loads(shipping_options) if shipping_options else {}
            tags_list = json.loads(tags) if tags else []
        except json.JSONDecodeError:
            colors_list = []
            materials_list = []
            shipping_dict = {}
            tags_list = []

        # Save images
        image_urls = []
        product_images_dir = IMAGES_DIR / product_id
        product_images_dir.mkdir(parents=True, exist_ok=True)

        for i, image in enumerate(images):
            # Generate unique filename
            ext = Path(image.filename).suffix or '.jpg'
            filename = f'{product_id}_{i+1}{ext}'
            filepath = product_images_dir / filename

            # Save file
            with open(filepath, 'wb') as f:
                content = await image.read()
                f.write(content)

            # Add URL (relative to images mount)
            image_urls.append(f'/images/{product_id}/{filename}')

        # Create product record
        product = {
            'id': product_id,
            'name': name,
            'title': title,
            'brand': brand,
            'category': category,
            'subcategory': subcategory,
            'condition': condition,
            'size': size,
            'colors': colors_list,
            'materials': materials_list,
            'price': price,
            'description': description,
            'description_full': description_full,
            'shipping_options': shipping_dict,
            'tags': tags_list,
            'status': status,
            'images': image_urls,
            'created_at': created_at,
            'updated_at': None
        }

        # Save to database
        db = load_products_db()
        db['products'][product_id] = product
        save_products_db(db)

        logger.info(f'Product created: {product_id} - {name}')

        return ProductResponse(**product)

    except Exception as e:
        logger.error(f'Failed to create product: {e}')
        raise HTTPException(status_code=500, detail=str(e))

@app.post('/api/automation/process')
async def automation_process(
    name: str = Form(...),
    title: str = Form(...),
    brand: str = Form(None),
    category: str = Form(...),
    subcategory: str = Form(None),
    condition: str = Form(...),
    size: str = Form(...),
    colors: str = Form('[]'),
    materials: str = Form('[]'),
    price: float = Form(...),
    description: str = Form(None),
    description_full: str = Form(None),
    shipping_options: str = Form('{}'),
    tags: str = Form('[]'),
    status: str = Form('pending'),
    created_at: str = Form(None),
    images: List[UploadFile] = File(...)
):
    """
    Process product from inserieren form (automation endpoint)
    This matches the frontend API call
    """
    return await create_product(
        name=name,
        title=title,
        brand=brand,
        category=category,
        subcategory=subcategory,
        condition=condition,
        size=size,
        colors=colors,
        materials=materials,
        price=price,
        description=description,
        description_full=description_full,
        shipping_options=shipping_options,
        tags=tags,
        status=status,
        images=images
    )

@app.get('/api/products', response_model=ProductListResponse)
async def list_products(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    category: Optional[str] = None,
    status: Optional[str] = None,
    search: Optional[str] = None
):
    """List all products with pagination and filters"""
    db = load_products_db()
    all_products = list(db.get('products', {}).values())

    # Filter by category
    if category:
        all_products = [p for p in all_products if p.get('category') == category]

    # Filter by status
    if status:
        all_products = [p for p in all_products if p.get('status') == status]

    # Search in title and description
    if search:
        search_lower = search.lower()
        all_products = [p for p in all_products if
                        search_lower in p.get('name', '').lower() or
                        search_lower in p.get('title', '').lower() or
                        search_lower in (p.get('brand') or '').lower() or
                        search_lower in (p.get('description') or '').lower()]

    # Sort by created_at (newest first)
    all_products.sort(key=lambda x: x.get('created_at', ''), reverse=True)

    # Paginate
    total = len(all_products)
    start = (page - 1) * per_page
    end = start + per_page
    products = all_products[start:end]

    return ProductListResponse(
        total=total,
        page=page,
        per_page=per_page,
        products=products
    )

@app.get('/api/products/{product_id}', response_model=ProductResponse)
async def get_product(product_id: str):
    """Get a single product by ID"""
    db = load_products_db()
    product = db.get('products', {}).get(product_id)

    if not product:
        raise HTTPException(status_code=404, detail='Product not found')

    return ProductResponse(**product)

@app.put('/api/products/{product_id}')
async def update_product(product_id: str, updates: Dict):
    """Update a product"""
    db = load_products_db()

    if product_id not in db.get('products', {}):
        raise HTTPException(status_code=404, detail='Product not found')

    # Update fields
    product = db['products'][product_id]
    for key, value in updates.items():
        if key not in ['id', 'created_at', 'images']:
            product[key] = value

    product['updated_at'] = datetime.now().isoformat()

    save_products_db(db)

    return product

@app.delete('/api/products/{product_id}')
async def delete_product(product_id: str):
    """Delete a product"""
    db = load_products_db()

    if product_id not in db.get('products', {}):
        raise HTTPException(status_code=404, detail='Product not found')

    # Delete images
    product_images_dir = IMAGES_DIR / product_id
    if product_images_dir.exists():
        shutil.rmtree(product_images_dir)

    # Delete from database
    del db['products'][product_id]
    save_products_db(db)

    logger.info(f'Product deleted: {product_id}')

    return {'status': 'deleted', 'id': product_id}

@app.get('/api/categories')
async def get_categories():
    """Get all available categories"""
    return {
        'categories': [
            {'id': 'damen', 'name': 'Damen', 'icon': '👗'},
            {'id': 'herren', 'name': 'Herren', 'icon': '👔'},
            {'id': 'kinder', 'name': 'Kinder', 'icon': '👶'},
            {'id': 'schuhe', 'name': 'Schuhe', 'icon': '👟'},
            {'id': 'accessoires', 'name': 'Accessoires', 'icon': '👜'}
        ]
    }

@app.get('/api/stats')
async def get_stats():
    """Get marketplace statistics"""
    db = load_products_db()
    products = list(db.get('products', {}).values())

    total = len(products)
    by_category = {}
    by_status = {}
    total_value = 0

    for p in products:
        cat = p.get('category', 'other')
        by_category[cat] = by_category.get(cat, 0) + 1

        status = p.get('status', 'unknown')
        by_status[status] = by_status.get(status, 0) + 1

        total_value += p.get('price', 0)

    return {
        'total_products': total,
        'by_category': by_category,
        'by_status': by_status,
        'total_value': round(total_value, 2),
        'average_price': round(total_value / total, 2) if total > 0 else 0
    }

# ========== Daemon Helper Functions ==========

def _get_daemon_pid() -> Optional[int]:
    """Get daemon PID from pidfile or systemctl"""
    try:
        if DAEMON_PID_FILE.exists():
            pid = int(DAEMON_PID_FILE.read_text().strip())
            # Check if process is actually running
            try:
                os.kill(pid, 0)  # Signal 0 just checks if process exists
                return pid
            except ProcessLookupError:
                return None
    except:
        pass

    # Fallback: parse systemctl
    try:
        result = subprocess.run(
            ['systemctl', 'show', 'tatanga-stockmonitor', '--property=MainPID'],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0 and 'MainPID=' in result.stdout:
            pid = int(result.stdout.split('=')[1].strip())
            return pid if pid > 0 else None
    except:
        pass

    return None


def _check_daemon_running() -> bool:
    """Check if daemon is running"""
    try:
        result = subprocess.run(
            ['systemctl', 'is-active', 'tatanga-stockmonitor'],
            capture_output=True, text=True, timeout=5
        )
        return result.stdout.strip() == 'active'
    except:
        # Fallback: check PID
        pid = _get_daemon_pid()
        return pid is not None


def _load_daemon_config() -> dict:
    """Load daemon config from file"""
    default_config = {
        'check_interval_seconds': 60,
        'products_per_minute': 10,
        'use_ai_vision': True,
        'last_updated': None
    }

    if DAEMON_CONFIG_FILE.exists():
        try:
            with open(DAEMON_CONFIG_FILE, 'r') as f:
                config = json.load(f)
                return {**default_config, **config}
        except:
            pass

    return default_config


def _save_daemon_config(config: dict) -> bool:
    """Save daemon config to file"""
    try:
        DAEMON_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        config['last_updated'] = datetime.now().isoformat()
        with open(DAEMON_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        return True
    except Exception as e:
        logger.error(f"Failed to save daemon config: {e}")
        return False


def _load_daemon_status() -> dict:
    """Load daemon status from file"""
    default_status = {
        'status': 'unknown',
        'products_checked': 0,
        'products_removed': 0,
        'errors': 0,
        'last_check': None
    }

    if DAEMON_STATUS_FILE.exists():
        try:
            with open(DAEMON_STATUS_FILE, 'r') as f:
                status = json.load(f)
                return {**default_status, **status}
        except:
            pass

    return default_status


def _send_sighup_to_daemon() -> bool:
    """Send SIGHUP signal to daemon for config reload"""
    pid = _get_daemon_pid()
    if pid:
        try:
            os.kill(pid, sig.SIGHUP)
            logger.info(f"Sent SIGHUP to daemon (PID: {pid})")
            return True
        except ProcessLookupError:
            logger.warning("Daemon process not found")
        except PermissionError:
            logger.warning("Permission denied to send signal")
        except Exception as e:
            logger.error(f"Failed to send SIGHUP: {e}")
    return False


def _interval_to_products_per_minute(interval_seconds: int) -> int:
    """Convert check interval to products per minute"""
    # Mapping: shorter interval = more products checked
    mapping = {
        30: 20,   # Very fast
        60: 10,   # Normal
        180: 4,   # Slow
        360: 2    # Very slow
    }
    return mapping.get(interval_seconds, 10)


# ========== Daemon API Endpoints ==========

@app.get('/api/daemon/config', response_model=DaemonConfigResponse)
async def get_daemon_config():
    """Get current daemon configuration"""
    config = _load_daemon_config()
    is_running = _check_daemon_running()
    pid = _get_daemon_pid()

    return DaemonConfigResponse(
        check_interval_seconds=config.get('check_interval_seconds', 60),
        products_per_minute=config.get('products_per_minute', 10),
        use_ai_vision=config.get('use_ai_vision', True),
        is_running=is_running,
        last_updated=config.get('last_updated'),
        pid=pid
    )


@app.post('/api/daemon/config', response_model=DaemonConfigResponse)
async def update_daemon_config(request: DaemonConfigRequest):
    """Update daemon configuration and trigger reload"""
    # Calculate products_per_minute from interval
    products_per_minute = _interval_to_products_per_minute(request.check_interval_seconds)

    config = {
        'check_interval_seconds': request.check_interval_seconds,
        'products_per_minute': products_per_minute,
        'use_ai_vision': True
    }

    # Save config
    if not _save_daemon_config(config):
        raise HTTPException(status_code=500, detail="Failed to save configuration")

    # Send SIGHUP to daemon for live reload
    _send_sighup_to_daemon()

    logger.info(f"Daemon config updated: {config}")

    return await get_daemon_config()


@app.get('/api/daemon/status', response_model=DaemonStatusResponse)
async def get_daemon_status():
    """Get daemon runtime status"""
    status = _load_daemon_status()
    is_running = _check_daemon_running()

    return DaemonStatusResponse(
        status='running' if is_running else status.get('status', 'stopped'),
        uptime_seconds=status.get('uptime_seconds'),
        products_checked=status.get('products_checked', 0),
        products_removed=status.get('products_removed', 0),
        errors=status.get('errors', 0),
        last_check=status.get('last_check')
    )


@app.post('/api/daemon/restart')
async def restart_daemon():
    """Restart the daemon service"""
    try:
        result = subprocess.run(
            ['systemctl', 'restart', 'tatanga-stockmonitor'],
            capture_output=True, text=True, timeout=30
        )

        if result.returncode == 0:
            logger.info("Daemon restarted successfully")
            return {
                'success': True,
                'message': 'Daemon restarted successfully'
            }
        else:
            logger.error(f"Failed to restart daemon: {result.stderr}")
            return {
                'success': False,
                'message': result.stderr or 'Unknown error'
            }
    except subprocess.TimeoutExpired:
        return {'success': False, 'message': 'Restart timeout'}
    except Exception as e:
        logger.error(f"Restart error: {e}")
        return {'success': False, 'message': str(e)}


# ========== Run Server ==========

if __name__ == '__main__':
    print()
    print('=' * 60)
    print('CSS Berlin API Server')
    print('=' * 60)
    print('API Docs: http://localhost:8003/docs')
    print('Health: http://localhost:8003/health')
    print('=' * 60)
    print()

    uvicorn.run(
        app,
        host='0.0.0.0',
        port=8003,
        log_level='info'
    )
