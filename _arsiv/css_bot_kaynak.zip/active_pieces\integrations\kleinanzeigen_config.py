#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
KLEINANZEIGEN CONFIG - Germany Configuration
Selectors, URL patterns, and condition mapping for Kleinanzeigen.de
"""

KLEINANZEIGEN_CONFIG = {
    'de': {
        'domain': 'kleinanzeigen.de',
        'base_url': 'https://www.kleinanzeigen.de',
        'search_url': 'https://www.kleinanzeigen.de/s-{query}/k0',
        'search_url_with_filters': 'https://www.kleinanzeigen.de/s-preis:{min_price}:{max_price}/{query}/k0',
        'language': 'de',
        'currency': 'EUR',

        # Search result selectors (multiple fallbacks)
        'item_selectors': [
            'article.aditem',
            '[data-testid="ad-listitem"]',
            '.ad-listitem',
            'li[class*="ad-listitem"]',
            '.aditem'
        ],

        # Title selectors
        'title_selectors': [
            'h2.text-module-begin a',
            '[data-testid="ad-title"]',
            '.aditem-main h2 a',
            '.ad-title a',
            'a.ellipsis'
        ],

        # Price selectors
        'price_selectors': [
            'p.aditem-main--middle--price-shipping--price',
            '[data-testid="price"]',
            '.aditem-main--middle--price-shipping--price',
            '.aditem-price',
            'p[class*="price"]'
        ],

        # Image selectors
        'image_selectors': [
            '.aditem-image img',
            '.imagebox img',
            'img[data-testid="ad-image"]',
            '.aditem img',
            'img[src*="kleinanzeigen"]'
        ],

        # Location selectors
        'location_selectors': [
            '.aditem-main--top--left',
            '[data-testid="ad-location"]',
            '.aditem-location'
        ],

        # Date selectors
        'date_selectors': [
            '.aditem-main--top--right',
            '[data-testid="ad-date"]'
        ],

        # Link selectors
        'link_selectors': [
            'article.aditem a.ellipsis',
            'h2.text-module-begin a',
            '.aditem-main h2 a',
            'a[href*="/s-anzeige/"]'
        ],

        # URL pattern for extracting ad ID
        'url_pattern': r'/s-anzeige/([^/]+)/(\d+)',

        # Condition mapping (German)
        'condition_map': {
            'new': 'Neu',
            'like_new': 'Neuwertig',
            'good': 'Gebraucht',
            'fair': 'Mit Maengeln',
            'parts': 'Defekt'
        },

        'condition_labels': {
            'Neu': 'new',
            'Neuwertig': 'like_new',
            'Gebraucht': 'good',
            'Mit Maengeln': 'fair',
            'Defekt': 'parts'
        },

        # Categories
        'categories': {
            'all': '',
            'clothing': 's-kleidung-herren',
            'clothing_women': 's-kleidung-damen',
            'shoes': 's-schuhe',
            'electronics': 's-elektronik',
            'furniture': 's-moebel',
            'sports': 's-sport-camping'
        },

        # Pagination
        'pagination': {
            'param': 'seite',
            'max_pages': 50
        }
    }
}


def get_kleinanzeigen_config(country: str = 'de') -> dict:
    """Get Kleinanzeigen config - only Germany supported"""
    return KLEINANZEIGEN_CONFIG.get(country, KLEINANZEIGEN_CONFIG['de'])


def build_search_url(query: str, min_price: float = None, max_price: float = None, category: str = None) -> str:
    """Build Kleinanzeigen search URL with filters"""
    from urllib.parse import quote_plus

    config = KLEINANZEIGEN_CONFIG['de']

    # Build base URL
    if category and category in config['categories']:
        base = f"{config['base_url']}/{config['categories'][category]}"
    else:
        base = config['base_url']

    # URL encode query (replace spaces with hyphens for Kleinanzeigen)
    query_encoded = query.replace(' ', '-')

    # Build search URL
    if min_price or max_price:
        min_p = int(min_price) if min_price else ''
        max_p = int(max_price) if max_price else ''
        search_url = f"{base}/s-preis:{min_p}:{max_p}/{query_encoded}/k0"
    else:
        search_url = f"{base}/s-{query_encoded}/k0"

    return search_url
