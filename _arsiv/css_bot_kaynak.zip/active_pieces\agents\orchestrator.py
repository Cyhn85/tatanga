#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AGENT ORCHESTRATOR - Central Agent Management System
Manages all TATANGA AI agents from a single control point

Features:
- Start/stop all agents
- Monitor agent status
- Webhook triggers
- Event-based activation
- Dashboard API
- Health monitoring

Author: TATANGA Team
Version: 1.0
"""

import sys
import json
import time
import sqlite3
import threading
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.logger import ModuleLogger

# Import agents
from agents.base_agent import BaseAgent, AgentConfig, AgentStatus
from agents.translator_agent import TranslatorAgent
from agents.fof_image_agent import FOFImageAgent
from agents.inbox_agent import InboxAgent
from agents.outbox_agent import OutboxAgent
from agents.store_agent import StoreAgent
from agents.platform_agent import PlatformAgent
from agents.accountant_agent import AccountantAgent
from agents.screenshot_agent import ScreenshotAgent
from agents.cargo_agent import CargoAgent


@dataclass
class AgentInfo:
    """Information about a registered agent"""
    name: str
    agent_class: type
    default_interval: int
    description: str
    auto_start: bool = False


# Available agents registry
AVAILABLE_AGENTS = {
    'translator': AgentInfo(
        name='translator',
        agent_class=TranslatorAgent,
        default_interval=10,
        description='24/7 Keyword and listing translation',
        auto_start=True
    ),
    'fof_image': AgentInfo(
        name='fof_image',
        agent_class=FOFImageAgent,
        default_interval=30,
        description='Image analysis and background processing',
        auto_start=False
    ),
    # Factory System Agents
    'inbox': AgentInfo(
        name='inbox',
        agent_class=InboxAgent,
        default_interval=60,
        description='Incoming messages handler (translate, risk, notify)',
        auto_start=True
    ),
    'outbox': AgentInfo(
        name='outbox',
        agent_class=OutboxAgent,
        default_interval=30,
        description='Outgoing message queue with rate limiting',
        auto_start=True
    ),
    'store': AgentInfo(
        name='store',
        agent_class=StoreAgent,
        default_interval=300,
        description='Store notifications (sales, stock, messages)',
        auto_start=True
    ),
    'platform': AgentInfo(
        name='platform',
        agent_class=PlatformAgent,
        default_interval=900,
        description='Platform events (price, availability, new listings)',
        auto_start=True
    ),
    # Accounting Agent
    'accountant': AgentInfo(
        name='accountant',
        agent_class=AccountantAgent,
        default_interval=300,
        description='Accounting: sales, purchases, expenses, invoices (Muhasebe)',
        auto_start=True
    ),
    # Screenshot Agent
    'screenshot': AgentInfo(
        name='screenshot',
        agent_class=ScreenshotAgent,
        default_interval=30,
        description='AI-powered visual scraping (URL → Screenshot → AI Analysis)',
        auto_start=True
    ),
    # Cargo Agent
    'cargo': AgentInfo(
        name='cargo',
        agent_class=CargoAgent,
        default_interval=300,
        description='Cargo tracking (DHL, Hermes, GLS, DPD) with Telegram notifications',
        auto_start=True
    ),
}


class AgentOrchestrator:
    """
    Central controller for all TATANGA AI agents

    Usage:
        orchestrator = AgentOrchestrator()

        # Start all auto-start agents
        orchestrator.start_all()

        # Start specific agent
        orchestrator.start_agent('translator')

        # Stop agent
        orchestrator.stop_agent('translator')

        # Get status
        status = orchestrator.get_all_status()

        # Webhook trigger
        orchestrator.trigger_agent('translator')

        # Stop all
        orchestrator.stop_all()
    """

    def __init__(self):
        """Initialize Orchestrator"""
        self.logger = ModuleLogger('orchestrator')

        # Active agent instances
        self.agents: Dict[str, BaseAgent] = {}

        # Lock for thread safety
        self._lock = threading.Lock()

        # Orchestrator database
        self.db_path = Path(__file__).parent.parent / 'storage' / 'orchestrator.db'
        self._init_db()

        # Event callbacks
        self._on_agent_start_callbacks = []
        self._on_agent_stop_callbacks = []
        self._on_agent_error_callbacks = []

        self.logger.info("Agent Orchestrator initialized")

    def _init_db(self):
        """Initialize orchestrator database"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Agent configuration table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_config (
                agent_name TEXT PRIMARY KEY,
                interval_seconds INTEGER,
                enabled INTEGER DEFAULT 1,
                auto_start INTEGER DEFAULT 0,
                last_started DATETIME,
                last_stopped DATETIME,
                config_json TEXT
            )
        """)

        # Events log
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS orchestrator_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT NOT NULL,
                agent_name TEXT,
                details TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        conn.commit()
        conn.close()

    def _log_event(self, event_type: str, agent_name: str = None, details: Dict = None):
        """Log orchestrator event"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO orchestrator_events (event_type, agent_name, details)
                VALUES (?, ?, ?)
            """, (event_type, agent_name, json.dumps(details) if details else None))
            conn.commit()
            conn.close()
        except Exception as e:
            self.logger.error(f"Event logging failed: {e}")

    # ========================================================================
    # AGENT MANAGEMENT
    # ========================================================================

    def get_available_agents(self) -> List[Dict]:
        """Get list of available agents"""
        return [
            {
                'name': info.name,
                'description': info.description,
                'default_interval': info.default_interval,
                'auto_start': info.auto_start,
                'is_running': info.name in self.agents and self.agents[info.name].status != AgentStatus.STOPPED
            }
            for info in AVAILABLE_AGENTS.values()
        ]

    def start_agent(
        self,
        agent_name: str,
        interval_seconds: int = None
    ) -> bool:
        """
        Start a specific agent

        Args:
            agent_name: Agent name from AVAILABLE_AGENTS
            interval_seconds: Custom interval (uses default if None)

        Returns:
            True if started successfully
        """
        with self._lock:
            # Check if already running
            if agent_name in self.agents:
                existing = self.agents[agent_name]
                if existing.status != AgentStatus.STOPPED:
                    self.logger.warning(f"Agent '{agent_name}' already running")
                    return False

            # Get agent info
            if agent_name not in AVAILABLE_AGENTS:
                self.logger.error(f"Unknown agent: {agent_name}")
                return False

            info = AVAILABLE_AGENTS[agent_name]

            # Use custom or default interval
            interval = interval_seconds or info.default_interval

            try:
                # Create agent instance
                agent = info.agent_class(interval_seconds=interval)

                # Register callbacks
                agent.on_start(lambda: self._on_agent_started(agent_name))
                agent.on_stop(lambda: self._on_agent_stopped(agent_name))
                agent.on_error(lambda e: self._on_agent_error(agent_name, e))

                # Start agent
                agent.start()

                # Store reference
                self.agents[agent_name] = agent

                # Update database
                self._save_agent_config(agent_name, interval, enabled=True)
                self._log_event('agent_started', agent_name, {'interval': interval})

                self.logger.info(f"Started agent: {agent_name} (interval: {interval}s)")
                return True

            except Exception as e:
                self.logger.error(f"Failed to start {agent_name}: {e}")
                self._log_event('agent_start_failed', agent_name, {'error': str(e)})
                return False

    def stop_agent(self, agent_name: str, timeout: float = 10.0) -> bool:
        """
        Stop a specific agent

        Args:
            agent_name: Agent name
            timeout: Stop timeout in seconds

        Returns:
            True if stopped successfully
        """
        with self._lock:
            if agent_name not in self.agents:
                self.logger.warning(f"Agent '{agent_name}' not running")
                return False

            try:
                agent = self.agents[agent_name]
                agent.stop(timeout=timeout)

                self._save_agent_config(agent_name, enabled=False)
                self._log_event('agent_stopped', agent_name)

                self.logger.info(f"Stopped agent: {agent_name}")
                return True

            except Exception as e:
                self.logger.error(f"Failed to stop {agent_name}: {e}")
                return False

    def start_all(self, auto_start_only: bool = True) -> Dict[str, bool]:
        """
        Start all agents

        Args:
            auto_start_only: Only start agents marked as auto_start

        Returns:
            Dict mapping agent name to start success
        """
        results = {}

        for name, info in AVAILABLE_AGENTS.items():
            if auto_start_only and not info.auto_start:
                continue

            results[name] = self.start_agent(name)

        started = sum(1 for v in results.values() if v)
        self.logger.info(f"Started {started}/{len(results)} agents")
        self._log_event('bulk_start', details={'results': results})

        return results

    def stop_all(self, timeout: float = 10.0) -> Dict[str, bool]:
        """
        Stop all running agents

        Returns:
            Dict mapping agent name to stop success
        """
        results = {}

        for name in list(self.agents.keys()):
            results[name] = self.stop_agent(name, timeout=timeout)

        stopped = sum(1 for v in results.values() if v)
        self.logger.info(f"Stopped {stopped}/{len(results)} agents")
        self._log_event('bulk_stop', details={'results': results})

        return results

    def restart_agent(self, agent_name: str) -> bool:
        """Restart an agent"""
        self.stop_agent(agent_name)
        time.sleep(1)
        return self.start_agent(agent_name)

    def trigger_agent(self, agent_name: str) -> bool:
        """
        Manually trigger an agent to run immediately

        Args:
            agent_name: Agent to trigger

        Returns:
            True if trigger sent
        """
        if agent_name not in self.agents:
            self.logger.warning(f"Agent '{agent_name}' not running")
            return False

        try:
            self.agents[agent_name].trigger()
            self._log_event('agent_triggered', agent_name)
            self.logger.info(f"Triggered agent: {agent_name}")
            return True
        except Exception as e:
            self.logger.error(f"Trigger failed: {e}")
            return False

    def pause_agent(self, agent_name: str) -> bool:
        """Pause an agent"""
        if agent_name not in self.agents:
            return False

        self.agents[agent_name].pause()
        self._log_event('agent_paused', agent_name)
        return True

    def resume_agent(self, agent_name: str) -> bool:
        """Resume a paused agent"""
        if agent_name not in self.agents:
            return False

        self.agents[agent_name].resume()
        self._log_event('agent_resumed', agent_name)
        return True

    # ========================================================================
    # STATUS & MONITORING
    # ========================================================================

    def get_agent_status(self, agent_name: str) -> Optional[Dict]:
        """Get status of a specific agent"""
        if agent_name not in self.agents:
            return None

        return self.agents[agent_name].get_status()

    def get_all_status(self) -> Dict[str, Dict]:
        """Get status of all running agents"""
        return {
            name: agent.get_status()
            for name, agent in self.agents.items()
        }

    def get_health_report(self) -> Dict:
        """Get overall health report"""
        running = 0
        paused = 0
        error = 0
        stopped = 0

        for agent in self.agents.values():
            status = agent.status
            if status == AgentStatus.RUNNING:
                running += 1
            elif status == AgentStatus.PAUSED:
                paused += 1
            elif status == AgentStatus.ERROR:
                error += 1
            else:
                stopped += 1

        return {
            'timestamp': datetime.now().isoformat(),
            'total_registered': len(AVAILABLE_AGENTS),
            'total_running': len(self.agents),
            'status_breakdown': {
                'running': running,
                'paused': paused,
                'error': error,
                'stopped': stopped
            },
            'agents': self.get_all_status()
        }

    def get_recent_events(self, limit: int = 50) -> List[Dict]:
        """Get recent orchestrator events"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                SELECT event_type, agent_name, details, created_at
                FROM orchestrator_events
                ORDER BY created_at DESC
                LIMIT ?
            """, (limit,))

            rows = cursor.fetchall()
            conn.close()

            return [
                {
                    'event_type': row[0],
                    'agent_name': row[1],
                    'details': json.loads(row[2]) if row[2] else None,
                    'timestamp': row[3]
                }
                for row in rows
            ]
        except Exception as e:
            self.logger.error(f"Failed to get events: {e}")
            return []

    # ========================================================================
    # CALLBACKS
    # ========================================================================

    def _on_agent_started(self, agent_name: str):
        """Internal callback when agent starts"""
        for callback in self._on_agent_start_callbacks:
            try:
                callback(agent_name)
            except:
                pass

    def _on_agent_stopped(self, agent_name: str):
        """Internal callback when agent stops"""
        for callback in self._on_agent_stop_callbacks:
            try:
                callback(agent_name)
            except:
                pass

    def _on_agent_error(self, agent_name: str, error: Exception):
        """Internal callback when agent has error"""
        self._log_event('agent_error', agent_name, {'error': str(error)})

        for callback in self._on_agent_error_callbacks:
            try:
                callback(agent_name, error)
            except:
                pass

    def on_agent_start(self, callback):
        """Register callback for agent start events"""
        self._on_agent_start_callbacks.append(callback)

    def on_agent_stop(self, callback):
        """Register callback for agent stop events"""
        self._on_agent_stop_callbacks.append(callback)

    def on_agent_error(self, callback):
        """Register callback for agent error events"""
        self._on_agent_error_callbacks.append(callback)

    # ========================================================================
    # CONFIGURATION
    # ========================================================================

    def _save_agent_config(
        self,
        agent_name: str,
        interval_seconds: int = None,
        enabled: bool = None
    ):
        """Save agent configuration to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO agent_config (agent_name, interval_seconds, enabled, last_started)
            VALUES (?, ?, ?, datetime('now'))
            ON CONFLICT(agent_name) DO UPDATE SET
                interval_seconds = COALESCE(?, interval_seconds),
                enabled = COALESCE(?, enabled),
                last_started = CASE WHEN ? = 1 THEN datetime('now') ELSE last_started END,
                last_stopped = CASE WHEN ? = 0 THEN datetime('now') ELSE last_stopped END
        """, (
            agent_name, interval_seconds, 1 if enabled else 0,
            interval_seconds, 1 if enabled else None,
            1 if enabled else 0, 1 if enabled else 0
        ))

        conn.commit()
        conn.close()

    def get_saved_config(self, agent_name: str) -> Optional[Dict]:
        """Get saved configuration for an agent"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT interval_seconds, enabled, auto_start, last_started, last_stopped
            FROM agent_config
            WHERE agent_name = ?
        """, (agent_name,))

        row = cursor.fetchone()
        conn.close()

        if row:
            return {
                'interval_seconds': row[0],
                'enabled': bool(row[1]),
                'auto_start': bool(row[2]),
                'last_started': row[3],
                'last_stopped': row[4]
            }

        return None


# Global orchestrator instance
_orchestrator_instance = None


def get_orchestrator() -> AgentOrchestrator:
    """Get global orchestrator instance"""
    global _orchestrator_instance
    if _orchestrator_instance is None:
        _orchestrator_instance = AgentOrchestrator()
    return _orchestrator_instance


# Test
if __name__ == "__main__":
    print("=" * 60)
    print("AGENT ORCHESTRATOR - TEST")
    print("=" * 60)
    print()

    orchestrator = get_orchestrator()

    print("Available agents:")
    for agent in orchestrator.get_available_agents():
        status = "RUNNING" if agent['is_running'] else "STOPPED"
        auto = " (auto-start)" if agent['auto_start'] else ""
        print(f"  [{status}] {agent['name']}: {agent['description']}{auto}")

    print()
    print("Health report:")
    health = orchestrator.get_health_report()
    print(f"  Total registered: {health['total_registered']}")
    print(f"  Currently running: {health['total_running']}")
    print(f"  Status breakdown: {health['status_breakdown']}")

    print()
    print("Recent events:")
    for event in orchestrator.get_recent_events(5):
        print(f"  [{event['timestamp']}] {event['event_type']}: {event['agent_name']}")

    print()
    print("=" * 60)
    print("Commands:")
    print("  orchestrator.start_all()     - Start all auto-start agents")
    print("  orchestrator.start_agent('translator')  - Start specific agent")
    print("  orchestrator.stop_agent('translator')   - Stop specific agent")
    print("  orchestrator.trigger_agent('translator') - Trigger immediate run")
    print("  orchestrator.get_health_report()        - Get health status")
    print("  orchestrator.stop_all()      - Stop all agents")
    print("=" * 60)
