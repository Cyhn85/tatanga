#!/usr/bin/env python3
"""
CSS Berlin Source Validator - Hetzner 7/24 Version
Her 30 dakikada kaynak URL kontrolu yapar
Satilmis/mevcut olmayan urunleri GitHub API ile siler
"""

import json
import requests
import base64
import time
import logging
from datetime import datetime
from pathlib import Path

# Config
GITHUB_REPO = "cyhyradev/CSS-Berlin-Website"
GITHUB_TOKEN = ""  # Will be loaded from .env
JSON_FILE = "scraped-products.json"
LOG_FILE = "/var/log/cssberlin_validator.log"

# Sold indicators
SOLD_INDICATORS = [
    'verkauft', 'sold', 'nicht mehr verfugbar', 'not available',
    'reserviert', 'reserved', 'ausverkauft', 'out of stock',
    'deaktiviert', 'deactivated', 'geloscht', 'deleted',
    'abgelaufen', 'expired', 'nicht gefunden', 'not found',
    'anzeige wurde deaktiviert', 'anzeige existiert nicht',
    'diese anzeige ist nicht mehr verfugbar', 'seite nicht gefunden',
]

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


def load_token():
    """Load GitHub token from .env file"""
    env_path = Path('/opt/cssberlin/.env')
    if env_path.exists():
        with open(env_path, 'r') as f:
            for line in f:
                if line.startswith('GITHUB_TOKEN='):
                    return line.split('=', 1)[1].strip().strip('"').strip("'")
    return None


def get_json_from_github(token):
    """Fetch JSON from GitHub API"""
    url = f"https://api.github.com/repos/{GITHUB_REPO}/contents/{JSON_FILE}"
    headers = {
        'Authorization': f'token {token}',
        'Accept': 'application/vnd.github.v3+json'
    }

    response = requests.get(url, headers=headers, timeout=30)
    if response.status_code != 200:
        logger.error(f"GitHub API error: {response.status_code}")
        return None, None

    data = response.json()
    content = base64.b64decode(data['content']).decode('utf-8')
    sha = data['sha']

    return json.loads(content), sha


def update_json_on_github(token, data, sha, message):
    """Update JSON on GitHub via API"""
    url = f"https://api.github.com/repos/{GITHUB_REPO}/contents/{JSON_FILE}"
    headers = {
        'Authorization': f'token {token}',
        'Accept': 'application/vnd.github.v3+json'
    }

    content = json.dumps(data, ensure_ascii=False, indent=2)
    encoded = base64.b64encode(content.encode('utf-8')).decode('utf-8')

    payload = {
        'message': message,
        'content': encoded,
        'sha': sha,
        'committer': {
            'name': 'CSS Berlin Bot',
            'email': 'bot@css-berlin.de'
        }
    }

    response = requests.put(url, headers=headers, json=payload, timeout=30)
    return response.status_code == 200


def check_source_availability(url, timeout=15):
    """Check if source URL is still available"""
    if not url or url in ['unknown', 'Unknown', '']:
        return {'available': None, 'reason': 'No source URL'}

    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
        }

        response = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)

        if response.status_code == 404:
            return {'available': False, 'reason': '404 Not Found'}

        if response.status_code == 410:
            return {'available': False, 'reason': '410 Gone'}

        if response.status_code >= 400:
            return {'available': False, 'reason': f'HTTP {response.status_code}'}

        # Check content for sold indicators
        content_lower = response.text.lower()
        for indicator in SOLD_INDICATORS:
            if indicator in content_lower:
                return {'available': False, 'reason': f'Sold: {indicator}'}

        return {'available': True, 'reason': 'OK'}

    except requests.exceptions.Timeout:
        return {'available': False, 'reason': 'Timeout'}
    except requests.exceptions.ConnectionError:
        return {'available': False, 'reason': 'Connection Error'}
    except Exception as e:
        return {'available': False, 'reason': str(e)[:50]}


def run_validation():
    """Main validation function"""
    logger.info("=" * 50)
    logger.info("HETZNER SOURCE VALIDATION STARTED")
    logger.info("=" * 50)

    # Load token
    token = load_token()
    if not token:
        logger.error("GitHub token not found in .env")
        return

    # Get JSON from GitHub
    logger.info("Fetching JSON from GitHub...")
    data, sha = get_json_from_github(token)
    if not data:
        logger.error("Failed to fetch JSON from GitHub")
        return

    products = data.get('products', [])
    logger.info(f"Total products: {len(products)}")

    # Filter products with source URL
    products_with_source = [p for p in products if p.get('source_url') and p['source_url'] not in ['unknown', 'Unknown', '']]
    logger.info(f"Products with source URL: {len(products_with_source)}")

    if not products_with_source:
        logger.info("No products to check")
        return

    # Check each product
    sold_products = []
    for i, product in enumerate(products_with_source):
        source_url = product.get('source_url', '')
        logger.info(f"Checking [{i+1}/{len(products_with_source)}]: {source_url[:60]}...")

        result = check_source_availability(source_url)

        if result['available'] == False:
            sold_products.append({
                'id': product.get('id'),
                'title': product.get('title', '')[:40],
                'reason': result['reason']
            })
            logger.info(f"  -> SOLD: {result['reason']}")
        else:
            logger.info(f"  -> OK")

        time.sleep(0.5)  # Rate limiting

    # Remove sold products
    if sold_products:
        logger.info(f"")
        logger.info(f"{'='*50}")
        logger.info(f"{len(sold_products)} SOLD PRODUCTS DETECTED")
        logger.info(f"{'='*50}")

        sold_ids = {p['id'] for p in sold_products}
        original_count = len(products)
        products = [p for p in products if p.get('id') not in sold_ids]

        # Update data
        data['products'] = products
        data['stats']['total_products'] = len(products)
        data['stats']['last_updated'] = datetime.now().strftime('%Y-%m-%d')

        # Push to GitHub
        message = f"Auto-remove {len(sold_products)} sold products (Hetzner validator)"
        logger.info(f"Pushing to GitHub: {message}")

        if update_json_on_github(token, data, sha, message):
            logger.info(f"SUCCESS: {original_count} -> {len(products)} products")
        else:
            logger.error("Failed to update GitHub")
    else:
        logger.info("No sold products found")

    logger.info("VALIDATION COMPLETED")


if __name__ == '__main__':
    run_validation()
