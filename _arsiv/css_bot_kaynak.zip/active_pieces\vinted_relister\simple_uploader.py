# Vinted Simple Uploader - Playwright with visible browser
# User watches and can intervene if needed

import os
import sys
import time
import random

sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from playwright.sync_api import sync_playwright
from human_behavior import HumanBehavior
from utils.database import db
from config import STATUS_VALIDATED, STATUS_UPLOADED

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
PROFILE_DIR = os.path.join(BASE_DIR, 'browser_profiles', 'cssberlin')
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PROFILE_DIR, exist_ok=True)

# Credentials
EMAIL = "cssberlin@hotmail.com"
PASSWORD = "Css200231"


def wait_for_user(message="Devam etmek icin ENTER'a basin..."):
    """Wait for user input"""
    input(f"\n>>> {message}")


def upload_product(page, human, product):
    """Upload single product"""
    title = product.get('processed_title', product.get('raw_title', ''))
    desc = product.get('processed_description', product.get('raw_description', ''))
    price = product.get('price', 0)
    images_path = product.get('processed_images_path', product.get('raw_images_path', ''))

    print(f"\n{'='*50}")
    print(f"  {title[:45]}...")
    print(f"  Fiyat: {price} EUR")
    print(f"{'='*50}")

    # Go to upload page
    print("\n[1] Upload sayfasi...")
    page.goto('https://www.vinted.de/items/new', wait_until='networkidle', timeout=60000)
    time.sleep(2)

    # Upload images
    print("[2] Resimler...")
    if images_path and os.path.exists(images_path):
        images = [os.path.join(images_path, f) for f in os.listdir(images_path)
                  if f.lower().endswith(('.jpg', '.jpeg', '.png'))][:5]
        if images:
            file_input = page.query_selector('input[type="file"]')
            if file_input:
                file_input.set_input_files(images)
                print(f"    {len(images)} resim yuklendi")
                time.sleep(3)

    human.between_actions()

    # Fill title
    print("[3] Baslik...")
    for sel in ['[data-testid="title-input"]', 'input[name="title"]', '#title']:
        el = page.query_selector(sel)
        if el:
            el.click()
            time.sleep(0.3)
            el.fill('')
            human.human_type(el, title, mistakes=False)
            break
    time.sleep(2)  # Wait for category

    human.between_actions()

    # Fill description
    print("[4] Aciklama...")
    for sel in ['[data-testid="description-textarea"]', 'textarea[name="description"]', '#description']:
        el = page.query_selector(sel)
        if el:
            el.click()
            time.sleep(0.3)
            el.fill(desc)  # Paste directly for speed
            break

    human.between_actions()

    # Fill price
    print("[5] Fiyat...")
    for sel in ['[data-testid="price-input"]', 'input[name="price"]', '#price']:
        el = page.query_selector(sel)
        if el:
            el.click()
            time.sleep(0.3)
            el.fill(str(int(price)))
            break

    # Screenshot
    ss = os.path.join(DATA_DIR, f'simple_{product["id"]}.png')
    page.screenshot(path=ss, full_page=True)
    print(f"\n    Screenshot: {ss}")

    # User check
    print("\n" + "="*50)
    print("  FORMU KONTROL ET!")
    print("  Tarayicida kategori vs. sec")
    print("="*50)
    wait_for_user("Hazirsa ENTER, iptal icin 'n' yaz: ")

    # Publish
    print("[6] Yayinlaniyor...")
    for sel in ['button:has-text("Hochladen")', 'button[type="submit"]']:
        btn = page.query_selector(sel)
        if btn and btn.is_visible():
            btn.click()
            break

    time.sleep(5)

    if '/items/' in page.url and '/new' not in page.url:
        print("[OK] YAYINLANDI!")
        return True
    return True


def main():
    print("=" * 60)
    print("  VINTED SIMPLE UPLOADER")
    print("  Tarayici acilacak, sen izle ve gerekirse mudahale et")
    print("=" * 60)

    products = db.get_products_by_status(STATUS_VALIDATED)
    print(f"\n{len(products)} urun hazir")

    if not products:
        print("Yuklenecek urun yok!")
        return

    with sync_playwright() as pw:
        # Open browser with profile (remembers login)
        print("\n[*] Tarayici aciliyor...")
        browser = pw.chromium.launch_persistent_context(
            user_data_dir=PROFILE_DIR,
            headless=False,
            viewport={'width': 1200, 'height': 800},
            locale='de-DE'
        )

        page = browser.pages[0] if browser.pages else browser.new_page()
        human = HumanBehavior(page)

        # Go to Vinted
        print("[*] Vinted.de...")
        page.goto('https://www.vinted.de/', wait_until='networkidle', timeout=60000)
        time.sleep(2)

        # Check login
        login_btn = page.query_selector('a:has-text("Registrieren | Einloggen")')
        if login_btn:
            print("\n[!] Login gerekli!")
            print("    Tarayicida manuel olarak giris yap.")
            print("    E-Mail: cssberlin@hotmail.com")
            print("    Sifre: Css200231")
            wait_for_user("Login yaptiktan sonra ENTER...")

        # Upload
        uploaded = 0
        for i, p in enumerate(products):
            print(f"\n### URUN {i+1}/{len(products)} ###")
            try:
                if upload_product(page, human, p):
                    db.update_product(p['id'], {'status': STATUS_UPLOADED, 'target_store': 'cssberlin'})
                    db.add_log(p['id'], 'upload', 'success', 'Simple uploader')
                    uploaded += 1

                if i < len(products) - 1:
                    wait_for_user("Sonraki urun icin ENTER...")

            except Exception as e:
                print(f"[ERROR] {e}")
                if input("Devam? (y/n): ").lower() != 'y':
                    break

        print(f"\n{'='*60}")
        print(f"  BITTI: {uploaded}/{len(products)}")
        print(f"{'='*60}")

        wait_for_user("Tarayiciyi kapatmak icin ENTER...")
        browser.close()


if __name__ == '__main__':
    main()
