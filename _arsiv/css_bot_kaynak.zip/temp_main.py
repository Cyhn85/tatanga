from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import redis
from config import settings

# Import routers
from api.products import router as products_router
from api.favorites import router as favorites_router
from api.accounting import router as accounting_router
from api.scraping import router as scraping_router
from api.monitoring import router as monitoring_router
from api.auth import router as auth_router
from api.settings import router as settings_router
from api.dashboard import router as dashboard_router
from api.publishing import router as publishing_router

# Redis connection
redis_client = redis.from_url(settings.redis_url, decode_responses=True)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    print(f"Starting {settings.app_name}...")
    try:
        redis_client.ping()
        print("Redis connected successfully")
    except Exception as e:
        print(f"Redis connection failed: {e}")
    yield
    # Shutdown
    print(f"Shutting down {settings.app_name}...")

app = FastAPI(
    title=settings.app_name,
    description="E-Commerce Automation Platform",
    version="3.0.0",
    lifespan=lifespan
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure properly in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth_router, prefix="/api/auth", tags=["Authentication"])
app.include_router(dashboard_router, prefix="/api/dashboard", tags=["Dashboard"])
app.include_router(products_router, prefix="/api/products", tags=["Products"])
app.include_router(favorites_router, prefix="/api/favorites", tags=["Favorites"])
app.include_router(scraping_router, prefix="/api/scraping", tags=["Scraping"])
app.include_router(monitoring_router, prefix="/api/monitoring", tags=["Monitoring"])
app.include_router(publishing_router, prefix="/api/publishing", tags=["Publishing"])
app.include_router(accounting_router, prefix="/api/accounting", tags=["Accounting"])
app.include_router(settings_router, prefix="/api/settings", tags=["Settings"])

@app.get("/")
async def root():
    return {
        "name": settings.app_name,
        "version": "3.0.0",
        "status": "running"
    }

@app.get("/health")
async def health_check():
    try:
        redis_client.ping()
        redis_status = "healthy"
    except:
        redis_status = "unhealthy"

    return {
        "status": "healthy",
        "redis": redis_status
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8600, reload=True)
