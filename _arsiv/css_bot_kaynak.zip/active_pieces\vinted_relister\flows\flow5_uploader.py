# Flow 5: Vinted Uploader - Full form automation
import sys, os, time, random, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')

from playwright.sync_api import sync_playwright
from config import (BASE_DIR, PROCESSED_DIR, STATUS_VALIDATED, STATUS_UPLOADED,
                    DELAY_BETWEEN_PRODUCTS, DELAY_BETWEEN_FIELDS, DELAY_BETWEEN_CHARS)
from utils.database import db

class VintedUploader:
    def __init__(self, target_store: str):
        self.target_store = target_store
        self.store = db.get_store_by_name(target_store)
        if not self.store:
            raise ValueError(f'Store not found: {target_store}')
        self.playwright_profile = self.store.get('chrome_profile', target_store)
        self.proxy_enabled = self.store.get('proxy_enabled', 0)
        self.proxy_host = self.store.get('proxy_host', '')
        self.proxy_port = self.store.get('proxy_port', 0)

    def get_browser(self, pw):
        pdir = os.path.join(BASE_DIR, 'playwright_profiles', self.playwright_profile)
        os.makedirs(pdir, exist_ok=True)
        args = ['--disable-blink-features=AutomationControlled', '--no-sandbox']
        if self.proxy_enabled and self.proxy_host:
            args.append(f'--proxy-server=http://{self.proxy_host}:{self.proxy_port}')
            print(f'[PROXY] {self.proxy_host}:{self.proxy_port}')
        return pw.chromium.launch_persistent_context(user_data_dir=pdir, headless=False,
            args=args, viewport={'width':1920,'height':1080}, locale='de-DE', timezone_id='Europe/Berlin')

    def human_type(self, page, selector, text):
        """Type text with human-like delays"""
        el = page.query_selector(selector)
        if not el:
            print(f'[WARN] Selector not found: {selector}')
            return False
        el.click()
        time.sleep(random.uniform(0.3, 0.6))
        for char in text:
            page.keyboard.type(char, delay=random.randint(50, 150))
        return True

    def random_delay(self, min_sec=2, max_sec=4):
        """Random human-like delay"""
        time.sleep(random.uniform(min_sec, max_sec))

    def upload_images(self, page, product):
        """Upload product images"""
        proc_path = product.get('processed_images_path', '')
        if not proc_path or not os.path.exists(proc_path):
            print('[WARN] No processed images')
            return False

        images = [f for f in os.listdir(proc_path) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
        if not images:
            print('[WARN] No image files found')
            return False

        print(f'[IMG] Uploading {len(images)} images...')

        # Find file input
        file_input = page.query_selector('input[type="file"]')
        if not file_input:
            # Try clicking add photos button first
            add_btn = page.query_selector('[data-testid="add-photos"], [class*="photo-upload"]')
            if add_btn:
                add_btn.click()
                self.random_delay(1, 2)
            file_input = page.query_selector('input[type="file"]')

        if file_input:
            # Upload all images at once
            image_paths = [os.path.join(proc_path, img) for img in images[:10]]
            file_input.set_input_files(image_paths)
            print(f'[OK] {len(image_paths)} images selected')
            self.random_delay(3, 5)  # Wait for upload
            return True
        else:
            print('[ERR] File input not found')
            return False

    def fill_title(self, page, product):
        """Fill product title"""
        title = product.get('processed_title', product.get('raw_title', ''))
        if not title:
            return False

        # Try different selectors
        selectors = [
            '[data-testid="title-input"]',
            'input[name="title"]',
            '[class*="title"] input',
            'input[placeholder*="Titel"]'
        ]

        for sel in selectors:
            el = page.query_selector(sel)
            if el:
                el.click()
                el.fill('')  # Clear first
                self.random_delay(0.3, 0.6)
                el.fill(title)
                print(f'[OK] Title: {title[:40]}...')
                self.random_delay(1, 2)
                return True

        print('[WARN] Title field not found')
        return False

    def fill_description(self, page, product):
        """Fill product description"""
        desc = product.get('processed_description', product.get('raw_description', ''))
        if not desc:
            return False

        # Try different selectors
        selectors = [
            '[data-testid="description-textarea"]',
            'textarea[name="description"]',
            '[class*="description"] textarea',
            'textarea[placeholder*="Beschreib"]'
        ]

        for sel in selectors:
            el = page.query_selector(sel)
            if el:
                el.click()
                el.fill('')
                self.random_delay(0.3, 0.6)
                el.fill(desc)
                print(f'[OK] Description: {len(desc)} chars')
                self.random_delay(1, 2)
                return True

        print('[WARN] Description field not found')
        return False

    def fill_price(self, page, product):
        """Fill product price"""
        price = product.get('price', 0)
        if not price:
            return False

        price_str = str(int(price))

        selectors = [
            '[data-testid="price-input"]',
            'input[name="price"]',
            '[class*="price"] input',
            'input[placeholder*="Preis"]'
        ]

        for sel in selectors:
            el = page.query_selector(sel)
            if el:
                el.click()
                el.fill('')
                self.random_delay(0.3, 0.6)
                el.fill(price_str)
                print(f'[OK] Price: {price_str} EUR')
                self.random_delay(1, 2)
                return True

        print('[WARN] Price field not found')
        return False

    def select_category(self, page, product):
        """Select product category"""
        # Click category selector
        cat_btn = page.query_selector('[data-testid="category-select"], [class*="category"] button, [class*="Category"]')
        if cat_btn:
            cat_btn.click()
            self.random_delay(1, 2)

            # Try to select based on product brand/type
            brand = product.get('brand', '').lower()

            # Map brands to categories
            if any(x in brand for x in ['apple', 'samsung', 'huawei', 'xiaomi', 'iphone']):
                # Electronics/Phones
                page.keyboard.type('Handy')
                self.random_delay(0.5, 1)
                # Click first result
                first_option = page.query_selector('[role="option"], [class*="option"]')
                if first_option:
                    first_option.click()
                    print('[OK] Category: Elektronik')
                    return True
            elif any(x in brand for x in ['nike', 'adidas', 'puma', 'reebok']):
                page.keyboard.type('Schuhe')
                self.random_delay(0.5, 1)
                first_option = page.query_selector('[role="option"], [class*="option"]')
                if first_option:
                    first_option.click()
                    print('[OK] Category: Schuhe')
                    return True

        print('[INFO] Category selection skipped')
        return False

    def fill_brand(self, page, product):
        """Fill brand field"""
        brand = product.get('brand', '')
        if not brand:
            return False

        selectors = [
            '[data-testid="brand-select"]',
            '[data-testid="brand-input"]',
            'input[name="brand"]',
            '[class*="brand"] input'
        ]

        for sel in selectors:
            el = page.query_selector(sel)
            if el:
                el.click()
                self.random_delay(0.3, 0.6)
                el.fill(brand)
                self.random_delay(1, 2)
                # Select from dropdown if available
                first_option = page.query_selector('[role="option"], [class*="option"]')
                if first_option:
                    first_option.click()
                print(f'[OK] Brand: {brand}')
                return True

        return False

    def fill_condition(self, page, product):
        """Select product condition"""
        condition = product.get('condition', 'Sehr gut')

        cond_btn = page.query_selector('[data-testid="condition-select"], [class*="condition"] button')
        if cond_btn:
            cond_btn.click()
            self.random_delay(1, 2)

            # Map conditions
            cond_map = {
                'Neu mit Etikett': 'Neu',
                'Neu': 'Neu',
                'Sehr gut': 'Sehr gut',
                'Gut': 'Gut',
                'Befriedigend': 'Befriedigend'
            }
            target = cond_map.get(condition, 'Sehr gut')

            options = page.query_selector_all('[role="option"], [class*="option"]')
            for opt in options:
                if target.lower() in opt.inner_text().lower():
                    opt.click()
                    print(f'[OK] Condition: {target}')
                    return True

        return False

    def submit_form(self, page):
        """Submit the upload form"""
        submit_selectors = [
            '[data-testid="submit-button"]',
            'button[type="submit"]',
            '[class*="submit"] button',
            'button:has-text("Hochladen")',
            'button:has-text("Artikel hochladen")'
        ]

        for sel in submit_selectors:
            btn = page.query_selector(sel)
            if btn and btn.is_visible():
                print('[SUBMIT] Clicking upload button...')
                btn.click()
                self.random_delay(3, 5)
                return True

        print('[WARN] Submit button not found')
        return False

    def upload_product(self, product: dict) -> bool:
        """Upload a single product to Vinted"""
        title = product.get('processed_title', product.get('raw_title', '?'))
        print(f'\n[UPLOAD] {title[:50]}')

        with sync_playwright() as pw:
            br = self.get_browser(pw)
            pg = br.pages[0] if br.pages else br.new_page()

            try:
                # Go to upload page
                pg.goto('https://www.vinted.de/items/new', wait_until='domcontentloaded', timeout=60000)
                self.random_delay(3, 5)

                # Accept cookies if shown
                try:
                    cookie_btn = pg.query_selector('[data-testid="cookie-consent-accept-all"]')
                    if cookie_btn:
                        cookie_btn.click()
                        self.random_delay(1, 2)
                except:
                    pass

                # Check if logged in
                if pg.query_selector('[data-testid="header-login-button"]'):
                    print('[ERROR] Not logged in! Please login first.')
                    br.close()
                    return False

                # Wait for form to load
                self.random_delay(2, 3)

                # 1. Upload images
                self.upload_images(pg, product)
                self.random_delay(2, 4)

                # 2. Fill title
                self.fill_title(pg, product)
                self.random_delay(*DELAY_BETWEEN_FIELDS)

                # 3. Fill description
                self.fill_description(pg, product)
                self.random_delay(*DELAY_BETWEEN_FIELDS)

                # 4. Select category
                self.select_category(pg, product)
                self.random_delay(*DELAY_BETWEEN_FIELDS)

                # 5. Fill brand
                self.fill_brand(pg, product)
                self.random_delay(*DELAY_BETWEEN_FIELDS)

                # 6. Fill condition
                self.fill_condition(pg, product)
                self.random_delay(*DELAY_BETWEEN_FIELDS)

                # 7. Fill price
                self.fill_price(pg, product)
                self.random_delay(2, 4)

                # 8. Submit form
                # Note: For safety, we don't auto-submit in first version
                print('[INFO] Form filled - waiting for manual verification...')
                print('[INFO] Press Enter in terminal to continue or Ctrl+C to abort')

                try:
                    input()
                    self.submit_form(pg)
                    self.random_delay(5, 8)
                    print('[OK] Upload submitted')
                    success = True
                except KeyboardInterrupt:
                    print('[ABORT] Skipped by user')
                    success = False

                br.close()
                return success

            except Exception as e:
                print(f'[ERROR] {e}')
                br.close()
                return False

    def run(self, limit: int = 15, auto_submit: bool = False) -> int:
        """Run uploader for all validated products"""
        print('='*50 + f'\nUPLOADER: {self.target_store}\n' + '='*50)

        if self.proxy_enabled:
            print(f'[PROXY] Using {self.proxy_host}:{self.proxy_port}')
            print('[!] Make sure mobile hotspot is connected!')

        products = db.get_products_by_status(STATUS_VALIDATED)[:limit]
        print(f'{len(products)} products to upload\n')

        if not products:
            print('[INFO] No products to upload')
            return 0

        done = 0
        for i, p in enumerate(products):
            print(f'\n--- Product {i+1}/{len(products)} ---')
            if self.upload_product(p):
                db.update_product(p['id'], {
                    'status': STATUS_UPLOADED,
                    'target_store': self.target_store,
                    'uploaded_at': 'datetime("now")'
                })
                db.add_log(p['id'], 'upload', 'success', f'To {self.target_store}')
                done += 1
            else:
                db.add_log(p['id'], 'upload', 'failed', 'Upload aborted or failed')

            if i < len(products) - 1:
                delay = random.randint(*DELAY_BETWEEN_PRODUCTS)
                print(f'\n[WAIT] {delay}s before next product...')
                time.sleep(delay)

        print(f'\n*** DONE: {done}/{len(products)} uploaded ***')
        return done

def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--store', default='cssberlin')
    p.add_argument('--limit', type=int, default=15)
    p.add_argument('--auto', action='store_true', help='Auto-submit without confirmation')
    a = p.parse_args()
    return VintedUploader(a.store).run(a.limit, a.auto)

if __name__ == '__main__': main()
