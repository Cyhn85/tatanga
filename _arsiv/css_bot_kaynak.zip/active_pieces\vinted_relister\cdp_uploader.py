# Vinted CDP Uploader - Connects to existing Chrome browser
# Uses human-like behavior to avoid bot detection

import os
import sys
import time
import random

sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from playwright.sync_api import sync_playwright
from human_behavior import HumanBehavior
from utils.database import db
from config import STATUS_VALIDATED, STATUS_UPLOADED

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
os.makedirs(DATA_DIR, exist_ok=True)

# Account configurations
ACCOUNTS = {
    'cyhn54': {
        'network': 'Ev WiFi',
        'login_method': 'Google',
        'avatar_hint': 'personal_photo',
    },
    'cssberlin': {
        'email': 'cssberlin@hotmail.com',
        'password': 'Css200231',
        'network': 'Mobil Hotspot + Every Proxy',
        'login_method': 'Email',
        'avatar_hint': 'css_logo',
    }
}


def print_banner():
    print("=" * 60)
    print("  VINTED CDP UPLOADER")
    print("  Mevcut Chrome tarayiciya baglanir")
    print("=" * 60)


def select_account():
    """Let user select which account to use"""
    print("\nHangi hesap ile islem yapilacak?")
    print("-" * 40)
    print("  [1] cyhn54      (Ev WiFi)")
    print("  [2] cssberlin   (Mobil Hotspot + Proxy)")
    print("-" * 40)

    while True:
        choice = input("\nSeciminiz (1/2): ").strip()
        if choice == '1':
            return 'cyhn54'
        elif choice == '2':
            return 'cssberlin'
        print("Gecersiz secim! 1 veya 2 girin.")


def check_network(account):
    """Remind user about network requirements"""
    config = ACCOUNTS[account]
    network = config['network']

    print(f"\n{'='*50}")
    print(f"  HESAP: {account}")
    print(f"  GEREKEN AG: {network}")
    print(f"{'='*50}")

    if account == 'cssberlin':
        print("\n!!! UYARI !!!")
        print("  1. Mobil Hotspot'u ACIN")
        print("  2. Every Proxy'yi AKTIF EDIN")
        print("  3. Ev WiFi'dan CIKTIGINIZDAN emin olun")

    input("\nHazir oldugunuzda ENTER'a basin...")


def connect_to_chrome():
    """Connect to existing Chrome via CDP"""
    print("\n[*] Chrome'a baglaniliyor (port 9222)...")

    try:
        pw = sync_playwright().start()
        browser = pw.chromium.connect_over_cdp("http://localhost:9222")
        print("[OK] Chrome'a baglandi!")

        # Get contexts and pages
        contexts = browser.contexts
        if not contexts:
            print("[ERROR] Acik sayfa bulunamadi!")
            return None, None, None

        # Find Vinted tab or use first tab
        page = None
        for ctx in contexts:
            for p in ctx.pages:
                if 'vinted' in p.url.lower():
                    page = p
                    print(f"[OK] Vinted sekmesi bulundu: {p.url}")
                    break
            if page:
                break

        if not page:
            page = contexts[0].pages[0]
            print(f"[INFO] Ilk sekme kullaniliyor: {page.url}")

        return pw, browser, page

    except Exception as e:
        print(f"[ERROR] Chrome'a baglanilamadi: {e}")
        print("\nCozum:")
        print("  1. Chrome'u KAPATIN")
        print("  2. Bu komutu calistirin:")
        print('     "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" --remote-debugging-port=9222')
        print("  3. Scripti tekrar calistirin")
        return None, None, None


def detect_logged_account(page):
    """Check which account is logged in by looking at avatar"""
    # Check if logged in at all
    login_btn = page.query_selector('a:has-text("Registrieren | Einloggen")')
    if login_btn:
        return None  # Not logged in

    # Try to get avatar
    avatar = page.query_selector('[data-testid*="avatar"] img, .header img, nav img')
    if avatar:
        src = avatar.get_attribute('src') or ''
        # cssberlin has CSS logo
        if 'css' in src.lower() or 'climate' in src.lower():
            return 'cssberlin'
        else:
            return 'cyhn54'  # Personal photo

    return 'unknown'


def wait_for_login(page, expected_account, timeout_minutes=10):
    """Wait for user to login manually"""
    print(f"\n[*] Login bekleniyor (max {timeout_minutes} dakika)...")
    print("    Manuel olarak giris yapin.")
    print("    Captcha cikarsa cozun.")

    start = time.time()
    max_wait = timeout_minutes * 60

    while time.time() - start < max_wait:
        current = detect_logged_account(page)

        if current:
            if current == expected_account or current == 'unknown':
                print(f"\n[OK] Login algilandi: {current}")
                return True
            else:
                print(f"\n[WARN] Yanlis hesap! Beklenen: {expected_account}, Mevcut: {current}")
                return False

        remaining = int(max_wait - (time.time() - start))
        mins = remaining // 60
        secs = remaining % 60
        print(f"\r  Login bekleniyor... {mins}:{secs:02d} kaldi", end='', flush=True)
        time.sleep(3)

    print("\n[ERROR] Zaman asimi!")
    return False


def select_dropdown_value(page, dropdown_text, value_text, human):
    """Click a dropdown and select a value"""
    try:
        # Find dropdown by its label or placeholder text
        dropdown = page.query_selector(f'div:has-text("{dropdown_text}") >> xpath=following-sibling::*[1]')
        if not dropdown:
            dropdown = page.query_selector(f'[aria-label*="{dropdown_text}"]')
        if not dropdown:
            dropdown = page.query_selector(f'button:has-text("{dropdown_text}")')

        if dropdown:
            dropdown.click()
            human.between_actions(min_delay=0.5, max_delay=1)

            # Wait for dropdown options to appear
            time.sleep(0.5)

            # Click the option
            option = page.query_selector(f'[role="option"]:has-text("{value_text}")')
            if not option:
                option = page.query_selector(f'li:has-text("{value_text}")')
            if not option:
                option = page.query_selector(f'div[role="listbox"] >> text="{value_text}"')

            if option:
                option.click()
                return True
    except Exception as e:
        print(f"    [WARN] Dropdown secim hatasi ({dropdown_text}): {e}")
    return False


def select_color(page, color_name, human):
    """Select a color from the color picker"""
    try:
        # Find and click color section
        color_section = page.query_selector('div:has-text("Farbe")')
        if color_section:
            color_section.click()
            time.sleep(0.5)

        # Color mapping German
        color_map = {
            'schwarz': 'Schwarz', 'black': 'Schwarz',
            'weiß': 'Weiß', 'weiss': 'Weiß', 'white': 'Weiß',
            'blau': 'Blau', 'blue': 'Blau',
            'rot': 'Rot', 'red': 'Rot',
            'grün': 'Grün', 'green': 'Grün',
            'gelb': 'Gelb', 'yellow': 'Gelb',
            'grau': 'Grau', 'grey': 'Grau', 'gray': 'Grau',
            'braun': 'Braun', 'brown': 'Braun',
            'beige': 'Beige',
            'rosa': 'Rosa', 'pink': 'Rosa',
            'türkis': 'Türkis', 'turquoise': 'Türkis',
            'orange': 'Orange',
            'lila': 'Lila', 'purple': 'Lila',
        }

        german_color = color_map.get(color_name.lower(), color_name)

        # Try to click color option
        color_opt = page.query_selector(f'[data-testid="color-select-{german_color.lower()}"]')
        if not color_opt:
            color_opt = page.query_selector(f'button:has-text("{german_color}")')
        if not color_opt:
            color_opt = page.query_selector(f'label:has-text("{german_color}")')
        if not color_opt:
            color_opt = page.query_selector(f'div[role="option"]:has-text("{german_color}")')

        if color_opt:
            color_opt.click()
            human.between_actions(min_delay=0.3, max_delay=0.6)
            return True

    except Exception as e:
        print(f"    [WARN] Renk secim hatasi: {e}")
    return False


def select_condition(page, condition, human):
    """Select condition/Zustand from dropdown"""
    # Condition mapping
    condition_map = {
        'new_with_tags': 'Neu mit Etikett',
        'new_without_tags': 'Neu ohne Etikett',
        'very_good': 'Sehr gut',
        'good': 'Gut',
        'satisfactory': 'Zufriedenstellend'
    }

    german_condition = condition_map.get(condition, 'Gut')

    try:
        # Click on Zustand dropdown
        zustand = page.query_selector('div:has-text("Zustand") >> xpath=ancestor::div[contains(@class, "cell")]')
        if not zustand:
            zustand = page.query_selector('[data-testid="item-status"]')
        if not zustand:
            # Try clicking directly on the dropdown area
            zustand = page.locator('text=Zustand').locator('xpath=..').locator('button, div[role="button"]').first

        if zustand:
            zustand.click()
            time.sleep(0.5)

            # Select condition option
            option = page.query_selector(f'[role="option"]:has-text("{german_condition}")')
            if not option:
                option = page.query_selector(f'li:has-text("{german_condition}")')
            if not option:
                option = page.locator(f'text="{german_condition}"').first

            if option:
                option.click()
                return True

    except Exception as e:
        print(f"    [WARN] Zustand secim hatasi: {e}")
    return False


def select_package_size(page, size='medium', human=None):
    """Select package size (Klein/Mittel/Groß)"""
    size_map = {
        'small': 'Klein',
        'medium': 'Mittel',
        'large': 'Groß'
    }

    german_size = size_map.get(size, 'Mittel')

    try:
        # Find and click package size radio
        radio = page.query_selector(f'input[type="radio"][value*="{german_size}"]')
        if not radio:
            label = page.query_selector(f'label:has-text("{german_size}")')
            if label:
                label.click()
                return True
        else:
            radio.click()
            return True

    except Exception as e:
        print(f"    [WARN] Paket boyutu hatasi: {e}")
    return False


def fill_price_field(page, price, human):
    """Fill price field - handles Vinted's specific price input"""
    try:
        # Vinted uses a special price input
        price_selectors = [
            'input[name="price"]',
            '[data-testid="price-input"] input',
            'input[inputmode="decimal"]',
            'input[placeholder*="0,00"]',
            'div:has-text("Preis") input'
        ]

        for sel in price_selectors:
            el = page.query_selector(sel)
            if el:
                el.click()
                time.sleep(0.2)
                # Clear existing value
                el.fill('')
                time.sleep(0.1)
                # Type price
                price_str = str(int(float(price)))
                el.type(price_str, delay=100)
                print(f"    Fiyat girildi: {price_str} EUR")
                return True

        # Alternative: find by aria-label
        el = page.query_selector('[aria-label*="Preis"]')
        if el:
            el.fill(str(int(float(price))))
            return True

    except Exception as e:
        print(f"    [WARN] Fiyat girisi hatasi: {e}")
    return False


def detect_product_colors(title, description):
    """Detect colors from title and description"""
    colors = []
    text = (title + ' ' + description).lower()

    color_keywords = {
        'schwarz': 'schwarz', 'black': 'schwarz',
        'weiß': 'weiß', 'weiss': 'weiß', 'white': 'weiß',
        'blau': 'blau', 'blue': 'blau',
        'rot': 'rot', 'red': 'rot',
        'grün': 'grün', 'green': 'grün',
        'gelb': 'gelb', 'yellow': 'gelb',
        'grau': 'grau', 'grey': 'grau', 'gray': 'grau',
        'braun': 'braun', 'brown': 'braun',
        'türkis': 'türkis', 'turquoise': 'türkis',
        'pink': 'rosa', 'rosa': 'rosa',
        'orange': 'orange',
        'lila': 'lila', 'purple': 'lila',
        'beige': 'beige',
    }

    for keyword, color in color_keywords.items():
        if keyword in text and color not in colors:
            colors.append(color)
            if len(colors) >= 2:  # Max 2 colors
                break

    return colors if colors else ['schwarz']  # Default to black


def detect_package_size(title):
    """Detect package size from product type"""
    title_lower = title.lower()

    # Large items
    if any(x in title_lower for x in ['jacke', 'mantel', 'coat', 'jacket', 'pullover', 'sweater']):
        return 'large'

    # Small items
    if any(x in title_lower for x in ['cap', 'mütze', 'hat', 'gürtel', 'belt', 'schal', 'scarf']):
        return 'small'

    # Medium (default) - shoes, t-shirts, etc.
    return 'medium'


def upload_product(page, human, product):
    """Upload a single product with human-like behavior - FULL FORM FILLING"""
    title = product.get('processed_title', product.get('raw_title', ''))
    desc = product.get('processed_description', product.get('raw_description', ''))
    price = product.get('price', 0)
    images_path = product.get('processed_images_path', product.get('raw_images_path', ''))

    # Detect additional attributes
    colors = detect_product_colors(title, desc)
    package_size = detect_package_size(title)
    condition = product.get('condition', 'good')

    print(f"\n{'='*50}")
    print(f"  URUN: {title[:45]}...")
    print(f"  FIYAT: {price} EUR")
    print(f"  RENKLER: {', '.join(colors)}")
    print(f"  PAKET: {package_size}")
    print(f"{'='*50}")

    # 1. Go to upload page
    print("\n[1] Upload sayfasina gidiliyor...")
    page.goto('https://www.vinted.de/items/new', wait_until='networkidle', timeout=60000)
    human.between_actions()
    time.sleep(2)

    # Take screenshot
    ss_path = os.path.join(DATA_DIR, f'upload_{product.get("id", "unknown")}_step1.png')
    page.screenshot(path=ss_path)
    print(f"    Screenshot: {ss_path}")

    # 2. Upload images
    print("\n[2] Resimler yukleniyor...")
    if images_path and os.path.exists(images_path):
        images = [os.path.join(images_path, f) for f in os.listdir(images_path)
                  if f.lower().endswith(('.jpg', '.jpeg', '.png'))][:10]

        if images:
            file_input = page.query_selector('input[type="file"]')
            if file_input:
                file_input.set_input_files(images)
                print(f"    {len(images)} resim yuklendi")
                # Wait for upload
                time.sleep(3 + len(images))
                human.random_scroll()

    human.between_actions()

    # 3. Fill title
    print("\n[3] Baslik yaziliyor...")
    title_selectors = [
        '[data-testid="title-input"]',
        'input[name="title"]',
        'input[placeholder*="Titel"]',
        'input[placeholder*="title"]',
        '#title'
    ]

    for sel in title_selectors:
        if human.fill_field(sel, title):
            print(f"    Baslik girildi: {title[:40]}...")
            break

    human.between_actions()
    time.sleep(2)  # Wait for category suggestion

    # 4. Fill description
    print("\n[4] Aciklama yaziliyor...")
    desc_selectors = [
        '[data-testid="description-textarea"]',
        'textarea[name="description"]',
        'textarea[placeholder*="Beschreib"]',
        '#description'
    ]

    for sel in desc_selectors:
        if human.fill_field(sel, desc):
            print(f"    Aciklama girildi ({len(desc)} karakter)")
            break

    human.between_actions()

    # 5. Wait for category fields to load (after title auto-suggest)
    print("\n[5] Kategori alanlarinin yuklenmesi bekleniyor...")
    time.sleep(3)  # Wait for category to auto-populate from title

    # Scroll down to see more fields
    human.random_scroll()
    time.sleep(1)

    # 6. Select condition (Zustand)
    print("\n[6] Zustand (durum) seciliyor...")
    if select_condition(page, condition, human):
        print("    Zustand secildi")
    else:
        # Try clicking on Zustand dropdown directly
        try:
            page.click('div:has-text("Zustand")', timeout=3000)
            time.sleep(0.5)
            page.click('text="Gut"', timeout=3000)
            print("    Zustand: Gut")
        except:
            print("    [SKIP] Zustand manuel secilebilir")

    human.between_actions()

    # 7. Select colors (Farbe)
    print("\n[7] Renk(ler) seciliyor...")
    try:
        # Click on Farbe dropdown area
        farbe_area = page.query_selector('div:has-text("Farbe")')
        if farbe_area:
            farbe_area.click()
            time.sleep(0.5)

        for color in colors[:2]:  # Max 2 colors
            if select_color(page, color, human):
                print(f"    Renk secildi: {color}")
            time.sleep(0.3)
    except Exception as e:
        print(f"    [SKIP] Renk manuel secilebilir: {e}")

    human.between_actions()

    # 8. Fill price (Preis) - IMPORTANT: Must be filled!
    print("\n[8] Fiyat giriliyor...")
    if not fill_price_field(page, price, human):
        # Fallback method
        price_selectors = [
            '[data-testid="price-input"]',
            'input[name="price"]',
            'input[placeholder*="Preis"]',
            '#price'
        ]
        for sel in price_selectors:
            if human.fill_field(sel, str(int(price))):
                print(f"    Fiyat: {price} EUR")
                break

    human.between_actions()

    # 9. Select package size (Paketgröße)
    print("\n[9] Paket boyutu seciliyor...")
    if select_package_size(page, package_size, human):
        print(f"    Paket: {package_size}")
    else:
        # Default to Mittel
        try:
            page.click('label:has-text("Mittel")', timeout=3000)
            print("    Paket: Mittel (varsayilan)")
        except:
            print("    [SKIP] Paket boyutu manuel secilebilir")

    human.between_actions()

    # Scroll to bottom to see publish button
    page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
    time.sleep(1)

    # Take screenshot before publish
    ss_path = os.path.join(DATA_DIR, f'upload_{product.get("id", "unknown")}_ready.png')
    page.screenshot(path=ss_path, full_page=True)
    print(f"\n    Form hazir - Screenshot: {ss_path}")

    # 10. Show summary and wait
    print("\n" + "="*50)
    print("  FORM DOLDURULDU!")
    print(f"  - Baslik: {title[:30]}...")
    print(f"  - Fiyat: {price} EUR")
    print(f"  - Renkler: {', '.join(colors)}")
    print(f"  - Paket: {package_size}")
    print("="*50)

    # Auto-confirm after 3 seconds
    print("\n[AUTO] 3 saniye sonra yayinlanacak...")
    time.sleep(3)

    # 11. Click publish button
    print("\n[10] Hochladen butonuna tiklanıyor...")
    publish_clicked = False

    publish_selectors = [
        'button:has-text("Hochladen")',
        'button:has-text("Artikel hochladen")',
        'button[data-testid="submit-button"]',
        'button[type="submit"]:has-text("Hochladen")',
        'form button[type="submit"]'
    ]

    for sel in publish_selectors:
        try:
            btn = page.query_selector(sel)
            if btn and btn.is_visible():
                btn.scroll_into_view_if_needed()
                time.sleep(0.3)
                btn.click()
                publish_clicked = True
                print("    Hochladen butonuna tiklandi!")
                break
        except:
            continue

    if not publish_clicked:
        # Try locator method
        try:
            page.locator('button:has-text("Hochladen")').first.click()
            publish_clicked = True
            print("    Hochladen tiklandi (locator)")
        except:
            print("    [WARN] Hochladen butonu bulunamadi - manuel tiklayin!")

    # Wait for upload
    time.sleep(5)

    # Take final screenshot
    ss_path = os.path.join(DATA_DIR, f'upload_{product.get("id", "unknown")}_done.png')
    page.screenshot(path=ss_path)
    print(f"    Final screenshot: {ss_path}")

    # Check if successful (URL should change to item page)
    current_url = page.url
    if '/items/' in current_url and '/new' not in current_url:
        print("\n[OK] URUN BASARIYLA YAYINLANDI!")
        return True
    elif 'vinted.de' in current_url:
        print(f"\n[INFO] Sayfa URL: {current_url}")
        # Wait a bit more and check again
        time.sleep(3)
        current_url = page.url
        if '/items/' in current_url and '/new' not in current_url:
            print("[OK] YAYINLANDI!")
            return True
        print("[WARN] Yayinlama durumu belirsiz - devam ediliyor")
        return True
    else:
        print(f"\n[WARN] Beklenmeyen URL: {current_url}")
        return True  # Assume success


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--account', choices=['cyhn54', 'cssberlin'],
                        help='Account to use (skip interactive selection)')
    parser.add_argument('--skip-network-check', action='store_true',
                        help='Skip network check prompt')
    parser.add_argument('--auto-confirm', action='store_true',
                        help='Auto-confirm uploads without asking')
    args = parser.parse_args()

    print_banner()

    # 1. Select account
    if args.account:
        account = args.account
        print(f"\n[INFO] Hesap secildi: {account}")
    else:
        account = select_account()

    # 2. Check network (skip if requested)
    if not args.skip_network_check:
        check_network(account)
    else:
        print(f"\n[INFO] Ag kontrolu atlandi. Hesap: {account}")

    # 3. Connect to Chrome
    pw, browser, page = connect_to_chrome()
    if not page:
        return

    try:
        # 4. Go to Vinted
        if 'vinted' not in page.url.lower():
            print("\n[*] Vinted.de'ye gidiliyor...")
            page.goto('https://www.vinted.de/', wait_until='networkidle', timeout=60000)
            time.sleep(2)

        # 5. Check login status
        current_account = detect_logged_account(page)
        print(f"\n[INFO] Mevcut hesap: {current_account or 'Giris yapilmamis'}")

        if not current_account:
            # Wait for manual login
            if not wait_for_login(page, account):
                print("[ERROR] Login basarisiz!")
                return

        # 6. Initialize human behavior
        human = HumanBehavior(page)

        # 7. Get products to upload
        products = db.get_products_by_status(STATUS_VALIDATED)
        print(f"\n[INFO] {len(products)} urun yuklemeye hazir")

        if not products:
            print("[INFO] Yuklenecek urun yok!")
            return

        # 8. Upload products
        uploaded = 0
        for i, product in enumerate(products):
            print(f"\n{'#'*60}")
            print(f"  URUN {i+1}/{len(products)}")
            print(f"{'#'*60}")

            try:
                if upload_product(page, human, product):
                    # Update database
                    db.update_product(product['id'], {
                        'status': STATUS_UPLOADED,
                        'target_store': account
                    })
                    db.add_log(product['id'], 'upload', 'success', f'Uploaded to {account}')
                    uploaded += 1

                # Delay between products
                if i < len(products) - 1:
                    delay = random.randint(30, 60)
                    print(f"\n[WAIT] Sonraki urun icin {delay}s bekleniyor...")
                    for remaining in range(delay, 0, -1):
                        print(f"\r  {remaining}s...", end='', flush=True)
                        time.sleep(1)
                    print()

            except Exception as e:
                print(f"\n[ERROR] Hata: {e}")
                db.add_log(product['id'], 'upload', 'failed', str(e))
                print("[AUTO] 3 saniye sonra devam edilecek...")
                time.sleep(3)

        # Summary
        print(f"\n{'='*60}")
        print(f"  TAMAMLANDI: {uploaded}/{len(products)} urun yuklendi")
        print(f"{'='*60}")

    finally:
        # Don't close browser - user's browser
        print("\n[INFO] Tarayici acik kaldi (kullanicinin tarayicisi)")
        if pw:
            pw.stop()


if __name__ == '__main__':
    main()
