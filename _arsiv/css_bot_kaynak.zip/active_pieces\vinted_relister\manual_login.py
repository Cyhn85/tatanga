# Manual login helper - opens browser without proxy, waits for login
import os
import sys
import time
sys.stdout.reconfigure(encoding='utf-8')
from playwright.sync_api import sync_playwright

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def manual_login():
    """Open browser for manual login - NO PROXY - waits until user logs in"""
    print("=" * 60)
    print("VINTED MANUAL LOGIN")
    print("=" * 60)
    print("\nOpening browser WITHOUT proxy...")
    print("Please login to cssberlin account manually.\n")

    profile_dir = os.path.join(BASE_DIR, 'playwright_profiles', 'cssberlin')
    os.makedirs(profile_dir, exist_ok=True)

    with sync_playwright() as pw:
        # NO PROXY - direct connection for login
        browser = pw.chromium.launch_persistent_context(
            user_data_dir=profile_dir,
            headless=False,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--no-sandbox',
                '--start-maximized'
            ],
            viewport={'width': 1400, 'height': 900},
            locale='de-DE',
            timezone_id='Europe/Berlin'
        )

        page = browser.pages[0] if browser.pages else browser.new_page()

        print("[1] Going to Vinted.de...")
        page.goto('https://www.vinted.de/', wait_until='networkidle', timeout=60000)
        page.wait_for_timeout(2000)

        # Accept cookies if shown
        try:
            cookie_btn = page.query_selector('[data-testid="cookie-consent-accept-all"], button:has-text("Alle zulassen")')
            if cookie_btn:
                cookie_btn.click()
                print("[OK] Cookies accepted")
                page.wait_for_timeout(1000)
        except:
            pass

        print("\n" + "=" * 60)
        print("BROWSER OPEN - PLEASE LOGIN!")
        print("=" * 60)
        print("""
STEPS:
1. Click 'Einloggen' link at bottom of popup
2. Click 'E-Mail' to login with email
3. Enter cssberlin email and password
4. Complete login

Browser will wait until you're logged in...
        """)

        # Wait for login - check every 5 seconds for up to 5 minutes
        logged_in = False
        for i in range(60):
            page.wait_for_timeout(5000)

            # Check if logged in by looking for login button
            login_btn = page.query_selector('[data-testid="header-login-button"], a:has-text("Registrieren"), a:has-text("Einloggen")')

            # Also check URL
            current_url = page.url

            # If no login button found on main page, user is logged in
            if not login_btn and 'vinted.de' in current_url and '/auth/' not in current_url:
                print(f"\n[OK] Login detected! URL: {current_url}")
                logged_in = True
                break

            # Check if on profile or items page (definitely logged in)
            if '/member/' in current_url or '/items/new' in current_url:
                print(f"\n[OK] Logged in! URL: {current_url}")
                logged_in = True
                break

            print(f"[{(i+1)*5}s] Waiting for login... URL: {current_url[:60]}")

        if logged_in:
            print("\n[2] Going to upload page...")
            page.goto('https://www.vinted.de/items/new', wait_until='domcontentloaded', timeout=60000)
            page.wait_for_timeout(3000)

            # Take screenshot
            ss_path = os.path.join(BASE_DIR, 'data', 'upload_form_logged_in.png')
            os.makedirs(os.path.dirname(ss_path), exist_ok=True)
            page.screenshot(path=ss_path)
            print(f"[OK] Screenshot saved: {ss_path}")

            # List form elements
            print("\n[3] Form elements on upload page:")
            elements = page.query_selector_all('input, textarea, button, select')
            for i, el in enumerate(elements[:25]):
                try:
                    tag = el.evaluate('e => e.tagName')
                    testid = el.get_attribute('data-testid') or ''
                    name = el.get_attribute('name') or ''
                    el_type = el.get_attribute('type') or ''
                    placeholder = el.get_attribute('placeholder') or ''
                    if testid or name or placeholder:
                        print(f"  {i+1}. {tag} | testid={testid} | name={name} | type={el_type}")
                except:
                    pass

            print("\n[SUCCESS] Login complete! Session saved.")
            print("You can now run the uploader.")

        else:
            print("\n[TIMEOUT] 5 minutes passed without login.")
            print("Please try again.")

        # Keep browser open for 30 more seconds
        print("\nBrowser closing in 30 seconds...")
        page.wait_for_timeout(30000)
        browser.close()

if __name__ == '__main__':
    manual_login()
