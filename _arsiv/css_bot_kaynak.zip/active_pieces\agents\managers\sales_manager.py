#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Sales Manager
Manages product uploads, favorites, and sales tracking

Features:
- Favorite system with availability tracking
- Product upload/listing management
- Sales tracking and reporting
- Auto-cleanup of non-favorites (7 days)
- Price adjustment automation
- Cross-platform listing

Author: TATANGA Team
Version: 1.0
"""

import sys
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from pathlib import Path
import sqlite3
import json

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")


class SalesManager:
    """
    Sales Manager - Handles favorites, uploads, and sales

    Responsibilities:
    1. Manage favorite products list
    2. Track product availability (sold/available)
    3. Handle product uploads to platforms
    4. Auto-cleanup non-favorites after 7 days
    5. Sales reporting
    """

    # Language-specific "SOLD" indicators
    SOLD_KEYWORDS = {
        'de': ['verkauft', 'ausverkauft', 'nicht mehr verfügbar', 'bereits verkauft'],
        'en': ['sold', 'sold out', 'no longer available', 'item sold'],
        'fr': ['vendu', 'épuisé', 'plus disponible', 'article vendu'],
        'es': ['vendido', 'agotado', 'no disponible'],
        'it': ['venduto', 'esaurito', 'non disponibile'],
        'nl': ['verkocht', 'uitverkocht', 'niet meer beschikbaar'],
        'pl': ['sprzedane', 'wyprzedane', 'niedostępne'],
        'sv': ['såld', 'slutsåld', 'ej tillgänglig'],
        'da': ['solgt', 'udsolgt', 'ikke tilgængelig'],
        'no': ['solgt', 'utsolgt', 'ikke tilgjengelig'],
        'cs': ['prodáno', 'vyprodáno', 'nedostupné'],
        'fi': ['myyty', 'loppuunmyyty', 'ei saatavilla'],
    }

    def __init__(self, ceo_agent):
        """
        Initialize Sales Manager

        Args:
            ceo_agent: Reference to CEO Agent
        """
        self.ceo = ceo_agent
        self.logger = ModuleLogger("sales_manager")

        # Database
        self.db_path = Path(__file__).parent.parent.parent / 'storage' / 'sales.db'
        self._init_database()

        # Upload queue
        self.upload_queue: List[Dict] = []

        # Statistics
        self.stats = {
            'favorites_count': 0,
            'products_sold': 0,
            'products_uploaded': 0,
            'revenue_total': 0.0
        }

        # Vision agent for availability checking
        self.vision_agent = None

        self.logger.info("Sales Manager initialized")

    def _init_database(self):
        """Initialize sales database"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Favorites table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS favorites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id TEXT NOT NULL,
                platform TEXT NOT NULL,
                url TEXT NOT NULL,
                title TEXT,
                price REAL,
                currency TEXT,
                condition TEXT,
                language TEXT,
                is_available BOOLEAN DEFAULT 1,
                is_sold BOOLEAN DEFAULT 0,
                last_checked DATETIME,
                added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                notes TEXT,
                UNIQUE(platform, product_id)
            )
        """)

        # Sales table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id TEXT NOT NULL,
                platform TEXT NOT NULL,
                buyer_id TEXT,
                sale_price REAL NOT NULL,
                original_price REAL,
                shipping_cost REAL DEFAULT 0,
                platform_fee REAL DEFAULT 0,
                net_profit REAL,
                currency TEXT,
                sale_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'completed',
                notes TEXT
            )
        """)

        # Uploads table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS uploads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_product_id TEXT,
                source_platform TEXT,
                target_platform TEXT NOT NULL,
                listing_id TEXT,
                title TEXT,
                price REAL,
                status TEXT DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                published_at DATETIME,
                error TEXT
            )
        """)

        # Cleanup log
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS cleanup_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cleanup_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                products_removed INTEGER,
                space_freed_mb REAL
            )
        """)

        conn.commit()
        conn.close()

    # ==================== FAVORITES ====================

    async def add_to_favorites(self, product: Dict, notes: str = None) -> bool:
        """
        Add a product to favorites

        Args:
            product: Product data dict
            notes: Optional notes

        Returns:
            Success status
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT OR REPLACE INTO favorites
                (product_id, platform, url, title, price, currency, condition, language, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                product.get('id') or product.get('product_id'),
                product.get('platform'),
                product.get('url'),
                product.get('title'),
                product.get('price'),
                product.get('currency'),
                product.get('condition'),
                product.get('language'),
                notes
            ))

            conn.commit()
            conn.close()

            self.stats['favorites_count'] += 1
            self.logger.info(f"Added to favorites: {product.get('title', 'Unknown')[:50]}")

            return True

        except Exception as e:
            self.logger.error("Failed to add favorite", exception=str(e))
            return False

    async def remove_from_favorites(self, product_id: str, platform: str) -> bool:
        """Remove a product from favorites"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                DELETE FROM favorites
                WHERE product_id = ? AND platform = ?
            """, (product_id, platform))

            conn.commit()
            conn.close()

            return True

        except Exception as e:
            self.logger.error("Failed to remove favorite", exception=str(e))
            return False

    async def get_favorites(self, platform: str = None) -> List[Dict]:
        """Get all favorites, optionally filtered by platform"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            if platform:
                cursor.execute(
                    "SELECT * FROM favorites WHERE platform = ? ORDER BY added_at DESC",
                    (platform,)
                )
            else:
                cursor.execute("SELECT * FROM favorites ORDER BY added_at DESC")

            rows = cursor.fetchall()
            conn.close()

            return [dict(row) for row in rows]

        except Exception as e:
            self.logger.error("Failed to get favorites", exception=str(e))
            return []

    async def check_favorites_availability(self) -> Dict:
        """
        Check if favorite products are still available

        Returns:
            Check results with availability status
        """
        self.logger.info("Checking favorites availability...")

        favorites = await self.get_favorites()
        results = {
            'total': len(favorites),
            'available': 0,
            'sold': 0,
            'unknown': 0,
            'details': []
        }

        for fav in favorites:
            try:
                status = await self._check_product_availability(fav)

                # Update database
                conn = sqlite3.connect(self.db_path)
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE favorites SET
                        is_available = ?,
                        is_sold = ?,
                        last_checked = ?
                    WHERE id = ?
                """, (
                    status.get('is_available', True),
                    status.get('is_sold', False),
                    datetime.now().isoformat(),
                    fav['id']
                ))
                conn.commit()
                conn.close()

                # Update results
                if status.get('is_sold'):
                    results['sold'] += 1
                    # Notify about sold items
                    await self._notify_sold(fav)
                elif status.get('is_available'):
                    results['available'] += 1
                else:
                    results['unknown'] += 1

                results['details'].append({
                    'product_id': fav['product_id'],
                    'platform': fav['platform'],
                    'status': status
                })

            except Exception as e:
                results['unknown'] += 1
                self.logger.error(f"Availability check failed for {fav['product_id']}", exception=str(e))

        self.logger.info(f"Availability check complete: {results['available']} available, {results['sold']} sold")

        return results

    async def _check_product_availability(self, product: Dict) -> Dict:
        """
        Check if a specific product is still available

        Args:
            product: Product data from favorites

        Returns:
            Availability status
        """
        platform = product.get('platform')
        url = product.get('url')
        language = product.get('language', 'en')

        # Get language code for sold keywords
        lang_code = language.split('-')[0] if language else 'en'
        sold_keywords = self.SOLD_KEYWORDS.get(lang_code, self.SOLD_KEYWORDS['en'])

        try:
            # Try to fetch product page
            scraping_manager = self.ceo.get_manager(self.ceo.ManagerType.SCRAPING) if hasattr(self.ceo, 'ManagerType') else None

            if scraping_manager and platform in scraping_manager.scrapers:
                scraper = scraping_manager.scrapers[platform]

                # Check if product page is accessible
                if hasattr(scraper, 'get_product_details'):
                    details = await scraper.get_product_details(url)

                    # Check for sold indicators in the page
                    if details:
                        title = details.get('title', '').lower()
                        status_text = details.get('status', '').lower()

                        for keyword in sold_keywords:
                            if keyword in title or keyword in status_text:
                                return {'is_available': False, 'is_sold': True}

                        return {'is_available': True, 'is_sold': False}

            # If we can't check, assume still available
            return {'is_available': True, 'is_sold': False, 'confidence': 0.5}

        except Exception as e:
            # If page returns 404, product is likely sold
            if '404' in str(e) or 'not found' in str(e).lower():
                return {'is_available': False, 'is_sold': True}

            return {'is_available': True, 'is_sold': False, 'error': str(e)}

    async def _notify_sold(self, product: Dict):
        """Notify when a favorite product is sold"""
        message = (
            f"📦 *Ürün Satıldı!*\n\n"
            f"Platform: {product.get('platform')}\n"
            f"Başlık: {product.get('title', 'Unknown')[:50]}\n"
            f"Fiyat: {product.get('price')} {product.get('currency')}"
        )

        await self.ceo.send_telegram_notification(message, priority='normal')

    # ==================== CLEANUP ====================

    async def cleanup_non_favorites(self, days_old: int = 7) -> Dict:
        """
        Clean up products not in favorites that are older than specified days

        Args:
            days_old: Number of days before cleanup

        Returns:
            Cleanup results
        """
        self.logger.info(f"Starting cleanup of non-favorites older than {days_old} days")

        cutoff_date = datetime.now() - timedelta(days=days_old)

        try:
            # Get main products database
            products_db = Path(__file__).parent.parent.parent / 'storage' / 'products.db'

            if not products_db.exists():
                return {'success': False, 'error': 'Products database not found'}

            conn = sqlite3.connect(products_db)
            cursor = conn.cursor()

            # Get favorite product IDs
            fav_conn = sqlite3.connect(self.db_path)
            fav_cursor = fav_conn.cursor()
            fav_cursor.execute("SELECT product_id, platform FROM favorites")
            favorites = set((row[0], row[1]) for row in fav_cursor.fetchall())
            fav_conn.close()

            # Count products to delete
            cursor.execute("""
                SELECT COUNT(*) FROM products
                WHERE created_at < ?
            """, (cutoff_date.isoformat(),))
            total_old = cursor.fetchone()[0]

            # Delete non-favorites
            cursor.execute("""
                DELETE FROM products
                WHERE created_at < ?
                AND (id, platform) NOT IN (SELECT product_id, platform FROM (
                    SELECT ? as product_id, ? as platform
                ))
            """, (cutoff_date.isoformat(),))

            deleted_count = cursor.rowcount

            # Vacuum to free space
            cursor.execute("VACUUM")

            conn.commit()
            conn.close()

            # Log cleanup
            self._log_cleanup(deleted_count)

            self.logger.info(f"Cleanup complete: {deleted_count} products removed")

            return {
                'success': True,
                'products_removed': deleted_count,
                'cutoff_date': cutoff_date.isoformat()
            }

        except Exception as e:
            self.logger.error("Cleanup failed", exception=str(e))
            return {'success': False, 'error': str(e)}

    def _log_cleanup(self, products_removed: int):
        """Log cleanup operation"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO cleanup_log (products_removed)
                VALUES (?)
            """, (products_removed,))

            conn.commit()
            conn.close()
        except:
            pass

    # ==================== SALES ====================

    async def record_sale(self, sale_data: Dict) -> bool:
        """
        Record a sale

        Args:
            sale_data: Sale information

        Returns:
            Success status
        """
        try:
            # Calculate net profit
            sale_price = sale_data.get('sale_price', 0)
            original_price = sale_data.get('original_price', 0)
            shipping = sale_data.get('shipping_cost', 0)
            platform_fee = sale_data.get('platform_fee', 0)
            net_profit = sale_price - original_price - shipping - platform_fee

            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO sales
                (product_id, platform, buyer_id, sale_price, original_price,
                 shipping_cost, platform_fee, net_profit, currency, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                sale_data.get('product_id'),
                sale_data.get('platform'),
                sale_data.get('buyer_id'),
                sale_price,
                original_price,
                shipping,
                platform_fee,
                net_profit,
                sale_data.get('currency'),
                sale_data.get('notes')
            ))

            conn.commit()
            conn.close()

            # Update stats
            self.stats['products_sold'] += 1
            self.stats['revenue_total'] += sale_price

            # Update CEO metrics
            self.ceo.metrics.products_sold += 1

            self.logger.info(f"Sale recorded: {sale_price} {sale_data.get('currency')}")

            return True

        except Exception as e:
            self.logger.error("Failed to record sale", exception=str(e))
            return False

    async def get_sales_report(self, period: str = 'daily') -> Dict:
        """
        Generate sales report

        Args:
            period: 'daily', 'weekly', 'monthly'

        Returns:
            Sales report
        """
        if period == 'daily':
            start_date = datetime.now() - timedelta(days=1)
        elif period == 'weekly':
            start_date = datetime.now() - timedelta(weeks=1)
        else:  # monthly
            start_date = datetime.now() - timedelta(days=30)

        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    COUNT(*) as total_sales,
                    SUM(sale_price) as total_revenue,
                    SUM(net_profit) as total_profit,
                    AVG(sale_price) as avg_price,
                    platform
                FROM sales
                WHERE sale_date >= ?
                GROUP BY platform
            """, (start_date.isoformat(),))

            by_platform = [dict(row) for row in cursor.fetchall()]

            cursor.execute("""
                SELECT
                    COUNT(*) as total_sales,
                    SUM(sale_price) as total_revenue,
                    SUM(net_profit) as total_profit
                FROM sales
                WHERE sale_date >= ?
            """, (start_date.isoformat(),))

            totals = dict(cursor.fetchone())
            conn.close()

            return {
                'period': period,
                'start_date': start_date.isoformat(),
                'totals': totals,
                'by_platform': by_platform
            }

        except Exception as e:
            self.logger.error("Failed to generate sales report", exception=str(e))
            return {'error': str(e)}

    # ==================== STATUS ====================

    def get_status(self) -> Dict:
        """Get manager status"""
        return {
            'status': 'healthy',
            'stats': self.stats,
            'upload_queue_size': len(self.upload_queue)
        }


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("SALES MANAGER TEST")
    print("=" * 60)

    class MockCEO:
        class ManagerType:
            SCRAPING = 'scraping'

        def get_manager(self, t):
            return None

        async def send_telegram_notification(self, msg, priority):
            print(f"[TELEGRAM] {msg}")

        class metrics:
            products_sold = 0

    async def test():
        ceo = MockCEO()
        manager = SalesManager(ceo)

        # Test add favorite
        await manager.add_to_favorites({
            'id': 'test123',
            'platform': 'vinted_de',
            'url': 'https://example.com/test',
            'title': 'Test Product',
            'price': 25.99,
            'currency': 'EUR',
            'condition': 'good',
            'language': 'de-DE'
        })

        # Get favorites
        favorites = await manager.get_favorites()
        print(f"\nFavorites: {len(favorites)}")

        print(f"\nStatus: {manager.get_status()}")
        print("\n✅ Sales Manager test complete!")

    asyncio.run(test())
    print("=" * 60)
