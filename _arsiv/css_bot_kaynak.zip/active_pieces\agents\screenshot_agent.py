#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SCREENSHOT AGENT - AI-Powered Visual Scraping
URL'ye git, screenshot al, AI ile oku, veri çıkar

Features:
- URL'den screenshot alma (mobile/desktop)
- AI ile görüntü analizi (Groq Vision, Claude, GPT-4V)
- Ürün durumu kontrolü (satıldı mı, stokta mı)
- Fiyat değişimi tespiti
- Ölü link kontrolü
- Sayfa içeriği çıkarma
- Cross-platform çalışma (Windows/Linux/Android)
- Self-learning: Hata durumlarından öğrenme

Author: TATANGA Team
Version: 1.0
"""

import sys
import os
import json
import base64
import sqlite3
import asyncio
import hashlib
import tempfile
import time
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
import threading
import re

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.logger import ModuleLogger
from agents.base_agent import BaseAgent, AgentConfig, AgentStatus


# ============================================================================
# ENUMS & DATA MODELS
# ============================================================================

class PageStatus(Enum):
    """Page status after screenshot analysis"""
    ACTIVE = "active"  # Ürün aktif
    SOLD = "sold"  # Satıldı
    UNAVAILABLE = "unavailable"  # Mevcut değil
    PRICE_CHANGED = "price_changed"  # Fiyat değişti
    DEAD_LINK = "dead_link"  # Ölü link (404)
    ERROR = "error"  # Hata
    UNKNOWN = "unknown"  # Bilinmiyor


class AnalysisType(Enum):
    """Types of screenshot analysis"""
    PRODUCT_STATUS = "product_status"  # Ürün durumu
    PRICE_CHECK = "price_check"  # Fiyat kontrolü
    CONTENT_EXTRACT = "content_extract"  # İçerik çıkarma
    LOGIN_CHECK = "login_check"  # Login durumu
    CAPTCHA_CHECK = "captcha_check"  # Captcha kontrolü
    GENERAL = "general"  # Genel analiz


@dataclass
class ScreenshotResult:
    """Result of screenshot capture"""
    success: bool
    url: str
    screenshot_path: str = ""
    screenshot_base64: str = ""
    page_title: str = ""
    final_url: str = ""
    status_code: int = 0
    error: str = ""
    captured_at: datetime = None
    device_type: str = "desktop"


@dataclass
class AnalysisResult:
    """Result of AI analysis"""
    success: bool
    page_status: PageStatus = PageStatus.UNKNOWN
    confidence: float = 0.0
    extracted_data: Dict = field(default_factory=dict)
    raw_response: str = ""
    analysis_type: AnalysisType = AnalysisType.GENERAL
    error: str = ""
    analyzed_at: datetime = None


@dataclass
class ScreenshotTask:
    """Task for screenshot queue"""
    id: int = None
    url: str = ""
    task_type: AnalysisType = AnalysisType.PRODUCT_STATUS
    priority: int = 5  # 1-10, 10 en yüksek
    expected_data: Dict = field(default_factory=dict)  # Beklenen değerler (fiyat vs)
    callback_data: Dict = field(default_factory=dict)  # Callback bilgileri
    status: str = "pending"
    retry_count: int = 0
    max_retries: int = 3
    created_at: datetime = None
    completed_at: datetime = None
    result: AnalysisResult = None


# ============================================================================
# SCREENSHOT AGENT
# ============================================================================

class ScreenshotAgent(BaseAgent):
    """
    Screenshot-based AI Scraping Agent

    Workflow:
    1. URL kuyruğundan görev al
    2. Playwright ile sayfaya git
    3. Screenshot al
    4. AI'a gönder, analiz et
    5. Sonucu kaydet/bildir
    6. Hata varsa öğren ve tekrar dene

    Self-Learning:
    - Başarısız analizleri logla
    - Prompt'ları optimize et
    - Platform-specific pattern'lar öğren
    """

    # AI Prompts for different analysis types
    ANALYSIS_PROMPTS = {
        AnalysisType.PRODUCT_STATUS: """
Analyze this screenshot of a product page and determine its status.

Return a JSON object with:
{
    "status": "active" | "sold" | "unavailable" | "error",
    "confidence": 0.0-1.0,
    "indicators": ["list of visual indicators you found"],
    "price": "extracted price or null",
    "currency": "EUR/USD/GBP/etc or null",
    "title": "product title or null"
}

Look for:
- "Sold", "Verkauft", "Vendu", "Satıldı" text
- Grayed out or crossed prices
- "Out of stock", "Nicht verfügbar" messages
- "Buy" or "Add to cart" buttons (indicates active)
- Error pages (404, not found)

Only return the JSON, no other text.
""",
        AnalysisType.PRICE_CHECK: """
Extract the price from this product page screenshot.

Return a JSON object with:
{
    "price": numeric value or null,
    "currency": "EUR/USD/GBP/etc",
    "original_price": numeric value if discounted or null,
    "discount_percent": percentage if discounted or null,
    "shipping_cost": numeric value or null,
    "total_cost": numeric value or null
}

Only return the JSON, no other text.
""",
        AnalysisType.CONTENT_EXTRACT: """
Extract all product information from this screenshot.

Return a JSON object with:
{
    "title": "product title",
    "description": "product description",
    "price": numeric value,
    "currency": "EUR/USD/GBP/etc",
    "condition": "new/used/like new/etc",
    "brand": "brand name or null",
    "category": "category or null",
    "seller_name": "seller name or null",
    "location": "location or null",
    "images_count": number of visible images
}

Only return the JSON, no other text.
""",
        AnalysisType.LOGIN_CHECK: """
Check if this page requires login or shows a login prompt.

Return a JSON object with:
{
    "requires_login": true/false,
    "login_type": "form" | "oauth" | "captcha" | "none",
    "page_type": "login_page" | "blocked" | "content_visible",
    "indicators": ["list of indicators found"]
}

Only return the JSON, no other text.
""",
        AnalysisType.CAPTCHA_CHECK: """
Check if this page shows a CAPTCHA or bot detection.

Return a JSON object with:
{
    "has_captcha": true/false,
    "captcha_type": "recaptcha" | "hcaptcha" | "image" | "text" | "none",
    "blocked": true/false,
    "indicators": ["list of indicators found"]
}

Only return the JSON, no other text.
"""
    }

    def __init__(self, interval_seconds: int = 30):
        """
        Initialize Screenshot Agent

        Args:
            interval_seconds: Check interval for queue processing
        """
        config = AgentConfig(
            name="screenshot",
            interval_seconds=interval_seconds,
            max_retries=3
        )
        super().__init__(config)

        self.logger = ModuleLogger('screenshot_agent')

        # Database path
        self.db_path = Path(__file__).parent.parent / 'storage' / 'screenshot_agent.db'
        self._init_db()

        # Screenshot storage
        self.screenshot_dir = Path(__file__).parent.parent / 'storage' / 'screenshots'
        self.screenshot_dir.mkdir(parents=True, exist_ok=True)

        # Playwright browser (lazy loaded)
        self._browser = None
        self._playwright = None

        # AI client settings
        self.ai_provider = "groq"  # groq, openai, anthropic
        self.groq_api_key = os.environ.get('GROQ_API_KEY', '')

        # Learning data
        self.learned_patterns: Dict[str, List[str]] = {}

        self.logger.info("Screenshot Agent initialized")

    def _init_db(self):
        """Initialize database"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Screenshot tasks queue
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS screenshot_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL,
                task_type TEXT NOT NULL,
                priority INTEGER DEFAULT 5,
                expected_data TEXT,
                callback_data TEXT,
                status TEXT DEFAULT 'pending',
                retry_count INTEGER DEFAULT 0,
                max_retries INTEGER DEFAULT 3,
                result_json TEXT,
                error_message TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                started_at DATETIME,
                completed_at DATETIME
            )
        """)

        # Screenshot history
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS screenshot_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER,
                url TEXT NOT NULL,
                screenshot_path TEXT,
                page_status TEXT,
                analysis_result TEXT,
                device_type TEXT,
                captured_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES screenshot_tasks(id)
            )
        """)

        # Learned patterns (self-learning)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS learned_patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                pattern_type TEXT NOT NULL,
                pattern_data TEXT NOT NULL,
                success_count INTEGER DEFAULT 0,
                failure_count INTEGER DEFAULT 0,
                last_used DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Agent activity log
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT NOT NULL,
                details TEXT,
                success INTEGER DEFAULT 1,
                error_message TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        conn.commit()
        conn.close()

    # ========================================================================
    # AGENT METHODS
    # ========================================================================

    async def process(self):
        """Main agent processing loop"""
        try:
            # Get pending tasks from queue
            tasks = self._get_pending_tasks(limit=5)

            if not tasks:
                self.logger.debug("No pending screenshot tasks")
                return

            self.logger.info(f"Processing {len(tasks)} screenshot tasks")

            for task in tasks:
                await self._process_task(task)

        except Exception as e:
            self.logger.error(f"Screenshot agent error: {e}")
            raise

    async def _process_task(self, task: ScreenshotTask):
        """Process a single screenshot task"""
        self._update_task_status(task.id, 'processing')
        self._log_action('task_started', {'task_id': task.id, 'url': task.url})

        try:
            # Take screenshot
            screenshot = await self.capture_screenshot(
                task.url,
                device_type='mobile' if 'mobile' in task.callback_data.get('device', '') else 'desktop'
            )

            if not screenshot.success:
                raise Exception(f"Screenshot failed: {screenshot.error}")

            # Analyze with AI
            analysis = await self.analyze_screenshot(
                screenshot,
                task.task_type,
                task.expected_data
            )

            # Save result
            task.result = analysis
            self._save_task_result(task.id, analysis)
            self._save_screenshot_history(task.id, screenshot, analysis)

            # Trigger callback if needed
            await self._trigger_callback(task, analysis)

            # Learn from result
            self._learn_from_result(task.url, analysis)

            self._log_action('task_completed', {
                'task_id': task.id,
                'status': analysis.page_status.value,
                'confidence': analysis.confidence
            })

        except Exception as e:
            self.logger.error(f"Task {task.id} failed: {e}")

            # Retry logic
            if task.retry_count < task.max_retries:
                self._update_task_retry(task.id)
                self._log_action('task_retry', {'task_id': task.id, 'error': str(e)})
            else:
                self._update_task_status(task.id, 'failed', str(e))
                self._log_action('task_failed', {'task_id': task.id, 'error': str(e)})

    # ========================================================================
    # SCREENSHOT CAPTURE
    # ========================================================================

    async def capture_screenshot(
        self,
        url: str,
        device_type: str = 'desktop',
        wait_for: str = None,
        timeout: int = 30000
    ) -> ScreenshotResult:
        """
        Capture screenshot of URL

        Args:
            url: URL to capture
            device_type: 'desktop' or 'mobile'
            wait_for: CSS selector to wait for
            timeout: Timeout in milliseconds

        Returns:
            ScreenshotResult
        """
        try:
            from playwright.async_api import async_playwright

            async with async_playwright() as p:
                # Launch browser
                browser = await p.chromium.launch(
                    headless=True,
                    args=['--disable-blink-features=AutomationControlled']
                )

                # Create context with device emulation
                if device_type == 'mobile':
                    context = await browser.new_context(
                        viewport={'width': 390, 'height': 844},
                        device_scale_factor=3,
                        is_mobile=True,
                        has_touch=True,
                        user_agent='Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
                    )
                else:
                    context = await browser.new_context(
                        viewport={'width': 1920, 'height': 1080},
                        user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    )

                page = await context.new_page()

                try:
                    # Navigate
                    response = await page.goto(url, timeout=timeout, wait_until='domcontentloaded')

                    # Wait for specific element if requested
                    if wait_for:
                        await page.wait_for_selector(wait_for, timeout=timeout)

                    # Wait a bit for dynamic content
                    await asyncio.sleep(2)

                    # Scroll to load lazy content
                    await page.evaluate('window.scrollTo(0, document.body.scrollHeight / 2)')
                    await asyncio.sleep(1)
                    await page.evaluate('window.scrollTo(0, 0)')

                    # Take screenshot
                    screenshot_bytes = await page.screenshot(full_page=True)

                    # Save to file
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
                    filename = f"ss_{timestamp}_{url_hash}.png"
                    filepath = self.screenshot_dir / filename

                    with open(filepath, 'wb') as f:
                        f.write(screenshot_bytes)

                    # Encode to base64
                    screenshot_base64 = base64.b64encode(screenshot_bytes).decode('utf-8')

                    return ScreenshotResult(
                        success=True,
                        url=url,
                        screenshot_path=str(filepath),
                        screenshot_base64=screenshot_base64,
                        page_title=await page.title(),
                        final_url=page.url,
                        status_code=response.status if response else 0,
                        captured_at=datetime.now(),
                        device_type=device_type
                    )

                finally:
                    await page.close()
                    await context.close()
                    await browser.close()

        except Exception as e:
            self.logger.error(f"Screenshot capture failed: {e}")
            return ScreenshotResult(
                success=False,
                url=url,
                error=str(e),
                captured_at=datetime.now(),
                device_type=device_type
            )

    # ========================================================================
    # AI ANALYSIS
    # ========================================================================

    async def analyze_screenshot(
        self,
        screenshot: ScreenshotResult,
        analysis_type: AnalysisType,
        expected_data: Dict = None
    ) -> AnalysisResult:
        """
        Analyze screenshot using AI

        Args:
            screenshot: Screenshot result
            analysis_type: Type of analysis to perform
            expected_data: Expected values for comparison

        Returns:
            AnalysisResult
        """
        if not screenshot.success or not screenshot.screenshot_base64:
            return AnalysisResult(
                success=False,
                error="No screenshot to analyze"
            )

        try:
            # Get appropriate prompt
            prompt = self.ANALYSIS_PROMPTS.get(
                analysis_type,
                self.ANALYSIS_PROMPTS[AnalysisType.PRODUCT_STATUS]
            )

            # Add context if expected data provided
            if expected_data:
                prompt += f"\n\nExpected data for comparison:\n{json.dumps(expected_data, indent=2)}"

            # Call AI API
            response = await self._call_ai_vision(
                screenshot.screenshot_base64,
                prompt
            )

            # Parse response
            try:
                result_data = json.loads(response)
            except json.JSONDecodeError:
                # Try to extract JSON from response
                json_match = re.search(r'\{.*\}', response, re.DOTALL)
                if json_match:
                    result_data = json.loads(json_match.group())
                else:
                    result_data = {'raw': response}

            # Determine page status
            status = PageStatus.UNKNOWN
            confidence = result_data.get('confidence', 0.5)

            if analysis_type == AnalysisType.PRODUCT_STATUS:
                status_str = result_data.get('status', '').lower()
                status_map = {
                    'active': PageStatus.ACTIVE,
                    'sold': PageStatus.SOLD,
                    'unavailable': PageStatus.UNAVAILABLE,
                    'error': PageStatus.ERROR
                }
                status = status_map.get(status_str, PageStatus.UNKNOWN)

            # Check for price change if expected price provided
            if expected_data and 'price' in expected_data and 'price' in result_data:
                expected_price = float(expected_data['price'])
                actual_price = float(result_data['price']) if result_data['price'] else 0
                if actual_price > 0 and abs(actual_price - expected_price) > 0.01:
                    status = PageStatus.PRICE_CHANGED
                    result_data['price_change'] = actual_price - expected_price

            return AnalysisResult(
                success=True,
                page_status=status,
                confidence=confidence,
                extracted_data=result_data,
                raw_response=response,
                analysis_type=analysis_type,
                analyzed_at=datetime.now()
            )

        except Exception as e:
            self.logger.error(f"AI analysis failed: {e}")
            return AnalysisResult(
                success=False,
                error=str(e),
                analysis_type=analysis_type
            )

    async def _call_ai_vision(self, image_base64: str, prompt: str) -> str:
        """
        Call AI Vision API

        Args:
            image_base64: Base64 encoded image
            prompt: Analysis prompt

        Returns:
            AI response text
        """
        try:
            import httpx

            if self.ai_provider == "groq":
                # Groq API (uses llama-3.2-vision or similar)
                async with httpx.AsyncClient() as client:
                    response = await client.post(
                        "https://api.groq.com/openai/v1/chat/completions",
                        headers={
                            "Authorization": f"Bearer {self.groq_api_key}",
                            "Content-Type": "application/json"
                        },
                        json={
                            "model": "llama-3.2-90b-vision-preview",
                            "messages": [
                                {
                                    "role": "user",
                                    "content": [
                                        {
                                            "type": "text",
                                            "text": prompt
                                        },
                                        {
                                            "type": "image_url",
                                            "image_url": {
                                                "url": f"data:image/png;base64,{image_base64}"
                                            }
                                        }
                                    ]
                                }
                            ],
                            "max_tokens": 1000,
                            "temperature": 0.1
                        },
                        timeout=60.0
                    )

                    result = response.json()
                    return result['choices'][0]['message']['content']

            # Fallback: Return placeholder for other providers
            return json.dumps({
                "status": "unknown",
                "confidence": 0.5,
                "message": "AI provider not configured"
            })

        except Exception as e:
            self.logger.error(f"AI API call failed: {e}")
            raise

    # ========================================================================
    # TASK QUEUE MANAGEMENT
    # ========================================================================

    def queue_screenshot(
        self,
        url: str,
        task_type: AnalysisType = AnalysisType.PRODUCT_STATUS,
        priority: int = 5,
        expected_data: Dict = None,
        callback_data: Dict = None
    ) -> int:
        """
        Add URL to screenshot queue

        Args:
            url: URL to screenshot
            task_type: Type of analysis
            priority: Priority (1-10)
            expected_data: Expected values for comparison
            callback_data: Callback information

        Returns:
            Task ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO screenshot_tasks (
                url, task_type, priority, expected_data, callback_data
            ) VALUES (?, ?, ?, ?, ?)
        """, (
            url,
            task_type.value,
            priority,
            json.dumps(expected_data or {}),
            json.dumps(callback_data or {})
        ))

        task_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Queued screenshot task {task_id}: {url}")
        return task_id

    def queue_bulk(self, urls: List[str], task_type: AnalysisType = AnalysisType.PRODUCT_STATUS) -> List[int]:
        """Queue multiple URLs"""
        return [self.queue_screenshot(url, task_type) for url in urls]

    def _get_pending_tasks(self, limit: int = 10) -> List[ScreenshotTask]:
        """Get pending tasks from queue"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, url, task_type, priority, expected_data, callback_data,
                   status, retry_count, max_retries, created_at
            FROM screenshot_tasks
            WHERE status IN ('pending', 'retry')
            ORDER BY priority DESC, created_at ASC
            LIMIT ?
        """, (limit,))

        tasks = []
        for row in cursor.fetchall():
            tasks.append(ScreenshotTask(
                id=row[0],
                url=row[1],
                task_type=AnalysisType(row[2]),
                priority=row[3],
                expected_data=json.loads(row[4]) if row[4] else {},
                callback_data=json.loads(row[5]) if row[5] else {},
                status=row[6],
                retry_count=row[7],
                max_retries=row[8],
                created_at=datetime.fromisoformat(row[9]) if row[9] else None
            ))

        conn.close()
        return tasks

    def _update_task_status(self, task_id: int, status: str, error: str = None):
        """Update task status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        if status == 'completed':
            cursor.execute("""
                UPDATE screenshot_tasks
                SET status = ?, completed_at = datetime('now')
                WHERE id = ?
            """, (status, task_id))
        elif status == 'processing':
            cursor.execute("""
                UPDATE screenshot_tasks
                SET status = ?, started_at = datetime('now')
                WHERE id = ?
            """, (status, task_id))
        else:
            cursor.execute("""
                UPDATE screenshot_tasks
                SET status = ?, error_message = ?
                WHERE id = ?
            """, (status, error, task_id))

        conn.commit()
        conn.close()

    def _update_task_retry(self, task_id: int):
        """Update task for retry"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE screenshot_tasks
            SET status = 'retry', retry_count = retry_count + 1
            WHERE id = ?
        """, (task_id,))

        conn.commit()
        conn.close()

    def _save_task_result(self, task_id: int, result: AnalysisResult):
        """Save task result"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE screenshot_tasks
            SET status = 'completed', result_json = ?, completed_at = datetime('now')
            WHERE id = ?
        """, (json.dumps({
            'page_status': result.page_status.value,
            'confidence': result.confidence,
            'extracted_data': result.extracted_data,
            'analysis_type': result.analysis_type.value
        }), task_id))

        conn.commit()
        conn.close()

    def _save_screenshot_history(
        self,
        task_id: int,
        screenshot: ScreenshotResult,
        analysis: AnalysisResult
    ):
        """Save screenshot to history"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO screenshot_history (
                task_id, url, screenshot_path, page_status, analysis_result, device_type
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, (
            task_id,
            screenshot.url,
            screenshot.screenshot_path,
            analysis.page_status.value,
            json.dumps(analysis.extracted_data),
            screenshot.device_type
        ))

        conn.commit()
        conn.close()

    # ========================================================================
    # CALLBACKS & NOTIFICATIONS
    # ========================================================================

    async def _trigger_callback(self, task: ScreenshotTask, analysis: AnalysisResult):
        """Trigger callback after analysis"""
        callback_data = task.callback_data

        if not callback_data:
            return

        callback_type = callback_data.get('type', '')

        if callback_type == 'telegram':
            await self._send_telegram_notification(task, analysis)

        elif callback_type == 'webhook':
            await self._call_webhook(callback_data.get('url'), task, analysis)

        elif callback_type == 'agent':
            # Notify another agent
            agent_name = callback_data.get('agent_name')
            await self._notify_agent(agent_name, task, analysis)

    async def _send_telegram_notification(
        self,
        task: ScreenshotTask,
        analysis: AnalysisResult
    ):
        """Send Telegram notification"""
        try:
            # Build message
            status_emoji = {
                PageStatus.ACTIVE: "✅",
                PageStatus.SOLD: "❌",
                PageStatus.UNAVAILABLE: "⚠️",
                PageStatus.PRICE_CHANGED: "💰",
                PageStatus.DEAD_LINK: "🔗",
                PageStatus.ERROR: "❗",
                PageStatus.UNKNOWN: "❓"
            }

            emoji = status_emoji.get(analysis.page_status, "❓")
            status_text = analysis.page_status.value.upper()

            message = f"""
{emoji} **Screenshot Analysis**

**URL:** {task.url[:50]}...
**Status:** {status_text}
**Confidence:** {analysis.confidence:.0%}
"""

            if analysis.extracted_data.get('price'):
                message += f"\n**Price:** {analysis.extracted_data['price']} {analysis.extracted_data.get('currency', 'EUR')}"

            if analysis.page_status == PageStatus.PRICE_CHANGED:
                change = analysis.extracted_data.get('price_change', 0)
                message += f"\n**Price Change:** {'+' if change > 0 else ''}{change:.2f}"

            # Would send via Telegram bot
            self.logger.info(f"Telegram notification: {message[:100]}...")

        except Exception as e:
            self.logger.error(f"Telegram notification failed: {e}")

    async def _call_webhook(self, url: str, task: ScreenshotTask, analysis: AnalysisResult):
        """Call webhook URL"""
        try:
            import httpx

            async with httpx.AsyncClient() as client:
                await client.post(url, json={
                    'task_id': task.id,
                    'url': task.url,
                    'page_status': analysis.page_status.value,
                    'confidence': analysis.confidence,
                    'extracted_data': analysis.extracted_data,
                    'analyzed_at': analysis.analyzed_at.isoformat() if analysis.analyzed_at else None
                })

        except Exception as e:
            self.logger.error(f"Webhook call failed: {e}")

    async def _notify_agent(self, agent_name: str, task: ScreenshotTask, analysis: AnalysisResult):
        """Notify another agent"""
        # Would integrate with orchestrator to notify specific agent
        self.logger.info(f"Notifying agent {agent_name} about task {task.id}")

    # ========================================================================
    # SELF-LEARNING
    # ========================================================================

    def _learn_from_result(self, url: str, analysis: AnalysisResult):
        """Learn patterns from analysis result"""
        try:
            # Extract platform from URL
            platform = self._extract_platform(url)

            if not platform:
                return

            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            # Store successful patterns
            if analysis.success and analysis.confidence > 0.8:
                pattern_data = json.dumps({
                    'indicators': analysis.extracted_data.get('indicators', []),
                    'status': analysis.page_status.value
                })

                cursor.execute("""
                    INSERT INTO learned_patterns (platform, pattern_type, pattern_data, success_count)
                    VALUES (?, ?, ?, 1)
                    ON CONFLICT(platform, pattern_type, pattern_data) DO UPDATE SET
                        success_count = success_count + 1,
                        last_used = datetime('now')
                """, (platform, analysis.analysis_type.value, pattern_data))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.debug(f"Learning failed: {e}")

    def _extract_platform(self, url: str) -> Optional[str]:
        """Extract platform name from URL"""
        patterns = {
            'vinted': r'vinted\.\w+',
            'ebay': r'ebay\.\w+',
            'kleinanzeigen': r'kleinanzeigen',
            'leboncoin': r'leboncoin',
            'shpock': r'shpock',
            'willhaben': r'willhaben',
            'tradera': r'tradera'
        }

        for platform, pattern in patterns.items():
            if re.search(pattern, url):
                return platform

        return None

    def get_learned_patterns(self, platform: str) -> List[Dict]:
        """Get learned patterns for platform"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT pattern_type, pattern_data, success_count
            FROM learned_patterns
            WHERE platform = ?
            ORDER BY success_count DESC
        """, (platform,))

        patterns = [
            {
                'type': row[0],
                'data': json.loads(row[1]),
                'success_count': row[2]
            }
            for row in cursor.fetchall()
        ]

        conn.close()
        return patterns

    # ========================================================================
    # LOGGING
    # ========================================================================

    def _log_action(self, action: str, details: Dict = None, success: bool = True, error: str = None):
        """Log agent action"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO agent_log (action, details, success, error_message)
                VALUES (?, ?, ?, ?)
            """, (action, json.dumps(details) if details else None, 1 if success else 0, error))

            conn.commit()
            conn.close()
        except:
            pass

    # ========================================================================
    # CONVENIENCE METHODS
    # ========================================================================

    async def check_product_status(self, url: str, expected_price: float = None) -> AnalysisResult:
        """
        Quick check product status

        Args:
            url: Product URL
            expected_price: Expected price for comparison

        Returns:
            AnalysisResult
        """
        screenshot = await self.capture_screenshot(url, device_type='mobile')

        if not screenshot.success:
            return AnalysisResult(
                success=False,
                error=screenshot.error,
                page_status=PageStatus.ERROR
            )

        expected_data = {'price': expected_price} if expected_price else None

        return await self.analyze_screenshot(
            screenshot,
            AnalysisType.PRODUCT_STATUS,
            expected_data
        )

    async def check_dead_links(self, urls: List[str]) -> Dict[str, PageStatus]:
        """
        Check multiple URLs for dead links

        Args:
            urls: List of URLs

        Returns:
            Dict mapping URL to status
        """
        results = {}

        for url in urls:
            try:
                screenshot = await self.capture_screenshot(url)
                if screenshot.status_code == 404:
                    results[url] = PageStatus.DEAD_LINK
                elif screenshot.status_code >= 400:
                    results[url] = PageStatus.ERROR
                else:
                    results[url] = PageStatus.ACTIVE
            except:
                results[url] = PageStatus.ERROR

        return results

    def get_statistics(self) -> Dict:
        """Get agent statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Task stats
        cursor.execute("""
            SELECT status, COUNT(*) FROM screenshot_tasks GROUP BY status
        """)
        task_stats = dict(cursor.fetchall())

        # History stats
        cursor.execute("""
            SELECT page_status, COUNT(*) FROM screenshot_history GROUP BY page_status
        """)
        status_stats = dict(cursor.fetchall())

        # Recent activity
        cursor.execute("""
            SELECT COUNT(*) FROM screenshot_tasks
            WHERE created_at > datetime('now', '-24 hours')
        """)
        last_24h = cursor.fetchone()[0]

        conn.close()

        return {
            'task_stats': task_stats,
            'status_stats': status_stats,
            'last_24h_tasks': last_24h,
            'learned_platforms': len(self.get_learned_patterns(''))
        }


# ============================================================================
# CLI TEST
# ============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("SCREENSHOT AGENT - Test")
    print("=" * 60)

    agent = ScreenshotAgent()

    # Queue test URLs
    test_urls = [
        "https://www.vinted.de/items/123456",
        "https://www.ebay.de/itm/789012"
    ]

    print("\nQueuing test tasks...")
    for url in test_urls:
        task_id = agent.queue_screenshot(
            url,
            AnalysisType.PRODUCT_STATUS,
            callback_data={'type': 'telegram'}
        )
        print(f"  Task {task_id}: {url}")

    print("\nStatistics:")
    stats = agent.get_statistics()
    print(f"  Tasks: {stats['task_stats']}")
    print(f"  Last 24h: {stats['last_24h_tasks']}")

    print("\n" + "=" * 60)
    print("Usage:")
    print("  # Queue URL for screenshot analysis")
    print("  agent.queue_screenshot('https://vinted.de/items/123')")
    print()
    print("  # Quick check product status")
    print("  result = await agent.check_product_status('https://...')")
    print()
    print("  # Check dead links")
    print("  results = await agent.check_dead_links(['url1', 'url2'])")
    print("=" * 60)