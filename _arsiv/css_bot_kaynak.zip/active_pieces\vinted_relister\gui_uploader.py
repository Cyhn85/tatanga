# Vinted GUI Uploader - Uses pyautogui to control existing browser
# No CDP required - works with any open Chrome window

import os
import sys
import time
import random
import pyautogui
import pyperclip

sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.database import db
from config import STATUS_VALIDATED, STATUS_UPLOADED

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')

# PyAutoGUI settings
pyautogui.PAUSE = 0.3  # Pause between actions
pyautogui.FAILSAFE = True  # Move mouse to corner to abort


def human_type(text):
    """Type text character by character with human-like delays"""
    for char in text:
        pyautogui.write(char, interval=random.uniform(0.05, 0.15))
        if random.random() < 0.05:
            time.sleep(random.uniform(0.2, 0.5))


def paste_text(text):
    """Paste text using clipboard (faster for long text)"""
    pyperclip.copy(text)
    time.sleep(0.2)
    pyautogui.hotkey('ctrl', 'v')
    time.sleep(0.3)


def random_delay(min_s=0.5, max_s=1.5):
    """Random delay between actions"""
    time.sleep(random.uniform(min_s, max_s))


def click_and_wait(x=None, y=None, wait=1):
    """Click and wait"""
    if x and y:
        pyautogui.click(x, y)
    else:
        pyautogui.click()
    time.sleep(wait)


def find_vinted_window():
    """Try to find and activate Vinted browser window"""
    import subprocess
    # Use PowerShell to find and activate Chrome with Vinted
    ps_script = '''
    Add-Type @"
    using System;
    using System.Runtime.InteropServices;
    public class Win32 {
        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);
    }
"@
    $chrome = Get-Process chrome -ErrorAction SilentlyContinue | Where-Object {$_.MainWindowTitle -like "*Vinted*"}
    if ($chrome) {
        [Win32]::SetForegroundWindow($chrome.MainWindowHandle)
        Write-Output "OK"
    } else {
        Write-Output "NOT_FOUND"
    }
    '''
    try:
        result = subprocess.run(['powershell', '-Command', ps_script],
                              capture_output=True, text=True, timeout=5)
        return 'OK' in result.stdout
    except:
        return False


def upload_product(product):
    """Upload a single product using GUI automation"""
    title = product.get('processed_title', product.get('raw_title', ''))
    desc = product.get('processed_description', product.get('raw_description', ''))
    price = product.get('price', 0)
    images_path = product.get('processed_images_path', product.get('raw_images_path', ''))

    print(f"\n{'='*50}")
    print(f"  URUN: {title[:45]}...")
    print(f"  FIYAT: {price} EUR")
    print(f"{'='*50}")

    # 1. Focus Vinted window
    print("\n[1] Vinted penceresi aktif ediliyor...")
    if not find_vinted_window():
        print("    [WARN] Vinted penceresi bulunamadi. Manuel olarak Vinted'e tiklayin.")
        input("    Vinted acikken ENTER'a basin...")

    random_delay(0.5, 1)

    # 2. Go to upload page (Ctrl+L, type URL, Enter)
    print("\n[2] Upload sayfasina gidiliyor...")
    pyautogui.hotkey('ctrl', 'l')  # Focus address bar
    time.sleep(0.3)
    pyautogui.write('https://www.vinted.de/items/new', interval=0.02)
    pyautogui.press('enter')
    print("    Sayfa yukleniyor...")
    time.sleep(4)  # Wait for page load

    # 3. Upload images
    print("\n[3] Resimler icin dosya secici aciliyor...")
    if images_path and os.path.exists(images_path):
        images = [os.path.join(images_path, f) for f in os.listdir(images_path)
                  if f.lower().endswith(('.jpg', '.jpeg', '.png'))][:10]

        if images:
            # Click on image upload area (usually top of form)
            # Press Tab a few times to reach file input, or click coordinates
            pyautogui.press('tab')
            time.sleep(0.3)
            pyautogui.press('enter')  # Open file dialog
            time.sleep(1.5)

            # Type file path in dialog
            files_str = ' '.join(f'"{img}"' for img in images)
            paste_text(images[0])  # First image
            pyautogui.press('enter')
            print(f"    Ilk resim secildi")
            time.sleep(3)

    random_delay(1, 2)

    # 4. Fill title (Tab to title field)
    print("\n[4] Baslik yaziliyor...")
    pyautogui.press('tab')
    time.sleep(0.3)
    paste_text(title)
    print(f"    Baslik: {title[:40]}...")
    random_delay(1, 2)

    # Wait for category suggestion
    time.sleep(2)

    # 5. Fill description (Tab to description field)
    print("\n[5] Aciklama yaziliyor...")
    pyautogui.press('tab')
    time.sleep(0.3)
    paste_text(desc)
    print(f"    Aciklama girildi ({len(desc)} karakter)")
    random_delay(1, 2)

    # 6. Fill price
    print("\n[6] Fiyat giriliyor...")
    # Tab through fields to reach price
    for _ in range(5):
        pyautogui.press('tab')
        time.sleep(0.2)
    paste_text(str(int(price)))
    print(f"    Fiyat: {price} EUR")

    # Take screenshot
    ss_path = os.path.join(DATA_DIR, f'gui_upload_{product.get("id", "unknown")}.png')
    screenshot = pyautogui.screenshot()
    screenshot.save(ss_path)
    print(f"\n    Screenshot: {ss_path}")

    # 7. User confirmation
    print("\n" + "="*50)
    print("  FORMU KONTROL EDIN!")
    print("  Tarayicida formu inceleyin.")
    print("="*50)

    confirm = input("\nYayinlamak icin 'y', atlamak icin 'n': ").strip().lower()

    if confirm != 'y':
        print("[SKIP] Urun atlandı.")
        return False

    # 8. Click publish (scroll down and click button)
    print("\n[7] Yayinlaniyor...")
    pyautogui.scroll(-5)  # Scroll down
    time.sleep(0.5)

    # Try to find and click "Hochladen" button
    # Using keyboard: Tab to button and Enter
    for _ in range(3):
        pyautogui.press('tab')
        time.sleep(0.2)
    pyautogui.press('enter')

    time.sleep(5)
    print("[OK] Yayinla komutu gonderildi!")
    return True


def main():
    print("=" * 60)
    print("  VINTED GUI UPLOADER")
    print("  PyAutoGUI ile mevcut tarayiciyi kontrol eder")
    print("=" * 60)

    print("\n[ONEMLI] Baslamadan once:")
    print("  1. Chrome'da Vinted.de acik olmali")
    print("  2. cssberlin hesabina giris yapmis olmali")
    print("  3. Bu pencereyi yan tarafa koy, Vinted gorunsun")

    input("\nHazir oldugunuzda ENTER'a basin...")

    # Get products
    products = db.get_products_by_status(STATUS_VALIDATED)
    print(f"\n[INFO] {len(products)} urun yuklemeye hazir")

    if not products:
        print("[INFO] Yuklenecek urun yok!")
        return

    # Upload products
    uploaded = 0
    for i, product in enumerate(products):
        print(f"\n{'#'*60}")
        print(f"  URUN {i+1}/{len(products)}")
        print(f"{'#'*60}")

        try:
            if upload_product(product):
                db.update_product(product['id'], {
                    'status': STATUS_UPLOADED,
                    'target_store': 'cssberlin'
                })
                db.add_log(product['id'], 'upload', 'success', 'GUI upload')
                uploaded += 1

            # Delay between products
            if i < len(products) - 1:
                delay = random.randint(10, 20)
                print(f"\n[WAIT] {delay}s bekleniyor...")
                time.sleep(delay)

        except Exception as e:
            print(f"\n[ERROR] {e}")
            cont = input("Devam? (y/n): ").strip().lower()
            if cont != 'y':
                break

    print(f"\n{'='*60}")
    print(f"  TAMAMLANDI: {uploaded}/{len(products)} urun")
    print(f"{'='*60}")


if __name__ == '__main__':
    main()
