#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Product Metadata Extractor
Extracts size, brand, color from product titles and descriptions
"""

import re
from typing import Dict, Optional


def extract_metadata(title: str, description: str = "") -> Dict[str, Optional[str]]:
    """
    Extract size, brand, color, condition from product title and description.

    Args:
        title: Product title (required)
        description: Product description (optional)

    Returns:
        Dict with keys: size, brand, color, condition
    """
    # Combine title and description for search
    text = f"{title} {description}".upper()

    # ============================================
    # SIZE EXTRACTION
    # ============================================
    size = None

    # Size patterns - ordered by specificity
    size_patterns = [
        # German patterns
        r'GR[ÖO][ßS]E\s*[:.]?\s*(\d{2})',      # Größe 38, Größe: 39
        r'GR\.?\s*(\d{2})\b',                   # Gr. 38, Gr38
        r'GROESSE\s*[:.]?\s*(\d{2})',          # Groesse 38

        # EU patterns
        r'EU\s*[:.]?\s*(\d{2})',               # EU 38, EU: 39
        r'\b(\d{2})\s*EU\b',                   # 38 EU

        # UK/US patterns (convert to EU later if needed)
        r'UK\s*[:.]?\s*(\d+(?:\.\d)?)',        # UK 5, UK 5.5
        r'US\s*[:.]?\s*(\d+(?:\.\d)?)',        # US 7, US 7.5

        # Standalone number in context
        r'STIEFEL[^\d]*(\d{2})\b',             # Stiefel 38
        r'BOOTS[^\d]*(\d{2})\b',               # Boots 39
        r'SCHUHE[^\d]*(\d{2})\b',              # Schuhe 40
    ]

    for pattern in size_patterns:
        match = re.search(pattern, text)
        if match:
            size = match.group(1)
            break

    # ============================================
    # BRAND EXTRACTION
    # ============================================
    brand = None

    # Brand list - case insensitive matching
    brands = {
        # Premium shoe brands
        'UGG': 'UGG',
        'NIKE': 'Nike',
        'ADIDAS': 'Adidas',
        'PUMA': 'Puma',
        'TIMBERLAND': 'Timberland',
        'DR. MARTENS': 'Dr. Martens',
        'DR MARTENS': 'Dr. Martens',
        'DOCMARTENS': 'Dr. Martens',
        'CONVERSE': 'Converse',
        'VANS': 'Vans',
        'NEW BALANCE': 'New Balance',
        'REEBOK': 'Reebok',
        'ASICS': 'Asics',
        'SKECHERS': 'Skechers',
        'CLARKS': 'Clarks',
        'GEOX': 'Geox',
        'ECCO': 'Ecco',
        'BIRKENSTOCK': 'Birkenstock',

        # Fashion brands
        'ZARA': 'Zara',
        'H&M': 'H&M',
        'MANGO': 'Mango',
        'GUCCI': 'Gucci',
        'PRADA': 'Prada',
        'LOUIS VUITTON': 'Louis Vuitton',
        'CHANEL': 'Chanel',
        'MICHAEL KORS': 'Michael Kors',
        'COACH': 'Coach',
        'FURLA': 'Furla',
        'RALPH LAUREN': 'Ralph Lauren',
        'TOMMY HILFIGER': 'Tommy Hilfiger',
        'LACOSTE': 'Lacoste',
        'BOSS': 'Hugo Boss',
        'HUGO BOSS': 'Hugo Boss',

        # German brands
        'GABOR': 'Gabor',
        'TAMARIS': 'Tamaris',
        'RIEKER': 'Rieker',
        'SALAMANDER': 'Salamander',
        'LLOYD': 'Lloyd',
        'SIOUX': 'Sioux',
    }

    for key, val in brands.items():
        if key in text:
            brand = val
            break

    # ============================================
    # COLOR EXTRACTION
    # ============================================
    color = None

    # Color mappings - German and English
    colors = {
        # Grays
        'GRAU': 'Grau',
        'GREY': 'Grau',
        'GRAY': 'Grau',
        'SILBER': 'Silber',
        'SILVER': 'Silber',

        # Browns
        'BRAUN': 'Braun',
        'BROWN': 'Braun',
        'COGNAC': 'Cognac',
        'CAMEL': 'Camel',
        'KARAMELL': 'Karamell',
        'CARAMEL': 'Karamell',
        'KASTANIE': 'Kastanienbraun',
        'CHESTNUT': 'Kastanienbraun',

        # Blacks
        'SCHWARZ': 'Schwarz',
        'BLACK': 'Schwarz',

        # Whites
        'WEI[ßS]': 'Weiß',
        'WHITE': 'Weiß',
        'CREME': 'Creme',
        'CREAM': 'Creme',
        'IVORY': 'Elfenbein',

        # Beiges
        'BEIGE': 'Beige',
        'SAND': 'Sand',
        'TAUPE': 'Taupe',
        'NUDE': 'Nude',

        # Blues
        'BLAU': 'Blau',
        'BLUE': 'Blau',
        'NAVY': 'Navy',
        'MARINE': 'Marine',
        'DUNKELBLAU': 'Dunkelblau',

        # Reds
        'ROT': 'Rot',
        'RED': 'Rot',
        'BORDEAUX': 'Bordeaux',
        'BURGUNDY': 'Bordeaux',
        'WEINROT': 'Weinrot',

        # Greens
        'GR[ÜU]N': 'Grün',
        'GREEN': 'Grün',
        'OLIVE': 'Olive',
        'KHAKI': 'Khaki',

        # Pinks
        'ROSA': 'Rosa',
        'PINK': 'Pink',

        # Yellows
        'GELB': 'Gelb',
        'YELLOW': 'Gelb',

        # Multi
        'BUNT': 'Bunt',
        'MULTI': 'Mehrfarbig',
    }

    for pattern, val in colors.items():
        if re.search(pattern, text):
            color = val
            break

    # ============================================
    # CONDITION EXTRACTION
    # ============================================
    condition = 'Gebraucht'  # Default

    condition_patterns = {
        r'NEU\s*(MIT\s*ETIKETT|WITH\s*TAGS?)': 'Neu mit Etikett',
        r'NEUWERTIG': 'Neuwertig',
        r'NEU\b': 'Neu',
        r'SEHR\s*GUT': 'Sehr gut',
        r'GUT(ER?)?\s*(ZUSTAND)?': 'Gut',
        r'GEBRAUCHT': 'Gebraucht',
        r'GETRAGEN': 'Gebraucht',
        r'LIKE\s*NEW': 'Neuwertig',
        r'EXCELLENT': 'Sehr gut',
        r'GOOD\s*CONDITION': 'Gut',
        r'USED': 'Gebraucht',
    }

    for pattern, cond in condition_patterns.items():
        if re.search(pattern, text):
            condition = cond
            break

    return {
        'size': size,
        'brand': brand,
        'color': color,
        'condition': condition
    }


def extract_size_from_title(title: str) -> Optional[str]:
    """Extract only size from title (shortcut function)"""
    return extract_metadata(title).get('size')


def extract_brand_from_title(title: str) -> Optional[str]:
    """Extract only brand from title (shortcut function)"""
    return extract_metadata(title).get('brand')


# Test
if __name__ == "__main__":
    test_titles = [
        "UGG Stiefel grau Größe 38",
        "UGG Damen Mini Bailey Button II Stiefel Grau Kurzschaft Winterstiefel EU 37",
        "Nike Air Max 90 weiß Gr. 42",
        "Adidas Ultraboost schwarz 43 EU NEU",
        "Timberland Boots braun Größe: 40 sehr gut",
        "Dr. Martens 1460 black UK 5",
    ]

    print("=" * 60)
    print("METADATA EXTRACTOR TEST")
    print("=" * 60)

    for title in test_titles:
        meta = extract_metadata(title)
        print(f"\nTitle: {title}")
        print(f"  Size: {meta['size']}")
        print(f"  Brand: {meta['brand']}")
        print(f"  Color: {meta['color']}")
        print(f"  Condition: {meta['condition']}")

    print("\n" + "=" * 60)
