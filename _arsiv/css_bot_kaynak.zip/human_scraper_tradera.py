"""
TATANGA V3 - Tradera Human Scraper
İnsan-benzeri davranışlarla Tradera'dan ürün kazıma
"""
from human_scraper_base import HumanScraper, LOG_DIR
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from datetime import datetime
from typing import List, Dict, Optional
import time
import random
import re
import urllib.parse


class TraderaScraper(HumanScraper):
    """Tradera (İsveç) için insan-benzeri scraper - İSVEÇÇE DESTEKLİ"""

    BASE_URL = "https://www.tradera.com"

    # Sıralama seçenekleri
    SORT_OPTIONS = {
        "relevance": "Relevance",
        "ending_soonest": "EndDateAscending",
        "newly_listed": "StartDateDescending",
        "price_low": "CurrentBidAscending",
        "price_high": "CurrentBidDescending",
    }

    # İsveççe Durum filtreleri (Condition/Zustand)
    # Tradera durum değerleri
    CONDITIONS = {
        # Almanca karşılıkları için mapping
        "neu": "1",           # Nyskick (Yeni)
        "sehr_gut": "2",      # Mycket gott skick (Çok iyi)
        "gut": "3",           # Gott skick (İyi)
        "akzeptabel": "4",    # Använt skick (Kullanılmış)
        # İsveççe orijinal isimler
        "nyskick": "1",
        "mycket_gott_skick": "2",
        "gott_skick": "3",
        "anvant_skick": "4",
        # English mappings
        "new": "1",
        "very_good": "2",
        "good": "3",
        "acceptable": "4",
    }

    # Almanca-İsveççe çeviri tablosu
    CONDITION_TRANSLATION = {
        "sehr gut": "mycket_gott_skick",
        "sehr_gut": "mycket_gott_skick",
        "gut": "gott_skick",
        "akzeptabel": "anvant_skick",
        "neu": "nyskick",
    }

    def __init__(self, headless: bool = True):
        super().__init__("tradera", headless)
        self.products_found = []
        self.visited_urls = set()

    def translate_condition(self, condition: str) -> str:
        """Almanca durum değerini İsveççe'ye çevir"""
        if not condition:
            return None
        condition_lower = condition.lower().replace(" ", "_")
        # Önce çeviri tablosuna bak
        if condition_lower in self.CONDITION_TRANSLATION:
            return self.CONDITION_TRANSLATION[condition_lower]
        # Direkt condition mapping'e bak
        if condition_lower in self.CONDITIONS:
            return condition_lower
        return None

    def build_search_url(self, query: str, page: int = 1,
                         min_price: float = None, max_price: float = None,
                         sort: str = None, buy_now_only: bool = False,
                         condition: str = None, conditions: list = None) -> str:
        """
        Tradera arama URL'si oluştur
        condition: Tek durum (str) - Almanca veya İsveççe kabul eder
        conditions: Çoklu durum listesi (list)
        """
        params = {
            "q": query,
            "pn": page,
        }

        if min_price:
            params["priceMin"] = int(min_price)
        if max_price:
            params["priceMax"] = int(max_price)
        if sort and sort in self.SORT_OPTIONS:
            params["sortBy"] = self.SORT_OPTIONS[sort]
        if buy_now_only:
            params["buyNow"] = "true"

        # Durum filtresi - tek veya çoklu
        condition_values = []
        if conditions:
            for cond in conditions:
                translated = self.translate_condition(cond)
                if translated and translated in self.CONDITIONS:
                    condition_values.append(self.CONDITIONS[translated])
        elif condition:
            translated = self.translate_condition(condition)
            if translated and translated in self.CONDITIONS:
                condition_values.append(self.CONDITIONS[translated])

        # Tradera itemCondition parametresi
        if condition_values:
            params["itemCondition"] = ",".join(condition_values)
            self.log(f"Durum filtresi eklendi: {condition_values}")

        query_string = urllib.parse.urlencode(params)
        return f"{self.BASE_URL}/search?{query_string}"

    def go_to_homepage(self):
        """Tradera ana sayfasına git"""
        self.log("Tradera ana sayfasına gidiliyor...")
        self.visit_url(self.BASE_URL)
        self.screenshot("homepage")
        self.random_delay(1, 2)
        self.close_cookie_banner()

    def close_cookie_banner(self, selectors: list = None):
        """Tradera cookie banner'ı kapat"""
        tradera_selectors = [
            "#onetrust-accept-btn-handler",
            "[data-testid='cookie-accept']",
            "button[id*='accept']",
            ".cookie-consent button",
        ]
        super().close_cookie_banner(tradera_selectors + (selectors or []))

    def get_product_elements(self) -> list:
        """Sayfadaki ürün elementlerini al"""
        selectors = [
            "[data-testid='search-result-item']",
            ".search-result-item",
            "article.item",
            ".item-card",
            "[class*='SearchResultItem']",
        ]

        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    self.log(f"{len(elements)} ürün elementi bulundu ({selector})")
                    return elements
            except:
                pass

        # Alternatif: Link bazlı arama
        try:
            links = self.driver.find_elements(By.CSS_SELECTOR, "a[href*='/item/']")
            if links:
                self.log(f"{len(links)} ürün linki bulundu")
                return links
        except:
            pass

        return []

    def extract_product_data(self, element) -> Optional[Dict]:
        """Ürün elementinden veri çıkar"""
        try:
            # URL
            url = None
            try:
                if element.tag_name == "a":
                    url = element.get_attribute("href")
                else:
                    link = element.find_element(By.CSS_SELECTOR, "a[href*='/item/']")
                    url = link.get_attribute("href")
            except:
                pass

            if not url or "/item/" not in url:
                return None

            # Zaten gördük mü?
            if url in self.visited_urls:
                return None
            self.visited_urls.add(url)

            # Başlık
            title = None
            title_selectors = [
                "[data-testid='item-title']",
                ".item-title",
                "h3",
                "h2",
                "[class*='title']",
            ]
            for sel in title_selectors:
                try:
                    title_elem = element.find_element(By.CSS_SELECTOR, sel)
                    title = title_elem.text.strip()
                    if title:
                        break
                except:
                    pass

            if not title:
                # Link text'den al
                try:
                    title = element.text.split("\n")[0].strip()
                except:
                    pass

            if not title:
                return None

            # Fiyat (SEK)
            price = None
            price_selectors = [
                "[data-testid='price']",
                ".price",
                "[class*='Price']",
                "span[class*='price']",
            ]
            for sel in price_selectors:
                try:
                    price_elem = element.find_element(By.CSS_SELECTOR, sel)
                    price_text = price_elem.text
                    # "150 kr" veya "1 500 kr"
                    price_match = re.search(r"([\d\s]+)\s*kr", price_text.replace(" ", ""))
                    if price_match:
                        price = float(price_match.group(1).replace(" ", ""))
                        break
                except:
                    pass

            # Resim
            image_url = None
            try:
                img = element.find_element(By.CSS_SELECTOR, "img")
                image_url = img.get_attribute("src") or img.get_attribute("data-src")
            except:
                pass

            # Açık artırma bitiş zamanı
            end_time = None
            try:
                time_elem = element.find_element(By.CSS_SELECTOR, "[data-testid='time-left'], .time-left")
                end_time = time_elem.text.strip()
            except:
                pass

            return {
                "url": url,
                "title": title,
                "price": price,
                "currency": "SEK",
                "end_time": end_time,
                "image": image_url,
                "platform": "tradera",
                "scraped_at": datetime.now().isoformat()
            }

        except Exception as e:
            self.log(f"Ürün verisi çıkarma hatası: {e}", "debug")
            return None

    def extract_all_products(self) -> List[Dict]:
        """Sayfadaki tüm ürünleri çıkar"""
        elements = self.get_product_elements()
        products = []

        for element in elements:
            product = self.extract_product_data(element)
            if product and product["url"] not in [p["url"] for p in self.products_found]:
                products.append(product)
                self.products_found.append(product)

        self.log(f"{len(products)} yeni ürün çıkarıldı (Toplam: {len(self.products_found)})")
        return products

    def visit_random_product(self, visit_seller: bool = True) -> Optional[Dict]:
        """
        Rastgele bir ürüne git ve satıcı profilini ziyaret et
        İnsansı davranış: Ürün → Scroll → Satıcı Profili → Scroll → Geri → Geri
        """
        elements = self.get_product_elements()
        if not elements:
            self.log("Ürün elementi bulunamadı")
            return None

        random_elements = random.sample(elements[:min(10, len(elements))], 1)
        element = random_elements[0]

        product_data = self.extract_product_data(element)
        if not product_data:
            return None

        self.log(f"=== RASTGELE ÜRÜN ZİYARETİ ===")
        self.log(f"Ürün: {product_data['title'][:50]}...")

        # Mouse zigzag hareketi
        self.mouse_zigzag(element)
        self.random_delay(0.3, 0.6)

        # Ürün sayfasına git
        self.visit_url(product_data["url"])
        self.random_delay(2, 4)
        self.screenshot("product_page")

        # Sayfayı incele gibi scroll yap
        self.human_scroll("down", random.randint(200, 400))
        self.random_delay(1, 2)

        # Biraz daha scroll
        self.human_scroll("down", random.randint(100, 300))
        self.random_delay(0.5, 1.5)

        # Satıcı profiline git
        if visit_seller:
            self._visit_seller_profile()

        # Arama sonuçlarına geri dön
        self.random_delay(1, 2)
        self.go_back()
        self.random_delay(1, 2)

        self.log(f"=== RASTGELE ZİYARET TAMAMLANDI ===")
        return product_data

    def _visit_seller_profile(self) -> bool:
        """
        Tradera satıcı profilini ziyaret et
        """
        seller_selectors = [
            # Tradera satıcı linkleri
            "a[href*='/member/']",
            "a[href*='/seller/']",
            "[data-testid='seller-link']",
            ".seller-info a",
            "[class*='seller'] a",
            "[class*='Seller'] a",
            "a.seller-link",
            ".item-seller a",
        ]

        for selector in seller_selectors:
            try:
                links = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for link in links:
                    if link.is_displayed():
                        href = link.get_attribute("href") or ""
                        if "member" in href or "seller" in href.lower():
                            self.log(f"Satıcı profiline gidiliyor: {href[:50]}...")

                            # Zigzag mouse
                            self.mouse_zigzag(link)

                            # Tıkla
                            self.human_click(link)
                            self.random_delay(2, 4)
                            self.screenshot("seller_profile")

                            # Profilde scroll yap
                            self.human_scroll("down", random.randint(300, 500))
                            self.random_delay(1, 3)

                            # Biraz daha scroll
                            if random.random() < 0.5:
                                self.human_scroll("down", random.randint(200, 400))
                                self.random_delay(0.5, 1.5)

                            # Geri dön (ürün sayfasına)
                            self.go_back()
                            self.random_delay(1, 2)

                            self.log("Satıcı profili ziyareti tamamlandı")
                            return True
            except Exception as e:
                self.log(f"Satıcı linki denemesi başarısız: {e}", "debug")
                continue

        self.log("Satıcı profili bulunamadı", "debug")
        return False

    def scrape(self, query: str, max_products: int = None, max_pages: int = None,
               visit_products: bool = True, min_price: float = None,
               max_price: float = None, sort: str = "newly_listed",
               buy_now_only: bool = False, condition: str = None,
               conditions: list = None) -> List[Dict]:
        """
        Ana kazıma fonksiyonu - İsveççe durum desteği ile
        condition: Tek durum (str) - "sehr gut", "gut", "nyskick" vb.
        conditions: Çoklu durum listesi ["sehr gut", "gut"]
        """
        self.log(f"=== KAZIMA BAŞLIYOR ===")
        self.log(f"Arama: {query}")
        self.log(f"Max ürün: {max_products or 'Sınırsız'}")
        if condition:
            self.log(f"Durum filtresi: {condition}")
        if conditions:
            self.log(f"Durum filtreleri: {conditions}")

        try:
            page = 1

            # İlk sayfa URL'si
            url = self.build_search_url(
                query=query,
                page=page,
                min_price=min_price,
                max_price=max_price,
                sort=sort,
                buy_now_only=buy_now_only,
                condition=condition,
                conditions=conditions
            )

            self.log(f"--- Sayfa {page} ---")
            self.visit_url(url)
            self.close_cookie_banner()
            self.random_delay(2, 3)

            # === İLK SAYFA: HER ZAMAN BİR ÜRÜN VE SATICI PROFİLİ ZİYARET ET ===
            self.log("=== İLK SAYFA RASTGELE GEZİNME ===")
            self.human_scroll("down", random.randint(300, 500))
            self.random_delay(1, 2)

            self.log("İlk sayfa: Rastgele ürün ve satıcı profili ziyareti...")
            self.visit_random_product(visit_seller=True)

            while True:
                self.log(f"--- Sayfa {page} ---")

                # Scroll yap
                self.human_scroll("down", random.randint(300, 500))
                self.random_delay(1, 2)

                # Zigzag mouse hareketi
                if random.random() < 0.3:
                    try:
                        elements = self.get_product_elements()
                        if elements:
                            random_elem = random.choice(elements[:5])
                            self.mouse_zigzag(random_elem)
                    except:
                        pass

                # Ürünleri çıkar
                before_count = len(self.products_found)
                self.extract_all_products()
                after_count = len(self.products_found)
                new_products = after_count - before_count

                self.log(f"+{new_products} yeni ürün (Toplam: {after_count})")

                # Limit kontrolü
                if max_products and len(self.products_found) >= max_products:
                    self.log(f"Maksimum ürün sayısına ulaşıldı: {max_products}")
                    break

                if max_pages and page >= max_pages:
                    self.log(f"Maksimum sayfa sayısına ulaşıldı: {max_pages}")
                    break

                # Boş sayfa kontrolü
                if new_products == 0:
                    self.log("Boş sayfa, kazıma durduruluyor...")
                    break

                # Sonraki sayfalarda rastgele ürün ziyareti (%30 ihtimalle)
                if visit_products and page > 1 and random.random() < 0.3:
                    self.visit_random_product(visit_seller=True)

                # İnsansı bekleme
                self.random_delay(2, 4)

                # Sonraki sayfa
                page += 1
                url = self.build_search_url(
                    query=query,
                    page=page,
                    min_price=min_price,
                    max_price=max_price,
                    sort=sort,
                    buy_now_only=buy_now_only,
                    condition=condition,
                    conditions=conditions
                )
                self.visit_url(url)
                self.random_delay(2, 3)

            self.log(f"=== KAZIMA TAMAMLANDI ===")
            self.log(f"Toplam ürün: {len(self.products_found)}")
            self.screenshot("scraping_complete")

            return self.products_found

        except Exception as e:
            self.log(f"Kazıma hatası: {e}", "error")
            self.screenshot("error")
            raise


def run_tradera_scrape(query: str, max_products: int = None, headless: bool = True) -> List[Dict]:
    """Tradera kazıma işlemini çalıştır"""
    with TraderaScraper(headless=headless) as scraper:
        return scraper.scrape(query, max_products=max_products)


if __name__ == "__main__":
    import sys

    query = sys.argv[1] if len(sys.argv) > 1 else "nike"
    max_items = int(sys.argv[2]) if len(sys.argv) > 2 else 50

    print(f"Tradera kazıma başlıyor: {query}")
    products = run_tradera_scrape(query, max_products=max_items, headless=True)

    print(f"\n{len(products)} ürün bulundu:")
    for p in products[:5]:
        print(f"  - {p['title'][:40]} | {p['price']} SEK | {p['url']}")
