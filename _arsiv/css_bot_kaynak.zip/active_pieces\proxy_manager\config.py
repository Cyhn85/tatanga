# Proxy Manager Configuration
# Store rules and proxy service configurations

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'proxy_quota.db')

# ============================================================================
# STORE RULES (ÖNCEDEN TANIMLI - KULLANICIYA SORULMAZ)
# ============================================================================
STORE_RULES = {
    'cyhn54': {
        'proxy_mode': 'direct',  # Proxy YOK - Ev WiFi
        'description': 'Ev WiFi - Direkt bağlantı',
        'network': 'home_wifi',
    },
    'cssberlin': {
        'proxy_mode': 'auto',  # Otomatik proxy seçimi
        'description': 'Farklı IP gerekli - Proxy havuzundan',
        'network': 'proxy_pool',
        'preferred_type': 'residential',  # Tercih: Residential IP
    }
}

# ============================================================================
# FREE PROXY SERVICES (Ücretsiz Servisler)
# ============================================================================
PROXY_SERVICES = {
    # -------------------------------------------------------------------------
    # WEBSHARE.IO - 10 ücretsiz proxy/ay (datacenter)
    # https://www.webshare.io/ - Kayıt gerekli
    # -------------------------------------------------------------------------
    'webshare': {
        'enabled': True,
        'type': 'datacenter',
        'quota_type': 'monthly',  # Aylık kota
        'quota_limit': 10,  # 10 proxy
        'quota_unit': 'proxies',
        'quality': 3,  # 1-5 arası kalite puanı
        'api_key': '',  # Kullanıcı dolduracak
        'proxy_format': 'http://{user}:{pass}@{host}:{port}',
        'docs': 'https://www.webshare.io/features/free-proxy',
    },

    # -------------------------------------------------------------------------
    # GEONODE - 100 istek/gün ücretsiz (residential)
    # https://geonode.com/ - Kayıt gerekli
    # -------------------------------------------------------------------------
    'geonode': {
        'enabled': True,
        'type': 'residential',
        'quota_type': 'daily',  # Günlük kota
        'quota_limit': 100,  # 100 istek/gün
        'quota_unit': 'requests',
        'quality': 4,
        'api_key': '',
        'proxy_format': 'http://{user}:{pass}@{host}:{port}',
        'docs': 'https://geonode.com/free-proxy-list',
    },

    # -------------------------------------------------------------------------
    # PROXYSCRAPE - Sınırsız ücretsiz proxy listesi
    # https://proxyscrape.com/ - API ile çekilir
    # -------------------------------------------------------------------------
    'proxyscrape': {
        'enabled': True,
        'type': 'mixed',
        'quota_type': 'unlimited',  # Sınırsız ama kalite düşük
        'quota_limit': 999999,
        'quota_unit': 'requests',
        'quality': 2,
        'api_url': 'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=DE&ssl=yes&anonymity=elite',
        'docs': 'https://proxyscrape.com/free-proxy-list',
    },

    # -------------------------------------------------------------------------
    # SCRAPINGANT - 10,000 API kredisi/ay ücretsiz
    # https://scrapingant.com/ - Web scraping API
    # -------------------------------------------------------------------------
    'scrapingant': {
        'enabled': False,  # Kayıt sonrası aktif et
        'type': 'rotating',
        'quota_type': 'monthly',
        'quota_limit': 10000,
        'quota_unit': 'credits',
        'quality': 4,
        'api_key': '',
        'docs': 'https://scrapingant.com/free-plan',
    },

    # -------------------------------------------------------------------------
    # SCRAPERAPI - 1000 istek/ay ücretsiz
    # https://www.scraperapi.com/ - Proxy rotasyonu dahil
    # -------------------------------------------------------------------------
    'scraperapi': {
        'enabled': False,
        'type': 'rotating',
        'quota_type': 'monthly',
        'quota_limit': 1000,
        'quota_unit': 'requests',
        'quality': 5,
        'api_key': '',
        'docs': 'https://www.scraperapi.com/pricing/',
    },

    # -------------------------------------------------------------------------
    # MOBILE HOTSPOT - Telefon üzerinden (manuel)
    # -------------------------------------------------------------------------
    'mobile_hotspot': {
        'enabled': True,
        'type': 'mobile',
        'quota_type': 'unlimited',  # Data planına bağlı
        'quota_limit': 999999,
        'quota_unit': 'requests',
        'quality': 5,  # En iyi - gerçek mobil IP
        'host': '192.168.43.1',
        'port': 8080,
        'requires_manual': True,  # Manuel aktivasyon gerekli
        'docs': 'Every Proxy app ile telefon hotspot',
    },
}

# ============================================================================
# ROTATION SETTINGS (Rotasyon Ayarları)
# ============================================================================
ROTATION_CONFIG = {
    'auto_switch_threshold': 7,  # %7 kota kaldığında otomatik geçiş
    'fallback_order': [  # Tercih sırası
        'mobile_hotspot',  # 1. Mobil (en güvenilir)
        'geonode',         # 2. Residential
        'webshare',        # 3. Datacenter
        'proxyscrape',     # 4. Free list (son çare)
    ],
    'health_check_interval': 300,  # 5 dakikada bir sağlık kontrolü
    'max_retries': 3,  # Başarısız proxy için max deneme
}

# ============================================================================
# VPN OPTIONS (Alternatif - Kurulum gerekli)
# ============================================================================
VPN_OPTIONS = {
    'protonvpn': {
        'name': 'ProtonVPN',
        'free_tier': 'Sınırsız (yavaş, 3 lokasyon)',
        'setup': 'https://protonvpn.com/download',
        'cli_command': 'protonvpn-cli connect --fastest',
    },
    'windscribe': {
        'name': 'Windscribe',
        'free_tier': '10GB/ay, 10+ lokasyon',
        'setup': 'https://windscribe.com/download',
        'cli_command': 'windscribe connect best',
    },
}