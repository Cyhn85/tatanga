"""
TATANGA V3 - Scraper Service
Headless Chrome ile platform scraping
"""
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
import time
import random
import re
from typing import List, Dict
from datetime import datetime
import logging

logger = logging.getLogger("TATANGA.scraper")

class ScraperService:
    """Headless scraping service for Vinted, eBay, Kleinanzeigen"""

    PLATFORMS = {
        "vinted": {
            "base_url": "https://www.vinted.de",
            "search_template": "/catalog?search_text={query}&order=newest_first",
        },
        "ebay": {
            "base_url": "https://www.ebay.de",
            "search_template": "/sch/i.html?_nkw={query}&_sop=10",
        },
        "kleinanzeigen": {
            "base_url": "https://www.kleinanzeigen.de",
            "search_template": "/s-{query}/k0",
        }
    }

    def __init__(self, headless: bool = True):
        self.headless = headless
        self.driver = None

    def _init_driver(self):
        if self.driver:
            return

        options = uc.ChromeOptions()

        if self.headless:
            options.add_argument("--headless=new")

        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--lang=de-DE")

        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
        options.add_argument(f"--user-agent={ua}")

        self.driver = uc.Chrome(options=options)
        self.driver.implicitly_wait(10)
        logger.info("Chrome driver initialized")

    def _close_cookies(self):
        selectors = [
            "#onetrust-accept-btn-handler",
            "[data-testid='cookie-accept']",
            ".cookie-consent-accept",
        ]

        for selector in selectors:
            try:
                btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    btn.click()
                    time.sleep(1)
                    return True
            except:
                continue

        # Try by text
        for text in ["Akzeptieren", "Accept", "Alle akzeptieren"]:
            try:
                btn = self.driver.find_element(By.XPATH, f"//button[contains(text(), '{text}')]")
                if btn.is_displayed():
                    btn.click()
                    time.sleep(1)
                    return True
            except:
                continue
        return False

    def _scroll_page(self, count: int = 3):
        for _ in range(count):
            self.driver.execute_script(f"window.scrollBy(0, {random.randint(400, 800)});")
            time.sleep(random.uniform(0.8, 1.5))

    def _extract_vinted(self) -> List[Dict]:
        products = []
        items = self.driver.find_elements(By.CSS_SELECTOR, ".feed-grid__item, [data-testid='grid-item']")

        for item in items:
            try:
                product = {}
                link = item.find_elements(By.CSS_SELECTOR, "a[href*='/item'], a[href*='/artikel']")
                if link:
                    product["url"] = link[0].get_attribute("href")

                img = item.find_elements(By.CSS_SELECTOR, "img")
                if img:
                    alt = img[0].get_attribute("alt") or ""
                    product["image"] = img[0].get_attribute("src") or img[0].get_attribute("data-src")

                    if ", marke:" in alt.lower():
                        product["title"] = alt.split(", marke:")[0].strip()
                    elif "," in alt:
                        product["title"] = alt.split(",")[0].strip()
                    else:
                        product["title"] = alt[:100].strip()

                    price_match = re.search(r"([\d.,]+)\s*(?:EUR|eur)", alt)
                    if price_match:
                        try:
                            product["price"] = float(price_match.group(1).replace(".", "").replace(",", "."))
                        except:
                            pass

                if product.get("url") and product.get("title"):
                    product["platform"] = "vinted"
                    product["scraped_at"] = datetime.now().isoformat()
                    products.append(product)
            except:
                continue

        return products

    def _extract_ebay(self) -> List[Dict]:
        products = []
        # Updated selector for eBay DE 2024/2025
        items = self.driver.find_elements(By.CSS_SELECTOR, "ul.srp-results li")

        for item in items:
            try:
                product = {}

                # Find title - try multiple selectors
                title_el = item.find_elements(By.CSS_SELECTOR, "[role='heading'] span, .s-item__title, a span")
                if title_el:
                    title = title_el[0].text.strip()
                    if title and len(title) > 3:
                        product["title"] = title

                # Find link
                link = item.find_elements(By.CSS_SELECTOR, "a[href*='ebay.de/itm'], a[href*='/itm/']")
                if link:
                    product["url"] = link[0].get_attribute("href")

                # Find price
                price_el = item.find_elements(By.CSS_SELECTOR, "[class*='price'] span, .s-item__price")
                if price_el:
                    price_text = price_el[0].text
                    price_match = re.search(r"([\d.,]+)", price_text)
                    if price_match:
                        try:
                            product["price"] = float(price_match.group(1).replace(".", "").replace(",", "."))
                        except:
                            pass

                # Find image
                img = item.find_elements(By.CSS_SELECTOR, "img[src*='ebayimg'], img[data-src*='ebayimg']")
                if img:
                    product["image"] = img[0].get_attribute("src") or img[0].get_attribute("data-src")

                if product.get("url") and product.get("title") and "Shop on eBay" not in product.get("title", ""):
                    product["platform"] = "ebay"
                    product["scraped_at"] = datetime.now().isoformat()
                    products.append(product)
            except:
                continue

        return products

    def _extract_kleinanzeigen(self) -> List[Dict]:
        products = []
        items = self.driver.find_elements(By.CSS_SELECTOR, ".aditem, article[data-adid]")

        for item in items:
            try:
                product = {}

                link = item.find_elements(By.CSS_SELECTOR, "a[href*='/s-anzeige']")
                if link:
                    href = link[0].get_attribute("href")
                    product["url"] = href if href.startswith("http") else "https://www.kleinanzeigen.de" + href
                    product["title"] = link[0].text.strip() or link[0].get_attribute("title")

                price_el = item.find_elements(By.CSS_SELECTOR, ".aditem-main--middle--price, [class*='price']")
                if price_el:
                    price_match = re.search(r"([\d.,]+)", price_el[0].text)
                    if price_match:
                        try:
                            product["price"] = float(price_match.group(1).replace(".", "").replace(",", "."))
                        except:
                            pass

                img = item.find_elements(By.CSS_SELECTOR, "img")
                if img:
                    product["image"] = img[0].get_attribute("src") or img[0].get_attribute("data-src")

                if product.get("url") and product.get("title"):
                    product["platform"] = "kleinanzeigen"
                    product["scraped_at"] = datetime.now().isoformat()
                    products.append(product)
            except:
                continue

        return products

    def scrape(self, platform: str, query: str, max_pages: int = 3, max_items: int = 50) -> Dict:
        result = {
            "status": "pending",
            "platform": platform,
            "query": query,
            "products": [],
            "stats": {
                "pages_scraped": 0,
                "items_found": 0,
                "started_at": datetime.now().isoformat(),
                "completed_at": None
            }
        }

        if platform not in self.PLATFORMS:
            result["status"] = "error"
            result["error"] = f"Unknown platform: {platform}"
            return result

        try:
            self._init_driver()

            config = self.PLATFORMS[platform]
            search_url = config["base_url"] + config["search_template"].format(query=query.replace(" ", "+"))

            logger.info(f"Scraping {platform}: {query}")

            self.driver.get(search_url)
            time.sleep(random.uniform(3, 5))

            self._close_cookies()
            time.sleep(1)

            all_products = []

            for page in range(max_pages):
                logger.info(f"Page {page + 1}/{max_pages}")

                self._scroll_page(3)
                time.sleep(2)

                if platform == "vinted":
                    products = self._extract_vinted()
                elif platform == "ebay":
                    products = self._extract_ebay()
                elif platform == "kleinanzeigen":
                    products = self._extract_kleinanzeigen()
                else:
                    products = []

                existing_urls = {p["url"] for p in all_products}
                new_products = [p for p in products if p.get("url") not in existing_urls]
                all_products.extend(new_products)

                result["stats"]["pages_scraped"] += 1

                if len(all_products) >= max_items:
                    break

                time.sleep(random.uniform(2, 4))

            result["products"] = all_products[:max_items]
            result["stats"]["items_found"] = len(result["products"])
            result["stats"]["completed_at"] = datetime.now().isoformat()
            result["status"] = "completed"

        except Exception as e:
            logger.error(f"Scraping error: {e}")
            result["status"] = "error"
            result["error"] = str(e)

        return result

    def close(self):
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            self.driver = None


def run_scrape_task(platform: str, query: str, max_pages: int = 3, max_items: int = 50) -> Dict:
    scraper = ScraperService(headless=True)
    try:
        return scraper.scrape(platform, query, max_pages, max_items)
    finally:
        scraper.close()
