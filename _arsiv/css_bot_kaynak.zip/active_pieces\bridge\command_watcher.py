#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Command Watcher
=========================
Bridge'den gelen komutları izler ve işler.
Bu script Claude Code tarafından çalıştırılabilir veya standalone çalışabilir.

Kullanım:
    python command_watcher.py           # Tek seferlik kontrol
    python command_watcher.py --watch   # Sürekli izleme
"""

import json
import sys
import time
import argparse
from pathlib import Path
from datetime import datetime

# Paths
BRIDGE_DIR = Path(__file__).parent
COMMANDS_FILE = BRIDGE_DIR / "commands.json"
RESULTS_FILE = BRIDGE_DIR / "results.json"
STATUS_FILE = BRIDGE_DIR / "status.json"

# Add parent to path for imports
sys.path.insert(0, str(BRIDGE_DIR.parent))


def load_json(file_path: Path) -> dict:
    """JSON dosyasını oku"""
    try:
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
    return {}


def save_json(file_path: Path, data: dict):
    """JSON dosyasına yaz"""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Error saving {file_path}: {e}")


def get_pending_commands() -> list:
    """Bekleyen komutları al"""
    commands = load_json(COMMANDS_FILE)
    return [c for c in commands.get('queue', []) if c.get('status') == 'pending']


def update_command_status(command_id: str, status: str, result: str = None):
    """Komut durumunu güncelle"""
    commands = load_json(COMMANDS_FILE)
    for cmd in commands.get('queue', []):
        if cmd.get('id') == command_id:
            cmd['status'] = status
            if result:
                cmd['result'] = result
            break
    commands['last_updated'] = datetime.now().isoformat()
    save_json(COMMANDS_FILE, commands)


def save_result(command_id: str, success: bool, result: str):
    """Sonucu kaydet"""
    results = load_json(RESULTS_FILE)
    if 'results' not in results:
        results['results'] = []

    results['results'].append({
        'command_id': command_id,
        'timestamp': datetime.now().isoformat(),
        'success': success,
        'result': result
    })
    results['last_updated'] = datetime.now().isoformat()

    # Keep only last 100 results
    if len(results['results']) > 100:
        results['results'] = results['results'][-100:]

    save_json(RESULTS_FILE, results)

    # Remove from queue
    commands = load_json(COMMANDS_FILE)
    commands['queue'] = [c for c in commands.get('queue', []) if c.get('id') != command_id]
    save_json(COMMANDS_FILE, commands)

    # Update status
    status = load_json(STATUS_FILE)
    status['stats'] = status.get('stats', {})
    if success:
        status['stats']['successful'] = status['stats'].get('successful', 0) + 1
    else:
        status['stats']['failed'] = status['stats'].get('failed', 0) + 1
    status['bridge_status'] = 'idle'
    status['active_command'] = None
    save_json(STATUS_FILE, status)


def update_heartbeat():
    """Heartbeat güncelle"""
    status = load_json(STATUS_FILE)
    status['last_heartbeat'] = datetime.now().isoformat()
    status['claude_connected'] = True
    save_json(STATUS_FILE, status)


def process_command(command: dict) -> tuple:
    """
    Komutu işle

    Returns:
        (success: bool, result: str)
    """
    from core.command_parser import parse_command, to_dict

    command_id = command.get('id')
    command_text = command.get('command', '')

    print(f"\n{'='*50}")
    print(f"Processing command: {command_id}")
    print(f"Text: {command_text}")
    print(f"{'='*50}")

    try:
        # Update status
        status = load_json(STATUS_FILE)
        status['bridge_status'] = 'processing'
        status['active_command'] = command_id
        save_json(STATUS_FILE, status)

        # Parse command
        parsed = parse_command(command_text)
        parsed_dict = to_dict(parsed)

        print(f"Parsed: {json.dumps(parsed_dict, indent=2)}")

        # Execute based on action
        action = parsed.action

        if action == 'search':
            result = execute_search(parsed)
        elif action == 'publish':
            result = execute_publish(parsed)
        elif action == 'delete':
            result = execute_delete(parsed)
        elif action == 'cleanup':
            result = execute_cleanup(parsed)
        elif action == 'check':
            result = execute_check(parsed)
        else:
            result = f"Unknown action: {action}"
            return False, result

        return True, result

    except Exception as e:
        error = f"Error processing command: {str(e)}"
        print(f"ERROR: {error}")
        return False, error


def execute_search(parsed) -> str:
    """Arama komutunu çalıştır"""
    platforms = parsed.platforms
    query = parsed.query
    filters = parsed.filters

    results = []

    for platform in platforms:
        if platform == 'ebay.de':
            try:
                from ebay_de_v2_scraper import EbayDEScraper
                scraper = EbayDEScraper()

                # Build params
                condition = filters.get('condition')
                products = scraper.scrape_ebay(
                    query=query,
                    max_pages=3,
                    condition=[condition] if condition else None,
                    buy_it_now_only=True
                )
                results.append(f"eBay.de: {len(products)} products found")
            except Exception as e:
                results.append(f"eBay.de error: {str(e)}")

        elif platform == 'vinted.de':
            try:
                from vinted_de_scraper import VintedDEScraper
                scraper = VintedDEScraper()
                products = scraper.scrape_vinted(query=query, max_pages=3)
                results.append(f"Vinted.de: {len(products)} products found")
            except Exception as e:
                results.append(f"Vinted.de error: {str(e)}")

    return " | ".join(results) if results else "No results"


def execute_publish(parsed) -> str:
    """Yayınlama komutunu çalıştır"""
    target_id = parsed.target_id

    if not target_id:
        return "No target ID specified. Use 'favori #123' format."

    try:
        from integrations.github_publisher import GitHubPublisher
        publisher = GitHubPublisher()
        # TODO: Implement publish by ID
        return f"Publishing product #{target_id} (not implemented yet)"
    except Exception as e:
        return f"Publish error: {str(e)}"


def execute_delete(parsed) -> str:
    """Silme komutunu çalıştır"""
    target_id = parsed.target_id

    if not target_id:
        return "No target ID specified. Use 'sil #123' format."

    return f"Deleting product #{target_id} (not implemented yet)"


def execute_cleanup(parsed) -> str:
    """Temizlik komutunu çalıştır"""
    try:
        from integrations.favorites_validator import FavoritesValidator
        validator = FavoritesValidator()
        result = validator.validate_all_favorites()

        sold_count = len(result.get('sold', []))
        available_count = len(result.get('available', []))

        return f"Cleanup complete: {sold_count} sold, {available_count} available"
    except Exception as e:
        return f"Cleanup error: {str(e)}"


def execute_check(parsed) -> str:
    """Kontrol komutunu çalıştır"""
    target_id = parsed.target_id

    if target_id:
        return f"Checking product #{target_id} (not implemented yet)"

    return "Use 'kontrol #123' to check specific product"


def watch_commands(interval: int = 5):
    """Komutları sürekli izle"""
    print(f"""
╔═══════════════════════════════════════════════════════╗
║           TATANGA COMMAND WATCHER v1.0                ║
╠═══════════════════════════════════════════════════════╣
║  Status:    WATCHING                                  ║
║  Interval:  {interval} seconds                               ║
║  Commands:  {COMMANDS_FILE}                           ║
╚═══════════════════════════════════════════════════════╝
    """)

    while True:
        try:
            update_heartbeat()

            pending = get_pending_commands()
            if pending:
                for cmd in pending:
                    success, result = process_command(cmd)
                    save_result(cmd['id'], success, result)
                    print(f"Result: {result}")
            else:
                print(".", end="", flush=True)

            time.sleep(interval)

        except KeyboardInterrupt:
            print("\n\nWatcher stopped.")
            break
        except Exception as e:
            print(f"\nError: {e}")
            time.sleep(interval)


def check_once():
    """Tek seferlik kontrol"""
    print("Checking for pending commands...")

    pending = get_pending_commands()
    if not pending:
        print("No pending commands.")
        return

    print(f"Found {len(pending)} pending command(s)")

    for cmd in pending:
        success, result = process_command(cmd)
        save_result(cmd['id'], success, result)
        print(f"Result: {result}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='TATANGA Command Watcher')
    parser.add_argument('--watch', action='store_true', help='Continuous watching mode')
    parser.add_argument('--interval', type=int, default=5, help='Check interval in seconds')

    args = parser.parse_args()

    if args.watch:
        watch_commands(args.interval)
    else:
        check_once()
