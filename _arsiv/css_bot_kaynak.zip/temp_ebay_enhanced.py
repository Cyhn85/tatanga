"""
TATANGA V3 - eBay Human Scraper
Insan-benzeri davranislarla eBay'den urun kazima
GUNCELLEME: Acik artirma filtreleme eklendi!
"""
from .human_scraper_base import HumanScraper, LOG_DIR
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from datetime import datetime
from typing import List, Dict, Optional
import time
import random
import re
import urllib.parse


class EbayScraper(HumanScraper):
    """eBay icin insan-benzeri scraper - acik artirma filtreleme destekli"""

    BASE_URL = "https://www.ebay.de"

    # Listing tipleri
    LISTING_TYPE_AUCTION = "auction"
    LISTING_TYPE_BUY_NOW = "buy_now"
    LISTING_TYPE_HYBRID = "hybrid"  # Hem acik artirma hem sofort-kaufen

    # eBay siralama secenekleri
    SORT_OPTIONS = {
        "best_match": "",
        "ending_soonest": "1",
        "newly_listed": "10",
        "price_low": "15",
        "price_high": "16",
    }

    # Durum filtreleri (eBay condition codes)
    CONDITIONS = {
        "new": "1000",
        "open_box": "1500",
        "refurbished": "2000",
        "used": "3000",
    }

    # Almanca durum isimleri -> eBay condition mapping
    CONDITION_MAPPING = {
        # Almanca
        "neu": "new",
        "sehr_gut": "used",
        "sehr gut": "used",
        "gut": "used",
        "akzeptabel": "used",
        # English
        "new": "new",
        "very_good": "used",
        "good": "used",
        "acceptable": "used",
    }

    def translate_condition(self, condition: str) -> str:
        """Almanca durum degerini eBay condition'a cevir"""
        if not condition:
            return None
        condition_lower = condition.lower().replace(" ", "_")
        if condition_lower in self.CONDITION_MAPPING:
            return self.CONDITION_MAPPING[condition_lower]
        if condition_lower in self.CONDITIONS:
            return condition_lower
        return None

    def __init__(self, headless: bool = True):
        super().__init__("ebay", headless)
        self.products_found = []
        self.visited_urls = set()

    def close_cookie_banner(self, selectors: list = None):
        """eBay cookie banner - special handling for bottom banner"""
        ebay_selectors = [
            "//button[contains(text(), 'Alle akzeptieren')]",
            "//button[contains(text(), 'Alle ablehnen')]",
            "#gdpr-banner-accept",
            "button#gdpr-banner-accept",
            "[data-testid='gdpr-banner-accept']",
            "button[class*='gdpr'][class*='accept']",
            "#onetrust-accept-btn-handler",
            "button[id*='accept']",
        ]
        return super().close_cookie_banner(ebay_selectors + (selectors or []))

    def is_auction(self, element) -> bool:
        """Urun acik artirma mi? (Gebot/bid gosteriyorsa)"""
        auction_indicators = [
            ".//span[contains(text(), 'Gebot')]",
            ".//span[contains(text(), 'Gebote')]",
            ".//span[contains(text(), 'bid')]",
            ".//span[contains(text(), 'bids')]",
            ".//span[contains(text(), 'Auktion')]",
            ".//*[contains(@class, 's-item__bidCount')]",
            ".//*[contains(@class, 'bid')]",
        ]

        for xpath in auction_indicators:
            try:
                el = element.find_element(By.XPATH, xpath)
                if el and el.text:
                    return True
            except:
                pass
        return False

    def has_buy_now(self, element) -> bool:
        """Urun Sofort-Kaufen (Buy Now) secenegine sahip mi?"""
        buy_now_indicators = [
            ".//span[contains(text(), 'Sofort-Kaufen')]",
            ".//span[contains(text(), 'Sofort kaufen')]",
            ".//span[contains(text(), 'Buy It Now')]",
            ".//*[contains(@class, 'buyItNow')]",
            ".//*[contains(@class, 'bin')]",
        ]

        for xpath in buy_now_indicators:
            try:
                el = element.find_element(By.XPATH, xpath)
                if el:
                    return True
            except:
                pass

        # Eger acik artirma degilse, genellikle Sofort-Kaufen'dir
        return not self.is_auction(element)

    def get_listing_type(self, element) -> str:
        """Ilan tipini belirle"""
        is_auc = self.is_auction(element)
        has_bin = self.has_buy_now(element)

        if is_auc and has_bin:
            return self.LISTING_TYPE_HYBRID
        elif is_auc:
            return self.LISTING_TYPE_AUCTION
        else:
            return self.LISTING_TYPE_BUY_NOW

    def build_search_url(self, query: str, page: int = 1,
                         min_price: float = None, max_price: float = None,
                         condition: str = None, sort: str = None,
                         buy_now_only: bool = False) -> str:
        """eBay arama URL'si olustur"""
        params = {
            "_nkw": query,
            "_pgn": page,
        }

        if min_price:
            params["_udlo"] = int(min_price)
        if max_price:
            params["_udhi"] = int(max_price)
        if condition and condition in self.CONDITIONS:
            params["LH_ItemCondition"] = self.CONDITIONS[condition]
        if sort and sort in self.SORT_OPTIONS:
            params["_sop"] = self.SORT_OPTIONS[sort]

        # Sadece Sofort-Kaufen ilanlarini goster
        if buy_now_only:
            params["LH_BIN"] = "1"

        query_string = urllib.parse.urlencode(params)
        return f"{self.BASE_URL}/sch/i.html?{query_string}"

    def go_to_homepage(self):
        """eBay ana sayfasina git"""
        self.log("eBay ana sayfasina gidiliyor...")
        self.visit_url(self.BASE_URL)
        self.screenshot("homepage")
        self.random_delay(1, 2)
        self.close_cookie_banner()

    def get_product_elements(self) -> list:
        """Sayfadaki urun elementlerini al - eBay 2024 yapisi"""
        selectors = [
            ".srp-results li.s-card",
            ".srp-results li[data-viewport]",
            ".srp-results li",
        ]

        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    self.log(f"{len(elements)} urun elementi bulundu ({selector})")
                    return elements
            except:
                pass

        return []

    def extract_product_data(self, element, skip_auctions: bool = True) -> Optional[Dict]:
        """Urun elementinden veri cikar - acik artirma filtreleme destekli"""
        try:
            # Listing tipini belirle
            listing_type = self.get_listing_type(element)

            # Acik artirma filtresi
            if skip_auctions and listing_type == self.LISTING_TYPE_AUCTION:
                self.log("Sadece acik artirma - atlaniyor", "debug")
                return None

            # URL - /itm/ iceren link
            url = None
            try:
                link = element.find_element(By.CSS_SELECTOR, "a[href*='/itm/']")
                url = link.get_attribute("href")
            except:
                return None

            if not url or "/itm/" not in url:
                return None

            # Zaten gorduk mu?
            base_url = url.split("?")[0]
            if base_url in self.visited_urls:
                return None
            self.visited_urls.add(base_url)

            # Baslik - farkli selector'lar dene
            title = None
            title_selectors = [
                ".s-card__title",
                "span[role='heading']",
                "h3",
                ".s-item__title span",
                "a[href*='/itm/'] span",
            ]
            for sel in title_selectors:
                try:
                    title_elem = element.find_element(By.CSS_SELECTOR, sel)
                    title = title_elem.text.strip()
                    if title and len(title) > 3:
                        break
                except:
                    pass

            # Fallback - link text
            if not title:
                try:
                    link = element.find_element(By.CSS_SELECTOR, "a[href*='/itm/']")
                    title = link.text.strip()
                except:
                    pass

            if not title or title.lower() in ["shop on ebay", "schreiben sie uns", ""]:
                return None

            # Fiyat
            price = None
            price_selectors = [
                "[class*='price']",
                ".s-item__price",
                "span.s-card__price",
            ]
            for sel in price_selectors:
                try:
                    price_elem = element.find_element(By.CSS_SELECTOR, sel)
                    price_text = price_elem.text
                    price_match = re.search(r"EUR\s*([\d.,]+)|([\d.,]+)\s*EUR", price_text)
                    if price_match:
                        price_str = price_match.group(1) or price_match.group(2)
                        price = float(price_str.replace(".", "").replace(",", "."))
                        break
                except:
                    pass

            # Acik artirma fiyati (varsa)
            auction_price = None
            if listing_type in [self.LISTING_TYPE_AUCTION, self.LISTING_TYPE_HYBRID]:
                try:
                    bid_elem = element.find_element(By.CSS_SELECTOR, "[class*='bid'] + *")
                    bid_text = bid_elem.text
                    bid_match = re.search(r"EUR\s*([\d.,]+)|([\d.,]+)\s*EUR", bid_text)
                    if bid_match:
                        price_str = bid_match.group(1) or bid_match.group(2)
                        auction_price = float(price_str.replace(".", "").replace(",", "."))
                except:
                    pass

            # Resim
            image_url = None
            try:
                img = element.find_element(By.CSS_SELECTOR, "img.s-card__image, img")
                image_url = img.get_attribute("src")
            except:
                pass

            # Durum
            condition = None
            try:
                cond_elem = element.find_element(By.CSS_SELECTOR, ".SECONDARY_INFO, [class*='condition']")
                condition = cond_elem.text.strip()
            except:
                pass

            return {
                "url": base_url,
                "title": title[:200] if title else None,
                "price": price,
                "auction_price": auction_price,
                "condition": condition,
                "image": image_url,
                "platform": "ebay",
                "listing_type": listing_type,
                "is_auction": listing_type == self.LISTING_TYPE_AUCTION,
                "has_buy_now": listing_type in [self.LISTING_TYPE_BUY_NOW, self.LISTING_TYPE_HYBRID],
                "scraped_at": datetime.now().isoformat()
            }

        except Exception as e:
            self.log(f"Urun verisi cikarma hatasi: {e}", "debug")
            return None

    def extract_all_products(self, skip_auctions: bool = True) -> List[Dict]:
        """Sayfadaki tum urunleri cikar"""
        elements = self.get_product_elements()
        products = []
        skipped_auctions = 0

        for element in elements:
            product = self.extract_product_data(element, skip_auctions=skip_auctions)
            if product:
                if product["url"] not in [p["url"] for p in self.products_found]:
                    products.append(product)
                    self.products_found.append(product)
            elif skip_auctions:
                skipped_auctions += 1

        self.log(f"{len(products)} yeni urun cikarildi (Toplam: {len(self.products_found)})")
        if skipped_auctions > 0:
            self.log(f"{skipped_auctions} acik artirma ilani atlandi")
        return products

    def go_to_next_page(self) -> bool:
        """Sonraki sayfaya git"""
        try:
            next_selectors = [
                "a.pagination__next",
                "[aria-label='Naechste Seite']",
                ".pagination__item--next a",
            ]

            for selector in next_selectors:
                try:
                    next_btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                    if next_btn.is_displayed():
                        self.log("Sonraki sayfa butonuna tiklanıyor...")
                        self.human_click(next_btn)
                        self.random_delay(3, 5)
                        return True
                except:
                    pass

            return False
        except:
            return False

    def visit_random_product(self, visit_seller: bool = True) -> Optional[Dict]:
        """Rastgele bir urune git ve satici profilini ziyaret et"""
        elements = self.get_product_elements()
        if not elements:
            self.log("Urun elementi bulunamadi")
            return None

        random_elements = random.sample(elements[:min(10, len(elements))], 1)
        element = random_elements[0]

        product_data = self.extract_product_data(element, skip_auctions=False)
        if not product_data:
            return None

        self.log(f"=== RASTGELE URUN ZIYARETI ===")
        self.log(f"Urun: {product_data['title'][:50]}...")

        self.mouse_zigzag(element)
        self.random_delay(0.3, 0.6)

        self.visit_url(product_data["url"])
        self.random_delay(2, 4)
        self.screenshot("product_page")

        self.human_scroll("down", random.randint(200, 400))
        self.random_delay(1, 2)
        self.human_scroll("down", random.randint(100, 300))
        self.random_delay(0.5, 1.5)

        if visit_seller:
            self._visit_seller_profile()

        self.random_delay(1, 2)
        self.go_back()
        self.random_delay(1, 2)

        self.log(f"=== RASTGELE ZIYARET TAMAMLANDI ===")
        return product_data

    def _visit_seller_profile(self) -> bool:
        """eBay satici profilini ziyaret et"""
        seller_selectors = [
            "a[href*='/usr/']",
            "[data-testid='seller-link']",
            ".ux-seller-section__item a",
            ".seller-card a[href*='/usr/']",
            "[class*='seller'] a",
            ".x-sellercard-atf a",
            "a.seller-link",
        ]

        for selector in seller_selectors:
            try:
                links = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for link in links:
                    if link.is_displayed():
                        href = link.get_attribute("href") or ""
                        if "/usr/" in href or "seller" in href.lower():
                            self.log(f"Satici profiline gidiliyor: {href[:50]}...")
                            self.mouse_zigzag(link)
                            self.human_click(link)
                            self.random_delay(2, 4)
                            self.screenshot("seller_profile")
                            self.human_scroll("down", random.randint(300, 500))
                            self.random_delay(1, 3)

                            if random.random() < 0.5:
                                self.human_scroll("down", random.randint(200, 400))
                                self.random_delay(0.5, 1.5)

                            self.go_back()
                            self.random_delay(1, 2)
                            self.log("Satici profili ziyareti tamamlandi")
                            return True
            except Exception as e:
                self.log(f"Satici linki denemesi basarisiz: {e}", "debug")
                continue

        self.log("Satici profili bulunamadi", "debug")
        return False

    def scrape(self, query: str, max_products: int = None, max_pages: int = None,
               visit_products: bool = True, min_price: float = None,
               max_price: float = None, condition: str = None,
               conditions: list = None, sort: str = "newly_listed",
               skip_auctions: bool = True, buy_now_only: bool = False,
               **kwargs) -> List[Dict]:
        """
        Ana kazima fonksiyonu

        Args:
            query: Arama kelimesi
            max_products: Maksimum urun sayisi
            max_pages: Maksimum sayfa sayisi
            visit_products: Rastgele urunlere git
            min_price: Minimum fiyat
            max_price: Maximum fiyat
            condition: Durum filtresi
            conditions: Coklu durum listesi
            sort: Siralama
            skip_auctions: Acik artirma ilanlarini atla (default: True)
            buy_now_only: Sadece Sofort-Kaufen ilanlarini getir (default: False)
        """
        self.log(f"=== EBAY KAZIMA BASLIYOR ===")
        self.log(f"Arama: {query}")
        self.log(f"Max urun: {max_products or 'Sinirsiz'}")
        self.log(f"Max sayfa: {max_pages or 'Sinirsiz'}")
        self.log(f"Acik artirma atla: {skip_auctions}")
        self.log(f"Sadece Sofort-Kaufen: {buy_now_only}")

        # buy_now_only true ise skip_auctions da true
        if buy_now_only:
            skip_auctions = True

        # Durum filtresi cevir
        translated_condition = None
        if conditions and len(conditions) > 0:
            translated_condition = self.translate_condition(conditions[0])
            self.log(f"Durum filtresi: {conditions[0]} -> {translated_condition}")
        elif condition:
            translated_condition = self.translate_condition(condition)
            self.log(f"Durum filtresi: {condition} -> {translated_condition}")

        effective_condition = translated_condition or condition

        try:
            page = 1

            url = self.build_search_url(
                query=query,
                page=page,
                min_price=min_price,
                max_price=max_price,
                condition=effective_condition,
                sort=sort,
                buy_now_only=buy_now_only
            )

            self.log(f"--- Sayfa {page} ---")
            self.visit_url(url)
            self.close_cookie_banner()

            # Ilk sayfa gezinme
            self.log("=== ILK SAYFA RASTGELE GEZINME ===")
            self.human_scroll("down", random.randint(300, 500))
            self.random_delay(1, 2)

            self.log("Ilk sayfa: Rastgele urun ve satici profili ziyareti...")
            self.visit_random_product(visit_seller=True)

            while True:
                self.log(f"--- Sayfa {page} ---")

                self.human_scroll("down", random.randint(300, 500))
                self.random_delay(1, 2)

                if random.random() < 0.3:
                    try:
                        elements = self.get_product_elements()
                        if elements:
                            random_elem = random.choice(elements[:5])
                            self.mouse_zigzag(random_elem)
                    except:
                        pass

                before_count = len(self.products_found)
                self.extract_all_products(skip_auctions=skip_auctions)
                after_count = len(self.products_found)
                new_products = after_count - before_count

                self.log(f"+{new_products} yeni urun (Toplam: {after_count})")

                if max_products and len(self.products_found) >= max_products:
                    self.log(f"Maksimum urun sayisina ulasildi: {max_products}")
                    break

                if max_pages and page >= max_pages:
                    self.log(f"Maksimum sayfa sayisina ulasildi: {max_pages}")
                    break

                if new_products == 0:
                    self.log("Bos sayfa, kazima durduruluyor...")
                    break

                if visit_products and page > 1 and random.random() < 0.3:
                    self.visit_random_product(visit_seller=True)

                self.random_delay(2, 4)

                page += 1
                url = self.build_search_url(
                    query=query,
                    page=page,
                    min_price=min_price,
                    max_price=max_price,
                    condition=effective_condition,
                    sort=sort,
                    buy_now_only=buy_now_only
                )
                self.visit_url(url)
                self.random_delay(2, 3)

            self.log(f"=== EBAY KAZIMA TAMAMLANDI ===")
            self.log(f"Toplam urun: {len(self.products_found)}")

            # Istatistikler
            buy_now_count = len([p for p in self.products_found if p.get("has_buy_now")])
            auction_count = len([p for p in self.products_found if p.get("is_auction")])
            self.log(f"Sofort-Kaufen: {buy_now_count} | Acik Artirma: {auction_count}")

            self.screenshot("scraping_complete")

            return self.products_found

        except Exception as e:
            self.log(f"Kazima hatasi: {e}", "error")
            self.screenshot("error")
            raise


def run_ebay_scrape(query: str, max_products: int = None, headless: bool = True,
                    skip_auctions: bool = True) -> List[Dict]:
    """eBay kazima islemini calistir"""
    with EbayScraper(headless=headless) as scraper:
        return scraper.scrape(query, max_products=max_products, skip_auctions=skip_auctions)


if __name__ == "__main__":
    import sys

    query = sys.argv[1] if len(sys.argv) > 1 else "nike"
    max_items = int(sys.argv[2]) if len(sys.argv) > 2 else 50

    print(f"eBay kazima basliyor: {query}")
    products = run_ebay_scrape(query, max_products=max_items, headless=True, skip_auctions=True)

    print(f"\n{len(products)} urun bulundu:")
    for p in products[:5]:
        listing = "Sofort-Kaufen" if p.get("has_buy_now") else "Acik Artirma"
        print(f"  - {p['title'][:30]} | {p['price']} EUR | {listing}")
