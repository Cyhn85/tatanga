#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAPTCHA SOLVER - Automatic Captcha Solving Service Integration
Supports: 2captcha, anti-captcha, capsolver

Author: TATANGA Team
Version: 1.0
"""

import requests
import time
import base64
from typing import Optional, Dict, Any
from pathlib import Path
import sys

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from config.credentials import API_KEYS
except:
    API_KEYS = {}


class CaptchaSolver:
    """
    Universal captcha solver supporting multiple services

    Usage:
        solver = CaptchaSolver(service='2captcha', api_key='YOUR_KEY')

        # Solve image captcha
        result = solver.solve_image('base64_image_data')

        # Solve reCAPTCHA v2
        result = solver.solve_recaptcha_v2(site_key, page_url)

        # Solve hCaptcha
        result = solver.solve_hcaptcha(site_key, page_url)
    """

    SERVICES = {
        '2captcha': {
            'submit_url': 'http://2captcha.com/in.php',
            'result_url': 'http://2captcha.com/res.php',
            'balance_url': 'http://2captcha.com/res.php?action=getbalance'
        },
        'anti-captcha': {
            'submit_url': 'https://api.anti-captcha.com/createTask',
            'result_url': 'https://api.anti-captcha.com/getTaskResult',
            'balance_url': 'https://api.anti-captcha.com/getBalance'
        },
        'capsolver': {
            'submit_url': 'https://api.capsolver.com/createTask',
            'result_url': 'https://api.capsolver.com/getTaskResult',
            'balance_url': 'https://api.capsolver.com/getBalance'
        }
    }

    def __init__(
        self,
        service: str = '2captcha',
        api_key: str = None,
        timeout: int = 120,
        poll_interval: int = 5
    ):
        """
        Initialize captcha solver

        Args:
            service: Captcha service ('2captcha', 'anti-captcha', 'capsolver')
            api_key: API key for the service
            timeout: Max wait time for solution (seconds)
            poll_interval: Time between status checks (seconds)
        """
        self.service = service.lower()
        self.api_key = api_key or API_KEYS.get(f'{service}_api_key', '')
        self.timeout = timeout
        self.poll_interval = poll_interval

        if self.service not in self.SERVICES:
            raise ValueError(f"Unsupported service: {service}")

        self.urls = self.SERVICES[self.service]
        self.stats = {
            'solved': 0,
            'failed': 0,
            'total_time': 0
        }

    def get_balance(self) -> float:
        """Get account balance"""
        try:
            if self.service == '2captcha':
                response = requests.get(
                    self.urls['balance_url'],
                    params={'key': self.api_key}
                )
                return float(response.text)
            else:
                response = requests.post(
                    self.urls['balance_url'],
                    json={'clientKey': self.api_key}
                )
                data = response.json()
                return data.get('balance', 0)
        except Exception as e:
            print(f"[CAPTCHA] Balance check error: {e}")
            return -1

    def solve_image(self, image_data: str, **kwargs) -> Optional[str]:
        """
        Solve image-based captcha

        Args:
            image_data: Base64 encoded image or file path
            **kwargs: Additional options (case_sensitive, numeric, etc.)

        Returns:
            Captcha solution text or None
        """
        start_time = time.time()

        # Load image if path provided
        if not image_data.startswith('data:') and not image_data.startswith('/9j'):
            try:
                with open(image_data, 'rb') as f:
                    image_data = base64.b64encode(f.read()).decode()
            except:
                pass

        try:
            if self.service == '2captcha':
                return self._solve_2captcha_image(image_data, **kwargs)
            else:
                return self._solve_anticaptcha_image(image_data, **kwargs)
        finally:
            self.stats['total_time'] += time.time() - start_time

    def solve_recaptcha_v2(
        self,
        site_key: str,
        page_url: str,
        invisible: bool = False,
        data_s: str = None
    ) -> Optional[str]:
        """
        Solve reCAPTCHA v2

        Args:
            site_key: Google site key
            page_url: Page URL where captcha appears
            invisible: Is it invisible reCAPTCHA
            data_s: data-s parameter (optional)

        Returns:
            g-recaptcha-response token or None
        """
        start_time = time.time()

        try:
            if self.service == '2captcha':
                return self._solve_2captcha_recaptcha(site_key, page_url, invisible, data_s)
            else:
                return self._solve_anticaptcha_recaptcha(site_key, page_url, invisible)
        finally:
            self.stats['total_time'] += time.time() - start_time

    def solve_recaptcha_v3(
        self,
        site_key: str,
        page_url: str,
        action: str = 'verify',
        min_score: float = 0.3
    ) -> Optional[str]:
        """
        Solve reCAPTCHA v3

        Args:
            site_key: Google site key
            page_url: Page URL
            action: Action name
            min_score: Minimum score required

        Returns:
            g-recaptcha-response token or None
        """
        start_time = time.time()

        try:
            if self.service == '2captcha':
                params = {
                    'key': self.api_key,
                    'method': 'userrecaptcha',
                    'googlekey': site_key,
                    'pageurl': page_url,
                    'version': 'v3',
                    'action': action,
                    'min_score': min_score,
                    'json': 1
                }
                response = requests.post(self.urls['submit_url'], data=params)
                data = response.json()

                if data.get('status') == 1:
                    task_id = data['request']
                    return self._wait_for_result_2captcha(task_id)
            else:
                task = {
                    'type': 'RecaptchaV3TaskProxyless',
                    'websiteURL': page_url,
                    'websiteKey': site_key,
                    'minScore': min_score,
                    'pageAction': action
                }
                return self._submit_anticaptcha_task(task)
        finally:
            self.stats['total_time'] += time.time() - start_time

        return None

    def solve_hcaptcha(
        self,
        site_key: str,
        page_url: str,
        invisible: bool = False
    ) -> Optional[str]:
        """
        Solve hCaptcha

        Args:
            site_key: hCaptcha site key
            page_url: Page URL
            invisible: Is it invisible hCaptcha

        Returns:
            h-captcha-response token or None
        """
        start_time = time.time()

        try:
            if self.service == '2captcha':
                params = {
                    'key': self.api_key,
                    'method': 'hcaptcha',
                    'sitekey': site_key,
                    'pageurl': page_url,
                    'invisible': 1 if invisible else 0,
                    'json': 1
                }
                response = requests.post(self.urls['submit_url'], data=params)
                data = response.json()

                if data.get('status') == 1:
                    task_id = data['request']
                    return self._wait_for_result_2captcha(task_id)
            else:
                task = {
                    'type': 'HCaptchaTaskProxyless',
                    'websiteURL': page_url,
                    'websiteKey': site_key,
                    'isInvisible': invisible
                }
                return self._submit_anticaptcha_task(task)
        finally:
            self.stats['total_time'] += time.time() - start_time

        return None

    def solve_turnstile(
        self,
        site_key: str,
        page_url: str
    ) -> Optional[str]:
        """
        Solve Cloudflare Turnstile

        Args:
            site_key: Turnstile site key
            page_url: Page URL

        Returns:
            cf-turnstile-response token or None
        """
        start_time = time.time()

        try:
            if self.service == '2captcha':
                params = {
                    'key': self.api_key,
                    'method': 'turnstile',
                    'sitekey': site_key,
                    'pageurl': page_url,
                    'json': 1
                }
                response = requests.post(self.urls['submit_url'], data=params)
                data = response.json()

                if data.get('status') == 1:
                    task_id = data['request']
                    return self._wait_for_result_2captcha(task_id)
            else:
                task = {
                    'type': 'TurnstileTaskProxyless',
                    'websiteURL': page_url,
                    'websiteKey': site_key
                }
                return self._submit_anticaptcha_task(task)
        finally:
            self.stats['total_time'] += time.time() - start_time

        return None

    # ========== 2CAPTCHA Methods ==========

    def _solve_2captcha_image(self, image_data: str, **kwargs) -> Optional[str]:
        """Solve image captcha via 2captcha"""
        params = {
            'key': self.api_key,
            'method': 'base64',
            'body': image_data,
            'json': 1
        }

        # Add optional params
        if kwargs.get('case_sensitive'):
            params['regsense'] = 1
        if kwargs.get('numeric'):
            params['numeric'] = kwargs['numeric']
        if kwargs.get('min_length'):
            params['min_len'] = kwargs['min_length']
        if kwargs.get('max_length'):
            params['max_len'] = kwargs['max_length']

        response = requests.post(self.urls['submit_url'], data=params)
        data = response.json()

        if data.get('status') == 1:
            task_id = data['request']
            return self._wait_for_result_2captcha(task_id)

        print(f"[CAPTCHA] 2captcha submit error: {data}")
        self.stats['failed'] += 1
        return None

    def _solve_2captcha_recaptcha(
        self,
        site_key: str,
        page_url: str,
        invisible: bool,
        data_s: str
    ) -> Optional[str]:
        """Solve reCAPTCHA v2 via 2captcha"""
        params = {
            'key': self.api_key,
            'method': 'userrecaptcha',
            'googlekey': site_key,
            'pageurl': page_url,
            'invisible': 1 if invisible else 0,
            'json': 1
        }

        if data_s:
            params['data-s'] = data_s

        response = requests.post(self.urls['submit_url'], data=params)
        data = response.json()

        if data.get('status') == 1:
            task_id = data['request']
            return self._wait_for_result_2captcha(task_id)

        print(f"[CAPTCHA] 2captcha submit error: {data}")
        self.stats['failed'] += 1
        return None

    def _wait_for_result_2captcha(self, task_id: str) -> Optional[str]:
        """Wait for 2captcha result"""
        start = time.time()

        while time.time() - start < self.timeout:
            time.sleep(self.poll_interval)

            response = requests.get(
                self.urls['result_url'],
                params={
                    'key': self.api_key,
                    'action': 'get',
                    'id': task_id,
                    'json': 1
                }
            )
            data = response.json()

            if data.get('status') == 1:
                self.stats['solved'] += 1
                return data['request']
            elif data.get('request') == 'CAPCHA_NOT_READY':
                continue
            else:
                print(f"[CAPTCHA] 2captcha error: {data}")
                self.stats['failed'] += 1
                return None

        print("[CAPTCHA] Timeout waiting for solution")
        self.stats['failed'] += 1
        return None

    # ========== Anti-Captcha / Capsolver Methods ==========

    def _solve_anticaptcha_image(self, image_data: str, **kwargs) -> Optional[str]:
        """Solve image captcha via anti-captcha/capsolver"""
        task = {
            'type': 'ImageToTextTask',
            'body': image_data,
            'case': kwargs.get('case_sensitive', False),
        }

        if kwargs.get('numeric'):
            task['numeric'] = kwargs['numeric']

        return self._submit_anticaptcha_task(task)

    def _solve_anticaptcha_recaptcha(
        self,
        site_key: str,
        page_url: str,
        invisible: bool
    ) -> Optional[str]:
        """Solve reCAPTCHA via anti-captcha/capsolver"""
        task = {
            'type': 'RecaptchaV2TaskProxyless' if not invisible else 'RecaptchaV2EnterpriseTaskProxyless',
            'websiteURL': page_url,
            'websiteKey': site_key,
            'isInvisible': invisible
        }

        return self._submit_anticaptcha_task(task)

    def _submit_anticaptcha_task(self, task: Dict) -> Optional[str]:
        """Submit task to anti-captcha/capsolver"""
        payload = {
            'clientKey': self.api_key,
            'task': task
        }

        response = requests.post(self.urls['submit_url'], json=payload)
        data = response.json()

        if data.get('errorId') == 0:
            task_id = data['taskId']
            return self._wait_for_result_anticaptcha(task_id)

        print(f"[CAPTCHA] Submit error: {data}")
        self.stats['failed'] += 1
        return None

    def _wait_for_result_anticaptcha(self, task_id: str) -> Optional[str]:
        """Wait for anti-captcha/capsolver result"""
        start = time.time()

        while time.time() - start < self.timeout:
            time.sleep(self.poll_interval)

            payload = {
                'clientKey': self.api_key,
                'taskId': task_id
            }

            response = requests.post(self.urls['result_url'], json=payload)
            data = response.json()

            if data.get('status') == 'ready':
                self.stats['solved'] += 1
                solution = data.get('solution', {})
                return (
                    solution.get('gRecaptchaResponse') or
                    solution.get('token') or
                    solution.get('text')
                )
            elif data.get('status') == 'processing':
                continue
            else:
                print(f"[CAPTCHA] Error: {data}")
                self.stats['failed'] += 1
                return None

        print("[CAPTCHA] Timeout waiting for solution")
        self.stats['failed'] += 1
        return None

    def get_stats(self) -> Dict:
        """Get solver statistics"""
        return {
            **self.stats,
            'success_rate': (
                self.stats['solved'] / max(self.stats['solved'] + self.stats['failed'], 1)
            ) * 100
        }


class SeleniumCaptchaSolver:
    """
    Selenium integration for captcha solving

    Usage:
        solver = SeleniumCaptchaSolver(driver, captcha_solver)
        success = solver.solve_page_captcha()
    """

    def __init__(self, driver, solver: CaptchaSolver):
        self.driver = driver
        self.solver = solver

    def detect_captcha_type(self) -> Optional[str]:
        """Detect captcha type on current page"""
        page_source = self.driver.page_source.lower()

        if 'g-recaptcha' in page_source or 'recaptcha' in page_source:
            # Check for v3
            if 'grecaptcha.execute' in page_source:
                return 'recaptcha_v3'
            return 'recaptcha_v2'
        elif 'h-captcha' in page_source or 'hcaptcha' in page_source:
            return 'hcaptcha'
        elif 'cf-turnstile' in page_source or 'turnstile' in page_source:
            return 'turnstile'
        elif 'captcha' in page_source:
            return 'image'

        return None

    def get_site_key(self, captcha_type: str) -> Optional[str]:
        """Extract site key from page"""
        try:
            if captcha_type in ['recaptcha_v2', 'recaptcha_v3']:
                # Try data-sitekey attribute
                elem = self.driver.find_element('css selector', '[data-sitekey]')
                return elem.get_attribute('data-sitekey')
            elif captcha_type == 'hcaptcha':
                elem = self.driver.find_element('css selector', '[data-sitekey]')
                return elem.get_attribute('data-sitekey')
            elif captcha_type == 'turnstile':
                elem = self.driver.find_element('css selector', '[data-sitekey]')
                return elem.get_attribute('data-sitekey')
        except:
            pass

        return None

    def solve_page_captcha(self) -> bool:
        """
        Automatically detect and solve captcha on current page

        Returns:
            True if solved successfully, False otherwise
        """
        captcha_type = self.detect_captcha_type()

        if not captcha_type:
            print("[CAPTCHA] No captcha detected")
            return True

        print(f"[CAPTCHA] Detected: {captcha_type}")

        page_url = self.driver.current_url
        site_key = self.get_site_key(captcha_type)

        if not site_key and captcha_type != 'image':
            print("[CAPTCHA] Could not find site key")
            return False

        token = None

        if captcha_type == 'recaptcha_v2':
            token = self.solver.solve_recaptcha_v2(site_key, page_url)
        elif captcha_type == 'recaptcha_v3':
            token = self.solver.solve_recaptcha_v3(site_key, page_url)
        elif captcha_type == 'hcaptcha':
            token = self.solver.solve_hcaptcha(site_key, page_url)
        elif captcha_type == 'turnstile':
            token = self.solver.solve_turnstile(site_key, page_url)
        elif captcha_type == 'image':
            return self._solve_image_captcha()

        if token:
            return self._inject_token(token, captcha_type)

        return False

    def _solve_image_captcha(self) -> bool:
        """Solve image-based captcha"""
        try:
            # Find captcha image
            img = self.driver.find_element('css selector', 'img[src*="captcha"]')
            img_src = img.get_attribute('src')

            if img_src.startswith('data:'):
                # Base64 encoded
                image_data = img_src.split(',')[1]
            else:
                # Download image
                response = requests.get(img_src)
                image_data = base64.b64encode(response.content).decode()

            # Solve
            solution = self.solver.solve_image(image_data)

            if solution:
                # Find input field
                input_field = self.driver.find_element(
                    'css selector',
                    'input[name*="captcha"], input[id*="captcha"]'
                )
                input_field.clear()
                input_field.send_keys(solution)
                return True
        except Exception as e:
            print(f"[CAPTCHA] Image captcha error: {e}")

        return False

    def _inject_token(self, token: str, captcha_type: str) -> bool:
        """Inject solved token into page"""
        try:
            if captcha_type in ['recaptcha_v2', 'recaptcha_v3']:
                # Inject g-recaptcha-response
                self.driver.execute_script(f'''
                    document.getElementById("g-recaptcha-response").innerHTML = "{token}";
                    if (typeof ___grecaptcha_cfg !== 'undefined') {{
                        Object.keys(___grecaptcha_cfg.clients).forEach(function(key) {{
                            var client = ___grecaptcha_cfg.clients[key];
                            if (client.V && client.V.callback) {{
                                client.V.callback("{token}");
                            }}
                        }});
                    }}
                ''')
            elif captcha_type == 'hcaptcha':
                self.driver.execute_script(f'''
                    document.querySelector('[name="h-captcha-response"]').value = "{token}";
                    document.querySelector('[name="g-recaptcha-response"]').value = "{token}";
                ''')
            elif captcha_type == 'turnstile':
                self.driver.execute_script(f'''
                    document.querySelector('[name="cf-turnstile-response"]').value = "{token}";
                ''')

            print(f"[CAPTCHA] Token injected successfully")
            return True
        except Exception as e:
            print(f"[CAPTCHA] Token injection error: {e}")
            return False


# Convenience function
def create_solver(
    service: str = '2captcha',
    api_key: str = None
) -> CaptchaSolver:
    """Create captcha solver instance"""
    return CaptchaSolver(service=service, api_key=api_key)


if __name__ == '__main__':
    # Test
    print("Captcha Solver Module")
    print("=" * 40)

    # Check if API key exists
    solver = CaptchaSolver(service='2captcha')

    if solver.api_key:
        balance = solver.get_balance()
        print(f"2captcha balance: ${balance}")
    else:
        print("No API key configured")
        print("\nTo use captcha solving:")
        print("1. Get API key from 2captcha.com, anti-captcha.com, or capsolver.com")
        print("2. Add to config/credentials.py:")
        print("   API_KEYS = {'2captcha_api_key': 'YOUR_KEY'}")