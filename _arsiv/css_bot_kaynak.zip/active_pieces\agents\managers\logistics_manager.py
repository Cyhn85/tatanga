#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Logistics Manager
Manages shipping, carrier APIs, and delivery tracking

Features:
- Multi-carrier API integration (DHL, UPS, DPD, GLS, Hermes)
- Shipping cost calculation
- Label generation
- Package tracking
- Delivery time estimation

Author: TATANGA Team
Version: 1.0
"""

import sys
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from pathlib import Path
import sqlite3
import json
import aiohttp

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")


class LogisticsManager:
    """
    Logistics Manager - Handles all shipping and delivery operations

    Responsibilities:
    1. Calculate shipping costs across carriers
    2. Generate shipping labels
    3. Track shipments
    4. Estimate delivery times
    5. Manage carrier integrations
    """

    # Carrier configurations
    CARRIERS = {
        'dhl': {
            'name': 'DHL',
            'api_base': 'https://api.dhl.com',
            'tracking_url': 'https://www.dhl.com/en/express/tracking.html?AWB=',
            'countries': ['de', 'at', 'ch', 'nl', 'be', 'fr', 'es', 'it', 'pl', 'uk']
        },
        'ups': {
            'name': 'UPS',
            'api_base': 'https://onlinetools.ups.com',
            'tracking_url': 'https://www.ups.com/track?tracknum=',
            'countries': ['us', 'uk', 'de', 'fr', 'es', 'it', 'nl']
        },
        'dpd': {
            'name': 'DPD',
            'api_base': 'https://api.dpd.com',
            'tracking_url': 'https://tracking.dpd.de/parcelstatus?query=',
            'countries': ['de', 'at', 'ch', 'nl', 'be', 'fr', 'pl', 'cz']
        },
        'gls': {
            'name': 'GLS',
            'api_base': 'https://api.gls-group.eu',
            'tracking_url': 'https://gls-group.eu/track/',
            'countries': ['de', 'at', 'nl', 'be', 'dk', 'se', 'no', 'fi']
        },
        'hermes': {
            'name': 'Hermes',
            'api_base': 'https://api.myhermes.co.uk',
            'tracking_url': 'https://www.myhermes.co.uk/tracking-results.html?trackingId=',
            'countries': ['de', 'uk', 'at']
        },
        'post_de': {
            'name': 'Deutsche Post',
            'api_base': 'https://api.deutschepost.de',
            'tracking_url': 'https://www.deutschepost.de/sendung/',
            'countries': ['de']
        },
        'post_at': {
            'name': 'Österreichische Post',
            'api_base': 'https://api.post.at',
            'tracking_url': 'https://www.post.at/sv/sendungssuche?snr=',
            'countries': ['at']
        },
        'la_poste': {
            'name': 'La Poste',
            'api_base': 'https://api.laposte.fr',
            'tracking_url': 'https://www.laposte.fr/outils/suivre-vos-envois?code=',
            'countries': ['fr']
        },
        'postnl': {
            'name': 'PostNL',
            'api_base': 'https://api.postnl.nl',
            'tracking_url': 'https://postnl.nl/tracktrace/?B=',
            'countries': ['nl', 'be']
        },
        'postnord': {
            'name': 'PostNord',
            'api_base': 'https://api.postnord.com',
            'tracking_url': 'https://tracking.postnord.com/?id=',
            'countries': ['se', 'dk', 'no', 'fi']
        }
    }

    # Base shipping rates (EUR) - simplified
    BASE_RATES = {
        'domestic': {
            'small': 4.99,   # up to 500g
            'medium': 6.99,  # 500g - 2kg
            'large': 9.99,   # 2kg - 5kg
            'xl': 14.99      # 5kg+
        },
        'eu': {
            'small': 8.99,
            'medium': 12.99,
            'large': 18.99,
            'xl': 29.99
        },
        'international': {
            'small': 15.99,
            'medium': 24.99,
            'large': 39.99,
            'xl': 59.99
        }
    }

    # Weight categories
    WEIGHT_CATEGORIES = {
        'small': 500,     # grams
        'medium': 2000,
        'large': 5000,
        'xl': float('inf')
    }

    def __init__(self, ceo_agent):
        """
        Initialize Logistics Manager

        Args:
            ceo_agent: Reference to CEO Agent
        """
        self.ceo = ceo_agent
        self.logger = ModuleLogger("logistics_manager")

        # Database
        self.db_path = Path(__file__).parent.parent.parent / 'storage' / 'logistics.db'
        self._init_database()

        # Carrier API clients
        self.carrier_clients: Dict[str, Any] = {}

        # Statistics
        self.stats = {
            'shipments_created': 0,
            'labels_generated': 0,
            'total_shipping_cost': 0.0
        }

        self.logger.info("Logistics Manager initialized")

    def _init_database(self):
        """Initialize logistics database"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Shipments table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS shipments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id TEXT,
                carrier TEXT NOT NULL,
                tracking_number TEXT,
                sender_name TEXT,
                sender_address TEXT,
                sender_city TEXT,
                sender_country TEXT,
                recipient_name TEXT,
                recipient_address TEXT,
                recipient_city TEXT,
                recipient_country TEXT,
                weight_grams INTEGER,
                dimensions TEXT,
                shipping_cost REAL,
                currency TEXT DEFAULT 'EUR',
                status TEXT DEFAULT 'created',
                label_url TEXT,
                estimated_delivery DATE,
                actual_delivery DATE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME
            )
        """)

        # Tracking history
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tracking_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                shipment_id INTEGER NOT NULL,
                status TEXT NOT NULL,
                location TEXT,
                description TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (shipment_id) REFERENCES shipments(id)
            )
        """)

        # Carrier credentials (encrypted in production)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS carrier_credentials (
                carrier TEXT PRIMARY KEY,
                api_key TEXT,
                api_secret TEXT,
                account_number TEXT,
                is_active BOOLEAN DEFAULT 1,
                last_used DATETIME
            )
        """)

        conn.commit()
        conn.close()

    # ==================== SHIPPING CALCULATION ====================

    async def calculate_shipping(self,
                                 origin_country: str,
                                 destination_country: str,
                                 weight_grams: int,
                                 dimensions: Dict = None) -> Dict:
        """
        Calculate shipping costs across all available carriers

        Args:
            origin_country: Origin country code
            destination_country: Destination country code
            weight_grams: Package weight in grams
            dimensions: Package dimensions (optional)

        Returns:
            Shipping quotes from all carriers
        """
        self.logger.info(f"Calculating shipping: {origin_country} -> {destination_country}, {weight_grams}g")

        # Determine shipping zone
        zone = self._get_shipping_zone(origin_country, destination_country)

        # Get weight category
        weight_category = self._get_weight_category(weight_grams)

        # Get base rate
        base_rate = self.BASE_RATES.get(zone, self.BASE_RATES['international']).get(
            weight_category, self.BASE_RATES['international']['xl']
        )

        # Get available carriers for route
        available_carriers = self._get_available_carriers(origin_country, destination_country)

        quotes = []
        for carrier_id in available_carriers:
            carrier = self.CARRIERS[carrier_id]

            # Calculate carrier-specific rate (simplified - real API would be used)
            rate = base_rate * self._get_carrier_multiplier(carrier_id)

            # Estimate delivery time
            delivery_days = self._estimate_delivery_days(zone, carrier_id)

            quotes.append({
                'carrier': carrier_id,
                'carrier_name': carrier['name'],
                'price': round(rate, 2),
                'currency': 'EUR',
                'delivery_days': delivery_days,
                'tracking_available': True,
                'tracking_url_template': carrier['tracking_url']
            })

        # Sort by price
        quotes.sort(key=lambda x: x['price'])

        return {
            'origin': origin_country,
            'destination': destination_country,
            'weight_grams': weight_grams,
            'zone': zone,
            'cheapest': quotes[0] if quotes else None,
            'fastest': min(quotes, key=lambda x: x['delivery_days']) if quotes else None,
            'all_quotes': quotes
        }

    def _get_shipping_zone(self, origin: str, destination: str) -> str:
        """Determine shipping zone"""
        if origin == destination:
            return 'domestic'

        eu_countries = {'de', 'fr', 'es', 'it', 'nl', 'be', 'at', 'pl', 'cz', 'dk', 'se', 'no', 'fi'}

        if origin in eu_countries and destination in eu_countries:
            return 'eu'

        return 'international'

    def _get_weight_category(self, weight_grams: int) -> str:
        """Get weight category"""
        for category, max_weight in self.WEIGHT_CATEGORIES.items():
            if weight_grams <= max_weight:
                return category
        return 'xl'

    def _get_available_carriers(self, origin: str, destination: str) -> List[str]:
        """Get carriers available for route"""
        available = []
        for carrier_id, carrier in self.CARRIERS.items():
            if origin in carrier['countries'] or destination in carrier['countries']:
                available.append(carrier_id)
        return available if available else ['dhl']  # Default to DHL

    def _get_carrier_multiplier(self, carrier_id: str) -> float:
        """Get price multiplier for carrier"""
        multipliers = {
            'dhl': 1.0,
            'ups': 1.1,
            'dpd': 0.95,
            'gls': 0.9,
            'hermes': 0.85,
            'post_de': 0.8,
            'postnl': 0.9,
            'postnord': 0.95
        }
        return multipliers.get(carrier_id, 1.0)

    def _estimate_delivery_days(self, zone: str, carrier_id: str) -> int:
        """Estimate delivery time in days"""
        base_days = {
            'domestic': 2,
            'eu': 4,
            'international': 7
        }

        carrier_speed = {
            'dhl': -1,  # Faster
            'ups': -1,
            'dpd': 0,
            'gls': 0,
            'hermes': 1,  # Slower
            'post_de': 1
        }

        base = base_days.get(zone, 7)
        adjustment = carrier_speed.get(carrier_id, 0)

        return max(1, base + adjustment)

    # ==================== SHIPMENT CREATION ====================

    async def create_shipment(self, shipment_data: Dict) -> Dict:
        """
        Create a new shipment

        Args:
            shipment_data: Shipment details

        Returns:
            Created shipment info
        """
        self.logger.info(f"Creating shipment to {shipment_data.get('recipient_country')}")

        try:
            # Calculate shipping if not provided
            if not shipment_data.get('shipping_cost'):
                quote = await self.calculate_shipping(
                    origin_country=shipment_data.get('sender_country', 'de'),
                    destination_country=shipment_data.get('recipient_country', 'de'),
                    weight_grams=shipment_data.get('weight_grams', 500)
                )
                shipment_data['shipping_cost'] = quote['cheapest']['price'] if quote['cheapest'] else 10.0
                shipment_data['carrier'] = quote['cheapest']['carrier'] if quote['cheapest'] else 'dhl'

            # Save to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO shipments
                (order_id, carrier, sender_name, sender_address, sender_city, sender_country,
                 recipient_name, recipient_address, recipient_city, recipient_country,
                 weight_grams, dimensions, shipping_cost, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'created')
            """, (
                shipment_data.get('order_id'),
                shipment_data.get('carrier', 'dhl'),
                shipment_data.get('sender_name'),
                shipment_data.get('sender_address'),
                shipment_data.get('sender_city'),
                shipment_data.get('sender_country'),
                shipment_data.get('recipient_name'),
                shipment_data.get('recipient_address'),
                shipment_data.get('recipient_city'),
                shipment_data.get('recipient_country'),
                shipment_data.get('weight_grams'),
                json.dumps(shipment_data.get('dimensions')),
                shipment_data.get('shipping_cost')
            ))

            shipment_id = cursor.lastrowid
            conn.commit()
            conn.close()

            # Update stats
            self.stats['shipments_created'] += 1
            self.stats['total_shipping_cost'] += shipment_data.get('shipping_cost', 0)
            self.ceo.metrics.shipments_created += 1

            return {
                'success': True,
                'shipment_id': shipment_id,
                'carrier': shipment_data.get('carrier'),
                'shipping_cost': shipment_data.get('shipping_cost')
            }

        except Exception as e:
            self.logger.error("Failed to create shipment", exception=str(e))
            return {'success': False, 'error': str(e)}

    async def generate_label(self, shipment_id: int) -> Dict:
        """
        Generate shipping label for a shipment

        Args:
            shipment_id: Shipment database ID

        Returns:
            Label generation result
        """
        try:
            # Get shipment details
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM shipments WHERE id = ?", (shipment_id,))
            shipment = dict(cursor.fetchone())
            conn.close()

            if not shipment:
                return {'success': False, 'error': 'Shipment not found'}

            carrier = shipment.get('carrier')

            # In production, this would call the carrier API
            # For now, generate a mock tracking number
            tracking_number = f"{carrier.upper()}-{datetime.now().strftime('%Y%m%d')}-{shipment_id:06d}"

            # Update shipment with tracking number
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE shipments
                SET tracking_number = ?, status = 'label_created', updated_at = ?
                WHERE id = ?
            """, (tracking_number, datetime.now().isoformat(), shipment_id))
            conn.commit()
            conn.close()

            self.stats['labels_generated'] += 1

            # Get tracking URL
            tracking_url = self.CARRIERS[carrier]['tracking_url'] + tracking_number

            return {
                'success': True,
                'shipment_id': shipment_id,
                'tracking_number': tracking_number,
                'tracking_url': tracking_url,
                'carrier': carrier
            }

        except Exception as e:
            self.logger.error("Failed to generate label", exception=str(e))
            return {'success': False, 'error': str(e)}

    # ==================== TRACKING ====================

    async def track_shipment(self, tracking_number: str, carrier: str = None) -> Dict:
        """
        Track a shipment

        Args:
            tracking_number: Tracking number
            carrier: Carrier (optional, auto-detect)

        Returns:
            Tracking status
        """
        self.logger.info(f"Tracking shipment: {tracking_number}")

        try:
            # Try to find in database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            cursor.execute(
                "SELECT * FROM shipments WHERE tracking_number = ?",
                (tracking_number,)
            )
            shipment = cursor.fetchone()

            if shipment:
                shipment = dict(shipment)
                carrier = carrier or shipment.get('carrier')

                # Get tracking history
                cursor.execute("""
                    SELECT * FROM tracking_history
                    WHERE shipment_id = ?
                    ORDER BY timestamp DESC
                """, (shipment['id'],))
                history = [dict(row) for row in cursor.fetchall()]

                conn.close()

                return {
                    'success': True,
                    'tracking_number': tracking_number,
                    'carrier': carrier,
                    'status': shipment.get('status'),
                    'estimated_delivery': shipment.get('estimated_delivery'),
                    'history': history,
                    'tracking_url': self.CARRIERS.get(carrier, {}).get('tracking_url', '') + tracking_number
                }

            conn.close()

            # If not in database, would call carrier API
            return {
                'success': False,
                'error': 'Shipment not found in local database'
            }

        except Exception as e:
            self.logger.error("Failed to track shipment", exception=str(e))
            return {'success': False, 'error': str(e)}

    async def update_tracking_status(self, shipment_id: int, status: str, location: str = None, description: str = None):
        """Update shipment tracking status"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            # Update shipment status
            cursor.execute("""
                UPDATE shipments SET status = ?, updated_at = ? WHERE id = ?
            """, (status, datetime.now().isoformat(), shipment_id))

            # Add to tracking history
            cursor.execute("""
                INSERT INTO tracking_history (shipment_id, status, location, description)
                VALUES (?, ?, ?, ?)
            """, (shipment_id, status, location, description))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error("Failed to update tracking status", exception=str(e))

    # ==================== REPORTS ====================

    async def get_active_shipments(self) -> List[Dict]:
        """Get all active shipments"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            cursor.execute("""
                SELECT * FROM shipments
                WHERE status NOT IN ('delivered', 'cancelled')
                ORDER BY created_at DESC
            """)

            rows = cursor.fetchall()
            conn.close()

            return [dict(row) for row in rows]

        except Exception as e:
            self.logger.error("Failed to get active shipments", exception=str(e))
            return []

    # ==================== STATUS ====================

    def get_status(self) -> Dict:
        """Get manager status"""
        return {
            'status': 'healthy',
            'stats': self.stats,
            'carriers_available': list(self.CARRIERS.keys())
        }


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("LOGISTICS MANAGER TEST")
    print("=" * 60)

    class MockCEO:
        class metrics:
            shipments_created = 0

    async def test():
        ceo = MockCEO()
        manager = LogisticsManager(ceo)

        # Test shipping calculation
        print("\nCalculating shipping DE -> FR, 1500g...")
        quote = await manager.calculate_shipping('de', 'fr', 1500)

        print(f"Zone: {quote['zone']}")
        print(f"Cheapest: {quote['cheapest']['carrier_name']} - €{quote['cheapest']['price']}")
        print(f"Fastest: {quote['fastest']['carrier_name']} - {quote['fastest']['delivery_days']} days")

        print(f"\nAll quotes:")
        for q in quote['all_quotes']:
            print(f"  {q['carrier_name']}: €{q['price']} ({q['delivery_days']} days)")

        print(f"\nStatus: {manager.get_status()}")
        print("\n✅ Logistics Manager test complete!")

    asyncio.run(test())
    print("=" * 60)
