#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PLATFORM AGENT - External Platform Events Monitor
24/7 monitoring of platform events for tracked items

Features:
- Price change detection
- Stock/availability monitoring
- New listing alerts (keyword-based)
- Favorite item tracking
- Seller activity monitoring
- Telegram notifications

Author: TATANGA Team
Version: 1.0
"""

import sys
import json
import sqlite3
import asyncio
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents.base_agent import BaseAgent, AgentConfig


class EventType(Enum):
    """Types of platform events"""
    PRICE_DROP = "price_drop"
    PRICE_INCREASE = "price_increase"
    SOLD_OUT = "sold_out"
    BACK_IN_STOCK = "back_in_stock"
    NEW_LISTING = "new_listing"
    SELLER_ACTIVE = "seller_active"
    LISTING_UPDATED = "listing_updated"
    LISTING_DELETED = "listing_deleted"


@dataclass
class TrackedItem:
    """Represents a tracked item"""
    id: int
    platform: str
    url: str
    title: str
    current_price: float
    original_price: float
    seller_id: str
    is_available: bool = True
    last_checked: Optional[datetime] = None
    price_history: List[Dict] = field(default_factory=list)


@dataclass
class KeywordAlert:
    """Keyword alert configuration"""
    id: int
    keyword: str
    platforms: List[str]
    max_price: Optional[float] = None
    category: Optional[str] = None
    is_active: bool = True


class PlatformAgent(BaseAgent):
    """
    24/7 Platform Events Monitor

    Monitors external platforms for:
    - Price changes on tracked items
    - Availability changes (sold out / back in stock)
    - New listings matching keywords
    - Seller activity

    Usage:
        agent = PlatformAgent(interval_seconds=900)  # 15 minutes
        agent.start()

        # Track an item
        agent.track_item('https://vinted.de/items/123', 49.99)

        # Add keyword alert
        agent.add_keyword_alert('leather jacket', ['vinted_de', 'ebay_de'], max_price=100)

        # Stop agent
        agent.stop()
    """

    # Significant price change thresholds
    PRICE_DROP_THRESHOLD = 10  # 10% price drop triggers alert
    PRICE_INCREASE_THRESHOLD = 20  # 20% price increase triggers alert

    def __init__(self, interval_seconds: int = 900):
        """
        Initialize Platform Agent

        Args:
            interval_seconds: How often to check platforms (default 15 min)
        """
        config = AgentConfig(
            name="platform",
            interval_seconds=interval_seconds,
            max_retries=3,
            retry_delay_seconds=30
        )
        super().__init__(config)

        # Events database
        self.events_db = Path(__file__).parent.parent / 'storage' / 'platform_events.db'
        self._init_events_db()

        # Stats
        self.events_detected = 0
        self.items_checked = 0

    def _init_events_db(self):
        """Initialize platform events database"""
        self.events_db.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        # Tracked items table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tracked_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                url TEXT UNIQUE NOT NULL,
                title TEXT,
                current_price REAL,
                original_price REAL,
                seller_id TEXT,
                seller_name TEXT,
                is_available INTEGER DEFAULT 1,
                is_favorite INTEGER DEFAULT 0,
                product_id INTEGER,
                last_checked DATETIME,
                last_price_change DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Price history table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tracked_item_id INTEGER NOT NULL,
                price REAL NOT NULL,
                recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (tracked_item_id) REFERENCES tracked_items(id)
            )
        """)

        # Keyword alerts table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS keyword_alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                keyword TEXT NOT NULL,
                platforms TEXT NOT NULL,
                max_price REAL,
                min_price REAL,
                category TEXT,
                brand TEXT,
                is_active INTEGER DEFAULT 1,
                last_triggered DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Platform events table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS platform_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT NOT NULL,
                platform TEXT NOT NULL,
                item_url TEXT,
                item_title TEXT,
                old_value TEXT,
                new_value TEXT,
                details TEXT,
                notified_telegram INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Indexes
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_tracked_items_platform
            ON tracked_items(platform, is_available)
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_events_type_time
            ON platform_events(event_type, created_at)
        """)

        conn.commit()
        conn.close()

    async def setup(self):
        """Setup hook - called before first process"""
        self.logger.info("Platform Agent starting up")

        # Count tracked items
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM tracked_items WHERE is_available = 1")
        tracked_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM keyword_alerts WHERE is_active = 1")
        alerts_count = cursor.fetchone()[0]
        conn.close()

        self.logger.info(f"Tracking {tracked_count} items, {alerts_count} keyword alerts")

    async def process(self) -> Dict[str, Any]:
        """
        Main processing loop - check all tracked items and keyword alerts

        Returns:
            Processing result summary
        """
        results = {
            'items_checked': 0,
            'price_changes': 0,
            'availability_changes': 0,
            'new_listings': 0,
            'events_created': 0
        }

        # Check tracked items for price/availability changes
        tracked_items = self._get_tracked_items()

        if tracked_items:
            self.logger.info(f"Checking {len(tracked_items)} tracked items")

            for item in tracked_items:
                try:
                    events = await self._check_item(item)
                    results['items_checked'] += 1
                    self.items_checked += 1

                    for event in events:
                        if event['type'] in [EventType.PRICE_DROP.value, EventType.PRICE_INCREASE.value]:
                            results['price_changes'] += 1
                        elif event['type'] in [EventType.SOLD_OUT.value, EventType.BACK_IN_STOCK.value]:
                            results['availability_changes'] += 1

                        results['events_created'] += 1
                        self.events_detected += 1

                except Exception as e:
                    self.logger.error(f"Item check error ({item['url'][:50]}): {e}")

        # Check keyword alerts for new listings
        keyword_alerts = self._get_keyword_alerts()

        if keyword_alerts:
            self.logger.info(f"Checking {len(keyword_alerts)} keyword alerts")

            for alert in keyword_alerts:
                try:
                    new_listings = await self._check_keyword_alert(alert)
                    results['new_listings'] += len(new_listings)
                    results['events_created'] += len(new_listings)
                    self.events_detected += len(new_listings)

                except Exception as e:
                    self.logger.error(f"Keyword alert error ({alert['keyword']}): {e}")

        results['total_events'] = self.events_detected
        results['total_items_checked'] = self.items_checked

        return results

    async def _check_item(self, item: Dict) -> List[Dict]:
        """
        Check a tracked item for changes

        Args:
            item: Tracked item data

        Returns:
            List of detected events
        """
        events = []

        # TODO: Implement actual scraping to get current state
        # For now, simulate by checking database

        # Simulate getting current price (in real implementation, scrape the URL)
        current_price = item['current_price']
        is_available = item['is_available']

        # Check for price change
        if item['original_price'] and current_price:
            price_change_percent = ((current_price - item['original_price']) / item['original_price']) * 100

            if price_change_percent <= -self.PRICE_DROP_THRESHOLD:
                event = await self._create_event(
                    event_type=EventType.PRICE_DROP,
                    platform=item['platform'],
                    item_url=item['url'],
                    item_title=item['title'],
                    old_value=str(item['original_price']),
                    new_value=str(current_price),
                    details={'percent_change': round(price_change_percent, 1)}
                )
                events.append(event)

            elif price_change_percent >= self.PRICE_INCREASE_THRESHOLD:
                event = await self._create_event(
                    event_type=EventType.PRICE_INCREASE,
                    platform=item['platform'],
                    item_url=item['url'],
                    item_title=item['title'],
                    old_value=str(item['original_price']),
                    new_value=str(current_price),
                    details={'percent_change': round(price_change_percent, 1)}
                )
                events.append(event)

        # Update last checked
        self._update_item_checked(item['id'])

        return events

    async def _check_keyword_alert(self, alert: Dict) -> List[Dict]:
        """
        Check for new listings matching keyword alert

        Args:
            alert: Keyword alert configuration

        Returns:
            List of new listing events
        """
        events = []
        platforms = json.loads(alert['platforms'])

        # TODO: Implement actual search across platforms
        # For now, return empty list

        # Update last triggered
        if events:
            self._update_alert_triggered(alert['id'])

        return events

    async def _create_event(
        self,
        event_type: EventType,
        platform: str,
        item_url: str = None,
        item_title: str = None,
        old_value: str = None,
        new_value: str = None,
        details: Dict = None
    ) -> Dict:
        """Create and save a platform event"""
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO platform_events
            (event_type, platform, item_url, item_title, old_value, new_value, details)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            event_type.value, platform, item_url, item_title,
            old_value, new_value, json.dumps(details) if details else None
        ))

        event_id = cursor.lastrowid
        conn.commit()
        conn.close()

        event = {
            'id': event_id,
            'type': event_type.value,
            'platform': platform,
            'item_url': item_url,
            'item_title': item_title,
            'old_value': old_value,
            'new_value': new_value,
            'details': details
        }

        # Send Telegram notification
        await self._notify_event(event)

        return event

    async def _notify_event(self, event: Dict):
        """Send Telegram notification for event"""
        try:
            from integrations.telegram_bot import TatangaTelegramBot

            bot = TatangaTelegramBot()

            event_type = event['type']

            if event_type == EventType.PRICE_DROP.value:
                details = event.get('details', {})
                message = (
                    f"📉 *FİYAT DÜŞTÜ!*\n\n"
                    f"📱 Platform: `{event['platform']}`\n"
                    f"📦 Ürün: {event.get('item_title', 'N/A')[:50]}\n\n"
                    f"💰 Eski: €{event['old_value']}\n"
                    f"💚 Yeni: €{event['new_value']}\n"
                    f"📊 Düşüş: {abs(details.get('percent_change', 0))}%\n\n"
                    f"🔗 {event.get('item_url', 'N/A')}"
                )

            elif event_type == EventType.PRICE_INCREASE.value:
                details = event.get('details', {})
                message = (
                    f"📈 *FİYAT ARTTI*\n\n"
                    f"📱 Platform: `{event['platform']}`\n"
                    f"📦 Ürün: {event.get('item_title', 'N/A')[:50]}\n\n"
                    f"💰 Eski: €{event['old_value']}\n"
                    f"🔴 Yeni: €{event['new_value']}\n"
                    f"📊 Artış: {details.get('percent_change', 0)}%"
                )

            elif event_type == EventType.SOLD_OUT.value:
                message = (
                    f"❌ *SATILDI*\n\n"
                    f"📱 Platform: `{event['platform']}`\n"
                    f"📦 Ürün: {event.get('item_title', 'N/A')[:50]}\n\n"
                    f"Bu ürün artık mevcut değil."
                )

            elif event_type == EventType.BACK_IN_STOCK.value:
                message = (
                    f"✅ *TEKRAR MEVCUT!*\n\n"
                    f"📱 Platform: `{event['platform']}`\n"
                    f"📦 Ürün: {event.get('item_title', 'N/A')[:50]}\n\n"
                    f"💰 Fiyat: €{event.get('new_value', 'N/A')}"
                )

            elif event_type == EventType.NEW_LISTING.value:
                message = (
                    f"🆕 *YENİ İLAN!*\n\n"
                    f"📱 Platform: `{event['platform']}`\n"
                    f"📦 Ürün: {event.get('item_title', 'N/A')[:50]}\n"
                    f"💰 Fiyat: €{event.get('new_value', 'N/A')}\n\n"
                    f"🔗 {event.get('item_url', 'N/A')}"
                )

            else:
                message = (
                    f"🔔 *PLATFORM OLAYI*\n\n"
                    f"📱 Platform: `{event['platform']}`\n"
                    f"📌 Tür: {event_type}\n"
                    f"📦 Ürün: {event.get('item_title', 'N/A')[:50]}"
                )

            await bot.send_notification(message)

            # Mark as notified
            conn = sqlite3.connect(self.events_db)
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE platform_events SET notified_telegram = 1 WHERE id = ?",
                (event['id'],)
            )
            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error(f"Telegram notification failed: {e}")

    def _get_tracked_items(self) -> List[Dict]:
        """Get all tracked items"""
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, platform, url, title, current_price, original_price,
                   seller_id, is_available, last_checked
            FROM tracked_items
            WHERE is_available = 1 OR is_favorite = 1
            ORDER BY last_checked NULLS FIRST
            LIMIT 50
        """)

        items = [
            {
                'id': row[0],
                'platform': row[1],
                'url': row[2],
                'title': row[3],
                'current_price': row[4],
                'original_price': row[5],
                'seller_id': row[6],
                'is_available': row[7] == 1,
                'last_checked': row[8]
            }
            for row in cursor.fetchall()
        ]

        conn.close()
        return items

    def _get_keyword_alerts(self) -> List[Dict]:
        """Get active keyword alerts"""
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, keyword, platforms, max_price, min_price, category, brand
            FROM keyword_alerts
            WHERE is_active = 1
        """)

        alerts = [
            {
                'id': row[0],
                'keyword': row[1],
                'platforms': row[2],
                'max_price': row[3],
                'min_price': row[4],
                'category': row[5],
                'brand': row[6]
            }
            for row in cursor.fetchall()
        ]

        conn.close()
        return alerts

    def _update_item_checked(self, item_id: int):
        """Update last checked timestamp"""
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE tracked_items SET last_checked = datetime('now') WHERE id = ?",
            (item_id,)
        )
        conn.commit()
        conn.close()

    def _update_alert_triggered(self, alert_id: int):
        """Update last triggered timestamp"""
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE keyword_alerts SET last_triggered = datetime('now') WHERE id = ?",
            (alert_id,)
        )
        conn.commit()
        conn.close()

    # ========================================================================
    # PUBLIC API - Item Tracking
    # ========================================================================

    def track_item(
        self,
        url: str,
        price: float,
        title: str = None,
        platform: str = None,
        seller_id: str = None,
        is_favorite: bool = False,
        product_id: int = None
    ) -> int:
        """
        Start tracking an item for price/availability changes

        Args:
            url: Item URL
            price: Current price
            title: Item title
            platform: Platform (auto-detected if not provided)
            seller_id: Seller ID
            is_favorite: Mark as favorite (always track even if sold)
            product_id: Related product ID in database

        Returns:
            Tracked item ID
        """
        # Auto-detect platform from URL
        if not platform:
            platform = self._detect_platform(url)

        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT OR REPLACE INTO tracked_items
            (url, platform, title, current_price, original_price, seller_id,
             is_favorite, product_id, is_available)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
        """, (url, platform, title, price, price, seller_id, 1 if is_favorite else 0, product_id))

        item_id = cursor.lastrowid

        # Record initial price
        cursor.execute("""
            INSERT INTO price_history (tracked_item_id, price)
            VALUES (?, ?)
        """, (item_id, price))

        conn.commit()
        conn.close()

        self.logger.info(f"Now tracking: {title or url[:50]} @ €{price}")
        return item_id

    def untrack_item(self, url: str) -> bool:
        """Stop tracking an item"""
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        cursor.execute(
            "DELETE FROM tracked_items WHERE url = ?",
            (url,)
        )

        affected = cursor.rowcount
        conn.commit()
        conn.close()

        return affected > 0

    def update_item_price(self, url: str, new_price: float):
        """Update tracked item price and check for changes"""
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        # Get current item
        cursor.execute(
            "SELECT id, current_price, original_price, title, platform FROM tracked_items WHERE url = ?",
            (url,)
        )
        row = cursor.fetchone()

        if not row:
            conn.close()
            return

        item_id, old_price, original_price, title, platform = row

        # Update price
        cursor.execute("""
            UPDATE tracked_items
            SET current_price = ?, last_price_change = datetime('now')
            WHERE id = ?
        """, (new_price, item_id))

        # Record in history
        cursor.execute("""
            INSERT INTO price_history (tracked_item_id, price)
            VALUES (?, ?)
        """, (item_id, new_price))

        conn.commit()
        conn.close()

        # Check for significant change
        if old_price and new_price != old_price:
            change_percent = ((new_price - old_price) / old_price) * 100

            if change_percent <= -self.PRICE_DROP_THRESHOLD:
                asyncio.create_task(self._create_event(
                    event_type=EventType.PRICE_DROP,
                    platform=platform,
                    item_url=url,
                    item_title=title,
                    old_value=str(old_price),
                    new_value=str(new_price),
                    details={'percent_change': round(change_percent, 1)}
                ))

    def mark_item_sold(self, url: str):
        """Mark an item as sold/unavailable"""
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        cursor.execute(
            "UPDATE tracked_items SET is_available = 0 WHERE url = ?",
            (url,)
        )

        cursor.execute(
            "SELECT title, platform FROM tracked_items WHERE url = ?",
            (url,)
        )
        row = cursor.fetchone()

        conn.commit()
        conn.close()

        if row:
            asyncio.create_task(self._create_event(
                event_type=EventType.SOLD_OUT,
                platform=row[1],
                item_url=url,
                item_title=row[0]
            ))

    def _detect_platform(self, url: str) -> str:
        """Detect platform from URL"""
        url_lower = url.lower()

        if 'vinted.de' in url_lower:
            return 'vinted_de'
        elif 'vinted.fr' in url_lower:
            return 'vinted_fr'
        elif 'vinted.co.uk' in url_lower:
            return 'vinted_uk'
        elif 'ebay.de' in url_lower:
            return 'ebay_de'
        elif 'ebay.co.uk' in url_lower:
            return 'ebay_uk'
        elif 'kleinanzeigen' in url_lower:
            return 'kleinanzeigen'
        elif 'tradera' in url_lower:
            return 'tradera'
        elif 'leboncoin' in url_lower:
            return 'leboncoin'
        elif 'willhaben' in url_lower:
            return 'willhaben'
        elif 'finn.no' in url_lower:
            return 'finn_no'
        elif 'blocket' in url_lower:
            return 'blocket_se'

        return 'unknown'

    # ========================================================================
    # PUBLIC API - Keyword Alerts
    # ========================================================================

    def add_keyword_alert(
        self,
        keyword: str,
        platforms: List[str],
        max_price: float = None,
        min_price: float = None,
        category: str = None,
        brand: str = None
    ) -> int:
        """
        Add a keyword alert for new listings

        Args:
            keyword: Search keyword
            platforms: List of platforms to search
            max_price: Maximum price filter
            min_price: Minimum price filter
            category: Category filter
            brand: Brand filter

        Returns:
            Alert ID
        """
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO keyword_alerts
            (keyword, platforms, max_price, min_price, category, brand)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (keyword, json.dumps(platforms), max_price, min_price, category, brand))

        alert_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Added keyword alert: '{keyword}' on {platforms}")
        return alert_id

    def remove_keyword_alert(self, alert_id: int) -> bool:
        """Remove a keyword alert"""
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        cursor.execute(
            "UPDATE keyword_alerts SET is_active = 0 WHERE id = ?",
            (alert_id,)
        )

        affected = cursor.rowcount
        conn.commit()
        conn.close()

        return affected > 0

    def get_stats(self) -> Dict:
        """Get agent statistics"""
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        cursor.execute("SELECT COUNT(*) FROM tracked_items WHERE is_available = 1")
        tracked_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM keyword_alerts WHERE is_active = 1")
        alerts_count = cursor.fetchone()[0]

        cursor.execute("""
            SELECT event_type, COUNT(*) as count
            FROM platform_events
            WHERE created_at > datetime('now', '-24 hours')
            GROUP BY event_type
        """)
        event_counts = {row[0]: row[1] for row in cursor.fetchall()}

        conn.close()

        return {
            'tracked_items': tracked_count,
            'keyword_alerts': alerts_count,
            'events_24h': event_counts,
            'total_events_detected': self.events_detected,
            'total_items_checked': self.items_checked
        }

    def get_recent_events(self, limit: int = 20) -> List[Dict]:
        """Get recent platform events"""
        conn = sqlite3.connect(self.events_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, event_type, platform, item_url, item_title,
                   old_value, new_value, details, created_at
            FROM platform_events
            ORDER BY created_at DESC
            LIMIT ?
        """, (limit,))

        events = [
            {
                'id': row[0],
                'type': row[1],
                'platform': row[2],
                'item_url': row[3],
                'item_title': row[4],
                'old_value': row[5],
                'new_value': row[6],
                'details': json.loads(row[7]) if row[7] else None,
                'created_at': row[8]
            }
            for row in cursor.fetchall()
        ]

        conn.close()
        return events


# Test
if __name__ == "__main__":
    print("=" * 60)
    print("PLATFORM AGENT - TEST")
    print("=" * 60)
    print()

    # Create agent
    agent = PlatformAgent(interval_seconds=900)

    # Track some test items
    print("Tracking test items...")

    agent.track_item(
        url='https://www.vinted.de/items/12345',
        price=49.99,
        title='Vintage Leather Jacket',
        is_favorite=True
    )

    agent.track_item(
        url='https://www.ebay.de/itm/67890',
        price=89.00,
        title='Designer Handbag',
        seller_id='seller123'
    )

    print()
    print("Adding keyword alerts...")

    agent.add_keyword_alert(
        keyword='leather jacket vintage',
        platforms=['vinted_de', 'ebay_de', 'kleinanzeigen'],
        max_price=100
    )

    agent.add_keyword_alert(
        keyword='nike air max',
        platforms=['vinted_de', 'vinted_fr'],
        max_price=80,
        category='shoes'
    )

    print()
    print("Stats:")
    stats = agent.get_stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")

    print()
    print("Testing price update...")
    agent.update_item_price('https://www.vinted.de/items/12345', 39.99)  # Price drop!

    print()
    print("Recent events:")
    for event in agent.get_recent_events(5):
        print(f"  [{event['type']}] {event['platform']}: {event.get('item_title', 'N/A')[:40]}")

    print()
    print("=" * 60)
    print("To run as background service: agent.start()")
    print("=" * 60)