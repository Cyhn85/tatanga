# Login + Upload in SAME browser session
# Manuel login yap, sonra ayni oturumda upload baslar

import os
import sys
import time
import random
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from playwright.sync_api import sync_playwright
from utils.database import db
from config import STATUS_VALIDATED, STATUS_UPLOADED

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROFILE_DIR = os.path.join(BASE_DIR, 'playwright_profiles', 'cssberlin')
DATA_DIR = os.path.join(BASE_DIR, 'data')
os.makedirs(PROFILE_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

def random_delay(min_s=1, max_s=3):
    time.sleep(random.uniform(min_s, max_s))

def upload_product(page, product):
    """Upload a single product"""
    title = product.get('processed_title', product.get('raw_title', ''))
    desc = product.get('processed_description', product.get('raw_description', ''))
    price = product.get('price', 0)
    images_path = product.get('processed_images_path', product.get('raw_images_path', ''))

    print(f"\n[UPLOAD] {title[:50]}...")

    # Go to upload page
    page.goto('https://www.vinted.de/items/new', wait_until='networkidle', timeout=60000)
    random_delay(2, 4)

    # Check if redirected to login
    if 'login' in page.url.lower() or 'signup' in page.url.lower():
        print("[ERROR] Redirected to login - session expired!")
        return False

    page.screenshot(path=os.path.join(DATA_DIR, f'upload_{product["id"]}_form.png'))

    # 1. Upload images
    print("[1] Uploading images...")
    if images_path and os.path.exists(images_path):
        images = [os.path.join(images_path, f) for f in os.listdir(images_path)
                 if f.lower().endswith(('.jpg', '.jpeg', '.png'))][:10]

        if images:
            file_input = page.query_selector('input[type="file"]')
            if file_input:
                file_input.set_input_files(images)
                print(f"  [OK] {len(images)} images uploaded")
                random_delay(3, 5)  # Wait for upload

    # 2. Fill title
    print("[2] Filling title...")
    title_input = page.query_selector('[data-testid="title-input"], input[name="title"], input[placeholder*="Titel"]')
    if title_input:
        title_input.fill(title)
        random_delay(1, 2)
        page.wait_for_timeout(2000)  # Wait for category suggestion

    # 3. Fill description
    print("[3] Filling description...")
    desc_input = page.query_selector('[data-testid="description-textarea"], textarea[name="description"], textarea[placeholder*="Beschreib"]')
    if desc_input:
        desc_input.fill(desc)
        random_delay(1, 2)

    # 4. Fill price
    print("[4] Filling price...")
    price_input = page.query_selector('[data-testid="price-input"], input[name="price"], input[placeholder*="Preis"]')
    if price_input:
        price_input.fill(str(int(price)))
        random_delay(1, 2)

    # Screenshot before submit
    page.screenshot(path=os.path.join(DATA_DIR, f'upload_{product["id"]}_filled.png'))

    # 5. Submit (publish)
    print("[5] Publishing...")
    publish_selectors = [
        'button:has-text("Hochladen")',
        'button:has-text("Artikel hochladen")',
        'button[type="submit"]:has-text("laden")',
        '[data-testid="upload-button"]'
    ]

    for sel in publish_selectors:
        try:
            publish_btn = page.query_selector(sel)
            if publish_btn and publish_btn.is_visible():
                publish_btn.click()
                print(f"  [OK] Clicked: {sel}")
                random_delay(5, 8)

                # Check for success
                if '/items/' in page.url:
                    print("[OK] Product published successfully!")
                    return True
                break
        except:
            continue

    page.screenshot(path=os.path.join(DATA_DIR, f'upload_{product["id"]}_result.png'))
    return False


def main():
    print("=" * 60)
    print("CSSBERLIN - LOGIN + UPLOAD")
    print("=" * 60)
    print()
    print("!!! HATIRLATMA !!!")
    print("  - Mobil Hotspot'a bagli mi?")
    print("  - Every Proxy acik mi?")
    print()
    print("=" * 60)

    # Get products
    products = db.get_products_by_status(STATUS_VALIDATED)[:5]  # Max 5 at a time
    print(f"\n{len(products)} products ready to upload\n")

    if not products:
        print("[INFO] No products to upload")
        return

    with sync_playwright() as pw:
        browser = pw.chromium.launch_persistent_context(
            user_data_dir=PROFILE_DIR,
            headless=False,
            viewport={'width': 1400, 'height': 900},
            locale='de-DE',
            timezone_id='Europe/Berlin',
            args=['--disable-blink-features=AutomationControlled', '--no-sandbox']
        )

        page = browser.pages[0] if browser.pages else browser.new_page()

        # Go to Vinted
        print("\n[1] Vinted.de aciliyor...")
        page.goto('https://www.vinted.de/', wait_until='networkidle', timeout=60000)
        time.sleep(2)

        # Accept cookies
        try:
            cookie_btn = page.query_selector('button#onetrust-accept-btn-handler')
            if cookie_btn and cookie_btn.is_visible():
                cookie_btn.click()
                print("[OK] Cookies accepted")
                time.sleep(2)
        except:
            pass

        # Check if logged in
        header_btn = page.query_selector('a:has-text("Registrieren | Einloggen")')

        if header_btn:
            print("\n" + "=" * 60)
            print("MANUEL LOGIN GEREKLI!")
            print("=" * 60)
            print()
            print("1. 'Registrieren | Einloggen' butonuna tikla")
            print("2. 'Einloggen' linkine tikla")
            print("3. 'E-Mail' secenegini tikla")
            print("4. Email: cssberlin@hotmail.com")
            print("5. Sifre: Cssberlin200231")
            print("6. 'Weiter' tikla ve CAPTCHA coz")
            print()
            print("Login tamamlaninca upload baslar...")
            print("=" * 60)

            # Wait for login (max 10 minutes)
            max_wait = 600
            start = time.time()

            while time.time() - start < max_wait:
                time.sleep(3)
                elapsed = int(time.time() - start)

                header_btn = page.query_selector('a:has-text("Registrieren | Einloggen")')
                if not header_btn:
                    print(f"\n[OK] Login tamamlandi! ({elapsed}s)")
                    break

                print(f"[{elapsed}s] Bekliyor...")
            else:
                print("[TIMEOUT] Login tamamlanmadi!")
                browser.close()
                return
        else:
            print("[OK] Zaten giris yapilmis!")

        # Now upload products
        print("\n" + "=" * 60)
        print("UPLOAD BASLIYOR")
        print("=" * 60)

        uploaded = 0
        for i, product in enumerate(products):
            print(f"\n--- Product {i+1}/{len(products)} ---")

            try:
                if upload_product(page, product):
                    db.update_product(product['id'], {
                        'status': STATUS_UPLOADED,
                        'target_store': 'cssberlin'
                    })
                    db.add_log(product['id'], 'upload', 'success', 'Uploaded to cssberlin')
                    uploaded += 1
                    print(f"[OK] Product {product['id']} uploaded!")
                else:
                    print(f"[FAIL] Product {product['id']} failed")

                # Delay between products
                if i < len(products) - 1:
                    delay = random.randint(30, 60)
                    print(f"\n[WAIT] {delay}s before next...")
                    time.sleep(delay)

            except Exception as e:
                print(f"[ERROR] {e}")
                db.add_log(product['id'], 'upload', 'failed', str(e))

        print("\n" + "=" * 60)
        print(f"DONE: {uploaded}/{len(products)} uploaded")
        print("=" * 60)

        print("\nBrowser 30 saniye acik kalacak...")
        time.sleep(30)
        browser.close()


if __name__ == '__main__':
    main()
