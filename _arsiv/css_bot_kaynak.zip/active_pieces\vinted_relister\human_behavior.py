# Human-like behavior functions for Vinted automation
# Avoids bot detection with natural movements and timing

import random
import time
import math


class HumanBehavior:
    """Human-like interactions for Playwright"""

    def __init__(self, page):
        self.page = page

    def random_delay(self, min_s=0.5, max_s=2.0):
        """Random delay between actions"""
        time.sleep(random.uniform(min_s, max_s))

    def thinking_pause(self):
        """Occasional longer pause (like reading)"""
        if random.random() < 0.2:  # 20% chance
            time.sleep(random.uniform(1.0, 3.0))

    def human_type(self, element, text, mistakes=True):
        """
        Type text character by character with human-like timing
        - Random delays between characters (80-200ms)
        - Occasional thinking pauses
        - Optional typos and corrections
        """
        for i, char in enumerate(text):
            # Occasional typo and correction (3% chance)
            if mistakes and random.random() < 0.03 and i > 2:
                # Type wrong character
                wrong_chars = 'qwertyuiopasdfghjklzxcvbnm'
                wrong = random.choice(wrong_chars)
                element.type(wrong, delay=random.randint(80, 150))
                time.sleep(random.uniform(0.15, 0.3))

                # Delete it
                element.press('Backspace')
                time.sleep(random.uniform(0.1, 0.2))

            # Type correct character
            element.type(char, delay=random.randint(80, 200))

            # Occasional thinking pause (5% chance)
            if random.random() < 0.05:
                time.sleep(random.uniform(0.3, 0.8))

        self.random_delay(0.3, 0.8)

    def human_click(self, element, allow_miss=True):
        """
        Click element with human-like behavior
        - Move mouse naturally to element
        - Occasional miss-click nearby
        """
        box = element.bounding_box()
        if not box:
            element.click()
            return

        # Target center with slight randomness
        target_x = box['x'] + box['width'] / 2 + random.randint(-5, 5)
        target_y = box['y'] + box['height'] / 2 + random.randint(-3, 3)

        # Occasional miss-click (5% chance)
        if allow_miss and random.random() < 0.05:
            miss_x = target_x + random.randint(-30, 30)
            miss_y = target_y + random.randint(-20, 20)
            self.human_mouse_move(miss_x, miss_y)
            self.page.mouse.click(miss_x, miss_y)
            time.sleep(random.uniform(0.3, 0.6))

        # Move to target and click
        self.human_mouse_move(target_x, target_y)
        self.random_delay(0.1, 0.3)
        self.page.mouse.click(target_x, target_y)
        self.random_delay(0.5, 1.5)

    def human_mouse_move(self, target_x, target_y):
        """
        Move mouse in a natural curved path (Bezier-like)
        - Not a straight line
        - Variable speed
        - Small random deviations
        """
        # Get current position (or start from random edge)
        try:
            # Playwright doesn't expose current mouse position easily
            # So we'll just do the movement
            pass
        except:
            pass

        steps = random.randint(15, 30)

        for i in range(steps):
            progress = i / steps

            # Ease-in-out curve
            ease = progress * progress * (3 - 2 * progress)

            # Add slight curve (sine wave deviation)
            curve_offset = math.sin(progress * math.pi) * random.randint(-10, 10)

            # Calculate position
            # (Assuming starting from somewhere, we just do relative moves)
            deviation_x = random.randint(-3, 3)
            deviation_y = random.randint(-2, 2)

            # Move in small steps
            self.page.mouse.move(
                target_x + curve_offset + deviation_x,
                target_y + deviation_y
            )
            time.sleep(random.uniform(0.008, 0.025))

        # Final position
        self.page.mouse.move(target_x, target_y)

    def random_scroll(self):
        """Random scroll like browsing"""
        if random.random() < 0.15:  # 15% chance
            scroll_amount = random.randint(-150, 150)
            self.page.mouse.wheel(0, scroll_amount)
            time.sleep(random.uniform(0.3, 0.8))

    def fill_field(self, selector, text, clear_first=True):
        """
        Fill a form field with human-like behavior
        1. Click the field
        2. Clear existing text
        3. Type new text character by character
        """
        element = self.page.query_selector(selector)
        if not element:
            print(f"  [WARN] Field not found: {selector}")
            return False

        # Click to focus
        self.human_click(element, allow_miss=False)
        self.random_delay(0.3, 0.6)

        # Clear existing text
        if clear_first:
            self.page.keyboard.press('Control+a')
            time.sleep(0.1)
            self.page.keyboard.press('Backspace')
            self.random_delay(0.2, 0.4)

        # Type new text
        self.human_type(element, text, mistakes=True)
        return True

    def safe_click(self, selector):
        """Click element if found"""
        element = self.page.query_selector(selector)
        if element and element.is_visible():
            self.human_click(element)
            return True
        return False

    def wait_and_click(self, selector, timeout=10):
        """Wait for element and click"""
        try:
            self.page.wait_for_selector(selector, timeout=timeout * 1000)
            return self.safe_click(selector)
        except:
            return False

    def scroll_to_element(self, selector):
        """Scroll element into view naturally"""
        element = self.page.query_selector(selector)
        if element:
            element.scroll_into_view_if_needed()
            self.random_delay(0.3, 0.8)
            self.random_scroll()  # Extra random scroll

    def between_actions(self):
        """Call between major actions"""
        self.thinking_pause()
        self.random_scroll()
        self.random_delay(0.5, 1.5)


# Standalone functions for backward compatibility
def human_type(element, text):
    """Type text with human-like delays"""
    for char in text:
        element.type(char, delay=random.randint(80, 200))
        if random.random() < 0.05:
            time.sleep(random.uniform(0.3, 0.8))


def random_delay(min_s=0.5, max_s=2.0):
    """Random sleep"""
    time.sleep(random.uniform(min_s, max_s))
