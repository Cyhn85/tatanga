#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - AI Vision Manager
Fallback zinciri ile AI Vision yönetimi

Sıralama (ücretsiz limitler):
1. Google Gemini Vision - 1M req/gün (EN İYİ)
2. Groq Vision - Rate limit bazlı
3. Cloudflare Workers AI - 10K neurons/gün
4. Ollama Lokal - Sınırsız (yavaş)
"""

import asyncio
import base64
import json
import os
import sys
import httpx
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.logger import get_logger

logger = get_logger("ai_vision_manager")


class AIProvider(Enum):
    """AI Vision provider'ları"""
    GEMINI = "gemini"
    GROQ = "groq"
    CLOUDFLARE = "cloudflare"
    OLLAMA = "ollama"


@dataclass
class ProviderConfig:
    """Provider konfigürasyonu"""
    name: str
    daily_limit: int
    current_usage: int = 0
    last_reset: datetime = None
    is_available: bool = True
    avg_latency_ms: float = 0
    success_rate: float = 1.0
    total_requests: int = 0
    successful_requests: int = 0


class AIVisionManager:
    """
    AI Vision Fallback Manager

    Akıllı fallback zinciri:
    1. Provider'ı seç (limit, hız, doğruluk)
    2. İstek gönder
    3. Başarısız olursa sonrakine geç
    4. Tüm provider'lar başarısız olursa hata döndür
    """

    # Provider konfigürasyonları
    PROVIDERS = {
        AIProvider.GEMINI: ProviderConfig(
            name="Google Gemini Vision",
            daily_limit=1000000,  # 1M req/gün
        ),
        AIProvider.GROQ: ProviderConfig(
            name="Groq Vision (llama-3.2-90b)",
            daily_limit=10000,  # Tahmini rate limit
        ),
        AIProvider.CLOUDFLARE: ProviderConfig(
            name="Cloudflare Workers AI",
            daily_limit=10000,  # 10K neurons/gün
        ),
        AIProvider.OLLAMA: ProviderConfig(
            name="Ollama Local (llava)",
            daily_limit=float('inf'),  # Sınırsız
        ),
    }

    # Analiz türleri
    ANALYSIS_PROMPTS = {
        'product_status': """Bu e-ticaret ürün sayfasının screenshot'ını analiz et.
Ürün satılık mı, satıldı mı, mevcut değil mi?
JSON formatında cevap ver:
{
    "status": "available|sold|unavailable|unknown",
    "price": sayı veya null,
    "currency": "EUR|USD|GBP|...",
    "condition": "new|like_new|good|fair|poor",
    "confidence": 0.0-1.0
}""",

        'content_extract': """Bu ürün sayfasından şu bilgileri çıkar:
- title: Ürün başlığı
- price: Fiyat (sayı)
- currency: Para birimi
- brand: Marka
- size: Beden
- color: Renk
- condition: Durum açıklaması
- description: Kısa açıklama
- seller_name: Satıcı adı
- shipping_info: Kargo bilgisi

JSON formatında döndür.""",

        'captcha_check': """Bu sayfayı analiz et:
- CAPTCHA var mı?
- Login gerekiyor mu?
- Bot tespit mesajı var mı?
- Sayfa normal yüklendi mi?

JSON formatında cevap ver:
{
    "has_captcha": true|false,
    "requires_login": true|false,
    "bot_detected": true|false,
    "page_loaded": true|false,
    "error_message": "..." veya null
}""",

        'gallery_extract': """Bu ürün sayfasındaki galeri görsellerini analiz et:
- Kaç tane ürün görseli var?
- Ana görsel hangi pozisyonda?
- Görsellerin kalitesi nasıl?

JSON formatında cevap ver:
{
    "image_count": sayı,
    "main_image_position": 0-based index,
    "quality_assessment": "high|medium|low",
    "has_watermark": true|false,
    "product_visible": true|false
}"""
    }

    def __init__(self):
        """Manager başlat"""
        self.providers = dict(self.PROVIDERS)
        self._load_api_keys()
        self._reset_daily_limits()

        # HTTP client
        self.client = httpx.AsyncClient(timeout=60.0)

        logger.info("AI Vision Manager başlatıldı")
        self._log_provider_status()

    def _load_api_keys(self):
        """API key'leri yükle"""
        # Gemini - Mevcut .env'den
        self.gemini_api_key = os.getenv('GEMINI_API_KEY', 'AIzaSyBwA4VQVEUROtcK9XZ228bAoCvRuHQ2LoE')

        # Groq
        self.groq_api_key = os.getenv('GROQ_API_KEY', '')

        # Cloudflare
        self.cloudflare_account_id = os.getenv('CLOUDFLARE_ACCOUNT_ID', '')
        self.cloudflare_api_token = os.getenv('CLOUDFLARE_API_TOKEN', '')

        # Ollama (lokal - key gerekmez)
        self.ollama_base_url = os.getenv('OLLAMA_BASE_URL', 'http://localhost:11434')

        # Provider availability güncelle
        if not self.gemini_api_key:
            self.providers[AIProvider.GEMINI].is_available = False
            logger.warning("Gemini API key bulunamadı")

        if not self.groq_api_key:
            self.providers[AIProvider.GROQ].is_available = False
            logger.warning("Groq API key bulunamadı")

        if not self.cloudflare_api_token:
            self.providers[AIProvider.CLOUDFLARE].is_available = False
            logger.warning("Cloudflare API token bulunamadı")

    def _reset_daily_limits(self):
        """Günlük limitleri sıfırla (gece yarısı)"""
        now = datetime.now()
        for provider in self.providers.values():
            if provider.last_reset is None or provider.last_reset.date() < now.date():
                provider.current_usage = 0
                provider.last_reset = now

    def _log_provider_status(self):
        """Provider durumlarını logla"""
        logger.info("=== AI Vision Provider Durumu ===")
        for provider_type, config in self.providers.items():
            status = "✅ Aktif" if config.is_available else "❌ Deaktif"
            usage = f"{config.current_usage}/{config.daily_limit}"
            logger.info(f"  {config.name}: {status} | Kullanım: {usage}")

    def _get_best_provider(self) -> Optional[AIProvider]:
        """
        En iyi provider'ı seç

        Kriterler:
        1. Aktif olmalı (API key var)
        2. Günlük limit aşılmamış olmalı
        3. Success rate yüksek olmalı
        """
        self._reset_daily_limits()

        available_providers = []
        for provider_type, config in self.providers.items():
            if config.is_available and config.current_usage < config.daily_limit:
                # Score hesapla (success rate * remaining capacity)
                remaining_ratio = 1 - (config.current_usage / config.daily_limit) if config.daily_limit != float('inf') else 1
                score = config.success_rate * remaining_ratio
                available_providers.append((provider_type, score))

        if not available_providers:
            return None

        # En yüksek score'a sahip provider'ı döndür
        available_providers.sort(key=lambda x: x[1], reverse=True)
        return available_providers[0][0]

    async def analyze_image(
        self,
        image_data: bytes,
        analysis_type: str = 'content_extract',
        custom_prompt: str = None,
        preferred_provider: AIProvider = None
    ) -> Dict[str, Any]:
        """
        Görsel analiz et (fallback zinciri ile)

        Args:
            image_data: Görsel bytes
            analysis_type: Analiz türü (product_status, content_extract, captcha_check, gallery_extract)
            custom_prompt: Özel prompt (opsiyonel)
            preferred_provider: Tercih edilen provider (opsiyonel)

        Returns:
            {
                'success': bool,
                'provider': str,
                'result': dict,
                'latency_ms': float,
                'error': str (eğer başarısız)
            }
        """
        prompt = custom_prompt or self.ANALYSIS_PROMPTS.get(analysis_type, self.ANALYSIS_PROMPTS['content_extract'])

        # Provider sıralaması
        if preferred_provider and self.providers[preferred_provider].is_available:
            provider_order = [preferred_provider] + [p for p in AIProvider if p != preferred_provider]
        else:
            provider_order = list(AIProvider)

        # Her provider'ı dene
        for provider_type in provider_order:
            config = self.providers[provider_type]

            if not config.is_available:
                continue

            if config.current_usage >= config.daily_limit:
                logger.warning(f"{config.name} günlük limit aşıldı")
                continue

            logger.info(f"Deneniyor: {config.name}")
            start_time = datetime.now()

            try:
                result = await self._call_provider(provider_type, image_data, prompt)

                latency_ms = (datetime.now() - start_time).total_seconds() * 1000

                # Stats güncelle
                config.current_usage += 1
                config.total_requests += 1
                config.successful_requests += 1
                config.avg_latency_ms = (config.avg_latency_ms * (config.total_requests - 1) + latency_ms) / config.total_requests
                config.success_rate = config.successful_requests / config.total_requests

                logger.success(f"{config.name} başarılı ({latency_ms:.0f}ms)")

                return {
                    'success': True,
                    'provider': provider_type.value,
                    'provider_name': config.name,
                    'result': result,
                    'latency_ms': latency_ms,
                    'analysis_type': analysis_type
                }

            except Exception as e:
                latency_ms = (datetime.now() - start_time).total_seconds() * 1000

                # Stats güncelle
                config.total_requests += 1
                config.success_rate = config.successful_requests / config.total_requests

                logger.error(f"{config.name} başarısız: {e}")
                continue

        # Tüm provider'lar başarısız
        logger.error("Tüm AI Vision provider'ları başarısız!")
        return {
            'success': False,
            'error': 'All providers failed',
            'providers_tried': [p.value for p in provider_order if self.providers[p].is_available]
        }

    async def _call_provider(
        self,
        provider: AIProvider,
        image_data: bytes,
        prompt: str
    ) -> Dict[str, Any]:
        """Provider'a istek gönder"""

        if provider == AIProvider.GEMINI:
            return await self._call_gemini(image_data, prompt)
        elif provider == AIProvider.GROQ:
            return await self._call_groq(image_data, prompt)
        elif provider == AIProvider.CLOUDFLARE:
            return await self._call_cloudflare(image_data, prompt)
        elif provider == AIProvider.OLLAMA:
            return await self._call_ollama(image_data, prompt)
        else:
            raise ValueError(f"Bilinmeyen provider: {provider}")

    async def _call_gemini(self, image_data: bytes, prompt: str) -> Dict[str, Any]:
        """Google Gemini Vision API"""
        import google.generativeai as genai

        genai.configure(api_key=self.gemini_api_key)

        # Try models in order of preference
        model_names = ['gemini-2.0-flash', 'gemini-1.5-pro', 'gemini-pro-vision']
        model = None
        for model_name in model_names:
            try:
                model = genai.GenerativeModel(model_name)
                break
            except Exception:
                continue

        if model is None:
            model = genai.GenerativeModel('gemini-pro-vision')

        # Görsel hazırla
        image_part = {
            'mime_type': 'image/png',
            'data': image_data
        }

        response = model.generate_content([prompt, image_part])

        # JSON parse et
        text = response.text
        try:
            # JSON bloğunu bul
            if '```json' in text:
                json_str = text.split('```json')[1].split('```')[0]
            elif '{' in text:
                start = text.index('{')
                end = text.rindex('}') + 1
                json_str = text[start:end]
            else:
                json_str = text

            return json.loads(json_str)
        except:
            return {'raw_text': text}

    async def _call_groq(self, image_data: bytes, prompt: str) -> Dict[str, Any]:
        """Groq Vision API"""
        image_base64 = base64.b64encode(image_data).decode('utf-8')

        response = await self.client.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {self.groq_api_key}",
                "Content-Type": "application/json"
            },
            json={
                "model": "llama-3.2-90b-vision-preview",
                "messages": [{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{image_base64}"
                            }
                        }
                    ]
                }],
                "max_tokens": 2000,
                "temperature": 0.1
            }
        )

        response.raise_for_status()
        data = response.json()

        text = data['choices'][0]['message']['content']

        # JSON parse et
        try:
            if '```json' in text:
                json_str = text.split('```json')[1].split('```')[0]
            elif '{' in text:
                start = text.index('{')
                end = text.rindex('}') + 1
                json_str = text[start:end]
            else:
                json_str = text

            return json.loads(json_str)
        except:
            return {'raw_text': text}

    async def _call_cloudflare(self, image_data: bytes, prompt: str) -> Dict[str, Any]:
        """Cloudflare Workers AI"""
        image_base64 = base64.b64encode(image_data).decode('utf-8')

        response = await self.client.post(
            f"https://api.cloudflare.com/client/v4/accounts/{self.cloudflare_account_id}/ai/run/@cf/meta/llama-3.2-11b-vision-instruct",
            headers={
                "Authorization": f"Bearer {self.cloudflare_api_token}",
                "Content-Type": "application/json"
            },
            json={
                "prompt": prompt,
                "image": [image_base64]
            }
        )

        response.raise_for_status()
        data = response.json()

        text = data.get('result', {}).get('response', '')

        # JSON parse et
        try:
            if '{' in text:
                start = text.index('{')
                end = text.rindex('}') + 1
                json_str = text[start:end]
                return json.loads(json_str)
        except:
            pass

        return {'raw_text': text}

    async def _call_ollama(self, image_data: bytes, prompt: str) -> Dict[str, Any]:
        """Ollama Local Vision (llava)"""
        image_base64 = base64.b64encode(image_data).decode('utf-8')

        response = await self.client.post(
            f"{self.ollama_base_url}/api/generate",
            json={
                "model": "llava",
                "prompt": prompt,
                "images": [image_base64],
                "stream": False
            },
            timeout=120.0  # Ollama daha yavaş
        )

        response.raise_for_status()
        data = response.json()

        text = data.get('response', '')

        # JSON parse et
        try:
            if '{' in text:
                start = text.index('{')
                end = text.rindex('}') + 1
                json_str = text[start:end]
                return json.loads(json_str)
        except:
            pass

        return {'raw_text': text}

    def get_stats(self) -> Dict[str, Any]:
        """Provider istatistiklerini döndür"""
        stats = {}
        for provider_type, config in self.providers.items():
            stats[provider_type.value] = {
                'name': config.name,
                'is_available': config.is_available,
                'daily_limit': config.daily_limit if config.daily_limit != float('inf') else 'unlimited',
                'current_usage': config.current_usage,
                'remaining': config.daily_limit - config.current_usage if config.daily_limit != float('inf') else 'unlimited',
                'success_rate': f"{config.success_rate * 100:.1f}%",
                'avg_latency_ms': f"{config.avg_latency_ms:.0f}ms",
                'total_requests': config.total_requests
            }
        return stats

    async def close(self):
        """HTTP client'ı kapat"""
        await self.client.aclose()


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

# Global instance
_manager: Optional[AIVisionManager] = None


def get_vision_manager() -> AIVisionManager:
    """Global vision manager instance al"""
    global _manager
    if _manager is None:
        _manager = AIVisionManager()
    return _manager


async def analyze_screenshot(
    image_data: bytes,
    analysis_type: str = 'content_extract'
) -> Dict[str, Any]:
    """Kısa yol: Screenshot analiz et"""
    manager = get_vision_manager()
    return await manager.analyze_image(image_data, analysis_type)


async def check_product_status(image_data: bytes) -> Dict[str, Any]:
    """Kısa yol: Ürün durumu kontrol et"""
    return await analyze_screenshot(image_data, 'product_status')


async def extract_product_data(image_data: bytes) -> Dict[str, Any]:
    """Kısa yol: Ürün verisi çıkar"""
    return await analyze_screenshot(image_data, 'content_extract')


async def check_captcha(image_data: bytes) -> Dict[str, Any]:
    """Kısa yol: CAPTCHA kontrolü"""
    return await analyze_screenshot(image_data, 'captcha_check')


# ============================================================================
# TEST
# ============================================================================

if __name__ == '__main__':
    import asyncio

    async def test():
        print("=" * 60)
        print("TATANGA - AI Vision Manager Test")
        print("=" * 60)

        manager = AIVisionManager()

        # Stats göster
        print("\n=== Provider Durumu ===")
        stats = manager.get_stats()
        for provider, data in stats.items():
            print(f"\n{provider}:")
            for key, value in data.items():
                print(f"  {key}: {value}")

        # Test görsel (placeholder)
        print("\n=== Test Analizi ===")
        print("Not: Gerçek test için bir screenshot dosyası gerekli")

        # Örnek kullanım:
        # with open('test_screenshot.png', 'rb') as f:
        #     image_data = f.read()
        #
        # result = await manager.analyze_image(image_data, 'product_status')
        # print(f"Sonuç: {result}")

        await manager.close()
        print("\n✅ AI Vision Manager hazır!")

    asyncio.run(test())
