#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FOF IMAGE AGENT - Fotoğraf Optimizasyon Fabrikası
AI-powered image analysis and background processing

Core Principles:
- NEVER touch the product itself
- ONLY modify the background
- Professional, natural, organic look
- Smart scenario detection

Features:
- Image scenario detection (wooden floor, hanger, mannequin, etc.)
- AI-powered background segmentation
- Background modification strategies
- Metadata manipulation for duplicate bypass
- Processing queue management

Author: TATANGA Team
Version: 1.0
"""

import sys
import asyncio
import sqlite3
import json
import hashlib
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents.base_agent import BaseAgent, AgentConfig
from core.logger import ModuleLogger

# Try to import image processing libraries
try:
    from PIL import Image, ImageFilter, ImageEnhance, ExifTags
    import io
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("Warning: PIL not installed. Run: pip install Pillow")

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False


class ImageScenario(Enum):
    """Detected image scenarios"""
    WOODEN_FLOOR = "wooden_floor"      # Product on wooden floor
    HANGER = "hanger"                  # Hanging on hanger
    MANNEQUIN = "mannequin"            # On mannequin/dress form
    FLAT_LAY = "flat_lay"              # Flat lay arrangement
    MODEL = "model"                     # Worn by model
    OUTDOOR = "outdoor"                 # Outdoor/nature background
    STUDIO = "studio"                   # Studio/plain background
    TABLE = "table"                     # On table/surface
    HAND_HELD = "hand_held"             # Held in hand
    UNKNOWN = "unknown"                 # Unknown scenario


class ProcessingStrategy(Enum):
    """Background processing strategies"""
    BLUR_BACKGROUND = "blur"           # Blur background, keep product sharp
    GRADIENT_REPLACE = "gradient"      # Replace with gradient
    SOLID_REPLACE = "solid"            # Replace with solid color
    SUBTLE_ADJUST = "subtle"           # Subtle color/brightness adjustment
    TEXTURE_OVERLAY = "texture"        # Add subtle texture
    VIGNETTE = "vignette"              # Add vignette effect
    PRESERVE = "preserve"              # Preserve original (just metadata)


class FOFImageAgent(BaseAgent):
    """
    Fotoğraf Optimizasyon Fabrikası (FOF) - Image Processing Agent

    Analyzes images and decides how to process them while preserving
    product integrity. Only modifies backgrounds, never the product.

    Usage:
        agent = FOFImageAgent()

        # Analyze single image
        analysis = agent.analyze_image("/path/to/image.jpg")

        # Process image
        result = agent.process_image("/path/to/image.jpg")

        # Queue for batch processing
        agent.queue_image(image_path, product_id)

        # Start background service
        agent.start()
    """

    def __init__(self, interval_seconds: int = 30):
        """
        Initialize FOF Image Agent

        Args:
            interval_seconds: How often to check the processing queue
        """
        config = AgentConfig(
            name="fof_image",
            interval_seconds=interval_seconds,
            max_retries=3,
            retry_delay_seconds=10
        )
        super().__init__(config)

        # Storage paths
        self.storage_dir = Path(__file__).parent.parent / 'storage'
        self.processed_dir = self.storage_dir / 'processed_images'
        self.processed_dir.mkdir(parents=True, exist_ok=True)

        # Queue database
        self.queue_db = self.storage_dir / 'image_queue.db'
        self._init_queue_db()

        # Processing stats
        self.images_analyzed = 0
        self.images_processed = 0
        self.images_failed = 0

        # Scenario detection patterns (simplified heuristics)
        self.scenario_keywords = {
            ImageScenario.WOODEN_FLOOR: ['parquet', 'holz', 'wood', 'floor'],
            ImageScenario.HANGER: ['hanger', 'hanging', 'askı', 'bügel'],
            ImageScenario.MANNEQUIN: ['mannequin', 'dummy', 'manken', 'schaufensterpuppe'],
            ImageScenario.MODEL: ['model', 'worn', 'wearing', 'outfit'],
            ImageScenario.STUDIO: ['studio', 'white', 'plain', 'background'],
        }

        # Processing strategy recommendations per scenario
        self.scenario_strategies = {
            ImageScenario.WOODEN_FLOOR: ProcessingStrategy.BLUR_BACKGROUND,
            ImageScenario.HANGER: ProcessingStrategy.GRADIENT_REPLACE,
            ImageScenario.MANNEQUIN: ProcessingStrategy.SUBTLE_ADJUST,
            ImageScenario.FLAT_LAY: ProcessingStrategy.VIGNETTE,
            ImageScenario.MODEL: ProcessingStrategy.PRESERVE,  # Don't modify model photos
            ImageScenario.OUTDOOR: ProcessingStrategy.BLUR_BACKGROUND,
            ImageScenario.STUDIO: ProcessingStrategy.SUBTLE_ADJUST,
            ImageScenario.TABLE: ProcessingStrategy.GRADIENT_REPLACE,
            ImageScenario.HAND_HELD: ProcessingStrategy.BLUR_BACKGROUND,
            ImageScenario.UNKNOWN: ProcessingStrategy.SUBTLE_ADJUST,
        }

    def _init_queue_db(self):
        """Initialize image processing queue database"""
        self.queue_db.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS image_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                image_path TEXT NOT NULL,
                product_id INTEGER,
                status TEXT DEFAULT 'pending',
                scenario TEXT,
                strategy TEXT,
                original_hash TEXT,
                processed_path TEXT,
                processed_hash TEXT,
                error_message TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                processed_at DATETIME
            )
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_image_queue_status
            ON image_queue(status, created_at)
        """)

        conn.commit()
        conn.close()

    async def setup(self):
        """Setup hook"""
        self.logger.info("FOF Image Agent starting up")

        if not PIL_AVAILABLE:
            self.logger.warning("PIL not available - image processing limited!")

    async def process(self) -> Dict[str, Any]:
        """
        Main processing loop - check queue and process images

        Returns:
            Processing result summary
        """
        results = {
            'processed': 0,
            'failed': 0
        }

        items = self._get_pending_items(limit=5)

        if not items:
            return {'status': 'idle', 'message': 'No pending images'}

        self.logger.info(f"Processing {len(items)} images")

        for item in items:
            try:
                self._update_status(item['id'], 'processing')

                # Analyze image
                analysis = self.analyze_image(item['image_path'])

                # Update with analysis results
                self._update_analysis(item['id'], analysis)

                # Process image
                processed_path = self.process_image(
                    item['image_path'],
                    strategy=analysis.get('recommended_strategy')
                )

                if processed_path:
                    self._mark_completed(item['id'], processed_path)
                    results['processed'] += 1
                    self.images_processed += 1
                else:
                    self._mark_failed(item['id'], "Processing failed")
                    results['failed'] += 1
                    self.images_failed += 1

            except Exception as e:
                self._mark_failed(item['id'], str(e))
                results['failed'] += 1
                self.images_failed += 1
                self.logger.error(f"Image processing error: {e}")

        results['total_processed'] = self.images_processed
        results['total_failed'] = self.images_failed

        return results

    # ========================================================================
    # IMAGE ANALYSIS
    # ========================================================================

    def analyze_image(self, image_path: str) -> Dict[str, Any]:
        """
        Analyze image and detect scenario

        Args:
            image_path: Path to image file

        Returns:
            Analysis results including scenario and recommended strategy
        """
        self.images_analyzed += 1
        self.logger.info(f"Analyzing image: {image_path}")

        analysis = {
            'image_path': image_path,
            'analyzed_at': datetime.now().isoformat(),
            'scenario': ImageScenario.UNKNOWN.value,
            'scenario_confidence': 0.0,
            'recommended_strategy': ProcessingStrategy.SUBTLE_ADJUST.value,
            'dimensions': None,
            'format': None,
            'file_size': None,
            'has_exif': False,
            'dominant_colors': [],
            'brightness_level': 'medium',
            'is_product_photo': True
        }

        if not os.path.exists(image_path):
            analysis['error'] = 'File not found'
            return analysis

        try:
            # Get file info
            analysis['file_size'] = os.path.getsize(image_path)

            if PIL_AVAILABLE:
                with Image.open(image_path) as img:
                    # Basic info
                    analysis['dimensions'] = img.size
                    analysis['format'] = img.format
                    analysis['mode'] = img.mode

                    # Check for EXIF
                    exif = img.getexif()
                    analysis['has_exif'] = bool(exif)

                    # Analyze colors and brightness
                    color_analysis = self._analyze_colors(img)
                    analysis.update(color_analysis)

                    # Detect scenario based on image characteristics
                    scenario, confidence = self._detect_scenario(img, color_analysis)
                    analysis['scenario'] = scenario.value
                    analysis['scenario_confidence'] = confidence

                    # Get recommended strategy
                    strategy = self.scenario_strategies.get(scenario, ProcessingStrategy.SUBTLE_ADJUST)
                    analysis['recommended_strategy'] = strategy.value

        except Exception as e:
            analysis['error'] = str(e)
            self.logger.warning(f"Analysis error: {e}")

        return analysis

    def _analyze_colors(self, img: Image.Image) -> Dict:
        """Analyze image colors and brightness"""
        result = {
            'dominant_colors': [],
            'brightness_level': 'medium',
            'is_mostly_white': False,
            'has_gradient': False
        }

        try:
            # Resize for faster analysis
            thumb = img.copy()
            thumb.thumbnail((150, 150))

            if thumb.mode != 'RGB':
                thumb = thumb.convert('RGB')

            # Get colors
            colors = thumb.getcolors(maxcolors=256) or []
            colors.sort(key=lambda x: x[0], reverse=True)

            # Top 5 dominant colors
            result['dominant_colors'] = [
                {'rgb': c[1], 'count': c[0]}
                for c in colors[:5]
            ]

            # Calculate average brightness
            if NUMPY_AVAILABLE:
                arr = np.array(thumb)
                brightness = np.mean(arr)
                result['average_brightness'] = float(brightness)

                if brightness > 200:
                    result['brightness_level'] = 'high'
                    result['is_mostly_white'] = True
                elif brightness > 127:
                    result['brightness_level'] = 'medium'
                else:
                    result['brightness_level'] = 'low'

        except Exception as e:
            self.logger.warning(f"Color analysis error: {e}")

        return result

    def _detect_scenario(
        self,
        img: Image.Image,
        color_analysis: Dict
    ) -> Tuple[ImageScenario, float]:
        """
        Detect image scenario using heuristics

        Returns:
            Tuple of (scenario, confidence)
        """
        width, height = img.size

        # Confidence starts at 0
        scenario_scores = {s: 0.0 for s in ImageScenario}

        # Check aspect ratio
        aspect = width / height

        # Portrait orientation often indicates model/mannequin
        if aspect < 0.8:
            scenario_scores[ImageScenario.MODEL] += 0.2
            scenario_scores[ImageScenario.MANNEQUIN] += 0.2

        # Square or landscape might be flat lay
        if 0.9 <= aspect <= 1.1:
            scenario_scores[ImageScenario.FLAT_LAY] += 0.3

        # Check if mostly white (studio shot)
        if color_analysis.get('is_mostly_white'):
            scenario_scores[ImageScenario.STUDIO] += 0.5

        # Check brightness
        brightness = color_analysis.get('brightness_level', 'medium')
        if brightness == 'high':
            scenario_scores[ImageScenario.STUDIO] += 0.2
        elif brightness == 'low':
            scenario_scores[ImageScenario.OUTDOOR] += 0.2

        # Analyze dominant colors for wooden floor detection
        dominant_colors = color_analysis.get('dominant_colors', [])
        for color_info in dominant_colors[:3]:
            rgb = color_info.get('rgb', (0, 0, 0))
            if isinstance(rgb, tuple) and len(rgb) >= 3:
                r, g, b = rgb[:3]

                # Brown/wooden tones
                if 100 < r < 180 and 60 < g < 130 and 30 < b < 100:
                    scenario_scores[ImageScenario.WOODEN_FLOOR] += 0.3

                # Very white
                if r > 240 and g > 240 and b > 240:
                    scenario_scores[ImageScenario.STUDIO] += 0.2

        # Find best scenario
        best_scenario = max(scenario_scores, key=scenario_scores.get)
        best_score = scenario_scores[best_scenario]

        # If no strong signal, default to unknown
        if best_score < 0.3:
            return ImageScenario.UNKNOWN, 0.0

        return best_scenario, best_score

    # ========================================================================
    # IMAGE PROCESSING
    # ========================================================================

    def process_image(
        self,
        image_path: str,
        strategy: str = None,
        output_path: str = None
    ) -> Optional[str]:
        """
        Process image according to strategy

        Args:
            image_path: Source image path
            strategy: Processing strategy (auto-detected if None)
            output_path: Output path (auto-generated if None)

        Returns:
            Path to processed image or None if failed
        """
        if not PIL_AVAILABLE:
            self.logger.error("PIL not available")
            return None

        if not os.path.exists(image_path):
            self.logger.error(f"Image not found: {image_path}")
            return None

        try:
            # Auto-detect strategy if not provided
            if strategy is None:
                analysis = self.analyze_image(image_path)
                strategy = analysis.get('recommended_strategy', ProcessingStrategy.SUBTLE_ADJUST.value)

            strategy_enum = ProcessingStrategy(strategy) if isinstance(strategy, str) else strategy

            self.logger.info(f"Processing with strategy: {strategy_enum.value}")

            with Image.open(image_path) as img:
                # Apply processing based on strategy
                processed = self._apply_strategy(img, strategy_enum)

                # Generate output path
                if output_path is None:
                    filename = Path(image_path).stem
                    ext = Path(image_path).suffix or '.jpg'
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    output_path = str(self.processed_dir / f"{filename}_{timestamp}{ext}")

                # Modify metadata to create unique hash
                processed = self._modify_metadata(processed)

                # Save
                if processed.mode == 'RGBA':
                    processed = processed.convert('RGB')

                processed.save(output_path, quality=95, optimize=True)

                self.logger.success(f"Processed image saved: {output_path}")
                return output_path

        except Exception as e:
            self.logger.error(f"Processing error: {e}")
            return None

    def _apply_strategy(
        self,
        img: Image.Image,
        strategy: ProcessingStrategy
    ) -> Image.Image:
        """Apply processing strategy to image"""

        if strategy == ProcessingStrategy.PRESERVE:
            # Just return copy (metadata will be modified)
            return img.copy()

        elif strategy == ProcessingStrategy.SUBTLE_ADJUST:
            # Subtle brightness/contrast adjustment
            enhancer = ImageEnhance.Brightness(img)
            img = enhancer.enhance(1.02)  # Very subtle
            enhancer = ImageEnhance.Contrast(img)
            img = enhancer.enhance(1.01)
            return img

        elif strategy == ProcessingStrategy.BLUR_BACKGROUND:
            # Blur edges more than center (simulated background blur)
            # This is a simplified approach - real bg blur needs segmentation
            blurred = img.filter(ImageFilter.GaussianBlur(radius=2))

            # Create mask for center (product area)
            width, height = img.size
            mask = Image.new('L', (width, height), 0)

            # Simple elliptical mask
            from PIL import ImageDraw
            draw = ImageDraw.Draw(mask)
            margin_x = width // 6
            margin_y = height // 6
            draw.ellipse(
                [margin_x, margin_y, width - margin_x, height - margin_y],
                fill=255
            )

            # Blur the mask
            mask = mask.filter(ImageFilter.GaussianBlur(radius=30))

            # Composite
            return Image.composite(img, blurred, mask)

        elif strategy == ProcessingStrategy.VIGNETTE:
            # Add vignette effect
            width, height = img.size

            # Create radial gradient
            from PIL import ImageDraw
            vignette = Image.new('L', (width, height), 0)
            draw = ImageDraw.Draw(vignette)

            for i in range(min(width, height) // 2):
                alpha = int(255 * (1 - (i / (min(width, height) / 2)) ** 2))
                draw.ellipse(
                    [i, i, width - i, height - i],
                    fill=alpha
                )

            # Invert (dark edges)
            from PIL import ImageOps
            vignette = ImageOps.invert(vignette)

            # Apply with reduced opacity
            vignette_rgb = Image.new('RGB', (width, height), (0, 0, 0))

            return Image.composite(img, vignette_rgb, vignette)

        elif strategy == ProcessingStrategy.GRADIENT_REPLACE:
            # Subtle color temperature shift
            enhancer = ImageEnhance.Color(img)
            return enhancer.enhance(0.98)

        elif strategy == ProcessingStrategy.SOLID_REPLACE:
            # Slight saturation adjustment
            enhancer = ImageEnhance.Color(img)
            return enhancer.enhance(1.02)

        elif strategy == ProcessingStrategy.TEXTURE_OVERLAY:
            # Add subtle noise
            if img.mode != 'RGB':
                img = img.convert('RGB')

            if NUMPY_AVAILABLE:
                arr = np.array(img).astype(np.float32)
                noise = np.random.normal(0, 2, arr.shape)
                arr = np.clip(arr + noise, 0, 255).astype(np.uint8)
                return Image.fromarray(arr)

            return img

        return img

    def _modify_metadata(self, img: Image.Image) -> Image.Image:
        """Modify image metadata to create unique hash"""
        # Strip existing EXIF
        if img.info.get('exif'):
            # Create new image without EXIF
            data = list(img.getdata())
            new_img = Image.new(img.mode, img.size)
            new_img.putdata(data)
            return new_img

        return img

    # ========================================================================
    # QUEUE MANAGEMENT
    # ========================================================================

    def queue_image(self, image_path: str, product_id: int = None) -> int:
        """Queue image for processing"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        # Calculate original hash
        original_hash = None
        if os.path.exists(image_path):
            with open(image_path, 'rb') as f:
                original_hash = hashlib.md5(f.read()).hexdigest()

        cursor.execute("""
            INSERT INTO image_queue (image_path, product_id, original_hash)
            VALUES (?, ?, ?)
        """, (image_path, product_id, original_hash))

        item_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.logger.info(f"Queued image: {image_path} (ID: {item_id})")
        return item_id

    def _get_pending_items(self, limit: int = 10) -> List[Dict]:
        """Get pending items from queue"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, image_path, product_id, original_hash
            FROM image_queue
            WHERE status = 'pending'
            ORDER BY created_at
            LIMIT ?
        """, (limit,))

        rows = cursor.fetchall()
        conn.close()

        return [
            {
                'id': row[0],
                'image_path': row[1],
                'product_id': row[2],
                'original_hash': row[3]
            }
            for row in rows
        ]

    def _update_status(self, item_id: int, status: str):
        """Update item status"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE image_queue SET status = ? WHERE id = ?",
            (status, item_id)
        )
        conn.commit()
        conn.close()

    def _update_analysis(self, item_id: int, analysis: Dict):
        """Update with analysis results"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE image_queue
            SET scenario = ?, strategy = ?
            WHERE id = ?
        """, (analysis.get('scenario'), analysis.get('recommended_strategy'), item_id))
        conn.commit()
        conn.close()

    def _mark_completed(self, item_id: int, processed_path: str):
        """Mark item as completed"""
        # Calculate new hash
        processed_hash = None
        if os.path.exists(processed_path):
            with open(processed_path, 'rb') as f:
                processed_hash = hashlib.md5(f.read()).hexdigest()

        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE image_queue
            SET status = 'completed',
                processed_path = ?,
                processed_hash = ?,
                processed_at = datetime('now')
            WHERE id = ?
        """, (processed_path, processed_hash, item_id))
        conn.commit()
        conn.close()

    def _mark_failed(self, item_id: int, error: str):
        """Mark item as failed"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE image_queue
            SET status = 'failed',
                error_message = ?,
                processed_at = datetime('now')
            WHERE id = ?
        """, (error, item_id))
        conn.commit()
        conn.close()

    def get_queue_stats(self) -> Dict:
        """Get queue statistics"""
        conn = sqlite3.connect(self.queue_db)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT status, COUNT(*) as count
            FROM image_queue
            GROUP BY status
        """)

        stats = {row[0]: row[1] for row in cursor.fetchall()}
        conn.close()

        return {
            'pending': stats.get('pending', 0),
            'processing': stats.get('processing', 0),
            'completed': stats.get('completed', 0),
            'failed': stats.get('failed', 0),
            'total_analyzed': self.images_analyzed,
            'total_processed_this_session': self.images_processed
        }


# Test
if __name__ == "__main__":
    print("=" * 60)
    print("FOF IMAGE AGENT - TEST")
    print("=" * 60)
    print()

    agent = FOFImageAgent(interval_seconds=30)

    print("Available scenarios:")
    for scenario in ImageScenario:
        strategy = agent.scenario_strategies.get(scenario, ProcessingStrategy.SUBTLE_ADJUST)
        print(f"  {scenario.value}: {strategy.value}")

    print()
    print("Queue stats:")
    stats = agent.get_queue_stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")

    print()
    print("=" * 60)
    print("To use:")
    print("  # Analyze image")
    print("  analysis = agent.analyze_image('/path/to/image.jpg')")
    print()
    print("  # Process image")
    print("  result = agent.process_image('/path/to/image.jpg')")
    print()
    print("  # Run as background service")
    print("  agent.start()")
    print("=" * 60)
