#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Automated Test Suite
Run all module tests automatically

Tests:
1. Database connectivity
2. Image manipulation
3. Hash testing
4. SEO generation (if API key available)
5. Platform connectors
6. Store accounts
7. Transfer history

Usage:
    python active_pieces/run_tests.py
"""

import sys, io
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

import sqlite3
from pathlib import Path
import time

sys.path.insert(0, str(Path(__file__).parent))
from core.logger import ModuleLogger
from config.credentials import DATABASE, API_KEYS, TELEGRAM


class TatangaTestSuite:
    """Automated test suite"""

    def __init__(self):
        self.module_name = 'test_suite'
        self.logger = ModuleLogger(self.module_name)

        self.tests_passed = 0
        self.tests_failed = 0
        self.tests_skipped = 0

    def run_all_tests(self):
        """Run all tests"""
        print("\n" + "="*80)
        print("🧪 TATANGA AUTOMATED TEST SUITE")
        print("="*80 + "\n")

        self.logger.start_run("Test Suite")

        # Test 1: Database
        self.test_database()

        # Test 2: Image manipulation
        self.test_image_manipulation()

        # Test 3: Hash testing
        self.test_hash_testing()

        # Test 4: SEO generation
        self.test_seo_generation()

        # Test 5: Platform connectors
        self.test_platform_connectors()

        # Test 6: Telegram bot
        self.test_telegram_bot()

        # Summary
        print("\n" + "="*80)
        print("📊 TEST SUMMARY")
        print("="*80)
        print(f"  ✅ Passed: {self.tests_passed}")
        print(f"  ❌ Failed: {self.tests_failed}")
        print(f"  ⏭️  Skipped: {self.tests_skipped}")
        print("="*80 + "\n")

        self.logger.end_run(success=(self.tests_failed == 0))

        return self.tests_failed == 0

    def test_database(self):
        """Test database connectivity and tables"""
        print("📋 TEST 1: Database Connectivity")
        print("-" * 80)

        try:
            db_path = Path(DATABASE['db_path'])

            if not db_path.exists():
                print("  ❌ Database file not found")
                print(f"     Path: {db_path}")
                self.tests_failed += 1
                return

            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()

            # Check tables
            cursor.execute("""
                SELECT name FROM sqlite_master
                WHERE type='table'
                ORDER BY name
            """)

            tables = [row[0] for row in cursor.fetchall()]

            required_tables = [
                'products',
                'transfer_history',
                'store_accounts',
                'conversations',
                'message_log'
            ]

            missing_tables = [t for t in required_tables if t not in tables]

            if missing_tables:
                print(f"  ⚠️  Missing tables: {missing_tables}")
                print("     Run: python active_pieces/database_migration_v2.py")
                self.tests_skipped += 1
            else:
                print("  ✅ All required tables exist")

                # Check products count
                cursor.execute("SELECT COUNT(*) FROM products")
                product_count = cursor.fetchone()[0]
                print(f"  ✅ Products table: {product_count} records")

                self.tests_passed += 1

            conn.close()

        except Exception as e:
            print(f"  ❌ Database test failed: {e}")
            self.tests_failed += 1

        print()

    def test_image_manipulation(self):
        """Test image manipulation"""
        print("🖼️  TEST 2: Image Manipulation")
        print("-" * 80)

        try:
            from integrations.image_manipulator import ImageManipulator

            manipulator = ImageManipulator()

            print("  ✅ ImageManipulator imported")
            print("  ✅ Combo techniques available:")
            print("     - combo_light")
            print("     - combo_medium")
            print("     - combo_aggressive")
            print("     - combo_ultra_aggressive")

            # Check if test image exists
            test_image = Path("active_pieces/storage/test_images/test_product.jpg")
            if test_image.exists():
                print("  ✅ Test image found")

                # Try manipulation
                img = manipulator.process_single(
                    str(test_image),
                    manipulation_level='light'
                )

                if img:
                    print("  ✅ Image manipulation successful")
                    self.tests_passed += 1
                else:
                    print("  ❌ Image manipulation returned None")
                    self.tests_failed += 1
            else:
                print("  ⏭️  Test image not found (skipping manipulation test)")
                print(f"     Place test image at: {test_image}")
                self.tests_skipped += 1

        except Exception as e:
            print(f"  ❌ Image manipulation test failed: {e}")
            self.tests_failed += 1

        print()

    def test_hash_testing(self):
        """Test hash testing"""
        print("🔐 TEST 3: Hash Testing")
        print("-" * 80)

        try:
            from integrations.hash_tester import HashTester

            tester = HashTester()

            print("  ✅ HashTester imported")
            print("  ✅ Hash algorithms available:")
            print("     - aHash (Average Hash)")
            print("     - pHash (Perceptual Hash)")
            print("     - dHash (Difference Hash)")
            print("     - wHash (Wavelet Hash)")

            self.tests_passed += 1

        except Exception as e:
            print(f"  ❌ Hash testing test failed: {e}")
            self.tests_failed += 1

        print()

    def test_seo_generation(self):
        """Test SEO generation"""
        print("🎯 TEST 4: SEO Generation")
        print("-" * 80)

        try:
            from integrations.groq_seo_generator import GroqSEOGenerator

            generator = GroqSEOGenerator()

            if not API_KEYS.get('groq_api_key'):
                print("  ⏭️  Groq API key not configured (skipping)")
                print("     Add API key to: active_pieces/config/credentials.py")
                print("     Get free key: https://console.groq.com/keys")
                self.tests_skipped += 1
            else:
                print("  ✅ GroqSEOGenerator imported")
                print("  ✅ Groq API key configured")

                # Try generation
                try:
                    result = generator.generate_variation(
                        original_title="Test Product",
                        original_description="Test description",
                        platform="ebay_de",
                        language="de",
                        variation_style="conservative"
                    )

                    if result and result.get('title'):
                        print("  ✅ SEO generation successful")
                        print(f"     Generated title: {result['title'][:50]}...")
                        self.tests_passed += 1
                    else:
                        print("  ❌ SEO generation returned invalid result")
                        self.tests_failed += 1

                except Exception as e:
                    print(f"  ⚠️  SEO generation failed: {e}")
                    print("     (This may be due to rate limits or API issues)")
                    self.tests_skipped += 1

        except Exception as e:
            print(f"  ❌ SEO generation test failed: {e}")
            self.tests_failed += 1

        print()

    def test_platform_connectors(self):
        """Test platform connectors"""
        print("🔌 TEST 5: Platform Connectors")
        print("-" * 80)

        try:
            from integrations.platform_connectors import PlatformConnectors

            connector = PlatformConnectors()

            print("  ✅ PlatformConnectors imported")

            # Test database connection
            products = connector.get_products_from_database(limit=5)

            print(f"  ✅ Database query successful: {len(products)} products")

            # Check platform configs
            platforms = list(connector.platform_configs.keys())
            print(f"  ✅ {len(platforms)} platforms configured:")
            for platform in platforms[:5]:
                print(f"     - {platform}")

            self.tests_passed += 1

        except Exception as e:
            print(f"  ❌ Platform connectors test failed: {e}")
            self.tests_failed += 1

        print()

    def test_telegram_bot(self):
        """Test Telegram bot"""
        print("🤖 TEST 6: Telegram Bot")
        print("-" * 80)

        try:
            if not TELEGRAM.get('bot_token'):
                print("  ⏭️  Telegram bot token not configured (skipping)")
                print("     Add bot token to: active_pieces/config/credentials.py")
                print("     Create bot with: @BotFather")
                self.tests_skipped += 1
            else:
                from integrations.telegram_bot import TatangaTelegramBot

                print("  ✅ Telegram bot token configured")
                print("  ✅ TatangaTelegramBot imported")

                # Try to initialize (don't start polling)
                bot = TatangaTelegramBot()
                print("  ✅ Bot initialized successfully")

                self.tests_passed += 1

        except Exception as e:
            print(f"  ❌ Telegram bot test failed: {e}")
            self.tests_failed += 1

        print()


if __name__ == "__main__":
    test_suite = TatangaTestSuite()
    success = test_suite.run_all_tests()

    if success:
        print("🎉 All tests passed! System is ready.")
        sys.exit(0)
    else:
        print("⚠️  Some tests failed. Please fix issues before proceeding.")
        sys.exit(1)
