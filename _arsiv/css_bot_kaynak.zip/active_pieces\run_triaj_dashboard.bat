@echo off
echo ============================================
echo TATANGA Triaj Merkezi Dashboard
echo ============================================
echo.

cd /d "%~dp0"

echo Checking dependencies...
pip install streamlit pandas -q

echo.
echo Starting Streamlit Dashboard...
echo URL: http://localhost:8501
echo.

streamlit run ui/triaj_dashboard.py --server.port 8501

pause
