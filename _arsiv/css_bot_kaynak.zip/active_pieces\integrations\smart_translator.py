#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SMART TRANSLATOR - AI-Powered Multilingual Translation System
Automatic keyword and listing translation for cross-platform operations

Features:
- Auto-detect source language
- Translate to platform's native language
- Context-aware translation (search vs listing)
- SQLite-based caching for performance
- Groq AI integration for quality translations
- Brand name preservation
- SEO optimization

Author: TATANGA Team
Version: 1.0
"""

import sys
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta
import json
import hashlib
from typing import Dict, Optional, List

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from groq import Groq
except ImportError:
    Groq = None
    print("Warning: groq not installed. Run: pip install groq")

from config.credentials import API_KEYS, PLATFORM_LANGUAGES

# Extended language support for Nordic countries
EXTENDED_LANGUAGES = {
    **PLATFORM_LANGUAGES,
    # Nordic platforms (Vend/Schibsted group)
    'finn_no': 'no',        # Norwegian
    'blocket_se': 'sv',     # Swedish
    'tori_fi': 'fi',        # Finnish
    'dba_dk': 'da',         # Danish
    # Shpock
    'shpock_de': 'de',
    'shpock_at': 'de',
    'shpock_uk': 'en',
    # Vinted extensions
    'vinted_de': 'de',
    'vinted_no': 'no',
    'vinted_dk': 'da',
    'vinted_it': 'it',
}

class SmartTranslator:
    """
    AI-powered smart translation for cross-platform e-commerce operations

    Usage:
        translator = SmartTranslator(groq_api_key)

        # Translate search keywords
        swedish = translator.translate_for_search(
            keywords="Nike Schuhe rot",
            source_platform="ebay_de",
            target_platform="tradera"
        )

        # Translate product listing
        result = translator.translate_for_listing(
            title="Nike Air Max - Rot - Größe 42",
            description="Schöne Schuhe in gutem Zustand",
            target_platform="tradera"
        )
    """

    def __init__(self, groq_api_key: str = None):
        """
        Initialize Smart Translator

        Args:
            groq_api_key: Groq API key for AI translations
        """
        # API key
        self.groq_api_key = groq_api_key or API_KEYS.get('groq_api_key')

        if not self.groq_api_key or self.groq_api_key == 'gsk_xxx':
            print("WARNING: No valid Groq API key! Translations will fail.")
            print("Please set groq_api_key in config/credentials.py")
            self.groq = None
        else:
            try:
                self.groq = Groq(api_key=self.groq_api_key)
            except Exception as e:
                print(f"ERROR: Failed to initialize Groq: {e}")
                self.groq = None

        # Platform language mapping (with extended support)
        self.platform_languages = {**PLATFORM_LANGUAGES, **EXTENDED_LANGUAGES}

        # Cache setup
        self.cache_dir = Path(__file__).parent.parent / 'storage'
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_db = self.cache_dir / 'translation_cache.db'
        self._init_cache_db()

        # Stats
        self.stats = {
            'translations_total': 0,
            'translations_cached': 0,
            'translations_api': 0,
            'errors': 0
        }

        # Language detection patterns
        self.language_patterns = {
            'tr': ['için', 'ile', 'veya', 'gibi', 've', 'bir', 'ürün', 'fiyat', 'satış', 'ayakkabı', 'gömlek', 'çanta', 'elbise'],
            'de': ['und', 'für', 'oder', 'mit', 'sehr', 'gut', 'zustand', 'größe', 'schuhe', 'jacke', 'hemd', 'tasche', 'neu', 'gebraucht'],
            'en': ['and', 'for', 'with', 'size', 'shoes', 'shirt', 'bag', 'dress', 'condition', 'new', 'used', 'the', 'this'],
            'fr': ['pour', 'avec', 'très', 'bon', 'état', 'taille', 'chaussures', 'chemise', 'sac', 'robe', 'neuf', 'occasion'],
            'sv': ['och', 'för', 'med', 'storlek', 'skor', 'väska', 'klänning', 'skjorta', 'bra', 'skick', 'ny', 'begagnad'],
            'no': ['og', 'for', 'med', 'størrelse', 'sko', 'veske', 'kjole', 'skjorte', 'god', 'stand', 'ny', 'brukt'],
            'da': ['og', 'for', 'med', 'størrelse', 'sko', 'taske', 'kjole', 'skjorte', 'god', 'stand', 'ny', 'brugt'],
            'fi': ['ja', 'kanssa', 'koko', 'kengät', 'laukku', 'mekko', 'paita', 'hyvä', 'kunto', 'uusi', 'käytetty'],
            'it': ['per', 'con', 'molto', 'buono', 'stato', 'taglia', 'scarpe', 'borsa', 'vestito', 'camicia', 'nuovo', 'usato'],
            'es': ['para', 'con', 'muy', 'bueno', 'estado', 'talla', 'zapatos', 'bolso', 'vestido', 'camisa', 'nuevo', 'usado'],
            'nl': ['en', 'voor', 'met', 'maat', 'schoenen', 'tas', 'jurk', 'overhemd', 'goed', 'staat', 'nieuw', 'gebruikt'],
            'pl': ['i', 'dla', 'z', 'rozmiar', 'buty', 'torba', 'sukienka', 'koszula', 'dobry', 'stan', 'nowy', 'używany'],
        }

    def detect_language(self, text: str) -> str:
        """
        Auto-detect language of input text

        Args:
            text: Input text to analyze

        Returns:
            Language code (e.g., 'de', 'tr', 'en')
        """
        if not text:
            return 'de'  # Default to German

        text_lower = text.lower()
        words = text_lower.split()

        # Count matches for each language
        scores = {}
        for lang, patterns in self.language_patterns.items():
            score = sum(1 for word in words if word in patterns)
            # Also check for partial matches
            for pattern in patterns:
                if pattern in text_lower:
                    score += 0.5
            scores[lang] = score

        # Return language with highest score
        if scores:
            best_lang = max(scores, key=scores.get)
            if scores[best_lang] > 0:
                return best_lang

        # Fallback: check for special characters
        if any(c in text for c in 'çğıöşüÇĞİÖŞÜ'):
            return 'tr'
        if any(c in text for c in 'äöüßÄÖÜ'):
            return 'de'
        if any(c in text for c in 'åäöÅÄÖ'):
            return 'sv'
        if any(c in text for c in 'æøåÆØÅ'):
            return 'no'

        return 'de'  # Default to German

    def translate_keyword_smart(
        self,
        keyword: str,
        target_platforms: List[str]
    ) -> Dict[str, str]:
        """
        Smart keyword translation with auto language detection

        Args:
            keyword: Search keyword in any language (TR/EN/DE/etc)
            target_platforms: List of target platforms

        Returns:
            Dictionary mapping platform to translated keyword:
            {
                'vinted_de': 'Lederjacke',
                'vinted_fr': 'veste en cuir',
                'ebay_uk': 'leather jacket'
            }

        Example:
            >>> translator.translate_keyword_smart(
            ...     "deri ceket",  # Turkish
            ...     ["vinted_de", "vinted_fr", "ebay_uk"]
            ... )
            {'vinted_de': 'Lederjacke', 'vinted_fr': 'veste en cuir', 'ebay_uk': 'leather jacket'}
        """
        self.stats['translations_total'] += 1

        # Auto-detect source language
        source_lang = self.detect_language(keyword)
        print(f"[SmartTranslator] Detected language: {source_lang} for '{keyword}'")

        results = {}

        for platform in target_platforms:
            target_lang = self.get_platform_language(platform)

            # No translation needed if same language
            if source_lang == target_lang:
                results[platform] = keyword
                continue

            # Check cache
            cache_key = self._generate_cache_key(
                keyword, source_lang, target_lang, 'keyword'
            )
            cached = self._get_from_cache(cache_key)
            if cached:
                self.stats['translations_cached'] += 1
                results[platform] = cached
                continue

            # Translate via AI
            try:
                translated = self._translate_keyword_ai(keyword, source_lang, target_lang)
                self._save_to_cache(
                    cache_key, keyword, source_lang, target_lang, 'keyword', translated
                )
                self.stats['translations_api'] += 1
                results[platform] = translated
            except Exception as e:
                print(f"Translation error for {platform}: {e}")
                self.stats['errors'] += 1
                results[platform] = keyword  # Fallback to original

        return results

    def _translate_keyword_ai(
        self,
        keyword: str,
        source_lang: str,
        target_lang: str
    ) -> str:
        """Translate keyword using Groq AI"""
        if not self.groq:
            return keyword

        lang_names = {
            'de': 'German', 'en': 'English', 'fr': 'French',
            'sv': 'Swedish', 'pl': 'Polish', 'es': 'Spanish',
            'nl': 'Dutch', 'cs': 'Czech', 'it': 'Italian',
            'tr': 'Turkish', 'no': 'Norwegian', 'da': 'Danish',
            'fi': 'Finnish'
        }

        source_name = lang_names.get(source_lang, source_lang)
        target_name = lang_names.get(target_lang, target_lang)

        prompt = f"""Translate this e-commerce search keyword from {source_name} to {target_name}.

Rules:
1. Keep brand names unchanged (Nike, Adidas, Gucci, etc.)
2. Keep product numbers unchanged
3. Use common local terms for clothing/fashion
4. Be concise - this is a search query
5. Return ONLY the translated keyword, nothing else

Keyword: {keyword}
Translated:"""

        response = self.groq.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=50
        )

        return response.choices[0].message.content.strip().strip('"\'')

    def _init_cache_db(self):
        """Initialize translation cache database"""
        conn = sqlite3.connect(self.cache_db)
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS translation_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cache_key TEXT UNIQUE NOT NULL,
                source_text TEXT NOT NULL,
                source_lang TEXT NOT NULL,
                target_lang TEXT NOT NULL,
                translation_type TEXT NOT NULL,
                translated_text TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_used DATETIME DEFAULT CURRENT_TIMESTAMP,
                use_count INTEGER DEFAULT 1
            )
        """)

        # Index for fast lookup
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_cache_key
            ON translation_cache(cache_key)
        """)

        conn.commit()
        conn.close()

    def get_platform_language(self, platform: str) -> str:
        """
        Get native language code for platform

        Args:
            platform: Platform identifier (e.g., 'ebay_de', 'tradera')

        Returns:
            Language code (e.g., 'de', 'sv', 'en')
        """
        return self.platform_languages.get(platform, 'de')

    def needs_translation(self, source_platform: str, target_platform: str) -> bool:
        """
        Check if translation is needed between platforms

        Args:
            source_platform: Source platform identifier
            target_platform: Target platform identifier

        Returns:
            True if platforms use different languages
        """
        source_lang = self.get_platform_language(source_platform)
        target_lang = self.get_platform_language(target_platform)
        return source_lang != target_lang

    def translate_for_search(
        self,
        keywords: str,
        source_platform: str,
        target_platform: str
    ) -> str:
        """
        Translate search keywords from source to target platform language
        Optimized for e-commerce search queries

        Args:
            keywords: Search keywords (e.g., "Nike Schuhe rot Größe 42")
            source_platform: Source platform (e.g., "ebay_de")
            target_platform: Target platform (e.g., "tradera")

        Returns:
            Translated keywords (e.g., "Nike skor röda storlek 42")

        Example:
            >>> translator.translate_for_search(
            ...     "Nike Schuhe rot Größe 42",
            ...     "ebay_de",
            ...     "tradera"
            ... )
            "Nike skor röda storlek 42"
        """
        self.stats['translations_total'] += 1

        # Get languages
        source_lang = self.get_platform_language(source_platform)
        target_lang = self.get_platform_language(target_platform)

        # No translation needed if same language
        if source_lang == target_lang:
            return keywords

        # Check cache
        cache_key = self._generate_cache_key(
            keywords, source_lang, target_lang, 'search'
        )

        cached = self._get_from_cache(cache_key)
        if cached:
            self.stats['translations_cached'] += 1
            return cached

        # Translate via AI
        try:
            translated = self._translate_search_ai(keywords, source_lang, target_lang)

            # Save to cache
            self._save_to_cache(
                cache_key, keywords, source_lang, target_lang, 'search', translated
            )

            self.stats['translations_api'] += 1
            return translated

        except Exception as e:
            print(f"Translation error: {e}")
            self.stats['errors'] += 1
            # Fallback: return original
            return keywords

    def translate_for_listing(
        self,
        title: str,
        description: str,
        target_platform: str,
        source_platform: str = 'ebay_de'
    ) -> Dict[str, str]:
        """
        Translate product listing (title + description) for target platform
        SEO-optimized for e-commerce platforms

        Args:
            title: Product title
            description: Product description
            target_platform: Target platform (e.g., "tradera", "leboncoin")
            source_platform: Source platform (default: "ebay_de")

        Returns:
            Dictionary with translated title and description:
            {
                'title': 'Translated title',
                'description': 'Translated description',
                'source_lang': 'de',
                'target_lang': 'sv'
            }

        Example:
            >>> result = translator.translate_for_listing(
            ...     title="Nike Air Max 90 - Rot - Größe 42",
            ...     description="Schöne Nike Schuhe...",
            ...     target_platform="tradera"
            ... )
            >>> result['title']
            "Nike Air Max 90 - Röda - Storlek 42"
        """
        self.stats['translations_total'] += 1

        # Get languages
        source_lang = self.get_platform_language(source_platform)
        target_lang = self.get_platform_language(target_platform)

        # No translation needed if same language
        if source_lang == target_lang:
            return {
                'title': title,
                'description': description,
                'source_lang': source_lang,
                'target_lang': target_lang
            }

        # Check cache (for title only - descriptions may be too long)
        cache_key = self._generate_cache_key(
            title, source_lang, target_lang, 'listing'
        )

        cached = self._get_from_cache(cache_key)
        if cached:
            self.stats['translations_cached'] += 1
            # Parse cached result
            try:
                result = json.loads(cached)
                return result
            except:
                pass

        # Translate via AI
        try:
            result = self._translate_listing_ai(
                title, description, source_lang, target_lang, target_platform
            )

            # Save to cache
            self._save_to_cache(
                cache_key, title, source_lang, target_lang, 'listing',
                json.dumps(result)
            )

            self.stats['translations_api'] += 1
            return result

        except Exception as e:
            print(f"Listing translation error: {e}")
            self.stats['errors'] += 1
            # Fallback: return original
            return {
                'title': title,
                'description': description,
                'source_lang': source_lang,
                'target_lang': target_lang,
                'error': str(e)
            }

    def _translate_search_ai(
        self,
        keywords: str,
        source_lang: str,
        target_lang: str
    ) -> str:
        """Translate search keywords using Groq AI"""

        if not self.groq:
            raise Exception("Groq API not initialized")

        # Language names for prompt
        lang_names = {
            'de': 'German', 'en': 'English', 'fr': 'French',
            'sv': 'Swedish', 'pl': 'Polish', 'es': 'Spanish',
            'nl': 'Dutch', 'cs': 'Czech'
        }

        source_lang_name = lang_names.get(source_lang, source_lang)
        target_lang_name = lang_names.get(target_lang, target_lang)

        prompt = f"""Translate these e-commerce search keywords from {source_lang_name} to {target_lang_name}.

Important rules:
1. Keep brand names unchanged (Nike, Adidas, etc.)
2. Keep product numbers unchanged
3. Optimize for product search
4. Be concise and natural
5. Return ONLY the translated keywords, nothing else

Original keywords: {keywords}

Translated keywords:"""

        response = self.groq.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=150
        )

        translated = response.choices[0].message.content.strip()

        # Clean up response (remove quotes, extra whitespace)
        translated = translated.strip('"\'')

        return translated

    def _translate_listing_ai(
        self,
        title: str,
        description: str,
        source_lang: str,
        target_lang: str,
        target_platform: str
    ) -> Dict[str, str]:
        """Translate product listing using Groq AI"""

        if not self.groq:
            raise Exception("Groq API not initialized")

        # Language names for prompt
        lang_names = {
            'de': 'German', 'en': 'English', 'fr': 'French',
            'sv': 'Swedish', 'pl': 'Polish', 'es': 'Spanish',
            'nl': 'Dutch', 'cs': 'Czech'
        }

        source_lang_name = lang_names.get(source_lang, source_lang)
        target_lang_name = lang_names.get(target_lang, target_lang)

        prompt = f"""Translate this product listing from {source_lang_name} to {target_lang_name} for the platform: {target_platform}

Important rules:
1. Keep brand names unchanged
2. Keep product numbers and sizes unchanged
3. Make it natural and SEO-friendly for {target_lang_name} speakers
4. Preserve the style and tone
5. Return ONLY valid JSON, nothing else

Title: {title}

Description: {description}

Return JSON format:
{{
    "title": "translated title",
    "description": "translated description"
}}"""

        response = self.groq.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=1000
        )

        content = response.choices[0].message.content.strip()

        # Try to parse JSON
        try:
            # Remove markdown code blocks if present
            if '```json' in content:
                content = content.split('```json')[1].split('```')[0].strip()
            elif '```' in content:
                content = content.split('```')[1].split('```')[0].strip()

            result = json.loads(content)

            # Add metadata
            result['source_lang'] = source_lang
            result['target_lang'] = target_lang
            result['target_platform'] = target_platform

            return result

        except json.JSONDecodeError as e:
            # Fallback: try to extract title and description manually
            print(f"JSON parse error: {e}")
            print(f"Content: {content}")

            # Simple fallback
            return {
                'title': title,  # Use original
                'description': description,  # Use original
                'source_lang': source_lang,
                'target_lang': target_lang,
                'error': 'JSON parse failed'
            }

    def _generate_cache_key(
        self,
        text: str,
        source_lang: str,
        target_lang: str,
        translation_type: str
    ) -> str:
        """Generate unique cache key for translation"""
        data = f"{text}|{source_lang}|{target_lang}|{translation_type}"
        return hashlib.md5(data.encode()).hexdigest()

    def _get_from_cache(self, cache_key: str) -> Optional[str]:
        """Get translation from cache"""
        try:
            conn = sqlite3.connect(self.cache_db)
            cursor = conn.cursor()

            # Get from cache (if not expired)
            cursor.execute("""
                SELECT translated_text
                FROM translation_cache
                WHERE cache_key = ?
                AND datetime(created_at, '+30 days') > datetime('now')
            """, (cache_key,))

            row = cursor.fetchone()

            if row:
                # Update last_used and use_count
                cursor.execute("""
                    UPDATE translation_cache
                    SET last_used = datetime('now'),
                        use_count = use_count + 1
                    WHERE cache_key = ?
                """, (cache_key,))
                conn.commit()
                conn.close()

                return row[0]

            conn.close()
            return None

        except Exception as e:
            print(f"Cache read error: {e}")
            return None

    def _save_to_cache(
        self,
        cache_key: str,
        source_text: str,
        source_lang: str,
        target_lang: str,
        translation_type: str,
        translated_text: str
    ):
        """Save translation to cache"""
        try:
            conn = sqlite3.connect(self.cache_db)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT OR REPLACE INTO translation_cache
                (cache_key, source_text, source_lang, target_lang,
                 translation_type, translated_text)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (cache_key, source_text, source_lang, target_lang,
                  translation_type, translated_text))

            conn.commit()
            conn.close()

        except Exception as e:
            print(f"Cache write error: {e}")

    def get_stats(self) -> Dict:
        """Get translation statistics"""
        cache_hit_rate = 0
        if self.stats['translations_total'] > 0:
            cache_hit_rate = (self.stats['translations_cached'] /
                            self.stats['translations_total']) * 100

        return {
            **self.stats,
            'cache_hit_rate_percent': round(cache_hit_rate, 2)
        }

    def clear_cache(self, older_than_days: int = 30):
        """Clear old cache entries"""
        try:
            conn = sqlite3.connect(self.cache_db)
            cursor = conn.cursor()

            cursor.execute("""
                DELETE FROM translation_cache
                WHERE datetime(created_at, ? || ' days') < datetime('now')
            """, (f'+{older_than_days}',))

            deleted = cursor.rowcount
            conn.commit()
            conn.close()

            return deleted

        except Exception as e:
            print(f"Cache clear error: {e}")
            return 0


# Test / Example usage
if __name__ == "__main__":
    print("="*60)
    print("SMART TRANSLATOR - TEST")
    print("="*60)
    print()

    # Initialize
    translator = SmartTranslator()

    if not translator.groq:
        print("ERROR: Groq API not initialized!")
        print("Please set your Groq API key in config/credentials.py")
        sys.exit(1)

    print("✓ Translator initialized")
    print()

    # Test 1: Search translation (German → Swedish)
    print("TEST 1: Search Translation (DE → SV)")
    print("-" * 40)
    keywords_de = "Nike Schuhe rot Größe 42"
    print(f"Original (DE): {keywords_de}")

    translated_sv = translator.translate_for_search(
        keywords_de,
        'ebay_de',
        'tradera'
    )
    print(f"Translated (SV): {translated_sv}")
    print()

    # Test 2: Listing translation (German → French)
    print("TEST 2: Listing Translation (DE → FR)")
    print("-" * 40)
    title_de = "Nike Air Max 90 - Rot - Größe 42 - Neuwertig"
    desc_de = "Schöne Nike Schuhe in gutem Zustand. Kaum getragen."

    print(f"Original Title (DE): {title_de}")
    print(f"Original Desc (DE): {desc_de}")
    print()

    result = translator.translate_for_listing(
        title_de,
        desc_de,
        'leboncoin'
    )

    print(f"Translated Title (FR): {result['title']}")
    print(f"Translated Desc (FR): {result['description']}")
    print()

    # Test 3: No translation needed (same language)
    print("TEST 3: Same Language (DE → DE)")
    print("-" * 40)
    print("Should return original without API call...")

    result_de = translator.translate_for_search(
        "Test keywords",
        'ebay_de',
        'kleinanzeigen'
    )
    print(f"Result: {result_de}")
    print()

    # Stats
    print("TRANSLATION STATS:")
    print("-" * 40)
    stats = translator.get_stats()
    for key, value in stats.items():
        print(f"{key}: {value}")
    print()

    print("="*60)
    print("✓ All tests completed!")
    print("="*60)
