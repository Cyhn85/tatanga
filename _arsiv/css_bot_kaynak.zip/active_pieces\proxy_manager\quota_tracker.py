# Proxy Quota Tracker - SQLite based quota management
# Tracks usage across all proxy services

import sqlite3
import os
from datetime import datetime, timedelta
from config import DB_PATH, PROXY_SERVICES, ROTATION_CONFIG

class QuotaTracker:
    def __init__(self):
        self.db_path = DB_PATH
        self._init_db()

    def _init_db(self):
        """Initialize quota tracking database"""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()

        # Quota usage table
        c.execute('''CREATE TABLE IF NOT EXISTS quota_usage (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            service TEXT NOT NULL,
            used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            store_id TEXT,
            request_type TEXT,
            success INTEGER DEFAULT 1
        )''')

        # Service status table
        c.execute('''CREATE TABLE IF NOT EXISTS service_status (
            service TEXT PRIMARY KEY,
            enabled INTEGER DEFAULT 1,
            last_check TIMESTAMP,
            last_success TIMESTAMP,
            fail_count INTEGER DEFAULT 0,
            notes TEXT
        )''')

        # Daily/Monthly reset tracking
        c.execute('''CREATE TABLE IF NOT EXISTS quota_resets (
            service TEXT PRIMARY KEY,
            last_daily_reset DATE,
            last_monthly_reset TEXT
        )''')

        conn.commit()
        conn.close()
        print(f'[OK] QuotaTracker DB: {self.db_path}')

    def record_usage(self, service: str, store_id: str = None, success: bool = True):
        """Record a proxy usage"""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute('''INSERT INTO quota_usage (service, store_id, success)
                     VALUES (?, ?, ?)''', (service, store_id, 1 if success else 0))
        conn.commit()
        conn.close()

    def get_usage_count(self, service: str, period: str = 'daily') -> int:
        """Get usage count for a service in given period"""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()

        if period == 'daily':
            # Today's usage
            today = datetime.now().strftime('%Y-%m-%d')
            c.execute('''SELECT COUNT(*) FROM quota_usage
                        WHERE service = ? AND date(used_at) = ?''', (service, today))
        elif period == 'monthly':
            # This month's usage
            month_start = datetime.now().strftime('%Y-%m-01')
            c.execute('''SELECT COUNT(*) FROM quota_usage
                        WHERE service = ? AND date(used_at) >= ?''', (service, month_start))
        else:
            # All time
            c.execute('SELECT COUNT(*) FROM quota_usage WHERE service = ?', (service,))

        count = c.fetchone()[0]
        conn.close()
        return count

    def get_remaining_quota(self, service: str) -> dict:
        """Get remaining quota for a service"""
        if service not in PROXY_SERVICES:
            return {'error': 'Unknown service'}

        config = PROXY_SERVICES[service]
        quota_limit = config.get('quota_limit', 0)
        quota_type = config.get('quota_type', 'daily')

        if quota_type == 'unlimited':
            return {
                'service': service,
                'limit': 999999,
                'used': self.get_usage_count(service, 'daily'),
                'remaining': 999999,
                'percentage': 100,
                'type': 'unlimited'
            }

        period = 'daily' if quota_type == 'daily' else 'monthly'
        used = self.get_usage_count(service, period)
        remaining = max(0, quota_limit - used)
        percentage = (remaining / quota_limit * 100) if quota_limit > 0 else 0

        return {
            'service': service,
            'limit': quota_limit,
            'used': used,
            'remaining': remaining,
            'percentage': round(percentage, 1),
            'type': quota_type
        }

    def get_all_quotas(self) -> list:
        """Get quota status for all enabled services"""
        quotas = []
        for service, config in PROXY_SERVICES.items():
            if config.get('enabled', False):
                quota = self.get_remaining_quota(service)
                quota['quality'] = config.get('quality', 3)
                quota['proxy_type'] = config.get('type', 'unknown')
                quotas.append(quota)
        return sorted(quotas, key=lambda x: -x['quality'])

    def should_switch(self, current_service: str) -> bool:
        """Check if we should switch to another service"""
        quota = self.get_remaining_quota(current_service)
        threshold = ROTATION_CONFIG.get('auto_switch_threshold', 7)
        return quota['percentage'] <= threshold

    def get_best_available(self, preferred_type: str = None) -> str:
        """Get best available proxy service based on quota and quality"""
        quotas = self.get_all_quotas()
        threshold = ROTATION_CONFIG.get('auto_switch_threshold', 7)

        # Filter by preferred type if specified
        if preferred_type:
            type_matched = [q for q in quotas if q['proxy_type'] == preferred_type]
            if type_matched:
                quotas = type_matched

        # Find first service with enough quota
        for quota in quotas:
            if quota['percentage'] > threshold:
                return quota['service']

        # Fallback: return any service with remaining quota
        for quota in quotas:
            if quota['remaining'] > 0:
                return quota['service']

        # Last resort: return first in fallback order
        fallback = ROTATION_CONFIG.get('fallback_order', [])
        for service in fallback:
            if service in PROXY_SERVICES and PROXY_SERVICES[service].get('enabled'):
                return service

        return None

    def get_dashboard_summary(self) -> dict:
        """Get summary for dashboard display"""
        quotas = self.get_all_quotas()

        total_remaining = sum(q['remaining'] for q in quotas if q['type'] != 'unlimited')
        total_limit = sum(q['limit'] for q in quotas if q['type'] != 'unlimited')

        low_quota_services = [q['service'] for q in quotas if q['percentage'] <= 20]

        return {
            'services': quotas,
            'total_remaining': total_remaining,
            'total_limit': total_limit,
            'overall_percentage': round(total_remaining / total_limit * 100, 1) if total_limit > 0 else 0,
            'low_quota_warnings': low_quota_services,
            'best_available': self.get_best_available(),
            'updated_at': datetime.now().isoformat()
        }


# Singleton instance
_tracker = None

def get_tracker() -> QuotaTracker:
    global _tracker
    if _tracker is None:
        _tracker = QuotaTracker()
    return _tracker


if __name__ == '__main__':
    # Test
    tracker = get_tracker()
    print('\n=== QUOTA STATUS ===')
    for q in tracker.get_all_quotas():
        print(f"{q['service']}: {q['remaining']}/{q['limit']} ({q['percentage']}%)")
