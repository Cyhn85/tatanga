#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Telegram Tanitim Mesaji
Tum ajanlari kullaniciya tanitir
"""

import requests

BOT_TOKEN = "8222444116:AAG5D2xc7-7EOGYIX1s0Tx0jM2m5nOWG1dw"
CHAT_ID = "5149567290"

MESSAGE = """🤖 *TATANGA ENTERPRISE - AJAN SİSTEMİ TANITIMI*

Merhaba! Ben TATANGA Enterprise sisteminin AI yöneticisiyim.
Sizin için 7/24 çalışan *30 adet otonom ajan* bulunuyor:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎯 *KOMUTA MERKEZİ*
• `CEOAgent` - Tüm sistemi yöneten merkezi beyin
• `AgentOrchestrator` - Agent koordinasyonu

📊 *YÖNETİCİLER (5 Müdür)*
• `ScrapingManager` - 36 platform kazıma koordinasyonu
• `SalesManager` - Satış, favori, fiyat yönetimi
• `CommunicationManager` - Mesajlaşma, yorumlar
• `LogisticsManager` - Kargo, takip, teslimat
• `AccountingManager` - Muhasebe, faturalar, raporlar

🔍 *PHASE 2 - ARBİTRAJ SİSTEMİ*
• `ConditionNormalizationAgent` - 12 dil durum puanlama
• `FilteringAgent` - Kâr/Risk hesaplama
• `BenchmarkService` - Referans fiyat analizi

🛡️ *DESTEK AJANLARI*
• `VisionAgent` - AI görsel analiz (GPT-4V/Claude)
• `SelfHealingSystem` - Otomatik hata düzeltme
• `TelegramBot` - Uzaktan kontrol

🏭 *FABRİKA AJANLARI (24/7 Çalışan)*
• `TranslatorAgent` - 7/24 çeviri işçisi
• `FOFImageAgent` - Görsel optimizasyon
• `ScreenshotAgent` - Ekran görüntüsü analizi
• `CargoAgent` - Kargo takibi (8 firma)
• `LearningEngine` - Öz-öğrenme motoru
• `MobileFarmManager` - Android çiftliği
• `InboxAgent` - Gelen mesaj takibi
• `OutboxAgent` - Giden mesaj kuyruğu
• `StoreAgent` - Mağaza bildirimleri
• `PlatformAgent` - Platform olayları
• `AccountantAgent` - Muhasebe işlemleri

🎬 *VIDEOCU AJANLARI*
• `CEOAgent (Video)` - Video üretim hattı
• `VideoProducerAgent` - Video oluşturma
• `SocialMediaAgent` - Sosyal medya yayını
• `MusicComposerAgent` - Müzik kompozisyonu
• `ServerAdminAgent` - Sunucu izleme

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📍 *TELEGRAM KOMUTLARI:*
/status - Sistem durumu
/health - Sağlık kontrolü
/arbitraj - Arbitraj araması
/inbox - Onay bekleyenler
/favorites - Favoriler
/sales - Satış raporu
/help - Tüm komutlar

🚀 *Sistem aktif ve çalışıyor!*

_TATANGA Enterprise v2.0 - Event-Driven Architecture_"""


def send_introduction():
    """Send introduction message to Telegram using requests"""
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"

        payload = {
            "chat_id": CHAT_ID,
            "text": MESSAGE,
            "parse_mode": "Markdown"
        }

        response = requests.post(url, json=payload)
        result = response.json()

        if result.get("ok"):
            print(f"SUCCESS: Introduction message sent!")
            print(f"   Chat ID: {CHAT_ID}")
            print(f"   Message ID: {result['result']['message_id']}")
            return True
        else:
            print(f"ERROR: {result.get('description', 'Unknown error')}")
            return False

    except Exception as e:
        print(f"ERROR: {e}")
        return False


if __name__ == "__main__":
    print("=" * 50)
    print("TATANGA ENTERPRISE - Telegram Introduction")
    print("=" * 50)

    send_introduction()
