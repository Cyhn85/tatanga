#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Bridge Server
=====================
VS Code kapalıyken bile çalışan standalone HTTP server.
Claude Code ile TATANGA UI arasında köprü görevi görür.

Kullanım:
    python bridge_server.py

Endpoints:
    POST /command      - Yeni komut ekle
    GET  /status       - Sistem durumu
    GET  /results      - Sonuçlar
    GET  /health       - Health check
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse
import threading
import time

# Config
PORT = 8503
BRIDGE_DIR = Path(__file__).parent
COMMANDS_FILE = BRIDGE_DIR / "commands.json"
RESULTS_FILE = BRIDGE_DIR / "results.json"
STATUS_FILE = BRIDGE_DIR / "status.json"


def load_json(file_path: Path) -> dict:
    """JSON dosyasını oku"""
    try:
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
    return {}


def save_json(file_path: Path, data: dict):
    """JSON dosyasına yaz"""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Error saving {file_path}: {e}")


def generate_command_id() -> str:
    """Benzersiz komut ID'si oluştur"""
    return f"cmd_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"


class BridgeHandler(BaseHTTPRequestHandler):
    """HTTP Request Handler"""

    def _set_headers(self, status=200, content_type='application/json'):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_OPTIONS(self):
        """CORS preflight"""
        self._set_headers()

    def do_GET(self):
        """GET requests"""
        parsed = urlparse(self.path)
        path = parsed.path

        if path == '/health':
            self._set_headers()
            response = {
                'status': 'ok',
                'timestamp': datetime.now().isoformat(),
                'version': '1.0'
            }
            self.wfile.write(json.dumps(response).encode())

        elif path == '/status':
            self._set_headers()
            status = load_json(STATUS_FILE)
            status['server_time'] = datetime.now().isoformat()
            self.wfile.write(json.dumps(status).encode())

        elif path == '/results':
            self._set_headers()
            results = load_json(RESULTS_FILE)
            self.wfile.write(json.dumps(results).encode())

        elif path == '/commands':
            self._set_headers()
            commands = load_json(COMMANDS_FILE)
            self.wfile.write(json.dumps(commands).encode())

        elif path == '/':
            # Dashboard HTML
            self._set_headers(content_type='text/html')
            html = self._get_dashboard_html()
            self.wfile.write(html.encode())

        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({'error': 'Not found'}).encode())

    def do_POST(self):
        """POST requests"""
        parsed = urlparse(self.path)
        path = parsed.path

        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')

        if path == '/command':
            try:
                data = json.loads(body) if body else {}
                command_text = data.get('command', '').strip()

                if not command_text:
                    self._set_headers(400)
                    self.wfile.write(json.dumps({'error': 'Command is required'}).encode())
                    return

                # Yeni komut oluştur
                command = {
                    'id': generate_command_id(),
                    'timestamp': datetime.now().isoformat(),
                    'command': command_text,
                    'status': 'pending',
                    'result': None
                }

                # Kuyruğa ekle
                commands = load_json(COMMANDS_FILE)
                if 'queue' not in commands:
                    commands['queue'] = []
                commands['queue'].append(command)
                commands['last_updated'] = datetime.now().isoformat()
                save_json(COMMANDS_FILE, commands)

                # Status güncelle
                status = load_json(STATUS_FILE)
                status['stats'] = status.get('stats', {})
                status['stats']['total_commands'] = status['stats'].get('total_commands', 0) + 1
                status['last_updated'] = datetime.now().isoformat()
                save_json(STATUS_FILE, status)

                self._set_headers(201)
                self.wfile.write(json.dumps({
                    'success': True,
                    'command_id': command['id'],
                    'message': 'Command queued'
                }).encode())

                print(f"[{datetime.now().strftime('%H:%M:%S')}] New command: {command_text[:50]}...")

            except json.JSONDecodeError:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'Invalid JSON'}).encode())

        elif path == '/result':
            try:
                data = json.loads(body) if body else {}
                command_id = data.get('command_id')
                result = data.get('result')
                success = data.get('success', True)

                if not command_id:
                    self._set_headers(400)
                    self.wfile.write(json.dumps({'error': 'command_id is required'}).encode())
                    return

                # Sonucu kaydet
                results = load_json(RESULTS_FILE)
                if 'results' not in results:
                    results['results'] = []

                results['results'].append({
                    'command_id': command_id,
                    'timestamp': datetime.now().isoformat(),
                    'success': success,
                    'result': result
                })
                results['last_updated'] = datetime.now().isoformat()
                save_json(RESULTS_FILE, results)

                # Komutu kuyruktan kaldır
                commands = load_json(COMMANDS_FILE)
                commands['queue'] = [c for c in commands.get('queue', []) if c.get('id') != command_id]
                save_json(COMMANDS_FILE, commands)

                # Status güncelle
                status = load_json(STATUS_FILE)
                status['stats'] = status.get('stats', {})
                if success:
                    status['stats']['successful'] = status['stats'].get('successful', 0) + 1
                else:
                    status['stats']['failed'] = status['stats'].get('failed', 0) + 1
                save_json(STATUS_FILE, status)

                self._set_headers()
                self.wfile.write(json.dumps({'success': True}).encode())

            except json.JSONDecodeError:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'Invalid JSON'}).encode())

        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({'error': 'Not found'}).encode())

    def _get_dashboard_html(self) -> str:
        """Simple HTML dashboard"""
        return '''<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TATANGA Bridge</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #1a1a2e;
            color: #eee;
            min-height: 100vh;
            padding: 20px;
        }
        .container { max-width: 800px; margin: 0 auto; }
        h1 {
            color: #00d4ff;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .status-card {
            background: #16213e;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .status-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #0f3460;
        }
        .status-row:last-child { border-bottom: none; }
        .label { color: #888; }
        .value { color: #00d4ff; font-weight: bold; }
        .value.ok { color: #00ff88; }
        .value.error { color: #ff4444; }

        .terminal {
            background: #0d1117;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .terminal h3 { color: #00d4ff; margin-bottom: 15px; }
        .input-row {
            display: flex;
            gap: 10px;
        }
        input[type="text"] {
            flex: 1;
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 6px;
            padding: 12px 15px;
            color: #fff;
            font-size: 16px;
        }
        input[type="text"]:focus {
            outline: none;
            border-color: #00d4ff;
        }
        button {
            background: #00d4ff;
            color: #000;
            border: none;
            border-radius: 6px;
            padding: 12px 24px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s;
        }
        button:hover { background: #00b8e6; }

        .results {
            background: #16213e;
            border-radius: 10px;
            padding: 20px;
            max-height: 300px;
            overflow-y: auto;
        }
        .result-item {
            background: #0f3460;
            border-radius: 6px;
            padding: 10px 15px;
            margin-bottom: 10px;
        }
        .result-item.pending { border-left: 3px solid #ffaa00; }
        .result-item.success { border-left: 3px solid #00ff88; }
        .result-item.error { border-left: 3px solid #ff4444; }
        .result-time { color: #666; font-size: 12px; }
        .result-cmd { color: #fff; margin-top: 5px; }

        .refresh-btn {
            background: transparent;
            border: 1px solid #30363d;
            color: #888;
            padding: 8px 16px;
            margin-bottom: 20px;
        }
        .refresh-btn:hover {
            background: #30363d;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌉 TATANGA Bridge</h1>

        <div class="status-card">
            <div class="status-row">
                <span class="label">Status</span>
                <span class="value ok" id="status">Checking...</span>
            </div>
            <div class="status-row">
                <span class="label">Pending Commands</span>
                <span class="value" id="pending">-</span>
            </div>
            <div class="status-row">
                <span class="label">Total Commands</span>
                <span class="value" id="total">-</span>
            </div>
            <div class="status-row">
                <span class="label">Successful</span>
                <span class="value ok" id="successful">-</span>
            </div>
        </div>

        <div class="terminal">
            <h3>💬 Send Command</h3>
            <div class="input-row">
                <input type="text" id="command" placeholder="ebay.de+vinted.de sitelerinde nike ayakkabi ara zustand:gut" />
                <button onclick="sendCommand()">Send</button>
            </div>
        </div>

        <button class="refresh-btn" onclick="loadData()">🔄 Refresh</button>

        <div class="results" id="results">
            <p style="color: #666;">No commands yet...</p>
        </div>
    </div>

    <script>
        async function loadData() {
            try {
                // Status
                const statusRes = await fetch('/status');
                const status = await statusRes.json();
                document.getElementById('status').textContent = 'Online';
                document.getElementById('total').textContent = status.stats?.total_commands || 0;
                document.getElementById('successful').textContent = status.stats?.successful || 0;

                // Commands
                const cmdRes = await fetch('/commands');
                const commands = await cmdRes.json();
                document.getElementById('pending').textContent = commands.queue?.length || 0;

                // Results
                const resultsRes = await fetch('/results');
                const results = await resultsRes.json();

                const resultsDiv = document.getElementById('results');
                if (commands.queue?.length || results.results?.length) {
                    let html = '';

                    // Pending commands
                    for (const cmd of (commands.queue || []).reverse()) {
                        html += `<div class="result-item pending">
                            <div class="result-time">⏳ ${cmd.timestamp}</div>
                            <div class="result-cmd">${cmd.command}</div>
                        </div>`;
                    }

                    // Completed results
                    for (const r of (results.results || []).slice(-10).reverse()) {
                        const cls = r.success ? 'success' : 'error';
                        html += `<div class="result-item ${cls}">
                            <div class="result-time">${r.success ? '✅' : '❌'} ${r.timestamp}</div>
                            <div class="result-cmd">${r.result || 'Completed'}</div>
                        </div>`;
                    }

                    resultsDiv.innerHTML = html;
                }
            } catch (e) {
                document.getElementById('status').textContent = 'Error';
                document.getElementById('status').className = 'value error';
            }
        }

        async function sendCommand() {
            const input = document.getElementById('command');
            const command = input.value.trim();
            if (!command) return;

            try {
                const res = await fetch('/command', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ command })
                });
                const data = await res.json();
                if (data.success) {
                    input.value = '';
                    loadData();
                }
            } catch (e) {
                alert('Error sending command');
            }
        }

        // Enter key to send
        document.getElementById('command').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendCommand();
        });

        // Auto refresh
        loadData();
        setInterval(loadData, 5000);
    </script>
</body>
</html>'''

    def log_message(self, format, *args):
        """Custom log format"""
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {args[0]}")


def run_server():
    """Start the HTTP server"""
    server = HTTPServer(('0.0.0.0', PORT), BridgeHandler)
    print(f"""
╔═══════════════════════════════════════════════════════╗
║           TATANGA BRIDGE SERVER v1.0                  ║
╠═══════════════════════════════════════════════════════╣
║  Status:    RUNNING                                   ║
║  Port:      {PORT}                                        ║
║  Dashboard: http://localhost:{PORT}                      ║
╠═══════════════════════════════════════════════════════╣
║  Endpoints:                                           ║
║    POST /command  - Add new command                   ║
║    GET  /status   - System status                     ║
║    GET  /results  - View results                      ║
║    GET  /health   - Health check                      ║
╚═══════════════════════════════════════════════════════╝
    """)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
        server.shutdown()


if __name__ == '__main__':
    run_server()
