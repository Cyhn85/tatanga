#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Scrape Orchestrator
Event Bus ile ScrapingManager arasinda kopru
Self-healing entegrasyonu ile otonom kazima

Author: TATANGA Team
Version: 1.0
"""

import asyncio
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional
import json
import traceback
import logging

# Path setup
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.event_bus import EventBus, Event, get_event_bus
from core.logger import ModuleLogger

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(name)s | %(message)s',
    handlers=[
        logging.FileHandler(Path(__file__).parent.parent / 'storage' / 'scrape_orchestrator.log'),
        logging.StreamHandler()
    ]
)


class ScrapeOrchestrator:
    """
    Scrape Orchestrator - Event Bus ile ScrapingManager arasinda kopru

    Gorevleri:
    1. scrape_requested eventlerini dinle
    2. ScrapingManager'i baslat
    3. Her platform icin bireysel kazima yap
    4. Sonuclari event olarak yayinla
    5. Hatalari self-healing'e yonlendir
    """

    def __init__(self):
        self.logger = ModuleLogger("scrape_orchestrator")
        self.event_bus = get_event_bus()
        self.scraping_manager = None
        self.self_healing = None
        self.ceo_agent = None

        # Active jobs tracking
        self.active_jobs: Dict[str, Dict] = {}
        self.job_results: Dict[str, List] = {}

        # Statistics
        self.stats = {
            'total_jobs': 0,
            'successful_scrapes': 0,
            'failed_scrapes': 0,
            'healed_errors': 0,
            'products_found': 0
        }

        # Subscribe to events
        self._setup_subscriptions()

        self.logger.info("Scrape Orchestrator initialized")

    def _setup_subscriptions(self):
        """Event Bus abonelikleri"""
        self.event_bus.subscribe('scrape_requested', self._handle_scrape_requested)
        self.event_bus.subscribe('scrape_stopped', self._handle_scrape_stopped)
        self.event_bus.subscribe('selector_failed', self._handle_selector_failed)
        self.logger.info("Event subscriptions registered")

    async def initialize(self):
        """Manager ve agent'lari initialize et"""
        try:
            # CEO Agent'i yukle (platform listesi icin)
            from agents.ceo_agent import CEOAgent
            self.ceo_agent = CEOAgent()

            # ScrapingManager'i yukle
            from agents.managers.scraping_manager import ScrapingManager
            self.scraping_manager = ScrapingManager(self.ceo_agent)
            await self.scraping_manager.initialize_scrapers()

            # Self-healing'i yukle
            try:
                from agents.self_healing import SelfHealingAgent
                self.self_healing = SelfHealingAgent()
                self.logger.info("Self-healing agent loaded")
            except ImportError:
                self.logger.warning("Self-healing agent not available")

            self.logger.info(f"Initialized with {len(self.scraping_manager.scrapers)} scrapers")
            return True

        except Exception as e:
            self.logger.error(f"Initialization failed: {e}")
            return False

    async def _handle_scrape_requested(self, event: Event):
        """
        scrape_requested eventi handler

        Event data:
        - job_id: Is ID
        - batch_id: Parti ID
        - query: Arama sorgusu
        - platforms: Platform listesi (bos = hepsi)
        - filters: Filtreler
        - mode: parallel/sequential
        - rate_limit: Bekleme suresi (sequential mod)
        """
        data = event.data
        job_id = data.get('job_id')
        batch_id = data.get('batch_id')
        query = data.get('query')
        platforms = data.get('platforms', [])
        filters = data.get('filters', {})
        mode = data.get('mode', 'parallel')
        rate_limit = data.get('rate_limit', 3)

        self.logger.info(f"Scrape requested: job={job_id}, query='{query}', mode={mode}")

        # Job kaydini olustur
        self.active_jobs[job_id] = {
            'job_id': job_id,
            'batch_id': batch_id,
            'query': query,
            'platforms': platforms,
            'mode': mode,
            'status': 'running',
            'progress': 0,
            'started_at': datetime.now().isoformat(),
            'platforms_completed': 0,
            'platforms_failed': 0,
            'products_found': 0,
            'errors': []
        }

        self.job_results[job_id] = []
        self.stats['total_jobs'] += 1

        try:
            # Platform listesini belirle
            if not platforms or 'all' in platforms:
                platforms = list(self.scraping_manager.scrapers.keys())

            total_platforms = len(platforms)
            self.active_jobs[job_id]['total_platforms'] = total_platforms

            # Kazima baslat
            if mode == 'parallel':
                await self._scrape_parallel(job_id, platforms, query, filters)
            else:
                await self._scrape_sequential(job_id, platforms, query, filters, rate_limit)

            # Tamamlandi
            self.active_jobs[job_id]['status'] = 'completed'
            self.active_jobs[job_id]['progress'] = 100
            self.active_jobs[job_id]['completed_at'] = datetime.now().isoformat()

            # Sonuc eventi yayinla
            await self.event_bus.emit(
                'scrape_completed',
                {
                    'job_id': job_id,
                    'batch_id': batch_id,
                    'total_products': self.active_jobs[job_id]['products_found'],
                    'platforms_completed': self.active_jobs[job_id]['platforms_completed'],
                    'platforms_failed': self.active_jobs[job_id]['platforms_failed']
                },
                source='scrape_orchestrator'
            )

            self.logger.info(f"Job {job_id} completed: {self.active_jobs[job_id]['products_found']} products")

        except Exception as e:
            self.logger.error(f"Job {job_id} failed: {e}")
            self.active_jobs[job_id]['status'] = 'failed'
            self.active_jobs[job_id]['errors'].append(str(e))

            # Hata eventi
            await self.event_bus.emit(
                'error_occurred',
                {
                    'job_id': job_id,
                    'error': str(e),
                    'traceback': traceback.format_exc()
                },
                source='scrape_orchestrator'
            )

    async def _scrape_parallel(self, job_id: str, platforms: List[str], query: str, filters: Dict):
        """Paralel kazima - tum platformlar ayni anda"""
        self.logger.info(f"Starting parallel scrape on {len(platforms)} platforms")

        tasks = []
        for platform in platforms:
            task = asyncio.create_task(
                self._scrape_single_platform(job_id, platform, query, filters)
            )
            tasks.append(task)

        # Tum tasklari bekle
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Sonuclari isle
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                self.logger.error(f"Platform {platforms[i]} failed: {result}")

    async def _scrape_sequential(self, job_id: str, platforms: List[str], query: str, filters: Dict, rate_limit: int):
        """Sirali kazima - platformlar sirayla"""
        self.logger.info(f"Starting sequential scrape on {len(platforms)} platforms with {rate_limit}s delay")

        for i, platform in enumerate(platforms):
            # Job durduruldu mu?
            if self.active_jobs[job_id]['status'] == 'stopped':
                self.logger.info(f"Job {job_id} stopped at platform {i+1}/{len(platforms)}")
                break

            await self._scrape_single_platform(job_id, platform, query, filters)

            # Rate limit bekle
            if i < len(platforms) - 1:
                await asyncio.sleep(rate_limit)

    async def _scrape_single_platform(self, job_id: str, platform: str, query: str, filters: Dict):
        """
        Tek platform kazima

        Returns:
            Kazima sonucu
        """
        self.logger.info(f"[{job_id}] Scraping {platform}...")

        try:
            # ScrapingManager ile kazima yap
            result = await self.scraping_manager.execute_scrape(
                platform=platform,
                query=query,
                limit=50,
                filters=filters
            )

            if result.get('success'):
                products = result.get('results', [])
                count = len(products)

                # Sonuclari kaydet
                self.job_results[job_id].extend(products)
                self.active_jobs[job_id]['products_found'] += count
                self.active_jobs[job_id]['platforms_completed'] += 1
                self.stats['successful_scrapes'] += 1
                self.stats['products_found'] += count

                # Progress guncelle
                total = self.active_jobs[job_id].get('total_platforms', 1)
                completed = self.active_jobs[job_id]['platforms_completed']
                self.active_jobs[job_id]['progress'] = int((completed / total) * 100)

                # Urunleri DB'ye kaydet
                await self._save_products(job_id, platform, products)

                # raw_product_found eventi yayinla
                for product in products:
                    await self.event_bus.emit(
                        'raw_product_found',
                        {
                            'job_id': job_id,
                            'batch_id': self.active_jobs[job_id]['batch_id'],
                            'platform': platform,
                            'product': product
                        },
                        source='scrape_orchestrator'
                    )

                self.logger.info(f"[{job_id}] {platform}: {count} products found")
                return result

            else:
                error = result.get('error', 'Unknown error')
                self.active_jobs[job_id]['platforms_failed'] += 1
                self.active_jobs[job_id]['errors'].append({
                    'platform': platform,
                    'error': error
                })
                self.stats['failed_scrapes'] += 1

                # Hatayi self-healing'e gonder
                await self._trigger_self_healing(job_id, platform, error)

                self.logger.error(f"[{job_id}] {platform} failed: {error}")
                return result

        except Exception as e:
            error_msg = str(e)
            self.active_jobs[job_id]['platforms_failed'] += 1
            self.active_jobs[job_id]['errors'].append({
                'platform': platform,
                'error': error_msg,
                'traceback': traceback.format_exc()
            })
            self.stats['failed_scrapes'] += 1

            # Hatayi self-healing'e gonder
            await self._trigger_self_healing(job_id, platform, error_msg)

            self.logger.error(f"[{job_id}] {platform} exception: {error_msg}")
            return {'success': False, 'error': error_msg}

    async def _save_products(self, job_id: str, platform: str, products: List[Dict]):
        """Urunleri veritabanina kaydet"""
        try:
            import sqlite3
            db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'

            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()

            batch_id = self.active_jobs[job_id]['batch_id']

            for product in products:
                cursor.execute("""
                    INSERT OR REPLACE INTO products (
                        url, title, price, currency, platform, condition,
                        brand, images, location, batch_id, is_in_inbox, scraped_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
                """, (
                    product.get('url', ''),
                    product.get('title', ''),
                    product.get('price', 0),
                    product.get('currency', 'EUR'),
                    platform,
                    product.get('condition', ''),
                    product.get('brand', ''),
                    json.dumps(product.get('images', [])),
                    product.get('location', ''),
                    batch_id,
                    datetime.now().isoformat()
                ))

            conn.commit()
            conn.close()
            self.logger.info(f"Saved {len(products)} products to database")

        except Exception as e:
            self.logger.error(f"Failed to save products: {e}")

    async def _trigger_self_healing(self, job_id: str, platform: str, error: str):
        """Self-healing'i tetikle"""
        if self.self_healing:
            try:
                # selector_failed eventi yayinla
                await self.event_bus.emit(
                    'selector_failed',
                    {
                        'job_id': job_id,
                        'platform': platform,
                        'error': error,
                        'timestamp': datetime.now().isoformat()
                    },
                    source='scrape_orchestrator'
                )

                # Self-healing'in hatayi islemesini bekle
                healing_result = await self.self_healing.diagnose_and_repair({
                    'platform': platform,
                    'error_type': 'SCRAPE_FAILED',
                    'error_message': error
                })

                if healing_result.get('success'):
                    self.stats['healed_errors'] += 1
                    self.logger.info(f"Self-healing repaired {platform}")
                else:
                    self.logger.warning(f"Self-healing could not repair {platform}")

            except Exception as e:
                self.logger.error(f"Self-healing failed: {e}")

    async def _handle_scrape_stopped(self, event: Event):
        """scrape_stopped eventi handler"""
        job_id = event.data.get('job_id')
        if job_id in self.active_jobs:
            self.active_jobs[job_id]['status'] = 'stopped'
            self.logger.info(f"Job {job_id} stopped by user")

    async def _handle_selector_failed(self, event: Event):
        """selector_failed eventi handler - Self-healing tetikle"""
        if self.self_healing:
            platform = event.data.get('platform')
            error = event.data.get('error')

            self.logger.warning(f"Selector failed for {platform}: {error}")

            # Self-healing tetikle
            await self._trigger_self_healing(
                event.data.get('job_id', 'unknown'),
                platform,
                error
            )

    def get_job_status(self, job_id: str) -> Optional[Dict]:
        """Job durumunu getir"""
        return self.active_jobs.get(job_id)

    def get_all_jobs(self) -> List[Dict]:
        """Tum joblari getir"""
        return list(self.active_jobs.values())

    def get_stats(self) -> Dict:
        """Istatistikleri getir"""
        return {
            **self.stats,
            'active_jobs': len([j for j in self.active_jobs.values() if j['status'] == 'running'])
        }


# Global instance
_orchestrator_instance: Optional[ScrapeOrchestrator] = None


def get_orchestrator() -> ScrapeOrchestrator:
    """Global ScrapeOrchestrator instance al"""
    global _orchestrator_instance
    if _orchestrator_instance is None:
        _orchestrator_instance = ScrapeOrchestrator()
    return _orchestrator_instance


async def start_orchestrator():
    """Orchestrator'i baslat"""
    orchestrator = get_orchestrator()
    await orchestrator.initialize()
    return orchestrator


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("SCRAPE ORCHESTRATOR TEST")
    print("=" * 60)

    async def test():
        orchestrator = await start_orchestrator()

        print(f"\nOrchestrator initialized")
        print(f"Stats: {orchestrator.get_stats()}")

        # Test event emit
        from core.event_bus import emit

        print("\nEmitting test scrape_requested event...")
        await emit(
            'scrape_requested',
            {
                'job_id': 'test_001',
                'batch_id': 'test_batch',
                'query': 'Nike Air Force',
                'platforms': [],  # all
                'mode': 'sequential',
                'rate_limit': 1
            },
            source='test'
        )

        # Bekle
        await asyncio.sleep(5)

        print(f"\nFinal stats: {orchestrator.get_stats()}")
        print(f"Job status: {orchestrator.get_job_status('test_001')}")

        print("\n" + "=" * 60)
        print("TEST COMPLETE")
        print("=" * 60)

    asyncio.run(test())
