# VPN Uploader - Full automation with Windscribe VPN + CAPTCHA handling
# For cssberlin store - requires different IP than home network

import os
import sys
import time
import random
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Add proxy_manager to path
ACTIVE_PIECES_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ACTIVE_PIECES_DIR, 'proxy_manager'))

from playwright.sync_api import sync_playwright
from utils.database import db
from utils.captcha_handler import get_captcha_handler
from config import (
    STATUS_VALIDATED, STATUS_UPLOADED,
    TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
)

# Try to import VPN manager
try:
    from vpn_manager import get_vpn_manager
    VPN_AVAILABLE = True
except ImportError:
    VPN_AVAILABLE = False
    print('[WARN] VPN Manager not available')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
SESSIONS_DIR = os.path.join(BASE_DIR, 'sessions')
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(SESSIONS_DIR, exist_ok=True)

# cssberlin credentials
VINTED_EMAIL = "cssberlin@hotmail.com"
VINTED_PASSWORD = "Css200231"

# Upload settings
DAILY_LIMIT = 15
MIN_DELAY_BETWEEN_PRODUCTS = 180  # 3 minutes
MAX_DELAY_BETWEEN_PRODUCTS = 300  # 5 minutes


class VPNUploader:
    def __init__(self):
        self.session_dir = os.path.join(SESSIONS_DIR, 'cssberlin_vpn')
        os.makedirs(self.session_dir, exist_ok=True)

        self.captcha_handler = get_captcha_handler()
        self.vpn_manager = get_vpn_manager() if VPN_AVAILABLE else None

        self.products_uploaded = 0
        self.products_failed = 0
        self.vpn_connected = False
        self.manual_publish = True  # Default: wait for user to click publish

    def print_banner(self):
        print('=' * 60)
        print('  VINTED VPN UPLOADER - cssberlin')
        print('  Windscribe VPN + CAPTCHA Handler')
        print('=' * 60)

    def send_telegram(self, message: str):
        """Send message to Telegram"""
        try:
            import requests
            requests.post(
                f'https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage',
                data={'chat_id': TELEGRAM_CHAT_ID, 'text': message, 'parse_mode': 'Markdown'},
                timeout=10
            )
        except:
            pass

    # =========================================================================
    # VPN MANAGEMENT (GUI Mode - Manual connection via Windscribe app)
    # =========================================================================

    def check_vpn_connected(self) -> bool:
        """Check if VPN is connected by checking IP"""
        try:
            import requests
            response = requests.get('https://api.ipify.org', timeout=10)
            current_ip = response.text.strip()

            # Check if IP is NOT Turkish (home IP usually starts with 85., 78., 31., etc.)
            turkish_prefixes = ['85.', '78.', '31.', '176.', '88.', '95.', '212.']
            is_turkish = any(current_ip.startswith(p) for p in turkish_prefixes)

            if is_turkish:
                print(f'[VPN] WARNING: IP looks Turkish ({current_ip}) - VPN might not be connected!')
                return False
            else:
                print(f'[VPN] OK - Current IP: {current_ip}')
                return True
        except Exception as e:
            print(f'[VPN] IP check failed: {e}')
            return True  # Continue anyway

    def connect_vpn(self) -> bool:
        """Check VPN connection (GUI mode - user connects manually)"""
        print('[VPN] Checking connection (GUI mode)...')

        if not self.check_vpn_connected():
            print('[VPN] ⚠️ VPN might not be connected!')
            print('[VPN] Please connect via Windscribe GUI to Germany')
            self.send_telegram('⚠️ *VPN Not Connected*\nPlease connect via Windscribe GUI')
            return False

        self.vpn_connected = True
        return True

    def disconnect_vpn(self):
        """No-op for GUI mode - user disconnects manually"""
        print('[VPN] GUI mode - disconnect manually when done')
        self.vpn_connected = False

    # =========================================================================
    # COOKIE HANDLING
    # =========================================================================

    def handle_cookie_popup(self, page) -> bool:
        """Handle cookie consent popup"""
        try:
            print('[COOKIES] Checking for cookie popup...')
            time.sleep(2)

            # Cookie accept button selectors (German Vinted)
            cookie_selectors = [
                'button:has-text("Alle akzeptieren")',
                'button:has-text("Alle Cookies akzeptieren")',
                'button:has-text("Akzeptieren")',
                'button:has-text("Accept all")',
                'button[data-testid="cookie-accept-all"]',
                '#onetrust-accept-btn-handler',
                '[id*="accept"]',
            ]

            for selector in cookie_selectors:
                try:
                    btn = page.query_selector(selector)
                    if btn and btn.is_visible():
                        btn.click()
                        print(f'[COOKIES] Accepted: {selector[:40]}')
                        time.sleep(2)
                        return True
                except:
                    continue

            # Try with get_by_text
            try:
                accept = page.get_by_text('Alle akzeptieren', exact=True)
                if accept.count() > 0:
                    accept.first.click()
                    print('[COOKIES] Accepted via get_by_text')
                    time.sleep(2)
                    return True
            except:
                pass

            print('[COOKIES] No popup found or already accepted')
            return False

        except Exception as e:
            print(f'[COOKIES] Error: {e}')
            return False

    # =========================================================================
    # BROWSER & LOGIN
    # =========================================================================

    def launch_browser(self, pw):
        """Launch browser with persistent context"""
        print('\n[BROWSER] Launching...')

        context = pw.chromium.launch_persistent_context(
            user_data_dir=self.session_dir,
            headless=False,
            viewport={'width': 1400, 'height': 900},
            locale='de-DE',
            timezone_id='Europe/Berlin',
            args=[
                '--disable-blink-features=AutomationControlled',
                '--no-sandbox',
            ]
        )

        page = context.pages[0] if context.pages else context.new_page()
        print('[BROWSER] Ready')
        return context, page

    def check_login_status(self, page) -> bool:
        """Check if already logged in"""
        # Look for login button - if exists, not logged in
        login_btn = page.query_selector('a:has-text("Registrieren | Einloggen")')
        return login_btn is None

    def login(self, page) -> bool:
        """Login to Vinted with CAPTCHA handling"""
        print('\n[LOGIN] Starting...')

        # Go to Vinted
        page.goto('https://www.vinted.de/', wait_until='networkidle', timeout=60000)
        time.sleep(3)

        # Handle cookie popup FIRST
        self.handle_cookie_popup(page)
        time.sleep(2)

        # Check if already logged in
        if self.check_login_status(page):
            print('[LOGIN] Already logged in!')
            return True

        # Check for CAPTCHA before login (now excludes cookie popups)
        is_captcha, captcha_reason = self.captcha_handler.detect_captcha(page)
        print(f'[LOGIN] CAPTCHA check: {is_captcha} - {captcha_reason}')
        if is_captcha:
            print('[LOGIN] CAPTCHA detected on homepage')
            resolved = self.captcha_handler.handle_captcha(
                page,
                os.path.join(DATA_DIR, 'captcha_homepage.png')
            )
            if not resolved:
                return False

        # Step 1: Click header button
        print('[LOGIN] Step 1: Opening login popup...')
        header_btn = page.query_selector('a:has-text("Registrieren | Einloggen")')
        if header_btn:
            header_btn.click()
            time.sleep(3)

        # Step 2: Click "Einloggen" in popup
        print('[LOGIN] Step 2: Clicking Einloggen...')
        try:
            einloggen = page.get_by_text('Einloggen', exact=True)
            if einloggen.count() > 0:
                einloggen.first.click()
                time.sleep(3)
        except:
            pass

        # Step 3: Click E-Mail option
        print('[LOGIN] Step 3: Selecting E-Mail...')
        email_btn = page.query_selector('[data-testid*="email"]')
        if not email_btn:
            try:
                email_btn = page.get_by_text('E-Mail', exact=True).first
            except:
                pass
        if email_btn:
            email_btn.click()
            time.sleep(3)

        # Check for CAPTCHA after clicking E-Mail
        is_captcha, _ = self.captcha_handler.detect_captcha(page)
        if is_captcha:
            print('[LOGIN] CAPTCHA detected!')
            ss_path = os.path.join(DATA_DIR, 'captcha_login.png')
            resolved = self.captcha_handler.handle_captcha(page, ss_path)
            if not resolved:
                return False

        # Step 4: Fill email
        print('[LOGIN] Step 4: Entering credentials...')
        email_input = page.query_selector('input[type="email"], input[name="email"], input[placeholder*="E-Mail"], input[placeholder*="Mitgliedsname"]')
        if email_input:
            email_input.fill(VINTED_EMAIL)
            time.sleep(1)

        # Step 5: Fill password
        password_input = page.query_selector('input[type="password"]')
        if password_input:
            password_input.fill(VINTED_PASSWORD)
            time.sleep(1)

        # Step 6: Submit
        print('[LOGIN] Step 5: Submitting...')
        submit_btn = page.query_selector('button[type="submit"]')
        if submit_btn:
            submit_btn.click()
            time.sleep(5)

        # Check for CAPTCHA after submit
        is_captcha, _ = self.captcha_handler.detect_captcha(page)
        if is_captcha:
            print('[LOGIN] CAPTCHA after submit!')
            ss_path = os.path.join(DATA_DIR, 'captcha_submit.png')
            resolved = self.captcha_handler.handle_captcha(page, ss_path)
            if not resolved:
                return False

        # Step 7: Handle SMS Verification (2FA)
        time.sleep(3)
        if self.detect_sms_verification(page):
            print('[LOGIN] Step 6: SMS Verification required!')
            self.send_telegram('📱 *SMS Doğrulama Gerekli*\n\nTelefona kod gönderildi.\nLütfen tarayıcıda kodu girin.')

            # Wait for manual code entry (max 5 minutes)
            resolved = self.wait_for_sms_verification(page, timeout_minutes=5)
            if not resolved:
                print('[LOGIN] SMS verification timeout!')
                return False
            print('[LOGIN] SMS verification completed!')

        # Verify login
        time.sleep(3)
        if self.check_login_status(page):
            print('[LOGIN] Success!')
            return True
        else:
            print('[LOGIN] Failed - still not logged in')
            page.screenshot(path=os.path.join(DATA_DIR, 'login_failed.png'))
            return False

    def detect_sms_verification(self, page) -> bool:
        """Detect if SMS verification screen is shown"""
        try:
            page_text = page.content().lower()
            sms_indicators = [
                'code eingeben',
                'bestätigungscode',
                'sms code',
                'verifizierungscode',
                'code senden',
                'telefonnummer',
                'an deine nummer',
                'code per sms',
            ]
            for indicator in sms_indicators:
                if indicator in page_text:
                    return True

            # Check for code input field
            code_input = page.query_selector('input[placeholder*="Code"], input[name*="code"], input[type="tel"]')
            if code_input and code_input.is_visible():
                return True

            return False
        except:
            return False

    def wait_for_sms_verification(self, page, timeout_minutes: int = 5) -> bool:
        """Wait for user to enter SMS code manually"""
        print(f'\n[SMS] Waiting for SMS code entry...')
        print(f'       Timeout: {timeout_minutes} minutes')
        print(f'       Please enter the code in the browser\n')

        start_time = time.time()
        check_interval = 3  # Check every 3 seconds

        while time.time() - start_time < timeout_minutes * 60:
            # Check if still on SMS verification screen
            if not self.detect_sms_verification(page):
                # SMS screen gone - either success or moved on
                return True

            # Check if already logged in
            if self.check_login_status(page):
                return True

            remaining = timeout_minutes * 60 - (time.time() - start_time)
            print(f'  [{int(remaining)}s remaining] Waiting for code...', end='\r')
            time.sleep(check_interval)

        print('\n[SMS] Timeout - code not entered')
        return False

    # =========================================================================
    # PRODUCT UPLOAD
    # =========================================================================

    def human_type(self, element, text: str, delay_range=(0.03, 0.08)):
        """Type text with human-like speed"""
        element.click()
        time.sleep(0.3)
        for char in text:
            element.type(char, delay=random.uniform(*delay_range) * 1000)
        time.sleep(0.5)

    def close_popup(self, page):
        """Close any popup that appears (like Elektronikverifizierung)"""
        try:
            # Look for close buttons
            close_selectors = [
                'button[aria-label="close"], button[aria-label="Close"]',
                'button:has-text("Schließen")',
                'button:has-text("Close")',
                '[data-testid="modal-close"]',
                '.modal-close',
                'div[role="dialog"] button:first-of-type',
            ]
            for sel in close_selectors:
                try:
                    close_btn = page.query_selector(sel)
                    if close_btn and close_btn.is_visible():
                        close_btn.click()
                        print('      [POPUP] Popup kapatildi')
                        time.sleep(1)
                        return True
                except:
                    continue

            # Try pressing Escape
            page.keyboard.press('Escape')
            time.sleep(0.5)
            return True
        except:
            return False

    def fill_dropdown_field(self, page, field_name: str, value: str):
        """Fill a dropdown field by clicking and selecting value"""
        if not value:
            return False

        try:
            # Find the field row
            selectors = [
                f'div:has-text("{field_name}") >> xpath=.. >> button',
                f'div:has-text("{field_name}") >> xpath=../.. >> [role="button"]',
                f'[data-testid*="{field_name.lower()}"]',
            ]

            for sel in selectors:
                try:
                    field = page.query_selector(sel)
                    if field and field.is_visible():
                        field.click()
                        time.sleep(1)

                        # Try to find and click the value in dropdown
                        option = page.query_selector(f'[role="option"]:has-text("{value}"), li:has-text("{value}"), div:has-text("{value}")')
                        if option and option.is_visible():
                            option.click()
                            print(f'      [OK] {field_name}: {value}')
                            time.sleep(0.5)
                            return True
                except:
                    continue
            return False
        except:
            return False

    def fill_dynamic_fields(self, page, product: dict):
        """
        AKILLI ALAN DOLDURMA V3 - Playwright get_by_text kullanarak daha güvenilir
        """
        import json
        import re

        print('  [4b/7] Dinamik alanlar taranıyor...')

        brand = product.get('brand', '')
        color = product.get('color', '')
        size = product.get('size', '')
        condition = product.get('condition', 'Sehr gut')
        extra = product.get('extra_fields', {})

        if isinstance(extra, str):
            try:
                extra = json.loads(extra)
            except:
                extra = {}

        speicher = extra.get('speicher', '')
        modell = extra.get('modell', '')

        # Renk çevirisi (ilk rengi al)
        color_first = color.split(',')[0].strip() if color else ''
        color_map = {
            'Blue': 'Blau', 'Red': 'Rot', 'Black': 'Schwarz',
            'White': 'Weiß', 'Green': 'Grün', 'Yellow': 'Gelb',
            'Pink': 'Rosa', 'Purple': 'Lila', 'Orange': 'Orange',
            'Gray': 'Grau', 'Grey': 'Grau', 'Brown': 'Braun',
            'Türkis': 'Türkis', 'Neon': 'Grün', 'Turquoise': 'Türkis',
        }
        german_color = color_map.get(color_first, color_first) if color_first else ''

        # Durum çevirisi
        zustand = 'Sehr gut'

        # Size'dan numara çıkar
        size_value = ''
        if size:
            size_match = re.search(r'(\d+(?:[.,]\d+)?)', str(size))
            size_value = size_match.group(1) if size_match else str(size)

        # Brand'dan sadece marka adını al
        brand_value = brand.split()[0] if brand else ''

        print(f'      Veriler: Marke={brand_value}, Größe={size_value}, Farbe={german_color}')

        # Kategori seçiminden sonra formun yüklenmesini bekle
        time.sleep(3)

        # Açık dropdown varsa kapat
        page.keyboard.press('Escape')
        time.sleep(1)

        # Sayfayı aşağı kaydır (form alanları görünsün)
        page.evaluate('window.scrollBy(0, 400)')
        time.sleep(1.5)

        # DEBUG: Form screenshot al
        try:
            debug_ss = os.path.join(DATA_DIR, f'form_debug_{time.time():.0f}.png')
            page.screenshot(path=debug_ss)
            print(f'      [DEBUG] Form screenshot: {debug_ss}')
        except:
            pass

        filled_count = 0

        # ================================================================
        # DOĞRUDAN get_by_text İLE ALAN DOLDURMA
        # ================================================================
        field_map = [
            ('Marke', brand_value),
            ('Größe', size_value),
            ('Schuhgröße', size_value),
            ('Farbe', german_color),
            ('Zustand', zustand),
            ('Speicher', speicher),
            ('Modell', modell),
        ]

        for field_label, field_value in field_map:
            if not field_value:
                continue

            try:
                # "Wähle {field}" butonunu bul
                waehle_text = f'Wähle {field_label}'
                btn = page.get_by_text(waehle_text, exact=False)

                if btn.count() > 0:
                    print(f'      [{field_label}] buton bulundu: "{waehle_text}"')
                    btn.first.click()
                    time.sleep(random.uniform(1, 1.5))

                    # Değeri seç veya yaz
                    if self._select_dropdown_value(page, field_value, field_label):
                        filled_count += 1
                    time.sleep(random.uniform(0.5, 1))

            except Exception as e:
                print(f'      [{field_label}] hata: {e}')
                try:
                    page.keyboard.press('Escape')
                except:
                    pass
                continue

        # ================================================================
        # FALLBACK: Tüm sayfadaki clickable dropdown'ları tara
        # ================================================================
        if filled_count == 0:
            print('      [FALLBACK] Tüm form elementleri taranıyor...')
            try:
                # data-testid içeren elementleri ara
                form_elements = page.locator('[data-testid*="field"], [data-testid*="select"], [class*="dropdown"]')
                count = form_elements.count()
                print(f'      [{count} form elementi bulundu]')

                for i in range(min(count, 10)):
                    try:
                        el = form_elements.nth(i)
                        if el.is_visible():
                            el_text = el.inner_text()
                            print(f'        -> {el_text[:50]}...')
                    except:
                        continue
            except:
                pass

        print(f'      [{filled_count} alan dolduruldu]')
        self.close_popup(page)

    def _select_dropdown_value(self, page, value: str, field_name: str) -> bool:
        """Açık dropdown'dan değer seç"""
        try:
            time.sleep(0.5)

            # Yöntem 1: Değeri doğrudan get_by_text ile ara
            try:
                option = page.get_by_text(value, exact=False)
                if option.count() > 0:
                    # Listbox içindeki olanı seç
                    for i in range(min(option.count(), 5)):
                        opt = option.nth(i)
                        if opt.is_visible():
                            opt.click()
                            print(f'      [OK] {field_name}: {value}')
                            return True
            except:
                pass

            # Yöntem 2: role="option" içinde ara
            try:
                options = page.locator('[role="option"], [role="listbox"] *')
                for i in range(min(options.count(), 20)):
                    opt = options.nth(i)
                    if opt.is_visible():
                        opt_text = opt.inner_text()
                        if value.lower() in opt_text.lower():
                            opt.click()
                            print(f'      [OK] {field_name}: {opt_text[:30]}')
                            return True
            except:
                pass

            # Yöntem 3: Klavye ile yaz
            page.keyboard.type(value, delay=50)
            time.sleep(0.8)
            page.keyboard.press('ArrowDown')
            time.sleep(0.3)
            page.keyboard.press('Enter')
            print(f'      [OK] {field_name}: {value} (typed)')
            return True

        except Exception as e:
            page.keyboard.press('Escape')
            print(f'      [WARN] {field_name}: seçilemedi')
            return False

    def upload_product(self, page, product: dict, manual_publish: bool = True) -> bool:
        """Upload a single product with CAPTCHA handling
        If manual_publish=True, pauses before publish for user control
        """
        title = product.get('processed_title', product.get('raw_title', ''))
        desc = product.get('processed_description', product.get('raw_description', ''))
        price = product.get('price', 0)
        images_path = product.get('processed_images_path', product.get('raw_images_path', ''))
        brand = product.get('brand', '')
        size = product.get('size', '')
        color = product.get('color', '')
        condition = product.get('condition', 'Gut')

        print(f'\n[UPLOAD] {title[:50]}...')

        # Go to upload page
        page.goto('https://www.vinted.de/items/new', wait_until='networkidle', timeout=60000)
        time.sleep(3)

        # Check for CAPTCHA
        is_captcha, _ = self.captcha_handler.detect_captcha(page)
        if is_captcha:
            ss_path = os.path.join(DATA_DIR, f'captcha_upload_{product.get("id")}.png')
            resolved = self.captcha_handler.handle_captcha(page, ss_path)
            if not resolved:
                return False

        # 1. Upload images (human-like: one by one with delay)
        print('  [1/7] Images...')
        if images_path and os.path.exists(images_path):
            images = [os.path.join(images_path, f) for f in sorted(os.listdir(images_path))
                     if f.lower().endswith(('.jpg', '.jpeg', '.png'))][:10]
            if images:
                file_input = page.query_selector('input[type="file"]')
                if file_input:
                    # Upload images one by one for human-like behavior
                    for i, img in enumerate(images):
                        file_input.set_input_files(img)
                        print(f'      [{i+1}/{len(images)}] {os.path.basename(img)}')
                        time.sleep(random.uniform(1.5, 3))
                    print(f'      {len(images)} images uploaded')
                    time.sleep(3)

        # 2. Fill title (human-like typing)
        print('  [2/7] Title...')
        title_input = page.query_selector('input[name="title"], input[placeholder*="Titel"]')
        if title_input:
            self.human_type(title_input, title)
            time.sleep(random.uniform(1, 2))

        # 3. Fill description (human-like typing)
        print('  [3/7] Description...')
        desc_input = page.query_selector('textarea[name="description"], textarea[placeholder*="Beschreib"]')
        if desc_input:
            # Type first 200 chars human-like, then paste rest for speed
            self.human_type(desc_input, desc[:200])
            if len(desc) > 200:
                desc_input.fill(desc)  # Fill complete description
            time.sleep(random.uniform(2, 3))

        # 4. Category selection - IMPORTANT: User must select manually
        print('  [4/7] Category... (MANUEL SECIM GEREKLI)')
        try:
            # Click category dropdown to open it
            cat_selectors = [
                '[data-testid*="category"]',
                'button:has-text("Kategorie")',
                'div[class*="category"]',
                'button:has-text("Wähle eine Kategorie")',
                '[class*="CategorySelector"]',
            ]
            for sel in cat_selectors:
                cat_btn = page.query_selector(sel)
                if cat_btn and cat_btn.is_visible():
                    cat_btn.click()
                    print(f'      Kategori dropdown acildi: {sel[:30]}')
                    time.sleep(2)
                    break

            # Send Telegram notification for category
            self.send_telegram('📂 *Kategori Seçimi Gerekli*\n\nLütfen tarayıcıda uygun kategoriyi seçin.')
            print('      >> KATEGORI SECIMI ICIN TARAYICIYA GECIN <<')

            # Wait for user to select category (check if category field is filled)
            print('      Kategori seçilmesini bekliyorum...')
            cat_selected = False
            for _ in range(60):  # Max 3 minutes
                time.sleep(3)
                # Check if category was selected (field has value)
                try:
                    cat_filled = page.query_selector('[data-testid*="category-selected"], span:has-text("Kategorie:")')
                    if cat_filled:
                        cat_selected = True
                        print('      [OK] Kategori secildi!')
                        break
                    # Also check if we moved to a filled state
                    page_text = page.content()
                    if 'Kategorie:' in page_text or 'Elektronik' in page_text or 'Kleidung' in page_text:
                        cat_selected = True
                        print('      [OK] Kategori algilandi!')
                        break
                except:
                    pass
                print(f'      [{60-_*3}s] Kategori bekleniyor...', end='\r')

            if not cat_selected:
                print('\n      [WARN] Kategori secilmedi ama devam ediyorum...')

        except Exception as e:
            print(f'      [WARN] Kategori hatasi: {e}')

        time.sleep(random.uniform(2, 3))

        # 4b. Fill dynamic fields after category (Marke, Speicher, Zustand, SIM-Lock, Farbe)
        self.fill_dynamic_fields(page, product)

        time.sleep(random.uniform(1, 2))

        # 5. Brand (if input field - for non-electronics)
        print('  [5/7] Brand (ek)...')
        if brand:
            try:
                brand_input = page.query_selector('input[name="brand"], input[placeholder*="Marke"]')
                if brand_input:
                    self.human_type(brand_input, brand)
                    time.sleep(1)
                    # Try to select from dropdown
                    page.keyboard.press('ArrowDown')
                    page.keyboard.press('Enter')
                    time.sleep(1)
            except:
                pass
        time.sleep(random.uniform(1, 2))

        # 6. Fill price (human-like)
        print('  [6/7] Price: {price}...')
        price_input = page.query_selector('input[name="price"], input[placeholder*="Preis"]')
        if price_input:
            price_input.click()
            time.sleep(0.5)
            price_input.fill(str(int(price)))
            time.sleep(random.uniform(1, 2))

        # Take screenshot before publish
        ss_path = os.path.join(DATA_DIR, f'upload_{product.get("id")}_ready.png')
        page.screenshot(path=ss_path)
        print(f'      Screenshot: {ss_path}')

        # 7. MANUAL PUBLISH MODE - Wait for user to click publish
        if manual_publish:
            print('\n' + '=' * 60)
            print('  [7/7] MANUEL YAYINLAMA MODU')
            print('=' * 60)
            print('  Form dolduruldu. Lutfen kontrol edin:')
            print(f'    - Baslik: {title[:40]}...')
            print(f'    - Fiyat: {price} EUR')
            print(f'    - Resim: {len(images) if "images" in dir() else 0} adet')
            print('')
            print('  >> YAYINLA butonuna SIZI TIKLAYIN <<')
            print('  >> Ardindan sayfa degisecek, otomatik algılanacak <<')
            print('=' * 60)

            # Send Telegram notification
            self.send_telegram(f"""📝 *Ürün Hazır - Manuel Onay Bekliyor*

Başlık: {title[:50]}
Fiyat: {price} EUR

Lütfen tarayıcıda kontrol edin ve YAYINLA butonuna tıklayın.
Sayfa değişince otomatik algılanacak (max 5 dk).""")

            # Wait for page to change (user clicked publish)
            print('\n[BEKLE] Sayfa degisikligini bekliyorum (max 5 dakika)...')
            start_wait = time.time()
            timeout_secs = 300  # 5 minutes
            initial_url = page.url

            while time.time() - start_wait < timeout_secs:
                try:
                    # Close any popups that might appear (like Elektronikverifizierung)
                    self.close_popup(page)

                    current_url = page.url
                    # Check if we left the upload page (multiple patterns)
                    if 'items/new' not in current_url:
                        # Could be member page, item page, or profile
                        if '/member/' in current_url or '/items/' in current_url or current_url != initial_url:
                            print(f'\n  [OK] Sayfa degisti: {current_url[:50]}')
                            return True

                    # Check for success indicators in page
                    page_content = page.content()
                    success_indicators = [
                        'Dein Artikel wurde hochgeladen',
                        'Artikel wurde hochgeladen',
                        'wurde erfolgreich hochgeladen',
                        'Artikel hochgeladen',
                    ]
                    for indicator in success_indicators:
                        if indicator in page_content:
                            print(f'\n  [OK] Basarili mesaj: {indicator}')
                            return True

                    # Check if product count increased (on member page)
                    artikel_count = page.query_selector('text=/\\d+ Artikel/')
                    if artikel_count:
                        print('\n  [OK] Profil sayfasina yonlendirildi!')
                        return True

                    remaining = int(timeout_secs - (time.time() - start_wait))
                    print(f'  [{remaining}s] Yayinla butonuna tiklamanizi bekliyorum...', end='\r')
                    time.sleep(3)

                except Exception as e:
                    print(f'\n  [WARN] Kontrol hatasi: {e}')
                    time.sleep(3)

            print('\n  [TIMEOUT] 5 dakika doldu, devam ediliyor...')
            self.send_telegram('⏰ *Zaman Aşımı*\n\n5 dakika doldu. Lütfen durumu kontrol edin.')
            return False

        else:
            # AUTO PUBLISH (old behavior)
            print('  [7/7] Publishing...')
            publish_btn = page.query_selector('button:has-text("Hochladen"), button:has-text("Artikel hochladen")')
            if publish_btn and publish_btn.is_visible():
                publish_btn.click()
                time.sleep(5)

                # Check for CAPTCHA after publish
                is_captcha, _ = self.captcha_handler.detect_captcha(page)
                if is_captcha:
                    ss_path = os.path.join(DATA_DIR, f'captcha_publish_{product.get("id")}.png')
                    resolved = self.captcha_handler.handle_captcha(page, ss_path)
                    if not resolved:
                        return False

                print('  [OK] Published!')
                return True
            else:
                print('  [WARN] Publish button not found')
                return False

    # =========================================================================
    # MAIN RUN
    # =========================================================================

    def run(self, limit: int = DAILY_LIMIT):
        """Main run function"""
        self.print_banner()

        # Get products to upload
        products = db.get_products_by_status(STATUS_VALIDATED)[:limit]
        print(f'\n[INFO] {len(products)} products ready to upload')

        if not products:
            print('[INFO] No products to upload')
            return 0

        # Check VPN connection (GUI mode)
        if not self.connect_vpn():
            print('[ERROR] VPN connection required for cssberlin')
            print('[INFO] Please connect via Windscribe GUI to Germany')
            return 0

        try:
            with sync_playwright() as pw:
                context, page = self.launch_browser(pw)

                # Login
                if not self.login(page):
                    print('[ERROR] Login failed!')
                    self.send_telegram('❌ *cssberlin Login Failed*\nManual intervention required')
                    context.close()
                    return 0

                # Upload products
                for i, product in enumerate(products):
                    print(f'\n{"="*50}')
                    print(f'Product {i+1}/{len(products)}')
                    print(f'{"="*50}')

                    try:
                        if self.upload_product(page, product, manual_publish=self.manual_publish):
                            # Update database
                            db.update_product(product['id'], {
                                'status': STATUS_UPLOADED,
                                'target_store': 'cssberlin'
                            })
                            db.add_log(product['id'], 'upload', 'success', 'VPN upload to cssberlin')
                            self.products_uploaded += 1
                        else:
                            self.products_failed += 1
                            db.add_log(product['id'], 'upload', 'failed', 'Upload failed')

                    except Exception as e:
                        print(f'[ERROR] {e}')
                        self.products_failed += 1
                        db.add_log(product['id'], 'upload', 'error', str(e))

                    # Delay between products
                    if i < len(products) - 1:
                        delay = random.randint(MIN_DELAY_BETWEEN_PRODUCTS, MAX_DELAY_BETWEEN_PRODUCTS)
                        print(f'\n[WAIT] {delay}s before next product...')
                        time.sleep(delay)

                # Close browser
                print('\n[BROWSER] Closing...')
                context.close()

        finally:
            # Disconnect VPN
            self.disconnect_vpn()

        # Final report
        self._send_report()

        return self.products_uploaded

    def _send_report(self):
        """Send final report to Telegram"""
        report = f"""📊 *cssberlin Upload Report*

✅ Uploaded: {self.products_uploaded}
❌ Failed: {self.products_failed}
🔐 CAPTCHAs: {self.captcha_handler.captcha_count}

⏰ {datetime.now().strftime('%Y-%m-%d %H:%M')}"""

        print('\n' + '=' * 60)
        print('FINAL REPORT')
        print('=' * 60)
        print(f'Uploaded: {self.products_uploaded}')
        print(f'Failed: {self.products_failed}')
        print(f'CAPTCHAs: {self.captcha_handler.captcha_count}')

        self.send_telegram(report)


def main():
    import argparse
    parser = argparse.ArgumentParser(description='VPN Uploader for cssberlin')
    parser.add_argument('--limit', type=int, default=DAILY_LIMIT, help='Max products to upload')
    parser.add_argument('--no-vpn', action='store_true', help='Skip VPN connection')
    parser.add_argument('--auto-publish', action='store_true', help='Auto publish (no manual confirmation)')
    args = parser.parse_args()

    if args.no_vpn:
        global VPN_AVAILABLE
        VPN_AVAILABLE = False
        print('[INFO] VPN disabled by --no-vpn flag')

    uploader = VPNUploader()
    uploader.manual_publish = not args.auto_publish
    return uploader.run(args.limit)


if __name__ == '__main__':
    main()
