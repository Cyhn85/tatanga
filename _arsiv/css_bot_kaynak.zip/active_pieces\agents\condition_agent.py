#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Condition Normalization Agent
Multi-language condition normalization with semantic conflict detection

Features:
- Universal 1-5 condition scoring
- Multi-language condition term mapping
- Semantic conflict detection (label vs description)
- Learning from user feedback
- Event Bus integration

Author: TATANGA Team
Version: 2.0
"""

import sys
import asyncio
import sqlite3
import json
import re
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from core.event_bus import get_event_bus, emit, subscribe, on
except ImportError:
    # Fallback
    def get_event_bus(): return None
    async def emit(*args, **kwargs): pass
    def subscribe(*args, **kwargs): pass
    def on(*args, **kwargs): return lambda f: f

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")
        def debug(self, msg, **kwargs):
            self.logger.debug(f"{msg} {kwargs}")


class ConditionNormalizationAgent:
    """
    Condition Normalization Agent

    Converts platform-specific condition labels to universal 1-5 score.
    Detects semantic conflicts between label and description.

    Score System:
        5: New with tags / Mint condition
        4: Like new / Very good
        3: Good / Minor wear
        2: Fair / Visible wear
        1: Acceptable / Significant wear
        0: Defective / For parts
    """

    # Conflict keywords by language (indicate potential defects)
    CONFLICT_KEYWORDS = {
        'de': [
            'defekt', 'kaputt', 'riss', 'loch', 'fleck', 'kratzer',
            'beschädigt', 'gebrochen', 'fehlt', 'abgenutzt', 'verschlissen',
            'gerissen', 'verfärbt', 'ausgeblichen', 'mängel', 'fehler'
        ],
        'en': [
            'defect', 'broken', 'tear', 'hole', 'stain', 'scratch',
            'damaged', 'missing', 'worn', 'faded', 'discolored',
            'ripped', 'cracked', 'chipped', 'fault', 'flaw'
        ],
        'fr': [
            'défaut', 'cassé', 'déchiré', 'trou', 'tache', 'rayure',
            'endommagé', 'manquant', 'usé', 'décoloré', 'abîmé',
            'fissuré', 'fêlé', 'défaillant'
        ],
        'sv': [
            'defekt', 'trasig', 'hål', 'fläck', 'repa', 'skadad',
            'saknas', 'sliten', 'blekt', 'missfärgad', 'sprucken'
        ],
        'no': [
            'defekt', 'ødelagt', 'hull', 'flekk', 'ripe', 'skadet',
            'mangler', 'slitt', 'falmet', 'misfarget', 'sprukket'
        ],
        'it': [
            'difetto', 'rotto', 'buco', 'macchia', 'graffio', 'danneggiato',
            'mancante', 'consumato', 'sbiadito', 'scolorito', 'incrinato'
        ],
        'es': [
            'defecto', 'roto', 'agujero', 'mancha', 'arañazo', 'dañado',
            'falta', 'desgastado', 'descolorido', 'agrietado'
        ],
        'nl': [
            'defect', 'kapot', 'gat', 'vlek', 'kras', 'beschadigd',
            'ontbreekt', 'versleten', 'verbleekt', 'verkleurd'
        ],
        'pl': [
            'defekt', 'zepsuty', 'dziura', 'plama', 'zarysowanie', 'uszkodzony',
            'brakuje', 'zużyty', 'wyblakły', 'odbarwiony'
        ],
        'cs': [
            'defekt', 'rozbitý', 'díra', 'skvrna', 'škrábanec', 'poškozený',
            'chybí', 'opotřebovaný', 'vybledlý', 'odbarvený'
        ],
        'da': [
            'defekt', 'ødelagt', 'hul', 'plet', 'ridse', 'beskadiget',
            'mangler', 'slidt', 'falmet', 'misfarvet'
        ],
        'fi': [
            'viallinen', 'rikki', 'reikä', 'tahra', 'naarmu', 'vaurioitunut',
            'puuttuu', 'kulunut', 'haalistunut', 'värjäytynyt'
        ],
    }

    # Positive keywords that indicate good condition
    POSITIVE_KEYWORDS = {
        'de': ['neuwertig', 'wie neu', 'ungetragen', 'original', 'perfekt'],
        'en': ['mint', 'pristine', 'unworn', 'original', 'perfect', 'flawless'],
        'fr': ['neuf', 'impeccable', 'jamais porté', 'original', 'parfait'],
        'sv': ['nyskick', 'oanvänd', 'original', 'perfekt', 'felfri'],
        'no': ['nytt', 'ubrukt', 'original', 'perfekt', 'feilfri'],
    }

    def __init__(self, db_path: str = None):
        """
        Initialize Condition Normalization Agent

        Args:
            db_path: Path to database (default: storage/tatanga.db)
        """
        if db_path:
            self.db_path = Path(db_path)
        else:
            self.db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'

        self.logger = ModuleLogger("condition_agent")
        self.event_bus = get_event_bus()

        # Statistics
        self.stats = {
            'products_normalized': 0,
            'conflicts_detected': 0,
            'unknown_terms': 0,
            'terms_learned': 0
        }

        # Register event handlers
        self._register_handlers()

        self.logger.info("Condition Normalization Agent initialized")

    def _register_handlers(self):
        """Register event bus handlers"""
        if self.event_bus:
            subscribe('raw_product_found', self._handle_raw_product)

    async def _handle_raw_product(self, event):
        """Handle raw_product_found event"""
        product = event.data
        normalized = await self.normalize(product)

        # Emit normalized event
        await emit('product_normalized', normalized, source='condition_agent')

    async def normalize(self, product: Dict) -> Dict:
        """
        Normalize product condition

        Args:
            product: Raw product data with 'condition', 'description', 'language', 'platform'

        Returns:
            Product with added fields:
                - normalized_score: int (0-5)
                - is_conflicting: bool
                - conflict_reason: str or None
                - confidence: float (0-1)
        """
        raw_condition = product.get('condition', '')
        description = product.get('description', '').lower()
        language = self._extract_language(product)
        platform = self._extract_platform(product)

        # Get score from database
        score, confidence = self._get_score_from_db(raw_condition, language, platform)

        # If not found, try to infer
        if score is None:
            score, confidence = self._infer_score(raw_condition, language)
            if score is not None:
                # Log unknown term for learning
                await self._log_unknown_term(raw_condition, language, platform, score, confidence)

        # Default to middle score if still unknown
        if score is None:
            score = 3
            confidence = 0.3
            self.stats['unknown_terms'] += 1

        # Check for semantic conflicts
        is_conflicting, conflict_reason, conflict_keywords = self._detect_conflict(
            score, description, language
        )

        # Adjust confidence if conflicting
        if is_conflicting:
            confidence = min(confidence, 0.5)
            self.stats['conflicts_detected'] += 1

        # Check for positive keywords that might increase confidence
        if self._has_positive_keywords(description, language):
            confidence = min(confidence + 0.1, 1.0)

        self.stats['products_normalized'] += 1

        return {
            **product,
            'normalized_score': score,
            'is_conflicting': is_conflicting,
            'conflict_reason': conflict_reason,
            'conflict_keywords': conflict_keywords,
            'confidence': round(confidence, 2),
            'original_condition': raw_condition
        }

    def _extract_language(self, product: Dict) -> str:
        """Extract language code from product"""
        language = product.get('language', 'en')
        # Handle formats like 'de-DE', 'en-GB'
        if '-' in language:
            language = language.split('-')[0]
        return language.lower()

    def _extract_platform(self, product: Dict) -> str:
        """Extract platform base name"""
        platform = product.get('platform', 'unknown')
        # Handle formats like 'vinted_de', 'ebay_uk'
        if '_' in platform:
            platform = platform.split('_')[0]
        return platform.lower()

    def _get_score_from_db(self, raw_term: str, language: str, platform: str) -> Tuple[Optional[int], float]:
        """
        Get normalized score from database

        Returns:
            (score, confidence) or (None, 0) if not found
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            # Try exact match with platform
            cursor.execute("""
                SELECT normalized_score, confidence FROM condition_mapping
                WHERE LOWER(raw_term) = LOWER(?)
                AND language = ?
                AND platform = ?
                AND is_verified = 1
            """, (raw_term, language, platform))

            row = cursor.fetchone()
            if row:
                # Update usage count
                cursor.execute("""
                    UPDATE condition_mapping
                    SET usage_count = usage_count + 1, last_used = ?
                    WHERE LOWER(raw_term) = LOWER(?)
                    AND language = ?
                    AND platform = ?
                """, (datetime.now(), raw_term, language, platform))
                conn.commit()
                conn.close()
                return row[0], row[1]

            # Try with any platform (fallback)
            cursor.execute("""
                SELECT normalized_score, confidence FROM condition_mapping
                WHERE LOWER(raw_term) = LOWER(?)
                AND language = ?
                ORDER BY is_verified DESC, usage_count DESC
                LIMIT 1
            """, (raw_term, language))

            row = cursor.fetchone()
            conn.close()

            if row:
                return row[0], row[1] * 0.9  # Slightly lower confidence for platform mismatch

            return None, 0

        except Exception as e:
            self.logger.error("DB lookup error", exception=str(e))
            return None, 0

    def _infer_score(self, raw_term: str, language: str) -> Tuple[Optional[int], float]:
        """
        Infer score from term using heuristics

        Returns:
            (score, confidence) or (None, 0) if cannot infer
        """
        term_lower = raw_term.lower()

        # Score 5: New with tags
        if any(kw in term_lower for kw in ['neu mit', 'new with', 'neuf avec', 'ny med', 'nuovo con', 'nuevo con']):
            return 5, 0.8

        # Score 4: Like new / Very good
        if any(kw in term_lower for kw in ['sehr gut', 'very good', 'très bon', 'veldig', 'ottim', 'muy buen', 'nyskick']):
            return 4, 0.7

        # Score 3: Good
        if any(kw in term_lower for kw in ['gut', 'good', 'bon', 'bra', 'buon', 'buen', 'goed']):
            return 3, 0.6

        # Score 2: Fair / Used
        if any(kw in term_lower for kw in ['akzeptabel', 'fair', 'satisf', 'gebraucht', 'used', 'usato', 'usado']):
            return 2, 0.6

        # Score 1/0: Defective
        if any(kw in term_lower for kw in ['defekt', 'defect', 'kaputt', 'broken', 'parts', 'pièces', 'parti']):
            return 0, 0.7

        return None, 0

    def _detect_conflict(self, score: int, description: str, language: str) -> Tuple[bool, Optional[str], List[str]]:
        """
        Detect semantic conflict between score and description

        A conflict occurs when:
        - High score (4-5) but description mentions defects
        - Defect keywords found in description

        Returns:
            (is_conflicting, reason, found_keywords)
        """
        if score <= 2:
            # Low scores don't conflict with defect mentions
            return False, None, []

        conflict_keywords = self.CONFLICT_KEYWORDS.get(language, self.CONFLICT_KEYWORDS['en'])

        found_keywords = []
        for keyword in conflict_keywords:
            # Use word boundary matching to avoid false positives
            pattern = r'\b' + re.escape(keyword) + r'\b'
            if re.search(pattern, description, re.IGNORECASE):
                found_keywords.append(keyword)

        if found_keywords:
            reason = f"Description mentions: {', '.join(found_keywords[:3])}"
            return True, reason, found_keywords

        return False, None, []

    def _has_positive_keywords(self, description: str, language: str) -> bool:
        """Check if description contains positive condition keywords"""
        positive_keywords = self.POSITIVE_KEYWORDS.get(language, self.POSITIVE_KEYWORDS['en'])

        for keyword in positive_keywords:
            if keyword.lower() in description:
                return True

        return False

    async def _log_unknown_term(self, raw_term: str, language: str, platform: str,
                                 inferred_score: int, confidence: float):
        """Log unknown term for later learning"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT OR IGNORE INTO condition_mapping
                (language, platform, raw_term, normalized_score, confidence, is_verified, learned_from)
                VALUES (?, ?, ?, ?, ?, 0, 'inferred')
            """, (language, platform, raw_term, inferred_score, confidence))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error("Failed to log unknown term", exception=str(e))

    async def learn_term(self, raw_term: str, score: int, language: str, platform: str,
                         source: str = 'user') -> bool:
        """
        Learn a new condition term mapping

        Args:
            raw_term: Original condition term
            score: Normalized score (0-5)
            language: Language code
            platform: Platform name
            source: Learning source (user, llm, etc.)

        Returns:
            Success status
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO condition_mapping
                (language, platform, raw_term, normalized_score, confidence, is_verified, learned_from, updated_at)
                VALUES (?, ?, ?, ?, 1.0, 1, ?, ?)
                ON CONFLICT(language, platform, raw_term) DO UPDATE SET
                    normalized_score = ?,
                    confidence = 1.0,
                    is_verified = 1,
                    learned_from = ?,
                    updated_at = ?
            """, (language, platform, raw_term, score, source, datetime.now(),
                  score, source, datetime.now()))

            conn.commit()
            conn.close()

            self.stats['terms_learned'] += 1
            self.logger.info(f"Learned term: {raw_term} = {score} ({language}/{platform})")

            return True

        except Exception as e:
            self.logger.error("Failed to learn term", exception=str(e))
            return False

    def get_unknown_terms(self, limit: int = 20) -> List[Dict]:
        """Get unverified terms that need human review"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                SELECT raw_term, language, platform, normalized_score, confidence, usage_count
                FROM condition_mapping
                WHERE is_verified = 0
                ORDER BY usage_count DESC
                LIMIT ?
            """, (limit,))

            rows = cursor.fetchall()
            conn.close()

            return [
                {
                    'term': row[0],
                    'language': row[1],
                    'platform': row[2],
                    'suggested_score': row[3],
                    'confidence': row[4],
                    'usage_count': row[5]
                }
                for row in rows
            ]

        except Exception as e:
            self.logger.error("Failed to get unknown terms", exception=str(e))
            return []

    def get_stats(self) -> Dict:
        """Get agent statistics"""
        return {
            **self.stats,
            'db_path': str(self.db_path)
        }


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("CONDITION NORMALIZATION AGENT TEST")
    print("=" * 60)

    async def test():
        agent = ConditionNormalizationAgent()

        # Test products
        test_products = [
            {
                'title': 'Nike Air Force 1',
                'condition': 'Sehr gut',
                'description': 'Kaum getragen, wie neu',
                'language': 'de',
                'platform': 'vinted_de',
                'price': 45.0
            },
            {
                'title': 'Levi\'s 501 Jeans',
                'condition': 'Sehr gut',
                'description': 'Guter Zustand aber kleiner Riss am Knie',  # CONFLICT!
                'language': 'de',
                'platform': 'vinted_de',
                'price': 30.0
            },
            {
                'title': 'Adidas Gazelle',
                'condition': 'Very good',
                'description': 'Worn twice, excellent condition',
                'language': 'en',
                'platform': 'vinted_uk',
                'price': 35.0
            },
            {
                'title': 'Vintage Jacket',
                'condition': 'Bra skick',
                'description': 'Fint skick, inga defekter',
                'language': 'sv',
                'platform': 'tradera',
                'price': 50.0
            },
            {
                'title': 'Unknown Condition Test',
                'condition': 'Geht so',  # Unknown term
                'description': 'Normale Gebrauchsspuren',
                'language': 'de',
                'platform': 'kleinanzeigen',
                'price': 20.0
            }
        ]

        print("\nNormalizing products:")
        print("-" * 60)

        for product in test_products:
            result = await agent.normalize(product)
            print(f"\n{product['title']} ({product['platform']})")
            print(f"  Original: {product['condition']}")
            print(f"  Score: {result['normalized_score']}/5 (confidence: {result['confidence']})")
            print(f"  Conflicting: {result['is_conflicting']}")
            if result['is_conflicting']:
                print(f"  Reason: {result['conflict_reason']}")

        # Test learning
        print("\n" + "-" * 60)
        print("Testing term learning...")

        success = await agent.learn_term(
            raw_term='Geht so',
            score=2,
            language='de',
            platform='kleinanzeigen',
            source='test'
        )
        print(f"Learn 'Geht so' = 2: {'Success' if success else 'Failed'}")

        # Get unknown terms
        unknown = agent.get_unknown_terms()
        print(f"\nUnknown terms needing review: {len(unknown)}")
        for term in unknown[:5]:
            print(f"  {term['term']} ({term['language']}/{term['platform']}) - suggested: {term['suggested_score']}")

        print(f"\nStats: {agent.get_stats()}")
        print("\n" + "=" * 60)
        print("CONDITION NORMALIZATION AGENT TEST COMPLETE")
        print("=" * 60)

    asyncio.run(test())
