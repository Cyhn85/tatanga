#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA v3 - Category & Brand Mapper
Platform-specific category mappings and query builder
"""

import urllib.parse
from typing import Dict, List, Optional
from dataclasses import dataclass

# ============================================================================
# CATEGORY TREE (Vinted-style hierarchical structure)
# ============================================================================

CATEGORY_TREE = {
    "herren": {
        "label": "Herren",
        "icon": "male",
        "children": {
            "herren_mantel": {
                "label": "Mantel & Jacken",
                "icon": "jacket",
                "keywords": ["mantel", "jacke", "coat", "jacket", "parka", "blazer"]
            },
            "herren_schuhe": {
                "label": "Schuhe",
                "icon": "shoe",
                "children": {
                    "herren_stiefel": {
                        "label": "Stiefel",
                        "keywords": ["stiefel", "boots", "chelsea", "desert"]
                    },
                    "herren_sneaker": {
                        "label": "Sneaker",
                        "keywords": ["sneaker", "turnschuhe", "sportschuhe"]
                    },
                    "herren_klassisch": {
                        "label": "Klassische Schuhe",
                        "keywords": ["oxford", "derby", "loafer", "mokassin"]
                    }
                }
            },
            "herren_pullover": {
                "label": "Pullover & Sweater",
                "icon": "sweater",
                "keywords": ["pullover", "sweater", "strickpullover", "hoodie"]
            },
            "herren_hosen": {
                "label": "Hosen",
                "icon": "pants",
                "keywords": ["hose", "jeans", "chino", "shorts"]
            },
            "herren_hemden": {
                "label": "Hemden",
                "icon": "shirt",
                "keywords": ["hemd", "shirt", "polo", "t-shirt"]
            }
        }
    },
    "damen": {
        "label": "Damen",
        "icon": "female",
        "children": {
            "damen_mantel": {
                "label": "Mantel & Jacken",
                "icon": "jacket",
                "keywords": ["mantel", "jacke", "coat", "blazer", "parka"]
            },
            "damen_schuhe": {
                "label": "Schuhe",
                "icon": "shoe",
                "children": {
                    "damen_stiefel": {
                        "label": "Stiefel",
                        "keywords": ["stiefel", "boots", "stiefeletten"]
                    },
                    "damen_pumps": {
                        "label": "Pumps & High Heels",
                        "keywords": ["pumps", "high heels", "stiletto"]
                    },
                    "damen_sneaker": {
                        "label": "Sneaker",
                        "keywords": ["sneaker", "turnschuhe"]
                    }
                }
            },
            "damen_kleider": {
                "label": "Kleider",
                "icon": "dress",
                "keywords": ["kleid", "dress", "maxikleid", "minikleid"]
            },
            "damen_taschen": {
                "label": "Taschen",
                "icon": "bag",
                "keywords": ["tasche", "handtasche", "bag", "clutch"]
            }
        }
    }
}

# ============================================================================
# BRAND DATABASE
# ============================================================================

BRAND_DATABASE = {
    # Premium Brands
    "hugo_boss": {
        "name": "Hugo Boss",
        "aliases": ["hugo boss", "boss", "boss orange", "boss green", "hugo"],
        "category_affinity": ["herren_mantel", "herren_hemden", "herren_hosen"],
        "price_tier": "premium"
    },
    "ralph_lauren": {
        "name": "Ralph Lauren",
        "aliases": ["ralph lauren", "polo ralph lauren", "polo", "lauren"],
        "category_affinity": ["herren_hemden", "herren_pullover", "damen_kleider"],
        "price_tier": "premium"
    },
    "tommy_hilfiger": {
        "name": "Tommy Hilfiger",
        "aliases": ["tommy hilfiger", "tommy", "hilfiger"],
        "category_affinity": ["herren_mantel", "herren_pullover", "herren_hemden"],
        "price_tier": "premium"
    },
    "lacoste": {
        "name": "Lacoste",
        "aliases": ["lacoste"],
        "category_affinity": ["herren_hemden", "herren_pullover"],
        "price_tier": "premium"
    },
    "burberry": {
        "name": "Burberry",
        "aliases": ["burberry"],
        "category_affinity": ["herren_mantel", "damen_mantel", "damen_taschen"],
        "price_tier": "luxury"
    },

    # Mid-tier Brands
    "nike": {
        "name": "Nike",
        "aliases": ["nike", "nike sportswear", "nike air", "air jordan", "jordan"],
        "category_affinity": ["herren_sneaker", "damen_sneaker", "herren_pullover"],
        "price_tier": "mid"
    },
    "adidas": {
        "name": "Adidas",
        "aliases": ["adidas", "adidas originals", "adidas performance"],
        "category_affinity": ["herren_sneaker", "damen_sneaker", "herren_pullover"],
        "price_tier": "mid"
    },
    "puma": {
        "name": "Puma",
        "aliases": ["puma"],
        "category_affinity": ["herren_sneaker", "damen_sneaker"],
        "price_tier": "mid"
    },
    "levis": {
        "name": "Levi's",
        "aliases": ["levis", "levi's", "levi strauss"],
        "category_affinity": ["herren_hosen", "damen_hosen"],
        "price_tier": "mid"
    },

    # Luxury Shoe Brands
    "church": {
        "name": "Church's",
        "aliases": ["church's", "churchs", "church"],
        "category_affinity": ["herren_klassisch"],
        "price_tier": "luxury"
    },
    "santoni": {
        "name": "Santoni",
        "aliases": ["santoni"],
        "category_affinity": ["herren_klassisch"],
        "price_tier": "luxury"
    },
    "loake": {
        "name": "Loake",
        "aliases": ["loake"],
        "category_affinity": ["herren_klassisch", "herren_stiefel"],
        "price_tier": "premium"
    }
}

# ============================================================================
# PLATFORM MAPPINGS
# ============================================================================

PLATFORM_MAPPING = {
    # Herren Mantel
    "herren_mantel": {
        "ebay.de": {
            "category_id": "57988",
            "query_template": "{brand} Herren Mantel",
            "url_pattern": "https://www.ebay.de/sch/i.html?_nkw={query}&_sacat=57988"
        },
        "kleinanzeigen": {
            "category_path": "/s-herrenkleidung/jacken-maentel",
            "query_template": "{brand} Mantel",
            "url_pattern": "https://www.kleinanzeigen.de/s-herrenkleidung/jacken-maentel/{query}/k0c212"
        },
        "vinted.de": {
            "catalog_id": "5",
            "subcatalog_id": "2050",
            "query_template": "{brand}",
            "url_pattern": "https://www.vinted.de/vetements?catalog[]=5&search_text={query}"
        },
        "tradera": {
            "category_path": "herrklader/jackor",
            "query_template": "{brand} rock",
            "url_pattern": "https://www.tradera.com/kategori/herrklader/jackor?q={query}"
        },
        "sellpy": {
            "category_path": "herren/jacken-mantel",
            "query_template": "{brand}",
            "url_pattern": "https://www.sellpy.de/herren/jacken-mantel?query={query}"
        },
        "percentil": {
            "category_path": "hombre/abrigos",
            "query_template": "{brand}",
            "url_pattern": "https://www.percentil.de/hombre/abrigos?q={query}"
        },
        "willhaben": {
            "category_id": "4552",
            "query_template": "{brand} Mantel Herren",
            "url_pattern": "https://www.willhaben.at/iad/kaufen-und-verkaufen/marktplatz?keyword={query}&categoryId=4552"
        }
    },

    # Herren Schuhe (general)
    "herren_schuhe": {
        "ebay.de": {
            "category_id": "93427",
            "query_template": "{brand} Herrenschuhe",
            "url_pattern": "https://www.ebay.de/sch/i.html?_nkw={query}&_sacat=93427"
        },
        "kleinanzeigen": {
            "category_path": "/s-herrenschuhe",
            "query_template": "{brand} Schuhe",
            "url_pattern": "https://www.kleinanzeigen.de/s-herrenschuhe/{query}/k0c159"
        },
        "vinted.de": {
            "catalog_id": "1231",
            "query_template": "{brand}",
            "url_pattern": "https://www.vinted.de/vetements?catalog[]=1231&search_text={query}"
        },
        "tradera": {
            "category_path": "herrklader/skor",
            "query_template": "{brand}",
            "url_pattern": "https://www.tradera.com/kategori/herrklader/skor?q={query}"
        },
        "sellpy": {
            "category_path": "herren/schuhe",
            "query_template": "{brand}",
            "url_pattern": "https://www.sellpy.de/herren/schuhe?query={query}"
        },
        "percentil": {
            "category_path": "hombre/zapatos",
            "query_template": "{brand}",
            "url_pattern": "https://www.percentil.de/hombre/zapatos?q={query}"
        },
        "willhaben": {
            "category_id": "4562",
            "query_template": "{brand} Schuhe Herren",
            "url_pattern": "https://www.willhaben.at/iad/kaufen-und-verkaufen/marktplatz?keyword={query}&categoryId=4562"
        }
    },

    # Herren Stiefel
    "herren_stiefel": {
        "ebay.de": {
            "category_id": "11498",
            "query_template": "{brand} Stiefel Herren",
            "url_pattern": "https://www.ebay.de/sch/i.html?_nkw={query}&_sacat=11498"
        },
        "kleinanzeigen": {
            "category_path": "/s-herrenschuhe/stiefel",
            "query_template": "{brand} Stiefel",
            "url_pattern": "https://www.kleinanzeigen.de/s-herrenschuhe/{query}/k0c159"
        },
        "vinted.de": {
            "catalog_id": "1906",
            "query_template": "{brand} Stiefel",
            "url_pattern": "https://www.vinted.de/vetements?catalog[]=1906&search_text={query}"
        },
        "willhaben": {
            "category_id": "4562",
            "query_template": "{brand} Stiefel Herren",
            "url_pattern": "https://www.willhaben.at/iad/kaufen-und-verkaufen/marktplatz?keyword={query}&categoryId=4562"
        }
    },

    # Herren Pullover
    "herren_pullover": {
        "ebay.de": {
            "category_id": "11484",
            "query_template": "{brand} Pullover Herren",
            "url_pattern": "https://www.ebay.de/sch/i.html?_nkw={query}&_sacat=11484"
        },
        "kleinanzeigen": {
            "category_path": "/s-herrenkleidung/pullover",
            "query_template": "{brand} Pullover",
            "url_pattern": "https://www.kleinanzeigen.de/s-herrenkleidung/{query}/k0c212"
        },
        "vinted.de": {
            "catalog_id": "183",
            "query_template": "{brand}",
            "url_pattern": "https://www.vinted.de/vetements?catalog[]=183&search_text={query}"
        },
        "sellpy": {
            "category_path": "herren/pullover-sweater",
            "query_template": "{brand}",
            "url_pattern": "https://www.sellpy.de/herren/pullover-sweater?query={query}"
        },
        "willhaben": {
            "category_id": "4554",
            "query_template": "{brand} Pullover Herren",
            "url_pattern": "https://www.willhaben.at/iad/kaufen-und-verkaufen/marktplatz?keyword={query}&categoryId=4554"
        }
    }
}


# ============================================================================
# QUERY BUILDER
# ============================================================================

@dataclass
class SearchQuery:
    """Represents a search query for a specific platform"""
    platform: str
    brand: str
    category: str
    query: str
    url: str


def build_search_queries(
    category: str,
    brands: List[str],
    platforms: List[str]
) -> Dict[str, List[SearchQuery]]:
    """
    Build platform-specific search queries from category and brands.

    Args:
        category: Category key (e.g., 'herren_mantel')
        brands: List of brand names to search
        platforms: List of platform keys

    Returns:
        Dictionary mapping platform to list of SearchQuery objects
    """
    queries = {}
    mapping = PLATFORM_MAPPING.get(category, {})

    for platform in platforms:
        if platform not in mapping:
            continue

        config = mapping[platform]
        platform_queries = []

        for brand in brands:
            # Build query string
            query_text = config["query_template"].format(brand=brand)

            # Build URL
            url = config["url_pattern"].format(
                query=urllib.parse.quote(query_text),
                catalog=config.get("catalog_id", ""),
                category=config.get("category_id", "")
            )

            platform_queries.append(SearchQuery(
                platform=platform,
                brand=brand,
                category=category,
                query=query_text,
                url=url
            ))

        queries[platform] = platform_queries

    return queries


def get_category_label(category_key: str) -> str:
    """Get human-readable label for category key"""
    for main_cat, main_data in CATEGORY_TREE.items():
        if main_cat == category_key:
            return main_data["label"]

        if "children" in main_data:
            for sub_cat, sub_data in main_data["children"].items():
                if sub_cat == category_key:
                    return sub_data["label"]

                if "children" in sub_data:
                    for leaf_cat, leaf_data in sub_data["children"].items():
                        if leaf_cat == category_key:
                            return leaf_data["label"]

    return category_key


def get_brand_by_alias(alias: str) -> Optional[Dict]:
    """Find brand by alias (case-insensitive)"""
    alias_lower = alias.lower().strip()

    for key, brand in BRAND_DATABASE.items():
        if alias_lower == brand["name"].lower():
            return {**brand, "key": key}

        for brand_alias in brand.get("aliases", []):
            if alias_lower == brand_alias.lower():
                return {**brand, "key": key}

    return None


def get_brands_for_category(category: str) -> List[Dict]:
    """Get brands that have affinity for a category"""
    matching_brands = []

    for key, brand in BRAND_DATABASE.items():
        if category in brand.get("category_affinity", []):
            matching_brands.append({**brand, "key": key})

    return matching_brands


def get_all_categories_flat() -> List[Dict]:
    """Get flat list of all categories"""
    categories = []

    def traverse(tree, parent=None):
        for key, data in tree.items():
            cat = {
                "key": key,
                "label": data.get("label", key),
                "icon": data.get("icon", ""),
                "parent": parent,
                "has_children": "children" in data
            }
            categories.append(cat)

            if "children" in data:
                traverse(data["children"], key)

    traverse(CATEGORY_TREE)
    return categories


def get_supported_platforms() -> List[str]:
    """Get list of all supported platforms"""
    platforms = set()
    for category_mappings in PLATFORM_MAPPING.values():
        platforms.update(category_mappings.keys())
    return sorted(list(platforms))


# ============================================================================
# KLEINANZEIGEN → VINTED CATEGORY MAPPING
# ============================================================================

KLEINANZEIGEN_TO_VINTED = {
    # HERREN KLEIDUNG
    "herrenkleidung/jacken-maentel": {
        "vinted_catalog": 5,        # Herren
        "vinted_category": 2050,    # Mäntel & Jacken
        "vinted_subcategory": None,
        "label": "Herren Mäntel & Jacken"
    },
    "herrenkleidung/hosen": {
        "vinted_catalog": 5,
        "vinted_category": 1742,    # Hosen
        "vinted_subcategory": None,
        "label": "Herren Hosen"
    },
    "herrenkleidung/pullover-sweater": {
        "vinted_catalog": 5,
        "vinted_category": 1741,    # Pullover & Sweater
        "vinted_subcategory": None,
        "label": "Herren Pullover"
    },
    "herrenkleidung/hemden": {
        "vinted_catalog": 5,
        "vinted_category": 1739,    # Hemden
        "vinted_subcategory": None,
        "label": "Herren Hemden"
    },
    "herrenkleidung/t-shirts": {
        "vinted_catalog": 5,
        "vinted_category": 1740,    # T-Shirts
        "vinted_subcategory": None,
        "label": "Herren T-Shirts"
    },
    "herrenkleidung/anzuege": {
        "vinted_catalog": 5,
        "vinted_category": 1744,    # Anzüge & Sakkos
        "vinted_subcategory": None,
        "label": "Herren Anzüge"
    },
    "herrenkleidung/sportkleidung": {
        "vinted_catalog": 5,
        "vinted_category": 2051,    # Sportbekleidung
        "vinted_subcategory": None,
        "label": "Herren Sportkleidung"
    },

    # HERREN SCHUHE
    "herrenschuhe": {
        "vinted_catalog": 5,
        "vinted_category": 1758,    # Schuhe
        "vinted_subcategory": None,
        "label": "Herrenschuhe"
    },
    "herrenschuhe/stiefel": {
        "vinted_catalog": 5,
        "vinted_category": 1906,    # Stiefel
        "vinted_subcategory": None,
        "label": "Herren Stiefel"
    },
    "herrenschuhe/sneaker": {
        "vinted_catalog": 5,
        "vinted_category": 1759,    # Sneaker
        "vinted_subcategory": None,
        "label": "Herren Sneaker"
    },
    "herrenschuhe/business": {
        "vinted_catalog": 5,
        "vinted_category": 1760,    # Business Schuhe
        "vinted_subcategory": None,
        "label": "Herren Business Schuhe"
    },

    # DAMEN KLEIDUNG
    "damenkleidung/jacken-maentel": {
        "vinted_catalog": 4,        # Damen
        "vinted_category": 1746,    # Mäntel & Jacken
        "vinted_subcategory": None,
        "label": "Damen Mäntel & Jacken"
    },
    "damenkleidung/kleider": {
        "vinted_catalog": 4,
        "vinted_category": 1747,    # Kleider
        "vinted_subcategory": None,
        "label": "Damen Kleider"
    },
    "damenkleidung/blusen": {
        "vinted_catalog": 4,
        "vinted_category": 1748,    # Blusen & Tuniken
        "vinted_subcategory": None,
        "label": "Damen Blusen"
    },
    "damenkleidung/roecke": {
        "vinted_catalog": 4,
        "vinted_category": 1749,    # Röcke
        "vinted_subcategory": None,
        "label": "Damen Röcke"
    },
    "damenkleidung/hosen": {
        "vinted_catalog": 4,
        "vinted_category": 1750,    # Hosen
        "vinted_subcategory": None,
        "label": "Damen Hosen"
    },
    "damenkleidung/pullover-sweater": {
        "vinted_catalog": 4,
        "vinted_category": 1755,    # Pullover & Sweater
        "vinted_subcategory": None,
        "label": "Damen Pullover"
    },

    # DAMEN SCHUHE
    "damenschuhe": {
        "vinted_catalog": 4,
        "vinted_category": 1751,    # Schuhe
        "vinted_subcategory": None,
        "label": "Damenschuhe"
    },
    "damenschuhe/stiefel": {
        "vinted_catalog": 4,
        "vinted_category": 1752,    # Stiefel & Stiefeletten
        "vinted_subcategory": None,
        "label": "Damen Stiefel"
    },
    "damenschuhe/sneaker": {
        "vinted_catalog": 4,
        "vinted_category": 1753,    # Sneaker
        "vinted_subcategory": None,
        "label": "Damen Sneaker"
    },
    "damenschuhe/pumps": {
        "vinted_catalog": 4,
        "vinted_category": 1754,    # Pumps & High Heels
        "vinted_subcategory": None,
        "label": "Damen Pumps"
    },

    # KINDER
    "kinderkleidung/jungen": {
        "vinted_catalog": 1,        # Kinder
        "vinted_category": 2087,    # Jungen
        "vinted_subcategory": None,
        "label": "Jungen Kleidung"
    },
    "kinderkleidung/maedchen": {
        "vinted_catalog": 1,
        "vinted_category": 2088,    # Mädchen
        "vinted_subcategory": None,
        "label": "Mädchen Kleidung"
    },
    "kinderkleidung/baby": {
        "vinted_catalog": 1,
        "vinted_category": 2086,    # Baby
        "vinted_subcategory": None,
        "label": "Baby Kleidung"
    },

    # ACCESSOIRES
    "accessoires/taschen": {
        "vinted_catalog": 6,        # Accessoires
        "vinted_category": 1756,    # Taschen
        "vinted_subcategory": None,
        "label": "Taschen"
    },
    "accessoires/uhren": {
        "vinted_catalog": 6,
        "vinted_category": 2089,    # Uhren
        "vinted_subcategory": None,
        "label": "Uhren"
    },
    "accessoires/schmuck": {
        "vinted_catalog": 6,
        "vinted_category": 2090,    # Schmuck
        "vinted_subcategory": None,
        "label": "Schmuck"
    },
    "accessoires/guertel": {
        "vinted_catalog": 6,
        "vinted_category": 2091,    # Gürtel
        "vinted_subcategory": None,
        "label": "Gürtel"
    },
    "accessoires/schals-tuecher": {
        "vinted_catalog": 6,
        "vinted_category": 2092,    # Schals & Tücher
        "vinted_subcategory": None,
        "label": "Schals & Tücher"
    }
}

# Reverse mapping: Vinted category → Kleinanzeigen path
VINTED_TO_KLEINANZEIGEN = {
    f"{v['vinted_catalog']}_{v['vinted_category']}": k
    for k, v in KLEINANZEIGEN_TO_VINTED.items()
}


# ============================================================================
# CONDITION MAPPING
# ============================================================================

CONDITION_MAPPING = {
    # Kleinanzeigen condition → Vinted condition ID
    "neu": 6,                   # Neu mit Etikett
    "neu mit etikett": 6,
    "new with tags": 6,
    "nwt": 6,

    "wie neu": 1,               # Neu ohne Etikett
    "neu ohne etikett": 1,
    "new without tags": 1,

    "sehr gut": 2,              # Sehr gut
    "very good": 2,
    "excellent": 2,

    "gut": 3,                   # Gut
    "good": 3,
    "normal": 3,

    "akzeptabel": 4,            # Zufriedenstellend
    "acceptable": 4,
    "fair": 4,
    "gebraucht": 4,
    "stark gebraucht": 4,
    "used": 4,
}

# Vinted condition ID → Label mapping
VINTED_CONDITIONS = {
    6: "Neu mit Etikett",
    1: "Neu ohne Etikett",
    2: "Sehr gut",
    3: "Gut",
    4: "Zufriedenstellend"
}


def map_category_to_vinted(
    source_category: str,
    source_platform: str = "kleinanzeigen"
) -> Optional[Dict]:
    """
    Kategoriyi Vinted formatına çevir.

    Args:
        source_category: Kaynak platform kategori yolu (e.g., "herrenkleidung/jacken-maentel")
        source_platform: Kaynak platform adı

    Returns:
        Dict with vinted_catalog, vinted_category, vinted_subcategory
        or None if no mapping found
    """
    if source_platform.lower() in ["kleinanzeigen", "ebay_kleinanzeigen"]:
        # Normalize category path
        normalized = source_category.lower().strip('/')

        # Direct match
        if normalized in KLEINANZEIGEN_TO_VINTED:
            return KLEINANZEIGEN_TO_VINTED[normalized]

        # Try partial match
        for ka_path, vinted_data in KLEINANZEIGEN_TO_VINTED.items():
            if normalized in ka_path or ka_path in normalized:
                return vinted_data

    return None


def map_condition_to_vinted(
    source_condition: str,
    source_platform: str = "kleinanzeigen"
) -> int:
    """
    Ürün durumunu Vinted ID'sine çevir.

    Args:
        source_condition: Kaynak durum metni (e.g., "Sehr gut", "Wie neu")
        source_platform: Kaynak platform adı

    Returns:
        Vinted condition ID (1-6), default 3 (Gut)
    """
    if not source_condition:
        return 3  # Default: Gut

    normalized = source_condition.lower().strip()

    # Direct match
    if normalized in CONDITION_MAPPING:
        return CONDITION_MAPPING[normalized]

    # Partial match
    for key, vinted_id in CONDITION_MAPPING.items():
        if key in normalized or normalized in key:
            return vinted_id

    # Default
    return 3  # Gut


def get_vinted_condition_label(condition_id: int) -> str:
    """Get Vinted condition label from ID."""
    return VINTED_CONDITIONS.get(condition_id, "Gut")


def detect_category_from_title(title: str) -> Optional[str]:
    """
    Ürün başlığından kategori tahmin et.

    Args:
        title: Ürün başlığı

    Returns:
        Kategori key veya None
    """
    if not title:
        return None

    title_lower = title.lower()

    # Keyword-based detection
    category_keywords = {
        "herren_mantel": ["mantel", "jacke", "coat", "jacket", "parka", "blazer herren"],
        "herren_schuhe": ["herrenschuhe", "schuhe herren", "shoes men"],
        "herren_stiefel": ["stiefel herren", "boots herren", "chelsea boots"],
        "herren_sneaker": ["sneaker herren", "nike herren", "adidas herren"],
        "herren_pullover": ["pullover herren", "sweater herren", "hoodie herren"],
        "herren_hemden": ["hemd herren", "shirt herren", "polo herren"],
        "herren_hosen": ["hose herren", "jeans herren", "chino herren"],
        "damen_mantel": ["mantel damen", "jacke damen", "coat ladies"],
        "damen_kleider": ["kleid", "dress", "maxikleid", "minikleid"],
        "damen_schuhe": ["damenschuhe", "schuhe damen", "pumps", "high heels"],
        "damen_taschen": ["tasche", "handtasche", "bag", "clutch"],
    }

    for category, keywords in category_keywords.items():
        for keyword in keywords:
            if keyword in title_lower:
                return category

    return None


def get_full_category_path(
    source_platform: str,
    target_platform: str,
    source_category: str
) -> Dict:
    """
    Kaynak kategoriden hedef platform kategorisine tam yol al.

    Args:
        source_platform: Kaynak platform (kleinanzeigen, vinted, ebay)
        target_platform: Hedef platform
        source_category: Kaynak kategori

    Returns:
        Dict with platform-specific category info
    """
    result = {
        'source_platform': source_platform,
        'target_platform': target_platform,
        'source_category': source_category,
        'target_category': None,
        'success': False
    }

    if target_platform.lower().startswith('vinted'):
        vinted_data = map_category_to_vinted(source_category, source_platform)
        if vinted_data:
            result['target_category'] = vinted_data
            result['success'] = True
            result['target_url'] = f"https://www.vinted.de/catalog?catalog[]={vinted_data['vinted_catalog']}"

    elif target_platform.lower() == 'kleinanzeigen':
        # Vinted → Kleinanzeigen
        vinted_key = f"{source_category}"
        if vinted_key in VINTED_TO_KLEINANZEIGEN:
            ka_path = VINTED_TO_KLEINANZEIGEN[vinted_key]
            result['target_category'] = ka_path
            result['success'] = True
            result['target_url'] = f"https://www.kleinanzeigen.de/{ka_path}"

    return result


# ============================================================================
# TEST
# ============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("TATANGA v3 - Category Mapper Test")
    print("=" * 60)

    # Test 1: Build search queries
    print("\n--- Test: Build Search Queries ---")
    queries = build_search_queries(
        category="herren_mantel",
        brands=["Nike", "Hugo Boss"],
        platforms=["ebay.de", "kleinanzeigen", "willhaben"]
    )

    for platform, platform_queries in queries.items():
        print(f"\n{platform}:")
        for q in platform_queries:
            print(f"  Brand: {q.brand}")
            print(f"  Query: {q.query}")
            print(f"  URL: {q.url[:80]}...")

    # Test 2: Brand lookup
    print("\n--- Test: Brand Lookup ---")
    brand = get_brand_by_alias("boss")
    if brand:
        print(f"Found: {brand['name']} (tier: {brand['price_tier']})")

    # Test 3: Categories
    print("\n--- Test: All Categories ---")
    cats = get_all_categories_flat()
    for cat in cats[:5]:
        print(f"  {cat['key']}: {cat['label']}")

    # Test 4: Supported platforms
    print("\n--- Test: Supported Platforms ---")
    platforms = get_supported_platforms()
    print(f"  {', '.join(platforms)}")

    print("\n" + "=" * 60)
    print("Category Mapper Test Complete!")
