# Proxy Manager Dashboard - Streamlit Single-Page Interface
# Tek ekrandan tüm proxy yönetimi

import streamlit as st
import sys
import os

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import STORE_RULES, PROXY_SERVICES, ROTATION_CONFIG, VPN_OPTIONS
from quota_tracker import get_tracker
from proxy_pool import get_pool

st.set_page_config(
    page_title="Proxy Manager",
    page_icon="🔄",
    layout="wide"
)

def main():
    st.title("🔄 Proxy Manager Dashboard")
    st.caption("Otomatik proxy rotasyonu ve kota takibi")

    # Get instances
    tracker = get_tracker()
    pool = get_pool()

    # Sidebar - Store Rules
    with st.sidebar:
        st.header("📋 Mağaza Kuralları")
        for store_id, rule in STORE_RULES.items():
            mode = rule.get('proxy_mode', 'direct')
            emoji = "🏠" if mode == 'direct' else "🔄"
            desc = rule.get('description', '')
            st.markdown(f"**{emoji} {store_id}**")
            st.caption(desc)
            st.divider()

        st.header("⚙️ Ayarlar")
        threshold = ROTATION_CONFIG.get('auto_switch_threshold', 7)
        st.metric("Otomatik Geçiş Eşiği", f"%{threshold}")

    # Main content - 3 columns
    col1, col2, col3 = st.columns(3)

    # Column 1: Quota Status
    with col1:
        st.subheader("📊 Kota Durumu")

        quotas = tracker.get_all_quotas()
        for q in quotas:
            service = q['service']
            remaining = q['remaining']
            limit = q['limit']
            pct = q['percentage']
            ptype = q['proxy_type']

            # Color based on percentage
            if pct > 50:
                color = "🟢"
            elif pct > 20:
                color = "🟡"
            else:
                color = "🔴"

            st.markdown(f"**{color} {service.upper()}** ({ptype})")

            if q['type'] == 'unlimited':
                st.progress(1.0)
                st.caption(f"Sınırsız - Bugün: {q['used']} kullanım")
            else:
                st.progress(pct / 100)
                st.caption(f"{remaining}/{limit} kalan ({pct}%)")

            st.divider()

    # Column 2: Active Connections
    with col2:
        st.subheader("🔗 Aktif Bağlantılar")

        status = pool.get_status()
        active = status.get('active_stores', {})

        if active:
            for store_id, proxy in active.items():
                st.markdown(f"**{store_id}**")
                st.write(f"Servis: {proxy.get('service', 'N/A')}")
                st.write(f"Tip: {proxy.get('type', 'N/A')}")
                if proxy.get('url'):
                    st.code(proxy['url'], language=None)
                st.divider()
        else:
            st.info("Henüz aktif bağlantı yok")

        # Quick actions
        st.subheader("⚡ Hızlı İşlemler")

        if st.button("🔄 Proxy Yenile", use_container_width=True):
            pool.current_proxies.clear()
            st.success("Tüm proxy'ler sıfırlandı!")
            st.rerun()

        if st.button("📈 Kota Güncelle", use_container_width=True):
            st.success("Kota verileri güncellendi!")
            st.rerun()

    # Column 3: Best Available & Recommendations
    with col3:
        st.subheader("💡 Öneriler")

        best = status.get('best_available')
        if best:
            st.success(f"En iyi seçenek: **{best.upper()}**")
        else:
            st.error("Kullanılabilir proxy yok!")

        # Warnings
        warnings = status.get('low_quota_warnings', [])
        if warnings:
            st.warning(f"Düşük kota: {', '.join(warnings)}")

        # Service info
        st.subheader("ℹ️ Servis Bilgileri")

        for service, config in PROXY_SERVICES.items():
            if config.get('enabled'):
                with st.expander(f"{service.upper()}"):
                    st.write(f"**Tip:** {config.get('type', 'N/A')}")
                    st.write(f"**Kota:** {config.get('quota_limit', 'N/A')} {config.get('quota_unit', '')}/{config.get('quota_type', '')}")
                    st.write(f"**Kalite:** {'⭐' * config.get('quality', 3)}")
                    if config.get('docs'):
                        st.markdown(f"[📚 Dokümantasyon]({config['docs']})")

    # Footer - Overall stats
    st.divider()
    footer_cols = st.columns(4)

    with footer_cols[0]:
        total_remaining = status.get('total_remaining', 0)
        st.metric("Toplam Kalan Kota", f"{total_remaining:,}")

    with footer_cols[1]:
        overall_pct = status.get('overall_percentage', 0)
        st.metric("Genel Doluluk", f"%{100 - overall_pct:.1f}")

    with footer_cols[2]:
        enabled_count = len([s for s in PROXY_SERVICES.values() if s.get('enabled')])
        st.metric("Aktif Servis", enabled_count)

    with footer_cols[3]:
        st.metric("Rotasyon Eşiği", f"%{threshold}")


if __name__ == '__main__':
    main()
