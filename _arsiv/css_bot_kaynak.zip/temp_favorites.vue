<template>
  <div>
    <h1 class="text-3xl font-bold mb-6">Favoriler</h1>

    <!-- Stats -->
    <div class="bg-white rounded-lg shadow p-4 mb-6">
      <div class="flex gap-4 items-center flex-wrap">
        <span class="text-gray-500">{{ totalCount }} favori urun</span>
        <span class="text-gray-400">|</span>
        <span class="text-gray-500">Sayfa {{ currentPage }}/{{ totalPages }}</span>
        <div class="flex gap-2 ml-auto">
          <button v-if="selectedFavorites.length > 0" @click="bulkPublish"
                  class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
            {{ selectedFavorites.length }} Urun Yayinla
          </button>
          <button v-if="favorites.length > 0" @click="removeAll"
                  class="text-red-600 hover:text-red-800 px-3 py-1 border border-red-300 rounded hover:bg-red-50">
            Tumunu Kaldir
          </button>
        </div>
      </div>
    </div>

    <!-- Favorites Table -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
      <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
          <tr>
            <th class="px-4 py-3 text-left">
              <input type="checkbox" @change="toggleSelectAll" :checked="allSelected" class="w-4 h-4" />
            </th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Gorsel</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Baslik</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fiyat Detay</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Eklendi</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Eylemler</th>
          </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
          <tr v-for="fav in paginatedFavorites" :key="fav.id" class="hover:bg-gray-50">
            <td class="px-4 py-3">
              <input type="checkbox" v-model="selectedFavorites" :value="fav.id" class="w-4 h-4" />
            </td>
            <td class="px-4 py-3 text-sm text-gray-500 font-mono">{{ fav.fav_id }}</td>
            <td class="px-4 py-3">
              <img v-if="getFirstImage(fav.product)" :src="getFirstImage(fav.product)"
                   class="w-20 h-20 object-cover rounded cursor-pointer hover:opacity-80"
                   @click="openPublishModal(fav)" />
              <div v-else class="w-20 h-20 bg-gray-200 rounded flex items-center justify-center text-gray-400">?</div>
            </td>
            <td class="px-4 py-3">
              <a :href="fav.product?.source_url" target="_blank" class="text-blue-600 hover:underline font-medium">
                {{ truncate(fav.product?.title, 50) }}
              </a>
              <div class="text-xs text-gray-400 mt-1">{{ fav.product?.brand || '-' }}</div>
            </td>
            <td class="px-4 py-3">
              <div class="text-lg font-bold text-green-600">{{ formatCurrency(fav.product?.price) }}</div>
              <div class="text-xs text-gray-500">Komisyon: ~{{ formatCurrency((fav.product?.price || 0) * 0.05) }}</div>
              <div class="text-xs text-gray-500">Kargo: ~{{ formatCurrency(4.99) }}</div>
              <div class="text-xs text-blue-600 font-semibold mt-1">Oneri: {{ formatCurrency((fav.product?.price || 0) * 1.3 + 4.99) }}</div>
            </td>
            <td class="px-4 py-3 text-sm text-gray-500">{{ formatDate(fav.added_at) }}</td>
            <td class="px-4 py-3">
              <div class="flex gap-2">
                <button @click="openPublishModal(fav)"
                        class="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-lg text-sm hover:from-blue-700 hover:to-purple-700 shadow-lg">
                  Yayinla
                </button>
                <a :href="fav.product?.source_url" target="_blank" class="text-blue-500 hover:text-blue-600 text-xl p-2" title="Kaynak">L</a>
                <button @click="remove(fav.id)" class="text-red-500 hover:text-red-600 text-xl p-2" title="Kaldir">X</button>
              </div>
            </td>
          </tr>
          <tr v-if="favorites.length === 0">
            <td colspan="7" class="px-4 py-8 text-center text-gray-500">
              Henuz favori urun yok. Urunler sayfasindan yildiza tiklayarak ekleyebilirsiniz.
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <div v-if="totalPages > 1" class="mt-6 flex justify-center items-center gap-2">
      <button @click="goToPage(1)" :disabled="currentPage === 1"
              class="px-3 py-2 rounded border hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed">
        &lt;&lt;
      </button>
      <button @click="goToPage(currentPage - 1)" :disabled="currentPage === 1"
              class="px-3 py-2 rounded border hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed">
        &lt;
      </button>
      <template v-for="page in visiblePages" :key="page">
        <button v-if="page !== '...'" @click="goToPage(page)"
                :class="page === currentPage ? 'bg-blue-600 text-white' : 'bg-white hover:bg-gray-100'"
                class="px-4 py-2 rounded border font-medium">
          {{ page }}
        </button>
        <span v-else class="px-2 text-gray-400">...</span>
      </template>
      <button @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages"
              class="px-3 py-2 rounded border hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed">
        &gt;
      </button>
      <button @click="goToPage(totalPages)" :disabled="currentPage === totalPages"
              class="px-3 py-2 rounded border hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed">
        &gt;&gt;
      </button>
      <select v-model="itemsPerPage" @change="goToPage(1)" class="ml-4 border rounded px-2 py-2">
        <option :value="25">25 / sayfa</option>
        <option :value="50">50 / sayfa</option>
        <option :value="100">100 / sayfa</option>
      </select>
    </div>

    <!-- Advanced Publishing Modal -->
    <div v-if="publishModal.show" class="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4" @click.self="closePublishModal">
      <div class="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <div class="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-4 flex justify-between items-center">
          <h2 class="text-xl font-bold">Urun Yayinlama</h2>
          <button @click="closePublishModal" class="text-white hover:text-gray-200 text-2xl">x</button>
        </div>

        <div class="overflow-y-auto max-h-[calc(90vh-180px)]">
          <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 p-6">
            <div>
              <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Gorseller</label>
                <div class="grid grid-cols-3 gap-2">
                  <img v-for="(img, i) in getImages(publishModal.product)" :key="i" :src="img"
                       class="w-full h-24 object-cover rounded-lg border-2 border-gray-200 hover:border-blue-500 cursor-pointer" />
                </div>
              </div>
              <div class="mb-4 p-3 bg-gray-50 rounded-lg">
                <label class="block text-xs font-medium text-gray-500 mb-1">Kaynak URL</label>
                <a :href="publishModal.product?.source_url" target="_blank" class="text-blue-600 hover:underline text-sm break-all">
                  {{ publishModal.product?.source_url }}
                </a>
              </div>
              <div class="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                <h3 class="font-bold text-yellow-800 mb-3">Fiyat Hesaplama</h3>
                <div class="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <label class="text-gray-600">Kaynak Fiyat:</label>
                    <div class="font-bold">{{ formatCurrency(publishModal.product?.price) }}</div>
                  </div>
                  <div>
                    <label class="text-gray-600">Komisyon (~5%):</label>
                    <div class="font-bold text-red-600">-{{ formatCurrency(publishModal.salePrice * 0.05) }}</div>
                  </div>
                  <div>
                    <label class="text-gray-600">Kargo:</label>
                    <input type="number" v-model="publishModal.shippingCost" step="0.5" min="0" class="w-full border rounded px-2 py-1" />
                  </div>
                  <div>
                    <label class="text-gray-600">Net Kazanc:</label>
                    <div class="font-bold text-green-600 text-lg">
                      {{ formatCurrency(publishModal.salePrice - (publishModal.product?.price || 0) - (publishModal.salePrice * 0.05) - publishModal.shippingCost) }}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Platformlar</label>
                <div class="grid grid-cols-2 gap-2">
                  <label v-for="platform in platforms" :key="platform.id"
                         class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50"
                         :class="publishModal.selectedPlatforms.includes(platform.id) ? 'border-blue-500 bg-blue-50' : 'border-gray-200'">
                    <input type="checkbox" v-model="publishModal.selectedPlatforms" :value="platform.id" class="w-4 h-4 mr-3" />
                    <span class="ml-2 font-medium">{{ platform.name }}</span>
                  </label>
                </div>
              </div>
              <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Satis Fiyati (EUR)</label>
                <input type="number" v-model="publishModal.salePrice" step="0.01" min="0"
                       class="w-full border-2 border-gray-300 rounded-lg px-4 py-3 text-xl font-bold text-green-600 focus:border-blue-500" />
                <div class="text-xs text-gray-500 mt-1">Onerilen: {{ formatCurrency((publishModal.product?.price || 0) * 1.3 + 4.99) }}</div>
              </div>
              <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Baslik (SEO)</label>
                <input type="text" v-model="publishModal.title" maxlength="80" class="w-full border rounded-lg px-4 py-2" />
                <div class="text-xs text-gray-500 mt-1">{{ publishModal.title?.length || 0 }}/80</div>
              </div>
              <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Aciklama</label>
                <textarea v-model="publishModal.description" rows="4" maxlength="500" class="w-full border rounded-lg px-4 py-2"></textarea>
                <div class="text-xs text-gray-500 mt-1">{{ publishModal.description?.length || 0 }}/500</div>
              </div>
              <button @click="generateSEO" class="w-full bg-purple-100 text-purple-700 px-4 py-2 rounded-lg hover:bg-purple-200 mb-4">
                AI SEO Optimize
              </button>
            </div>
          </div>
        </div>
        <div class="bg-gray-50 px-6 py-4 flex justify-between items-center border-t">
          <div class="text-sm text-gray-500">{{ publishModal.selectedPlatforms.length }} platform</div>
          <div class="flex gap-3">
            <button @click="closePublishModal" class="px-6 py-2 border rounded-lg hover:bg-gray-100">Iptal</button>
            <button @click="submitPublish" :disabled="publishModal.selectedPlatforms.length === 0 || publishing"
                    class="px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg disabled:opacity-50">
              <span v-if="publishing">Yayinlaniyor...</span>
              <span v-else>Yayinla</span>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Success Modal -->
    <div v-if="successModal.show" class="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
      <div class="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden">
        <div class="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-4">
          <h2 class="text-xl font-bold">Yayinlama Basarili!</h2>
        </div>
        <div class="p-6">
          <p class="text-gray-600 mb-4">Urun asagidaki platformlarda yayinlandi:</p>
          <div class="space-y-3">
            <div v-for="pub in successModal.publications" :key="pub.platform" class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <span class="font-bold">{{ pub.platform }}</span>
                <div class="text-xs text-gray-500">ID: {{ pub.pub_id }}</div>
              </div>
              <a v-if="pub.listing_url" :href="pub.listing_url" target="_blank" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm">Goruntule</a>
              <span v-else class="text-yellow-600 text-sm">Bekleniyor</span>
            </div>
          </div>
          <div class="mt-6 flex gap-3">
            <button @click="goToPublishing" class="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg">Yayinlari Gor</button>
            <button @click="successModal.show = false" class="flex-1 border px-4 py-2 rounded-lg">Kapat</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue"
import { useRouter } from "vue-router"
import api from "../api/client"

const router = useRouter()
const favorites = ref([])
const selectedFavorites = ref([])
const publishing = ref(false)
const currentPage = ref(1)
const itemsPerPage = ref(50)

const platforms = [
  { id: "cssberlin.de", name: "CSS Berlin" },
  { id: "vinted", name: "Vinted" },
  { id: "ebay", name: "eBay" },
  { id: "kleinanzeigen", name: "Kleinanzeigen" },
]

const publishModal = ref({
  show: false,
  product: null,
  favorite: null,
  selectedPlatforms: ["cssberlin.de"],
  salePrice: 0,
  shippingCost: 4.99,
  title: "",
  description: ""
})

const successModal = ref({ show: false, publications: [] })

const totalCount = computed(() => favorites.value.length)
const totalPages = computed(() => Math.ceil(totalCount.value / itemsPerPage.value) || 1)

const paginatedFavorites = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage.value
  return favorites.value.slice(start, start + itemsPerPage.value)
})

const visiblePages = computed(() => {
  const pages = []
  const total = totalPages.value
  const current = currentPage.value
  if (total <= 7) {
    for (let i = 1; i <= total; i++) pages.push(i)
  } else {
    pages.push(1)
    if (current > 3) pages.push("...")
    for (let i = Math.max(2, current - 1); i <= Math.min(total - 1, current + 1); i++) {
      pages.push(i)
    }
    if (current < total - 2) pages.push("...")
    pages.push(total)
  }
  return pages
})

const allSelected = computed(() => favorites.value.length > 0 && selectedFavorites.value.length === favorites.value.length)

const goToPage = (page) => {
  if (page >= 1 && page <= totalPages.value) currentPage.value = page
}

const getFirstImage = (product) => {
  if (product?.images && product.images.length > 0) return product.images[0].url || product.images[0]
  return null
}

const getImages = (product) => {
  if (!product?.images) return []
  return product.images.slice(0, 6).map(img => img.url || img)
}

const truncate = (text, len) => {
  if (!text) return "-"
  return text.length > len ? text.substring(0, len) + "..." : text
}

const formatCurrency = (value) => {
  if (value === null || value === undefined) return "-"
  return new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(value)
}

const formatDate = (dateStr) => {
  if (!dateStr) return "-"
  return new Date(dateStr).toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" })
}

const toggleSelectAll = () => {
  if (allSelected.value) selectedFavorites.value = []
  else selectedFavorites.value = favorites.value.map(f => f.id)
}

const openPublishModal = (fav) => {
  const product = fav.product
  publishModal.value = {
    show: true,
    product: product,
    favorite: fav,
    selectedPlatforms: ["cssberlin.de"],
    salePrice: Math.round((product?.price || 0) * 1.3 + 4.99),
    shippingCost: 4.99,
    title: product?.title || "",
    description: product?.description || generateDescription(product)
  }
}

const closePublishModal = () => { publishModal.value.show = false }

const generateDescription = (product) => {
  if (!product) return ""
  let desc = ""
  if (product.brand) desc += "Marke: " + product.brand + "\n"
  if (product.size) desc += "Groesse: " + product.size + "\n"
  if (product.condition) desc += "Zustand: " + product.condition + "\n"
  desc += "\nVersand moeglich!"
  return desc
}

const generateSEO = () => {
  const product = publishModal.value.product
  if (!product) return
  let title = product.title || ""
  if (product.brand && !title.toLowerCase().includes(product.brand.toLowerCase())) {
    title = product.brand + " " + title
  }
  publishModal.value.title = title.substring(0, 80)
  publishModal.value.description = generateDescription(product)
}

const submitPublish = async () => {
  if (publishModal.value.selectedPlatforms.length === 0) { alert("Platform secin!"); return }
  publishing.value = true
  const results = []
  try {
    for (const platform of publishModal.value.selectedPlatforms) {
      try {
        const res = await api.post("/publishing/", {
          product_id: publishModal.value.product?.id,
          platform: platform,
          sale_price: publishModal.value.salePrice
        })
        results.push({ platform, pub_id: res.data.pub_id, success: true })
      } catch (err) {
        results.push({ platform, success: false })
      }
    }
    successModal.value = { show: true, publications: results.filter(r => r.success) }
    closePublishModal()
    loadFavorites()
  } finally { publishing.value = false }
}

const bulkPublish = () => {
  if (selectedFavorites.value.length === 0) return
  const fav = favorites.value.find(f => f.id === selectedFavorites.value[0])
  if (fav) openPublishModal(fav)
}

const goToPublishing = () => { successModal.value.show = false; router.push("/publishing") }

const remove = async (favId) => {
  if (!confirm("Kaldirilsin mi?")) return
  await api.delete("/favorites/" + favId)
  loadFavorites()
}

const removeAll = async () => {
  if (!confirm("Tumu kaldirilsin mi?")) return
  await api.delete("/favorites")
  loadFavorites()
}

const loadFavorites = async () => {
  try {
    const res = await api.get("/favorites/")
    favorites.value = res.data
    selectedFavorites.value = []
    if (currentPage.value > totalPages.value) currentPage.value = 1
  } catch (error) { console.error(error) }
}

onMounted(loadFavorites)
</script>