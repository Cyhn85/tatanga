"""
TATANGA V3 - eBay Human Scraper
İnsan-benzeri davranışlarla eBay'den ürün kazıma
"""
from human_scraper_base import HumanScraper, LOG_DIR
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from datetime import datetime
from typing import List, Dict, Optional
import time
import random
import re
import urllib.parse


class EbayScraper(HumanScraper):
    """eBay için insan-benzeri scraper"""

    BASE_URL = "https://www.ebay.de"

    # eBay sıralama seçenekleri
    SORT_OPTIONS = {
        "best_match": "",
        "ending_soonest": "1",
        "newly_listed": "10",
        "price_low": "15",
        "price_high": "16",
    }

    # Durum filtreleri (eBay condition codes)
    CONDITIONS = {
        "new": "1000",
        "open_box": "1500",
        "refurbished": "2000",
        "used": "3000",
    }

    # Almanca durum isimleri -> eBay condition mapping
    CONDITION_MAPPING = {
        # Almanca
        "neu": "new",
        "sehr_gut": "used",       # eBay'de "Sehr gut" = used kategorisinde
        "sehr gut": "used",
        "gut": "used",
        "akzeptabel": "used",
        # English
        "new": "new",
        "very_good": "used",
        "good": "used",
        "acceptable": "used",
    }

    def translate_condition(self, condition: str) -> str:
        """Almanca durum değerini eBay condition'a çevir"""
        if not condition:
            return None
        condition_lower = condition.lower().replace(" ", "_")
        if condition_lower in self.CONDITION_MAPPING:
            return self.CONDITION_MAPPING[condition_lower]
        if condition_lower in self.CONDITIONS:
            return condition_lower
        return None

    def __init__(self, headless: bool = True):
        super().__init__("ebay", headless)
        self.products_found = []
        self.visited_urls = set()

    def build_search_url(self, query: str, page: int = 1,
                         min_price: float = None, max_price: float = None,
                         condition: str = None, sort: str = None) -> str:
        """
        eBay arama URL'si oluştur
        """
        params = {
            "_nkw": query,
            "_pgn": page,
        }

        if min_price:
            params["_udlo"] = int(min_price)
        if max_price:
            params["_udhi"] = int(max_price)
        if condition and condition in self.CONDITIONS:
            params["LH_ItemCondition"] = self.CONDITIONS[condition]
        if sort and sort in self.SORT_OPTIONS:
            params["_sop"] = self.SORT_OPTIONS[sort]

        query_string = urllib.parse.urlencode(params)
        return f"{self.BASE_URL}/sch/i.html?{query_string}"

    def go_to_homepage(self):
        """eBay ana sayfasına git"""
        self.log("eBay ana sayfasına gidiliyor...")
        self.visit_url(self.BASE_URL)
        self.screenshot("homepage")
        self.random_delay(1, 2)
        self.close_cookie_banner()

    def get_product_elements(self) -> list:
        """Sayfadaki ürün elementlerini al - eBay 2024 yapısı"""
        selectors = [
            ".srp-results li.s-card",
            ".srp-results li[data-viewport]",
            ".srp-results li",
        ]

        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    self.log(f"{len(elements)} ürün elementi bulundu ({selector})")
                    return elements
            except:
                pass

        return []

    def extract_product_data(self, element) -> Optional[Dict]:
        """Ürün elementinden veri çıkar - eBay 2024 yapısı"""
        try:
            # URL - /itm/ içeren link
            url = None
            try:
                link = element.find_element(By.CSS_SELECTOR, "a[href*='/itm/']")
                url = link.get_attribute("href")
            except:
                return None

            if not url or "/itm/" not in url:
                return None

            # Zaten gördük mü?
            base_url = url.split("?")[0]
            if base_url in self.visited_urls:
                return None
            self.visited_urls.add(base_url)

            # Başlık - farklı selector'lar dene
            title = None
            title_selectors = [
                ".s-card__title",
                "span[role='heading']",
                "h3",
                ".s-item__title span",
                "a[href*='/itm/'] span",
            ]
            for sel in title_selectors:
                try:
                    title_elem = element.find_element(By.CSS_SELECTOR, sel)
                    title = title_elem.text.strip()
                    if title and len(title) > 3:
                        break
                except:
                    pass

            # Fallback - link text
            if not title:
                try:
                    link = element.find_element(By.CSS_SELECTOR, "a[href*='/itm/']")
                    title = link.text.strip()
                except:
                    pass

            if not title or title.lower() in ["shop on ebay", "schreiben sie uns", ""]:
                return None

            # Fiyat
            price = None
            price_selectors = [
                "[class*='price']",
                ".s-item__price",
                "span.s-card__price",
            ]
            for sel in price_selectors:
                try:
                    price_elem = element.find_element(By.CSS_SELECTOR, sel)
                    price_text = price_elem.text
                    price_match = re.search(r"EUR\s*([\d.,]+)|([\d.,]+)\s*€", price_text)
                    if price_match:
                        price_str = price_match.group(1) or price_match.group(2)
                        price = float(price_str.replace(".", "").replace(",", "."))
                        break
                except:
                    pass

            # Resim
            image_url = None
            try:
                img = element.find_element(By.CSS_SELECTOR, "img.s-card__image, img")
                image_url = img.get_attribute("src")
            except:
                pass

            # Durum
            condition = None
            try:
                cond_elem = element.find_element(By.CSS_SELECTOR, ".SECONDARY_INFO, [class*='condition']")
                condition = cond_elem.text.strip()
            except:
                pass

            return {
                "url": base_url,
                "title": title[:200] if title else None,
                "price": price,
                "condition": condition,
                "image": image_url,
                "platform": "ebay",
                "scraped_at": datetime.now().isoformat()
            }

        except Exception as e:
            self.log(f"Ürün verisi çıkarma hatası: {e}", "debug")
            return None

    def extract_all_products(self) -> List[Dict]:
        """Sayfadaki tüm ürünleri çıkar"""
        elements = self.get_product_elements()
        products = []

        for element in elements:
            product = self.extract_product_data(element)
            if product and product["url"] not in [p["url"] for p in self.products_found]:
                products.append(product)
                self.products_found.append(product)

        self.log(f"{len(products)} yeni ürün çıkarıldı (Toplam: {len(self.products_found)})")
        return products

    def go_to_next_page(self) -> bool:
        """Sonraki sayfaya git"""
        try:
            # Pagination kontrol
            next_selectors = [
                "a.pagination__next",
                "[aria-label='Nächste Seite']",
                ".pagination__item--next a",
            ]

            for selector in next_selectors:
                try:
                    next_btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                    if next_btn.is_displayed():
                        self.log("Sonraki sayfa butonuna tıklanıyor...")
                        self.human_click(next_btn)
                        self.random_delay(3, 5)
                        return True
                except:
                    pass

            return False
        except:
            return False

    def visit_random_product(self, visit_seller: bool = True) -> Optional[Dict]:
        """
        Rastgele bir ürüne git ve satıcı profilini ziyaret et
        İnsansı davranış: Ürün → Scroll → Satıcı Profili → Scroll → Geri → Geri
        """
        elements = self.get_product_elements()
        if not elements:
            self.log("Ürün elementi bulunamadı")
            return None

        random_elements = random.sample(elements[:min(10, len(elements))], 1)
        element = random_elements[0]

        product_data = self.extract_product_data(element)
        if not product_data:
            return None

        self.log(f"=== RASTGELE ÜRÜN ZİYARETİ ===")
        self.log(f"Ürün: {product_data['title'][:50]}...")

        # Mouse zigzag hareketi
        self.mouse_zigzag(element)
        self.random_delay(0.3, 0.6)

        # Ürün sayfasına git
        self.visit_url(product_data["url"])
        self.random_delay(2, 4)
        self.screenshot("product_page")

        # Sayfayı incele gibi scroll yap
        self.human_scroll("down", random.randint(200, 400))
        self.random_delay(1, 2)

        # Biraz daha scroll
        self.human_scroll("down", random.randint(100, 300))
        self.random_delay(0.5, 1.5)

        # Satıcı profiline git
        if visit_seller:
            self._visit_seller_profile()

        # Arama sonuçlarına geri dön
        self.random_delay(1, 2)
        self.go_back()
        self.random_delay(1, 2)

        self.log(f"=== RASTGELE ZİYARET TAMAMLANDI ===")
        return product_data

    def _visit_seller_profile(self) -> bool:
        """
        eBay satıcı profilini ziyaret et
        """
        seller_selectors = [
            # eBay satıcı linkleri
            "a[href*='/usr/']",
            "[data-testid='seller-link']",
            ".ux-seller-section__item a",
            ".seller-card a[href*='/usr/']",
            "[class*='seller'] a",
            ".x-sellercard-atf a",
            "a.seller-link",
        ]

        for selector in seller_selectors:
            try:
                links = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for link in links:
                    if link.is_displayed():
                        href = link.get_attribute("href") or ""
                        if "/usr/" in href or "seller" in href.lower():
                            self.log(f"Satıcı profiline gidiliyor: {href[:50]}...")

                            # Zigzag mouse
                            self.mouse_zigzag(link)

                            # Tıkla
                            self.human_click(link)
                            self.random_delay(2, 4)
                            self.screenshot("seller_profile")

                            # Profilde scroll yap
                            self.human_scroll("down", random.randint(300, 500))
                            self.random_delay(1, 3)

                            # Biraz daha scroll
                            if random.random() < 0.5:
                                self.human_scroll("down", random.randint(200, 400))
                                self.random_delay(0.5, 1.5)

                            # Geri dön (ürün sayfasına)
                            self.go_back()
                            self.random_delay(1, 2)

                            self.log("Satıcı profili ziyareti tamamlandı")
                            return True
            except Exception as e:
                self.log(f"Satıcı linki denemesi başarısız: {e}", "debug")
                continue

        self.log("Satıcı profili bulunamadı", "debug")
        return False

    def scrape(self, query: str, max_products: int = None, max_pages: int = None,
               visit_products: bool = True, min_price: float = None,
               max_price: float = None, condition: str = None,
               conditions: list = None, sort: str = "newly_listed") -> List[Dict]:
        """
        Ana kazıma fonksiyonu

        Args:
            query: Arama kelimesi
            max_products: Maksimum ürün sayısı
            max_pages: Maksimum sayfa sayısı
            visit_products: Rastgele ürünlere git
            min_price: Minimum fiyat
            max_price: Maximum fiyat
            condition: Durum filtresi (new, used, sehr gut, gut, etc.)
            conditions: Çoklu durum listesi ["sehr gut", "gut"]
            sort: Sıralama
        """
        self.log(f"=== KAZIMA BAŞLIYOR ===")
        self.log(f"Arama: {query}")
        self.log(f"Max ürün: {max_products or 'Sınırsız'}")
        self.log(f"Max sayfa: {max_pages or 'Sınırsız'}")

        # Durum filtresi çevir - Almanca'dan eBay condition'a
        translated_condition = None
        if conditions and len(conditions) > 0:
            # İlk condition'ı kullan (eBay tek condition destekliyor)
            translated_condition = self.translate_condition(conditions[0])
            self.log(f"Durum filtresi: {conditions[0]} -> {translated_condition}")
        elif condition:
            translated_condition = self.translate_condition(condition)
            self.log(f"Durum filtresi: {condition} -> {translated_condition}")

        # Eğer çeviri başarılıysa kullan, değilse orijinal condition'ı kullan
        effective_condition = translated_condition or condition

        try:
            page = 1

            # İlk sayfa URL'si
            url = self.build_search_url(
                query=query,
                page=page,
                min_price=min_price,
                max_price=max_price,
                condition=effective_condition,
                sort=sort
            )

            self.log(f"--- Sayfa {page} ---")
            self.visit_url(url)
            self.close_cookie_banner()

            # === İLK SAYFA: HER ZAMAN BİR ÜRÜN VE SATICI PROFİLİ ZİYARET ET ===
            self.log("=== İLK SAYFA RASTGELE GEZİNME ===")
            self.human_scroll("down", random.randint(300, 500))
            self.random_delay(1, 2)

            # İlk sayfada HER ZAMAN bir ürüne git ve satıcı profiline tıkla
            self.log("İlk sayfa: Rastgele ürün ve satıcı profili ziyareti...")
            self.visit_random_product(visit_seller=True)

            while True:
                self.log(f"--- Sayfa {page} ---")

                # Sayfayı scroll yap
                self.human_scroll("down", random.randint(300, 500))
                self.random_delay(1, 2)

                # Zigzag mouse hareketi
                if random.random() < 0.3:
                    try:
                        elements = self.get_product_elements()
                        if elements:
                            random_elem = random.choice(elements[:5])
                            self.mouse_zigzag(random_elem)
                    except:
                        pass

                # Ürünleri çıkar
                before_count = len(self.products_found)
                self.extract_all_products()
                after_count = len(self.products_found)
                new_products = after_count - before_count

                self.log(f"+{new_products} yeni ürün (Toplam: {after_count})")

                # Limit kontrolü
                if max_products and len(self.products_found) >= max_products:
                    self.log(f"Maksimum ürün sayısına ulaşıldı: {max_products}")
                    break

                if max_pages and page >= max_pages:
                    self.log(f"Maksimum sayfa sayısına ulaşıldı: {max_pages}")
                    break

                # Boş sayfa kontrolü
                if new_products == 0:
                    self.log("Boş sayfa, kazıma durduruluyor...")
                    break

                # Sonraki sayfalarda rastgele ürün ziyareti (%30 ihtimalle)
                if visit_products and page > 1 and random.random() < 0.3:
                    self.visit_random_product(visit_seller=True)

                # İnsansı bekleme
                self.random_delay(2, 4)

                # Sonraki sayfaya git
                page += 1
                url = self.build_search_url(
                    query=query,
                    page=page,
                    min_price=min_price,
                    max_price=max_price,
                    condition=effective_condition,
                    sort=sort
                )
                self.visit_url(url)
                self.random_delay(2, 3)

            self.log(f"=== KAZIMA TAMAMLANDI ===")
            self.log(f"Toplam ürün: {len(self.products_found)}")
            self.screenshot("scraping_complete")

            return self.products_found

        except Exception as e:
            self.log(f"Kazıma hatası: {e}", "error")
            self.screenshot("error")
            raise


def run_ebay_scrape(query: str, max_products: int = None, headless: bool = True) -> List[Dict]:
    """eBay kazıma işlemini çalıştır"""
    with EbayScraper(headless=headless) as scraper:
        return scraper.scrape(query, max_products=max_products)


if __name__ == "__main__":
    import sys

    query = sys.argv[1] if len(sys.argv) > 1 else "nike"
    max_items = int(sys.argv[2]) if len(sys.argv) > 2 else 50

    print(f"eBay kazıma başlıyor: {query}")
    products = run_ebay_scrape(query, max_products=max_items, headless=True)

    print(f"\n{len(products)} ürün bulundu:")
    for p in products[:5]:
        print(f"  - {p['title'][:40]} | {p['price']} EUR | {p['url']}")
