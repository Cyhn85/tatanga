#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Image Processor
Scraper'lar için görsel indirme, işleme ve minimum resim garantisi.

Features:
- URL'lerden görsel indirme
- ImageManipulator entegrasyonu
- Minimum 5 resim garantisi (augmentation ile)
- Batch processing
- Platform-specific presets

Author: TATANGA Team
Version: 1.0.0
"""

import sys
import io
import os
import uuid
import hashlib
import random
import requests
import shutil
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from datetime import datetime

# Safe stdout wrapper for Windows - skip if in Streamlit or already wrapped
if sys.platform == 'win32':
    try:
        if hasattr(sys.stdout, 'buffer') and not isinstance(sys.stdout, io.TextIOWrapper):
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    except (AttributeError, ValueError, OSError):
        pass  # Skip if already wrapped, closed, or in special environment (Streamlit)

sys.path.insert(0, str(Path(__file__).parent.parent))

from core.logger import get_logger

logger = get_logger("image_processor")

# Import ImageManipulator
try:
    from integrations.image_manipulator import ImageManipulator
    MANIPULATOR_AVAILABLE = True
except ImportError:
    MANIPULATOR_AVAILABLE = False
    logger.warning("ImageManipulator not available")


class ImageProcessor:
    """
    Scraper'lar için görsel işleme sınıfı.

    URL'lerden görsel indirir, ImageManipulator ile işler ve
    minimum resim sayısını garanti eder.
    """

    def __init__(self, temp_dir: str = None, output_dir: str = None):
        """
        Initialize ImageProcessor.

        Args:
            temp_dir: Geçici dosyalar için klasör (default: temp_images/)
            output_dir: İşlenmiş görseller için klasör (default: processed_images/)
        """
        base_path = Path(__file__).parent.parent

        if temp_dir:
            self.temp_dir = Path(temp_dir)
        else:
            self.temp_dir = base_path / "temp_images"

        if output_dir:
            self.output_dir = Path(output_dir)
        else:
            self.output_dir = base_path / "processed_images"

        # Klasörleri oluştur
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # ImageManipulator instance
        self.manipulator = ImageManipulator() if MANIPULATOR_AVAILABLE else None

        # İstatistikler
        self.stats = {
            'images_downloaded': 0,
            'images_processed': 0,
            'images_augmented': 0,
            'errors': 0
        }

        # Session for downloading
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
        })

        logger.info("ImageProcessor initialized",
                   temp_dir=str(self.temp_dir),
                   output_dir=str(self.output_dir),
                   manipulator_available=MANIPULATOR_AVAILABLE)

    def download_image(self, url: str, save_path: Path = None, timeout: int = 15) -> Optional[Path]:
        """
        URL'den görsel indir.

        Args:
            url: Görsel URL'i
            save_path: Kayıt yolu (default: temp_dir'de rastgele isim)
            timeout: İndirme timeout süresi

        Returns:
            İndirilen dosyanın Path'i veya None
        """
        if not url:
            return None

        try:
            # URL'den dosya uzantısını al
            ext = self._get_extension_from_url(url)

            if not save_path:
                filename = f"{uuid.uuid4().hex[:12]}.{ext}"
                save_path = self.temp_dir / filename

            response = self.session.get(url, timeout=timeout, stream=True)
            response.raise_for_status()

            # Content-Type kontrolü
            content_type = response.headers.get('Content-Type', '')
            if 'image' not in content_type.lower() and 'octet-stream' not in content_type.lower():
                logger.warning(f"Not an image: {content_type}", url=url[:50])
                return None

            # Dosyayı kaydet
            with open(save_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            # Dosya boyutu kontrolü (en az 1KB)
            if save_path.stat().st_size < 1024:
                save_path.unlink()
                return None

            self.stats['images_downloaded'] += 1
            return save_path

        except requests.RequestException as e:
            logger.warning(f"Download failed: {e}", url=url[:50])
            self.stats['errors'] += 1
            return None
        except Exception as e:
            logger.error(f"Download error: {e}", url=url[:50])
            self.stats['errors'] += 1
            return None

    def _get_extension_from_url(self, url: str) -> str:
        """URL'den dosya uzantısını çıkar."""
        # Query parametrelerini kaldır
        clean_url = url.split('?')[0]

        # Uzantıyı al
        ext = clean_url.split('.')[-1].lower()

        # Geçerli uzantı kontrolü
        valid_extensions = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp']
        if ext in valid_extensions:
            return ext

        return 'jpg'  # Default

    def download_images(self, urls: List[str], max_images: int = 20) -> List[Path]:
        """
        Birden fazla URL'den görsel indir.

        Args:
            urls: Görsel URL'leri listesi
            max_images: Maksimum indirilecek görsel sayısı

        Returns:
            İndirilen dosyaların Path listesi
        """
        downloaded = []

        for i, url in enumerate(urls[:max_images]):
            logger.info(f"Downloading image {i+1}/{min(len(urls), max_images)}")

            path = self.download_image(url)
            if path:
                downloaded.append(path)

        logger.info(f"Downloaded {len(downloaded)}/{len(urls)} images")
        return downloaded

    def process_images(
        self,
        image_paths: List[Path],
        manipulation_level: str = "medium",
        platform: str = None
    ) -> List[Path]:
        """
        Görselleri ImageManipulator ile işle.

        Args:
            image_paths: İşlenecek görsel dosyaları
            manipulation_level: 'light', 'medium', 'aggressive', 'ultra'
            platform: Platform adı (preset için)

        Returns:
            İşlenmiş görsel Path'leri
        """
        if not MANIPULATOR_AVAILABLE or not self.manipulator:
            logger.warning("ImageManipulator not available, returning original images")
            return image_paths

        # Platform preset
        if platform:
            manipulation_level = self.manipulator.get_platform_preset(platform)
            logger.info(f"Using platform preset: {platform} → {manipulation_level}")

        processed = []
        batch_id = uuid.uuid4().hex[:8]
        batch_dir = self.output_dir / batch_id
        batch_dir.mkdir(exist_ok=True)

        for i, img_path in enumerate(image_paths):
            try:
                # İşle
                result = self.manipulator.process_single(
                    img_path,
                    manipulation_level=manipulation_level,
                    strip_metadata=True
                )

                if result:
                    # Kaydet
                    output_path = batch_dir / f"processed_{i:02d}.jpg"
                    result.save(output_path, quality=95)
                    processed.append(output_path)
                    self.stats['images_processed'] += 1

            except Exception as e:
                logger.error(f"Processing error: {e}", file=str(img_path))
                self.stats['errors'] += 1
                continue

        logger.info(f"Processed {len(processed)}/{len(image_paths)} images")
        return processed

    def ensure_minimum_images(
        self,
        image_paths: List[Path],
        minimum: int = 5,
        manipulation_level: str = "medium"
    ) -> List[Path]:
        """
        Minimum resim sayısını garanti et.
        Yeterli resim yoksa mevcut olanları farklı manipülasyonlarla çoğalt.

        Args:
            image_paths: Mevcut görsel dosyaları
            minimum: Minimum görsel sayısı
            manipulation_level: Augmentation için başlangıç seviyesi

        Returns:
            En az {minimum} görsel içeren Path listesi
        """
        if len(image_paths) >= minimum:
            return image_paths[:minimum]

        if len(image_paths) == 0:
            logger.warning("No images to augment!")
            return []

        if not MANIPULATOR_AVAILABLE or not self.manipulator:
            logger.warning("ImageManipulator not available for augmentation")
            return image_paths

        logger.info(f"Augmenting images: {len(image_paths)} → {minimum}")

        # Mevcut görselleri koru
        augmented = list(image_paths)

        # Augmentation seviyeleri (farklı manipülasyonlar)
        aug_levels = ['light', 'medium', 'aggressive']

        # Batch klasörü
        batch_id = uuid.uuid4().hex[:8]
        batch_dir = self.output_dir / f"aug_{batch_id}"
        batch_dir.mkdir(exist_ok=True)

        idx = 0
        while len(augmented) < minimum:
            # Kaynak görsel (döngüsel)
            source = image_paths[idx % len(image_paths)]

            # Farklı manipülasyon seviyesi
            level = aug_levels[len(augmented) % len(aug_levels)]

            try:
                # Farklı parametrelerle işle
                result = self.manipulator.process_single(
                    source,
                    manipulation_level=level,
                    strip_metadata=True
                )

                if result:
                    output_path = batch_dir / f"aug_{len(augmented):02d}.jpg"
                    result.save(output_path, quality=93)
                    augmented.append(output_path)
                    self.stats['images_augmented'] += 1
                    logger.debug(f"Augmented image created: {output_path.name}")

            except Exception as e:
                logger.error(f"Augmentation error: {e}")
                self.stats['errors'] += 1

            idx += 1

            # Sonsuz döngü önleme
            if idx > minimum * 3:
                break

        logger.info(f"Augmentation complete: {len(augmented)} images")
        return augmented

    def process_from_urls(
        self,
        urls: List[str],
        minimum: int = 5,
        platform: str = None,
        manipulation_level: str = "medium"
    ) -> Dict:
        """
        URL'lerden görselleri indir, işle ve minimum sayıyı garanti et.

        Tek method ile tüm pipeline'ı çalıştırır.

        Args:
            urls: Görsel URL'leri
            minimum: Minimum görsel sayısı
            platform: Platform adı (preset için)
            manipulation_level: İşleme seviyesi

        Returns:
            {
                'success': bool,
                'images': List[Path],
                'original_count': int,
                'processed_count': int,
                'augmented_count': int
            }
        """
        logger.info(f"Processing {len(urls)} URLs, minimum {minimum} required")

        # 1. İndir
        downloaded = self.download_images(urls, max_images=20)
        original_count = len(downloaded)

        if original_count == 0:
            return {
                'success': False,
                'error': 'No images could be downloaded',
                'images': [],
                'original_count': 0,
                'processed_count': 0,
                'augmented_count': 0
            }

        # 2. İşle
        if platform:
            manipulation_level = self.manipulator.get_platform_preset(platform) if self.manipulator else manipulation_level

        processed = self.process_images(downloaded, manipulation_level=manipulation_level)
        processed_count = len(processed)

        # 3. Minimum garantisi
        if processed_count < minimum:
            final_images = self.ensure_minimum_images(processed, minimum=minimum, manipulation_level=manipulation_level)
            augmented_count = len(final_images) - processed_count
        else:
            final_images = processed[:minimum]  # En fazla minimum kadar döndür
            augmented_count = 0

        # 4. Temizlik - temp dosyalarını sil
        self._cleanup_temp_files(downloaded)

        return {
            'success': True,
            'images': final_images,
            'original_count': original_count,
            'processed_count': processed_count,
            'augmented_count': augmented_count
        }

    def _cleanup_temp_files(self, files: List[Path]):
        """Geçici dosyaları temizle."""
        for f in files:
            try:
                if f.exists():
                    f.unlink()
            except:
                pass

    def cleanup_all(self, older_than_hours: int = 24):
        """Eski temp ve output dosyalarını temizle."""
        now = datetime.now().timestamp()
        threshold = now - (older_than_hours * 3600)

        cleaned = 0
        for directory in [self.temp_dir, self.output_dir]:
            if not directory.exists():
                continue
            for item in directory.iterdir():
                try:
                    if item.stat().st_mtime < threshold:
                        if item.is_file():
                            item.unlink()
                        elif item.is_dir():
                            shutil.rmtree(item)
                        cleaned += 1
                except:
                    continue

        logger.info(f"Cleaned {cleaned} old files/folders")
        return cleaned

    def get_stats(self) -> Dict:
        """İstatistikleri döndür."""
        return {
            **self.stats,
            'manipulator_available': MANIPULATOR_AVAILABLE
        }


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("TATANGA - Image Processor Test")
    print("=" * 70)

    processor = ImageProcessor()

    print("\nProcessor Stats:")
    stats = processor.get_stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")

    print("\nUsage:")
    print("  processor = ImageProcessor()")
    print("  result = processor.process_from_urls(urls=['...'], minimum=5, platform='vinted')")
    print("  print(result['images'])")

    print("\n" + "=" * 70)
