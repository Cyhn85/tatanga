#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Favorites Validator & Publisher
=========================================
Favori ürünlerin kaynak kontrolü, fiyatlandırma ve yayınlama sistemi.

Features:
- Kaynak URL satılık/mevcut kontrolü
- Fiyat + kargo + komisyon hesaplama
- AI ile orijinal başlık/açıklama üretimi
- Minimum 5 resim kontrolü
- Resim manipülasyonu (organik görsel)
"""

import requests
import sqlite3
import json
import re
import time
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("favorites_validator")

# Sold/unavailable indicators
SOLD_INDICATORS = [
    'verkauft', 'sold', 'nicht mehr verfugbar', 'not available',
    'reserviert', 'reserved', 'ausverkauft', 'out of stock',
    'deaktiviert', 'deactivated', 'geloscht', 'deleted',
    'abgelaufen', 'expired', 'nicht gefunden', 'not found',
    'anzeige wurde deaktiviert', 'anzeige existiert nicht',
    'diese anzeige ist nicht mehr verfugbar', 'seite nicht gefunden',
    'dieses angebot wurde verkauft', 'artikel nicht mehr verfugbar',
    'listing has ended', 'item sold', 'no longer available'
]

# Platform shipping costs (EUR)
PLATFORM_SHIPPING = {
    'vinted': {'small': 2.99, 'medium': 4.99, 'large': 6.99},
    'ebay': {'small': 4.99, 'medium': 6.99, 'large': 9.99},
    'kleinanzeigen': {'small': 4.99, 'medium': 5.99, 'large': 7.99},
    'default': {'small': 4.99, 'medium': 5.99, 'large': 7.99}
}

# Platform commission rates
PLATFORM_COMMISSION = {
    'vinted': 0.05,  # 5%
    'ebay': 0.13,    # 13%
    'kleinanzeigen': 0.0,  # Free
    'default': 0.10  # 10%
}

@dataclass
class SourceCheckResult:
    """Kaynak kontrol sonucu"""
    url: str
    is_available: bool
    is_sold: bool
    reason: str
    checked_at: datetime
    current_price: Optional[float] = None
    shipping_cost: Optional[float] = None


@dataclass
class CostBreakdown:
    """Maliyet dökümu"""
    source_price: float
    shipping_cost: float
    platform_commission: float
    total_cost: float
    suggested_price: float
    profit_margin: float
    currency: str = "EUR"


class FavoritesValidator:
    """Favori ürün doğrulayıcı ve yayınlayıcı"""

    def __init__(self, db_path: str = None):
        if db_path:
            self.db_path = Path(db_path)
        else:
            self.db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'

        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
        })

    def get_db_connection(self):
        """Database connection"""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def check_source_availability(self, url: str, timeout: int = 15) -> SourceCheckResult:
        """
        Kaynak URL'nin mevcut olup olmadığını kontrol et
        """
        if not url or url in ['unknown', 'Unknown', '']:
            return SourceCheckResult(
                url=url or '',
                is_available=False,
                is_sold=False,
                reason='No source URL',
                checked_at=datetime.now()
            )

        try:
            response = self.session.get(url, timeout=timeout, allow_redirects=True)

            # HTTP status checks
            if response.status_code == 404:
                return SourceCheckResult(
                    url=url,
                    is_available=False,
                    is_sold=True,
                    reason='404 Not Found',
                    checked_at=datetime.now()
                )

            if response.status_code == 410:
                return SourceCheckResult(
                    url=url,
                    is_available=False,
                    is_sold=True,
                    reason='410 Gone',
                    checked_at=datetime.now()
                )

            if response.status_code >= 400:
                return SourceCheckResult(
                    url=url,
                    is_available=False,
                    is_sold=False,
                    reason=f'HTTP {response.status_code}',
                    checked_at=datetime.now()
                )

            # Content check for sold indicators
            content_lower = response.text.lower()
            for indicator in SOLD_INDICATORS:
                if indicator in content_lower:
                    return SourceCheckResult(
                        url=url,
                        is_available=False,
                        is_sold=True,
                        reason=f'Sold: {indicator}',
                        checked_at=datetime.now()
                    )

            # Try to extract current price from page
            current_price = self._extract_price_from_page(response.text, url)
            shipping_cost = self._extract_shipping_from_page(response.text, url)

            return SourceCheckResult(
                url=url,
                is_available=True,
                is_sold=False,
                reason='Available',
                checked_at=datetime.now(),
                current_price=current_price,
                shipping_cost=shipping_cost
            )

        except requests.exceptions.Timeout:
            return SourceCheckResult(
                url=url,
                is_available=False,
                is_sold=False,
                reason='Timeout',
                checked_at=datetime.now()
            )
        except requests.exceptions.ConnectionError:
            return SourceCheckResult(
                url=url,
                is_available=False,
                is_sold=False,
                reason='Connection Error',
                checked_at=datetime.now()
            )
        except Exception as e:
            return SourceCheckResult(
                url=url,
                is_available=False,
                is_sold=False,
                reason=str(e)[:50],
                checked_at=datetime.now()
            )

    def _extract_price_from_page(self, html: str, url: str) -> Optional[float]:
        """Sayfadan fiyat çıkar"""
        patterns = [
            r'(\d+[,\.]\d{2})\s*€',
            r'€\s*(\d+[,\.]\d{2})',
            r'EUR\s*(\d+[,\.]\d{2})',
            r'"price":\s*"?(\d+[,\.]\d{2})"?',
            r'price["\']?\s*:\s*(\d+[,\.]\d{2})',
        ]

        for pattern in patterns:
            match = re.search(pattern, html)
            if match:
                price_str = match.group(1).replace(',', '.')
                try:
                    return float(price_str)
                except ValueError:
                    continue
        return None

    def _extract_shipping_from_page(self, html: str, url: str) -> Optional[float]:
        """Sayfadan kargo ücreti çıkar"""
        patterns = [
            r'versand[^\d]*(\d+[,\.]\d{2})\s*€',
            r'shipping[^\d]*(\d+[,\.]\d{2})',
            r'lieferung[^\d]*(\d+[,\.]\d{2})',
        ]

        for pattern in patterns:
            match = re.search(pattern, html.lower())
            if match:
                price_str = match.group(1).replace(',', '.')
                try:
                    return float(price_str)
                except ValueError:
                    continue
        return None

    def calculate_cost_breakdown(
        self,
        source_price: float,
        source_platform: str = 'default',
        target_platform: str = 'cssberlin',
        shipping_size: str = 'medium',
        custom_shipping: float = None
    ) -> CostBreakdown:
        """
        Maliyet dökümü hesapla
        """
        # Get shipping cost
        platform_shipping = PLATFORM_SHIPPING.get(source_platform, PLATFORM_SHIPPING['default'])
        shipping_cost = custom_shipping if custom_shipping is not None else platform_shipping.get(shipping_size, 5.99)

        # Get commission rate
        commission_rate = PLATFORM_COMMISSION.get(source_platform, PLATFORM_COMMISSION['default'])
        platform_commission = source_price * commission_rate

        # Total cost
        total_cost = source_price + shipping_cost + platform_commission

        # Suggested price (30% profit margin)
        suggested_price = round(total_cost * 1.30, 2)

        # Profit margin
        profit_margin = suggested_price - total_cost

        return CostBreakdown(
            source_price=source_price,
            shipping_cost=shipping_cost,
            platform_commission=round(platform_commission, 2),
            total_cost=round(total_cost, 2),
            suggested_price=suggested_price,
            profit_margin=round(profit_margin, 2)
        )

    def validate_all_favorites(self, batch_size: int = 10, delay: float = 0.5) -> Dict:
        """
        Tüm favorileri kontrol et ve güncelle
        """
        conn = self.get_db_connection()
        cursor = conn.cursor()

        # Get favorites with source URLs
        cursor.execute("""
            SELECT f.id, f.product_id, p.url, p.title, p.price
            FROM favorites f
            JOIN products p ON f.product_id = p.id
            WHERE p.url IS NOT NULL AND p.url != '' AND p.url != 'unknown'
        """)

        favorites = cursor.fetchall()

        results = {
            'total': len(favorites),
            'available': 0,
            'sold': 0,
            'error': 0,
            'details': []
        }

        for fav in favorites:
            check_result = self.check_source_availability(fav['url'])

            # Update favorites table
            cursor.execute("""
                UPDATE favorites
                SET is_available = ?, is_sold = ?, last_checked = ?
                WHERE id = ?
            """, (
                check_result.is_available,
                check_result.is_sold,
                check_result.checked_at.isoformat(),
                fav['id']
            ))

            if check_result.is_available:
                results['available'] += 1
            elif check_result.is_sold:
                results['sold'] += 1
            else:
                results['error'] += 1

            results['details'].append({
                'product_id': fav['product_id'],
                'title': fav['title'][:40] if fav['title'] else 'N/A',
                'url': fav['url'],
                'status': check_result.reason
            })

            time.sleep(delay)

        conn.commit()
        conn.close()

        return results

    def get_favorites_with_costs(self) -> List[Dict]:
        """
        Tüm favorileri maliyet bilgileriyle getir
        """
        conn = self.get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                f.id as favorite_id,
                f.product_id,
                f.is_available,
                f.is_sold,
                f.last_checked,
                f.target_price,
                p.url,
                p.title,
                p.description,
                p.price,
                p.platform,
                p.images,
                p.brand,
                p.size,
                p.condition
            FROM favorites f
            JOIN products p ON f.product_id = p.id
            ORDER BY f.added_at DESC
        """)

        favorites = []
        for row in cursor.fetchall():
            fav = dict(row)

            # Calculate cost breakdown if price exists
            if fav.get('price'):
                platform = fav.get('platform', 'default').lower()
                cost = self.calculate_cost_breakdown(
                    source_price=fav['price'],
                    source_platform=platform
                )
                fav['cost_breakdown'] = {
                    'source_price': cost.source_price,
                    'shipping_cost': cost.shipping_cost,
                    'commission': cost.platform_commission,
                    'total_cost': cost.total_cost,
                    'suggested_price': cost.suggested_price,
                    'profit_margin': cost.profit_margin
                }

            # Count images
            images = fav.get('images', '[]')
            if isinstance(images, str):
                try:
                    images = json.loads(images)
                except:
                    images = [images] if images else []
            fav['image_count'] = len(images) if images else 0

            favorites.append(fav)

        conn.close()
        return favorites


def generate_original_title(product: Dict, language: str = 'de') -> str:
    """
    AI ile orijinal başlık üret (Gemini API kullanır)
    """
    try:
        from core.ai_helpers import generate_seo_title
        return generate_seo_title(product, language)
    except ImportError:
        # Fallback: Template-based title
        brand = product.get('brand', '')
        category = product.get('category', 'Artikel')
        size = product.get('size', '')
        condition = product.get('condition', '')

        parts = []
        if brand and brand.lower() != 'unknown':
            parts.append(brand)
        parts.append(category)
        if size:
            parts.append(f"Gr. {size}")
        if condition:
            parts.append(f"({condition})")

        return ' '.join(parts)


def generate_original_description(product: Dict, language: str = 'de') -> str:
    """
    AI ile orijinal açıklama üret
    """
    try:
        from core.ai_helpers import generate_seo_description
        return generate_seo_description(product, language)
    except ImportError:
        # Fallback: Template-based description
        title = product.get('title', 'Artikel')
        brand = product.get('brand', '')
        size = product.get('size', '')
        condition = product.get('condition', 'Gut')

        desc = f"Zum Verkauf steht: {title}\n\n"
        if brand:
            desc += f"Marke: {brand}\n"
        if size:
            desc += f"Größe: {size}\n"
        desc += f"Zustand: {condition}\n\n"
        desc += "Bei Fragen einfach melden!\n"
        desc += "Privatverkauf - keine Garantie/Rücknahme."

        return desc


def ensure_minimum_images(product_id: int, min_images: int = 5, db_path: str = None) -> Tuple[bool, List[str]]:
    """
    Minimum resim sayısını kontrol et ve gerekirse oluştur
    """
    if db_path is None:
        db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'

    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()

    cursor.execute("SELECT images FROM products WHERE id = ?", (product_id,))
    row = cursor.fetchone()

    if not row:
        conn.close()
        return False, []

    images = row[0]
    if isinstance(images, str):
        try:
            images = json.loads(images)
        except:
            images = [images] if images else []

    if len(images) >= min_images:
        conn.close()
        return True, images

    # Need more images - try to generate variants
    try:
        from integrations.image_manipulator import ImageManipulator
        manipulator = ImageManipulator()

        new_images = list(images)
        while len(new_images) < min_images and images:
            # Pick a source image and create variant
            source = images[len(new_images) % len(images)]
            # Note: In real implementation, this would create manipulated copies
            new_images.append(source)  # Placeholder

        conn.close()
        return len(new_images) >= min_images, new_images
    except Exception as e:
        logger.error(f"Image generation error: {e}")
        conn.close()
        return len(images) >= min_images, images


def manipulate_images_for_publish(
    image_paths: List[str],
    output_dir: str = None,
    manipulation_level: str = 'medium'
) -> List[str]:
    """
    Yayınlama için resimleri manipüle et (duplicate detection bypass)
    """
    try:
        from integrations.image_manipulator import ImageManipulator

        if output_dir is None:
            output_dir = Path(__file__).parent.parent / 'storage' / 'manipulated_images'

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        manipulator = ImageManipulator(output_dir=str(output_path))

        manipulated_paths = []
        for img_path in image_paths:
            try:
                # Apply manipulation based on level
                if manipulation_level == 'light':
                    # noise + brightness + border
                    result = manipulator.manipulate_image(
                        img_path,
                        techniques=['noise', 'brightness', 'border']
                    )
                elif manipulation_level == 'aggressive':
                    # all techniques
                    result = manipulator.manipulate_image(
                        img_path,
                        techniques=['noise', 'brightness', 'rotation', 'color', 'border', 'jpeg']
                    )
                else:  # medium
                    # rotation + color shift + JPEG
                    result = manipulator.manipulate_image(
                        img_path,
                        techniques=['rotation', 'color', 'jpeg', 'brightness']
                    )

                if result:
                    manipulated_paths.append(result)
                else:
                    manipulated_paths.append(img_path)
            except Exception as e:
                logger.warning(f"Failed to manipulate {img_path}: {e}")
                manipulated_paths.append(img_path)

        return manipulated_paths
    except ImportError:
        logger.warning("ImageManipulator not available")
        return image_paths


# Singleton instance
_validator_instance = None

def get_validator() -> FavoritesValidator:
    """Get singleton validator instance"""
    global _validator_instance
    if _validator_instance is None:
        _validator_instance = FavoritesValidator()
    return _validator_instance
