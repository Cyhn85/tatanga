#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA STOCK MONITOR DAEMON
7/24 Hetzner'da çalışacak periyodik stok kontrol servisi

Özellikler:
- Round-robin queue sistemi (10 ürün/dakika)
- AI Vision ile satıldı mı tespiti
- Otomatik ürün silme (CSS Berlin JSON)
- Hetzner görsel temizliği
- Telegram bildirimleri
- Systemd entegrasyonu

Author: TATANGA Team
Version: 2.0
"""

import os
import sys
import json
import time
import asyncio
import logging
import signal
import shutil
from pathlib import Path
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Dict, Optional, Any
from collections import deque
import threading
import subprocess

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent))

# Setup logging for daemon
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(Path(__file__).parent / 'logs' / 'stock_monitor_daemon.log')
    ]
)
logger = logging.getLogger('stock_monitor_daemon')

# Ensure logs directory exists
(Path(__file__).parent / 'logs').mkdir(exist_ok=True)


# ============================================================================
# CONFIGURATION
# ============================================================================

# Config file paths for dynamic configuration
CONFIG_FILE = Path('/opt/tatanga/stock_monitor/daemon_config.json')
STATUS_FILE = Path('/opt/tatanga/stock_monitor/daemon_status.json')
PID_FILE = Path('/opt/tatanga/stock_monitor/daemon.pid')


@dataclass
class DaemonConfig:
    """Daemon configuration"""
    # Check intervals
    products_per_minute: int = 10  # 10 ürün/dakika kontrol
    priority_check_interval_hours: int = 1  # Son 24 saatte eklenen ürünler
    normal_check_interval_hours: int = 2  # Normal ürünler

    # Paths
    css_berlin_repo: Path = Path(r"c:\Users\cyhnsrgc\Desktop\CSS-Berlin-Website")
    products_file: Path = None  # Set in __post_init__

    # Hetzner settings
    hetzner_host: str = "195.201.146.224"
    hetzner_user: str = "root"
    hetzner_images_path: str = "/root/videocu_v1/cssberlin_data/images"

    # Telegram (optional)
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""

    # AI Vision
    use_ai_vision: bool = True

    def __post_init__(self):
        self.products_file = self.css_berlin_repo / "scraped-products.json"

    def load_from_file(self):
        """Load config from JSON file (for dynamic updates)"""
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, 'r') as f:
                    data = json.load(f)
                    self.products_per_minute = data.get('products_per_minute', self.products_per_minute)
                    self.use_ai_vision = data.get('use_ai_vision', self.use_ai_vision)
                    logger.info(f"Config loaded: products_per_minute={self.products_per_minute}")
            except Exception as e:
                logger.error(f"Error loading config file: {e}")


# ============================================================================
# QUEUE MANAGER
# ============================================================================

class RoundRobinQueue:
    """
    Round-robin queue for fair product checking

    Strateji:
    - Her dakika N ürün kontrol et
    - Öncelik: Son 24 saatte eklenenler daha sık
    - 1000 ürün = ~100 dakika (1.5 saat) tam döngü
    """

    def __init__(self, config: DaemonConfig):
        self.config = config

        # Queues
        self.priority_queue: deque = deque()  # Son 24 saat
        self.normal_queue: deque = deque()    # Diğerleri

        # Tracking
        self.last_full_cycle: datetime = None
        self.products_checked: int = 0
        self.cycles_completed: int = 0

    def load_products(self) -> List[Dict]:
        """Load products from JSON"""
        try:
            if not self.config.products_file.exists():
                logger.warning("Products file not found")
                return []

            with open(self.config.products_file, 'r', encoding='utf-8') as f:
                data = json.load(f)

            products = data.get('products', [])
            logger.info(f"Loaded {len(products)} products from JSON")
            return products

        except Exception as e:
            logger.error(f"Error loading products: {e}")
            return []

    def rebuild_queues(self):
        """Rebuild priority and normal queues"""
        products = self.load_products()

        now = datetime.now()
        priority_cutoff = now - timedelta(hours=24)

        self.priority_queue.clear()
        self.normal_queue.clear()

        for product in products:
            # Check scraped_at for priority
            scraped_at_str = product.get('scraped_at', '')
            try:
                scraped_at = datetime.fromisoformat(scraped_at_str.replace('Z', '+00:00'))
                if scraped_at.replace(tzinfo=None) > priority_cutoff:
                    self.priority_queue.append(product)
                else:
                    self.normal_queue.append(product)
            except:
                self.normal_queue.append(product)

        logger.info(f"Queue rebuilt: {len(self.priority_queue)} priority, {len(self.normal_queue)} normal")

    def get_next_batch(self, count: int) -> List[Dict]:
        """Get next batch of products to check"""
        batch = []

        # Priority first (2/3 of batch from priority if available)
        priority_count = min(count * 2 // 3, len(self.priority_queue))
        for _ in range(priority_count):
            if self.priority_queue:
                product = self.priority_queue.popleft()
                batch.append(product)
                self.priority_queue.append(product)  # Re-add to end

        # Fill rest from normal queue
        normal_count = count - len(batch)
        for _ in range(normal_count):
            if self.normal_queue:
                product = self.normal_queue.popleft()
                batch.append(product)
                self.normal_queue.append(product)  # Re-add to end

        self.products_checked += len(batch)

        return batch

    def get_stats(self) -> Dict:
        """Get queue statistics"""
        total = len(self.priority_queue) + len(self.normal_queue)
        return {
            'total_products': total,
            'priority_queue': len(self.priority_queue),
            'normal_queue': len(self.normal_queue),
            'products_checked': self.products_checked,
            'cycles_completed': self.cycles_completed,
            'estimated_cycle_minutes': total // self.config.products_per_minute if total > 0 else 0
        }


# ============================================================================
# STOCK CHECKER
# ============================================================================

class StockChecker:
    """
    Check product availability using AI Vision
    """

    def __init__(self, config: DaemonConfig):
        self.config = config

        # Lazy load AI modules
        self._screenshot_agent = None
        self._vision_manager = None

        # Platform-specific prompts
        self.SOLD_PROMPTS = {
            'vinted': """Analyze this Vinted product screenshot.
Is the product sold, reserved, or available?
Look for: Green "Verkauft/Sold" banner, "Reserviert", grayed button.
Return JSON: {"status": "available|sold|unavailable", "confidence": 0.0-1.0}""",

            'kleinanzeigen': """Analyze this Kleinanzeigen screenshot.
Is the product available or sold/deactivated?
Look for: Faded image, "Anzeige deaktiviert", missing buttons.
Return JSON: {"status": "available|sold|unavailable", "confidence": 0.0-1.0}""",

            'ebay': """Analyze this eBay product screenshot.
Is the auction/listing ended or still active?
Look for: "Beendet/Ended", "Verkauft/Sold", crossed price.
Return JSON: {"status": "available|sold|unavailable", "confidence": 0.0-1.0}""",

            'default': """Analyze this e-commerce product screenshot.
Is the product available for purchase?
Return JSON: {"status": "available|sold|unavailable", "confidence": 0.0-1.0}"""
        }

    def _get_screenshot_agent(self):
        """Lazy load screenshot agent"""
        if self._screenshot_agent is None:
            try:
                from agents.screenshot_agent import ScreenshotAgent
                self._screenshot_agent = ScreenshotAgent()
            except ImportError:
                logger.warning("Screenshot agent not available")
        return self._screenshot_agent

    def _get_vision_manager(self):
        """Lazy load vision manager"""
        if self._vision_manager is None:
            try:
                from agents.ai_vision_manager import get_vision_manager
                self._vision_manager = get_vision_manager()
            except ImportError:
                logger.warning("Vision manager not available")
        return self._vision_manager

    def _detect_platform(self, url: str) -> str:
        """Detect platform from URL"""
        url_lower = url.lower()
        if 'vinted' in url_lower:
            return 'vinted'
        elif 'kleinanzeigen' in url_lower:
            return 'kleinanzeigen'
        elif 'ebay' in url_lower:
            return 'ebay'
        return 'default'

    async def check_product(self, product: Dict) -> Dict:
        """
        Check if product is still available

        Returns:
            {
                'product_id': int,
                'status': 'available' | 'sold' | 'unavailable' | 'error',
                'confidence': float,
                'reason': str
            }
        """
        product_id = product.get('id', 0)
        source_url = product.get('source_url', '') or product.get('link', '')

        if not source_url:
            return {
                'product_id': product_id,
                'status': 'error',
                'confidence': 0.0,
                'reason': 'No source URL'
            }

        platform = self._detect_platform(source_url)

        try:
            if self.config.use_ai_vision:
                return await self._check_with_ai_vision(product_id, source_url, platform)
            else:
                return await self._check_with_http(product_id, source_url)

        except Exception as e:
            logger.error(f"Error checking product {product_id}: {e}")
            return {
                'product_id': product_id,
                'status': 'error',
                'confidence': 0.0,
                'reason': str(e)
            }

    async def _check_with_ai_vision(self, product_id: int, url: str, platform: str) -> Dict:
        """Check using AI Vision"""

        screenshot_agent = self._get_screenshot_agent()
        vision_manager = self._get_vision_manager()

        if not screenshot_agent or not vision_manager:
            return await self._check_with_http(product_id, url)

        try:
            # Take screenshot
            logger.info(f"Taking screenshot: {url[:50]}...")
            screenshot = await screenshot_agent.capture_screenshot(
                url=url,
                device_type='desktop',
                timeout=30000
            )

            if not screenshot.success:
                if screenshot.status_code == 404:
                    return {
                        'product_id': product_id,
                        'status': 'unavailable',
                        'confidence': 1.0,
                        'reason': 'HTTP 404 - Page not found'
                    }
                return {
                    'product_id': product_id,
                    'status': 'error',
                    'confidence': 0.5,
                    'reason': f'Screenshot failed: {screenshot.error}'
                }

            # AI Vision analysis
            with open(screenshot.screenshot_path, 'rb') as f:
                image_data = f.read()

            prompt = self.SOLD_PROMPTS.get(platform, self.SOLD_PROMPTS['default'])
            analysis = await vision_manager.analyze_image(image_data, custom_prompt=prompt)

            if not analysis.get('success'):
                return {
                    'product_id': product_id,
                    'status': 'error',
                    'confidence': 0.0,
                    'reason': f"AI error: {analysis.get('error', 'Unknown')}"
                }

            result = analysis.get('result', {})
            status = result.get('status', 'unknown').lower()
            confidence = result.get('confidence', 0.5)

            # Normalize status
            if status in ['sold', 'reserved', 'ended']:
                status = 'sold'
            elif status in ['unavailable', 'deactivated']:
                status = 'unavailable'
            elif status == 'available':
                status = 'available'
            else:
                status = 'available'  # Default to available

            return {
                'product_id': product_id,
                'status': status,
                'confidence': confidence,
                'reason': f"AI: {status} ({platform})"
            }

        except Exception as e:
            logger.error(f"AI Vision error: {e}")
            return await self._check_with_http(product_id, url)

    async def _check_with_http(self, product_id: int, url: str) -> Dict:
        """Fallback: Check using HTTP only"""
        import aiohttp

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    timeout=aiohttp.ClientTimeout(total=10),
                    headers={'User-Agent': 'Mozilla/5.0'}
                ) as response:

                    if response.status == 404:
                        return {
                            'product_id': product_id,
                            'status': 'unavailable',
                            'confidence': 1.0,
                            'reason': 'HTTP 404'
                        }

                    if response.status >= 400:
                        return {
                            'product_id': product_id,
                            'status': 'error',
                            'confidence': 0.5,
                            'reason': f'HTTP {response.status}'
                        }

                    # Check for sold keywords in HTML
                    html = await response.text()
                    html_lower = html.lower()

                    sold_keywords = [
                        'verkauft', 'sold', 'ausverkauft', 'out of stock',
                        'nicht verfügbar', 'nicht mehr verfügbar',
                        'deaktiviert', 'beendet', 'ended'
                    ]

                    for keyword in sold_keywords:
                        if keyword in html_lower:
                            return {
                                'product_id': product_id,
                                'status': 'sold',
                                'confidence': 0.7,
                                'reason': f'Keyword found: {keyword}'
                            }

                    return {
                        'product_id': product_id,
                        'status': 'available',
                        'confidence': 0.6,
                        'reason': 'HTTP check - no sold indicators'
                    }

        except Exception as e:
            return {
                'product_id': product_id,
                'status': 'error',
                'confidence': 0.0,
                'reason': str(e)
            }


# ============================================================================
# PRODUCT REMOVER
# ============================================================================

class ProductRemover:
    """
    Remove sold products from CSS Berlin
    """

    def __init__(self, config: DaemonConfig):
        self.config = config

    def remove_product(self, product_id: int, reason: str) -> bool:
        """
        Remove product from JSON and push to GitHub
        """
        try:
            # Load products
            with open(self.config.products_file, 'r', encoding='utf-8') as f:
                data = json.load(f)

            products = data.get('products', [])
            original_count = len(products)

            # Find and remove product
            products = [p for p in products if p.get('id') != product_id]

            if len(products) == original_count:
                logger.warning(f"Product {product_id} not found in JSON")
                return False

            # Update stats
            data['products'] = products
            data['stats']['total_products'] = len(products)
            data['stats']['last_updated'] = datetime.now().strftime('%Y-%m-%d')

            # Save
            with open(self.config.products_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            logger.info(f"Removed product {product_id} from JSON")

            # Git push
            self._git_push(product_id, reason)

            # Cleanup Hetzner images (optional)
            self._cleanup_hetzner_images(product_id)

            return True

        except Exception as e:
            logger.error(f"Error removing product {product_id}: {e}")
            return False

    def _git_push(self, product_id: int, reason: str):
        """Git add, commit, push"""
        try:
            repo_path = self.config.css_berlin_repo

            # Git add
            subprocess.run(
                ['git', 'add', 'scraped-products.json'],
                cwd=repo_path,
                check=True
            )

            # Git commit
            commit_msg = f"[TATANGA-DAEMON] Auto-remove: Product {product_id} - {reason}"
            subprocess.run(
                ['git', 'commit', '-m', commit_msg],
                cwd=repo_path,
                check=True
            )

            # Git push
            result = subprocess.run(
                ['git', 'push', 'origin', 'main'],
                cwd=repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                logger.info(f"Git push successful for product {product_id}")
            else:
                logger.error(f"Git push failed: {result.stderr}")

        except Exception as e:
            logger.error(f"Git error: {e}")

    def _cleanup_hetzner_images(self, product_id: int):
        """Remove images from Hetzner server"""
        try:
            # SSH command to remove images
            remote_path = f"{self.config.hetzner_images_path}/{product_id}"
            ssh_cmd = f"ssh {self.config.hetzner_user}@{self.config.hetzner_host} 'rm -rf {remote_path}'"

            result = subprocess.run(ssh_cmd, shell=True, capture_output=True, text=True)

            if result.returncode == 0:
                logger.info(f"Hetzner images cleaned: {remote_path}")
            else:
                logger.debug(f"Hetzner cleanup (may not exist): {result.stderr}")

        except Exception as e:
            logger.debug(f"Hetzner cleanup error: {e}")


# ============================================================================
# TELEGRAM NOTIFIER (Optional)
# ============================================================================

class TelegramNotifier:
    """Send notifications to Telegram"""

    def __init__(self, config: DaemonConfig):
        self.config = config
        self.enabled = bool(config.telegram_bot_token and config.telegram_chat_id)

    async def send_message(self, message: str):
        """Send message to Telegram"""
        if not self.enabled:
            return

        try:
            import aiohttp

            url = f"https://api.telegram.org/bot{self.config.telegram_bot_token}/sendMessage"

            async with aiohttp.ClientSession() as session:
                async with session.post(url, json={
                    'chat_id': self.config.telegram_chat_id,
                    'text': message,
                    'parse_mode': 'Markdown'
                }) as response:
                    if response.status != 200:
                        logger.error(f"Telegram error: {await response.text()}")

        except Exception as e:
            logger.error(f"Telegram send error: {e}")

    async def notify_product_removed(self, product_id: int, title: str, reason: str):
        """Notify about removed product"""
        message = f"""
*TATANGA Stock Monitor*

Product *{product_id}* kaldırıldı

*Başlık:* {title[:50]}...
*Sebep:* {reason}
*Zaman:* {datetime.now().strftime('%H:%M:%S')}
"""
        await self.send_message(message)


# ============================================================================
# MAIN DAEMON
# ============================================================================

class StockMonitorDaemon:
    """
    Main daemon process

    Workflow:
    1. Load products into round-robin queue
    2. Every minute, check N products
    3. Remove sold/unavailable products
    4. Send notifications
    5. Repeat
    """

    def __init__(self, config: DaemonConfig = None):
        self.config = config or DaemonConfig()

        # Components
        self.queue = RoundRobinQueue(self.config)
        self.checker = StockChecker(self.config)
        self.remover = ProductRemover(self.config)
        self.notifier = TelegramNotifier(self.config)

        # State
        self.running = False
        self.last_queue_rebuild = None
        self._reload_requested = False  # For SIGHUP handling

        # Stats
        self.stats = {
            'start_time': None,
            'products_checked': 0,
            'products_removed': 0,
            'errors': 0,
            'last_check': None
        }

        # Signal handlers
        signal.signal(signal.SIGTERM, self._handle_signal)
        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGHUP, self._handle_sighup)  # Config reload

    def _handle_signal(self, signum, frame):
        """Handle shutdown signals"""
        logger.info(f"Received signal {signum}, shutting down...")
        self.running = False

    def _handle_sighup(self, signum, frame):
        """Handle SIGHUP signal - reload configuration"""
        logger.info("SIGHUP received - reloading configuration...")
        self._reload_requested = True

    def _reload_config(self):
        """Reload configuration from file"""
        self.config.load_from_file()
        self._reload_requested = False
        logger.info(f"Config reloaded: {self.config.products_per_minute} products/min, AI Vision: {self.config.use_ai_vision}")

    def _write_pid(self):
        """Write PID file for external management"""
        try:
            PID_FILE.parent.mkdir(parents=True, exist_ok=True)
            PID_FILE.write_text(str(os.getpid()))
            logger.info(f"PID file written: {PID_FILE} (PID: {os.getpid()})")
        except Exception as e:
            logger.error(f"Failed to write PID file: {e}")

    def _remove_pid(self):
        """Remove PID file on shutdown"""
        try:
            if PID_FILE.exists():
                PID_FILE.unlink()
                logger.info("PID file removed")
        except Exception as e:
            logger.error(f"Failed to remove PID file: {e}")

    def _write_status(self):
        """Write status file for API access"""
        try:
            STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)

            runtime = datetime.now() - self.stats['start_time'] if self.stats['start_time'] else timedelta(0)

            status = {
                'status': 'running' if self.running else 'stopped',
                'uptime_seconds': int(runtime.total_seconds()),
                'products_checked': self.stats['products_checked'],
                'products_removed': self.stats['products_removed'],
                'errors': self.stats['errors'],
                'last_check': self.stats['last_check'].isoformat() if self.stats['last_check'] else None,
                'products_per_minute': self.config.products_per_minute,
                'use_ai_vision': self.config.use_ai_vision,
                'queue_size': len(self.queue.priority_queue) + len(self.queue.normal_queue),
                'updated_at': datetime.now().isoformat()
            }

            with open(STATUS_FILE, 'w') as f:
                json.dump(status, f, indent=2)

        except Exception as e:
            logger.error(f"Failed to write status file: {e}")

    async def run(self):
        """Main daemon loop"""
        logger.info("="*60)
        logger.info("TATANGA STOCK MONITOR DAEMON STARTING")
        logger.info(f"Products per minute: {self.config.products_per_minute}")
        logger.info(f"AI Vision: {'Enabled' if self.config.use_ai_vision else 'Disabled'}")
        logger.info("="*60)

        self.running = True
        self.stats['start_time'] = datetime.now()

        # Write PID file
        self._write_pid()

        # Load config from file if exists
        self.config.load_from_file()

        # Initial queue build
        self.queue.rebuild_queues()
        self.last_queue_rebuild = datetime.now()

        # Write initial status
        self._write_status()

        while self.running:
            try:
                # Check for config reload (SIGHUP)
                if self._reload_requested:
                    self._reload_config()

                # Write status periodically
                self._write_status()

                # Rebuild queues every hour
                if datetime.now() - self.last_queue_rebuild > timedelta(hours=1):
                    logger.info("Rebuilding product queues...")
                    self.queue.rebuild_queues()
                    self.last_queue_rebuild = datetime.now()

                # Get next batch
                batch = self.queue.get_next_batch(self.config.products_per_minute)

                if not batch:
                    logger.info("No products to check, waiting...")
                    await asyncio.sleep(60)
                    continue

                # Check products
                for product in batch:
                    if not self.running:
                        break

                    product_id = product.get('id', 0)
                    title = product.get('title', 'Unknown')[:50]

                    result = await self.checker.check_product(product)
                    self.stats['products_checked'] += 1
                    self.stats['last_check'] = datetime.now()

                    if result['status'] in ['sold', 'unavailable']:
                        logger.warning(f"REMOVING: {product_id} - {title} ({result['reason']})")

                        if self.remover.remove_product(product_id, result['reason']):
                            self.stats['products_removed'] += 1
                            await self.notifier.notify_product_removed(
                                product_id, title, result['reason']
                            )

                    elif result['status'] == 'error':
                        self.stats['errors'] += 1
                        logger.debug(f"Check error: {product_id} - {result['reason']}")

                    else:
                        logger.debug(f"Available: {product_id}")

                    # Small delay between checks
                    await asyncio.sleep(3)

                # Log stats every 10 minutes
                if self.stats['products_checked'] % 100 == 0:
                    self._log_stats()

                # Wait for next minute
                await asyncio.sleep(60 - len(batch) * 3)

            except Exception as e:
                logger.error(f"Daemon loop error: {e}")
                self.stats['errors'] += 1
                await asyncio.sleep(60)

        logger.info("DAEMON STOPPED")
        self._log_stats()

        # Cleanup on exit
        self._remove_pid()
        self._write_status()  # Final status update

    def _log_stats(self):
        """Log current statistics"""
        queue_stats = self.queue.get_stats()

        runtime = datetime.now() - self.stats['start_time'] if self.stats['start_time'] else timedelta(0)

        logger.info("="*40)
        logger.info("DAEMON STATISTICS")
        logger.info(f"  Runtime: {runtime}")
        logger.info(f"  Products checked: {self.stats['products_checked']}")
        logger.info(f"  Products removed: {self.stats['products_removed']}")
        logger.info(f"  Errors: {self.stats['errors']}")
        logger.info(f"  Queue size: {queue_stats['total_products']}")
        logger.info(f"  Est. cycle time: {queue_stats['estimated_cycle_minutes']} min")
        logger.info("="*40)


# ============================================================================
# ENTRY POINT
# ============================================================================

def main():
    """Entry point for daemon"""
    import argparse

    parser = argparse.ArgumentParser(description='TATANGA Stock Monitor Daemon')
    parser.add_argument('--products-per-minute', type=int, default=10,
                       help='Number of products to check per minute')
    parser.add_argument('--no-ai', action='store_true',
                       help='Disable AI Vision (HTTP only)')
    parser.add_argument('--test', action='store_true',
                       help='Run single check cycle and exit')

    args = parser.parse_args()

    # Configure
    config = DaemonConfig(
        products_per_minute=args.products_per_minute,
        use_ai_vision=not args.no_ai
    )

    # Run
    daemon = StockMonitorDaemon(config)

    if args.test:
        logger.info("Running test cycle...")
        asyncio.run(daemon.run())
    else:
        logger.info("Starting daemon...")
        asyncio.run(daemon.run())


if __name__ == '__main__':
    main()
