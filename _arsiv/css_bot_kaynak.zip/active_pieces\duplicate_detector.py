#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Duplicate Detection System
Multi-layer duplicate detection to prevent duplicate products in database and GUI

USER REQUIREMENT: "bu hatayi istemiyorum net stabil ve saglikli bir islem tasarla"
Translation: "I don't want this error, design clean/stable/healthy operation"

5-Layer Detection:
1. URL exact match (fastest, database constraint)
2. Platform + Item ID match
3. Image perceptual hash match (pHash + average hash)
4. Title + Price similarity (Levenshtein distance)
5. Scrape timestamp cooldown (prevent re-scraping same item too soon)
"""

import sqlite3
import hashlib
import time
from pathlib import Path
from typing import Dict, Optional, Tuple, List
from datetime import datetime, timedelta
import re
import io


class DuplicateDetector:
    """
    Multi-layer duplicate detection system

    Prevents duplicate products from entering the system at multiple levels:
    - Database level (unique constraints)
    - Image level (perceptual hashing)
    - Content level (similarity matching)
    - Temporal level (cooldown tracking)
    """

    def __init__(self, db_path: str = None):
        if db_path is None:
            db_path = Path(__file__).parent / 'tatanga.db'

        self.db_path = db_path
        self._init_duplicate_tables()

        # Try to import image hashing libraries
        self.imagehash_available = False
        self.pillow_available = False

        try:
            from PIL import Image
            self.pillow_available = True
        except ImportError:
            pass

        try:
            import imagehash
            self.imagehash_available = True
        except ImportError:
            pass

    def _init_duplicate_tables(self):
        """
        Initialize duplicate detection tables
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Image hash cache table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS image_hash_cache (
                image_url TEXT PRIMARY KEY,
                average_hash TEXT,
                phash TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Scrape cooldown table (prevent re-scraping too soon)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS scrape_cooldown (
                source_url TEXT PRIMARY KEY,
                platform TEXT,
                item_id TEXT,
                last_scraped DATETIME,
                scrape_count INTEGER DEFAULT 1
            )
        ''')

        # Duplicate detection log
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS duplicate_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_url TEXT,
                platform TEXT,
                detection_method TEXT,
                matched_product_id INTEGER,
                detected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                reason TEXT
            )
        ''')

        # Add unique constraints to products table if not exists
        # (This would be integrated with existing products table)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS product_urls_unique (
                source_url TEXT PRIMARY KEY,
                product_id INTEGER UNIQUE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        conn.commit()
        conn.close()

    # ========================================================================
    # LAYER 1: URL-Based Detection (Fastest)
    # ========================================================================

    def check_by_url(self, url: str) -> Tuple[bool, Optional[int], str]:
        """
        Check if URL already exists in database

        Returns:
            (is_duplicate, existing_product_id, reason)
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Normalize URL (remove tracking params, fragments)
        normalized_url = self._normalize_url(url)

        cursor.execute('''
            SELECT product_id FROM product_urls_unique WHERE source_url = ?
        ''', (normalized_url,))

        row = cursor.fetchone()
        conn.close()

        if row:
            return True, row[0], "Exact URL match"
        return False, None, ""

    def _normalize_url(self, url: str) -> str:
        """
        Normalize URL by removing tracking parameters and fragments
        """
        # Remove fragment (#)
        url = url.split('#')[0]

        # Remove common tracking parameters
        tracking_params = [
            'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term',
            'fbclid', 'gclid', 'ref', 'source', '_ga', 'mc_cid', 'mc_eid'
        ]

        # Simple parameter removal (proper URL parsing would be better)
        for param in tracking_params:
            url = re.sub(f'[?&]{param}=[^&]*', '', url)

        # Clean up resulting URL
        url = url.rstrip('?&')

        return url

    # ========================================================================
    # LAYER 2: Platform + Item ID Match
    # ========================================================================

    def check_by_platform_id(self, platform: str, item_id: str) -> Tuple[bool, Optional[int], str]:
        """
        Check if Platform + Item ID combination already exists

        Args:
            platform: Platform name (e.g., 'kleinanzeigen', 'vinted_de')
            item_id: Platform-specific item ID

        Returns:
            (is_duplicate, existing_product_id, reason)
        """
        if not item_id:
            return False, None, ""

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Check in products table (assuming it has platform and platform_item_id columns)
        cursor.execute('''
            SELECT id FROM products
            WHERE source_platform = ? AND platform_item_id = ?
            LIMIT 1
        ''', (platform, item_id))

        row = cursor.fetchone()
        conn.close()

        if row:
            return True, row[0], f"Platform ID match: {platform}:{item_id}"
        return False, None, ""

    # ========================================================================
    # LAYER 3: Image Perceptual Hash Match
    # ========================================================================

    def check_by_image_hash(self, image_urls: List[str], threshold: int = 5) -> Tuple[bool, Optional[int], str]:
        """
        Check if similar images already exist using perceptual hashing

        Args:
            image_urls: List of image URLs to check
            threshold: Hamming distance threshold (lower = more strict, 0-10 recommended)

        Returns:
            (is_duplicate, existing_product_id, reason)
        """
        if not image_urls or not self.pillow_available:
            return False, None, ""

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        for img_url in image_urls[:3]:  # Check first 3 images only
            # Compute hash for this image
            img_hash = self._compute_image_hash(img_url)
            if not img_hash:
                continue

            # Get all existing hashes from database
            cursor.execute('SELECT image_url, average_hash, phash FROM image_hash_cache')
            existing_hashes = cursor.fetchall()

            # Compare with existing hashes
            for existing_url, existing_avg_hash, existing_phash in existing_hashes:
                if not existing_avg_hash:
                    continue

                # Calculate Hamming distance
                distance = self._hamming_distance(img_hash['average_hash'], existing_avg_hash)

                if distance <= threshold:
                    # Found duplicate image! Find which product it belongs to
                    cursor.execute('''
                        SELECT id FROM products WHERE images LIKE ?
                    ''', (f'%{existing_url}%',))

                    product_row = cursor.fetchone()
                    if product_row:
                        conn.close()
                        return True, product_row[0], f"Similar image detected (distance: {distance})"

        conn.close()
        return False, None, ""

    def _compute_image_hash(self, image_url: str) -> Optional[Dict[str, str]]:
        """
        Compute perceptual hash for an image

        Returns:
            {'average_hash': '...', 'phash': '...'} or None if failed
        """
        if not self.pillow_available:
            return None

        # Check cache first
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('SELECT average_hash, phash FROM image_hash_cache WHERE image_url = ?', (image_url,))
        cached = cursor.fetchone()

        if cached:
            conn.close()
            return {'average_hash': cached[0], 'phash': cached[1]}

        try:
            # Download and hash image
            import requests
            from PIL import Image

            response = requests.get(image_url, timeout=10)
            img = Image.open(io.BytesIO(response.content))

            # Compute average hash (simple and fast)
            avg_hash = self._average_hash(img)

            # Compute pHash if imagehash available
            phash_str = None
            if self.imagehash_available:
                import imagehash
                phash_str = str(imagehash.phash(img))

            # Cache the result
            cursor.execute('''
                INSERT OR REPLACE INTO image_hash_cache (image_url, average_hash, phash)
                VALUES (?, ?, ?)
            ''', (image_url, avg_hash, phash_str))
            conn.commit()
            conn.close()

            return {'average_hash': avg_hash, 'phash': phash_str}

        except Exception as e:
            conn.close()
            return None

    def _average_hash(self, img, hash_size: int = 8) -> str:
        """
        Compute average hash (aHash) for image
        Simple perceptual hash - compares pixel brightness to average
        """
        from PIL import Image

        # Resize to hash_size x hash_size
        img = img.convert('L').resize((hash_size, hash_size), Image.Resampling.LANCZOS)

        # Get pixel data
        pixels = list(img.getdata())
        avg = sum(pixels) / len(pixels)

        # Generate hash: 1 if pixel > average, 0 otherwise
        bits = ''.join('1' if pixel > avg else '0' for pixel in pixels)

        # Convert to hex string
        return hex(int(bits, 2))[2:].zfill(16)

    def _hamming_distance(self, hash1: str, hash2: str) -> int:
        """
        Calculate Hamming distance between two hash strings
        (Number of differing bits)
        """
        if not hash1 or not hash2:
            return 999  # Max distance if one is None

        # Convert hex to binary
        try:
            int1 = int(hash1, 16)
            int2 = int(hash2, 16)

            # XOR and count 1 bits
            xor = int1 ^ int2
            return bin(xor).count('1')
        except:
            return 999

    # ========================================================================
    # LAYER 4: Title + Price Similarity
    # ========================================================================

    def check_by_content_similarity(
        self,
        title: str,
        price: float,
        platform: str,
        title_threshold: float = 0.85,
        price_tolerance: float = 0.10
    ) -> Tuple[bool, Optional[int], str]:
        """
        Check if similar title + price combination exists on same platform

        Args:
            title: Product title
            price: Product price
            platform: Platform name
            title_threshold: Similarity threshold 0-1 (0.85 = 85% similar)
            price_tolerance: Price tolerance (0.10 = ±10%)

        Returns:
            (is_duplicate, existing_product_id, reason)
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Get products from same platform with similar price
        price_min = price * (1 - price_tolerance)
        price_max = price * (1 + price_tolerance)

        cursor.execute('''
            SELECT id, title, price FROM products
            WHERE source_platform = ? AND price BETWEEN ? AND ?
        ''', (platform, price_min, price_max))

        products = cursor.fetchall()
        conn.close()

        # Compare titles using Levenshtein distance
        for product_id, existing_title, existing_price in products:
            similarity = self._title_similarity(title, existing_title)

            if similarity >= title_threshold:
                return True, product_id, f"Similar content (title: {similarity:.0%}, price match)"

        return False, None, ""

    def _title_similarity(self, title1: str, title2: str) -> float:
        """
        Calculate title similarity using Levenshtein distance

        Returns:
            Similarity score 0-1 (1 = identical)
        """
        # Normalize titles
        t1 = self._normalize_title(title1)
        t2 = self._normalize_title(title2)

        # Levenshtein distance
        distance = self._levenshtein_distance(t1, t2)
        max_len = max(len(t1), len(t2))

        if max_len == 0:
            return 1.0

        similarity = 1 - (distance / max_len)
        return similarity

    def _normalize_title(self, title: str) -> str:
        """
        Normalize title for comparison
        - Lowercase
        - Remove special characters
        - Remove extra spaces
        """
        title = title.lower()
        title = re.sub(r'[^a-z0-9äöüß\s]', ' ', title)  # Keep German umlauts
        title = re.sub(r'\s+', ' ', title).strip()
        return title

    def _levenshtein_distance(self, s1: str, s2: str) -> int:
        """
        Calculate Levenshtein distance between two strings
        (Minimum number of edits to transform s1 into s2)
        """
        if len(s1) < len(s2):
            return self._levenshtein_distance(s2, s1)

        if len(s2) == 0:
            return len(s1)

        previous_row = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                # Cost of insertions, deletions, substitutions
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row

        return previous_row[-1]

    # ========================================================================
    # LAYER 5: Scrape Cooldown (Temporal Duplicate Prevention)
    # ========================================================================

    def check_scrape_cooldown(
        self,
        url: str,
        platform: str,
        cooldown_hours: int = 24
    ) -> Tuple[bool, Optional[datetime], str]:
        """
        Check if URL was scraped recently (within cooldown period)

        Args:
            url: Source URL
            platform: Platform name
            cooldown_hours: Cooldown period in hours (default: 24)

        Returns:
            (is_in_cooldown, last_scraped_time, reason)
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            SELECT last_scraped, scrape_count FROM scrape_cooldown
            WHERE source_url = ?
        ''', (url,))

        row = cursor.fetchone()
        conn.close()

        if row:
            last_scraped = datetime.fromisoformat(row[0])
            scrape_count = row[1]
            time_since_scrape = datetime.now() - last_scraped

            if time_since_scrape < timedelta(hours=cooldown_hours):
                hours_left = cooldown_hours - (time_since_scrape.total_seconds() / 3600)
                return True, last_scraped, f"Scraped {scrape_count} times. Cooldown: {hours_left:.1f}h remaining"

        return False, None, ""

    def record_scrape(self, url: str, platform: str, item_id: str = None):
        """
        Record that URL was scraped (for cooldown tracking)
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO scrape_cooldown (source_url, platform, item_id, last_scraped, scrape_count)
            VALUES (?, ?, ?, CURRENT_TIMESTAMP, 1)
            ON CONFLICT(source_url) DO UPDATE SET
                last_scraped = CURRENT_TIMESTAMP,
                scrape_count = scrape_count + 1
        ''', (url, platform, item_id))

        conn.commit()
        conn.close()

    # ========================================================================
    # UNIFIED DUPLICATE CHECK (All Layers)
    # ========================================================================

    def check_duplicate(
        self,
        product_data: Dict,
        layers: List[str] = None
    ) -> Tuple[bool, Optional[int], str]:
        """
        Comprehensive duplicate check using multiple layers

        Args:
            product_data: {
                'url': str,
                'platform': str,
                'item_id': str,
                'title': str,
                'price': float,
                'images': List[str]
            }
            layers: List of layers to check (default: all)
                    ['url', 'platform_id', 'image_hash', 'content', 'cooldown']

        Returns:
            (is_duplicate, existing_product_id, reason)
        """
        if layers is None:
            layers = ['url', 'platform_id', 'image_hash', 'content', 'cooldown']

        # Layer 1: URL check (fastest)
        if 'url' in layers and product_data.get('url'):
            is_dup, prod_id, reason = self.check_by_url(product_data['url'])
            if is_dup:
                self._log_duplicate(product_data, 'url', prod_id, reason)
                return True, prod_id, f"🔴 DUPLICATE: {reason}"

        # Layer 2: Platform ID check
        if 'platform_id' in layers and product_data.get('platform') and product_data.get('item_id'):
            is_dup, prod_id, reason = self.check_by_platform_id(
                product_data['platform'],
                product_data['item_id']
            )
            if is_dup:
                self._log_duplicate(product_data, 'platform_id', prod_id, reason)
                return True, prod_id, f"🔴 DUPLICATE: {reason}"

        # Layer 3: Image hash check (slower, more thorough)
        if 'image_hash' in layers and product_data.get('images'):
            is_dup, prod_id, reason = self.check_by_image_hash(product_data['images'])
            if is_dup:
                self._log_duplicate(product_data, 'image_hash', prod_id, reason)
                return True, prod_id, f"🔴 DUPLICATE: {reason}"

        # Layer 4: Content similarity check
        if 'content' in layers and product_data.get('title') and product_data.get('price'):
            is_dup, prod_id, reason = self.check_by_content_similarity(
                product_data['title'],
                product_data['price'],
                product_data.get('platform', '')
            )
            if is_dup:
                self._log_duplicate(product_data, 'content', prod_id, reason)
                return True, prod_id, f"🔴 DUPLICATE: {reason}"

        # Layer 5: Cooldown check (prevents re-scraping too soon)
        if 'cooldown' in layers and product_data.get('url'):
            is_cooldown, last_scraped, reason = self.check_scrape_cooldown(
                product_data['url'],
                product_data.get('platform', ''),
                cooldown_hours=24
            )
            if is_cooldown:
                return True, None, f"⏳ COOLDOWN: {reason}"

        # NOT a duplicate
        return False, None, "✅ Unique product"

    def _log_duplicate(self, product_data: Dict, detection_method: str, matched_id: int, reason: str):
        """
        Log duplicate detection for analysis
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO duplicate_log (source_url, platform, detection_method, matched_product_id, reason)
            VALUES (?, ?, ?, ?, ?)
        ''', (
            product_data.get('url', ''),
            product_data.get('platform', ''),
            detection_method,
            matched_id,
            reason
        ))

        conn.commit()
        conn.close()

    # ========================================================================
    # STATISTICS & REPORTING
    # ========================================================================

    def get_duplicate_stats(self) -> Dict:
        """
        Get duplicate detection statistics
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        stats = {}

        # Total duplicates detected
        cursor.execute('SELECT COUNT(*) FROM duplicate_log')
        stats['total_duplicates_detected'] = cursor.fetchone()[0]

        # Duplicates by detection method
        cursor.execute('''
            SELECT detection_method, COUNT(*)
            FROM duplicate_log
            GROUP BY detection_method
        ''')
        stats['by_method'] = {row[0]: row[1] for row in cursor.fetchall()}

        # Duplicates by platform
        cursor.execute('''
            SELECT platform, COUNT(*)
            FROM duplicate_log
            GROUP BY platform
        ''')
        stats['by_platform'] = {row[0]: row[1] for row in cursor.fetchall()}

        # Recent duplicates (last 24h)
        cursor.execute('''
            SELECT COUNT(*) FROM duplicate_log
            WHERE detected_at > datetime('now', '-1 day')
        ''')
        stats['last_24h'] = cursor.fetchone()[0]

        conn.close()
        return stats


if __name__ == '__main__':
    # Test duplicate detector
    print("TATANGA - Duplicate Detector Test\n")

    detector = DuplicateDetector()

    # Test product data
    test_product = {
        'url': 'https://www.kleinanzeigen.de/s-anzeige/nike-air-max/12345678',
        'platform': 'kleinanzeigen',
        'item_id': '12345678',
        'title': 'Nike Air Max 90 Herren Schuhe Gr. 42',
        'price': 89.99,
        'images': []
    }

    # First check - should be unique
    is_dup, prod_id, reason = detector.check_duplicate(test_product)
    print(f"First check: {reason}")

    # Get stats
    stats = detector.get_duplicate_stats()
    print(f"\nDuplicate Statistics:")
    print(f"  Total detected: {stats['total_duplicates_detected']}")
    print(f"  By method: {stats['by_method']}")
    print(f"  Last 24h: {stats['last_24h']}")
