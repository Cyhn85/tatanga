#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - Product Variant Generator
Multi-platform ürün varyantı üretici

1 ürün → N platform varyantı (farklı resim, başlık, açıklama)
"""

import sys
import io
import json
import random
import requests
import hashlib
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional

# Safe stdout wrapper for Windows
if sys.platform == 'win32':
    try:
        if hasattr(sys.stdout, 'buffer') and not isinstance(sys.stdout, io.TextIOWrapper):
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    except (AttributeError, ValueError, OSError):
        pass

sys.path.insert(0, str(Path(__file__).parent.parent))

# Import image manipulator
try:
    from integrations.image_manipulator import ImageManipulator
    IMAGE_MANIPULATOR_AVAILABLE = True
except ImportError:
    IMAGE_MANIPULATOR_AVAILABLE = False

# Import GroqSEO
try:
    from integrations.groq_seo_generator import GroqSEOGenerator
    GROQ_SEO_AVAILABLE = True
except ImportError:
    GROQ_SEO_AVAILABLE = False

# Storage path for downloaded images
IMAGES_DIR = Path(__file__).parent.parent / 'storage' / 'images'


class ProductVariantGenerator:
    """
    Multi-Platform Product Variant Generator

    Features:
    - Download and cache product images locally
    - Generate platform-specific image variants (different manipulation per platform)
    - Generate platform-specific SEO content (different title/description per platform)
    - Support for: CSS Berlin, Vinted, eBay, Kleinanzeigen, Willhaben
    """

    # Platform-specific manipulation presets
    PLATFORM_PRESETS = {
        'cssberlin': {
            'rotation': 1.5,
            'noise': 5,
            'brightness': 8,
            'contrast': 1.03,
            'color_shift': 5,
            'quality': 92
        },
        'vinted': {
            'rotation': -1.2,
            'noise': 7,
            'brightness': 10,
            'contrast': 1.05,
            'color_shift': -3,
            'quality': 90
        },
        'ebay': {
            'rotation': 2.0,
            'noise': 4,
            'brightness': 5,
            'contrast': 1.04,
            'color_shift': 8,
            'quality': 93
        },
        'kleinanzeigen': {
            'rotation': -0.8,
            'noise': 6,
            'brightness': 12,
            'contrast': 1.02,
            'color_shift': -5,
            'quality': 88
        },
        'willhaben': {
            'rotation': 1.0,
            'noise': 8,
            'brightness': 7,
            'contrast': 1.06,
            'color_shift': 4,
            'quality': 91
        }
    }

    # Platform-specific SEO styles
    PLATFORM_STYLES = {
        'cssberlin': 'balanced',
        'vinted': 'casual',
        'ebay': 'professional',
        'kleinanzeigen': 'conservative',
        'willhaben': 'balanced'
    }

    # Platform-specific price margins
    PLATFORM_MARGINS = {
        'cssberlin': 1.35,  # 35% margin
        'vinted': 1.25,     # 25% margin
        'ebay': 1.40,       # 40% margin (fees are higher)
        'kleinanzeigen': 1.30,  # 30% margin
        'willhaben': 1.30   # 30% margin
    }

    def __init__(self):
        self.images_dir = IMAGES_DIR
        self.images_dir.mkdir(parents=True, exist_ok=True)

        self.image_manipulator = None
        self.groq_seo = None

        if IMAGE_MANIPULATOR_AVAILABLE:
            self.image_manipulator = ImageManipulator()

        if GROQ_SEO_AVAILABLE:
            self.groq_seo = GroqSEOGenerator()

    def download_product_images(self, product_id: int, image_urls: list) -> List[str]:
        """
        Download all product images to local storage

        Args:
            product_id: Product ID in database
            image_urls: List of image URLs to download

        Returns:
            List of local file paths
        """
        product_dir = self.images_dir / str(product_id)
        product_dir.mkdir(parents=True, exist_ok=True)

        downloaded = []

        for i, url in enumerate(image_urls):
            if not url or not url.startswith('http'):
                continue

            try:
                # Generate filename based on URL hash for deduplication
                url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
                filename = f"original_{i+1}_{url_hash}.jpg"
                filepath = product_dir / filename

                # Skip if already downloaded
                if filepath.exists():
                    downloaded.append(str(filepath))
                    continue

                # Download image
                response = requests.get(url, timeout=30, headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                })
                response.raise_for_status()

                # Save to file
                filepath.write_bytes(response.content)
                downloaded.append(str(filepath))
                print(f"  [DOWNLOAD] Image {i+1}: {filepath.name}")

            except Exception as e:
                print(f"  [ERROR] Failed to download image {i+1}: {e}")
                continue

        return downloaded

    def get_local_images(self, product_id: int) -> List[str]:
        """Get list of already downloaded images for a product"""
        product_dir = self.images_dir / str(product_id)
        if not product_dir.exists():
            return []

        images = list(product_dir.glob("original_*.jpg"))
        return [str(p) for p in sorted(images)]

    def generate_image_variant(self, image_path: str, platform: str) -> Optional[str]:
        """
        Generate a platform-specific image variant

        Args:
            image_path: Path to original image
            platform: Target platform name

        Returns:
            Path to manipulated image, or None if failed
        """
        if not self.image_manipulator:
            return image_path  # Return original if no manipulator

        preset = self.PLATFORM_PRESETS.get(platform, self.PLATFORM_PRESETS['cssberlin'])

        try:
            # Create output directory for this platform
            original_path = Path(image_path)
            output_dir = original_path.parent / platform
            output_dir.mkdir(exist_ok=True)

            output_filename = original_path.stem.replace('original_', f'{platform}_') + '.jpg'
            output_path = output_dir / output_filename

            # Skip if already generated
            if output_path.exists():
                return str(output_path)

            # Apply manipulations
            import cv2
            img = cv2.imread(str(image_path))
            if img is None:
                return image_path

            # 1. Rotation
            if preset.get('rotation'):
                angle = preset['rotation'] + random.uniform(-0.3, 0.3)
                h, w = img.shape[:2]
                center = (w // 2, h // 2)
                matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
                img = cv2.warpAffine(img, matrix, (w, h), borderMode=cv2.BORDER_REPLICATE)

            # 2. Noise
            if preset.get('noise'):
                noise_level = preset['noise'] + random.randint(-2, 2)
                noise = np.random.normal(0, noise_level, img.shape)
                img = np.clip(img + noise, 0, 255).astype(np.uint8)

            # 3. Brightness/Contrast
            if preset.get('brightness') or preset.get('contrast'):
                brightness = preset.get('brightness', 0) + random.randint(-3, 3)
                contrast = preset.get('contrast', 1.0) + random.uniform(-0.02, 0.02)
                img = cv2.convertScaleAbs(img, alpha=contrast, beta=brightness)

            # 4. Color shift
            if preset.get('color_shift'):
                shift = preset['color_shift'] + random.randint(-2, 2)
                img = img.astype(np.float32)
                if shift > 0:
                    img[:, :, 2] += shift  # Red
                    img[:, :, 1] += shift * 0.5  # Green
                else:
                    img[:, :, 0] += abs(shift)  # Blue
                img = np.clip(img, 0, 255).astype(np.uint8)

            # 5. Save with quality setting
            quality = preset.get('quality', 92)
            cv2.imwrite(str(output_path), img, [cv2.IMWRITE_JPEG_QUALITY, quality])

            return str(output_path)

        except Exception as e:
            print(f"  [ERROR] Image manipulation failed: {e}")
            return image_path

    def generate_seo_variant(self, title: str, description: str, platform: str) -> Dict:
        """
        Generate platform-specific SEO content

        Args:
            title: Original product title
            description: Original product description
            platform: Target platform name

        Returns:
            Dict with seo_title, seo_description, keywords
        """
        if not self.groq_seo:
            # Return original if no SEO generator
            return {
                'seo_title': title,
                'seo_description': description,
                'keywords': []
            }

        style = self.PLATFORM_STYLES.get(platform, 'balanced')

        try:
            result = self.groq_seo.generate_variation(
                original_title=title,
                original_description=description,
                platform=platform,
                language='de',
                variation_style=style
            )

            return {
                'seo_title': result.get('title', title),
                'seo_description': result.get('description', description),
                'keywords': result.get('keywords', [])
            }

        except Exception as e:
            print(f"  [ERROR] SEO generation failed for {platform}: {e}")
            return {
                'seo_title': title,
                'seo_description': description,
                'keywords': []
            }

    def calculate_platform_price(self, original_price: float, platform: str, shipping_cost: float = 5.99) -> int:
        """
        DOĞRU FİYAT FORMÜLÜ:
        final_price = round(original + (shipping × 2) + 5)

        Platform komisyonları:
        - Kleinanzeigen: Komisyon YOK
        - Vinted: Komisyon VAR (~5%)
        - CSS Berlin: Komisyon YOK
        - eBay: Komisyon VAR (~13%)

        Küsürat YOK - sadece düz fiyatlar (75€, 80€, 95€)
        """
        # Platform-specific commission rates
        COMMISSIONS = {
            'vinted': 0.05,      # 5% Vinted commission
            'cssberlin': 0,      # No commission
            'kleinanzeigen': 0,  # No commission
            'ebay': 0.13,        # ~13% eBay fees
            'willhaben': 0       # No commission
        }

        # Base calculation: original + (shipping × 2) + 5
        base_price = original_price + (shipping_cost * 2) + 5

        # Platform-specific commission - add to price so seller gets base_price after fees
        commission_rate = COMMISSIONS.get(platform, 0)
        if commission_rate > 0:
            base_price = base_price / (1 - commission_rate)

        # Round to whole number - NO DECIMALS
        return int(round(base_price))

    def generate_variants(self, product_data: dict, platforms: List[str]) -> Dict[str, Dict]:
        """
        Generate variants for multiple platforms

        Args:
            product_data: Original product data with keys:
                - id: Product ID
                - title: Product title
                - description: Product description (optional)
                - price: Original price
                - images: List of image URLs or local paths
                - local_images: List of already downloaded image paths (optional)

        platforms: List of target platforms ['cssberlin', 'vinted', 'ebay', ...]

        Returns:
            Dict mapping platform -> variant data
        """
        variants = {}
        product_id = product_data.get('id')

        # Get or download images
        local_images = product_data.get('local_images', [])
        if not local_images:
            image_urls = product_data.get('images', [])
            if isinstance(image_urls, str):
                try:
                    image_urls = json.loads(image_urls)
                except:
                    image_urls = [image_urls] if image_urls else []

            # Add single image if images list is empty
            if not image_urls and product_data.get('image'):
                image_urls = [product_data['image']]

            if image_urls and product_id:
                print(f"[VARIANT] Downloading {len(image_urls)} images for product {product_id}...")
                local_images = self.download_product_images(product_id, image_urls)

        print(f"[VARIANT] Generating variants for {len(platforms)} platforms...")

        for platform in platforms:
            print(f"  [PLATFORM] {platform}...")

            # 1. Generate image variants
            platform_images = []
            for img_path in local_images:
                variant_path = self.generate_image_variant(img_path, platform)
                if variant_path:
                    platform_images.append(variant_path)

            # 2. Generate SEO variant
            seo = self.generate_seo_variant(
                title=product_data.get('title', ''),
                description=product_data.get('description', ''),
                platform=platform
            )

            # 3. Calculate platform price with new formula
            original_price = float(product_data.get('price', 0) or 0)
            shipping_cost = float(product_data.get('shipping_cost', 5.99) or 5.99)
            platform_price = self.calculate_platform_price(original_price, platform, shipping_cost)

            # 4. Build variant with COMPLETE METADATA
            variants[platform] = {
                'title': seo['seo_title'],
                'description': seo['seo_description'],
                'keywords': seo['keywords'],
                'images': platform_images,
                'image': platform_images[0] if platform_images else product_data.get('image', ''),
                'price': platform_price,
                'original_price': original_price,
                'margin_percent': int((self.PLATFORM_MARGINS.get(platform, 1.30) - 1) * 100),
                'platform': platform,
                'source_platform': product_data.get('platform', 'unknown'),
                'source_url': product_data.get('url') or product_data.get('link', ''),
                'product_id': product_id,
                'generated_at': datetime.now().isoformat(),
                # METADATA - Kaynak verisinden doğrudan aktarılıyor (DEĞİŞTİRME!)
                'size': product_data.get('size', ''),
                'color': product_data.get('color', ''),
                'condition': product_data.get('condition', ''),
                'brand': product_data.get('brand', ''),
                'shipping_cost': product_data.get('shipping_cost', 5.99)
            }

            print(f"    [OK] {platform}: '{seo['seo_title'][:40]}...' @ {platform_price}€")

        return variants


# Need to import numpy for image manipulation
try:
    import numpy as np
except ImportError:
    np = None


def download_images_on_favorite(product_id: int, image_urls: list) -> List[str]:
    """
    Helper function to download images when product is added to favorites

    Usage in triaj_dashboard.py:
        from integrations.variant_generator import download_images_on_favorite
        downloaded = download_images_on_favorite(product_id, image_urls)
    """
    generator = ProductVariantGenerator()
    return generator.download_product_images(product_id, image_urls)


def generate_product_variants(product_data: dict, platforms: List[str]) -> Dict[str, Dict]:
    """
    Helper function to generate variants for publishing

    Usage in triaj_dashboard.py:
        from integrations.variant_generator import generate_product_variants
        variants = generate_product_variants(product_data, ['cssberlin', 'vinted'])
    """
    generator = ProductVariantGenerator()
    return generator.generate_variants(product_data, platforms)


# Test
if __name__ == "__main__":
    print("=" * 60)
    print("VARIANT GENERATOR TEST")
    print("=" * 60)

    # Test product data
    test_product = {
        'id': 999,
        'title': 'UGG Stiefel 38 NEU Original',
        'description': 'Originale UGG Stiefel in Größe 38. Neuwertig, nur einmal getragen.',
        'price': 89.99,
        'images': [
            'https://via.placeholder.com/400x400.jpg?text=UGG1',
            'https://via.placeholder.com/400x400.jpg?text=UGG2'
        ],
        'platform': 'vinted',
        'url': 'https://vinted.de/items/12345'
    }

    # Test variant generation
    generator = ProductVariantGenerator()

    print("\n1. Testing image download...")
    downloaded = generator.download_product_images(
        test_product['id'],
        test_product['images']
    )
    print(f"   Downloaded: {len(downloaded)} images")

    print("\n2. Testing variant generation...")
    platforms = ['cssberlin', 'vinted', 'ebay']
    test_product['local_images'] = downloaded

    variants = generator.generate_variants(test_product, platforms)

    print("\n3. Results:")
    for platform, variant in variants.items():
        print(f"\n   [{platform.upper()}]")
        print(f"   Title: {variant['title'][:50]}...")
        print(f"   Price: {variant['price']}€ ({variant['margin_percent']}% margin)")
        print(f"   Images: {len(variant['images'])}")

    print("\n" + "=" * 60)
    print("TEST COMPLETE")
    print("=" * 60)
