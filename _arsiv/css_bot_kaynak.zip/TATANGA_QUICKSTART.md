# 🚀 TATANGA Quick Start Guide

## 📋 İçindekiler
1. [Kurulum](#kurulum)
2. [İlk Yapılandırma](#ilk-yapılandırma)
3. [Modül Testleri](#modül-testleri)
4. [Kullanım Senaryoları](#kullanım-senaryoları)
5. [Sorun Giderme](#sorun-giderme)

---

## 🔧 Kurulum

### 1. Gerekli Paketleri Yükle

```bash
cd "c:\Users\cyhnsrgc\Desktop\CSS BOT"

# Virtual environment oluştur (opsiyonel ama önerilen)
python -m venv venv
venv\Scripts\activate

# Paketleri yükle
pip install -r requirements_tatanga.txt
```

**Kurulacak Paketler:**
- `opencv-python` - Resim manipülasyonu
- `pillow` - Resim işleme
- `imagehash` - Duplicate detection
- `selenium` - Web scraping
- `requests` - HTTP istekleri
- `python-telegram-bot` - Telegram bot
- `groq` - SEO generation (ücretsiz)
- `cryptography` - Şifreleme
- `flask` - Webhook API

### 2. API Keylerini Yapılandır

**Dosya:** `active_pieces/config/credentials.py`

```python
API_KEYS = {
    'gemini_api_key': 'AIzaSyCXJ9lWMD4N84cshZP-T3RQRXLg_Z7D0lk',  # Mevcut
    'groq_api_key': '',  # ← BURAYA GROQ KEY EKLE
    'ebay_app_id': 'CyhnSerg-CSSBerli-PRD-e0d4ac71f-d51f3ef1',  # Mevcut
    # ...
}

TELEGRAM = {
    'bot_token': '',  # ← BURAYA BOT TOKEN EKLE
    'chat_id': '',    # ← BURAYA CHAT ID EKLE
}
```

**API Key Alma:**
- **Groq API:** https://console.groq.com/keys (Ücretsiz, 14,400 istek/gün)
- **Telegram Bot:** @BotFather'dan bot oluştur
- **Chat ID:** Bot'a `/start` yaz, sonra `https://api.telegram.org/bot<TOKEN>/getUpdates` aç

### 3. Database Migration

```bash
python active_pieces/database_migration_v2.py
# Soruyu "yes" ile cevapla
```

**Oluşturulacak Tablolar:**
- `transfer_history` - Transfer geçmişi
- `store_accounts` - Mağaza hesapları
- `conversations` - Satıcı mesajları
- `message_log` - Mesaj geçmişi
- `seo_variations` - SEO cache
- `image_manipulations` - Resim işleme geçmişi

---

## 🎯 İlk Yapılandırma

### Adım 1: Test Klasörlerini Oluştur

```bash
mkdir active_pieces\storage\test_images
mkdir active_pieces\storage\temp_transfer
```

### Adım 2: Test Resmi Hazırla

Test için herhangi bir ürün resmini `active_pieces\storage\test_images\test_product.jpg` olarak kaydet.

---

## 🧪 Modül Testleri

### Test 1: Resim Manipülasyonu ✅

```bash
cd active_pieces\integrations

# Test et
python image_manipulator.py
```

**Beklenen:**
- ✅ Manipulation levels açıklaması
- ✅ "Test klasörü bulunamadı" uyarısı (normal)

**Manuel Test:**
```python
from integrations.image_manipulator import ImageManipulator

manipulator = ImageManipulator()
img = manipulator.process_single(
    'storage/test_images/test_product.jpg',
    manipulation_level='aggressive'
)
img.save('storage/test_images/manipulated_test.jpg')
print("✅ Resim manipüle edildi!")
```

### Test 2: Hash Tester ✅

```bash
python hash_tester.py
```

**Manuel Test:**
```python
from integrations.hash_tester import HashTester

tester = HashTester()
result = tester.compare_images(
    'storage/test_images/test_product.jpg',
    'storage/test_images/manipulated_test.jpg'
)

for algo, data in result.items():
    print(f"{algo}: distance={data['distance']} - {data['status']}")
```

**Başarı Kriteri:** Distance > 10 (her algoritma için)

### Test 3: Groq SEO Generator ✅

```bash
python groq_seo_generator.py
```

**Gerekli:** Groq API key

**Manuel Test:**
```python
from integrations.groq_seo_generator import GroqSEOGenerator

generator = GroqSEOGenerator()

# Test
result = generator.generate_variation(
    original_title="Nike Air Max 90 Sneaker Weiß Gr. 42",
    original_description="Neuwertig, nur 2x getragen",
    platform="ebay_de",
    language="de"
)

print(f"Yeni başlık: {result['title']}")
print(f"Keywords: {result['keywords']}")
```

### Test 4: Platform Connectors ✅

```bash
python platform_connectors.py
```

**Beklenen:**
- ✅ Database'de kaç ürün olduğu gösterilir

### Test 5: Telegram Bot ✅

```bash
python telegram_bot.py
```

**Gerekli:** Bot token ve chat ID

**Test Adımları:**
1. Bot başlatılır
2. Telegram'dan `/start` komutu gönder
3. `/status` komutu gönder
4. Bot yanıt verirse ✅

**Durdurma:** `Ctrl+C`

### Test 6: Webhook API ✅

```bash
python activepieces_webhook.py
```

**Beklenen:**
```
🔗 TATANGA ACTIVE PIECES WEBHOOK API
Server: http://0.0.0.0:5000

Endpoints:
  POST  http://0.0.0.0:5000/api/activepieces/product-favorited
  ...
```

**Test Komutu (başka terminal):**
```bash
curl http://localhost:5000/api/activepieces/status
```

**Beklenen Yanıt:**
```json
{
  "success": true,
  "status": "online",
  "products": 1373,
  ...
}
```

---

## 🎮 Kullanım Senaryoları

### Senaryo 1: Mağaza Ekleme

```bash
python active_pieces/store_manager_gui.py
```

**Adımlar:**
1. Sol panelden platform seç (örn: eBay Germany)
2. **[➕ YENİ MAĞAZA EKLE]** butonuna tıkla
3. Bilgileri doldur:
   - Mağaza Adı: `Shop 1`
   - Mağaza ID: `shop1`
   - Email: `shop1@example.com`
   - Password: `********`
4. **[💾 KAYDET]**
5. ✅ Mağaza listede görünür

### Senaryo 2: Çapraz Platform Transfer

```bash
python active_pieces/transfer_dashboard_gui.py
```

**Adımlar:**
1. **Sol Panel:** Kaynak platformları seç
   - ☑️ Vinted DE
   - ☑️ eBay DE
2. **[🔄 YENİLE]** butonuna tıkla
3. Orta panel: Ürünler yüklenir
4. **Sağ Panel:** Hedef mağazaları seç
   - ☑️ eBay Shop1
   - ☑️ Kleinanzeigen Shop1
   - ☑️ CSSBerlin (otomatik)
5. Ayarlar:
   - Resim Manipülasyonu: `aggressive`
   - SEO Stili: `balanced`
6. **[🚀 TRANSFER BAŞLAT]**
7. ✅ Progress bar takip et
8. ✅ Telegram'da bildirim gelir

**Tahmini Süre:** 15 ürün × 3 hedef = 45 ilan → ~15 dakika

### Senaryo 3: Multi-Store Publishing

```bash
python active_pieces/multi_store_publisher_gui.py
```

**Adımlar:**
1. **[🔍 ÜRÜN SEÇ]** butonuna tıkla
2. Listeden ürün seç (çift tıkla veya **[✅ SEÇ]**)
3. Sağ panel: Hedef mağazaları seç
4. **[👁️ ÖNİZLEME]** → Her mağaza için farklı başlık/açıklama görüntüle
5. **[📢 İLANLA]**
6. ✅ Ürün tüm seçili mağazalara yayınlanır

### Senaryo 4: Active Pieces Entegrasyonu

**Active Pieces Workflow Oluştur:**

1. **Flow 1: Product Favorited → Message Seller**
   - Trigger: Webhook (TATANGA)
   - Action: HTTP Request → Vinted API
   - Payload: `{"message": "Noch zu haben?"}`

2. **Flow 2: Message Received → Translate → Telegram**
   - Trigger: Schedule (15 min)
   - Action: Vinted API → Parse messages
   - Action: Groq API → Translate to Turkish
   - Action: HTTP Request → TATANGA Webhook
   - Webhook URL: `http://YOUR_IP:5000/api/activepieces/message-received`
   - Payload:
     ```json
     {
       "conversation_id": 456,
       "product_id": 123,
       "message_original": "Ja, ist noch da",
       "message_translated": "Evet, hala mevcut",
       "language": "de"
     }
     ```

3. **Flow 3: Telegram Button → Action**
   - Trigger: Telegram Button Click
   - Action: TATANGA Webhook
   - Actions:
     - `[DÜZELT]` → Edit product
     - `[OTOMATIK DEVAM]` → Continue conversation
     - `[BEKLET]` → Put on hold
     - `[SİTEYE GİT]` → Open URL

---

## 🔍 Sorun Giderme

### Hata: "Groq API key boş"

**Çözüm:**
```python
# active_pieces/config/credentials.py
API_KEYS = {
    'groq_api_key': 'gsk_xxxxxxxxxxxxxx',  # ← BURAYA KEY EKLE
}
```

### Hata: "Telegram bot token bulunamadı"

**Çözüm:**
1. @BotFather'dan bot oluştur
2. Token'ı `credentials.py` dosyasına ekle

### Hata: "Database table not found"

**Çözüm:**
```bash
python active_pieces/database_migration_v2.py
```

### Hata: "Port 5000 already in use"

**Çözüm:**
```bash
# Başka bir port kullan
webhook_api = ActivePiecesWebhook(port=5001)
```

### Hata: "opencv-python import hatası"

**Çözüm:**
```bash
pip uninstall opencv-python
pip install opencv-python-headless
```

---

## 📊 Performans İstatistikleri

| İşlem | Süre | Not |
|-------|------|-----|
| Resim manipülasyonu | 2-3 saniye | Aggressive level |
| SEO generation (ilk) | 3-5 saniye | Groq API |
| SEO generation (cache) | < 0.1 saniye | Cache'den |
| Hash test | 1-2 saniye | 4 algoritma |
| Transfer (1 ilan) | 15-20 saniye | Tam işlem |
| Transfer (60 ilan, paralel) | 15-20 dakika | 5 worker |

---

## 🎉 Başarı Kontrol Listesi

### Kurulum ✅
- [ ] Python paketleri yüklendi
- [ ] API keyler yapılandırıldı
- [ ] Database migration tamamlandı
- [ ] Test klasörleri oluşturuldu

### Modül Testleri ✅
- [ ] Resim manipülasyonu çalışıyor
- [ ] Hash tester distance > 10 veriyor
- [ ] Groq SEO generator yanıt veriyor
- [ ] Platform connectors database'e bağlanıyor
- [ ] Telegram bot komutlara yanıt veriyor
- [ ] Webhook API `/status` endpoint'i çalışıyor

### GUI Testleri ✅
- [ ] Store Manager: Mağaza eklendi
- [ ] Transfer Dashboard: Ürünler yüklendi
- [ ] Multi-Store Publisher: Önizleme çalıştı

### Entegrasyon Testleri ✅
- [ ] Transfer tamamlandı
- [ ] Telegram bildirimi geldi
- [ ] SEO varyasyonları farklı
- [ ] Resimler manipüle edildi

---

## 📞 Destek

**Dosyalar:**
- `TATANGA_QUICKSTART.md` - Bu dosya
- `README_TATANGA.md` - Detaylı dokümantasyon
- `active_pieces/core/logger.py` - Logları kontrol et

**Log Dosyaları:**
- `active_pieces/logs/` klasörü

**Sorun Bildir:**
GitHub Issues veya email

---

## 🚀 Sonraki Adımlar

1. ✅ Tüm testleri tamamla
2. ✅ İlk transfer'i başarıyla gerçekleştir
3. ✅ Active Pieces workflow'larını kur
4. ✅ Mağaza hesaplarını ekle
5. ✅ Otomatik monitoring başlat

**Hazırsın! 🎉**
