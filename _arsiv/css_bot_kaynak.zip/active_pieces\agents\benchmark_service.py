#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Benchmark Service
Reference pricing from sold products for arbitrage calculations

Features:
- Scrape sold products for reference prices
- Calculate average, min, max prices by condition
- Platform-specific pricing
- Cache management
- Historical price tracking

Author: TATANGA Team
Version: 2.0
"""

import sys
import asyncio
import sqlite3
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from pathlib import Path
from statistics import mean, median, stdev

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from core.event_bus import get_event_bus, emit, subscribe
except ImportError:
    def get_event_bus(): return None
    async def emit(*args, **kwargs): pass
    def subscribe(*args, **kwargs): pass

try:
    from core.logger import ModuleLogger
except ImportError:
    import logging
    class ModuleLogger:
        def __init__(self, name):
            self.logger = logging.getLogger(name)
        def info(self, msg, **kwargs):
            self.logger.info(f"{msg} {kwargs}")
        def error(self, msg, **kwargs):
            self.logger.error(f"{msg} {kwargs}")
        def warning(self, msg, **kwargs):
            self.logger.warning(f"{msg} {kwargs}")
        def debug(self, msg, **kwargs):
            self.logger.debug(f"{msg} {kwargs}")


class BenchmarkService:
    """
    Benchmark Service - Reference Pricing

    Provides reference prices from sold products for profit calculation.

    Methods:
    1. get_benchmark(): Get stored benchmark price
    2. scrape_sold_products(): Scrape sold products from platforms
    3. calculate_benchmark(): Calculate average from sold products
    4. update_benchmarks(): Refresh benchmark data
    """

    # Platform-specific sold search URLs
    SOLD_SEARCH_CONFIG = {
        'vinted': {
            'filter_param': 'status=1',  # sold items
            'sold_indicator': ['verkauft', 'sold', 'vendu', 'venduto'],
        },
        'ebay': {
            'filter_param': 'LH_Complete=1&LH_Sold=1',
            'sold_indicator': ['sold', 'verkauft', 'vendu'],
        },
        'leboncoin': {
            'sold_indicator': ['vendu'],
        },
        'kleinanzeigen': {
            'sold_indicator': ['reserviert', 'verkauft'],
        }
    }

    def __init__(self, db_path: str = None):
        """
        Initialize Benchmark Service

        Args:
            db_path: Path to database
        """
        if db_path:
            self.db_path = Path(db_path)
        else:
            self.db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'

        self.logger = ModuleLogger("benchmark_service")
        self.event_bus = get_event_bus()

        # Cache
        self._cache = {}
        self._cache_ttl = 3600  # 1 hour

        # Statistics
        self.stats = {
            'benchmarks_calculated': 0,
            'cache_hits': 0,
            'cache_misses': 0
        }

        self.logger.info("Benchmark Service initialized")

    async def get_benchmark(self, product_name: str, brand: str = None,
                           condition_score: int = None, platform: str = None) -> Optional[Dict]:
        """
        Get benchmark price for a product

        Args:
            product_name: Product name/query
            brand: Brand name (optional)
            condition_score: Condition score to match (optional)
            platform: Platform to search (optional)

        Returns:
            Benchmark data dict or None
        """
        # Check cache first
        cache_key = f"{product_name}:{brand}:{condition_score}:{platform}"
        if cache_key in self._cache:
            cached = self._cache[cache_key]
            if datetime.now() - cached['timestamp'] < timedelta(seconds=self._cache_ttl):
                self.stats['cache_hits'] += 1
                return cached['data']

        self.stats['cache_misses'] += 1

        # Try database
        benchmark = self._get_from_db(product_name, brand, condition_score, platform)

        if benchmark:
            # Cache result
            self._cache[cache_key] = {
                'data': benchmark,
                'timestamp': datetime.now()
            }
            return benchmark

        return None

    def _get_from_db(self, product_name: str, brand: str = None,
                     condition_score: int = None, platform: str = None) -> Optional[Dict]:
        """Get benchmark from database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            # Build query
            query = "SELECT * FROM benchmarks WHERE LOWER(product_name) LIKE LOWER(?)"
            params = [f"%{product_name}%"]

            if brand:
                query += " AND LOWER(brand) = LOWER(?)"
                params.append(brand)

            if condition_score is not None:
                query += " AND condition_score = ?"
                params.append(condition_score)

            if platform:
                query += " AND platform = ?"
                params.append(platform)

            query += " ORDER BY sample_count DESC, last_updated DESC LIMIT 1"

            cursor.execute(query, params)
            row = cursor.fetchone()
            conn.close()

            if row:
                return {
                    'id': row[0],
                    'product_name': row[1],
                    'brand': row[2],
                    'category': row[3],
                    'condition_score': row[4],
                    'platform': row[5],
                    'avg_price': row[6],
                    'min_price': row[7],
                    'max_price': row[8],
                    'sample_count': row[9],
                    'currency': row[10],
                    'last_updated': row[11]
                }

            return None

        except Exception as e:
            self.logger.error("DB lookup error", exception=str(e))
            return None

    async def calculate_benchmark(self, sold_products: List[Dict],
                                  condition_score: int = None) -> Dict:
        """
        Calculate benchmark from list of sold products

        Args:
            sold_products: List of sold product dicts with 'price' field
            condition_score: Optional filter by condition score

        Returns:
            Benchmark statistics dict
        """
        if not sold_products:
            return {
                'avg_price': 0,
                'min_price': 0,
                'max_price': 0,
                'median_price': 0,
                'sample_count': 0
            }

        # Filter by condition if specified
        if condition_score is not None:
            sold_products = [
                p for p in sold_products
                if p.get('normalized_score') == condition_score
            ]

        if not sold_products:
            return {
                'avg_price': 0,
                'min_price': 0,
                'max_price': 0,
                'median_price': 0,
                'sample_count': 0
            }

        prices = [p.get('price', 0) for p in sold_products if p.get('price', 0) > 0]

        if not prices:
            return {
                'avg_price': 0,
                'min_price': 0,
                'max_price': 0,
                'median_price': 0,
                'sample_count': 0
            }

        self.stats['benchmarks_calculated'] += 1

        result = {
            'avg_price': round(mean(prices), 2),
            'min_price': round(min(prices), 2),
            'max_price': round(max(prices), 2),
            'median_price': round(median(prices), 2),
            'sample_count': len(prices)
        }

        if len(prices) > 1:
            result['std_dev'] = round(stdev(prices), 2)

        return result

    async def save_benchmark(self, product_name: str, benchmark: Dict,
                            brand: str = None, category: str = None,
                            condition_score: int = None, platform: str = None) -> bool:
        """
        Save benchmark to database

        Args:
            product_name: Product name
            benchmark: Benchmark data from calculate_benchmark()
            brand: Brand name
            category: Product category
            condition_score: Condition score
            platform: Platform name

        Returns:
            Success status
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO benchmarks
                (product_name, brand, category, condition_score, platform,
                 avg_price, min_price, max_price, sample_count, currency, last_updated)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'EUR', ?)
                ON CONFLICT(product_name, brand, condition_score, platform) DO UPDATE SET
                    avg_price = ?,
                    min_price = ?,
                    max_price = ?,
                    sample_count = ?,
                    last_updated = ?
            """, (
                product_name, brand, category, condition_score, platform,
                benchmark['avg_price'], benchmark['min_price'], benchmark['max_price'],
                benchmark['sample_count'], datetime.now(),
                # For update
                benchmark['avg_price'], benchmark['min_price'], benchmark['max_price'],
                benchmark['sample_count'], datetime.now()
            ))

            conn.commit()
            conn.close()

            self.logger.info(f"Saved benchmark: {product_name} = {benchmark['avg_price']}€")
            return True

        except Exception as e:
            self.logger.error("Failed to save benchmark", exception=str(e))
            return False

    async def scrape_sold_products(self, query: str, platform: str,
                                   limit: int = 50) -> List[Dict]:
        """
        Scrape sold products from a platform

        This is a placeholder - actual implementation would use
        the platform connectors with sold filter.

        Args:
            query: Search query
            platform: Platform name (vinted, ebay, etc.)
            limit: Maximum products to scrape

        Returns:
            List of sold product dicts
        """
        self.logger.info(f"Scraping sold products: {query} on {platform}")

        # This would be implemented using actual scrapers
        # For now, return empty list
        # TODO: Integrate with scraping manager

        try:
            # Example: Use existing connector with sold filter
            # from integrations.vinted_enhanced import VintedEnhancedScraper
            # scraper = VintedEnhancedScraper(country=platform.split('_')[1])
            # results = await scraper.search_sold(query, limit)
            # return results

            return []

        except Exception as e:
            self.logger.error("Sold products scraping failed", exception=str(e))
            return []

    async def update_benchmark_from_scrape(self, query: str, brand: str = None,
                                          platforms: List[str] = None) -> Dict:
        """
        Update benchmark by scraping sold products

        Args:
            query: Product search query
            brand: Brand name
            platforms: List of platforms to scrape (default: all major)

        Returns:
            Updated benchmark data
        """
        if platforms is None:
            platforms = ['vinted_de', 'ebay_de', 'vinted_uk', 'ebay_uk']

        all_sold_products = []

        for platform in platforms:
            sold = await self.scrape_sold_products(query, platform, limit=30)
            all_sold_products.extend(sold)

        if not all_sold_products:
            self.logger.warning(f"No sold products found for: {query}")
            return {'avg_price': 0, 'sample_count': 0}

        # Calculate benchmark for each condition score
        benchmarks = {}
        for score in range(1, 6):
            benchmark = await self.calculate_benchmark(all_sold_products, condition_score=score)
            if benchmark['sample_count'] > 0:
                benchmarks[score] = benchmark

                # Save to database
                await self.save_benchmark(
                    product_name=query,
                    benchmark=benchmark,
                    brand=brand,
                    condition_score=score,
                    platform='all'
                )

        # Calculate overall benchmark
        overall = await self.calculate_benchmark(all_sold_products)
        await self.save_benchmark(
            product_name=query,
            benchmark=overall,
            brand=brand,
            condition_score=None,
            platform='all'
        )

        return {
            'query': query,
            'overall': overall,
            'by_condition': benchmarks,
            'platforms_scraped': platforms,
            'total_samples': len(all_sold_products)
        }

    async def get_price_suggestion(self, product_name: str, brand: str = None,
                                   condition_score: int = 4, margin: float = 0.30) -> Dict:
        """
        Get suggested purchase price based on benchmark

        Args:
            product_name: Product name
            brand: Brand name
            condition_score: Expected condition
            margin: Desired profit margin

        Returns:
            Price suggestion dict
        """
        benchmark = await self.get_benchmark(product_name, brand, condition_score)

        if not benchmark or benchmark['avg_price'] == 0:
            return {
                'has_benchmark': False,
                'message': 'No benchmark data available'
            }

        selling_price = benchmark['avg_price']
        max_purchase_price = selling_price * (1 - margin)

        return {
            'has_benchmark': True,
            'selling_price': round(selling_price, 2),
            'max_purchase_price': round(max_purchase_price, 2),
            'margin': margin,
            'sample_count': benchmark['sample_count'],
            'price_range': {
                'min': benchmark['min_price'],
                'max': benchmark['max_price']
            },
            'recommendation': f"Max {max_purchase_price:.0f}€ öde, {selling_price:.0f}€'ya sat, %{margin*100:.0f} kâr"
        }

    def get_stats(self) -> Dict:
        """Get service statistics"""
        return {
            **self.stats,
            'cache_size': len(self._cache)
        }


# ==================== TEST ====================

if __name__ == "__main__":
    import asyncio

    print("=" * 60)
    print("BENCHMARK SERVICE TEST")
    print("=" * 60)

    async def test():
        service = BenchmarkService()

        # Test with mock sold products
        mock_sold_products = [
            {'price': 85, 'normalized_score': 5, 'platform': 'vinted_de'},
            {'price': 90, 'normalized_score': 5, 'platform': 'ebay_de'},
            {'price': 95, 'normalized_score': 5, 'platform': 'vinted_uk'},
            {'price': 75, 'normalized_score': 4, 'platform': 'vinted_de'},
            {'price': 80, 'normalized_score': 4, 'platform': 'ebay_de'},
            {'price': 70, 'normalized_score': 4, 'platform': 'vinted_de'},
            {'price': 60, 'normalized_score': 3, 'platform': 'vinted_de'},
            {'price': 55, 'normalized_score': 3, 'platform': 'ebay_uk'},
            {'price': 45, 'normalized_score': 2, 'platform': 'vinted_de'},
        ]

        print("\nCalculating benchmarks from sold products...")
        print("-" * 60)

        # Overall benchmark
        overall = await service.calculate_benchmark(mock_sold_products)
        print(f"\nOverall Benchmark:")
        print(f"  Average: {overall['avg_price']}€")
        print(f"  Median: {overall['median_price']}€")
        print(f"  Range: {overall['min_price']}€ - {overall['max_price']}€")
        print(f"  Samples: {overall['sample_count']}")

        # By condition score
        print(f"\nBy Condition Score:")
        for score in range(5, 1, -1):
            benchmark = await service.calculate_benchmark(mock_sold_products, condition_score=score)
            if benchmark['sample_count'] > 0:
                print(f"  Score {score}: {benchmark['avg_price']}€ ({benchmark['sample_count']} samples)")

        # Save to database
        print(f"\nSaving benchmark for 'Levi's 501'...")
        success = await service.save_benchmark(
            product_name="Levi's 501",
            benchmark=overall,
            brand="Levi's",
            category="Jeans",
            condition_score=4,
            platform='all'
        )
        print(f"  Save: {'Success' if success else 'Failed'}")

        # Get price suggestion
        print(f"\nPrice Suggestion (40% margin):")
        suggestion = await service.get_price_suggestion(
            product_name="Levi's 501",
            brand="Levi's",
            condition_score=4,
            margin=0.40
        )

        if suggestion.get('has_benchmark'):
            print(f"  {suggestion['recommendation']}")
            print(f"  Selling Price: {suggestion['selling_price']}€")
            print(f"  Max Purchase: {suggestion['max_purchase_price']}€")
        else:
            print(f"  {suggestion['message']}")

        print(f"\nStats: {service.get_stats()}")
        print("\n" + "=" * 60)
        print("BENCHMARK SERVICE TEST COMPLETE")
        print("=" * 60)

    asyncio.run(test())
