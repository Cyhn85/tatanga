# Flow 1: Vinted Product Scraper
import sys, os, time, requests, re
from typing import List, Dict, Optional
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')

from playwright.sync_api import sync_playwright
from config import BASE_DIR, RAW_DIR
from utils.database import db

class VintedScraper:
    def __init__(self, store_name: str, limit: int = 15):
        self.store_name = store_name
        self.limit = limit
        self.store = db.get_store_by_name(store_name)
        if not self.store:
            raise ValueError(f'Store not found: {store_name}')
        self.profile_url = self.store.get('profile_url', '')
        self.playwright_profile = self.store.get('chrome_profile', store_name)
        self.proxy_enabled = self.store.get('proxy_enabled', 0)
        self.proxy_host = self.store.get('proxy_host', '')
        self.proxy_port = self.store.get('proxy_port', 0)
        os.makedirs(RAW_DIR, exist_ok=True)

    def get_browser(self, pw):
        pdir = os.path.join(BASE_DIR, 'playwright_profiles', self.playwright_profile)
        os.makedirs(pdir, exist_ok=True)
        args = ['--disable-blink-features=AutomationControlled', '--no-sandbox']
        if self.proxy_enabled and self.proxy_host:
            args.append(f'--proxy-server=http://{self.proxy_host}:{self.proxy_port}')
        return pw.chromium.launch_persistent_context(user_data_dir=pdir, headless=False,
            args=args, viewport={'width':1920,'height':1080}, locale='de-DE', timezone_id='Europe/Berlin')

    def get_product_urls(self) -> List[str]:
        print(f'[SCRAPER] {self.store_name} - {self.profile_url}')
        urls = []
        with sync_playwright() as pw:
            br = self.get_browser(pw)
            pg = br.pages[0] if br.pages else br.new_page()
            try:
                pg.goto(self.profile_url + '/items', wait_until='domcontentloaded', timeout=60000)
                pg.wait_for_timeout(3000)
                try:
                    cb = pg.query_selector('[data-testid="cookie-consent-accept-all"]')
                    if cb: cb.click(); pg.wait_for_timeout(1000)
                except: pass
                for _ in range(3):
                    pg.evaluate('window.scrollTo(0, document.body.scrollHeight)')
                    pg.wait_for_timeout(2000)
                seen = set()
                for lnk in pg.query_selector_all('a[href*="/items/"]'):
                    href = lnk.get_attribute('href')
                    if href and re.search(r'/items/\d+', href):
                        full = f'https://www.vinted.de{href}' if href.startswith('/') else href
                        if full not in seen:
                            seen.add(full); urls.append(full)
                            if len(urls) >= self.limit: break
                print(f'[OK] {len(urls)} URL bulundu')
            except Exception as e: print(f'[ERROR] {e}')
            finally: br.close()
        return urls

    def get_product(self, url: str) -> Optional[Dict]:
        with sync_playwright() as pw:
            br = self.get_browser(pw)
            pg = br.pages[0] if br.pages else br.new_page()
            try:
                pg.goto(url, wait_until='domcontentloaded', timeout=60000)
                pg.wait_for_timeout(3000)
                vid = re.search(r'/items/(\d+)', url)
                if not vid: br.close(); return None
                data = {'vinted_id': vid.group(1), 'vinted_url': url, 'source_store': self.store_name}

                # Title
                el = pg.query_selector('[data-testid="item-title"], h1')
                if el: data['raw_title'] = el.inner_text().strip()

                # Click "... mehr" to expand full description
                try:
                    mehr_btns = pg.query_selector_all('button')
                    for btn in mehr_btns:
                        if 'mehr' in btn.inner_text().lower():
                            btn.click()
                            pg.wait_for_timeout(800)
                            break
                except: pass

                # Get full description using itemprop selector
                el = pg.query_selector('[itemprop="description"]')
                if el: data['raw_description'] = el.inner_text().strip()

                # Price
                el = pg.query_selector('[data-testid="item-price"]')
                if el:
                    m = re.search(r'[\d,\.]+', el.inner_text().replace(',','.'))
                    if m: data['price'] = float(m.group())

                # Brand from link
                el = pg.query_selector('a[href*="/brand/"]')
                if el: data['brand'] = el.inner_text().strip()

                # ===== PRODUCT DETAILS (Marke, Modell, Speicher, Zustand, etc.) =====
                details = {}
                # Method 1: Find detail rows in the sidebar
                detail_rows = pg.query_selector_all('[class*="ItemDetails"] [class*="Row"], [class*="details"] tr, [data-testid*="item-details"] > div')
                for row in detail_rows:
                    text = row.inner_text().strip()
                    if '\n' in text:
                        parts = text.split('\n')
                        if len(parts) >= 2:
                            key = parts[0].strip().lower().replace(':', '')
                            val = parts[1].strip()
                            details[key] = val

                # Method 2: Look for specific data-testid attributes
                spec_selectors = {
                    'model': '[data-testid="item-attributes-model"] a, [href*="/catalog/"]',
                    'size': '[data-testid="item-attributes-size"], [class*="Size"]',
                    'condition': '[data-testid="item-attributes-status"]',
                    'color': '[data-testid="item-attributes-color"]',
                }
                for key, sel in spec_selectors.items():
                    el = pg.query_selector(sel)
                    if el and key not in details:
                        details[key] = el.inner_text().strip()

                # Method 3: Parse the details section more thoroughly
                details_section = pg.query_selector('[class*="ItemPage__Details"], [class*="item-details"]')
                if details_section:
                    # Find all text pairs
                    all_text = details_section.inner_text()
                    lines = [l.strip() for l in all_text.split('\n') if l.strip()]
                    for i in range(0, len(lines)-1, 1):
                        key_lower = lines[i].lower().replace(':', '').strip()
                        if key_lower in ['marke', 'modell', 'speicher', 'zustand', 'sim-lock', 'farbe', 'größe', 'material', 'hochgeladen']:
                            if i+1 < len(lines):
                                details[key_lower] = lines[i+1]

                # Store details in extra_fields
                if details:
                    data['extra_fields'] = details
                    # Also map common fields
                    if 'modell' in details: data['model'] = details['modell']
                    if 'größe' in details: data['size'] = details['größe']
                    if 'zustand' in details: data['condition'] = details['zustand']
                    if 'farbe' in details: data['color'] = details['farbe']

                print(f'[DETAILS] {len(details)} specs found: {list(details.keys())[:5]}')

                # Images - STRICT filtering to avoid recommendation images
                imgs = []
                vinted_id = data.get('vinted_id', '')

                # Only look in the main gallery area - NOT the whole page
                gallery = pg.query_selector('[data-testid="item-photos"]')
                if not gallery:
                    gallery = pg.query_selector('[class*="ItemGallery"], [class*="item-photos"]')

                if gallery:
                    img_elements = gallery.query_selector_all('img')
                    for im in img_elements:
                        src = im.get_attribute('src') or im.get_attribute('data-src')
                        if not src or 'vinted.net' not in src:
                            continue
                        # Exclude avatars, logos, thumbnails from other sections
                        if any(x in src.lower() for x in ['avatar', 'logo', 'user', 'member']):
                            continue
                        # Upgrade to high resolution
                        hi = re.sub(r'/f\d+/', '/f800/', src)
                        if hi not in imgs:
                            imgs.append(hi)

                # Deduplicate and DO NOT pad to 10 - only use real product images
                imgs = list(dict.fromkeys(imgs))
                data['image_urls'] = imgs
                data['image_count'] = len(imgs)

                print(f'[OK] {data.get("raw_title","?")[:40]} - {len(imgs)} img')
                br.close()
                return data
            except Exception as e:
                print(f'[ERROR] {e}')
                br.close()
                return None

    def download_imgs(self, data: Dict) -> str:
        vid = data.get('vinted_id')
        urls = data.get('image_urls', [])
        if not vid or not urls: return ''
        pdir = os.path.join(RAW_DIR, vid)
        os.makedirs(pdir, exist_ok=True)
        for i, u in enumerate(urls):
            try:
                r = requests.get(u, timeout=30)
                if r.status_code == 200:
                    with open(os.path.join(pdir, f'img_{i+1}.jpg'), 'wb') as f: f.write(r.content)
            except: pass
        return pdir

    def run(self) -> List[int]:
        print('='*50 + f'\nSCRAPER: {self.store_name} - {self.limit} urun\n' + '='*50)
        urls = self.get_product_urls()
        if not urls: return []
        ids = []
        for i, url in enumerate(urls):
            print(f'\n[{i+1}/{len(urls)}] {url}')
            data = self.get_product(url)
            if not data: continue
            data['raw_images_path'] = self.download_imgs(data)
            try:
                pid = db.add_product(data)
                ids.append(pid)
                db.add_log(pid, 'scrape', 'success', f'From {self.store_name}')
                print(f'[DB] Saved ID={pid}')
            except Exception as e: print(f'[DB ERR] {e}')
            time.sleep(2)
        print(f'\n*** DONE: {len(ids)} products saved ***')
        return ids

def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--store', default='cyhn85')
    p.add_argument('--limit', type=int, default=15)
    a = p.parse_args()
    return VintedScraper(a.store, a.limit).run()

if __name__ == '__main__': main()
