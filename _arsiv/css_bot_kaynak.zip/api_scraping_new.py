"""
TATANGA V3 - Scraping API with Human Scrapers
7 platform destekli insan-benzeri kazima sistemi
"""
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from database import get_db
from models import ScrapeJob, Product
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from celery.result import AsyncResult
import random

router = APIRouter()


def generate_job_id():
    date_str = datetime.now().strftime("%Y%m%d")
    seq = str(random.randint(1, 9999)).zfill(4)
    return f"JOB-{date_str}-{seq}"


def generate_scr_id():
    date_str = datetime.now().strftime("%Y%m%d")
    seq = str(random.randint(1, 9999)).zfill(4)
    return f"SCR-{date_str}-{seq}"


class ScrapeRequest(BaseModel):
    platform: str
    search_term: Optional[str] = None
    query: Optional[str] = None  # alias for search_term
    category: Optional[str] = None
    min_price: Optional[float] = None
    max_price: Optional[float] = None
    page_count: Optional[int] = None
    max_pages: Optional[int] = None  # alias for page_count
    max_items: int = 50
    condition: Optional[str] = None
    conditions: Optional[List[str]] = None  # Coklu durum listesi
    sort: Optional[str] = None

    @property
    def get_search_term(self):
        return self.search_term or self.query or ""

    @property
    def get_page_count(self):
        return self.page_count or self.max_pages or 3


@router.get("/platforms")
async def get_platforms():
    """
    Desteklenen 7 platform listesi
    - Almanca: vinted, ebay, kleinanzeigen, willhaben, sellpy, percentil
    - Isvecce: tradera
    """
    return {
        "platforms": [
            {"id": "vinted", "name": "Vinted DE", "status": "active", "language": "de"},
            {"id": "ebay", "name": "eBay DE", "status": "active", "language": "de"},
            {"id": "kleinanzeigen", "name": "Kleinanzeigen", "status": "active", "language": "de"},
            {"id": "willhaben", "name": "Willhaben AT", "status": "active", "language": "de"},
            {"id": "sellpy", "name": "Sellpy DE", "status": "active", "language": "de"},
            {"id": "percentil", "name": "Percentil DE", "status": "active", "language": "de"},
            {"id": "tradera", "name": "Tradera SE", "status": "active", "language": "sv"}
        ],
        "conditions": {
            "de": ["neu", "sehr gut", "gut", "akzeptabel"],
            "sv": ["nyskick", "mycket gott skick", "gott skick", "anvant skick"]
        }
    }


@router.get("/jobs")
async def get_scrape_jobs(
    status: Optional[str] = None,
    limit: int = 20,
    db: AsyncSession = Depends(get_db)
):
    query = select(ScrapeJob).order_by(desc(ScrapeJob.created_at)).limit(limit)
    if status:
        query = query.where(ScrapeJob.status == status)
    result = await db.execute(query)
    return result.scalars().all()


@router.post("/start")
async def start_scrape(request: ScrapeRequest, db: AsyncSession = Depends(get_db)):
    """Start a new scrape job using Celery with Human Scrapers"""
    from celery_worker import scrape_task

    job_id = generate_job_id()

    # Create job record
    job = ScrapeJob(
        job_id=job_id,
        platform=request.platform,
        search_term=request.get_search_term,
        category=request.category,
        min_price=request.min_price,
        max_price=request.max_price,
        page_count=request.get_page_count,
        status="running",
        started_at=datetime.utcnow()
    )
    db.add(job)
    await db.commit()
    await db.refresh(job)

    # Submit Celery task with human scrapers
    task = scrape_task.delay(
        platform=request.platform,
        query=request.get_search_term,
        max_pages=request.get_page_count,
        max_items=request.max_items,
        min_price=request.min_price,
        max_price=request.max_price,
        condition=request.condition,
        conditions=request.conditions,
        sort=request.sort,
        job_id=job_id
    )

    return {
        "message": "Scrape job started with human-like behavior",
        "job_id": job_id,
        "task_id": task.id,
        "status": "running",
        "platform": request.platform
    }


@router.get("/jobs/{job_id}")
async def get_job_status(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ScrapeJob).where(ScrapeJob.job_id == job_id))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.get("/task/{task_id}")
async def get_task_status(task_id: str):
    """Get Celery task status"""
    task = AsyncResult(task_id)
    return {
        "task_id": task_id,
        "status": task.status,
        "ready": task.ready(),
        "result": task.result if task.ready() else None
    }


@router.post("/test")
async def test_scrape(platform: str = "vinted", query: str = "nike", max_items: int = 5):
    """Quick test scrape with human scrapers (synchronous, limited)"""
    from celery_worker import get_scraper_class

    ScraperClass = get_scraper_class(platform)
    if not ScraperClass:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown platform: {platform}. Supported: vinted, ebay, kleinanzeigen, willhaben, sellpy, percentil, tradera"
        )

    try:
        with ScraperClass(headless=True) as scraper:
            products = scraper.scrape(query=query, max_products=max_items, max_pages=1)

        return {
            "status": "success",
            "platform": platform,
            "query": query,
            "items_found": len(products),
            "products": products[:5]
        }
    except Exception as e:
        return {
            "status": "error",
            "platform": platform,
            "query": query,
            "error": str(e)
        }


@router.post("/save-results/{job_id}")
async def save_results(job_id: str, db: AsyncSession = Depends(get_db)):
    """Save scrape results to products table"""
    job_result = await db.execute(select(ScrapeJob).where(ScrapeJob.job_id == job_id))
    job = job_result.scalar_one_or_none()

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # TODO: Get results from task and save to products
    return {"message": "Results saved", "job_id": job_id}


@router.delete("/jobs/{job_id}")
async def delete_job(job_id: str, db: AsyncSession = Depends(get_db)):
    """Delete a scrape job"""
    result = await db.execute(select(ScrapeJob).where(ScrapeJob.job_id == job_id))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    await db.delete(job)
    await db.commit()
    return {"message": "Job deleted", "job_id": job_id}


@router.delete("/jobs")
async def delete_all_jobs(db: AsyncSession = Depends(get_db)):
    """Delete all scrape jobs"""
    await db.execute(select(ScrapeJob).execution_options(synchronize_session="fetch"))
    from sqlalchemy import delete
    await db.execute(delete(ScrapeJob))
    await db.commit()
    return {"message": "All jobs deleted"}


@router.post("/jobs/{job_id}/cancel")
async def cancel_job(job_id: str, db: AsyncSession = Depends(get_db)):
    """Cancel a running scrape job"""
    result = await db.execute(select(ScrapeJob).where(ScrapeJob.job_id == job_id))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    job.status = "cancelled"
    job.completed_at = datetime.utcnow()
    await db.commit()
    return {"message": "Job cancelled", "job_id": job_id}
