#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MOBILE FARM MANAGER - Android Telefon Ciftligi Yonetimi
Birden fazla Android cihazi paralel olarak yonetir

Features:
- ADB (Android Debug Bridge) ile cihaz yonetimi
- Birden fazla cihazi paralel kullanma
- Gorev kuyrugu ve dagitimi
- Cihaz durumu izleme
- Otomatik yeniden baglanti
- Appium entegrasyonu (otomasyon)
- scrcpy entegrasyonu (ekran yansitma)
- Screenshot ve screen recording
- Uygulama kurulum/kaldirma
- Tarayici otomasyonu (Chrome, Firefox)
- Platform uygulamalari (Vinted, eBay apps)

Author: TATANGA Team
Version: 1.0
"""

import sys
import os
import json
import sqlite3
import asyncio
import subprocess
import time
import threading
import queue
import random
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
from concurrent.futures import ThreadPoolExecutor
import hashlib

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.logger import ModuleLogger


# ============================================================================
# ENUMS & DATA MODELS
# ============================================================================

class DeviceStatus(Enum):
    """Device status"""
    ONLINE = "online"           # Connected and ready
    OFFLINE = "offline"         # Not connected
    BUSY = "busy"               # Processing a task
    ERROR = "error"             # Error state
    MAINTENANCE = "maintenance" # Manual maintenance
    UNAUTHORIZED = "unauthorized"  # USB debugging not authorized


class TaskType(Enum):
    """Types of mobile farm tasks"""
    SCREENSHOT = "screenshot"         # Take screenshot of URL
    SCRAPE = "scrape"                # Scrape data from page
    INTERACT = "interact"            # Click, type, scroll
    APP_AUTOMATE = "app_automate"    # Automate app actions
    BROWSE = "browse"                # Browse URL
    LOGIN = "login"                  # Login to platform
    MESSAGE = "message"              # Send message
    SEARCH = "search"                # Search on platform
    MONITOR = "monitor"              # Monitor page for changes


class TaskPriority(Enum):
    """Task priority levels"""
    LOW = 1
    NORMAL = 5
    HIGH = 8
    URGENT = 10


@dataclass
class Device:
    """Android device information"""
    device_id: str                    # ADB device ID
    model: str = ""                   # Device model
    android_version: str = ""         # Android version
    status: DeviceStatus = DeviceStatus.OFFLINE
    battery_level: int = 0            # Battery percentage
    screen_size: Tuple[int, int] = (0, 0)  # Width x Height
    ip_address: str = ""              # WiFi IP for wireless ADB
    last_seen: datetime = None
    current_task_id: int = None
    total_tasks_completed: int = 0
    success_rate: float = 0.0
    tags: List[str] = field(default_factory=list)  # Device tags/capabilities
    metadata: Dict = field(default_factory=dict)


@dataclass
class MobileTask:
    """Task for mobile farm"""
    id: int = None
    task_type: TaskType = TaskType.SCREENSHOT
    priority: TaskPriority = TaskPriority.NORMAL
    url: str = ""
    app_package: str = ""             # For app automation
    actions: List[Dict] = field(default_factory=list)  # List of actions to perform
    expected_result: Dict = field(default_factory=dict)
    callback_data: Dict = field(default_factory=dict)
    device_preference: str = None     # Preferred device ID
    status: str = "pending"           # pending, running, completed, failed
    device_id: str = None             # Assigned device
    result: Dict = field(default_factory=dict)
    error: str = ""
    retry_count: int = 0
    max_retries: int = 3
    created_at: datetime = None
    started_at: datetime = None
    completed_at: datetime = None


# ============================================================================
# ADB WRAPPER
# ============================================================================

class ADBWrapper:
    """Wrapper for ADB commands"""

    def __init__(self, adb_path: str = "adb"):
        """Initialize ADB wrapper"""
        self.adb_path = adb_path
        self.logger = ModuleLogger('adb')

    def _run_command(self, args: List[str], device_id: str = None, timeout: int = 30) -> Tuple[bool, str]:
        """Run ADB command"""
        cmd = [self.adb_path]
        if device_id:
            cmd.extend(['-s', device_id])
        cmd.extend(args)

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout
            )

            if result.returncode == 0:
                return True, result.stdout.strip()
            else:
                return False, result.stderr.strip()

        except subprocess.TimeoutExpired:
            return False, "Command timed out"
        except Exception as e:
            return False, str(e)

    def get_devices(self) -> List[Dict]:
        """Get list of connected devices"""
        success, output = self._run_command(['devices', '-l'])

        if not success:
            return []

        devices = []
        for line in output.split('\n')[1:]:  # Skip header
            if not line.strip():
                continue

            parts = line.split()
            if len(parts) >= 2:
                device_id = parts[0]
                status = parts[1]

                device_info = {
                    'device_id': device_id,
                    'status': status,
                    'model': '',
                    'product': ''
                }

                # Parse additional info
                for part in parts[2:]:
                    if ':' in part:
                        key, value = part.split(':', 1)
                        device_info[key] = value

                devices.append(device_info)

        return devices

    def get_device_info(self, device_id: str) -> Dict:
        """Get detailed device information"""
        info = {'device_id': device_id}

        # Model
        success, model = self._run_command(['shell', 'getprop', 'ro.product.model'], device_id)
        if success:
            info['model'] = model

        # Android version
        success, version = self._run_command(['shell', 'getprop', 'ro.build.version.release'], device_id)
        if success:
            info['android_version'] = version

        # Battery level
        success, battery = self._run_command(['shell', 'dumpsys', 'battery'], device_id)
        if success:
            for line in battery.split('\n'):
                if 'level:' in line:
                    try:
                        info['battery_level'] = int(line.split(':')[1].strip())
                    except:
                        pass

        # Screen size
        success, wm = self._run_command(['shell', 'wm', 'size'], device_id)
        if success and 'Physical size:' in wm:
            try:
                size = wm.split(':')[1].strip()
                width, height = map(int, size.split('x'))
                info['screen_size'] = (width, height)
            except:
                pass

        # IP address
        success, ip = self._run_command(['shell', 'ip', 'route', 'get', '1'], device_id)
        if success:
            for part in ip.split():
                if part.startswith('192.') or part.startswith('10.') or part.startswith('172.'):
                    info['ip_address'] = part
                    break

        return info

    def take_screenshot(self, device_id: str, output_path: str) -> bool:
        """Take screenshot and save to file"""
        # Take screenshot on device
        remote_path = '/sdcard/screenshot.png'
        success, _ = self._run_command(['shell', 'screencap', '-p', remote_path], device_id)

        if not success:
            return False

        # Pull to local
        success, _ = self._run_command(['pull', remote_path, output_path], device_id)

        # Clean up remote file
        self._run_command(['shell', 'rm', remote_path], device_id)

        return success

    def tap(self, device_id: str, x: int, y: int) -> bool:
        """Tap on screen coordinates"""
        success, _ = self._run_command(['shell', 'input', 'tap', str(x), str(y)], device_id)
        return success

    def swipe(self, device_id: str, x1: int, y1: int, x2: int, y2: int, duration_ms: int = 300) -> bool:
        """Swipe on screen"""
        success, _ = self._run_command([
            'shell', 'input', 'swipe',
            str(x1), str(y1), str(x2), str(y2), str(duration_ms)
        ], device_id)
        return success

    def input_text(self, device_id: str, text: str) -> bool:
        """Input text (escapes spaces)"""
        escaped = text.replace(' ', '%s')
        success, _ = self._run_command(['shell', 'input', 'text', escaped], device_id)
        return success

    def press_key(self, device_id: str, keycode: int) -> bool:
        """Press key by keycode (e.g., 4=back, 3=home, 66=enter)"""
        success, _ = self._run_command(['shell', 'input', 'keyevent', str(keycode)], device_id)
        return success

    def open_url(self, device_id: str, url: str) -> bool:
        """Open URL in default browser"""
        success, _ = self._run_command([
            'shell', 'am', 'start', '-a', 'android.intent.action.VIEW', '-d', url
        ], device_id)
        return success

    def launch_app(self, device_id: str, package: str, activity: str = None) -> bool:
        """Launch app by package name"""
        if activity:
            success, _ = self._run_command([
                'shell', 'am', 'start', '-n', f'{package}/{activity}'
            ], device_id)
        else:
            success, _ = self._run_command([
                'shell', 'monkey', '-p', package, '-c', 'android.intent.category.LAUNCHER', '1'
            ], device_id)
        return success

    def close_app(self, device_id: str, package: str) -> bool:
        """Force stop app"""
        success, _ = self._run_command(['shell', 'am', 'force-stop', package], device_id)
        return success

    def install_apk(self, device_id: str, apk_path: str) -> bool:
        """Install APK"""
        success, _ = self._run_command(['install', '-r', apk_path], device_id, timeout=120)
        return success

    def uninstall_app(self, device_id: str, package: str) -> bool:
        """Uninstall app"""
        success, _ = self._run_command(['uninstall', package], device_id)
        return success

    def get_installed_packages(self, device_id: str) -> List[str]:
        """Get list of installed packages"""
        success, output = self._run_command(['shell', 'pm', 'list', 'packages'], device_id)
        if success:
            return [line.replace('package:', '') for line in output.split('\n') if line]
        return []

    def connect_wireless(self, ip_address: str, port: int = 5555) -> bool:
        """Connect to device via WiFi"""
        success, _ = self._run_command(['connect', f'{ip_address}:{port}'])
        return success

    def disconnect_wireless(self, ip_address: str, port: int = 5555) -> bool:
        """Disconnect wireless device"""
        success, _ = self._run_command(['disconnect', f'{ip_address}:{port}'])
        return success

    def reboot(self, device_id: str) -> bool:
        """Reboot device"""
        success, _ = self._run_command(['reboot'], device_id)
        return success

    def get_screen_xml(self, device_id: str) -> str:
        """Get UI hierarchy XML"""
        remote_path = '/sdcard/window_dump.xml'
        success, _ = self._run_command(['shell', 'uiautomator', 'dump', remote_path], device_id)

        if not success:
            return ""

        success, xml = self._run_command(['shell', 'cat', remote_path], device_id)
        self._run_command(['shell', 'rm', remote_path], device_id)

        return xml if success else ""


# ============================================================================
# MOBILE FARM MANAGER
# ============================================================================

class MobileFarmManager:
    """
    Mobile Farm Manager

    Manages multiple Android devices for parallel task processing.

    Features:
    - Device discovery and management
    - Task queue and distribution
    - Load balancing
    - Health monitoring
    - Automatic recovery

    Usage:
        farm = MobileFarmManager()

        # Discover devices
        farm.discover_devices()

        # Queue task
        task_id = farm.queue_task(
            task_type=TaskType.SCREENSHOT,
            url='https://vinted.de/items/123'
        )

        # Start processing
        farm.start()
    """

    # Common app packages
    PLATFORM_APPS = {
        'vinted': 'fr.vinted',
        'ebay': 'com.ebay.mobile',
        'kleinanzeigen': 'com.ebay.kleinanzeigen',
        'shpock': 'com.shpock.android',
        'willhaben': 'at.willhaben',
        'chrome': 'com.android.chrome',
        'firefox': 'org.mozilla.firefox',
    }

    def __init__(self, max_concurrent: int = 5):
        """
        Initialize Mobile Farm Manager

        Args:
            max_concurrent: Maximum concurrent tasks
        """
        self.logger = ModuleLogger('mobile_farm')

        # Database path
        self.db_path = Path(__file__).parent.parent / 'storage' / 'mobile_farm.db'
        self._init_db()

        # ADB wrapper
        self.adb = ADBWrapper()

        # Device registry
        self.devices: Dict[str, Device] = {}

        # Task queue
        self.task_queue = queue.PriorityQueue()
        self._task_lock = threading.Lock()

        # Processing
        self.max_concurrent = max_concurrent
        self.executor = ThreadPoolExecutor(max_workers=max_concurrent)
        self._running = False
        self._worker_thread = None

        # Screenshots directory
        self.screenshot_dir = Path(__file__).parent.parent / 'storage' / 'mobile_screenshots'
        self.screenshot_dir.mkdir(parents=True, exist_ok=True)

        # Callbacks
        self._on_task_complete_callbacks = []
        self._on_device_status_change_callbacks = []

        self.logger.info(f"Mobile Farm Manager initialized (max {max_concurrent} concurrent)")

    def _init_db(self):
        """Initialize database"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Devices table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS devices (
                device_id TEXT PRIMARY KEY,
                model TEXT,
                android_version TEXT,
                status TEXT DEFAULT 'offline',
                battery_level INTEGER DEFAULT 0,
                screen_width INTEGER DEFAULT 0,
                screen_height INTEGER DEFAULT 0,
                ip_address TEXT,
                last_seen DATETIME,
                total_tasks INTEGER DEFAULT 0,
                successful_tasks INTEGER DEFAULT 0,
                tags TEXT,
                metadata TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Tasks table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS mobile_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_type TEXT NOT NULL,
                priority INTEGER DEFAULT 5,
                url TEXT,
                app_package TEXT,
                actions_json TEXT,
                expected_result_json TEXT,
                callback_data_json TEXT,
                device_preference TEXT,
                status TEXT DEFAULT 'pending',
                device_id TEXT,
                result_json TEXT,
                error TEXT,
                retry_count INTEGER DEFAULT 0,
                max_retries INTEGER DEFAULT 3,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                started_at DATETIME,
                completed_at DATETIME
            )
        """)

        # Task history for analytics
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER,
                device_id TEXT,
                task_type TEXT,
                success INTEGER,
                duration_seconds REAL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        conn.commit()
        conn.close()

    # ========================================================================
    # DEVICE MANAGEMENT
    # ========================================================================

    def discover_devices(self) -> List[Device]:
        """Discover connected Android devices"""
        adb_devices = self.adb.get_devices()

        discovered = []
        for dev_info in adb_devices:
            device_id = dev_info['device_id']

            if dev_info['status'] == 'device':
                # Get detailed info
                details = self.adb.get_device_info(device_id)

                device = Device(
                    device_id=device_id,
                    model=details.get('model', ''),
                    android_version=details.get('android_version', ''),
                    status=DeviceStatus.ONLINE,
                    battery_level=details.get('battery_level', 0),
                    screen_size=details.get('screen_size', (0, 0)),
                    ip_address=details.get('ip_address', ''),
                    last_seen=datetime.now()
                )

                self.devices[device_id] = device
                self._save_device(device)
                discovered.append(device)

                self.logger.info(f"Discovered device: {device_id} ({device.model})")

            elif dev_info['status'] == 'unauthorized':
                device = Device(
                    device_id=device_id,
                    status=DeviceStatus.UNAUTHORIZED,
                    last_seen=datetime.now()
                )
                self.devices[device_id] = device
                self.logger.warning(f"Device unauthorized: {device_id}")

        return discovered

    def add_wireless_device(self, ip_address: str, port: int = 5555) -> bool:
        """Add device via WiFi ADB"""
        success = self.adb.connect_wireless(ip_address, port)

        if success:
            time.sleep(1)
            self.discover_devices()

        return success

    def remove_device(self, device_id: str):
        """Remove device from farm"""
        if device_id in self.devices:
            del self.devices[device_id]

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM devices WHERE device_id = ?", (device_id,))
        conn.commit()
        conn.close()

        self.logger.info(f"Removed device: {device_id}")

    def get_device(self, device_id: str) -> Optional[Device]:
        """Get device by ID"""
        return self.devices.get(device_id)

    def get_all_devices(self) -> List[Device]:
        """Get all devices"""
        return list(self.devices.values())

    def get_available_devices(self) -> List[Device]:
        """Get devices available for tasks"""
        return [d for d in self.devices.values() if d.status == DeviceStatus.ONLINE]

    def set_device_status(self, device_id: str, status: DeviceStatus):
        """Set device status"""
        if device_id in self.devices:
            old_status = self.devices[device_id].status
            self.devices[device_id].status = status

            self._save_device(self.devices[device_id])

            # Notify callbacks
            for callback in self._on_device_status_change_callbacks:
                try:
                    callback(device_id, old_status, status)
                except:
                    pass

    def _save_device(self, device: Device):
        """Save device to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO devices (
                device_id, model, android_version, status, battery_level,
                screen_width, screen_height, ip_address, last_seen, tags, metadata
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(device_id) DO UPDATE SET
                model = excluded.model,
                android_version = excluded.android_version,
                status = excluded.status,
                battery_level = excluded.battery_level,
                screen_width = excluded.screen_width,
                screen_height = excluded.screen_height,
                ip_address = excluded.ip_address,
                last_seen = excluded.last_seen,
                tags = excluded.tags,
                metadata = excluded.metadata
        """, (
            device.device_id,
            device.model,
            device.android_version,
            device.status.value,
            device.battery_level,
            device.screen_size[0],
            device.screen_size[1],
            device.ip_address,
            device.last_seen.isoformat() if device.last_seen else None,
            json.dumps(device.tags),
            json.dumps(device.metadata)
        ))

        conn.commit()
        conn.close()

    # ========================================================================
    # TASK MANAGEMENT
    # ========================================================================

    def queue_task(
        self,
        task_type: TaskType,
        url: str = "",
        app_package: str = "",
        actions: List[Dict] = None,
        priority: TaskPriority = TaskPriority.NORMAL,
        expected_result: Dict = None,
        callback_data: Dict = None,
        device_preference: str = None,
        max_retries: int = 3
    ) -> int:
        """
        Queue a task for execution

        Args:
            task_type: Type of task
            url: URL to process
            app_package: App package for app automation
            actions: List of actions to perform
            priority: Task priority
            expected_result: Expected result for validation
            callback_data: Callback information
            device_preference: Preferred device ID
            max_retries: Maximum retry attempts

        Returns:
            Task ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO mobile_tasks (
                task_type, priority, url, app_package, actions_json,
                expected_result_json, callback_data_json, device_preference, max_retries
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            task_type.value,
            priority.value,
            url,
            app_package,
            json.dumps(actions or []),
            json.dumps(expected_result or {}),
            json.dumps(callback_data or {}),
            device_preference,
            max_retries
        ))

        task_id = cursor.lastrowid
        conn.commit()
        conn.close()

        # Create task object and add to queue
        task = MobileTask(
            id=task_id,
            task_type=task_type,
            priority=priority,
            url=url,
            app_package=app_package,
            actions=actions or [],
            expected_result=expected_result or {},
            callback_data=callback_data or {},
            device_preference=device_preference,
            max_retries=max_retries,
            created_at=datetime.now()
        )

        # Priority queue uses (priority_value, task) - lower number = higher priority
        # Negate priority so higher TaskPriority value = processed first
        self.task_queue.put((-priority.value, task_id, task))

        self.logger.info(f"Queued task {task_id}: {task_type.value}")
        return task_id

    def queue_screenshot(self, url: str, callback_data: Dict = None) -> int:
        """Convenience method to queue screenshot task"""
        return self.queue_task(
            task_type=TaskType.SCREENSHOT,
            url=url,
            callback_data=callback_data
        )

    def queue_browse(self, url: str, actions: List[Dict] = None) -> int:
        """Convenience method to queue browse task"""
        return self.queue_task(
            task_type=TaskType.BROWSE,
            url=url,
            actions=actions
        )

    def get_task(self, task_id: int) -> Optional[MobileTask]:
        """Get task by ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, task_type, priority, url, app_package, actions_json,
                   expected_result_json, callback_data_json, device_preference,
                   status, device_id, result_json, error, retry_count, max_retries,
                   created_at, started_at, completed_at
            FROM mobile_tasks WHERE id = ?
        """, (task_id,))

        row = cursor.fetchone()
        conn.close()

        if row:
            return self._row_to_task(row)
        return None

    def _row_to_task(self, row: tuple) -> MobileTask:
        """Convert database row to MobileTask"""
        return MobileTask(
            id=row[0],
            task_type=TaskType(row[1]),
            priority=TaskPriority(row[2]),
            url=row[3],
            app_package=row[4],
            actions=json.loads(row[5]) if row[5] else [],
            expected_result=json.loads(row[6]) if row[6] else {},
            callback_data=json.loads(row[7]) if row[7] else {},
            device_preference=row[8],
            status=row[9],
            device_id=row[10],
            result=json.loads(row[11]) if row[11] else {},
            error=row[12] or "",
            retry_count=row[13],
            max_retries=row[14],
            created_at=datetime.fromisoformat(row[15]) if row[15] else None,
            started_at=datetime.fromisoformat(row[16]) if row[16] else None,
            completed_at=datetime.fromisoformat(row[17]) if row[17] else None
        )

    # ========================================================================
    # TASK PROCESSING
    # ========================================================================

    def start(self):
        """Start task processing"""
        if self._running:
            return

        self._running = True
        self._worker_thread = threading.Thread(target=self._process_loop, daemon=True)
        self._worker_thread.start()

        self.logger.info("Mobile Farm started")

    def stop(self):
        """Stop task processing"""
        self._running = False
        if self._worker_thread:
            self._worker_thread.join(timeout=5)

        self.logger.info("Mobile Farm stopped")

    def _process_loop(self):
        """Main processing loop"""
        while self._running:
            try:
                # Get available devices
                available = self.get_available_devices()

                if not available:
                    time.sleep(1)
                    continue

                # Get task from queue
                try:
                    priority, task_id, task = self.task_queue.get(timeout=1)
                except queue.Empty:
                    continue

                # Find suitable device
                device = self._select_device(task, available)

                if not device:
                    # Re-queue task
                    self.task_queue.put((priority, task_id, task))
                    time.sleep(0.5)
                    continue

                # Execute task
                self.executor.submit(self._execute_task, task, device)

            except Exception as e:
                self.logger.error(f"Processing loop error: {e}")
                time.sleep(1)

    def _select_device(self, task: MobileTask, available: List[Device]) -> Optional[Device]:
        """Select best device for task"""
        # Check preference
        if task.device_preference:
            for device in available:
                if device.device_id == task.device_preference:
                    return device

        # Select based on success rate and load
        if available:
            # Prefer devices with higher success rate
            return max(available, key=lambda d: (d.success_rate, -d.total_tasks_completed))

        return None

    def _execute_task(self, task: MobileTask, device: Device):
        """Execute a task on device"""
        start_time = time.time()

        # Mark device busy
        self.set_device_status(device.device_id, DeviceStatus.BUSY)
        device.current_task_id = task.id

        # Update task status
        self._update_task_status(task.id, 'running', device.device_id)

        try:
            # Execute based on type
            if task.task_type == TaskType.SCREENSHOT:
                result = self._execute_screenshot(task, device)
            elif task.task_type == TaskType.BROWSE:
                result = self._execute_browse(task, device)
            elif task.task_type == TaskType.INTERACT:
                result = self._execute_interact(task, device)
            elif task.task_type == TaskType.APP_AUTOMATE:
                result = self._execute_app_automate(task, device)
            elif task.task_type == TaskType.SEARCH:
                result = self._execute_search(task, device)
            else:
                result = {'success': False, 'error': 'Unsupported task type'}

            # Save result
            duration = time.time() - start_time
            self._complete_task(task.id, result, duration, device.device_id)

            # Update device stats
            device.total_tasks_completed += 1
            if result.get('success'):
                device.success_rate = (device.success_rate * (device.total_tasks_completed - 1) + 1) / device.total_tasks_completed

            # Notify callbacks
            for callback in self._on_task_complete_callbacks:
                try:
                    callback(task.id, result)
                except:
                    pass

        except Exception as e:
            self.logger.error(f"Task {task.id} execution error: {e}")
            self._fail_task(task.id, str(e))

            # Retry if possible
            if task.retry_count < task.max_retries:
                task.retry_count += 1
                self.task_queue.put((-task.priority.value, task.id, task))

        finally:
            # Mark device available
            device.current_task_id = None
            self.set_device_status(device.device_id, DeviceStatus.ONLINE)

    def _execute_screenshot(self, task: MobileTask, device: Device) -> Dict:
        """Execute screenshot task"""
        # Open URL
        if not self.adb.open_url(device.device_id, task.url):
            return {'success': False, 'error': 'Failed to open URL'}

        # Wait for page load
        time.sleep(3)

        # Take screenshot
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        url_hash = hashlib.md5(task.url.encode()).hexdigest()[:8]
        filename = f"mobile_{timestamp}_{url_hash}.png"
        filepath = self.screenshot_dir / filename

        if not self.adb.take_screenshot(device.device_id, str(filepath)):
            return {'success': False, 'error': 'Failed to take screenshot'}

        return {
            'success': True,
            'screenshot_path': str(filepath),
            'url': task.url,
            'device': device.device_id
        }

    def _execute_browse(self, task: MobileTask, device: Device) -> Dict:
        """Execute browse task with actions"""
        # Open URL
        if not self.adb.open_url(device.device_id, task.url):
            return {'success': False, 'error': 'Failed to open URL'}

        time.sleep(2)

        # Execute actions
        for action in task.actions:
            action_type = action.get('type')

            if action_type == 'wait':
                time.sleep(action.get('seconds', 1))

            elif action_type == 'tap':
                self.adb.tap(device.device_id, action.get('x', 0), action.get('y', 0))

            elif action_type == 'swipe':
                self.adb.swipe(
                    device.device_id,
                    action.get('x1', 0), action.get('y1', 0),
                    action.get('x2', 0), action.get('y2', 0),
                    action.get('duration', 300)
                )

            elif action_type == 'input':
                self.adb.input_text(device.device_id, action.get('text', ''))

            elif action_type == 'key':
                self.adb.press_key(device.device_id, action.get('keycode', 0))

            elif action_type == 'screenshot':
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = f"action_{timestamp}.png"
                filepath = self.screenshot_dir / filename
                self.adb.take_screenshot(device.device_id, str(filepath))

        return {'success': True, 'url': task.url, 'actions_completed': len(task.actions)}

    def _execute_interact(self, task: MobileTask, device: Device) -> Dict:
        """Execute interaction task"""
        results = []

        for action in task.actions:
            action_type = action.get('type')
            success = False

            if action_type == 'tap':
                success = self.adb.tap(device.device_id, action.get('x'), action.get('y'))
            elif action_type == 'swipe':
                success = self.adb.swipe(
                    device.device_id,
                    action.get('x1'), action.get('y1'),
                    action.get('x2'), action.get('y2')
                )
            elif action_type == 'input':
                success = self.adb.input_text(device.device_id, action.get('text', ''))

            results.append({'action': action_type, 'success': success})

            if action.get('wait_after'):
                time.sleep(action.get('wait_after'))

        return {'success': all(r['success'] for r in results), 'results': results}

    def _execute_app_automate(self, task: MobileTask, device: Device) -> Dict:
        """Execute app automation task"""
        # Launch app
        if not self.adb.launch_app(device.device_id, task.app_package):
            return {'success': False, 'error': 'Failed to launch app'}

        time.sleep(3)

        # Execute actions
        result = self._execute_interact(task, device)

        # Close app
        self.adb.close_app(device.device_id, task.app_package)

        return result

    def _execute_search(self, task: MobileTask, device: Device) -> Dict:
        """Execute search task on platform"""
        # Get platform from URL or app
        platform = None
        for name, package in self.PLATFORM_APPS.items():
            if package == task.app_package or name in task.url.lower():
                platform = name
                break

        if not platform:
            return {'success': False, 'error': 'Unknown platform'}

        # Open URL or app
        if task.url:
            self.adb.open_url(device.device_id, task.url)
        elif task.app_package:
            self.adb.launch_app(device.device_id, task.app_package)

        time.sleep(3)

        # Execute search actions
        result = self._execute_interact(task, device)

        # Take screenshot of results
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"search_{platform}_{timestamp}.png"
        filepath = self.screenshot_dir / filename
        self.adb.take_screenshot(device.device_id, str(filepath))

        result['screenshot'] = str(filepath)
        return result

    # ========================================================================
    # TASK STATUS UPDATES
    # ========================================================================

    def _update_task_status(self, task_id: int, status: str, device_id: str = None):
        """Update task status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        if status == 'running':
            cursor.execute("""
                UPDATE mobile_tasks SET status = ?, device_id = ?, started_at = datetime('now')
                WHERE id = ?
            """, (status, device_id, task_id))
        else:
            cursor.execute("""
                UPDATE mobile_tasks SET status = ? WHERE id = ?
            """, (status, task_id))

        conn.commit()
        conn.close()

    def _complete_task(self, task_id: int, result: Dict, duration: float, device_id: str):
        """Mark task as completed"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE mobile_tasks SET status = 'completed', result_json = ?, completed_at = datetime('now')
            WHERE id = ?
        """, (json.dumps(result), task_id))

        # Record history
        cursor.execute("""
            INSERT INTO task_history (task_id, device_id, task_type, success, duration_seconds)
            SELECT id, device_id, task_type, ?, ? FROM mobile_tasks WHERE id = ?
        """, (1 if result.get('success') else 0, duration, task_id))

        conn.commit()
        conn.close()

    def _fail_task(self, task_id: int, error: str):
        """Mark task as failed"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE mobile_tasks SET status = 'failed', error = ?, completed_at = datetime('now')
            WHERE id = ?
        """, (error, task_id))

        conn.commit()
        conn.close()

    # ========================================================================
    # STATISTICS
    # ========================================================================

    def get_statistics(self) -> Dict:
        """Get farm statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Device stats
        cursor.execute("SELECT status, COUNT(*) FROM devices GROUP BY status")
        device_stats = dict(cursor.fetchall())

        # Task stats
        cursor.execute("SELECT status, COUNT(*) FROM mobile_tasks GROUP BY status")
        task_stats = dict(cursor.fetchall())

        # Success rate
        cursor.execute("""
            SELECT AVG(success) FROM task_history WHERE created_at > datetime('now', '-24 hours')
        """)
        success_rate_24h = cursor.fetchone()[0] or 0

        # Average duration
        cursor.execute("""
            SELECT AVG(duration_seconds) FROM task_history WHERE success = 1
        """)
        avg_duration = cursor.fetchone()[0] or 0

        conn.close()

        return {
            'devices': device_stats,
            'tasks': task_stats,
            'success_rate_24h': round(success_rate_24h * 100, 1),
            'avg_task_duration': round(avg_duration, 2),
            'queue_size': self.task_queue.qsize(),
            'is_running': self._running
        }

    # ========================================================================
    # CALLBACKS
    # ========================================================================

    def on_task_complete(self, callback: Callable[[int, Dict], None]):
        """Register callback for task completion"""
        self._on_task_complete_callbacks.append(callback)

    def on_device_status_change(self, callback: Callable[[str, DeviceStatus, DeviceStatus], None]):
        """Register callback for device status change"""
        self._on_device_status_change_callbacks.append(callback)


# ============================================================================
# GLOBAL INSTANCE
# ============================================================================

_farm_instance = None


def get_mobile_farm() -> MobileFarmManager:
    """Get global mobile farm instance"""
    global _farm_instance
    if _farm_instance is None:
        _farm_instance = MobileFarmManager()
    return _farm_instance


# ============================================================================
# CLI TEST
# ============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("MOBILE FARM MANAGER - Test")
    print("=" * 60)

    farm = get_mobile_farm()

    # Discover devices
    print("\nDiscovering devices...")
    devices = farm.discover_devices()
    print(f"Found {len(devices)} device(s)")

    for device in devices:
        print(f"\n  Device: {device.device_id}")
        print(f"  Model: {device.model}")
        print(f"  Android: {device.android_version}")
        print(f"  Battery: {device.battery_level}%")
        print(f"  Screen: {device.screen_size}")

    # Get statistics
    print("\nStatistics:")
    stats = farm.get_statistics()
    print(f"  Devices: {stats['devices']}")
    print(f"  Tasks: {stats['tasks']}")
    print(f"  Success rate (24h): {stats['success_rate_24h']}%")

    print("\n" + "=" * 60)
    print("Usage:")
    print("  farm = get_mobile_farm()")
    print("  farm.discover_devices()")
    print("  task_id = farm.queue_screenshot('https://vinted.de/items/123')")
    print("  farm.start()")
    print("=" * 60)
