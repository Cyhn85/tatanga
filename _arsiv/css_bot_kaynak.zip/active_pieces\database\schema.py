#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Database Schema
Centralized database schema for all components

Tables:
- products: Scraped products
- favorites: Favorited products
- sales: Sales transactions
- purchases: Purchase transactions
- messages: Platform messages
- reviews: Product reviews
- shipments: Shipping records
- invoices: Invoice archives
- accounts: Platform accounts
- sessions: Login sessions
- agent_state: Agent status tracking
- error_log: Error tracking for self-healing
- selectors: Adaptive selector storage
- condition_mapping: Multi-language condition normalization
- arbitrage_configs: Arbitrage search configurations
- filtering_rules: Auto-approve/reject rules
- product_scores: Normalized scores and risk analysis
- benchmarks: Reference prices from sold products

Author: TATANGA Team
Version: 2.0
"""

import sqlite3
from pathlib import Path
from datetime import datetime
import json


class DatabaseSchema:
    """
    Database schema manager for TATANGA Enterprise

    Creates and maintains all database tables with proper
    relationships and indexes.
    """

    def __init__(self, db_path: str = None):
        """
        Initialize database schema

        Args:
            db_path: Path to SQLite database
        """
        if db_path is None:
            db_path = Path(__file__).parent.parent / 'storage' / 'tatanga.db'

        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

    def initialize_all(self):
        """Initialize all database tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Enable foreign keys
        cursor.execute("PRAGMA foreign_keys = ON")

        # Create all tables
        self._create_products_table(cursor)
        self._create_favorites_table(cursor)
        self._create_sales_table(cursor)
        self._create_purchases_table(cursor)
        self._create_messages_table(cursor)
        self._create_reviews_table(cursor)
        self._create_shipments_table(cursor)
        self._create_invoices_table(cursor)
        self._create_accounts_table(cursor)
        self._create_sessions_table(cursor)
        self._create_agent_state_table(cursor)
        self._create_error_log_table(cursor)
        self._create_selectors_table(cursor)
        self._create_scrape_history_table(cursor)
        self._create_operations_table(cursor)
        self._create_condition_mapping_table(cursor)
        self._create_arbitrage_configs_table(cursor)
        self._create_filtering_rules_table(cursor)
        self._create_product_scores_table(cursor)
        self._create_benchmarks_table(cursor)

        # TATANGA v3 tables
        self._create_scheduled_tasks_table(cursor)
        self._create_task_runs_table(cursor)
        self._create_categories_table(cursor)
        self._create_brands_table(cursor)
        self._create_platform_mappings_table(cursor)

        # Create indexes
        self._create_indexes(cursor)

        conn.commit()
        conn.close()

        print(f"Database initialized at: {self.db_path}")

    def _create_products_table(self, cursor):
        """Products table - scraped products"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                external_id TEXT,
                platform TEXT NOT NULL,
                country TEXT,
                url TEXT NOT NULL,
                title TEXT,
                description TEXT,
                price REAL,
                original_price REAL,
                currency TEXT DEFAULT 'EUR',
                condition TEXT,
                condition_normalized TEXT,
                brand TEXT,
                category TEXT,
                size TEXT,
                color TEXT,
                material TEXT,
                seller_id TEXT,
                seller_name TEXT,
                seller_rating REAL,
                location TEXT,
                images TEXT,
                image_hash TEXT,
                is_available BOOLEAN DEFAULT 1,
                is_sold BOOLEAN DEFAULT 0,
                is_duplicate BOOLEAN DEFAULT 0,
                duplicate_of INTEGER,
                language TEXT,
                scraped_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_checked DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME,
                metadata TEXT,

                -- Hibrit Triaj Sistemi için yeni alanlar
                batch_id TEXT,
                product_type TEXT DEFAULT 'standard',  -- 'standard', 'vintage', 'conflicting'
                estimated_shipping_days INTEGER,
                shipping_origin_country TEXT,
                profit_percentage REAL,
                is_in_inbox BOOLEAN DEFAULT 1,  -- Gelen kutusunda mı?
                inbox_added_at DATETIME DEFAULT CURRENT_TIMESTAMP,

                UNIQUE(platform, external_id)
            )
        """)

    def _create_favorites_table(self, cursor):
        """Favorites table - user favorited products"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS favorites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                user_id TEXT DEFAULT 'default',
                notes TEXT,
                priority INTEGER DEFAULT 0,
                target_price REAL,
                notify_on_price_drop BOOLEAN DEFAULT 0,
                notify_on_sold BOOLEAN DEFAULT 1,
                is_available BOOLEAN DEFAULT 1,
                is_sold BOOLEAN DEFAULT 0,
                last_checked DATETIME,
                added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
                UNIQUE(product_id, user_id)
            )
        """)

    def _create_sales_table(self, cursor):
        """Sales table - sold items"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER,
                platform TEXT NOT NULL,
                order_id TEXT,
                buyer_id TEXT,
                buyer_name TEXT,
                sale_price REAL NOT NULL,
                original_price REAL,
                shipping_cost REAL DEFAULT 0,
                platform_fee REAL DEFAULT 0,
                tax REAL DEFAULT 0,
                net_profit REAL,
                currency TEXT DEFAULT 'EUR',
                payment_method TEXT,
                payment_status TEXT DEFAULT 'pending',
                tracking_number TEXT,
                shipped_at DATETIME,
                delivered_at DATETIME,
                sale_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'completed',
                notes TEXT,
                metadata TEXT,
                FOREIGN KEY (product_id) REFERENCES products(id)
            )
        """)

    def _create_purchases_table(self, cursor):
        """Purchases table - bought items"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS purchases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                order_id TEXT,
                seller_id TEXT,
                seller_name TEXT,
                product_url TEXT,
                product_title TEXT,
                purchase_price REAL NOT NULL,
                shipping_cost REAL DEFAULT 0,
                total_cost REAL,
                currency TEXT DEFAULT 'EUR',
                payment_method TEXT,
                payment_status TEXT DEFAULT 'completed',
                tracking_number TEXT,
                expected_delivery DATE,
                received_at DATETIME,
                purchase_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'pending',
                condition_received TEXT,
                notes TEXT,
                metadata TEXT
            )
        """)

    def _create_messages_table(self, cursor):
        """Messages table - platform messaging"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                conversation_id TEXT,
                message_id TEXT,
                sender_id TEXT,
                sender_name TEXT,
                receiver_id TEXT,
                direction TEXT NOT NULL,
                content TEXT NOT NULL,
                content_translated TEXT,
                language TEXT,
                product_id INTEGER,
                is_read BOOLEAN DEFAULT 0,
                is_urgent BOOLEAN DEFAULT 0,
                is_replied BOOLEAN DEFAULT 0,
                replied_at DATETIME,
                reply_content TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(id)
            )
        """)

    def _create_reviews_table(self, cursor):
        """Reviews table - product/seller reviews"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                review_id TEXT,
                product_id INTEGER,
                sale_id INTEGER,
                reviewer_id TEXT,
                reviewer_name TEXT,
                rating INTEGER,
                content TEXT,
                content_translated TEXT,
                language TEXT,
                review_type TEXT,
                our_response TEXT,
                responded_at DATETIME,
                is_positive BOOLEAN,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(id),
                FOREIGN KEY (sale_id) REFERENCES sales(id)
            )
        """)

    def _create_shipments_table(self, cursor):
        """Shipments table - shipping records"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS shipments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sale_id INTEGER,
                purchase_id INTEGER,
                order_id TEXT,
                carrier TEXT NOT NULL,
                tracking_number TEXT,
                sender_name TEXT,
                sender_address TEXT,
                sender_city TEXT,
                sender_postal TEXT,
                sender_country TEXT,
                recipient_name TEXT,
                recipient_address TEXT,
                recipient_city TEXT,
                recipient_postal TEXT,
                recipient_country TEXT,
                weight_grams INTEGER,
                dimensions TEXT,
                shipping_cost REAL,
                currency TEXT DEFAULT 'EUR',
                label_url TEXT,
                label_created_at DATETIME,
                status TEXT DEFAULT 'created',
                estimated_delivery DATE,
                actual_delivery DATETIME,
                last_tracking_update DATETIME,
                tracking_history TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME,
                FOREIGN KEY (sale_id) REFERENCES sales(id),
                FOREIGN KEY (purchase_id) REFERENCES purchases(id)
            )
        """)

    def _create_invoices_table(self, cursor):
        """Invoices table - invoice archives"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS invoices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                order_id TEXT,
                sale_id INTEGER,
                purchase_id INTEGER,
                invoice_number TEXT,
                invoice_type TEXT,
                amount REAL,
                tax_amount REAL,
                currency TEXT DEFAULT 'EUR',
                file_path TEXT,
                file_hash TEXT,
                downloaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                invoice_date DATE,
                FOREIGN KEY (sale_id) REFERENCES sales(id),
                FOREIGN KEY (purchase_id) REFERENCES purchases(id),
                UNIQUE(platform, invoice_number)
            )
        """)

    def _create_accounts_table(self, cursor):
        """Accounts table - platform accounts"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                country TEXT,
                username TEXT NOT NULL,
                email TEXT,
                password_encrypted TEXT,
                is_active BOOLEAN DEFAULT 1,
                is_verified BOOLEAN DEFAULT 0,
                seller_rating REAL,
                total_sales INTEGER DEFAULT 0,
                total_reviews INTEGER DEFAULT 0,
                profile_url TEXT,
                last_login DATETIME,
                login_failures INTEGER DEFAULT 0,
                status TEXT DEFAULT 'active',
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME,
                metadata TEXT,
                UNIQUE(platform, username)
            )
        """)

    def _create_sessions_table(self, cursor):
        """Sessions table - login sessions"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id INTEGER NOT NULL,
                platform TEXT NOT NULL,
                session_data TEXT,
                cookies TEXT,
                user_agent TEXT,
                proxy TEXT,
                is_valid BOOLEAN DEFAULT 1,
                expires_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_used DATETIME,
                FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
            )
        """)

    def _create_agent_state_table(self, cursor):
        """Agent state table - agent status tracking"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_state (
                agent_name TEXT PRIMARY KEY,
                agent_type TEXT,
                status TEXT NOT NULL,
                last_run DATETIME,
                next_run DATETIME,
                run_count INTEGER DEFAULT 0,
                success_count INTEGER DEFAULT 0,
                error_count INTEGER DEFAULT 0,
                last_error TEXT,
                last_error_at DATETIME,
                config TEXT,
                metrics TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

    def _create_error_log_table(self, cursor):
        """Error log table - for self-healing system"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS error_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_name TEXT,
                platform TEXT,
                error_type TEXT NOT NULL,
                error_message TEXT NOT NULL,
                stack_trace TEXT,
                url TEXT,
                selector TEXT,
                context TEXT,
                is_resolved BOOLEAN DEFAULT 0,
                resolution TEXT,
                resolved_at DATETIME,
                auto_healed BOOLEAN DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

    def _create_selectors_table(self, cursor):
        """Selectors table - adaptive selector storage"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS selectors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                page_type TEXT NOT NULL,
                element_type TEXT NOT NULL,
                selector TEXT NOT NULL,
                selector_type TEXT DEFAULT 'css',
                priority INTEGER DEFAULT 0,
                success_count INTEGER DEFAULT 0,
                failure_count INTEGER DEFAULT 0,
                success_rate REAL DEFAULT 100.0,
                last_success DATETIME,
                last_failure DATETIME,
                is_active BOOLEAN DEFAULT 1,
                is_learned BOOLEAN DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME,
                UNIQUE(platform, page_type, element_type, selector)
            )
        """)

    def _create_scrape_history_table(self, cursor):
        """Scrape history table - scraping operation logs"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS scrape_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                query TEXT,
                filters TEXT,
                products_found INTEGER DEFAULT 0,
                products_new INTEGER DEFAULT 0,
                products_duplicate INTEGER DEFAULT 0,
                duration_seconds REAL,
                method TEXT,
                success BOOLEAN DEFAULT 1,
                error TEXT,
                started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                completed_at DATETIME
            )
        """)

    def _create_operations_table(self, cursor):
        """Operations table - operation queue"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS operations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                operation_id TEXT NOT NULL,
                operation_type TEXT NOT NULL,
                platform TEXT,
                parameters TEXT,
                priority INTEGER DEFAULT 3,
                status TEXT DEFAULT 'pending',
                result TEXT,
                error TEXT,
                retry_count INTEGER DEFAULT 0,
                max_retries INTEGER DEFAULT 3,
                scheduled_at DATETIME,
                started_at DATETIME,
                completed_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(operation_id)
            )
        """)

    def _create_condition_mapping_table(self, cursor):
        """Condition mapping table - multi-language condition normalization"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS condition_mapping (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                language TEXT NOT NULL,
                platform TEXT NOT NULL,
                raw_term TEXT NOT NULL,
                normalized_score INTEGER NOT NULL,
                confidence REAL DEFAULT 1.0,
                usage_count INTEGER DEFAULT 0,
                last_used DATETIME,
                learned_from TEXT,
                is_verified BOOLEAN DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME,
                UNIQUE(language, platform, raw_term)
            )
        """)

        # Pre-populate with common condition terms
        condition_data = [
            # German
            ('de', 'vinted', 'Neu mit Etikett', 5, 1.0),
            ('de', 'vinted', 'Neu ohne Etikett', 4, 1.0),
            ('de', 'vinted', 'Sehr gut', 4, 1.0),
            ('de', 'vinted', 'Gut', 3, 1.0),
            ('de', 'ebay', 'Neu', 5, 1.0),
            ('de', 'ebay', 'Neuwertig', 4, 1.0),
            ('de', 'ebay', 'Sehr gut', 4, 1.0),
            ('de', 'ebay', 'Gut', 3, 1.0),
            ('de', 'ebay', 'Akzeptabel', 2, 1.0),
            ('de', 'kleinanzeigen', 'Neu', 5, 1.0),
            ('de', 'kleinanzeigen', 'Neuwertig', 4, 1.0),
            ('de', 'kleinanzeigen', 'Gebraucht', 2, 1.0),

            # English
            ('en', 'vinted', 'New with tags', 5, 1.0),
            ('en', 'vinted', 'New without tags', 4, 1.0),
            ('en', 'vinted', 'Very good', 4, 1.0),
            ('en', 'vinted', 'Good', 3, 1.0),
            ('en', 'vinted', 'Satisfactory', 2, 1.0),
            ('en', 'ebay', 'New', 5, 1.0),
            ('en', 'ebay', 'New other', 4, 1.0),
            ('en', 'ebay', 'Excellent', 4, 1.0),
            ('en', 'ebay', 'Good', 3, 1.0),
            ('en', 'ebay', 'Acceptable', 2, 1.0),

            # French
            ('fr', 'vinted', 'Neuf avec étiquette', 5, 1.0),
            ('fr', 'vinted', 'Neuf sans étiquette', 4, 1.0),
            ('fr', 'vinted', 'Très bon état', 4, 1.0),
            ('fr', 'vinted', 'Bon état', 3, 1.0),
            ('fr', 'vinted', 'Satisfaisant', 2, 1.0),
            ('fr', 'leboncoin', 'Neuf', 5, 1.0),
            ('fr', 'leboncoin', 'Très bon état', 4, 1.0),
            ('fr', 'leboncoin', 'Bon état', 3, 1.0),
            ('fr', 'leboncoin', 'État satisfaisant', 2, 1.0),

            # Swedish
            ('sv', 'vinted', 'Ny med lapp', 5, 1.0),
            ('sv', 'vinted', 'Ny utan lapp', 4, 1.0),
            ('sv', 'vinted', 'Nyskick', 4, 1.0),
            ('sv', 'vinted', 'Bra skick', 3, 1.0),
            ('sv', 'tradera', 'Oanvänd', 5, 1.0),
            ('sv', 'tradera', 'Mycket bra skick', 4, 1.0),
            ('sv', 'tradera', 'Bra skick', 3, 1.0),

            # Norwegian
            ('no', 'vinted', 'Ny med lapp', 5, 1.0),
            ('no', 'vinted', 'Ny uten lapp', 4, 1.0),
            ('no', 'vinted', 'Veldig bra', 4, 1.0),
            ('no', 'vinted', 'Bra', 3, 1.0),
            ('no', 'finn', 'Ubrukt', 5, 1.0),
            ('no', 'finn', 'Pent brukt', 3, 1.0),

            # Italian
            ('it', 'vinted', 'Nuovo con etichetta', 5, 1.0),
            ('it', 'vinted', 'Nuovo senza etichetta', 4, 1.0),
            ('it', 'vinted', 'Ottime condizioni', 4, 1.0),
            ('it', 'vinted', 'Buone condizioni', 3, 1.0),

            # Spanish
            ('es', 'vinted', 'Nuevo con etiqueta', 5, 1.0),
            ('es', 'vinted', 'Nuevo sin etiqueta', 4, 1.0),
            ('es', 'vinted', 'Muy bueno', 4, 1.0),
            ('es', 'vinted', 'Bueno', 3, 1.0),

            # Dutch
            ('nl', 'vinted', 'Nieuw met label', 5, 1.0),
            ('nl', 'vinted', 'Nieuw zonder label', 4, 1.0),
            ('nl', 'vinted', 'Zeer goed', 4, 1.0),
            ('nl', 'vinted', 'Goed', 3, 1.0),

            # Polish
            ('pl', 'vinted', 'Nowy z metką', 5, 1.0),
            ('pl', 'vinted', 'Nowy bez metki', 4, 1.0),
            ('pl', 'vinted', 'Bardzo dobry', 4, 1.0),
            ('pl', 'vinted', 'Dobry', 3, 1.0),

            # Czech
            ('cs', 'vinted', 'Nové s visačkou', 5, 1.0),
            ('cs', 'vinted', 'Nové bez visačky', 4, 1.0),
            ('cs', 'vinted', 'Velmi dobrý', 4, 1.0),
            ('cs', 'vinted', 'Dobrý', 3, 1.0),

            # Danish
            ('da', 'vinted', 'Ny med mærke', 5, 1.0),
            ('da', 'vinted', 'Ny uden mærke', 4, 1.0),
            ('da', 'vinted', 'Meget god', 4, 1.0),
            ('da', 'vinted', 'God', 3, 1.0),

            # Finnish
            ('fi', 'vinted', 'Uusi lapulla', 5, 1.0),
            ('fi', 'vinted', 'Uusi ilman lappua', 4, 1.0),
            ('fi', 'vinted', 'Erittäin hyvä', 4, 1.0),
            ('fi', 'vinted', 'Hyvä', 3, 1.0),
        ]

        for lang, platform, term, score, conf in condition_data:
            try:
                cursor.execute("""
                    INSERT OR IGNORE INTO condition_mapping
                    (language, platform, raw_term, normalized_score, confidence, is_verified)
                    VALUES (?, ?, ?, ?, ?, 1)
                """, (lang, platform, term, score, conf))
            except:
                pass

    def _create_arbitrage_configs_table(self, cursor):
        """Arbitrage configs table - search configurations"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS arbitrage_configs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                query TEXT NOT NULL,
                platforms TEXT,
                min_condition_score INTEGER DEFAULT 3,
                max_condition_score INTEGER DEFAULT 5,
                benchmark_price REAL,
                min_profit_margin REAL DEFAULT 0.30,
                max_price REAL,
                min_price REAL,
                brands TEXT,
                categories TEXT,
                exclude_keywords TEXT,
                is_active BOOLEAN DEFAULT 1,
                last_run DATETIME,
                products_found INTEGER DEFAULT 0,
                products_approved INTEGER DEFAULT 0,
                created_by TEXT DEFAULT 'user',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME
            )
        """)

    def _create_filtering_rules_table(self, cursor):
        """Filtering rules table - auto-approve/reject rules"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS filtering_rules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                rule_type TEXT NOT NULL,
                condition_field TEXT NOT NULL,
                condition_operator TEXT NOT NULL,
                condition_value TEXT NOT NULL,
                action TEXT NOT NULL,
                priority INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT 1,
                hit_count INTEGER DEFAULT 0,
                last_hit DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME
            )
        """)

        # Pre-populate with default rules
        default_rules = [
            # Auto-reject rules
            ('Low Score Reject', 'auto_reject', 'normalized_score', '<', '2', 'reject', 100),
            ('Very Low Price Reject', 'auto_reject', 'price', '<', '5', 'reject', 90),
            ('Defect Keyword Reject', 'auto_reject', 'description', 'contains', 'defekt,kaputt,broken', 'reject', 80),

            # Auto-approve rules
            ('High Score + Margin', 'auto_approve', 'normalized_score', '>=', '4', 'approve', 50),
            ('Premium Brand', 'auto_approve', 'brand', 'in', 'Nike,Adidas,Levi\'s,The North Face', 'approve', 40),

            # Risky rules
            ('Conflict Detection', 'risky', 'is_conflicting', '=', 'true', 'review', 70),
            ('Low Margin', 'risky', 'profit_margin', '<', '0.25', 'review', 60),
        ]

        for name, rule_type, field, op, value, action, priority in default_rules:
            try:
                cursor.execute("""
                    INSERT OR IGNORE INTO filtering_rules
                    (name, rule_type, condition_field, condition_operator, condition_value, action, priority)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (name, rule_type, field, op, value, action, priority))
            except:
                pass

    def _create_product_scores_table(self, cursor):
        """Product scores table - normalized scores and risk analysis"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS product_scores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                normalized_score INTEGER,
                confidence REAL DEFAULT 1.0,
                is_conflicting BOOLEAN DEFAULT 0,
                conflict_reason TEXT,
                conflict_keywords TEXT,
                profit_amount REAL,
                profit_margin REAL,
                benchmark_price REAL,
                filter_decision TEXT,
                filter_reason TEXT,
                is_approved BOOLEAN DEFAULT 0,
                approved_by TEXT,
                approved_at DATETIME,
                is_rejected BOOLEAN DEFAULT 0,
                rejected_by TEXT,
                rejected_at DATETIME,
                arbitrage_config_id INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
                FOREIGN KEY (arbitrage_config_id) REFERENCES arbitrage_configs(id)
            )
        """)

    def _create_benchmarks_table(self, cursor):
        """Benchmarks table - reference prices from sold products"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS benchmarks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_name TEXT NOT NULL,
                brand TEXT,
                category TEXT,
                condition_score INTEGER,
                platform TEXT,
                avg_price REAL NOT NULL,
                min_price REAL,
                max_price REAL,
                sample_count INTEGER DEFAULT 0,
                currency TEXT DEFAULT 'EUR',
                last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(product_name, brand, condition_score, platform)
            )
        """)

    def _create_scheduled_tasks_table(self, cursor):
        """Scheduled scraping tasks for TATANGA v3"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS scheduled_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                brands TEXT NOT NULL,
                platforms TEXT NOT NULL,
                filters TEXT,
                schedule_type TEXT DEFAULT 'interval',
                schedule_value TEXT DEFAULT '4h',
                is_active BOOLEAN DEFAULT 1,
                last_run_at DATETIME,
                next_run_at DATETIME,
                total_runs INTEGER DEFAULT 0,
                total_products_found INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME
            )
        """)

    def _create_task_runs_table(self, cursor):
        """Task execution history"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                completed_at DATETIME,
                status TEXT DEFAULT 'running',
                products_found INTEGER DEFAULT 0,
                platforms_scraped TEXT,
                error_message TEXT,
                duration_seconds INTEGER,
                FOREIGN KEY (task_id) REFERENCES scheduled_tasks(id) ON DELETE CASCADE
            )
        """)

    def _create_categories_table(self, cursor):
        """Category tree for smart filtering"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE NOT NULL,
                label TEXT NOT NULL,
                parent_key TEXT,
                keywords TEXT,
                icon TEXT,
                sort_order INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

    def _create_brands_table(self, cursor):
        """Brand database with aliases"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS brands (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                aliases TEXT,
                category_affinity TEXT,
                price_tier TEXT DEFAULT 'mid',
                is_active BOOLEAN DEFAULT 1,
                search_count INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

    def _create_platform_mappings_table(self, cursor):
        """Platform-specific category mappings"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS platform_mappings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_key TEXT NOT NULL,
                platform TEXT NOT NULL,
                category_id TEXT,
                category_path TEXT,
                query_template TEXT,
                url_pattern TEXT,
                pagination_type TEXT DEFAULT 'scroll',
                is_active BOOLEAN DEFAULT 1,
                last_tested DATETIME,
                success_rate REAL DEFAULT 1.0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(category_key, platform)
            )
        """)

    def _create_indexes(self, cursor):
        """Create database indexes for performance"""
        indexes = [
            "CREATE INDEX IF NOT EXISTS idx_products_platform ON products(platform)",
            "CREATE INDEX IF NOT EXISTS idx_products_scraped_at ON products(scraped_at DESC)",
            "CREATE INDEX IF NOT EXISTS idx_products_is_available ON products(is_available)",
            "CREATE INDEX IF NOT EXISTS idx_products_url ON products(url)",
            "CREATE INDEX IF NOT EXISTS idx_products_batch ON products(batch_id)",
            "CREATE INDEX IF NOT EXISTS idx_products_inbox ON products(is_in_inbox)",
            "CREATE INDEX IF NOT EXISTS idx_products_type ON products(product_type)",

            "CREATE INDEX IF NOT EXISTS idx_favorites_product ON favorites(product_id)",
            "CREATE INDEX IF NOT EXISTS idx_favorites_user ON favorites(user_id)",

            "CREATE INDEX IF NOT EXISTS idx_sales_platform ON sales(platform)",
            "CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date DESC)",
            "CREATE INDEX IF NOT EXISTS idx_sales_status ON sales(status)",

            "CREATE INDEX IF NOT EXISTS idx_messages_platform ON messages(platform)",
            "CREATE INDEX IF NOT EXISTS idx_messages_direction ON messages(direction)",
            "CREATE INDEX IF NOT EXISTS idx_messages_is_read ON messages(is_read)",

            "CREATE INDEX IF NOT EXISTS idx_shipments_tracking ON shipments(tracking_number)",
            "CREATE INDEX IF NOT EXISTS idx_shipments_status ON shipments(status)",

            "CREATE INDEX IF NOT EXISTS idx_error_log_platform ON error_log(platform)",
            "CREATE INDEX IF NOT EXISTS idx_error_log_type ON error_log(error_type)",
            "CREATE INDEX IF NOT EXISTS idx_error_log_resolved ON error_log(is_resolved)",

            "CREATE INDEX IF NOT EXISTS idx_selectors_platform ON selectors(platform, page_type)",
            "CREATE INDEX IF NOT EXISTS idx_selectors_success ON selectors(success_rate DESC)",

            "CREATE INDEX IF NOT EXISTS idx_scrape_history_platform ON scrape_history(platform)",
            "CREATE INDEX IF NOT EXISTS idx_scrape_history_date ON scrape_history(started_at DESC)",

            "CREATE INDEX IF NOT EXISTS idx_operations_status ON operations(status)",
            "CREATE INDEX IF NOT EXISTS idx_operations_scheduled ON operations(scheduled_at)",

            # New tables indexes
            "CREATE INDEX IF NOT EXISTS idx_condition_mapping_lang ON condition_mapping(language, platform)",
            "CREATE INDEX IF NOT EXISTS idx_condition_mapping_term ON condition_mapping(raw_term)",
            "CREATE INDEX IF NOT EXISTS idx_arbitrage_active ON arbitrage_configs(is_active)",
            "CREATE INDEX IF NOT EXISTS idx_filtering_rules_type ON filtering_rules(rule_type)",
            "CREATE INDEX IF NOT EXISTS idx_filtering_rules_active ON filtering_rules(is_active)",
            "CREATE INDEX IF NOT EXISTS idx_product_scores_product ON product_scores(product_id)",
            "CREATE INDEX IF NOT EXISTS idx_product_scores_decision ON product_scores(filter_decision)",
            "CREATE INDEX IF NOT EXISTS idx_product_scores_approved ON product_scores(is_approved)",
            "CREATE INDEX IF NOT EXISTS idx_benchmarks_product ON benchmarks(product_name, brand)",
            "CREATE INDEX IF NOT EXISTS idx_benchmarks_condition ON benchmarks(condition_score)",

            # TATANGA v3 indexes
            "CREATE INDEX IF NOT EXISTS idx_scheduled_tasks_active ON scheduled_tasks(is_active)",
            "CREATE INDEX IF NOT EXISTS idx_scheduled_tasks_next_run ON scheduled_tasks(next_run_at)",
            "CREATE INDEX IF NOT EXISTS idx_scheduled_tasks_category ON scheduled_tasks(category)",
            "CREATE INDEX IF NOT EXISTS idx_task_runs_task ON task_runs(task_id)",
            "CREATE INDEX IF NOT EXISTS idx_task_runs_status ON task_runs(status)",
            "CREATE INDEX IF NOT EXISTS idx_task_runs_started ON task_runs(started_at DESC)",
            "CREATE INDEX IF NOT EXISTS idx_categories_parent ON categories(parent_key)",
            "CREATE INDEX IF NOT EXISTS idx_categories_active ON categories(is_active)",
            "CREATE INDEX IF NOT EXISTS idx_brands_active ON brands(is_active)",
            "CREATE INDEX IF NOT EXISTS idx_brands_tier ON brands(price_tier)",
            "CREATE INDEX IF NOT EXISTS idx_platform_mappings_category ON platform_mappings(category_key)",
            "CREATE INDEX IF NOT EXISTS idx_platform_mappings_platform ON platform_mappings(platform)",
        ]

        for idx in indexes:
            try:
                cursor.execute(idx)
            except Exception as e:
                print(f"Index creation warning: {e}")

    def get_table_stats(self) -> dict:
        """Get statistics for all tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        tables = [
            'products', 'favorites', 'sales', 'purchases', 'messages',
            'reviews', 'shipments', 'invoices', 'accounts', 'sessions',
            'agent_state', 'error_log', 'selectors', 'scrape_history', 'operations',
            'condition_mapping', 'arbitrage_configs', 'filtering_rules',
            'product_scores', 'benchmarks',
            # TATANGA v3 tables
            'scheduled_tasks', 'task_runs', 'categories', 'brands', 'platform_mappings'
        ]

        stats = {}
        for table in tables:
            try:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                stats[table] = cursor.fetchone()[0]
            except:
                stats[table] = 0

        conn.close()
        return stats


# ==================== TEST ====================

if __name__ == "__main__":
    print("=" * 60)
    print("DATABASE SCHEMA INITIALIZATION")
    print("=" * 60)

    schema = DatabaseSchema()
    schema.initialize_all()

    print("\nTable Statistics:")
    stats = schema.get_table_stats()
    for table, count in stats.items():
        print(f"  {table}: {count} rows")

    print("\n✅ Database schema initialized successfully!")
    print("=" * 60)
