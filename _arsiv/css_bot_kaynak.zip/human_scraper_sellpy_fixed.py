"""
TATANGA V3 - Sellpy Human Scraper - FIXED
Fiyat ve condition cikarma iyilestirildi
"""
from .human_scraper_base import HumanScraper, LOG_DIR
from selenium.webdriver.common.by import By
from datetime import datetime
from typing import List, Dict, Optional
import re


class SellpyScraper(HumanScraper):
    BASE_URL = "https://www.sellpy.de"

    METADATA_FIELDS = {
        "brand": "Marke", "type": "Art", "size": "Groesse",
        "color": "Farbe", "material": "Material", "condition": "Zustand",
    }

    def __init__(self, headless: bool = True):
        super().__init__("sellpy", headless)
        self.products_found = []
        self.visited_urls = set()

    def close_cookie_banner(self, selectors: list = None):
        sellpy_selectors = [
            "//button[contains(text(), 'Alle Cookies akzeptieren')]",
            "//button[contains(text(), 'Alle akzeptieren')]",
            "#onetrust-accept-btn-handler",
            "button[id*='accept']",
        ]
        return super().close_cookie_banner(sellpy_selectors + (selectors or []))

    def close_size_popup(self):
        popup_selectors = [
            "//button[contains(@class, 'close')]",
            "button[aria-label='Close']",
            ".modal-close",
        ]
        for selector in popup_selectors:
            try:
                if selector.startswith('//'):
                    btn = self.driver.find_element(By.XPATH, selector)
                else:
                    btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                if btn.is_displayed():
                    self.human_click(btn)
                    self.random_delay(0.5, 1)
                    return True
            except:
                pass
        return False

    def build_search_url(self, query: str, page: int = 1,
                         min_price: float = None, max_price: float = None,
                         category: str = None, condition: str = None) -> str:
        import urllib.parse
        params = {"q": query}
        if page > 1:
            params["page"] = page
        if min_price is not None:
            params["minPrice"] = int(min_price)
        if max_price is not None:
            params["maxPrice"] = int(max_price)
        query_string = urllib.parse.urlencode(params)
        return f"{self.BASE_URL}/search?{query_string}"

    def get_product_elements(self) -> list:
        selectors = [
            "[data-testid='product-card']",
            ".product-card",
            "article[class*='Product']",
            "a[href*='/item/']",
        ]
        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    self.log(f"{len(elements)} urun elementi bulundu ({selector})")
                    return elements
            except:
                pass
        return []

    def extract_price_from_text(self, text: str) -> Optional[float]:
        """Fiyat metninden sayisal degeri cikar - IMPROVED"""
        if not text:
            return None

        text = text.strip()

        # Pattern'lar - euro isareti once veya sonra olabilir
        patterns = [
            r'(\d+[.,]\d{2})\s*EUR',
            r'(\d+[.,]\d{2})\s*\u20ac',
            r'EUR\s*(\d+[.,]\d{2})',
            r'\u20ac\s*(\d+[.,]\d{2})',
            r'(\d+)\s*EUR',
            r'(\d+)\s*\u20ac',
            r'(\d+[.,]\d{2})',
            r'(\d+)',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                price_str = match.group(1)
                price_str = price_str.replace(',', '.')
                try:
                    return float(price_str)
                except:
                    pass

        self.log(f"UYARI: Fiyat cikarilmadi: '{text}'", "warning")
        return None

    def extract_product_data(self, element) -> Optional[Dict]:
        """Urun elementinden veri cikar - IMPROVED"""
        try:
            # URL
            url = None
            try:
                link = element.find_element(By.CSS_SELECTOR, "a[href*='/item/']")
                url = link.get_attribute("href")
            except:
                try:
                    url = element.get_attribute("href")
                except:
                    pass

            if not url:
                return None

            # Product ID
            product_id = None
            match = re.search(r'/item/([a-zA-Z0-9-]+)', url)
            if match:
                product_id = match.group(1)

            if not product_id:
                return None

            # Title
            title = ""
            title_selectors = ["h3", "h2", ".item-title", "[class*='title']", "[class*='Title']", "img[alt]"]
            for sel in title_selectors:
                try:
                    title_el = element.find_element(By.CSS_SELECTOR, sel)
                    if sel == "img[alt]":
                        title = title_el.get_attribute("alt") or ""
                    else:
                        title = title_el.text.strip()
                    if title and len(title) > 3:
                        break
                except:
                    pass

            # Price - IMPROVED with multiple selectors
            price = None
            price_selectors = [
                "[data-testid='product-price']",
                "[data-testid='price']",
                "[class*='Price']",
                "[class*='price']",
                ".product-price",
                ".item-price",
                "span[class*='price']",
                "div[class*='price']",
                "p[class*='price']",
            ]

            for sel in price_selectors:
                try:
                    price_els = element.find_elements(By.CSS_SELECTOR, sel)
                    for price_el in price_els:
                        price_text = price_el.text.strip()
                        if price_text:
                            extracted = self.extract_price_from_text(price_text)
                            if extracted and extracted > 0:
                                price = extracted
                                self.log(f"Fiyat bulundu ({sel}): {price} EUR", "debug")
                                break
                    if price:
                        break
                except:
                    pass

            # Fallback: tum element text'inden fiyat ara
            if price is None:
                try:
                    full_text = element.text
                    price = self.extract_price_from_text(full_text)
                    if price:
                        self.log(f"Fiyat full text'ten bulundu: {price} EUR", "debug")
                except:
                    pass

            # Image
            image_url = None
            try:
                img = element.find_element(By.CSS_SELECTOR, "img")
                image_url = img.get_attribute("src") or img.get_attribute("data-src")
            except:
                pass

            # Brand
            brand = None
            if title:
                known_brands = ["Nike", "Adidas", "Puma", "Tommy Hilfiger", "H&M", "Zara",
                               "Calvin Klein", "Ralph Lauren", "Levis", "Guess", "Hugo Boss",
                               "Gant", "Lacoste", "Polo", "Jack & Jones", "Only", "Vero Moda"]
                for b in known_brands:
                    if b.lower() in title.lower():
                        brand = b
                        break

            # Condition
            condition = None
            condition_selectors = ["[class*='condition']", "[class*='Condition']", "[class*='zustand']"]
            for sel in condition_selectors:
                try:
                    cond_el = element.find_element(By.CSS_SELECTOR, sel)
                    condition = cond_el.text.strip()
                    if condition:
                        break
                except:
                    pass

            return {
                "product_id": product_id,
                "url": url,
                "title": title,
                "price": price,
                "brand": brand,
                "image": image_url,
                "condition": condition,
                "platform": "sellpy",
                "is_auction": False,
                "scraped_at": datetime.now().isoformat()
            }

        except Exception as e:
            self.log(f"Urun verisi cikarma hatasi: {e}", "debug")
            return None

    def extract_all_products(self) -> List[Dict]:
        elements = self.get_product_elements()
        products = []
        for element in elements:
            product = self.extract_product_data(element)
            if product and product["url"] not in [p["url"] for p in self.products_found]:
                products.append(product)
                self.products_found.append(product)
        self.log(f"{len(products)} yeni urun cikarildi (Toplam: {len(self.products_found)})")
        return products

    def load_more_products(self) -> bool:
        initial_count = len(self.get_product_elements())
        for _ in range(3):
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            self.random_delay(1.5, 2.5)
            self.close_size_popup()
            new_count = len(self.get_product_elements())
            if new_count > initial_count:
                return True
        return False

    def scrape_page(self, url: str) -> List[Dict]:
        self.log(f"Sayfa aciliyor: {url}")
        self.visit_url(url)
        self.close_cookie_banner()
        self.close_size_popup()
        self.random_delay(2, 3)
        return self.extract_all_products()

    def scrape(self, query: str, max_products: int = None, max_pages: int = 10,
               min_price: float = None, max_price: float = None,
               category: str = None, condition: str = None,
               conditions: list = None, **kwargs) -> List[Dict]:
        self.log("=== SELLPY KAZIMA BASLIYOR ===")
        self.log(f"Arama: {query}, Fiyat: {min_price}-{max_price} EUR")

        try:
            for page in range(1, max_pages + 1):
                url = self.build_search_url(query=query, page=page,
                    min_price=min_price, max_price=max_price)

                self.log(f"Sayfa {page}/{max_pages}")
                before_count = len(self.products_found)
                self.scrape_page(url)
                after_count = len(self.products_found)
                new_products = after_count - before_count
                self.log(f"+{new_products} yeni urun (Toplam: {after_count})")

                if max_products and len(self.products_found) >= max_products:
                    self.log(f"Max urun sayisina ulasildi: {max_products}")
                    break
                if new_products == 0:
                    self.log("Bos sayfa, durduruluyor...")
                    break
                self.random_delay(2, 4)

            self.log(f"=== SELLPY TAMAMLANDI: {len(self.products_found)} urun ===")
            return self.products_found

        except Exception as e:
            self.log(f"Kazima hatasi: {e}", "error")
            self.screenshot("error")
            raise


def run_sellpy_scrape(query: str, max_products: int = None, headless: bool = True) -> List[Dict]:
    with SellpyScraper(headless=headless) as scraper:
        return scraper.scrape(query, max_products=max_products)


if __name__ == "__main__":
    import sys
    query = sys.argv[1] if len(sys.argv) > 1 else "pullover"
    max_items = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    products = run_sellpy_scrape(query, max_products=max_items, headless=True)
    print(f"{len(products)} urun bulundu")
    for p in products[:5]:
        print(f"  - {p['title'][:40]} | {p['price']} EUR")
