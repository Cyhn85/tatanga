@echo off
chcp 65001 >nul
title TATANGA - Launcher
color 0A

:MENU
cls
echo ╔══════════════════════════════════════════════════════════════╗
echo ║           TATANGA - E-Commerce Automation Platform           ║
echo ╠══════════════════════════════════════════════════════════════╣
echo ║                                                              ║
echo ║   [1] DIS LOGISTIK (Kazima)       - Scrape from platforms    ║
echo ║   [2] IC LOGISTIK                 - Internal transfers       ║
echo ║   [3] Store Manager               - Manage stores            ║
echo ║   [4] Multi-Store Publisher       - Publish to stores        ║
echo ║                                                              ║
echo ╠══════════════════════════════════════════════════════════════╣
echo ║                                                              ║
echo ║   [5] Webhook API Server          - Active Pieces API        ║
echo ║   [6] Telegram Bot                - Start bot server         ║
echo ║   [7] Test Telegram               - Test bot config          ║
echo ║                                                              ║
echo ╠══════════════════════════════════════════════════════════════╣
echo ║                                                              ║
echo ║   [8] Vinted Connector Test       - Test 13 countries        ║
echo ║   [9] Webhook API Test            - Test endpoints           ║
echo ║                                                              ║
echo ╠══════════════════════════════════════════════════════════════╣
echo ║   [0] Exit                                                   ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.
set /p choice="Select option: "

if "%choice%"=="1" goto DIS
if "%choice%"=="2" goto IC
if "%choice%"=="3" goto STORE
if "%choice%"=="4" goto MULTI
if "%choice%"=="5" goto WEBHOOK
if "%choice%"=="6" goto TELEGRAM
if "%choice%"=="7" goto TESTTEL
if "%choice%"=="8" goto TESTVINTED
if "%choice%"=="9" goto TESTWEBHOOK
if "%choice%"=="0" goto EXIT
goto MENU

:DIS
echo Starting DIS LOGISTIK...
cd /d "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python dis_logistik_gui.py
goto MENU

:IC
echo Starting IC LOGISTIK...
cd /d "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python ic_logistik_gui.py
goto MENU

:STORE
echo Starting Store Manager...
cd /d "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python store_manager_gui.py
goto MENU

:MULTI
echo Starting Multi-Store Publisher...
cd /d "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python multi_store_publisher_gui.py
goto MENU

:WEBHOOK
echo Starting Webhook API Server...
cd /d "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python integrations/activepieces_webhook.py
goto MENU

:TELEGRAM
echo Starting Telegram Bot...
cd /d "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python integrations/telegram_bot.py
goto MENU

:TESTTEL
echo Testing Telegram Configuration...
cd /d "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python test_telegram_bot.py
pause
goto MENU

:TESTVINTED
echo Testing Vinted Connector...
cd /d "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python test_vinted_connector.py
pause
goto MENU

:TESTWEBHOOK
echo Testing Webhook API...
cd /d "c:\Users\cyhnsrgc\Desktop\CSS BOT\active_pieces"
python test_webhook.py
pause
goto MENU

:EXIT
echo Goodbye!
exit
