"""
TATANGA V3 - Scraping API with Celery Integration
"""
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from database import get_db
from models import ScrapeJob, Product
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from celery.result import AsyncResult
import random

router = APIRouter()


def generate_job_id():
    date_str = datetime.now().strftime("%Y%m%d")
    seq = str(random.randint(1, 9999)).zfill(4)
    return f"JOB-{date_str}-{seq}"


def generate_scr_id():
    date_str = datetime.now().strftime("%Y%m%d")
    seq = str(random.randint(1, 9999)).zfill(4)
    return f"SCR-{date_str}-{seq}"


class ScrapeRequest(BaseModel):
    platform: str
    search_term: str
    category: Optional[str] = None
    min_price: Optional[float] = None
    max_price: Optional[float] = None
    page_count: int = 3
    max_items: int = 50


@router.get("/platforms")
async def get_platforms():
    return {
        "platforms": [
            {"id": "vinted", "name": "Vinted DE", "status": "active"},
            {"id": "ebay", "name": "eBay DE", "status": "active"},
            {"id": "kleinanzeigen", "name": "Kleinanzeigen", "status": "active"},
            {"id": "willhaben", "name": "Willhaben AT", "status": "planned"}
        ]
    }


@router.get("/jobs")
async def get_scrape_jobs(
    status: Optional[str] = None,
    limit: int = 20,
    db: AsyncSession = Depends(get_db)
):
    query = select(ScrapeJob).order_by(desc(ScrapeJob.created_at)).limit(limit)
    if status:
        query = query.where(ScrapeJob.status == status)
    result = await db.execute(query)
    return result.scalars().all()


@router.post("/start")
async def start_scrape(request: ScrapeRequest, db: AsyncSession = Depends(get_db)):
    """Start a new scrape job using Celery"""
    from celery_worker import scrape_task

    job_id = generate_job_id()

    # Create job record
    job = ScrapeJob(
        job_id=job_id,
        platform=request.platform,
        search_term=request.search_term,
        category=request.category,
        min_price=request.min_price,
        max_price=request.max_price,
        page_count=request.page_count,
        status="running",
        started_at=datetime.utcnow()
    )
    db.add(job)
    await db.commit()
    await db.refresh(job)

    # Submit Celery task
    task = scrape_task.delay(
        platform=request.platform,
        query=request.search_term,
        max_pages=request.page_count,
        max_items=request.max_items
    )

    return {
        "message": "Scrape job started",
        "job_id": job_id,
        "task_id": task.id,
        "status": "running"
    }


@router.get("/jobs/{job_id}")
async def get_job_status(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ScrapeJob).where(ScrapeJob.job_id == job_id))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.get("/task/{task_id}")
async def get_task_status(task_id: str):
    """Get Celery task status"""
    task = AsyncResult(task_id)
    return {
        "task_id": task_id,
        "status": task.status,
        "ready": task.ready(),
        "result": task.result if task.ready() else None
    }


@router.post("/test")
async def test_scrape(platform: str = "vinted", query: str = "nike"):
    """Quick test scrape (synchronous, limited)"""
    from services.scraper_service import run_scrape_task

    result = run_scrape_task(platform, query, max_pages=1, max_items=5)
    return result


@router.post("/save-results/{job_id}")
async def save_results(job_id: str, db: AsyncSession = Depends(get_db)):
    """Save scrape results to products table"""
    job_result = await db.execute(select(ScrapeJob).where(ScrapeJob.job_id == job_id))
    job = job_result.scalar_one_or_none()

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # TODO: Get results from task and save to products
    return {"message": "Results saved", "job_id": job_id}
