#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WILLHABEN CONFIG - Austria Configuration
Selectors, URL patterns, and condition mapping for Willhaben.at
"""

WILLHABEN_CONFIG = {
    'at': {
        'domain': 'willhaben.at',
        'base_url': 'https://www.willhaben.at',
        'search_url': 'https://www.willhaben.at/iad/kaufen-und-verkaufen/marktplatz',
        'language': 'de',
        'currency': 'EUR',

        # Search result selectors (multiple fallbacks)
        'item_selectors': [
            'a[data-testid="ad-list-item"]',
            '[data-testid="search-result-item"]',
            'article[class*="ListItem"]',
            '.search-result-entry',
            'a[href*="/iad/kaufen-und-verkaufen/d/"]'
        ],

        # Title selectors
        'title_selectors': [
            '[data-testid="ad-title"]',
            'h2[data-testid="ad-list-item-title"]',
            '.list-item__title',
            'h3[class*="Title"]',
            'span[class*="title"]'
        ],

        # Price selectors
        'price_selectors': [
            '[data-testid="ad-price"]',
            'span[data-testid="price"]',
            '.list-item__price',
            'span[class*="Price"]',
            '[class*="price-tag"]'
        ],

        # Image selectors
        'image_selectors': [
            'img[data-testid="ad-image"]',
            '.list-item__image img',
            'img[src*="willhaben"]',
            'picture img'
        ],

        # Location selectors
        'location_selectors': [
            '[data-testid="ad-location"]',
            '.list-item__location',
            'span[class*="Location"]'
        ],

        # URL pattern for extracting ad ID
        'url_pattern': r'/iad/kaufen-und-verkaufen/d/([^/]+)-(\d+)',

        # Condition mapping (German - Austria)
        'condition_map': {
            'new': 'Neu',
            'like_new': 'Neuwertig',
            'very_good': 'Sehr gut',
            'good': 'Gut',
            'fair': 'Gebraucht'
        },

        'condition_labels': {
            'Neu': 'new',
            'Neuwertig': 'like_new',
            'Sehr gut': 'very_good',
            'Gut': 'good',
            'Gebraucht': 'fair'
        },

        # Category mapping
        'categories': {
            'all': '/iad/kaufen-und-verkaufen/marktplatz',
            'clothing': '/iad/kaufen-und-verkaufen/mode-accessoires',
            'electronics': '/iad/kaufen-und-verkaufen/elektronik',
            'furniture': '/iad/kaufen-und-verkaufen/haus-garten',
            'sports': '/iad/kaufen-und-verkaufen/sport-sportgeraete',
            'toys': '/iad/kaufen-und-verkaufen/spielzeug',
            'baby': '/iad/kaufen-und-verkaufen/baby-kind'
        },

        # Pagination
        'pagination': {
            'param': 'page',
            'max_pages': 100
        },

        # Search params
        'search_params': {
            'keyword': 'keyword',
            'price_from': 'PRICE_FROM',
            'price_to': 'PRICE_TO',
            'sort': 'sort',
            'rows': 'rows'
        }
    }
}


def get_willhaben_config(country: str = 'at') -> dict:
    """Get Willhaben config - only Austria supported"""
    return WILLHABEN_CONFIG.get(country, WILLHABEN_CONFIG['at'])


def build_search_url(
    keywords: str,
    category: str = None,
    min_price: float = None,
    max_price: float = None,
    page: int = 1
) -> str:
    """Build Willhaben search URL with filters"""
    from urllib.parse import quote_plus, urlencode

    config = WILLHABEN_CONFIG['at']

    # Build base URL with category
    if category and category in config['categories']:
        base_url = f"{config['base_url']}{config['categories'][category]}"
    else:
        base_url = f"{config['base_url']}{config['categories']['all']}"

    # Build params
    params = {}

    if keywords:
        params['keyword'] = keywords

    if min_price:
        params['PRICE_FROM'] = int(min_price)

    if max_price:
        params['PRICE_TO'] = int(max_price)

    if page > 1:
        params['page'] = page

    # Build URL
    if params:
        return f"{base_url}?{urlencode(params)}"
    return base_url
