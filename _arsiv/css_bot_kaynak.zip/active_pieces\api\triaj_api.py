#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA Enterprise - Triaj Merkezi API
Hibrit Zeka Odaklı Triaj (Ayıklama) Merkezi Backend

Endpoints:
- /batches - Parti yönetimi
- /inbox - Gelen kutusu (ham veri)
- /favorites - Favoriler (kalıcı liste)
- /learning - Öğrenme merkezi

Author: TATANGA Team
Version: 1.0
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict
from contextlib import contextmanager

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Event Bus import
import sys
import asyncio
sys.path.insert(0, str(Path(__file__).parent.parent))
from core.event_bus import EventBus
from core.scrape_orchestrator import get_orchestrator, start_orchestrator


# ==================== CONFIGURATION ====================

DB_PATH = Path(__file__).parent.parent / 'storage' / 'tatanga.db'

# Event Bus instance (global)
event_bus = EventBus(persist_events=True)

app = FastAPI(
    title="TATANGA Triaj Merkezi API",
    description="Hibrit Zeka Odaklı Triaj (Ayıklama) Merkezi",
    version="1.0.0"
)

# CORS ayarları
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==================== DATABASE ====================

@contextmanager
def get_db():
    """Database connection context manager"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def dict_from_row(row):
    """Convert sqlite3.Row to dict"""
    return dict(row) if row else None


# ==================== MODELS ====================

class LikeRequest(BaseModel):
    notes: Optional[str] = None
    priority: Optional[int] = 0


class MessageRequest(BaseModel):
    template: Optional[str] = "default"
    custom_message: Optional[str] = None


class TrainTermRequest(BaseModel):
    language: str
    platform: str
    raw_term: str
    score: int  # 1-5


class FilterRuleRequest(BaseModel):
    name: str
    rule_type: str  # auto_reject, auto_approve, risky
    condition_field: str
    condition_operator: str
    condition_value: str
    action: str
    priority: Optional[int] = 0


# ==================== BATCH ENDPOINTS ====================

@app.get("/api/batches")
async def get_batches():
    """Tüm partileri listele"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT
                batch_id,
                COUNT(*) as total_count,
                COUNT(CASE WHEN is_in_inbox = 1 THEN 1 END) as inbox_count,
                MIN(scraped_at) as first_scraped,
                MAX(scraped_at) as last_scraped
            FROM products
            WHERE batch_id IS NOT NULL
            GROUP BY batch_id
            ORDER BY last_scraped DESC
        """)
        rows = cursor.fetchall()

        batches = []
        for row in rows:
            batches.append({
                'batch_id': row['batch_id'],
                'total_count': row['total_count'],
                'inbox_count': row['inbox_count'],
                'first_scraped': row['first_scraped'],
                'last_scraped': row['last_scraped']
            })

        return {'batches': batches, 'count': len(batches)}


@app.delete("/api/batches/{batch_id}/clear")
async def clear_batch(batch_id: str, keep_favorites: bool = True):
    """
    Partiyi temizle

    Bu en önemli temizlik tetiği:
    - Favoriye alınmayan tüm ürünleri siler
    - keep_favorites=True ise favorilerdeki ürünler korunur
    """
    with get_db() as conn:
        cursor = conn.cursor()

        if keep_favorites:
            # Favorilerde olmayan ürünleri sil
            cursor.execute("""
                DELETE FROM products
                WHERE batch_id = ?
                AND id NOT IN (SELECT product_id FROM favorites)
            """, (batch_id,))
        else:
            # Tüm partiyi sil
            cursor.execute("DELETE FROM products WHERE batch_id = ?", (batch_id,))

        deleted_count = cursor.rowcount
        conn.commit()

        return {
            'success': True,
            'batch_id': batch_id,
            'deleted_count': deleted_count,
            'message': f'{deleted_count} ürün silindi'
        }


# ==================== INBOX ENDPOINTS ====================

@app.get("/api/inbox")
async def get_inbox(
    batch_id: Optional[str] = None,
    min_score: Optional[int] = Query(None, ge=1, le=5),
    max_score: Optional[int] = Query(None, ge=1, le=5),
    product_type: Optional[str] = None,  # standard, vintage, conflicting
    min_shipping_days: Optional[int] = None,
    max_shipping_days: Optional[int] = None,
    min_profit: Optional[float] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    platform: Optional[str] = None,
    sort_by: str = "scraped_at",
    sort_order: str = "desc",
    limit: int = 50,
    offset: int = 0
):
    """
    Gelen kutusunu filtrele ve listele

    Bu endpoint arayüzdeki "Akıllı Filtreleme Çubuğu"nu destekler.
    Filtreler: Durum skoru, ürün tipi, kargo süresi, kâr, fiyat
    """
    with get_db() as conn:
        cursor = conn.cursor()

        # Base query
        query = """
            SELECT
                p.*,
                ps.normalized_score,
                ps.is_conflicting,
                ps.conflict_reason,
                ps.profit_amount,
                ps.profit_margin,
                ps.filter_decision
            FROM products p
            LEFT JOIN product_scores ps ON p.id = ps.product_id
            WHERE p.is_in_inbox = 1
        """
        params = []

        # Batch filter
        if batch_id:
            query += " AND p.batch_id = ?"
            params.append(batch_id)

        # Score filter
        if min_score:
            query += " AND ps.normalized_score >= ?"
            params.append(min_score)
        if max_score:
            query += " AND ps.normalized_score <= ?"
            params.append(max_score)

        # Product type filter
        if product_type:
            if product_type == 'conflicting':
                query += " AND ps.is_conflicting = 1"
            else:
                query += " AND p.product_type = ?"
                params.append(product_type)

        # Shipping filter
        if min_shipping_days:
            query += " AND p.estimated_shipping_days >= ?"
            params.append(min_shipping_days)
        if max_shipping_days:
            query += " AND p.estimated_shipping_days <= ?"
            params.append(max_shipping_days)

        # Profit filter
        if min_profit:
            query += " AND ps.profit_margin >= ?"
            params.append(min_profit)

        # Price filter
        if min_price:
            query += " AND p.price >= ?"
            params.append(min_price)
        if max_price:
            query += " AND p.price <= ?"
            params.append(max_price)

        # Platform filter
        if platform:
            query += " AND p.platform LIKE ?"
            params.append(f"%{platform}%")

        # Count total before pagination
        count_query = query.replace("SELECT\n                p.*,", "SELECT COUNT(*)")
        count_query = count_query.split("FROM products")[0] + "COUNT(*) FROM products" + count_query.split("FROM products")[1]

        # Sorting
        valid_sort_fields = ['scraped_at', 'price', 'normalized_score', 'profit_margin', 'estimated_shipping_days']
        if sort_by not in valid_sort_fields:
            sort_by = 'scraped_at'

        sort_order = 'DESC' if sort_order.lower() == 'desc' else 'ASC'
        query += f" ORDER BY {sort_by} {sort_order}"

        # Pagination
        query += " LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        cursor.execute(query, params)
        rows = cursor.fetchall()

        products = []
        for row in rows:
            product = dict_from_row(row)
            # Parse images JSON
            if product.get('images'):
                try:
                    product['images'] = json.loads(product['images'])
                except:
                    product['images'] = []
            products.append(product)

        # Get total count
        cursor.execute("""
            SELECT COUNT(*) FROM products WHERE is_in_inbox = 1
        """ + (" AND batch_id = ?" if batch_id else ""),
            [batch_id] if batch_id else []
        )
        total_count = cursor.fetchone()[0]

        return {
            'products': products,
            'count': len(products),
            'total': total_count,
            'offset': offset,
            'limit': limit
        }


@app.post("/api/inbox/{product_id}/like")
async def like_product(product_id: int, request: LikeRequest):
    """
    Ürünü beğen (Favorilere taşı)

    Tetiklenen Otonom Sonuç:
    - Ürün products tablosundan kopyalanır
    - favorites tablosuna eklenir
    - is_in_inbox = 0 yapılır
    """
    with get_db() as conn:
        cursor = conn.cursor()

        # Check if product exists
        cursor.execute("SELECT * FROM products WHERE id = ?", (product_id,))
        product = cursor.fetchone()

        if not product:
            raise HTTPException(status_code=404, detail="Ürün bulunamadı")

        # Add to favorites
        try:
            cursor.execute("""
                INSERT INTO favorites (product_id, notes, priority, added_at)
                VALUES (?, ?, ?, ?)
            """, (product_id, request.notes, request.priority, datetime.now()))
        except sqlite3.IntegrityError:
            # Already in favorites
            pass

        # Remove from inbox
        cursor.execute("""
            UPDATE products SET is_in_inbox = 0 WHERE id = ?
        """, (product_id,))

        conn.commit()

        return {
            'success': True,
            'product_id': product_id,
            'message': 'Ürün favorilere eklendi'
        }


@app.delete("/api/inbox/{product_id}")
async def delete_from_inbox(product_id: int):
    """
    Ürünü gelen kutusundan sil

    Tetiklenen Otonom Sonuç:
    - Ürün products tablosundan kalıcı olarak silinir
    """
    with get_db() as conn:
        cursor = conn.cursor()

        cursor.execute("DELETE FROM products WHERE id = ? AND is_in_inbox = 1", (product_id,))

        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Ürün bulunamadı veya zaten silinmiş")

        conn.commit()

        return {
            'success': True,
            'product_id': product_id,
            'message': 'Ürün silindi'
        }


@app.post("/api/inbox/bulk-like")
async def bulk_like(product_ids: List[int]):
    """Toplu beğenme"""
    with get_db() as conn:
        cursor = conn.cursor()
        liked_count = 0

        for pid in product_ids:
            try:
                cursor.execute("""
                    INSERT OR IGNORE INTO favorites (product_id, added_at)
                    VALUES (?, ?)
                """, (pid, datetime.now()))

                cursor.execute("UPDATE products SET is_in_inbox = 0 WHERE id = ?", (pid,))
                liked_count += 1
            except:
                pass

        conn.commit()

        return {
            'success': True,
            'liked_count': liked_count,
            'message': f'{liked_count} ürün favorilere eklendi'
        }


@app.post("/api/inbox/bulk-delete")
async def bulk_delete(product_ids: List[int]):
    """Toplu silme"""
    with get_db() as conn:
        cursor = conn.cursor()

        placeholders = ','.join(['?' for _ in product_ids])
        cursor.execute(f"""
            DELETE FROM products WHERE id IN ({placeholders}) AND is_in_inbox = 1
        """, product_ids)

        deleted_count = cursor.rowcount
        conn.commit()

        return {
            'success': True,
            'deleted_count': deleted_count,
            'message': f'{deleted_count} ürün silindi'
        }


# ==================== FAVORITES ENDPOINTS ====================

@app.get("/api/favorites")
async def get_favorites(
    status: Optional[str] = None,  # pending, processing, published
    limit: int = 50,
    offset: int = 0
):
    """Favorileri listele"""
    with get_db() as conn:
        cursor = conn.cursor()

        query = """
            SELECT
                f.*,
                p.title, p.url, p.price, p.currency, p.platform,
                p.condition, p.brand, p.images, p.location,
                p.estimated_shipping_days,
                ps.normalized_score, ps.profit_amount, ps.profit_margin
            FROM favorites f
            JOIN products p ON f.product_id = p.id
            LEFT JOIN product_scores ps ON p.id = ps.product_id
            ORDER BY f.added_at DESC
            LIMIT ? OFFSET ?
        """

        cursor.execute(query, (limit, offset))
        rows = cursor.fetchall()

        favorites = []
        for row in rows:
            fav = dict_from_row(row)
            if fav.get('images'):
                try:
                    fav['images'] = json.loads(fav['images'])
                except:
                    fav['images'] = []
            favorites.append(fav)

        # Total count
        cursor.execute("SELECT COUNT(*) FROM favorites")
        total = cursor.fetchone()[0]

        return {
            'favorites': favorites,
            'count': len(favorites),
            'total': total
        }


@app.post("/api/favorites/{product_id}/publish")
async def publish_favorite(product_id: int):
    """
    Favoriyi yayına al

    Tetiklenen Otonom Sonuç:
    - AgentOrchestrator'a 'action_requested' eventi atılır
    - SalesManager fiyat takibini başlatır
    - UploadAgent mağazaya yükleme yapar
    """
    # Get product details
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT p.*, ps.profit_margin, ps.benchmark_price
            FROM products p
            LEFT JOIN product_scores ps ON p.id = ps.product_id
            WHERE p.id = ?
        """, (product_id,))
        product = dict_from_row(cursor.fetchone())

    if not product:
        raise HTTPException(status_code=404, detail="Ürün bulunamadı")

    # Emit event to Event Bus
    event = await event_bus.emit(
        event_type='action_requested',
        data={
            'action': 'publish_item',
            'product_id': product_id,
            'product_url': product.get('url'),
            'platform': product.get('platform'),
            'price': product.get('price'),
            'profit_margin': product.get('profit_margin')
        },
        source='triaj_api'
    )

    return {
        'success': True,
        'product_id': product_id,
        'message': 'Yayınlama işlemi başlatıldı',
        'event_id': event.id,
        'event_type': 'action_requested'
    }


@app.post("/api/favorites/{product_id}/message")
async def send_message(product_id: int, request: MessageRequest):
    """
    Satıcıya mesaj gönder

    Tetiklenen Otonom Sonuç:
    - CommunicationManager'a 'action_requested' eventi atılır
    - İlgili dilde otomatik çeviri yapılır
    - Mesaj kuyruğuna eklenir
    """
    # Get product and seller details
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT p.*, p.seller_id, p.seller_name, p.language
            FROM products p
            WHERE p.id = ?
        """, (product_id,))
        product = dict_from_row(cursor.fetchone())

    if not product:
        raise HTTPException(status_code=404, detail="Ürün bulunamadı")

    # Emit event to Event Bus
    event = await event_bus.emit(
        event_type='action_requested',
        data={
            'action': 'send_message',
            'product_id': product_id,
            'product_url': product.get('url'),
            'platform': product.get('platform'),
            'seller_id': product.get('seller_id'),
            'seller_name': product.get('seller_name'),
            'language': product.get('language'),
            'template': request.template,
            'custom_message': request.custom_message
        },
        source='triaj_api'
    )

    return {
        'success': True,
        'product_id': product_id,
        'message': 'Mesaj gönderme işlemi başlatıldı',
        'event_id': event.id,
        'event_type': 'action_requested'
    }


@app.delete("/api/favorites/{product_id}")
async def remove_from_favorites(product_id: int):
    """Favoriyi kaldır"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM favorites WHERE product_id = ?", (product_id,))

        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Favori bulunamadı")

        conn.commit()

        return {
            'success': True,
            'product_id': product_id,
            'message': 'Favoriden kaldırıldı'
        }


# ==================== LEARNING CENTER ENDPOINTS ====================

@app.get("/api/learning/unknown-terms")
async def get_unknown_terms():
    """
    Bilinmeyen durum terimlerini listele

    Bunlar kullanıcının eğitmesi gereken terimler.
    """
    with get_db() as conn:
        cursor = conn.cursor()

        # Find conditions that are not in condition_mapping
        cursor.execute("""
            SELECT DISTINCT
                p.condition,
                p.platform,
                p.language,
                COUNT(*) as count
            FROM products p
            WHERE p.condition IS NOT NULL
            AND p.condition != ''
            AND NOT EXISTS (
                SELECT 1 FROM condition_mapping cm
                WHERE cm.raw_term = p.condition
                AND (cm.platform = p.platform OR cm.platform = '*')
            )
            GROUP BY p.condition, p.platform, p.language
            ORDER BY count DESC
            LIMIT 50
        """)

        rows = cursor.fetchall()

        unknown_terms = []
        for row in rows:
            unknown_terms.append({
                'term': row['condition'],
                'platform': row['platform'],
                'language': row['language'],
                'count': row['count']
            })

        return {'unknown_terms': unknown_terms, 'count': len(unknown_terms)}


@app.post("/api/learning/train-term")
async def train_term(request: TrainTermRequest):
    """
    Yeni terim eğit

    Tetiklenen Otonom Sonuç:
    - condition_mapping tablosuna yeni terim eklenir
    - Bir sonraki kazımada bu terim otomatik puanlanır
    """
    with get_db() as conn:
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT INTO condition_mapping
                (language, platform, raw_term, normalized_score, confidence, learned_from, is_verified)
                VALUES (?, ?, ?, ?, 0.8, 'user_training', 1)
            """, (request.language, request.platform, request.raw_term, request.score))

            conn.commit()

            return {
                'success': True,
                'term': request.raw_term,
                'score': request.score,
                'message': 'Terim başarıyla eğitildi'
            }

        except sqlite3.IntegrityError:
            # Term already exists, update it
            cursor.execute("""
                UPDATE condition_mapping
                SET normalized_score = ?, updated_at = ?
                WHERE language = ? AND platform = ? AND raw_term = ?
            """, (request.score, datetime.now(), request.language, request.platform, request.raw_term))

            conn.commit()

            return {
                'success': True,
                'term': request.raw_term,
                'score': request.score,
                'message': 'Terim güncellendi'
            }


@app.get("/api/learning/rules")
async def get_rules():
    """Filtreleme kurallarını listele"""
    with get_db() as conn:
        cursor = conn.cursor()

        cursor.execute("""
            SELECT * FROM filtering_rules
            ORDER BY priority DESC, created_at DESC
        """)

        rules = [dict_from_row(row) for row in cursor.fetchall()]

        return {'rules': rules, 'count': len(rules)}


@app.post("/api/learning/rules")
async def create_rule(request: FilterRuleRequest):
    """
    Yeni filtreleme kuralı ekle

    Tetiklenen Otonom Sonuç:
    - FilteringAgent konfigürasyonu güncellenir
    - Bir sonraki kazımada bu kural otonom olarak uygulanır
    """
    with get_db() as conn:
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO filtering_rules
            (name, rule_type, condition_field, condition_operator, condition_value, action, priority)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            request.name, request.rule_type, request.condition_field,
            request.condition_operator, request.condition_value,
            request.action, request.priority
        ))

        conn.commit()

        return {
            'success': True,
            'rule_id': cursor.lastrowid,
            'message': 'Kural oluşturuldu'
        }


@app.delete("/api/learning/rules/{rule_id}")
async def delete_rule(rule_id: int):
    """Kuralı sil"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM filtering_rules WHERE id = ?", (rule_id,))

        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Kural bulunamadı")

        conn.commit()

        return {
            'success': True,
            'rule_id': rule_id,
            'message': 'Kural silindi'
        }


@app.put("/api/learning/rules/{rule_id}/toggle")
async def toggle_rule(rule_id: int):
    """Kuralı aktif/pasif yap"""
    with get_db() as conn:
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE filtering_rules
            SET is_active = NOT is_active, updated_at = ?
            WHERE id = ?
        """, (datetime.now(), rule_id))

        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Kural bulunamadı")

        conn.commit()

        # Get new state
        cursor.execute("SELECT is_active FROM filtering_rules WHERE id = ?", (rule_id,))
        new_state = cursor.fetchone()['is_active']

        return {
            'success': True,
            'rule_id': rule_id,
            'is_active': bool(new_state),
            'message': f"Kural {'aktif' if new_state else 'pasif'} yapıldı"
        }


# ==================== STATS ENDPOINTS ====================

@app.get("/api/stats")
async def get_stats():
    """Genel istatistikleri getir"""
    with get_db() as conn:
        cursor = conn.cursor()

        stats = {}

        # Inbox count
        cursor.execute("SELECT COUNT(*) FROM products WHERE is_in_inbox = 1")
        stats['inbox_count'] = cursor.fetchone()[0]

        # Favorites count
        cursor.execute("SELECT COUNT(*) FROM favorites")
        stats['favorites_count'] = cursor.fetchone()[0]

        # Today's scraped
        cursor.execute("""
            SELECT COUNT(*) FROM products
            WHERE DATE(scraped_at) = DATE('now')
        """)
        stats['today_scraped'] = cursor.fetchone()[0]

        # By product type
        cursor.execute("""
            SELECT product_type, COUNT(*) as count
            FROM products WHERE is_in_inbox = 1
            GROUP BY product_type
        """)
        stats['by_type'] = {row['product_type'] or 'standard': row['count'] for row in cursor.fetchall()}

        # By shipping category
        cursor.execute("""
            SELECT
                CASE
                    WHEN estimated_shipping_days <= 2 THEN 'fast'
                    WHEN estimated_shipping_days <= 4 THEN 'medium'
                    WHEN estimated_shipping_days <= 6 THEN 'slow'
                    ELSE 'very_slow'
                END as category,
                COUNT(*) as count
            FROM products WHERE is_in_inbox = 1 AND estimated_shipping_days IS NOT NULL
            GROUP BY category
        """)
        stats['by_shipping'] = {row['category']: row['count'] for row in cursor.fetchall()}

        # Active rules count
        cursor.execute("SELECT COUNT(*) FROM filtering_rules WHERE is_active = 1")
        stats['active_rules'] = cursor.fetchone()[0]

        return stats


# ==================== SCRAPING ENDPOINTS ====================

# Active scraping jobs (in-memory)
scraping_jobs: Dict[str, Dict] = {}


class ScrapeRequest(BaseModel):
    query: str
    platforms: List[str] = []  # Empty = all
    min_price: int = 0
    max_price: int = 1000
    min_score: int = 3
    mode: str = "parallel"  # parallel or sequential
    rate_limit: int = 3  # seconds between requests (sequential mode)


@app.post("/api/scrape/start")
async def start_scraping(request: ScrapeRequest):
    """
    Kazıma işlemi başlat

    Dashboard'dan kazıma başlatmak için kullanılır.
    Event Bus'a 'scrape_requested' eventi atılır.
    """
    import uuid

    batch_id = f"{request.query.replace(' ', '_').lower()}_{datetime.now().strftime('%Y%m%d_%H%M')}"
    job_id = str(uuid.uuid4())[:8]

    # Job kaydı oluştur
    scraping_jobs[job_id] = {
        'job_id': job_id,
        'batch_id': batch_id,
        'query': request.query,
        'platforms': request.platforms if request.platforms else ['all'],
        'min_price': request.min_price,
        'max_price': request.max_price,
        'min_score': request.min_score,
        'mode': request.mode,
        'status': 'started',
        'progress': 0,
        'total_platforms': 36 if not request.platforms else len(request.platforms),
        'products_found': 0,
        'started_at': datetime.now().isoformat(),
        'errors': []
    }

    # Event Bus'a emit
    try:
        event = await event_bus.emit(
            event_type='scrape_requested',
            data={
                'job_id': job_id,
                'batch_id': batch_id,
                'query': request.query,
                'platforms': request.platforms,
                'filters': {
                    'min_price': request.min_price,
                    'max_price': request.max_price,
                    'min_score': request.min_score
                },
                'mode': request.mode,
                'rate_limit': request.rate_limit
            },
            source='triaj_api'
        )
        event_id = event.id
    except:
        event_id = None

    return {
        'success': True,
        'job_id': job_id,
        'batch_id': batch_id,
        'message': f'Kazıma başlatıldı: {request.query}',
        'event_id': event_id,
        'status_url': f'/api/scrape/status/{job_id}'
    }


@app.get("/api/scrape/status/{job_id}")
async def get_scrape_status(job_id: str):
    """Kazıma işlemi durumunu getir"""
    if job_id not in scraping_jobs:
        raise HTTPException(status_code=404, detail="Job bulunamadı")

    return scraping_jobs[job_id]


@app.get("/api/scrape/jobs")
async def list_scrape_jobs():
    """Tüm kazıma işlemlerini listele"""
    return {
        'jobs': list(scraping_jobs.values()),
        'total': len(scraping_jobs)
    }


@app.post("/api/scrape/stop/{job_id}")
async def stop_scraping(job_id: str):
    """Kazıma işlemini durdur"""
    if job_id not in scraping_jobs:
        raise HTTPException(status_code=404, detail="Job bulunamadı")

    scraping_jobs[job_id]['status'] = 'stopped'

    # Event Bus'a emit
    await event_bus.emit(
        event_type='scrape_stopped',
        data={'job_id': job_id},
        source='triaj_api'
    )

    return {
        'success': True,
        'job_id': job_id,
        'message': 'Kazıma durduruldu'
    }


# ==================== ORCHESTRATOR INTEGRATION ====================

# Global orchestrator instance
orchestrator = None


@app.on_event("startup")
async def startup_event():
    """API basladiginda orchestrator'i baslat"""
    global orchestrator
    try:
        orchestrator = await start_orchestrator()
        print("[API] Scrape Orchestrator initialized successfully")
    except Exception as e:
        print(f"[API] Warning: Orchestrator init failed: {e}")
        orchestrator = None


@app.get("/api/scrape/orchestrator/status")
async def get_orchestrator_status():
    """Orchestrator durumunu getir"""
    if orchestrator:
        return {
            'status': 'active',
            'stats': orchestrator.get_stats(),
            'active_jobs': orchestrator.get_all_jobs()
        }
    return {
        'status': 'inactive',
        'message': 'Orchestrator not initialized'
    }


@app.get("/api/scrape/live-status/{job_id}")
async def get_live_job_status(job_id: str):
    """Orchestrator'dan canli job durumu"""
    if orchestrator:
        job = orchestrator.get_job_status(job_id)
        if job:
            return job

    # Fallback to in-memory jobs
    if job_id in scraping_jobs:
        return scraping_jobs[job_id]

    raise HTTPException(status_code=404, detail="Job bulunamadi")


# ==================== HEALTH CHECK ====================

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    orchestrator_status = "active" if orchestrator else "inactive"
    return {
        'status': 'healthy',
        'service': 'TATANGA Triaj Merkezi API',
        'version': '2.0.0',
        'orchestrator': orchestrator_status,
        'timestamp': datetime.now().isoformat()
    }


@app.get("/api/system/logs")
async def get_system_logs(limit: int = 100, level: str = None):
    """Sistem loglarini getir"""
    log_file = Path(__file__).parent.parent / 'storage' / 'scrape_orchestrator.log'

    if not log_file.exists():
        return {'logs': [], 'message': 'Log file not found'}

    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        # Son N satiri al
        lines = lines[-limit:]

        logs = []
        for line in lines:
            line = line.strip()
            if line:
                # Level filtrele
                if level:
                    if f"| {level.upper()} |" in line:
                        logs.append(line)
                else:
                    logs.append(line)

        return {
            'logs': logs,
            'total': len(logs),
            'file': str(log_file)
        }
    except Exception as e:
        return {'logs': [], 'error': str(e)}


@app.get("/api/system/errors")
async def get_system_errors():
    """Son hatalari getir"""
    if orchestrator:
        all_jobs = orchestrator.get_all_jobs()
        errors = []
        for job in all_jobs:
            if job.get('errors'):
                for error in job['errors']:
                    errors.append({
                        'job_id': job['job_id'],
                        'batch_id': job['batch_id'],
                        'error': error
                    })
        return {
            'errors': errors,
            'total': len(errors)
        }
    return {'errors': [], 'total': 0}


# ==================== RUN SERVER ====================

if __name__ == "__main__":
    import uvicorn
    print("=" * 60)
    print("TATANGA Triaj Merkezi API v2.0")
    print("With Scrape Orchestrator Integration")
    print("=" * 60)
    uvicorn.run(app, host="0.0.0.0", port=8080)