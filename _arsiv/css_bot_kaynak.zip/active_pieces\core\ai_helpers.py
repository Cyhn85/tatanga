#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TATANGA - AI Helpers
====================
AI ile SEO-optimize başlık ve açıklama üretimi.
Gemini API kullanır.
"""

import os
import json
import re
from typing import Dict, Optional
from pathlib import Path

# Gemini API Key
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', 'AIzaSyBwA4VQVEUROtcK9XZ228bAoCvRuHQ2LoE')


def generate_seo_title(product: Dict, language: str = 'de') -> str:
    """
    AI ile SEO-optimize başlık üret

    Args:
        product: Ürün bilgileri dict
        language: Hedef dil (de, en, tr)

    Returns:
        Orijinal SEO-optimize başlık
    """
    try:
        import google.generativeai as genai

        genai.configure(api_key=GEMINI_API_KEY)
        model = genai.GenerativeModel('gemini-1.5-flash')

        # Ürün bilgilerini hazırla
        brand = product.get('brand', '')
        category = product.get('category', '')
        size = product.get('size', '')
        condition = product.get('condition', '')
        color = product.get('color', '')
        original_title = product.get('title', '')

        prompt = f"""
Du bist ein E-Commerce SEO-Experte. Erstelle einen KOMPLETT NEUEN und ORIGINALEN Produkttitel auf Deutsch.

Original-Informationen:
- Titel: {original_title}
- Marke: {brand}
- Kategorie: {category}
- Größe: {size}
- Zustand: {condition}
- Farbe: {color}

Regeln:
1. KOPIERE NICHT den Originaltitel - erstelle etwas NEUES
2. Maximal 80 Zeichen
3. Wichtige Keywords am Anfang
4. Marke zuerst (wenn bekannt)
5. Größe und Zustand einbeziehen
6. Natürlich und ansprechend formulieren
7. KEINE Sonderzeichen wie #, *, etc.

Gib NUR den neuen Titel zurück, NICHTS anderes.
"""

        response = model.generate_content(prompt)
        new_title = response.text.strip()

        # Clean up
        new_title = re.sub(r'["\'\n\r]', '', new_title)
        new_title = new_title[:80]  # Max 80 chars

        return new_title if new_title else _fallback_title(product)

    except Exception as e:
        print(f"AI title generation failed: {e}")
        return _fallback_title(product)


def generate_seo_description(product: Dict, language: str = 'de') -> str:
    """
    AI ile SEO-optimize açıklama üret

    Args:
        product: Ürün bilgileri dict
        language: Hedef dil (de, en, tr)

    Returns:
        Orijinal SEO-optimize açıklama
    """
    try:
        import google.generativeai as genai

        genai.configure(api_key=GEMINI_API_KEY)
        model = genai.GenerativeModel('gemini-1.5-flash')

        brand = product.get('brand', '')
        category = product.get('category', '')
        size = product.get('size', '')
        condition = product.get('condition', '')
        color = product.get('color', '')
        original_title = product.get('title', '')
        original_desc = product.get('description', '')
        price = product.get('price', 0)

        prompt = f"""
Du bist ein E-Commerce Verkaufsexperte. Erstelle eine KOMPLETT NEUE und ORIGINALE Produktbeschreibung auf Deutsch.

Original-Informationen:
- Titel: {original_title}
- Beschreibung: {original_desc[:200] if original_desc else 'Keine'}
- Marke: {brand}
- Kategorie: {category}
- Größe: {size}
- Zustand: {condition}
- Farbe: {color}

Regeln:
1. KOPIERE NICHTS vom Original - schreibe KOMPLETT NEU
2. 150-300 Zeichen
3. Freundlich und verkaufsorientiert
4. Wichtige Details: Marke, Größe, Zustand
5. Am Ende: "Privatverkauf - keine Garantie/Rücknahme"
6. KEINE Sonderzeichen oder Emojis
7. Professionell aber persönlich

Gib NUR die neue Beschreibung zurück, NICHTS anderes.
"""

        response = model.generate_content(prompt)
        new_desc = response.text.strip()

        # Clean up
        new_desc = re.sub(r'["\']', '', new_desc)

        # Ensure legal disclaimer
        if 'privatverkauf' not in new_desc.lower():
            new_desc += "\n\nPrivatverkauf - keine Garantie/Rücknahme."

        return new_desc if new_desc else _fallback_description(product)

    except Exception as e:
        print(f"AI description generation failed: {e}")
        return _fallback_description(product)


def _fallback_title(product: Dict) -> str:
    """Fallback başlık üretici (AI yoksa)"""
    parts = []

    brand = product.get('brand', '')
    if brand and brand.lower() not in ['unknown', 'unbekannt', '']:
        parts.append(brand)

    category = product.get('category', 'Artikel')
    if category:
        parts.append(category)

    size = product.get('size', '')
    if size:
        parts.append(f"Gr. {size}")

    condition = product.get('condition', '')
    if condition:
        cond_map = {
            'new': 'Neu',
            'like_new': 'Wie Neu',
            'good': 'Gut',
            'fair': 'Akzeptabel'
        }
        parts.append(cond_map.get(condition.lower(), condition))

    return ' '.join(parts) if parts else product.get('title', 'Artikel')[:80]


def _fallback_description(product: Dict) -> str:
    """Fallback açıklama üretici (AI yoksa)"""
    title = product.get('title', 'Artikel')
    brand = product.get('brand', '')
    size = product.get('size', '')
    condition = product.get('condition', 'Gut')

    desc = f"Zum Verkauf steht: {title}\n\n"

    if brand and brand.lower() not in ['unknown', '']:
        desc += f"Marke: {brand}\n"
    if size:
        desc += f"Größe: {size}\n"

    desc += f"Zustand: {condition}\n\n"
    desc += "Bei Fragen einfach melden!\n"
    desc += "Privatverkauf - keine Garantie/Rücknahme."

    return desc


def generate_both(product: Dict, language: str = 'de') -> Dict[str, str]:
    """
    Başlık ve açıklama birlikte üret

    Returns:
        {'title': str, 'description': str}
    """
    return {
        'title': generate_seo_title(product, language),
        'description': generate_seo_description(product, language)
    }
