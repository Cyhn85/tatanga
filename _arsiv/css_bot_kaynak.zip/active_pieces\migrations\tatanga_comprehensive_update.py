"""
TATANGA Kapsamlı Güncelleme Scripti
====================================
1. JSON yapısını güncelle (images dizisi ekle)
2. Kaynak URL'leri kontrol et (satılmış/stok dışı tespiti)
3. Metadata iyileştirme (size, gender, category)
4. SEO optimizasyonu (title, description, keywords)
5. Hetzner görsel doğrulama
"""

import json
import re
import requests
from pathlib import Path
from datetime import datetime
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

# Paths
WEBSITE_PATH = Path(r"C:\Users\cyhnsrgc\Desktop\CSS-Berlin-Website")
JSON_PATH = WEBSITE_PATH / "scraped-products.json"
HETZNER_BASE_URL = "https://images.css-berlin.de/images"

# Size patterns
SIZE_PATTERNS = {
    'numeric': re.compile(r'\b(3[2-9]|4[0-9]|5[0-2])\b'),  # 32-52
    'letter': re.compile(r'\b(XXS|XS|S|M|L|XL|XXL|XXXL|2XL|3XL)\b', re.I),
    'eu': re.compile(r'\bEU\s*(\d{2})\b', re.I),
    'de': re.compile(r'\bGr\.?\s*(\d{2})\b', re.I),
}

# Gender keywords
GENDER_KEYWORDS = {
    'damen': ['damen', 'frauen', 'women', 'woman', 'ladies', 'female', 'mädchen'],
    'herren': ['herren', 'männer', 'men', 'man', 'male', 'jungen'],
    'kinder': ['kinder', 'kids', 'children', 'baby', 'mädchen', 'jungen', 'teenager'],
    'unisex': ['unisex', 'universal'],
}

# Category keywords
CATEGORY_KEYWORDS = {
    'jacken': ['jacke', 'jacket', 'mantel', 'coat', 'parka', 'blazer', 'weste', 'vest'],
    'hosen': ['hose', 'pants', 'jeans', 'trousers', 'leggings', 'shorts'],
    'kleider': ['kleid', 'dress', 'rock', 'skirt'],
    'oberteile': ['shirt', 'bluse', 'top', 'pullover', 'sweater', 'hoodie', 'sweatshirt', 't-shirt', 'tshirt'],
    'schuhe': ['schuh', 'shoe', 'boots', 'stiefel', 'sneaker', 'sandalen', 'pumps', 'loafer'],
    'taschen': ['tasche', 'bag', 'rucksack', 'backpack', 'handtasche', 'clutch'],
    'accessoires': ['schal', 'scarf', 'mütze', 'hat', 'gürtel', 'belt', 'schmuck', 'jewelry', 'uhr', 'watch'],
}

# Brand keywords (common brands)
BRAND_KEYWORDS = [
    'nike', 'adidas', 'puma', 'reebok', 'under armour', 'new balance',
    'gucci', 'prada', 'louis vuitton', 'chanel', 'dior', 'hermes', 'burberry',
    'zara', 'h&m', 'mango', 'cos', 'massimo dutti', 'uniqlo',
    'levi\'s', 'tommy hilfiger', 'ralph lauren', 'calvin klein', 'hugo boss',
    'north face', 'patagonia', 'columbia', 'jack wolfskin',
    'dr. martens', 'converse', 'vans', 'timberland', 'birkenstock',
    'michael kors', 'kate spade', 'coach', 'fossil', 'tory burch',
    'ugg', 'canada goose', 'moncler', 'stone island', 'acne studios',
]

# Sold/unavailable indicators in page content
SOLD_INDICATORS = [
    'verkauft', 'sold', 'nicht mehr verfügbar', 'not available',
    'reserviert', 'reserved', 'ausverkauft', 'out of stock',
    'deaktiviert', 'deactivated', 'gelöscht', 'deleted',
    'abgelaufen', 'expired', 'nicht gefunden', 'not found',
]


def load_json():
    """Load full JSON structure"""
    with open(JSON_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_products():
    """Load products from JSON"""
    data = load_json()
    return data.get('products', [])


def save_products(products, stats=None):
    """Save products to JSON with stats"""
    data = load_json()
    data['products'] = products
    if stats:
        data['stats'] = stats
    data['stats']['last_updated'] = datetime.now().strftime('%Y-%m-%d')
    data['stats']['total_products'] = len(products)

    with open(JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"[OK] {len(products)} urun kaydedildi")


def extract_size(text):
    """Extract size from text"""
    text_lower = text.lower()

    # Try letter sizes first
    match = SIZE_PATTERNS['letter'].search(text)
    if match:
        return match.group(1).upper()

    # Try EU/DE sizes
    for pattern_name in ['eu', 'de']:
        match = SIZE_PATTERNS[pattern_name].search(text)
        if match:
            return f"EU {match.group(1)}"

    # Try numeric
    match = SIZE_PATTERNS['numeric'].search(text)
    if match:
        return match.group(1)

    return None


def extract_gender(text):
    """Extract gender from text"""
    text_lower = text.lower()

    for gender, keywords in GENDER_KEYWORDS.items():
        for keyword in keywords:
            if keyword in text_lower:
                return gender.capitalize()

    return None


def extract_category(text):
    """Extract category from text"""
    text_lower = text.lower()

    for category, keywords in CATEGORY_KEYWORDS.items():
        for keyword in keywords:
            if keyword in text_lower:
                return category.capitalize()

    return None


def extract_brand(text):
    """Extract brand from text"""
    text_lower = text.lower()

    for brand in BRAND_KEYWORDS:
        if brand.lower() in text_lower:
            return brand.title()

    return None


def extract_condition(text):
    """Extract condition from text"""
    text_lower = text.lower()

    conditions = {
        'Neu mit Etikett': ['neu mit etikett', 'new with tag', 'nwt', 'ovp'],
        'Neu ohne Etikett': ['neu ohne etikett', 'new without tag', 'nwot'],
        'Sehr gut': ['sehr gut', 'excellent', 'wie neu', 'fast neu'],
        'Gut': ['gut', 'good', 'guter zustand'],
        'Akzeptabel': ['akzeptabel', 'acceptable', 'gebraucht', 'used'],
    }

    for condition, keywords in conditions.items():
        for keyword in keywords:
            if keyword in text_lower:
                return condition

    return None


def check_source_availability(url, timeout=10):
    """Check if source URL is still available"""
    if not url or url in ['unknown', 'Unknown', '']:
        return {'available': None, 'reason': 'No source URL'}

    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        response = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)

        if response.status_code == 404:
            return {'available': False, 'reason': '404 Not Found'}

        if response.status_code != 200:
            return {'available': False, 'reason': f'HTTP {response.status_code}'}

        # Check content for sold indicators
        content_lower = response.text.lower()
        for indicator in SOLD_INDICATORS:
            if indicator in content_lower:
                return {'available': False, 'reason': f'Sold indicator: {indicator}'}

        return {'available': True, 'reason': 'OK'}

    except requests.exceptions.Timeout:
        return {'available': False, 'reason': 'Timeout'}
    except requests.exceptions.RequestException as e:
        return {'available': False, 'reason': str(e)[:50]}


def check_image_availability(url, timeout=5):
    """Check if image URL is accessible"""
    if not url:
        return False

    try:
        response = requests.head(url, timeout=timeout, allow_redirects=True)
        return response.status_code == 200
    except:
        return False


def improve_seo(product):
    """Improve SEO for product"""
    title = product.get('title', '')
    description = product.get('description', '')

    # Extract metadata
    combined_text = f"{title} {description}"

    size = extract_size(combined_text)
    gender = extract_gender(combined_text)
    category = extract_category(combined_text)
    brand = extract_brand(combined_text)
    condition = extract_condition(combined_text)

    # Build keywords
    keywords = []
    if brand:
        keywords.append(brand)
    if category:
        keywords.append(category)
    if gender:
        keywords.append(gender)
    if size:
        keywords.append(f"Größe {size}")
    if condition:
        keywords.append(condition)

    # Add common search terms
    keywords.extend(['Second Hand', 'Berlin', 'CSS Berlin', 'Vintage', 'Fashion'])

    return {
        'size': size or product.get('size'),
        'gender': gender or product.get('gender'),
        'category': category or product.get('category'),
        'brand': brand or product.get('brand'),
        'condition': condition or product.get('condition'),
        'keywords': list(set(keywords)),
    }


def update_product_structure(product):
    """Update product to new structure with images array"""
    # Ensure images array exists
    if 'images' not in product or not product['images']:
        if 'image' in product and product['image']:
            product['images'] = [product['image']]
        else:
            product['images'] = []

    # Update image_count
    product['image_count'] = len(product['images'])

    return product


def analyze_products():
    """Analyze all products and generate report"""
    products = load_products()

    stats = {
        'total': len(products),
        'with_images_array': 0,
        'with_single_image': 0,
        'with_source_url': 0,
        'kleinanzeigen': 0,
        'vinted': 0,
        'ebay': 0,
        'other': 0,
        'hetzner_images': 0,
        'external_images': 0,
        'with_size': 0,
        'with_brand': 0,
        'with_gender': 0,
        'with_category': 0,
    }

    for product in products:
        # Image structure
        if 'images' in product and product['images']:
            stats['with_images_array'] += 1
        elif 'image' in product and product['image']:
            stats['with_single_image'] += 1

        # Source URL
        source = product.get('source_url', '')
        if source and source not in ['unknown', 'Unknown', '']:
            stats['with_source_url'] += 1
            if 'kleinanzeigen' in source:
                stats['kleinanzeigen'] += 1
            elif 'vinted' in source:
                stats['vinted'] += 1
            elif 'ebay' in source:
                stats['ebay'] += 1
            else:
                stats['other'] += 1

        # Image source
        image_url = product.get('image', '') or (product.get('images', [''])[0] if product.get('images') else '')
        if 'images.css-berlin.de' in image_url:
            stats['hetzner_images'] += 1
        elif image_url:
            stats['external_images'] += 1

        # Metadata
        if product.get('size'):
            stats['with_size'] += 1
        if product.get('brand'):
            stats['with_brand'] += 1
        if product.get('gender'):
            stats['with_gender'] += 1
        if product.get('category'):
            stats['with_category'] += 1

    return stats


def run_comprehensive_update():
    """Run comprehensive update"""
    print("=" * 60)
    print("TATANGA KAPSAMLI GUNCELLEME")
    print("=" * 60)

    # Load products
    products = load_products()
    print(f"\n[INFO] Toplam urun: {len(products)}")

    # Analyze before
    print("\n[STATS] MEVCUT DURUM:")
    stats = analyze_products()
    for key, value in stats.items():
        print(f"   {key}: {value}")

    # Update structure and SEO
    print("\n[UPDATE] GUNCELLEME BASLIYOR...")

    updated_count = 0
    source_checks = {'available': 0, 'unavailable': 0, 'no_source': 0}

    for i, product in enumerate(products):
        print(f"\r   Isleniyor: {i+1}/{len(products)}", end='')

        # Update structure
        product = update_product_structure(product)

        # Improve SEO
        seo_data = improve_seo(product)
        for key, value in seo_data.items():
            if value:
                product[key] = value

        updated_count += 1

    print(f"\n\n[OK] {updated_count} urun guncellendi")

    # Check source URLs (only for products with valid source)
    print("\n[CHECK] KAYNAK URL KONTROLU...")
    products_with_source = [p for p in products if p.get('source_url') and p['source_url'] not in ['unknown', 'Unknown', '']]
    print(f"   Kontrol edilecek: {len(products_with_source)} urun")

    unavailable_products = []

    for i, product in enumerate(products_with_source):
        print(f"\r   Kontrol: {i+1}/{len(products_with_source)} - {product.get('source_url', '')[:50]}...", end='')

        result = check_source_availability(product.get('source_url'))
        product['source_status'] = result
        product['last_source_check'] = datetime.now().isoformat()

        if result['available'] == False:
            unavailable_products.append({
                'id': product.get('id'),
                'title': product.get('title', '')[:50],
                'source': product.get('source_url'),
                'reason': result['reason']
            })
            source_checks['unavailable'] += 1
        elif result['available'] == True:
            source_checks['available'] += 1
        else:
            source_checks['no_source'] += 1

        time.sleep(0.5)  # Rate limiting

    print(f"\n\n[RESULTS] KAYNAK KONTROL SONUCLARI:")
    print(f"   [+] Mevcut: {source_checks['available']}")
    print(f"   [-] Mevcut Degil: {source_checks['unavailable']}")
    print(f"   [?] Kaynak yok: {source_checks['no_source']}")

    if unavailable_products:
        print(f"\n[WARN] SATILMIS/MEVCUT OLMAYAN URUNLER:")
        for p in unavailable_products:
            print(f"   - ID {p['id']}: {p['title']} ({p['reason']})")

    # Save updated products (without removing unavailable - user decision)
    save_products(products)

    # Final stats
    print("\n[STATS] GUNCELLENMIS DURUM:")
    final_stats = analyze_products()
    for key, value in final_stats.items():
        print(f"   {key}: {value}")

    print("\n" + "=" * 60)
    print("GUNCELLEME TAMAMLANDI")
    print("=" * 60)

    return {
        'updated': updated_count,
        'source_checks': source_checks,
        'unavailable': unavailable_products
    }


if __name__ == "__main__":
    result = run_comprehensive_update()
